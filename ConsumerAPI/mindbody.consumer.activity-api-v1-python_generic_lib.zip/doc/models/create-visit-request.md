
# Create Visit Request

VisitRequest object

## Structure

`CreateVisitRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `service_name` | `string` | Optional | The service name of the visit |
| `service_category` | `string` | Optional | The service category of the visit |
| `payment_method` | `string` | Optional | The payment method of the visit |
| `amount_paid` | `float` | Optional | The amount paid for the visit |
| `visit_date` | `datetime` | Optional | The date of the visit |
| `booking_date` | `datetime` | Optional | The booking date of the visit |
| `business_name` | `string` | Optional | The business name of the site where this visit was made |
| `location_name` | `string` | Optional | The location name of the site where this visit was made |
| `address_line_1` | `string` | Optional | The first line of the visit location’s street address |
| `address_line_2` | `string` | Optional | A second address line for the visit location’s street address, if needed |
| `city` | `string` | Optional | The visit location’s city |
| `state_code` | `string` | Optional | The visit location’s state or province code |
| `country_code` | `string` | Optional | The visit location’s country code |
| `postal_code` | `string` | Optional | The visit location’s postal code |

## Example (as JSON)

```json
{
  "serviceName": null,
  "serviceCategory": null,
  "paymentMethod": null,
  "amountPaid": null,
  "visitDate": null,
  "bookingDate": null,
  "businessName": null,
  "locationName": null,
  "addressLine1": null,
  "addressLine2": null,
  "city": null,
  "stateCode": null,
  "countryCode": null,
  "postalCode": null
}
```

