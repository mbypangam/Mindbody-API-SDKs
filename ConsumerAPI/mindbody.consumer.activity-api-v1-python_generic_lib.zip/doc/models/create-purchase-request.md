
# Create Purchase Request

PurchaseRequest object

## Structure

`CreatePurchaseRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product_name` | `string` | Optional | The service name of the purchase |
| `product_category` | `string` | Optional | The service category of the purchase |
| `payment_method` | `string` | Optional | The payment method of the purchase |
| `amount_paid` | `float` | Optional | The amount Paid for the purchase |
| `purchase_date` | `datetime` | Optional | The date of the purchase |
| `quantity` | `int` | Optional | The quantity of the purchase |
| `product_type` | `string` | Optional | The product type of the purchase |

## Example (as JSON)

```json
{
  "productName": null,
  "productCategory": null,
  "paymentMethod": null,
  "amountPaid": null,
  "purchaseDate": null,
  "quantity": null,
  "productType": null
}
```

