// <copyright file="ConsumerController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyConsumerActivityAPIV1.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using MindbodyConsumerActivityAPIV1.Standard;
    using MindbodyConsumerActivityAPIV1.Standard.Authentication;
    using MindbodyConsumerActivityAPIV1.Standard.Exceptions;
    using MindbodyConsumerActivityAPIV1.Standard.Http.Client;
    using MindbodyConsumerActivityAPIV1.Standard.Http.Request;
    using MindbodyConsumerActivityAPIV1.Standard.Http.Request.Configuration;
    using MindbodyConsumerActivityAPIV1.Standard.Http.Response;
    using MindbodyConsumerActivityAPIV1.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ConsumerController.
    /// </summary>
    public class ConsumerController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConsumerController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal ConsumerController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Return a list of all verified visits of a consumer for a given duration.  <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/visits" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/visits</a>.
        /// </summary>
        /// <param name="aPIKey">Required parameter: Example: .</param>
        /// <param name="applicationId">Required parameter: Application Id of the Partner making a request to the API..</param>
        /// <param name="startDate">Required parameter: Start date of the visit activity. It should be in "yyyy-mm-dd" format and it cannot be older than 3 months..</param>
        /// <param name="endDate">Required parameter: End date of the visit activity. It should be in "yyyy-mm-dd" format and future date is not allowed..</param>
        /// <param name="clientId">Required parameter: OAuth Client Id of the Partner making a request to the API.</param>
        /// <param name="isTestData">Optional parameter: Is Test Data of visit activity. If enable then return test data of consumer else provide actual data..</param>
        /// <returns>Returns the Models.VisitResponse response from the API call.</returns>
        public Models.VisitResponse GETConsumerVisits(
                string aPIKey,
                string applicationId,
                DateTime startDate,
                DateTime endDate,
                string clientId,
                bool? isTestData = null)
        {
            Task<Models.VisitResponse> t = this.GETConsumerVisitsAsync(aPIKey, applicationId, startDate, endDate, clientId, isTestData);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Return a list of all verified visits of a consumer for a given duration.  <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/visits" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/visits</a>.
        /// </summary>
        /// <param name="aPIKey">Required parameter: Example: .</param>
        /// <param name="applicationId">Required parameter: Application Id of the Partner making a request to the API..</param>
        /// <param name="startDate">Required parameter: Start date of the visit activity. It should be in "yyyy-mm-dd" format and it cannot be older than 3 months..</param>
        /// <param name="endDate">Required parameter: End date of the visit activity. It should be in "yyyy-mm-dd" format and future date is not allowed..</param>
        /// <param name="clientId">Required parameter: OAuth Client Id of the Partner making a request to the API.</param>
        /// <param name="isTestData">Optional parameter: Is Test Data of visit activity. If enable then return test data of consumer else provide actual data..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.VisitResponse response from the API call.</returns>
        public async Task<Models.VisitResponse> GETConsumerVisitsAsync(
                string aPIKey,
                string applicationId,
                DateTime startDate,
                DateTime endDate,
                string clientId,
                bool? isTestData = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/consumer/activity/v1/visits");

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "startDate", startDate.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") },
                { "endDate", endDate.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") },
                { "isTestData", isTestData },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "API-Key", aPIKey },
                { "applicationId", applicationId },
                { "clientId", clientId },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            if (response.StatusCode == 400)
            {
                throw new ErrorResponseException("Bad Request", context);
            }

            if (response.StatusCode == 401)
            {
                throw new ProblemDetailsException("Unauthorized", context);
            }

            if (response.StatusCode == 403)
            {
                throw new ProblemDetailsException("Forbidden", context);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.VisitResponse>(response.Body);
        }

        /// <summary>
        /// Return a list of all verified purchases of a consumer for a given duration. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/purchases" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/purchases</a>.
        /// </summary>
        /// <param name="aPIKey">Required parameter: Example: .</param>
        /// <param name="applicationId">Required parameter: Application Id of the Partner making a request to the API..</param>
        /// <param name="startDate">Required parameter: Start date of the Purchase activity. It should be in "yyyy-mm-dd" format and it cannot be older than 3 months..</param>
        /// <param name="endDate">Required parameter: End date of the Purchase activity. It should be in "yyyy-mm-dd" format and future date is not allowed..</param>
        /// <param name="clientId">Required parameter: OAuth Client Id of the Partner making a request to the API.</param>
        /// <param name="productType">Optional parameter: Product Type of the Purchase activity..</param>
        /// <param name="isTestData">Optional parameter: Is test data of purchase activity. If enable then return test data of consumer else provide actual data..</param>
        /// <returns>Returns the Models.PurchaseResponse response from the API call.</returns>
        public Models.PurchaseResponse GetVerifiedPurchases(
                string aPIKey,
                string applicationId,
                DateTime startDate,
                DateTime endDate,
                string clientId,
                string productType = null,
                bool? isTestData = null)
        {
            Task<Models.PurchaseResponse> t = this.GetVerifiedPurchasesAsync(aPIKey, applicationId, startDate, endDate, clientId, productType, isTestData);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Return a list of all verified purchases of a consumer for a given duration. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/purchases" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/purchases</a>.
        /// </summary>
        /// <param name="aPIKey">Required parameter: Example: .</param>
        /// <param name="applicationId">Required parameter: Application Id of the Partner making a request to the API..</param>
        /// <param name="startDate">Required parameter: Start date of the Purchase activity. It should be in "yyyy-mm-dd" format and it cannot be older than 3 months..</param>
        /// <param name="endDate">Required parameter: End date of the Purchase activity. It should be in "yyyy-mm-dd" format and future date is not allowed..</param>
        /// <param name="clientId">Required parameter: OAuth Client Id of the Partner making a request to the API.</param>
        /// <param name="productType">Optional parameter: Product Type of the Purchase activity..</param>
        /// <param name="isTestData">Optional parameter: Is test data of purchase activity. If enable then return test data of consumer else provide actual data..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PurchaseResponse response from the API call.</returns>
        public async Task<Models.PurchaseResponse> GetVerifiedPurchasesAsync(
                string aPIKey,
                string applicationId,
                DateTime startDate,
                DateTime endDate,
                string clientId,
                string productType = null,
                bool? isTestData = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/consumer/activity/v1/purchases");

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "startDate", startDate.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") },
                { "endDate", endDate.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") },
                { "productType", productType },
                { "isTestData", isTestData },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "API-Key", aPIKey },
                { "applicationId", applicationId },
                { "clientId", clientId },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            if (response.StatusCode == 400)
            {
                throw new ErrorResponseException("Bad Request", context);
            }

            if (response.StatusCode == 401)
            {
                throw new ProblemDetailsException("Unauthorized", context);
            }

            if (response.StatusCode == 403)
            {
                throw new ProblemDetailsException("Forbidden", context);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PurchaseResponse>(response.Body);
        }

        /// <summary>
        /// Disconnect consumer from a partner. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/consumer" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/consumer</a>.
        /// </summary>
        /// <param name="aPIKey">Required parameter: Example: .</param>
        /// <param name="clientId">Required parameter: OAuth Client Id of the Partner making a request to the API.</param>
        public void DisconnectConsumerFromAPartner(
                string aPIKey,
                string clientId)
        {
            Task t = this.DisconnectConsumerFromAPartnerAsync(aPIKey, clientId);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Disconnect consumer from a partner. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/consumer" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/consumer</a>.
        /// </summary>
        /// <param name="aPIKey">Required parameter: Example: .</param>
        /// <param name="clientId">Required parameter: OAuth Client Id of the Partner making a request to the API.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DisconnectConsumerFromAPartnerAsync(
                string aPIKey,
                string clientId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/consumer/activity/v1/consumer");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "API-Key", aPIKey },
                { "clientId", clientId },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            if (response.StatusCode == 400)
            {
                throw new ErrorResponseException("Bad Request", context);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }
    }
}