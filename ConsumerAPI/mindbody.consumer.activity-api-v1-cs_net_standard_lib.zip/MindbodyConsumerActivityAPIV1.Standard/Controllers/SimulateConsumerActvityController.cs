// <copyright file="SimulateConsumerActvityController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyConsumerActivityAPIV1.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using MindbodyConsumerActivityAPIV1.Standard;
    using MindbodyConsumerActivityAPIV1.Standard.Authentication;
    using MindbodyConsumerActivityAPIV1.Standard.Exceptions;
    using MindbodyConsumerActivityAPIV1.Standard.Http.Client;
    using MindbodyConsumerActivityAPIV1.Standard.Http.Request;
    using MindbodyConsumerActivityAPIV1.Standard.Http.Request.Configuration;
    using MindbodyConsumerActivityAPIV1.Standard.Http.Response;
    using MindbodyConsumerActivityAPIV1.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// SimulateConsumerActvityController.
    /// </summary>
    public class SimulateConsumerActvityController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SimulateConsumerActvityController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal SimulateConsumerActvityController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Create a new test visit. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/visit" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/visit</a>.
        /// </summary>
        /// <param name="aPIKey">Required parameter: Example: .</param>
        /// <param name="body">Optional parameter: Visit object.</param>
        public void CreateTestDataForVerifiedVisits(
                string aPIKey,
                Models.CreateVisitRequest body = null)
        {
            Task t = this.CreateTestDataForVerifiedVisitsAsync(aPIKey, body);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Create a new test visit. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/visit" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/visit</a>.
        /// </summary>
        /// <param name="aPIKey">Required parameter: Example: .</param>
        /// <param name="body">Optional parameter: Visit object.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task CreateTestDataForVerifiedVisitsAsync(
                string aPIKey,
                Models.CreateVisitRequest body = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/consumer/activity/v1/simulate/visit");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "API-Key", aPIKey },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            if (response.StatusCode == 400)
            {
                throw new ErrorResponseException("Bad Request", context);
            }

            if (response.StatusCode == 401)
            {
                throw new ProblemDetailsException("Unauthorized", context);
            }

            if (response.StatusCode == 403)
            {
                throw new ProblemDetailsException("Forbidden", context);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Create a new test purchase. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/purchase" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/purchase</a>.
        /// </summary>
        /// <param name="aPIKey">Required parameter: Example: .</param>
        /// <param name="body">Optional parameter: Purchase object.</param>
        public void CreateTestDataForVerifiedPurchases(
                string aPIKey,
                Models.CreatePurchaseRequest body = null)
        {
            Task t = this.CreateTestDataForVerifiedPurchasesAsync(aPIKey, body);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Create a new test purchase. <br> <a href="https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/purchase" target="_blank">https://api.mindbodyonline.com/partnergateway/consumer/activity/v1/simulate/purchase</a>.
        /// </summary>
        /// <param name="aPIKey">Required parameter: Example: .</param>
        /// <param name="body">Optional parameter: Purchase object.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task CreateTestDataForVerifiedPurchasesAsync(
                string aPIKey,
                Models.CreatePurchaseRequest body = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/consumer/activity/v1/simulate/purchase");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "API-Key", aPIKey },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(body);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            if (response.StatusCode == 400)
            {
                throw new ErrorResponseException("Bad Request", context);
            }

            if (response.StatusCode == 401)
            {
                throw new ProblemDetailsException("Unauthorized", context);
            }

            if (response.StatusCode == 403)
            {
                throw new ProblemDetailsException("Forbidden", context);
            }

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }
    }
}