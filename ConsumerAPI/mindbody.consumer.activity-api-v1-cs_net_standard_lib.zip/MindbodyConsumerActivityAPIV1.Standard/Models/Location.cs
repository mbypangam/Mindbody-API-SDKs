// <copyright file="Location.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyConsumerActivityAPIV1.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MindbodyConsumerActivityAPIV1.Standard;
    using MindbodyConsumerActivityAPIV1.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Location.
    /// </summary>
    public class Location
    {
        private string id;
        private string name;
        private string addressLine1;
        private string addressLine2;
        private string city;
        private string stateProvCode;
        private string postalCode;
        private string countryCode;
        private string bookingUrl;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "id", false },
            { "name", false },
            { "addressLine1", false },
            { "addressLine2", false },
            { "city", false },
            { "stateProvCode", false },
            { "postalCode", false },
            { "countryCode", false },
            { "bookingUrl", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="Location"/> class.
        /// </summary>
        public Location()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Location"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="name">name.</param>
        /// <param name="addressLine1">addressLine1.</param>
        /// <param name="addressLine2">addressLine2.</param>
        /// <param name="city">city.</param>
        /// <param name="stateProvCode">stateProvCode.</param>
        /// <param name="postalCode">postalCode.</param>
        /// <param name="countryCode">countryCode.</param>
        /// <param name="bookingUrl">bookingUrl.</param>
        public Location(
            string id = null,
            string name = null,
            string addressLine1 = null,
            string addressLine2 = null,
            string city = null,
            string stateProvCode = null,
            string postalCode = null,
            string countryCode = null,
            string bookingUrl = null)
        {
            if (id != null)
            {
                this.Id = id;
            }

            if (name != null)
            {
                this.Name = name;
            }

            if (addressLine1 != null)
            {
                this.AddressLine1 = addressLine1;
            }

            if (addressLine2 != null)
            {
                this.AddressLine2 = addressLine2;
            }

            if (city != null)
            {
                this.City = city;
            }

            if (stateProvCode != null)
            {
                this.StateProvCode = stateProvCode;
            }

            if (postalCode != null)
            {
                this.PostalCode = postalCode;
            }

            if (countryCode != null)
            {
                this.CountryCode = countryCode;
            }

            if (bookingUrl != null)
            {
                this.BookingUrl = bookingUrl;
            }

        }

        /// <summary>
        /// The id of the location of business.
        /// </summary>
        [JsonProperty("id")]
        public string Id
        {
            get
            {
                return this.id;
            }

            set
            {
                this.shouldSerialize["id"] = true;
                this.id = value;
            }
        }

        /// <summary>
        /// The name of the location of business.
        /// </summary>
        [JsonProperty("name")]
        public string Name
        {
            get
            {
                return this.name;
            }

            set
            {
                this.shouldSerialize["name"] = true;
                this.name = value;
            }
        }

        /// <summary>
        /// The first line of the business location’s street address.
        /// </summary>
        [JsonProperty("addressLine1")]
        public string AddressLine1
        {
            get
            {
                return this.addressLine1;
            }

            set
            {
                this.shouldSerialize["addressLine1"] = true;
                this.addressLine1 = value;
            }
        }

        /// <summary>
        /// A second address line for the business location’s street address, if needed.
        /// </summary>
        [JsonProperty("addressLine2")]
        public string AddressLine2
        {
            get
            {
                return this.addressLine2;
            }

            set
            {
                this.shouldSerialize["addressLine2"] = true;
                this.addressLine2 = value;
            }
        }

        /// <summary>
        /// The business location’s city.
        /// </summary>
        [JsonProperty("city")]
        public string City
        {
            get
            {
                return this.city;
            }

            set
            {
                this.shouldSerialize["city"] = true;
                this.city = value;
            }
        }

        /// <summary>
        /// The business location’s state or province code.
        /// </summary>
        [JsonProperty("stateProvCode")]
        public string StateProvCode
        {
            get
            {
                return this.stateProvCode;
            }

            set
            {
                this.shouldSerialize["stateProvCode"] = true;
                this.stateProvCode = value;
            }
        }

        /// <summary>
        /// The business location’s postal code.
        /// </summary>
        [JsonProperty("postalCode")]
        public string PostalCode
        {
            get
            {
                return this.postalCode;
            }

            set
            {
                this.shouldSerialize["postalCode"] = true;
                this.postalCode = value;
            }
        }

        /// <summary>
        /// The business location’s country code.
        /// </summary>
        [JsonProperty("countryCode")]
        public string CountryCode
        {
            get
            {
                return this.countryCode;
            }

            set
            {
                this.shouldSerialize["countryCode"] = true;
                this.countryCode = value;
            }
        }

        /// <summary>
        /// The booking url of the business.
        /// </summary>
        [JsonProperty("bookingUrl")]
        public string BookingUrl
        {
            get
            {
                return this.bookingUrl;
            }

            set
            {
                this.shouldSerialize["bookingUrl"] = true;
                this.bookingUrl = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Location : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetId()
        {
            this.shouldSerialize["id"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetName()
        {
            this.shouldSerialize["name"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetAddressLine1()
        {
            this.shouldSerialize["addressLine1"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetAddressLine2()
        {
            this.shouldSerialize["addressLine2"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetCity()
        {
            this.shouldSerialize["city"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetStateProvCode()
        {
            this.shouldSerialize["stateProvCode"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetPostalCode()
        {
            this.shouldSerialize["postalCode"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetCountryCode()
        {
            this.shouldSerialize["countryCode"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetBookingUrl()
        {
            this.shouldSerialize["bookingUrl"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeId()
        {
            return this.shouldSerialize["id"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeName()
        {
            return this.shouldSerialize["name"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeAddressLine1()
        {
            return this.shouldSerialize["addressLine1"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeAddressLine2()
        {
            return this.shouldSerialize["addressLine2"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeCity()
        {
            return this.shouldSerialize["city"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeStateProvCode()
        {
            return this.shouldSerialize["stateProvCode"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializePostalCode()
        {
            return this.shouldSerialize["postalCode"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeCountryCode()
        {
            return this.shouldSerialize["countryCode"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeBookingUrl()
        {
            return this.shouldSerialize["bookingUrl"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Location other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.AddressLine1 == null && other.AddressLine1 == null) || (this.AddressLine1?.Equals(other.AddressLine1) == true)) &&
                ((this.AddressLine2 == null && other.AddressLine2 == null) || (this.AddressLine2?.Equals(other.AddressLine2) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.StateProvCode == null && other.StateProvCode == null) || (this.StateProvCode?.Equals(other.StateProvCode) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.CountryCode == null && other.CountryCode == null) || (this.CountryCode?.Equals(other.CountryCode) == true)) &&
                ((this.BookingUrl == null && other.BookingUrl == null) || (this.BookingUrl?.Equals(other.BookingUrl) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id == string.Empty ? "" : this.Id)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.AddressLine1 = {(this.AddressLine1 == null ? "null" : this.AddressLine1 == string.Empty ? "" : this.AddressLine1)}");
            toStringOutput.Add($"this.AddressLine2 = {(this.AddressLine2 == null ? "null" : this.AddressLine2 == string.Empty ? "" : this.AddressLine2)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.StateProvCode = {(this.StateProvCode == null ? "null" : this.StateProvCode == string.Empty ? "" : this.StateProvCode)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
            toStringOutput.Add($"this.CountryCode = {(this.CountryCode == null ? "null" : this.CountryCode == string.Empty ? "" : this.CountryCode)}");
            toStringOutput.Add($"this.BookingUrl = {(this.BookingUrl == null ? "null" : this.BookingUrl == string.Empty ? "" : this.BookingUrl)}");
        }
    }
}