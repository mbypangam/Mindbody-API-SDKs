// <copyright file="VisitResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyConsumerActivityAPIV1.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MindbodyConsumerActivityAPIV1.Standard;
    using MindbodyConsumerActivityAPIV1.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// VisitResponse.
    /// </summary>
    public class VisitResponse
    {
        private List<Models.Visit> visits;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "visits", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="VisitResponse"/> class.
        /// </summary>
        public VisitResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="VisitResponse"/> class.
        /// </summary>
        /// <param name="visits">visits.</param>
        public VisitResponse(
            List<Models.Visit> visits = null)
        {
            if (visits != null)
            {
                this.Visits = visits;
            }

        }

        /// <summary>
        /// A list of all verified visits of a consumer for a given duration.
        /// </summary>
        [JsonProperty("visits")]
        public List<Models.Visit> Visits
        {
            get
            {
                return this.visits;
            }

            set
            {
                this.shouldSerialize["visits"] = true;
                this.visits = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"VisitResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetVisits()
        {
            this.shouldSerialize["visits"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeVisits()
        {
            return this.shouldSerialize["visits"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is VisitResponse other &&
                ((this.Visits == null && other.Visits == null) || (this.Visits?.Equals(other.Visits) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Visits = {(this.Visits == null ? "null" : $"[{string.Join(", ", this.Visits)} ]")}");
        }
    }
}