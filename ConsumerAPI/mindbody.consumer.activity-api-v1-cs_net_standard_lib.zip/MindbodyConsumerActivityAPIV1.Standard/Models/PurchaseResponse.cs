// <copyright file="PurchaseResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyConsumerActivityAPIV1.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MindbodyConsumerActivityAPIV1.Standard;
    using MindbodyConsumerActivityAPIV1.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PurchaseResponse.
    /// </summary>
    public class PurchaseResponse
    {
        private List<Models.Purchase> purchases;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "purchases", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="PurchaseResponse"/> class.
        /// </summary>
        public PurchaseResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PurchaseResponse"/> class.
        /// </summary>
        /// <param name="purchases">purchases.</param>
        public PurchaseResponse(
            List<Models.Purchase> purchases = null)
        {
            if (purchases != null)
            {
                this.Purchases = purchases;
            }

        }

        /// <summary>
        /// A list of all verified purchases of a consumer for a given duration.
        /// </summary>
        [JsonProperty("purchases")]
        public List<Models.Purchase> Purchases
        {
            get
            {
                return this.purchases;
            }

            set
            {
                this.shouldSerialize["purchases"] = true;
                this.purchases = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PurchaseResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetPurchases()
        {
            this.shouldSerialize["purchases"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializePurchases()
        {
            return this.shouldSerialize["purchases"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PurchaseResponse other &&
                ((this.Purchases == null && other.Purchases == null) || (this.Purchases?.Equals(other.Purchases) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Purchases = {(this.Purchases == null ? "null" : $"[{string.Join(", ", this.Purchases)} ]")}");
        }
    }
}