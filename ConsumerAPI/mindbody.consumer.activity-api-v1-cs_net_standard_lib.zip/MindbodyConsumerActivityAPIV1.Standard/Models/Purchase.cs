// <copyright file="Purchase.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyConsumerActivityAPIV1.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MindbodyConsumerActivityAPIV1.Standard;
    using MindbodyConsumerActivityAPIV1.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Purchase.
    /// </summary>
    public class Purchase
    {
        private string consumerId;
        private string productName;
        private string productCategory;
        private string paymentMethod;
        private double? amountPaid;
        private string productType;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "consumerId", false },
            { "productName", false },
            { "productCategory", false },
            { "paymentMethod", false },
            { "amountPaid", false },
            { "productType", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="Purchase"/> class.
        /// </summary>
        public Purchase()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Purchase"/> class.
        /// </summary>
        /// <param name="consumerId">consumerId.</param>
        /// <param name="productName">productName.</param>
        /// <param name="productCategory">productCategory.</param>
        /// <param name="paymentMethod">paymentMethod.</param>
        /// <param name="amountPaid">amountPaid.</param>
        /// <param name="purchaseDate">purchaseDate.</param>
        /// <param name="productType">productType.</param>
        /// <param name="quantity">quantity.</param>
        public Purchase(
            string consumerId = null,
            string productName = null,
            string productCategory = null,
            string paymentMethod = null,
            double? amountPaid = null,
            DateTime? purchaseDate = null,
            string productType = null,
            int? quantity = null)
        {
            if (consumerId != null)
            {
                this.ConsumerId = consumerId;
            }

            if (productName != null)
            {
                this.ProductName = productName;
            }

            if (productCategory != null)
            {
                this.ProductCategory = productCategory;
            }

            if (paymentMethod != null)
            {
                this.PaymentMethod = paymentMethod;
            }

            if (amountPaid != null)
            {
                this.AmountPaid = amountPaid;
            }

            this.PurchaseDate = purchaseDate;
            if (productType != null)
            {
                this.ProductType = productType;
            }

            this.Quantity = quantity;
        }

        /// <summary>
        /// The Id of the consumer.
        /// </summary>
        [JsonProperty("consumerId")]
        public string ConsumerId
        {
            get
            {
                return this.consumerId;
            }

            set
            {
                this.shouldSerialize["consumerId"] = true;
                this.consumerId = value;
            }
        }

        /// <summary>
        /// The product name of the purchase.
        /// </summary>
        [JsonProperty("productName")]
        public string ProductName
        {
            get
            {
                return this.productName;
            }

            set
            {
                this.shouldSerialize["productName"] = true;
                this.productName = value;
            }
        }

        /// <summary>
        /// The product category of the purchase.
        /// </summary>
        [JsonProperty("productCategory")]
        public string ProductCategory
        {
            get
            {
                return this.productCategory;
            }

            set
            {
                this.shouldSerialize["productCategory"] = true;
                this.productCategory = value;
            }
        }

        /// <summary>
        /// The payment method of the purchase.
        /// </summary>
        [JsonProperty("paymentMethod")]
        public string PaymentMethod
        {
            get
            {
                return this.paymentMethod;
            }

            set
            {
                this.shouldSerialize["paymentMethod"] = true;
                this.paymentMethod = value;
            }
        }

        /// <summary>
        /// The amount paid for the purchase.
        /// </summary>
        [JsonProperty("amountPaid")]
        public double? AmountPaid
        {
            get
            {
                return this.amountPaid;
            }

            set
            {
                this.shouldSerialize["amountPaid"] = true;
                this.amountPaid = value;
            }
        }

        /// <summary>
        /// The date of the purchase.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("purchaseDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? PurchaseDate { get; set; }

        /// <summary>
        /// The product type of the purchase.
        /// </summary>
        [JsonProperty("productType")]
        public string ProductType
        {
            get
            {
                return this.productType;
            }

            set
            {
                this.shouldSerialize["productType"] = true;
                this.productType = value;
            }
        }

        /// <summary>
        /// The quantity of the product purchased.
        /// </summary>
        [JsonProperty("quantity", NullValueHandling = NullValueHandling.Ignore)]
        public int? Quantity { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Purchase : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetConsumerId()
        {
            this.shouldSerialize["consumerId"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetProductName()
        {
            this.shouldSerialize["productName"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetProductCategory()
        {
            this.shouldSerialize["productCategory"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetPaymentMethod()
        {
            this.shouldSerialize["paymentMethod"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetAmountPaid()
        {
            this.shouldSerialize["amountPaid"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetProductType()
        {
            this.shouldSerialize["productType"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeConsumerId()
        {
            return this.shouldSerialize["consumerId"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeProductName()
        {
            return this.shouldSerialize["productName"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeProductCategory()
        {
            return this.shouldSerialize["productCategory"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializePaymentMethod()
        {
            return this.shouldSerialize["paymentMethod"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeAmountPaid()
        {
            return this.shouldSerialize["amountPaid"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeProductType()
        {
            return this.shouldSerialize["productType"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Purchase other &&
                ((this.ConsumerId == null && other.ConsumerId == null) || (this.ConsumerId?.Equals(other.ConsumerId) == true)) &&
                ((this.ProductName == null && other.ProductName == null) || (this.ProductName?.Equals(other.ProductName) == true)) &&
                ((this.ProductCategory == null && other.ProductCategory == null) || (this.ProductCategory?.Equals(other.ProductCategory) == true)) &&
                ((this.PaymentMethod == null && other.PaymentMethod == null) || (this.PaymentMethod?.Equals(other.PaymentMethod) == true)) &&
                ((this.AmountPaid == null && other.AmountPaid == null) || (this.AmountPaid?.Equals(other.AmountPaid) == true)) &&
                ((this.PurchaseDate == null && other.PurchaseDate == null) || (this.PurchaseDate?.Equals(other.PurchaseDate) == true)) &&
                ((this.ProductType == null && other.ProductType == null) || (this.ProductType?.Equals(other.ProductType) == true)) &&
                ((this.Quantity == null && other.Quantity == null) || (this.Quantity?.Equals(other.Quantity) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ConsumerId = {(this.ConsumerId == null ? "null" : this.ConsumerId == string.Empty ? "" : this.ConsumerId)}");
            toStringOutput.Add($"this.ProductName = {(this.ProductName == null ? "null" : this.ProductName == string.Empty ? "" : this.ProductName)}");
            toStringOutput.Add($"this.ProductCategory = {(this.ProductCategory == null ? "null" : this.ProductCategory == string.Empty ? "" : this.ProductCategory)}");
            toStringOutput.Add($"this.PaymentMethod = {(this.PaymentMethod == null ? "null" : this.PaymentMethod == string.Empty ? "" : this.PaymentMethod)}");
            toStringOutput.Add($"this.AmountPaid = {(this.AmountPaid == null ? "null" : this.AmountPaid.ToString())}");
            toStringOutput.Add($"this.PurchaseDate = {(this.PurchaseDate == null ? "null" : this.PurchaseDate.ToString())}");
            toStringOutput.Add($"this.ProductType = {(this.ProductType == null ? "null" : this.ProductType == string.Empty ? "" : this.ProductType)}");
            toStringOutput.Add($"this.Quantity = {(this.Quantity == null ? "null" : this.Quantity.ToString())}");
        }
    }
}