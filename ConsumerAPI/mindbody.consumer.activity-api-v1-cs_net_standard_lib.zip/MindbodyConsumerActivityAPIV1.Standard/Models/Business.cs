// <copyright file="Business.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyConsumerActivityAPIV1.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MindbodyConsumerActivityAPIV1.Standard;
    using MindbodyConsumerActivityAPIV1.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Business.
    /// </summary>
    public class Business
    {
        private string id;
        private string name;
        private string websiteUrl;
        private List<Models.Location> locations;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "id", false },
            { "name", false },
            { "websiteUrl", false },
            { "locations", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="Business"/> class.
        /// </summary>
        public Business()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Business"/> class.
        /// </summary>
        /// <param name="id">id.</param>
        /// <param name="name">name.</param>
        /// <param name="websiteUrl">websiteUrl.</param>
        /// <param name="locations">locations.</param>
        public Business(
            string id = null,
            string name = null,
            string websiteUrl = null,
            List<Models.Location> locations = null)
        {
            if (id != null)
            {
                this.Id = id;
            }

            if (name != null)
            {
                this.Name = name;
            }

            if (websiteUrl != null)
            {
                this.WebsiteUrl = websiteUrl;
            }

            if (locations != null)
            {
                this.Locations = locations;
            }

        }

        /// <summary>
        /// The id of the business.
        /// </summary>
        [JsonProperty("id")]
        public string Id
        {
            get
            {
                return this.id;
            }

            set
            {
                this.shouldSerialize["id"] = true;
                this.id = value;
            }
        }

        /// <summary>
        /// The name of the business.
        /// </summary>
        [JsonProperty("name")]
        public string Name
        {
            get
            {
                return this.name;
            }

            set
            {
                this.shouldSerialize["name"] = true;
                this.name = value;
            }
        }

        /// <summary>
        /// The website url of the business.
        /// </summary>
        [JsonProperty("websiteUrl")]
        public string WebsiteUrl
        {
            get
            {
                return this.websiteUrl;
            }

            set
            {
                this.shouldSerialize["websiteUrl"] = true;
                this.websiteUrl = value;
            }
        }

        /// <summary>
        /// The locations of the business.
        /// </summary>
        [JsonProperty("locations")]
        public List<Models.Location> Locations
        {
            get
            {
                return this.locations;
            }

            set
            {
                this.shouldSerialize["locations"] = true;
                this.locations = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Business : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetId()
        {
            this.shouldSerialize["id"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetName()
        {
            this.shouldSerialize["name"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetWebsiteUrl()
        {
            this.shouldSerialize["websiteUrl"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetLocations()
        {
            this.shouldSerialize["locations"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeId()
        {
            return this.shouldSerialize["id"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeName()
        {
            return this.shouldSerialize["name"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeWebsiteUrl()
        {
            return this.shouldSerialize["websiteUrl"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeLocations()
        {
            return this.shouldSerialize["locations"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Business other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.WebsiteUrl == null && other.WebsiteUrl == null) || (this.WebsiteUrl?.Equals(other.WebsiteUrl) == true)) &&
                ((this.Locations == null && other.Locations == null) || (this.Locations?.Equals(other.Locations) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id == string.Empty ? "" : this.Id)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.WebsiteUrl = {(this.WebsiteUrl == null ? "null" : this.WebsiteUrl == string.Empty ? "" : this.WebsiteUrl)}");
            toStringOutput.Add($"this.Locations = {(this.Locations == null ? "null" : $"[{string.Join(", ", this.Locations)} ]")}");
        }
    }
}