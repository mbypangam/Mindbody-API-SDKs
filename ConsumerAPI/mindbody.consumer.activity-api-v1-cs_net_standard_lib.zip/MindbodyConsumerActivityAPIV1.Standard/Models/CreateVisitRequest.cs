// <copyright file="CreateVisitRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyConsumerActivityAPIV1.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MindbodyConsumerActivityAPIV1.Standard;
    using MindbodyConsumerActivityAPIV1.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CreateVisitRequest.
    /// </summary>
    public class CreateVisitRequest
    {
        private string serviceName;
        private string serviceCategory;
        private string paymentMethod;
        private DateTime? bookingDate;
        private string businessName;
        private string locationName;
        private string addressLine1;
        private string addressLine2;
        private string city;
        private string stateCode;
        private string countryCode;
        private string postalCode;
        private Dictionary<string, bool> shouldSerialize = new Dictionary<string, bool>
        {
            { "serviceName", false },
            { "serviceCategory", false },
            { "paymentMethod", false },
            { "bookingDate", false },
            { "businessName", false },
            { "locationName", false },
            { "addressLine1", false },
            { "addressLine2", false },
            { "city", false },
            { "stateCode", false },
            { "countryCode", false },
            { "postalCode", false },
        };

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateVisitRequest"/> class.
        /// </summary>
        public CreateVisitRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateVisitRequest"/> class.
        /// </summary>
        /// <param name="serviceName">serviceName.</param>
        /// <param name="serviceCategory">serviceCategory.</param>
        /// <param name="paymentMethod">paymentMethod.</param>
        /// <param name="amountPaid">amountPaid.</param>
        /// <param name="visitDate">visitDate.</param>
        /// <param name="bookingDate">bookingDate.</param>
        /// <param name="businessName">businessName.</param>
        /// <param name="locationName">locationName.</param>
        /// <param name="addressLine1">addressLine1.</param>
        /// <param name="addressLine2">addressLine2.</param>
        /// <param name="city">city.</param>
        /// <param name="stateCode">stateCode.</param>
        /// <param name="countryCode">countryCode.</param>
        /// <param name="postalCode">postalCode.</param>
        public CreateVisitRequest(
            string serviceName = null,
            string serviceCategory = null,
            string paymentMethod = null,
            double? amountPaid = null,
            DateTime? visitDate = null,
            DateTime? bookingDate = null,
            string businessName = null,
            string locationName = null,
            string addressLine1 = null,
            string addressLine2 = null,
            string city = null,
            string stateCode = null,
            string countryCode = null,
            string postalCode = null)
        {
            if (serviceName != null)
            {
                this.ServiceName = serviceName;
            }

            if (serviceCategory != null)
            {
                this.ServiceCategory = serviceCategory;
            }

            if (paymentMethod != null)
            {
                this.PaymentMethod = paymentMethod;
            }

            this.AmountPaid = amountPaid;
            this.VisitDate = visitDate;
            if (bookingDate != null)
            {
                this.BookingDate = bookingDate;
            }

            if (businessName != null)
            {
                this.BusinessName = businessName;
            }

            if (locationName != null)
            {
                this.LocationName = locationName;
            }

            if (addressLine1 != null)
            {
                this.AddressLine1 = addressLine1;
            }

            if (addressLine2 != null)
            {
                this.AddressLine2 = addressLine2;
            }

            if (city != null)
            {
                this.City = city;
            }

            if (stateCode != null)
            {
                this.StateCode = stateCode;
            }

            if (countryCode != null)
            {
                this.CountryCode = countryCode;
            }

            if (postalCode != null)
            {
                this.PostalCode = postalCode;
            }

        }

        /// <summary>
        /// The service name of the visit
        /// </summary>
        [JsonProperty("serviceName")]
        public string ServiceName
        {
            get
            {
                return this.serviceName;
            }

            set
            {
                this.shouldSerialize["serviceName"] = true;
                this.serviceName = value;
            }
        }

        /// <summary>
        /// The service category of the visit
        /// </summary>
        [JsonProperty("serviceCategory")]
        public string ServiceCategory
        {
            get
            {
                return this.serviceCategory;
            }

            set
            {
                this.shouldSerialize["serviceCategory"] = true;
                this.serviceCategory = value;
            }
        }

        /// <summary>
        /// The payment method of the visit
        /// </summary>
        [JsonProperty("paymentMethod")]
        public string PaymentMethod
        {
            get
            {
                return this.paymentMethod;
            }

            set
            {
                this.shouldSerialize["paymentMethod"] = true;
                this.paymentMethod = value;
            }
        }

        /// <summary>
        /// The amount paid for the visit
        /// </summary>
        [JsonProperty("amountPaid", NullValueHandling = NullValueHandling.Ignore)]
        public double? AmountPaid { get; set; }

        /// <summary>
        /// The date of the visit
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("visitDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? VisitDate { get; set; }

        /// <summary>
        /// The booking date of the visit
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("bookingDate")]
        public DateTime? BookingDate
        {
            get
            {
                return this.bookingDate;
            }

            set
            {
                this.shouldSerialize["bookingDate"] = true;
                this.bookingDate = value;
            }
        }

        /// <summary>
        /// The business name of the site where this visit was made
        /// </summary>
        [JsonProperty("businessName")]
        public string BusinessName
        {
            get
            {
                return this.businessName;
            }

            set
            {
                this.shouldSerialize["businessName"] = true;
                this.businessName = value;
            }
        }

        /// <summary>
        /// The location name of the site where this visit was made
        /// </summary>
        [JsonProperty("locationName")]
        public string LocationName
        {
            get
            {
                return this.locationName;
            }

            set
            {
                this.shouldSerialize["locationName"] = true;
                this.locationName = value;
            }
        }

        /// <summary>
        /// The first line of the visit location’s street address
        /// </summary>
        [JsonProperty("addressLine1")]
        public string AddressLine1
        {
            get
            {
                return this.addressLine1;
            }

            set
            {
                this.shouldSerialize["addressLine1"] = true;
                this.addressLine1 = value;
            }
        }

        /// <summary>
        /// A second address line for the visit location’s street address, if needed
        /// </summary>
        [JsonProperty("addressLine2")]
        public string AddressLine2
        {
            get
            {
                return this.addressLine2;
            }

            set
            {
                this.shouldSerialize["addressLine2"] = true;
                this.addressLine2 = value;
            }
        }

        /// <summary>
        /// The visit location’s city
        /// </summary>
        [JsonProperty("city")]
        public string City
        {
            get
            {
                return this.city;
            }

            set
            {
                this.shouldSerialize["city"] = true;
                this.city = value;
            }
        }

        /// <summary>
        /// The visit location’s state or province code
        /// </summary>
        [JsonProperty("stateCode")]
        public string StateCode
        {
            get
            {
                return this.stateCode;
            }

            set
            {
                this.shouldSerialize["stateCode"] = true;
                this.stateCode = value;
            }
        }

        /// <summary>
        /// The visit location’s country code
        /// </summary>
        [JsonProperty("countryCode")]
        public string CountryCode
        {
            get
            {
                return this.countryCode;
            }

            set
            {
                this.shouldSerialize["countryCode"] = true;
                this.countryCode = value;
            }
        }

        /// <summary>
        /// The visit location’s postal code
        /// </summary>
        [JsonProperty("postalCode")]
        public string PostalCode
        {
            get
            {
                return this.postalCode;
            }

            set
            {
                this.shouldSerialize["postalCode"] = true;
                this.postalCode = value;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CreateVisitRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetServiceName()
        {
            this.shouldSerialize["serviceName"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetServiceCategory()
        {
            this.shouldSerialize["serviceCategory"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetPaymentMethod()
        {
            this.shouldSerialize["paymentMethod"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetBookingDate()
        {
            this.shouldSerialize["bookingDate"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetBusinessName()
        {
            this.shouldSerialize["businessName"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetLocationName()
        {
            this.shouldSerialize["locationName"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetAddressLine1()
        {
            this.shouldSerialize["addressLine1"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetAddressLine2()
        {
            this.shouldSerialize["addressLine2"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetCity()
        {
            this.shouldSerialize["city"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetStateCode()
        {
            this.shouldSerialize["stateCode"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetCountryCode()
        {
            this.shouldSerialize["countryCode"] = false;
        }

        /// <summary>
        /// Marks the field to not be serailized.
        /// </summary>
        public void UnsetPostalCode()
        {
            this.shouldSerialize["postalCode"] = false;
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeServiceName()
        {
            return this.shouldSerialize["serviceName"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeServiceCategory()
        {
            return this.shouldSerialize["serviceCategory"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializePaymentMethod()
        {
            return this.shouldSerialize["paymentMethod"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeBookingDate()
        {
            return this.shouldSerialize["bookingDate"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeBusinessName()
        {
            return this.shouldSerialize["businessName"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeLocationName()
        {
            return this.shouldSerialize["locationName"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeAddressLine1()
        {
            return this.shouldSerialize["addressLine1"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeAddressLine2()
        {
            return this.shouldSerialize["addressLine2"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeCity()
        {
            return this.shouldSerialize["city"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeStateCode()
        {
            return this.shouldSerialize["stateCode"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializeCountryCode()
        {
            return this.shouldSerialize["countryCode"];
        }

        /// <summary>
        /// Checks if the field should be serialized or not.
        /// </summary>
        /// <returns>A boolean weather the field should be serialized or not.</returns>
        public bool ShouldSerializePostalCode()
        {
            return this.shouldSerialize["postalCode"];
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CreateVisitRequest other &&
                ((this.ServiceName == null && other.ServiceName == null) || (this.ServiceName?.Equals(other.ServiceName) == true)) &&
                ((this.ServiceCategory == null && other.ServiceCategory == null) || (this.ServiceCategory?.Equals(other.ServiceCategory) == true)) &&
                ((this.PaymentMethod == null && other.PaymentMethod == null) || (this.PaymentMethod?.Equals(other.PaymentMethod) == true)) &&
                ((this.AmountPaid == null && other.AmountPaid == null) || (this.AmountPaid?.Equals(other.AmountPaid) == true)) &&
                ((this.VisitDate == null && other.VisitDate == null) || (this.VisitDate?.Equals(other.VisitDate) == true)) &&
                ((this.BookingDate == null && other.BookingDate == null) || (this.BookingDate?.Equals(other.BookingDate) == true)) &&
                ((this.BusinessName == null && other.BusinessName == null) || (this.BusinessName?.Equals(other.BusinessName) == true)) &&
                ((this.LocationName == null && other.LocationName == null) || (this.LocationName?.Equals(other.LocationName) == true)) &&
                ((this.AddressLine1 == null && other.AddressLine1 == null) || (this.AddressLine1?.Equals(other.AddressLine1) == true)) &&
                ((this.AddressLine2 == null && other.AddressLine2 == null) || (this.AddressLine2?.Equals(other.AddressLine2) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.StateCode == null && other.StateCode == null) || (this.StateCode?.Equals(other.StateCode) == true)) &&
                ((this.CountryCode == null && other.CountryCode == null) || (this.CountryCode?.Equals(other.CountryCode) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ServiceName = {(this.ServiceName == null ? "null" : this.ServiceName == string.Empty ? "" : this.ServiceName)}");
            toStringOutput.Add($"this.ServiceCategory = {(this.ServiceCategory == null ? "null" : this.ServiceCategory == string.Empty ? "" : this.ServiceCategory)}");
            toStringOutput.Add($"this.PaymentMethod = {(this.PaymentMethod == null ? "null" : this.PaymentMethod == string.Empty ? "" : this.PaymentMethod)}");
            toStringOutput.Add($"this.AmountPaid = {(this.AmountPaid == null ? "null" : this.AmountPaid.ToString())}");
            toStringOutput.Add($"this.VisitDate = {(this.VisitDate == null ? "null" : this.VisitDate.ToString())}");
            toStringOutput.Add($"this.BookingDate = {(this.BookingDate == null ? "null" : this.BookingDate.ToString())}");
            toStringOutput.Add($"this.BusinessName = {(this.BusinessName == null ? "null" : this.BusinessName == string.Empty ? "" : this.BusinessName)}");
            toStringOutput.Add($"this.LocationName = {(this.LocationName == null ? "null" : this.LocationName == string.Empty ? "" : this.LocationName)}");
            toStringOutput.Add($"this.AddressLine1 = {(this.AddressLine1 == null ? "null" : this.AddressLine1 == string.Empty ? "" : this.AddressLine1)}");
            toStringOutput.Add($"this.AddressLine2 = {(this.AddressLine2 == null ? "null" : this.AddressLine2 == string.Empty ? "" : this.AddressLine2)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.StateCode = {(this.StateCode == null ? "null" : this.StateCode == string.Empty ? "" : this.StateCode)}");
            toStringOutput.Add($"this.CountryCode = {(this.CountryCode == null ? "null" : this.CountryCode == string.Empty ? "" : this.CountryCode)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
        }
    }
}