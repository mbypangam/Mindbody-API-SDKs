
# Location

## Structure

`Location`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | The id of the location of business. |
| `Name` | `string` | Optional | The name of the location of business. |
| `AddressLine1` | `string` | Optional | The first line of the business location’s street address. |
| `AddressLine2` | `string` | Optional | A second address line for the business location’s street address, if needed. |
| `City` | `string` | Optional | The business location’s city. |
| `StateProvCode` | `string` | Optional | The business location’s state or province code. |
| `PostalCode` | `string` | Optional | The business location’s postal code. |
| `CountryCode` | `string` | Optional | The business location’s country code. |
| `BookingUrl` | `string` | Optional | The booking url of the business. |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "addressLine1": null,
  "addressLine2": null,
  "city": null,
  "stateProvCode": null,
  "postalCode": null,
  "countryCode": null,
  "bookingUrl": null
}
```

