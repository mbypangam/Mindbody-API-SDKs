
# Visit Response

Visits response properties

## Structure

`VisitResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Visits` | [`List<Models.Visit>`](../../doc/models/visit.md) | Optional | A list of all verified visits of a consumer for a given duration. |

## Example (as JSON)

```json
{
  "visits": null
}
```

