
# Business Response

Business response properties

## Structure

`BusinessResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PageCount` | `int?` | Optional | The total number of pages |
| `Businesses` | [`List<Models.Business>`](../../doc/models/business.md) | Optional | A list of business data. |

## Example (as JSON)

```json
{
  "pageCount": null,
  "businesses": null
}
```

