
# Visit

## Structure

`Visit`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ConsumerId` | `string` | Optional | The Id of the consumer. |
| `ServiceName` | `string` | Optional | The service name of the visit. |
| `ServiceCategory` | `string` | Optional | The service category of the visit. |
| `PaymentMethod` | `string` | Optional | The payment method of the visit. |
| `AmountPaid` | `double?` | Optional | The amount paid for the visit. |
| `VisitDate` | `DateTime?` | Optional | The date of the visit. |
| `BookingDate` | `DateTime?` | Optional | The booking date of the visit. |
| `BusinessName` | `string` | Optional | The business name of the site where this visit was made. |
| `LocationName` | `string` | Optional | The location name of the site where this visit was made. |
| `AddressLine1` | `string` | Optional | The first line of the visit location’s street address. |
| `AddressLine2` | `string` | Optional | A second address line for the visit location’s street address, if needed. |
| `City` | `string` | Optional | The visit location’s city. |
| `StateCode` | `string` | Optional | The visit location’s state or province code. |
| `CountryCode` | `string` | Optional | The visit location’s country code. |
| `PostalCode` | `string` | Optional | The visit location’s postal code. |

## Example (as JSON)

```json
{
  "consumerId": null,
  "serviceName": null,
  "serviceCategory": null,
  "paymentMethod": null,
  "amountPaid": null,
  "visitDate": null,
  "bookingDate": null,
  "businessName": null,
  "locationName": null,
  "addressLine1": null,
  "addressLine2": null,
  "city": null,
  "stateCode": null,
  "countryCode": null,
  "postalCode": null
}
```

