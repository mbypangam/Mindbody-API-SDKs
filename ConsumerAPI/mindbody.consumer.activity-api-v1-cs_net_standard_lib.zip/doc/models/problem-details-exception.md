
# Problem Details Exception

## Structure

`ProblemDetailsException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `string` | Optional | - |
| `Title` | `string` | Optional | - |
| `Status` | `int?` | Optional | - |
| `Detail` | `string` | Optional | - |
| `Instance` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "type": null,
  "title": null,
  "status": null,
  "detail": null,
  "instance": null
}
```

