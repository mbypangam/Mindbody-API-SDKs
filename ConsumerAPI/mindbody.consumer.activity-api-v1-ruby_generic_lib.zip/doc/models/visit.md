
# Visit

## Structure

`Visit`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consumer_id` | `String` | Optional | The Id of the consumer. |
| `service_name` | `String` | Optional | The service name of the visit. |
| `service_category` | `String` | Optional | The service category of the visit. |
| `payment_method` | `String` | Optional | The payment method of the visit. |
| `amount_paid` | `Float` | Optional | The amount paid for the visit. |
| `visit_date` | `DateTime` | Optional | The date of the visit. |
| `booking_date` | `DateTime` | Optional | The booking date of the visit. |
| `business_name` | `String` | Optional | The business name of the site where this visit was made. |
| `location_name` | `String` | Optional | The location name of the site where this visit was made. |
| `address_line_1` | `String` | Optional | The first line of the visit location’s street address. |
| `address_line_2` | `String` | Optional | A second address line for the visit location’s street address, if needed. |
| `city` | `String` | Optional | The visit location’s city. |
| `state_code` | `String` | Optional | The visit location’s state or province code. |
| `country_code` | `String` | Optional | The visit location’s country code. |
| `postal_code` | `String` | Optional | The visit location’s postal code. |

## Example (as JSON)

```json
{
  "consumerId": null,
  "serviceName": null,
  "serviceCategory": null,
  "paymentMethod": null,
  "amountPaid": null,
  "visitDate": null,
  "bookingDate": null,
  "businessName": null,
  "locationName": null,
  "addressLine1": null,
  "addressLine2": null,
  "city": null,
  "stateCode": null,
  "countryCode": null,
  "postalCode": null
}
```

