
# Location

## Structure

`Location`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | The id of the location of business. | getId(): ?string | setId(?string id): void |
| `name` | `?string` | Optional | The name of the location of business. | getName(): ?string | setName(?string name): void |
| `addressLine1` | `?string` | Optional | The first line of the business location’s street address. | getAddressLine1(): ?string | setAddressLine1(?string addressLine1): void |
| `addressLine2` | `?string` | Optional | A second address line for the business location’s street address, if needed. | getAddressLine2(): ?string | setAddressLine2(?string addressLine2): void |
| `city` | `?string` | Optional | The business location’s city. | getCity(): ?string | setCity(?string city): void |
| `stateProvCode` | `?string` | Optional | The business location’s state or province code. | getStateProvCode(): ?string | setStateProvCode(?string stateProvCode): void |
| `postalCode` | `?string` | Optional | The business location’s postal code. | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `countryCode` | `?string` | Optional | The business location’s country code. | getCountryCode(): ?string | setCountryCode(?string countryCode): void |
| `bookingUrl` | `?string` | Optional | The booking url of the business. | getBookingUrl(): ?string | setBookingUrl(?string bookingUrl): void |

## Example (as JSON)

```json
{
  "id": null,
  "name": null,
  "addressLine1": null,
  "addressLine2": null,
  "city": null,
  "stateProvCode": null,
  "postalCode": null,
  "countryCode": null,
  "bookingUrl": null
}
```

