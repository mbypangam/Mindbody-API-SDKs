
# Purchase Response

Purchase Response Properties

## Structure

`PurchaseResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `purchases` | [`?(Purchase[])`](../../doc/models/purchase.md) | Optional | A list of all verified purchases of a consumer for a given duration. | getPurchases(): ?array | setPurchases(?array purchases): void |

## Example (as JSON)

```json
{
  "purchases": null
}
```

