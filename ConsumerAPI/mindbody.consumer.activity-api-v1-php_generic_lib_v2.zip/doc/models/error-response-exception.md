
# Error Response Exception

Error response

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `errors` | [`?(Error[])`](../../doc/models/error.md) | Optional | Collection of errors describing why the request was not processed. | getErrors(): ?array | setErrors(?array errors): void |

## Example (as JSON)

```json
{}
```

