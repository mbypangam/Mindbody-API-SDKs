
# Purchase

## Structure

`Purchase`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `consumerId` | `?string` | Optional | The Id of the consumer. | getConsumerId(): ?string | setConsumerId(?string consumerId): void |
| `productName` | `?string` | Optional | The product name of the purchase. | getProductName(): ?string | setProductName(?string productName): void |
| `productCategory` | `?string` | Optional | The product category of the purchase. | getProductCategory(): ?string | setProductCategory(?string productCategory): void |
| `paymentMethod` | `?string` | Optional | The payment method of the purchase. | getPaymentMethod(): ?string | setPaymentMethod(?string paymentMethod): void |
| `amountPaid` | `?float` | Optional | The amount paid for the purchase. | getAmountPaid(): ?float | setAmountPaid(?float amountPaid): void |
| `purchaseDate` | `?\DateTime` | Optional | The date of the purchase. | getPurchaseDate(): ?\DateTime | setPurchaseDate(?\DateTime purchaseDate): void |
| `productType` | `?string` | Optional | The product type of the purchase. | getProductType(): ?string | setProductType(?string productType): void |
| `quantity` | `?int` | Optional | The quantity of the product purchased. | getQuantity(): ?int | setQuantity(?int quantity): void |

## Example (as JSON)

```json
{
  "consumerId": null,
  "productName": null,
  "productCategory": null,
  "paymentMethod": null,
  "amountPaid": null,
  "purchaseDate": null,
  "productType": null,
  "quantity": null
}
```

