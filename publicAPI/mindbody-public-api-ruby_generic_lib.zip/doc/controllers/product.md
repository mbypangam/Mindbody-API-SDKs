# Product

```csharp
ProductController productController = client.ProductController;
```

## Class Name

`ProductController`


# Product Update Products

Update retail products available for purchase at a site.

```csharp
ProductUpdateProductsAsync(
    string siteId,
    List<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest> updateProductsRequests,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateProductsRequests` | [`List<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-product-request.md) | Body, Required | - |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-products-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
var updateProductsRequests = new List<MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest>();

var updateProductsRequests0 = new MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest();
updateProductsRequests.Add(updateProductsRequests0);

var updateProductsRequests1 = new MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest();
updateProductsRequests.Add(updateProductsRequests1);

string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse result = await productController.ProductUpdateProductsAsync(siteId, updateProductsRequests, version, null);
}
catch (ApiException e){};
```

