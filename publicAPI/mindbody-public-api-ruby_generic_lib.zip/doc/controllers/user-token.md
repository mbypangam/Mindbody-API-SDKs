# User Token

```csharp
UserTokenController userTokenController = client.UserTokenController;
```

## Class Name

`UserTokenController`

## Methods

* [User Token Issue](../../doc/controllers/user-token.md#user-token-issue)
* [User Token Revoke](../../doc/controllers/user-token.md#user-token-revoke)


# User Token Issue

Get a staff user token.

```csharp
UserTokenIssueAsync(
    Models.MindbodyPublicApiDtoModelsV6UserTokenControllerIssueRequest request,
    string siteId,
    string version)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6UserTokenControllerIssueRequest`](../../doc/models/mindbody-public-api-dto-models-v6-user-token-controller-issue-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6UserTokenControllerIssueResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-user-token-controller-issue-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6UserTokenControllerIssueRequest();
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6UserTokenControllerIssueResponse result = await userTokenController.UserTokenIssueAsync(request, siteId, version);
}
catch (ApiException e){};
```


# User Token Revoke

Revokes the user token in the Authorization header.

```csharp
UserTokenRevokeAsync(
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    object result = await userTokenController.UserTokenRevokeAsync(siteId, version, null);
}
catch (ApiException e){};
```

