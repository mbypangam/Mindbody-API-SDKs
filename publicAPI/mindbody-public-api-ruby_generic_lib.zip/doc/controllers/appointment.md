# Appointment

```csharp
AppointmentController appointmentController = client.AppointmentController;
```

## Class Name

`AppointmentController`

## Methods

* [Appointment Add Appointment](../../doc/controllers/appointment.md#appointment-add-appointment)
* [Appointment Update Appointment](../../doc/controllers/appointment.md#appointment-update-appointment)
* [Appointment Get Available Dates](../../doc/controllers/appointment.md#appointment-get-available-dates)
* [Appointment Get Bookable Items](../../doc/controllers/appointment.md#appointment-get-bookable-items)
* [Appointment Get Active Session Times](../../doc/controllers/appointment.md#appointment-get-active-session-times)
* [Appointment Get Schedule Items](../../doc/controllers/appointment.md#appointment-get-schedule-items)
* [Appointment Get Appointment Options](../../doc/controllers/appointment.md#appointment-get-appointment-options)
* [Appointment Get Staff Appointments](../../doc/controllers/appointment.md#appointment-get-staff-appointments)
* [Appointment Get Add Ons](../../doc/controllers/appointment.md#appointment-get-add-ons)
* [Appointment Add Appointment Add On](../../doc/controllers/appointment.md#appointment-add-appointment-add-on)
* [Appointment Delete Appointment Add On](../../doc/controllers/appointment.md#appointment-delete-appointment-add-on)
* [Appointment Update Availability](../../doc/controllers/appointment.md#appointment-update-availability)
* [Appointment Add Availabilities](../../doc/controllers/appointment.md#appointment-add-availabilities)
* [Appointment Delete Availability](../../doc/controllers/appointment.md#appointment-delete-availability)


# Appointment Add Appointment

To book an appointment, you must use a location ID, staff ID, client ID, session type ID, and the `StartDateTime` of the appointment. You can get most of this information using `GET BookableItems`.

```csharp
AppointmentAddAppointmentAsync(
    Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentRequest();
request.ClientId = "ClientId0";
request.LocationId = 238;
request.SessionTypeId = 82;
request.StaffId = 188L;
request.StartDateTime = DateTime.Parse("2016-03-13T12:52:32.123Z");
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse result = await appointmentController.AppointmentAddAppointmentAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Appointment Update Appointment

To update the information for a specific appointment, you must have a staff user token with the proper permissions. Note that you can only update the appointment’s `StartDateTime`, `EndDateTime`, `StaffId`, `Notes`, and `SessionTypeId`.

```csharp
AppointmentUpdateAppointmentAsync(
    Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-appointment-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-appointment-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest();
request.AppointmentId = 246L;
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse result = await appointmentController.AppointmentUpdateAppointmentAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Appointment Get Available Dates

Returns a list of available dates for the given session types.

```csharp
AppointmentGetAvailableDatesAsync(
    int requestSessionTypeId,
    string siteId,
    string version,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLocationId = null,
    long? requestStaffId = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestSessionTypeId` | `int` | Query, Required | required requested session type ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestLocationId` | `int?` | Query, Optional | optional requested location ID. |
| `requestStaffId` | `long?` | Query, Optional | optional requested staff ID. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range.<br><br />Default: **today’s date** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-available-dates-response.md)

## Example Usage

```csharp
int requestSessionTypeId = 100;
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse result = await appointmentController.AppointmentGetAvailableDatesAsync(requestSessionTypeId, siteId, version, null, null, null, null, null);
}
catch (ApiException e){};
```


# Appointment Get Bookable Items

Returns a list of availabilities with the information needed to book appointments. Availabilities include information such as the location and its amenities, staff members, programs, and session types.

```csharp
AppointmentGetBookableItemsAsync(
    List<int> requestSessionTypeIds,
    string siteId,
    string version,
    string authorization = null,
    long? requestAppointmentId = null,
    DateTime? requestEndDate = null,
    bool? requestIgnoreDefaultSessionLength = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestSessionTypeIds` | `List<int>` | Query, Required | A list of the requested session type IDs. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentId` | `long?` | Query, Optional | If provided, filters out the appointment with this ID. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestIgnoreDefaultSessionLength` | `bool?` | Query, Optional | When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br /><br>When `false`, only availabilities that have the default session length return. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | A list of the requested location IDs. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `List<long>` | Query, Optional | A list of the requested staff IDs. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range.<br><br />Default: **today’s date** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-bookable-items-response.md)

## Example Usage

```csharp
var requestSessionTypeIds = new List<int>();
requestSessionTypeIds.Add(228);
requestSessionTypeIds.Add(229);
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse result = await appointmentController.AppointmentGetBookableItemsAsync(requestSessionTypeIds, siteId, version, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Appointment Get Active Session Times

Returns a list of the times that can be booked for a given program schedule type. `ActiveSessionTimes` represent the scheduling increments that can be booked during the active business hours for services.

```csharp
AppointmentGetActiveSessionTimesAsync(
    string siteId,
    string version,
    string authorization = null,
    DateTime? requestEndTime = null,
    int? requestLimit = null,
    int? requestOffset = null,
    Models.RequestScheduleTypeEnum? requestScheduleType = null,
    List<int> requestSessionTypeIds = null,
    DateTime? requestStartTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndTime` | `DateTime?` | Query, Optional | Filters results to times that end on or before this time on the current date. Any date provided is ignored..<br><br />Default: **23:59:59** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestScheduleType` | [`Models.RequestScheduleTypeEnum?`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided. |
| `requestSessionTypeIds` | `List<int>` | Query, Optional | Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided. |
| `requestStartTime` | `DateTime?` | Query, Optional | Filters results to times that start on or after this time on the current date. Any date provided is ignored.<br><br />Default: **00:00:00** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-active-session-times-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse result = await appointmentController.AppointmentGetActiveSessionTimesAsync(siteId, version, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Appointment Get Schedule Items

Returns a list of schedule items, including appointments, availabilities, and unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.

```csharp
AppointmentGetScheduleItemsAsync(
    string siteId,
    string version,
    string authorization = null,
    DateTime? requestEndDate = null,
    bool? requestIgnorePrepFinishTimes = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **today’s date** |
| `requestIgnorePrepFinishTimes` | `bool?` | Query, Optional | When `true`, appointment preparation and finish unavailabilities are not returned.<br><br />Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | A list of requested location IDs. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `List<long>` | Query, Optional | A list of requested staff IDs. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range.<br><br />Default: **today’s date** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-schedule-items-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse result = await appointmentController.AppointmentGetScheduleItemsAsync(siteId, version, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Appointment Get Appointment Options

This endpoint has no query parameters.

```csharp
AppointmentGetAppointmentOptionsAsync(
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-appointment-options-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse result = await appointmentController.AppointmentGetAppointmentOptionsAsync(siteId, version, null);
}
catch (ApiException e){};
```


# Appointment Get Staff Appointments

Returns a list of appointments by staff member.

```csharp
AppointmentGetStaffAppointmentsAsync(
    string siteId,
    string version,
    string authorization = null,
    List<int> requestAppointmentIds = null,
    string requestClientId = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentIds` | `List<int>` | Query, Optional | A list of the requested appointment IDs. |
| `requestClientId` | `string` | Query, Optional | The client ID to be returned. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | A list of the requested location IDs. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `List<long>` | Query, Optional | List of staff IDs to be returned. Use a value of zero to return all staff appointments. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today’s date** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-staff-appointments-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse result = await appointmentController.AppointmentGetStaffAppointmentsAsync(siteId, version, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Appointment Get Add Ons

Returns a list of appointment addons optionally filtered by those that can be performed by the given staff member

```csharp
AppointmentGetAddOnsAsync(
    string siteId,
    string version,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null,
    int? requestStaffId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffId` | `int?` | Query, Optional | Optionally filter add ons that can be performed by this staff |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-add-ons-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse result = await appointmentController.AppointmentGetAddOnsAsync(siteId, version, null, null, null, null);
}
catch (ApiException e){};
```


# Appointment Add Appointment Add On

Creates an Add On to an existing appointment

```csharp
AppointmentAddAppointmentAddOnAsync(
    Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-add-on-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-add-on-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest();
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse result = await appointmentController.AppointmentAddAppointmentAddOnAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Appointment Delete Appointment Add On

Cross Regional Add On payments are not currently supported.  Returns 204 No Content on success.

```csharp
AppointmentDeleteAppointmentAddOnAsync(
    long id,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long` | Query, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task`

## Example Usage

```csharp
long id = 112L;
string siteId = "siteId8";
string version = "version4";

try
{
    await appointmentController.AppointmentDeleteAppointmentAddOnAsync(id, siteId, version, null);
}
catch (ApiException e){};
```


# Appointment Update Availability

Update availability/unavailability of the staff

```csharp
AppointmentUpdateAvailabilityAsync(
    string siteId,
    Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest updateAvailabilityRequest,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateAvailabilityRequest` | [`Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-availability-request.md) | Body, Required | - |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-availability-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
var updateAvailabilityRequest = new MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest();
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse result = await appointmentController.AppointmentUpdateAvailabilityAsync(siteId, updateAvailabilityRequest, version, null);
}
catch (ApiException e){};
```


# Appointment Add Availabilities

To Add Availabillity/Unavailabillity, you must use a location ID, staff IDs and the `StartDate/EndDate` of the Availabillity/Unavailabillity.

```csharp
AppointmentAddAvailabilitiesAsync(
    Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-availabilities-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-availabilities-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest();
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse result = await appointmentController.AppointmentAddAvailabilitiesAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Appointment Delete Availability

Delete availability/unavailability of the staff

```csharp
AppointmentDeleteAvailabilityAsync(
    string siteId,
    string version,
    string authorization = null,
    int? deleteAvailabilityRequestAvailabilityId = null,
    bool? deleteAvailabilityRequestTest = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `deleteAvailabilityRequestAvailabilityId` | `int?` | Query, Optional | Availability Id to be deleted |
| `deleteAvailabilityRequestTest` | `bool?` | Query, Optional | The test flag |

## Response Type

`Task`

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    await appointmentController.AppointmentDeleteAvailabilityAsync(siteId, version, null, null, null);
}
catch (ApiException e){};
```

