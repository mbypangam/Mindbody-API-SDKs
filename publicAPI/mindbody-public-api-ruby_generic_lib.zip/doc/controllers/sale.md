# Sale

```csharp
SaleController saleController = client.SaleController;
```

## Class Name

`SaleController`

## Methods

* [Sale Get Products](../../doc/controllers/sale.md#sale-get-products)
* [Sale Get Sales](../../doc/controllers/sale.md#sale-get-sales)
* [Sale Return Sale](../../doc/controllers/sale.md#sale-return-sale)
* [Sale Purchase Contract](../../doc/controllers/sale.md#sale-purchase-contract)
* [Sale Checkout Shopping Cart](../../doc/controllers/sale.md#sale-checkout-shopping-cart)
* [Sale Get Gift Cards](../../doc/controllers/sale.md#sale-get-gift-cards)
* [Sale Get Services](../../doc/controllers/sale.md#sale-get-services)
* [Sale Update Services](../../doc/controllers/sale.md#sale-update-services)
* [Sale Get Products Inventory](../../doc/controllers/sale.md#sale-get-products-inventory)
* [Sale Get Accepted Card Types](../../doc/controllers/sale.md#sale-get-accepted-card-types)
* [Sale Get Contracts](../../doc/controllers/sale.md#sale-get-contracts)
* [Sale Get Custom Payment Methods](../../doc/controllers/sale.md#sale-get-custom-payment-methods)
* [Sale Purchase Account Credit](../../doc/controllers/sale.md#sale-purchase-account-credit)
* [Sale Purchase Gift Card](../../doc/controllers/sale.md#sale-purchase-gift-card)
* [Sale Get Packages](../../doc/controllers/sale.md#sale-get-packages)
* [Sale Get Gift Card Balance](../../doc/controllers/sale.md#sale-get-gift-card-balance)
* [Sale Get Transactions](../../doc/controllers/sale.md#sale-get-transactions)
* [Sale Update Product Price](../../doc/controllers/sale.md#sale-update-product-price)
* [Sale Update Sale Date](../../doc/controllers/sale.md#sale-update-sale-date)
* [Sale Initialize Credit Card Entry](../../doc/controllers/sale.md#sale-initialize-credit-card-entry)


# Sale Get Products

Get retail products available for purchase at a site.

```csharp
SaleGetProductsAsync(
    string siteId,
    string version,
    string authorization = null,
    List<int> requestCategoryIds = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    List<string> requestProductIds = null,
    string requestSearchText = null,
    bool? requestSellOnline = null,
    List<int> requestSubCategoryIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestCategoryIds` | `List<int>` | Query, Optional | A list of category IDs to filter by. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | The location ID to use to determine the tax for the products that this request returns.<br /><br>Default: **online store** |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProductIds` | `List<string>` | Query, Optional | An ID filter for products. |
| `requestSearchText` | `string` | Query, Optional | A search filter, used for searching by term. |
| `requestSellOnline` | `bool?` | Query, Optional | When `true`, only products that can be sold online are returned.<br /><br>When `false`, all products are returned.<br /><br>Default: **false** |
| `requestSubCategoryIds` | `List<int>` | Query, Optional | A list of subcategory IDs to filter by. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-products-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse result = await saleController.SaleGetProductsAsync(siteId, version, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Get Sales

Get sales completed at a site.

```csharp
SaleGetSalesAsync(
    string siteId,
    string version,
    string authorization = null,
    DateTime? requestEndSaleDateTime = null,
    int? requestLimit = null,
    int? requestOffset = null,
    int? requestPaymentMethodId = null,
    long? requestSaleId = null,
    DateTime? requestStartSaleDateTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndSaleDateTime` | `DateTime?` | Query, Optional | Filters results to sales that happened before this date and time. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestPaymentMethodId` | `int?` | Query, Optional | Filters results to sales paid for by the given payment method ID. |
| `requestSaleId` | `long?` | Query, Optional | Filters results to the requested sale ID. |
| `requestStartSaleDateTime` | `DateTime?` | Query, Optional | Filters results to sales that happened after this date and time. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-sales-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse result = await saleController.SaleGetSalesAsync(siteId, version, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Return Sale

Retunn sale

```csharp
SaleReturnSaleAsync(
    Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleRequest returnSaleRequest,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `returnSaleRequest` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-return-sale-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-return-sale-response.md)

## Example Usage

```csharp
var returnSaleRequest = new MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleRequest();
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleResponse result = await saleController.SaleReturnSaleAsync(returnSaleRequest, siteId, version, null);
}
catch (ApiException e){};
```


# Sale Purchase Contract

Allows a client to sign up for a contract or autopay using the information returned from the `GET Contracts` endpoint. The client can pay with a new credit card or with a stored credit card. The client must exist at the site specified before this call is made.

This endpoint allows a developer to specify whether a client pays now or pays on the `StartDate`.If you are building a client-facing experience, you should talk with the business owner to understand the owner’s policies before you give clients a choice of the two payment types.

```csharp
SalePurchaseContractAsync(
    Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-contract-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractRequest();
request.ClientId = "ClientId0";
request.ContractId = 168;
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractResponse result = await saleController.SalePurchaseContractAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Sale Checkout Shopping Cart

This endpoint provides a wide range of functionality. For example, you can use it when a client purchases new pricing options, retail products, packages, and tips. You can also combine purchasing a new pricing option and many other functions, such as booking a client into a class, booking a new appointment for a client, enrolling a client into an enrollment or course, or reconciling an unpaid, already booked appointment or class. Use this call when a client purchases:

* a pricing option, after calling `GET Services` and choosing a specific pricing option’s ID
* a retail product, after calling `GET Products` and choosing a specific retail product’s ID
* a package, after calling `GET Packages` and choosing a specific package’s ID
* a tip to give to a staff member, after calling `GET Staff` and choosing a specific staff member ID, and the amount that the client wants to tip
  The documentation provides explanations of the request body and response, as well as the cart item metadata, payment item metadata, and purchased cart items.

```csharp
SaleCheckoutShoppingCartAsync(
    Models.MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutShoppingCartRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutShoppingCartRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-checkout-request-checkout-shopping-cart-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutShoppingCartRequest();
request.ClientId = "ClientId0";
request.Items = new List<MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutItemWrapper>();

var requestItems0 = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutItemWrapper();
request.Items.Add(requestItems0);

var requestItems1 = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutItemWrapper();
request.Items.Add(requestItems1);

var requestItems2 = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutItemWrapper();
request.Items.Add(requestItems2);

request.Payments = new List<MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo>();

var requestPayments0 = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo();
request.Payments.Add(requestPayments0);

var requestPayments1 = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo();
request.Payments.Add(requestPayments1);

var requestPayments2 = new MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo();
request.Payments.Add(requestPayments2);

string siteId = "siteId8";
string version = "version4";

try
{
    object result = await saleController.SaleCheckoutShoppingCartAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Sale Get Gift Cards

Get gift cards available for purchase at a site.

```csharp
SaleGetGiftCardsAsync(
    string siteId,
    string version,
    string authorization = null,
    List<int> requestIds = null,
    bool? requestIncludeCustomLayouts = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    bool? requestSoldOnline = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestIds` | `List<int>` | Query, Optional | Filters the results to the requested gift card IDs.<br /><br>Default: **all** gift cards. |
| `requestIncludeCustomLayouts` | `bool?` | Query, Optional | When `true`, includes custom gift card layouts.<br /><br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | When included, returns gift cards that are sold at the provided location ID. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSoldOnline` | `bool?` | Query, Optional | When `true`, only returns gift cards that are sold online.<br /><br>Default: **false** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-gift-card-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardResponse result = await saleController.SaleGetGiftCardsAsync(siteId, version, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Get Services

Get pricing options available for purchase at a site

```csharp
SaleGetServicesAsync(
    string siteId,
    string version,
    string authorization = null,
    int? requestClassId = null,
    int? requestClassScheduleId = null,
    bool? requestHideRelatedPrograms = null,
    bool? requestIncludeDiscontinued = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    List<int> requestProgramIds = null,
    bool? requestSellOnline = null,
    List<string> requestServiceIds = null,
    List<int> requestSessionTypeIds = null,
    long? requestStaffId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClassId` | `int?` | Query, Optional | Filters to the pricing options for the specified class ID. |
| `requestClassScheduleId` | `int?` | Query, Optional | Filters to the pricing options for the specified class schedule ID. |
| `requestHideRelatedPrograms` | `bool?` | Query, Optional | When `true`, indicates that pricing options of related programs are omitted from the response.<br /><br>Default: **false** |
| `requestIncludeDiscontinued` | `bool?` | Query, Optional | When `true`, indicates that the filtered pricing option list includes discontinued pricing options.<br /><br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | When specified, for each returned pricing option, `TaxRate` and `TaxIncluded` are calculated according to the specified location. Note that this does not filter results to only services provided at the given location, and for locations where Value-Added Tax (VAT) rules apply, the `TaxRate` is set to zero. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `List<int>` | Query, Optional | Filters to pricing options with the specified program IDs. |
| `requestSellOnline` | `bool?` | Query, Optional | When `true`, filters to the pricing options that can be sold online.<br /><br>Default: **false** |
| `requestServiceIds` | `List<string>` | Query, Optional | Filters to the pricing options with the specified IDs. In this context, service and pricing option are used interchangeably. |
| `requestSessionTypeIds` | `List<int>` | Query, Optional | Filters to the pricing options with the specified session types IDs. |
| `requestStaffId` | `long?` | Query, Optional | Sets `Price` and `OnlinePrice` to the particular pricing of a specific staff member, if allowed by the business. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-services-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse result = await saleController.SaleGetServicesAsync(siteId, version, null, null, null, null, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Update Services

Update unit price and online price of provided services.

```csharp
SaleUpdateServicesAsync(
    string siteId,
    List<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceRequest> updateServicesRequest,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateServicesRequest` | [`List<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceRequest>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-service-request.md) | Body, Required | - |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-service-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
var updateServicesRequest = new List<MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceRequest>();

var updateServicesRequest0 = new MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceRequest();
updateServicesRequest.Add(updateServicesRequest0);

string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse result = await saleController.SaleUpdateServicesAsync(siteId, updateServicesRequest, version, null);
}
catch (ApiException e){};
```


# Sale Get Products Inventory

Get retail products inventory data available at a site.

```csharp
SaleGetProductsInventoryAsync(
    string siteId,
    string version,
    string authorization = null,
    List<string> requestBarcodeIds = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<string> requestProductIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestBarcodeIds` | `List<string>` | Query, Optional | An IDs is barcodeId to filter for products inventory data. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | The location IDs to use to determine the inventory data of the product of specific location.<br /><br>Default: **online store** |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProductIds` | `List<string>` | Query, Optional | An IDs filter for products inventory data. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-products-inventory-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse result = await saleController.SaleGetProductsInventoryAsync(siteId, version, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Get Accepted Card Types

Gets a list of card types that the site accepts. You can also use `GET Sites` to return the Site object, which contains individual accepted card types for requested sites.

This endpoint has no query parameters.The response returns a list of strings. Possible values are:

* Visa
* MasterCard
* Discover
* AMEX

```csharp
SaleGetAcceptedCardTypesAsync(
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<List<string>>`

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    List<string> result = await saleController.SaleGetAcceptedCardTypesAsync(siteId, version, null);
}
catch (ApiException e){};
```


# Sale Get Contracts

Get contracts available for purchase at a site.

```csharp
SaleGetContractsAsync(
    int requestLocationId,
    string siteId,
    string version,
    string authorization = null,
    long? requestConsumerId = null,
    List<int> requestContractIds = null,
    int? requestLimit = null,
    int? requestOffset = null,
    bool? requestSoldOnline = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestLocationId` | `int` | Query, Required | The ID of the location that has the requested contracts and AutoPay options. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestConsumerId` | `long?` | Query, Optional | The ID of the client. |
| `requestContractIds` | `List<int>` | Query, Optional | When included, the response only contains details about the specified contract IDs. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSoldOnline` | `bool?` | Query, Optional | When `true`, the response only contains details about contracts and AutoPay options that can be sold online.<br /><br>When `false`, only contracts that are not intended to be sold online are returned.<br /><br>Default: **all contracts** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-contracts-response.md)

## Example Usage

```csharp
int requestLocationId = 90;
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse result = await saleController.SaleGetContractsAsync(requestLocationId, siteId, version, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Get Custom Payment Methods

Get payment methods that can be used to pay for sales at a site.

```csharp
SaleGetCustomPaymentMethodsAsync(
    string siteId,
    string version,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-custom-payment-methods-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse result = await saleController.SaleGetCustomPaymentMethodsAsync(siteId, version, null, null, null);
}
catch (ApiException e){};
```


# Sale Purchase Account Credit

Purchases account credit for a client

```csharp
SalePurchaseAccountCreditAsync(
    Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-account-credit-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-account-credit-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditRequest();
request.ClientId = "ClientId0";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditResponse result = await saleController.SalePurchaseAccountCreditAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Sale Purchase Gift Card

Allows a client to purchase a gift card from a business in a variety of designs. The card can be emailed to the recipient on a specific day, and a card title and a personal message can be added.

```csharp
SalePurchaseGiftCardAsync(
    Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-gift-card-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-gift-card-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardRequest();
request.LocationId = 238;
request.PurchaserClientId = "PurchaserClientId6";
request.GiftCardId = 222;
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardResponse result = await saleController.SalePurchaseGiftCardAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Sale Get Packages

A package is typically used to combine multiple services and/or products into a single offering. Staff members can check out multiple appointments while selling the package, and can discount the items included. For example, a spa might bundle a massage, a pedicure, a manicure, a facial, and a few selected beauty products into a package.

```csharp
SaleGetPackagesAsync(
    string siteId,
    string version,
    string authorization = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    List<int> requestPackageIds = null,
    bool? requestSellOnline = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | The location ID to use to determine the tax for the products that this request returns.<br /><br>Default: **online store** |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestPackageIds` | `List<int>` | Query, Optional | A list of the packages IDs to filter by. |
| `requestSellOnline` | `bool?` | Query, Optional | When `true`, only returns products that can be sold online.<br /><br>When `false`, all products are returned.<br /><br>Default: **false** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-packages-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse result = await saleController.SaleGetPackagesAsync(siteId, version, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Get Gift Card Balance

Get a gift card's remaining balance.

```csharp
SaleGetGiftCardBalanceAsync(
    string siteId,
    string version,
    string authorization = null,
    string barcodeId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `barcodeId` | `string` | Query, Optional | The barcode ID of the gift card for which you want the balance. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-gift-card-balance-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse result = await saleController.SaleGetGiftCardBalanceAsync(siteId, version, null, null);
}
catch (ApiException e){};
```


# Sale Get Transactions

Get transactions completed at a site.

```csharp
SaleGetTransactionsAsync(
    string siteId,
    string version,
    string authorization = null,
    long? requestClientId = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    long? requestSaleId = null,
    string requestStatus = null,
    DateTime? requestTransactionEndDateTime = null,
    int? requestTransactionId = null,
    DateTime? requestTransactionStartDateTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientId` | `long?` | Query, Optional | Filters results to the requested client ID. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | Filters results to the requested location ID. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSaleId` | `long?` | Query, Optional | Filters results to the requested sale ID. |
| `requestStatus` | `string` | Query, Optional | Filters results to the requested status. |
| `requestTransactionEndDateTime` | `DateTime?` | Query, Optional | Filters results to transactions that happened before this date and time. |
| `requestTransactionId` | `int?` | Query, Optional | Filters results to the requested transaction ID. |
| `requestTransactionStartDateTime` | `DateTime?` | Query, Optional | Filters results to transactions that happened after this date and time. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-transactions-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsResponse result = await saleController.SaleGetTransactionsAsync(siteId, version, null, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Sale Update Product Price

Update retail product's unit and online price.

```csharp
SaleUpdateProductPriceAsync(
    Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-product-price-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-product-price-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest();
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceResponse result = await saleController.SaleUpdateProductPriceAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Sale Update Sale Date

```csharp
SaleUpdateSaleDateAsync(
    Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-sale-date-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-sale-date-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateRequest();
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse result = await saleController.SaleUpdateSaleDateAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Sale Initialize Credit Card Entry

```csharp
SaleInitializeCreditCardEntryAsync(
    Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-initialize-credit-card-entry-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-initialize-credit-card-entry-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest();
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse result = await saleController.SaleInitializeCreditCardEntryAsync(request, siteId, version, null);
}
catch (ApiException e){};
```

