# Staff

```csharp
StaffController staffController = client.StaffController;
```

## Class Name

`StaffController`

## Methods

* [Staff Get Staff](../../doc/controllers/staff.md#staff-get-staff)
* [Staff Get Staff Permissions](../../doc/controllers/staff.md#staff-get-staff-permissions)
* [Staff Get Staff Image URL](../../doc/controllers/staff.md#staff-get-staff-image-url)
* [Staff Update Staff Permissions](../../doc/controllers/staff.md#staff-update-staff-permissions)
* [Staff Add Staff](../../doc/controllers/staff.md#staff-add-staff)
* [Staff Update Staff](../../doc/controllers/staff.md#staff-update-staff)
* [Staff Add Staff Availability](../../doc/controllers/staff.md#staff-add-staff-availability)
* [Staff Get Staff Session Types](../../doc/controllers/staff.md#staff-get-staff-session-types)
* [Staff Assign Staff Session Type](../../doc/controllers/staff.md#staff-assign-staff-session-type)
* [Staff Get Sales Reps](../../doc/controllers/staff.md#staff-get-sales-reps)


# Staff Get Staff

Get staff members at a site.

```csharp
StaffGetStaffAsync(
    string siteId,
    string version,
    string authorization = null,
    List<string> requestFilters = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    int? requestSessionTypeId = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDateTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestFilters` | `List<string>` | Query, Optional | Filters to apply to the search. Possible values are:<br><br>* StaffViewable<br>* AppointmentInstructor<br>* ClassInstructor<br>* Male<br>* Female |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSessionTypeId` | `int?` | Query, Optional | Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter. |
| `requestStaffIds` | `List<long>` | Query, Optional | A list of the requested staff IDs. |
| `requestStartDateTime` | `DateTime?` | Query, Optional | Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse result = await staffController.StaffGetStaffAsync(siteId, version, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Staff Get Staff Permissions

Get configured staff permissions for a staff member.

```csharp
StaffGetStaffPermissionsAsync(
    long requestStaffId,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestStaffId` | `long` | Query, Required | The ID of the staff member whose permissions you want to return. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-permissions-response.md)

## Example Usage

```csharp
long requestStaffId = 180L;
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse result = await staffController.StaffGetStaffPermissionsAsync(requestStaffId, siteId, version, null);
}
catch (ApiException e){};
```


# Staff Get Staff Image URL

Get image URLs for the given staff ID in the request.

```csharp
StaffGetStaffImageURLAsync(
    string siteId,
    string version,
    string authorization = null,
    long? requestStaffId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestStaffId` | `long?` | Query, Optional | A requested staff ID. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-image-url-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse result = await staffController.StaffGetStaffImageURLAsync(siteId, version, null, null);
}
catch (ApiException e){};
```


# Staff Update Staff Permissions

```csharp
StaffUpdateStaffPermissionsAsync(
    Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-permissions-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-permissions-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest();
request.StaffId = 188L;
request.PermissionGroupName = "PermissionGroupName8";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse result = await staffController.StaffUpdateStaffPermissionsAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Staff Add Staff

```csharp
StaffAddStaffAsync(
    Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-add-staff-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-add-staff-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest();
request.FirstName = "FirstName8";
request.LastName = "LastName8";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse result = await staffController.StaffAddStaffAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Staff Update Staff

```csharp
StaffUpdateStaffAsync(
    Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest();
request.ID = 142L;
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse result = await staffController.StaffUpdateStaffAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Staff Add Staff Availability

```csharp
StaffAddStaffAvailabilityAsync(
    Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-add-staff-availability-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task`

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest();
request.StaffId = 188L;
request.IsAvailability = false;
request.DaysOfWeek = new List<string>();
request.DaysOfWeek.Add("DaysOfWeek7");
request.StartTime = "StartTime4";
request.EndTime = "EndTime0";
request.StartDate = "StartDate0";
request.EndDate = "EndDate6";
string siteId = "siteId8";
string version = "version4";

try
{
    await staffController.StaffAddStaffAvailabilityAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Staff Get Staff Session Types

Get the session types used at a site for a staff member.

```csharp
StaffGetStaffSessionTypesAsync(
    long requestStaffId,
    string siteId,
    string version,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null,
    bool? requestOnlineOnly = null,
    List<int> requestProgramIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestStaffId` | `long` | Query, Required | Filters returned session types to only those the staff member performs.  Staff should be active. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `bool?` | Query, Optional | Only session types that can be booked online. |
| `requestProgramIds` | `List<int>` | Query, Optional | Filters results to session types that belong in program IDs. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-session-types-response.md)

## Example Usage

```csharp
long requestStaffId = 180L;
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse result = await staffController.StaffGetStaffSessionTypesAsync(requestStaffId, siteId, version, null, null, null, null, null);
}
catch (ApiException e){};
```


# Staff Assign Staff Session Type

```csharp
StaffAssignStaffSessionTypeAsync(
    Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-assign-staff-session-type-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-assign-staff-session-type-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest();
request.StaffId = 188L;
request.SessionTypeId = 82;
request.Active = false;
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse result = await staffController.StaffAssignStaffSessionTypeAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Staff Get Sales Reps

```csharp
StaffGetSalesRepsAsync(
    string siteId,
    string version,
    string authorization = null,
    bool? requestActiveOnly = null,
    int? requestLimit = null,
    int? requestOffset = null,
    List<int> requestSalesRepNumbers = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestActiveOnly` | `bool?` | Query, Optional | This is to filter out the active sales rep from the list |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSalesRepNumbers` | `List<int>` | Query, Optional | This is the list of rep numbers to be fetched |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-sales-reps-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse result = await staffController.StaffGetSalesRepsAsync(siteId, version, null, null, null, null, null);
}
catch (ApiException e){};
```

