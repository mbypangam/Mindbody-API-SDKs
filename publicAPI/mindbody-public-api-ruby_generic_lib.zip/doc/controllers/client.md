# Client

```csharp
ClientController clientController = client.ClientController;
```

## Class Name

`ClientController`

## Methods

* [Client Get Clients](../../doc/controllers/client.md#client-get-clients)
* [Client Get Client Duplicates](../../doc/controllers/client.md#client-get-client-duplicates)
* [Client Get Client Formula Notes](../../doc/controllers/client.md#client-get-client-formula-notes)
* [Client Delete Client Formula Note](../../doc/controllers/client.md#client-delete-client-formula-note)
* [Client Add Formula Note](../../doc/controllers/client.md#client-add-formula-note)
* [Client Upload Client Document](../../doc/controllers/client.md#client-upload-client-document)
* [Client Upload Client Photo](../../doc/controllers/client.md#client-upload-client-photo)
* [Client Get Client Contracts](../../doc/controllers/client.md#client-get-client-contracts)
* [Client Get Client Services](../../doc/controllers/client.md#client-get-client-services)
* [Client Get Client Visits](../../doc/controllers/client.md#client-get-client-visits)
* [Client Get Client Schedule](../../doc/controllers/client.md#client-get-client-schedule)
* [Client Get Active Client Memberships](../../doc/controllers/client.md#client-get-active-client-memberships)
* [Client Get Required Client Fields](../../doc/controllers/client.md#client-get-required-client-fields)
* [Client Get Client Referral Types](../../doc/controllers/client.md#client-get-client-referral-types)
* [Client Get Client Account Balances](../../doc/controllers/client.md#client-get-client-account-balances)
* [Client Get Client Purchases](../../doc/controllers/client.md#client-get-client-purchases)
* [Client Get Client Indexes](../../doc/controllers/client.md#client-get-client-indexes)
* [Client Get Custom Client Fields](../../doc/controllers/client.md#client-get-custom-client-fields)
* [Client Add Contact Log](../../doc/controllers/client.md#client-add-contact-log)
* [Client Update Contact Log](../../doc/controllers/client.md#client-update-contact-log)
* [Client Get Cross Regional Client Associations](../../doc/controllers/client.md#client-get-cross-regional-client-associations)
* [Client Add Client](../../doc/controllers/client.md#client-add-client)
* [Client Update Client](../../doc/controllers/client.md#client-update-client)
* [Client Update Client Visit](../../doc/controllers/client.md#client-update-client-visit)
* [Client Add Arrival](../../doc/controllers/client.md#client-add-arrival)
* [Client Send Password Reset Email](../../doc/controllers/client.md#client-send-password-reset-email)
* [Client Get Contact Logs](../../doc/controllers/client.md#client-get-contact-logs)
* [Client Update Client Service](../../doc/controllers/client.md#client-update-client-service)
* [Client Get Direct Debit Info](../../doc/controllers/client.md#client-get-direct-debit-info)
* [Client Delete Direct Debit Info](../../doc/controllers/client.md#client-delete-direct-debit-info)
* [Client Add Client Direct Debit Info](../../doc/controllers/client.md#client-add-client-direct-debit-info)
* [Client Get Client Rewards](../../doc/controllers/client.md#client-get-client-rewards)
* [Client Update Client Rewards](../../doc/controllers/client.md#client-update-client-rewards)
* [Client Get Client Complete Info](../../doc/controllers/client.md#client-get-client-complete-info)
* [Client Get Contact Log Types](../../doc/controllers/client.md#client-get-contact-log-types)
* [Client Delete Contact Log](../../doc/controllers/client.md#client-delete-contact-log)
* [Client Send Auto Email](../../doc/controllers/client.md#client-send-auto-email)
* [Client Get Active Clients Memberships](../../doc/controllers/client.md#client-get-active-clients-memberships)
* [Client Terminate Contract](../../doc/controllers/client.md#client-terminate-contract)


# Client Get Clients

Get clients.

```csharp
ClientGetClientsAsync(
    string siteId,
    string version,
    string authorization = null,
    List<string> requestClientIDs = null,
    bool? requestIncludeInactive = null,
    bool? requestIsProspect = null,
    DateTime? requestLastModifiedDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    string requestSearchText = null,
    List<long> requestUniqueIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientIDs` | `List<string>` | Query, Optional | The requested client IDs.<br>Default: **all IDs** that the authenticated user’s access level allows. |
| `requestIncludeInactive` | `bool?` | Query, Optional | When `true`, indicates the results to include active and inactive clients.<br /><br>When `false`, indicates that only those clients who are marked as active should be returned. |
| `requestIsProspect` | `bool?` | Query, Optional | When `true`, filters the results to include only those clients marked as prospects for the business.<br /><br>When `false`, indicates that only those clients who are not marked prospects should be returned. |
| `requestLastModifiedDate` | `DateTime?` | Query, Optional | Filters the results to include only the clients that have been modified on or after this date. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSearchText` | `string` | Query, Optional | Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided. |
| `requestUniqueIds` | `List<long>` | Query, Optional | Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.<br>Default: **all UniqueIDs** that the authenticated user’s access level allows. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-clients-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse result = await clientController.ClientGetClientsAsync(siteId, version, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Duplicates

Get client records that would be considered duplicates of the client values passed in.

```csharp
ClientGetClientDuplicatesAsync(
    string siteId,
    string version,
    string authorization = null,
    string requestEmail = null,
    string requestFirstName = null,
    string requestLastName = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEmail` | `string` | Query, Optional | The client email to match on when searching for duplicates. |
| `requestFirstName` | `string` | Query, Optional | The client first name to match on when searching for duplicates. |
| `requestLastName` | `string` | Query, Optional | The client last name to match on when searching for duplicates. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-duplicates-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse result = await clientController.ClientGetClientDuplicatesAsync(siteId, version, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Formula Notes

Get a client's formula notes.

```csharp
ClientGetClientFormulaNotesAsync(
    string siteId,
    string version,
    string authorization = null,
    long? requestAppointmentId = null,
    string requestClientId = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentId` | `long?` | Query, Optional | The appointment ID of the appointment that the formula notes are related to. |
| `requestClientId` | `string` | Query, Optional | The client ID of the client whose formula notes are being requested. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-formula-notes-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse result = await clientController.ClientGetClientFormulaNotesAsync(siteId, version, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Delete Client Formula Note

Deletes client's formula note.

```csharp
ClientDeleteClientFormulaNoteAsync(
    string requestClientId,
    long requestFormulaNoteId,
    string siteId,
    string version,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestClientId` | `string` | Query, Required | The client ID of the client whose formula notes are being requested. |
| `requestFormulaNoteId` | `long` | Query, Required | The Formula Note ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

`Task`

## Example Usage

```csharp
string requestClientId = "request.clientId2";
long requestFormulaNoteId = 72L;
string siteId = "siteId8";
string version = "version4";

try
{
    await clientController.ClientDeleteClientFormulaNoteAsync(requestClientId, requestFormulaNoteId, siteId, version, null, null, null);
}
catch (ApiException e){};
```


# Client Add Formula Note

```csharp
ClientAddFormulaNoteAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-formula-note-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-formula-note-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest();
request.ClientId = "ClientId0";
request.Note = "Note6";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse result = await clientController.ClientAddFormulaNoteAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Upload Client Document

Returns a string representation of the image byte array. The maximum document size is 1MB.

The maximum size file that can be uploaded is 4 MB.

```csharp
ClientUploadClientDocumentAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-document-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-document-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest();
request.ClientId = "ClientId0";
request.File = new MindbodyPublicApiDtoModelsV6ClientDocument();
request.File.FileName = "FileName2";
request.File.MediaType = "MediaType2";
request.File.Buffer = "Buffer4";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse result = await clientController.ClientUploadClientDocumentAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Upload Client Photo

The maximum file size is 4 MB and acceptable file types are:

* bmp
* jpeg
* gif
* tiff
* png

```csharp
ClientUploadClientPhotoAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-photo-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-photo-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest();
request.Bytes = "Bytes6";
request.ClientId = "ClientId0";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse result = await clientController.ClientUploadClientPhotoAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Get Client Contracts

Get contracts that a client has purchased.

```csharp
ClientGetClientContractsAsync(
    string requestClientId,
    string siteId,
    string version,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestClientId` | `string` | Query, Required | The ID of the client. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Determines how many sites are skipped over when retrieving a client’s cross regional contracts. Used when a client ID is linked to more than ten sites in an organization. Only a maximum of ten site databases are queried when this call is made and `CrossRegionalLookup` is set to `true`. To change which sites are queried, change this offset value.<br>Default: **0** |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | When `true`, indicates that the requesting client’s cross regional contracts are returned, if any.<br /><br>When `false`, indicates that cross regional contracts are not returned. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-contracts-response.md)

## Example Usage

```csharp
string requestClientId = "request.clientId2";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsResponse result = await clientController.ClientGetClientContractsAsync(requestClientId, siteId, version, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Services

Get pricing options that a client has purchased.

```csharp
ClientGetClientServicesAsync(
    string requestClientId,
    string siteId,
    string version,
    string authorization = null,
    int? requestClassId = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    DateTime? requestEndDate = null,
    bool? requestIgnoreCrossRegionalSiteLimit = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<int> requestProgramIds = null,
    int? requestSessionTypeId = null,
    bool? requestShowActiveOnly = null,
    DateTime? requestStartDate = null,
    int? requestVisitCount = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestClientId` | `string` | Query, Required | The ID of the client to query. The results are a list of pricing options that the client has purchased. Note that “service” and “pricing option” are synonymous in this section of the documentation. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClassId` | `int?` | Query, Optional | Filters results to only those pricing options that can be used to pay for this class. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters results to pricing options that are valid on or before this date. |
| `requestIgnoreCrossRegionalSiteLimit` | `bool?` | Query, Optional | Used to specify if the number of cross regional sites used to search for client’s pricing options should be ignored.<br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | Filters results to pricing options that can be used at the listed location IDs. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `List<int>` | Query, Optional | Filters results to pricing options that belong to one of the given program IDs. |
| `requestSessionTypeId` | `int?` | Query, Optional | Filters results to pricing options that will pay for the given session type ID. Use this to find pricing options that will pay for a specific appointment type. |
| `requestShowActiveOnly` | `bool?` | Query, Optional | When `true`, includes active services only.<br>Default: **false** |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters results to pricing options that are valid on or after this date. |
| `requestVisitCount` | `int?` | Query, Optional | A filter on the minimum number of visits a service can pay for. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientServicesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-services-response.md)

## Example Usage

```csharp
string requestClientId = "request.clientId2";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientServicesResponse result = await clientController.ClientGetClientServicesAsync(requestClientId, siteId, version, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Visits

Get a client's visit history.

```csharp
ClientGetClientVisitsAsync(
    string requestClientId,
    string siteId,
    string version,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    DateTime? requestStartDate = null,
    bool? requestUnpaidsOnly = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestClientId` | `string` | Query, Required | The ID of the requested client. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br /><br>When `false`, indicates that only visits at the current site are returned. |
| `requestEndDate` | `DateTime?` | Query, Optional | The date past which class visits are not returned.<br>Default: **today’s date** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `DateTime?` | Query, Optional | The date before which class visits are not returned.<br>Default: **the end date** |
| `requestUnpaidsOnly` | `bool?` | Query, Optional | When `true`, indicates that only visits that have not been paid for are returned.<br /><br>When `false`, indicates that all visits are returned, regardless of whether they have been paid for.<br /><br>Default: **false** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientVisitsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-visits-response.md)

## Example Usage

```csharp
string requestClientId = "request.clientId2";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientVisitsResponse result = await clientController.ClientGetClientVisitsAsync(requestClientId, siteId, version, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Schedule

Gets a client's schedule history.

```csharp
ClientGetClientScheduleAsync(
    string requestClientId,
    string siteId,
    string version,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestClientId` | `string` | Query, Required | The ID of the requested client. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br>When `false`, indicates that only visits at the current site are returned. |
| `requestEndDate` | `DateTime?` | Query, Optional | The date past which class visits are not returned.<br>Default is today’s date |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `DateTime?` | Query, Optional | The date before which class visits are not returned.<br>Default is the end date |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-schedule-response.md)

## Example Usage

```csharp
string requestClientId = "request.clientId2";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleResponse result = await clientController.ClientGetClientScheduleAsync(requestClientId, siteId, version, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Active Client Memberships

Get a client's active memberships.

```csharp
ClientGetActiveClientMembershipsAsync(
    string requestClientId,
    string siteId,
    string version,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestClientId` | `string` | Query, Required | The ID of the client whose membership was requested. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | The ID of the location where the requested membership was created. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-active-client-memberships-response.md)

## Example Usage

```csharp
string requestClientId = "request.clientId2";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse result = await clientController.ClientGetActiveClientMembershipsAsync(requestClientId, siteId, version, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Required Client Fields

Gets the list of fields that a new client has to fill out in business mode, specifically for the sign-up process. `AddClient` and `UpdateClient` validate against these fields.

This endpoint has no query parameters.

```csharp
ClientGetRequiredClientFieldsAsync(
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-required-client-fields-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse result = await clientController.ClientGetRequiredClientFieldsAsync(siteId, version, null);
}
catch (ApiException e){};
```


# Client Get Client Referral Types

Gets a list of referral types. Referral types are options that new clients can choose to identify how they learned about the business. Referral types are typically used for the sign-up process.

```csharp
ClientGetClientReferralTypesAsync(
    string siteId,
    string version,
    string authorization = null,
    bool? requestIncludeInactive = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestIncludeInactive` | `bool?` | Query, Optional | When `true`, filters the results to include subtypes and inactive referral types.<br /><br>When `false`, includes no subtypes and only active types. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-referral-types-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse result = await clientController.ClientGetClientReferralTypesAsync(siteId, version, null, null);
}
catch (ApiException e){};
```


# Client Get Client Account Balances

Get account balance information for one or more client(s).

```csharp
ClientGetClientAccountBalancesAsync(
    List<string> requestClientIds,
    string siteId,
    string version,
    string authorization = null,
    DateTime? requestBalanceDate = null,
    int? requestClassId = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestClientIds` | `List<string>` | Query, Required | The list of clients IDs for which you want account balances. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestBalanceDate` | `DateTime?` | Query, Optional | The date you want a balance relative to.<br>Default: **the current date** |
| `requestClassId` | `int?` | Query, Optional | The class ID of the event for which you want a balance. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-account-balances-response.md)

## Example Usage

```csharp
var requestClientIds = new List<string>();
requestClientIds.Add("request.clientIds9");
requestClientIds.Add("request.clientIds0");
requestClientIds.Add("request.clientIds1");
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesResponse result = await clientController.ClientGetClientAccountBalancesAsync(requestClientIds, siteId, version, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Purchases

Get a client's purchase history.

```csharp
ClientGetClientPurchasesAsync(
    string requestClientId,
    string siteId,
    string version,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    int? requestSaleId = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestClientId` | `string` | Query, Required | The ID of the client you are querying for purchases. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters results to purchases made before this timestamp.<br /><br>Default: **end of today** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSaleId` | `int?` | Query, Optional | Filters results to the single record associated with this ID. |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters results to purchases made on or after this timestamp.<br /><br>Default: **now** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-purchases-response.md)

## Example Usage

```csharp
string requestClientId = "request.clientId2";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesResponse result = await clientController.ClientGetClientPurchasesAsync(requestClientId, siteId, version, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Indexes

Client indexes are used to analyze client demographics. A business owner can set up different categories with sets of values which they can assign to each client. Client indexes are used in client searches, for tagging clients so that the owner can send mass emails to similar groups, and for many reports.

For more information, see Client Indexes and [Client Index Values (video tutorial)](https://support.mindbodyonline.com/s/article/203261653-Client-indexes-and-client-index-values-video-tutorial?language=en_USclient).

```csharp
ClientGetClientIndexesAsync(
    string siteId,
    string version,
    string authorization = null,
    bool? requestRequiredOnly = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestRequiredOnly` | `bool?` | Query, Optional | When `true`, filters the results to only indexes that are required on creation.<br /><br>When `false` or omitted, returns all of the client indexes. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-indexes-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse result = await clientController.ClientGetClientIndexesAsync(siteId, version, null, null);
}
catch (ApiException e){};
```


# Client Get Custom Client Fields

Get a site's configured custom client fields.

```csharp
ClientGetCustomClientFieldsAsync(
    string siteId,
    string version,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-custom-client-fields-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsResponse result = await clientController.ClientGetCustomClientFieldsAsync(siteId, version, null, null, null);
}
catch (ApiException e){};
```


# Client Add Contact Log

Add a contact log to a client's account.

```csharp
ClientAddContactLogAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-contact-log-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ContactLog>`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest();
request.ClientId = "ClientId0";
request.ContactMethod = "ContactMethod0";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ContactLog result = await clientController.ClientAddContactLogAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Update Contact Log

Update a contact log on a client's account.

```csharp
ClientUpdateContactLogAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-contact-log-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ContactLog>`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest();
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ContactLog result = await clientController.ClientUpdateContactLogAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Get Cross Regional Client Associations

Returns a list of sites that a particular client ID (also referred to as an RSSID) or a client email address is associated with in a cross-regional organization. Either the `ClientID` or `Email` parameter is required. If both are provided, the `ClientID` is used.

Use this endpoint to retrieve information for other Public API endpoints, about the same client at multiple sites within an organization. To use this endpoint, your developer account must have been granted permission to the site’s entire organization.

Note that this endpoint does not work on the Developer Sandbox site, as it is not set up for cross-regional use cases.

```csharp
ClientGetCrossRegionalClientAssociationsAsync(
    string siteId,
    string version,
    string authorization = null,
    string requestClientId = null,
    string requestEmail = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientId` | `string` | Query, Optional | Looks up the cross regional associations by the client’s ID. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. |
| `requestEmail` | `string` | Query, Optional | Looks up the cross regional associations by the client’s email address. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-cross-regional-client-associations-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsResponse result = await clientController.ClientGetCrossRegionalClientAssociationsAsync(siteId, version, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Add Client

The `FirstName` and `LastName` parameters are always required in this request. All other parameters are optional, but note that any of the optional parameters could be required by a particular business, depending on how the business has configured the site settings.

Use after calling the `GetRequiredClientFields` endpoint to make sure you are collecting all required pieces of information.

```csharp
ClientAddClientAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerAddClientRequest();
request.FirstName = "FirstName8";
request.LastName = "LastName8";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerAddClientResponse result = await clientController.ClientAddClientAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Update Client

Updates an existing client for a specific subscriber. Use this endpoint as follows:

* If you need to update the `ReferredBy` parameter, use this endpoint after calling `GET ClientReferralTypes`.
* When updating a client’s home location, use after calling `GET Locations`.
* If you are updating a client’s stored credit card, use after calling `GET AcceptedCardTypes` so that you can make sure the card is a type that is accepted at the subscriber.
  If this endpoint is used on a cross-regional site, passing in a client’s RSSID and email address creates a cross-regional link. This means that the client is created in cross-regional sites where the client does not exist and `GET CrossRegionalClientAssociations` returns all appropriate cross-regional sites. When `CrossRegionalUpdate` is omitted or set to `true`, the client’s updated information is propagated to all of the region’s sites. If `CrossRegionalUpdate` is set to `false`, only the local client is updated.

Note that the following items cannot be updated for a cross-regional client:

* `ClientIndexes`
* `ClientRelationships`
* `CustomClientFields`
* `SalesReps`
* `SendAccountEmails`
* `SendAccountTexts`
* `SendPromotionalEmails`
* `SendPromotionalTexts`
* `SendScheduleEmails`
* `SendScheduleTexts`

```csharp
ClientUpdateClientAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest();
request.Client = new MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo();
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse result = await clientController.ClientUpdateClientAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Update Client Visit

Update a client's visit.

```csharp
ClientUpdateClientVisitAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-visit-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-visit-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest();
request.VisitId = 92;
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse result = await clientController.ClientUpdateClientVisitAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Add Arrival

Add an arrival for a client.

```csharp
ClientAddArrivalAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-arrival-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-arrival-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest();
request.ClientId = "ClientId0";
request.LocationId = 238;
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse result = await clientController.ClientAddArrivalAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Send Password Reset Email

Send a password reset email to a client.

```csharp
ClientSendPasswordResetEmailAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-send-password-reset-email-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest();
request.UserEmail = "UserEmail2";
request.UserFirstName = "UserFirstName2";
request.UserLastName = "UserLastName8";
string siteId = "siteId8";
string version = "version4";

try
{
    object result = await clientController.ClientSendPasswordResetEmailAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Get Contact Logs

This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.

```csharp
ClientGetContactLogsAsync(
    string requestClientId,
    string siteId,
    string version,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    bool? requestShowSystemGenerated = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null,
    List<int> requestSubtypeIds = null,
    List<int> requestTypeIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestClientId` | `string` | Query, Required | The ID of the client whose contact logs are being requested. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters the results to contact logs created before this date.<br /><br>Default: **the start date** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestShowSystemGenerated` | `bool?` | Query, Optional | When `true`, system-generated contact logs are returned in the results.<br /><br>Default: **false** |
| `requestStaffIds` | `List<long>` | Query, Optional | Filters the results to return contact logs assigned to one or more staff IDs. |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters the results to contact logs created on or after this date.<br /><br>Default: **the current date** |
| `requestSubtypeIds` | `List<int>` | Query, Optional | Filters the results to contact logs assigned one or more of these subtype IDs. |
| `requestTypeIds` | `List<int>` | Query, Optional | Filters the results to contact logs assigned one or more of these type IDs. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-contact-logs-response.md)

## Example Usage

```csharp
string requestClientId = "request.clientId2";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsResponse result = await clientController.ClientGetContactLogsAsync(requestClientId, siteId, version, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Update Client Service

Updates the active date and/or expiration date of a client pricing option. This request requires staff user credentials. If the active date is modified, the expiration date is also modified accordingly. If the expiration date is modified, the active date is unchanged.

```csharp
ClientUpdateClientServiceAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-service-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-service-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest();
request.ServiceId = 130;
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse result = await clientController.ClientUpdateClientServiceAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Get Direct Debit Info

Get direct debit info for a client.

```csharp
ClientGetDirectDebitInfoAsync(
    string siteId,
    string version,
    string authorization = null,
    string clientId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `clientId` | `string` | Query, Optional | - |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6DirectDebitInfo>`](../../doc/models/mindbody-public-api-dto-models-v6-direct-debit-info.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6DirectDebitInfo result = await clientController.ClientGetDirectDebitInfoAsync(siteId, version, null, null);
}
catch (ApiException e){};
```


# Client Delete Direct Debit Info

Delete direct debit info for a client.

```csharp
ClientDeleteDirectDebitInfoAsync(
    string siteId,
    string version,
    string authorization = null,
    string clientId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `clientId` | `string` | Query, Optional | - |

## Response Type

`Task<object>`

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    object result = await clientController.ClientDeleteDirectDebitInfoAsync(siteId, version, null, null);
}
catch (ApiException e){};
```


# Client Add Client Direct Debit Info

```csharp
ClientAddClientDirectDebitInfoAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-direct-debit-info-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-direct-debit-info-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest();
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse result = await clientController.ClientAddClientDirectDebitInfoAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Get Client Rewards

```csharp
ClientGetClientRewardsAsync(
    string requestClientId,
    string siteId,
    string version,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestClientId` | `string` | Query, Required | The ID of the client whose reward information is being requested. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters the results to rewards transactions created before this date.<br /><br>Default: **the start date** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters the results to rewards transactions created on or after this date.<br /><br>Default: **the current date** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-rewards-response.md)

## Example Usage

```csharp
string requestClientId = "request.clientId2";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse result = await clientController.ClientGetClientRewardsAsync(requestClientId, siteId, version, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Update Client Rewards

```csharp
ClientUpdateClientRewardsAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-rewards-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-rewards-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest();
request.ClientId = "ClientId0";
request.Points = 10L;
request.Action = "Action6";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse result = await clientController.ClientUpdateClientRewardsAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Get Client Complete Info

Get Services, Contracts, MemberShips and Arrivals for Client as per requirement

```csharp
ClientGetClientCompleteInfoAsync(
    string requestClientId,
    string siteId,
    string version,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    DateTime? requestEndDate = null,
    List<string> requestRequiredClientData = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestClientId` | `string` | Query, Required | The ID of the client to query. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | Used to retrieve a client’s data from multiple sites within an organization.<br>Default: **false** |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters results to pricing options that are valid on or before this date. |
| `requestRequiredClientData` | `List<string>` | Query, Optional | Used to store the required type of data for particular client |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters results to pricing options that are valid on or after this date. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-complete-info-response.md)

## Example Usage

```csharp
string requestClientId = "request.clientId2";
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse result = await clientController.ClientGetClientCompleteInfoAsync(requestClientId, siteId, version, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Contact Log Types

Get All Active Contact Log Types

```csharp
ClientGetContactLogTypesAsync(
    string siteId,
    string version,
    string authorization = null,
    int? requestContactLogTypeId = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestContactLogTypeId` | `int?` | Query, Optional | The ID of the Contact Log Type |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-contact-log-types-response.md)

## Example Usage

```csharp
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse result = await clientController.ClientGetContactLogTypesAsync(siteId, version, null, null, null, null);
}
catch (ApiException e){};
```


# Client Delete Contact Log

Delete client's contact log.

```csharp
ClientDeleteContactLogAsync(
    string requestClientId,
    long requestContactLogId,
    string siteId,
    string version,
    string authorization = null,
    bool? requestTest = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestClientId` | `string` | Query, Required | The client ID of the client whose Contact Log is being deleted. |
| `requestContactLogId` | `long` | Query, Required | The Contact Log ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestTest` | `bool?` | Query, Optional | When `true`, indicates that this is a test request and no data is inserted into the subscriber’s database.<br>When `false`, the database is updated. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string requestClientId = "request.clientId2";
long requestContactLogId = 90L;
string siteId = "siteId8";
string version = "version4";

try
{
    object result = await clientController.ClientDeleteContactLogAsync(requestClientId, requestContactLogId, siteId, version, null, null);
}
catch (ApiException e){};
```


# Client Send Auto Email

Send a client a supported auto email

```csharp
ClientSendAutoEmailAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-send-auto-email-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest();
request.ClientId = "ClientId0";
request.EmailType = "EmailType4";
string siteId = "siteId8";
string version = "version4";

try
{
    object result = await clientController.ClientSendAutoEmailAsync(request, siteId, version, null);
}
catch (ApiException e){};
```


# Client Get Active Clients Memberships

Get a client's active memberships.

```csharp
ClientGetActiveClientsMembershipsAsync(
    List<string> requestClientIds,
    string siteId,
    string version,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `requestClientIds` | `List<string>` | Query, Required | The ID's of the clients whose membership was requested. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | The ID of the location where the requested membership was created. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-active-clients-memberships-response.md)

## Example Usage

```csharp
var requestClientIds = new List<string>();
requestClientIds.Add("request.clientIds9");
requestClientIds.Add("request.clientIds0");
requestClientIds.Add("request.clientIds1");
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse result = await clientController.ClientGetActiveClientsMembershipsAsync(requestClientIds, siteId, version, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Terminate Contract

Terminate client contract

```csharp
ClientTerminateContractAsync(
    Models.MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest request,
    string siteId,
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-terminate-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `version` | `string` | Template, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-terminate-contract-response.md)

## Example Usage

```csharp
var request = new MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest();
request.ClientId = "ClientId0";
request.ClientContractId = 118;
request.TerminationDate = DateTime.Parse("2016-03-13T12:52:32.123Z");
string siteId = "siteId8";
string version = "version4";

try
{
    MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse result = await clientController.ClientTerminateContractAsync(request, siteId, version, null);
}
catch (ApiException e){};
```

