
# Mindbody Public Api Dto Models V6 Site Controller Get Promo Codes Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetPromoCodesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `PromoCodes` | [`List<Models.MindbodyPublicApiDtoModelsV6PromoCode>`](../../doc/models/mindbody-public-api-dto-models-v6-promo-code.md) | Optional | Contains information about Promocodes at a site |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "PromoCodes": null
}
```

