
# Mindbody Public Api Dto Models V6 Sale Controller Update Product Price Request

Update Product Price Request Model

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BarcodeId` | `string` | Optional | An BarcodeID filter for product. |
| `Price` | `double?` | Optional | The price of the product. |
| `OnlinePrice` | `double?` | Optional | The online price of the product. |

## Example (as JSON)

```json
{
  "BarcodeId": null,
  "Price": null,
  "OnlinePrice": null
}
```

