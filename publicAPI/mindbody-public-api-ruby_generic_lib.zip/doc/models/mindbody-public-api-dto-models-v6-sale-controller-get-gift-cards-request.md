
# Mindbody Public Api Dto Models V6 Sale Controller Get Gift Cards Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LocationId` | `int?` | Optional | When included, returns gift cards that are sold at the provided location ID. |
| `SoldOnline` | `bool?` | Optional | When `true`, only returns gift cards that are sold online.<br /><br>Default: **false** |
| `IncludeCustomLayouts` | `bool?` | Optional | When `true`, includes custom gift card layouts.<br /><br>Default: **false** |
| `Ids` | `List<int>` | Optional | Filters the results to the requested gift card IDs.<br /><br>Default: **all** gift cards. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "LocationId": null,
  "SoldOnline": null,
  "IncludeCustomLayouts": null,
  "Ids": null,
  "Limit": null,
  "Offset": null
}
```

