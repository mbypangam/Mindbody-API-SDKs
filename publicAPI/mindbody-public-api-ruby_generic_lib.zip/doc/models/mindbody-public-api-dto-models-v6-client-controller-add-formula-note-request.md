
# Mindbody Public Api Dto Models V6 Client Controller Add Formula Note Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | Required.  The client’s ID, as configured by the business owner. This is the client’s barcode ID if the business owner assigns barcodes to clients. |
| `AppointmentId` | `long?` | Optional | The optional appointment Id associated with the formula note |
| `Note` | `string` | Required | The note itself |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "AppointmentId": null,
  "Note": "Note0"
}
```

