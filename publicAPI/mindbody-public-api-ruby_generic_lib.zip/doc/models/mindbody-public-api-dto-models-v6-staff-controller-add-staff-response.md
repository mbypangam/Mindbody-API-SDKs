
# Mindbody Public Api Dto Models V6 Staff Controller Add Staff Response

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Staff` | [`Models.MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | - |

## Example (as JSON)

```json
{
  "Staff": null
}
```

