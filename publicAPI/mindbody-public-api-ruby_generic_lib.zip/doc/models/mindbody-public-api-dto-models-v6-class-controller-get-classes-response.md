
# Mindbody Public Api Dto Models V6 Class Controller Get Classes Response

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetClassesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `Classes` | [`List<Models.MindbodyPublicApiDtoModelsV6Class>`](../../doc/models/mindbody-public-api-dto-models-v6-class.md) | Optional | A list of the requested classes. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Classes": null
}
```

