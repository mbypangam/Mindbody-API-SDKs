
# Mindbody Public Api Common Models Appointment

## Structure

`MindbodyPublicApiCommonModelsAppointment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `GenderPreference` | `string` | Optional | - |
| `Duration` | `int?` | Optional | - |
| `ProviderId` | `string` | Optional | - |
| `Id` | `long?` | Optional | - |
| `Status` | [`Models.Status1Enum?`](../../doc/models/status-1-enum.md) | Optional | - |
| `StartDateTime` | `DateTime?` | Optional | - |
| `EndDateTime` | `DateTime?` | Optional | - |
| `Notes` | `string` | Optional | - |
| `StaffRequested` | `bool?` | Optional | - |
| `ProgramId` | `int?` | Optional | - |
| `SessionTypeId` | `int?` | Optional | - |
| `LocationId` | `int?` | Optional | - |
| `StaffId` | `long?` | Optional | - |
| `ClientId` | `string` | Optional | - |
| `FirstAppointment` | `bool?` | Optional | - |
| `ClientServiceId` | `long?` | Optional | - |
| `Resources` | [`List<Models.MindbodyPublicApiCommonModelsResource>`](../../doc/models/mindbody-public-api-common-models-resource.md) | Optional | - |
| `AddOns` | [`List<Models.MindbodyPublicApiCommonModelsAddOnSmall>`](../../doc/models/mindbody-public-api-common-models-add-on-small.md) | Optional | - |
| `OnlineDescription` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "GenderPreference": null,
  "Duration": null,
  "ProviderId": null,
  "Id": null,
  "Status": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Notes": null,
  "StaffRequested": null,
  "ProgramId": null,
  "SessionTypeId": null,
  "LocationId": null,
  "StaffId": null,
  "ClientId": null,
  "FirstAppointment": null,
  "ClientServiceId": null,
  "Resources": null,
  "AddOns": null,
  "OnlineDescription": null
}
```

