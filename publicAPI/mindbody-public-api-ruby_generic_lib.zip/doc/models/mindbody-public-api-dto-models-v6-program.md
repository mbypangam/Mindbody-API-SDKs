
# Mindbody Public Api Dto Models V6 Program

## Structure

`MindbodyPublicApiDtoModelsV6Program`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The service category’s ID. |
| `Name` | `string` | Optional | The name of this service category. |
| `ScheduleType` | [`Models.ScheduleTypeEnum?`](../../doc/models/schedule-type-enum.md) | Optional | The service category’s schedule type. |
| `CancelOffset` | `int?` | Optional | The offset to use for the service category. |
| `ContentFormats` | `List<string>` | Optional | The content delivery platform(s) used by the service category. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "ScheduleType": null,
  "CancelOffset": null,
  "ContentFormats": null
}
```

