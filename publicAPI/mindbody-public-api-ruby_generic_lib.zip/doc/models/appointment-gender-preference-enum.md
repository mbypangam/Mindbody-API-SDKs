
# Appointment Gender Preference Enum

The gender of staff member with whom the client prefers to book appointments.

## Enumeration

`AppointmentGenderPreferenceEnum`

## Fields

| Name |
|  --- |
| `None` |
| `Female` |
| `Male` |

