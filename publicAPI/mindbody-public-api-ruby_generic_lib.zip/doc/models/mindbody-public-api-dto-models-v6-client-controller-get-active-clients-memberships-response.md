
# Mindbody Public Api Dto Models V6 Client Controller Get Active Clients Memberships Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `ClientMemberships` | [`List<Models.MindbodyPublicApiDtoModelsV6ClientMemberships>`](../../doc/models/mindbody-public-api-dto-models-v6-client-memberships.md) | Optional | Details about the requested memberships. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientMemberships": null
}
```

