
# Mindbody Public Api Dto Models V6 Site Controller Get Memberships Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetMembershipsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MembershipIds` | `List<int>` | Optional | Filters results to memberships that belong to one of the given membership IDs. If omitted, all memberships are returned. |

## Example (as JSON)

```json
{
  "MembershipIds": null
}
```

