
# Mindbody Public Api Dto Models V6 Client Controller Get Contact Logs Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | The ID of the client whose contact logs are being requested. |
| `StartDate` | `DateTime?` | Optional | Filters the results to contact logs created on or after this date.<br /><br>Default: **the current date** |
| `EndDate` | `DateTime?` | Optional | Filters the results to contact logs created before this date.<br /><br>Default: **the start date** |
| `StaffIds` | `List<long>` | Optional | Filters the results to return contact logs assigned to one or more staff IDs. |
| `ShowSystemGenerated` | `bool?` | Optional | When `true`, system-generated contact logs are returned in the results.<br /><br>Default: **false** |
| `TypeIds` | `List<int>` | Optional | Filters the results to contact logs assigned one or more of these type IDs. |
| `SubtypeIds` | `List<int>` | Optional | Filters the results to contact logs assigned one or more of these subtype IDs. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "StartDate": null,
  "EndDate": null,
  "StaffIds": null,
  "ShowSystemGenerated": null,
  "TypeIds": null,
  "SubtypeIds": null,
  "Limit": null,
  "Offset": null
}
```

