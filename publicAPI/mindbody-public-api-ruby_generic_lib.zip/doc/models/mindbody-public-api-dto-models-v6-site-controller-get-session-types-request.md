
# Mindbody Public Api Dto Models V6 Site Controller Get Session Types Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetSessionTypesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProgramIDs` | `List<int>` | Optional | Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return. |
| `OnlineOnly` | `bool?` | Optional | When `true`, indicates that only the session types that can be booked online should be returned.<br /><br>Default: **false** |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ProgramIDs": null,
  "OnlineOnly": null,
  "Limit": null,
  "Offset": null
}
```

