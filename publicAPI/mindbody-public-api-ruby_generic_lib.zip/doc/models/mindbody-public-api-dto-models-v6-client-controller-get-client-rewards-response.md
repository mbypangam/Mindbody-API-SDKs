
# Mindbody Public Api Dto Models V6 Client Controller Get Client Rewards Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `Balance` | `long?` | Optional | Current balance of client rewards |
| `Transactions` | [`List<Models.MindbodyPublicApiDtoModelsV6ClientRewardTransaction>`](../../doc/models/mindbody-public-api-dto-models-v6-client-reward-transaction.md) | Optional | List of client reward transactions |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Balance": null,
  "Transactions": null
}
```

