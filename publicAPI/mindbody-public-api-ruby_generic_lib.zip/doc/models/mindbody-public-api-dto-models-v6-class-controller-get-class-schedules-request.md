
# Mindbody Public Api Dto Models V6 Class Controller Get Class Schedules Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetClassSchedulesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClassScheduleIds` | `List<int>` | Optional | The class schedule IDs.<br><br />Default: **all** |
| `EndDate` | `DateTime?` | Optional | The end date of the range. Return any active enrollments that occur on or before this day.<br><br />Default: **StartDate** |
| `LocationIds` | `List<int>` | Optional | The location IDs.<br><br />Default: **all** |
| `ProgramIds` | `List<int>` | Optional | The program IDs.<br><br />Default: **all** |
| `SessionTypeIds` | `List<int>` | Optional | The session type IDs.<br><br />Default: **all** |
| `StaffIds` | `List<long>` | Optional | The staff IDs.<br><br />Default: **all** |
| `StartDate` | `DateTime?` | Optional | The start date of the range. Return any active enrollments that occur on or after this day.<br><br />Default: **today’s date** |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ClassScheduleIds": null,
  "EndDate": null,
  "LocationIds": null,
  "ProgramIds": null,
  "SessionTypeIds": null,
  "StaffIds": null,
  "StartDate": null,
  "Limit": null,
  "Offset": null
}
```

