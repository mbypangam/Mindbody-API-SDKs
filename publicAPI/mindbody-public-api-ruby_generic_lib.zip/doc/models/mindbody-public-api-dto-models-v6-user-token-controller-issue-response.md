
# Mindbody Public Api Dto Models V6 User Token Controller Issue Response

POST UserToken/Issue successful response

## Structure

`MindbodyPublicApiDtoModelsV6UserTokenControllerIssueResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TokenType` | `string` | Optional | - |
| `AccessToken` | `string` | Optional | The authentication token value. |
| `User` | [`Models.MindbodyPublicApiDtoModelsV6User`](../../doc/models/mindbody-public-api-dto-models-v6-user.md) | Optional | - |

## Example (as JSON)

```json
{
  "TokenType": null,
  "AccessToken": null,
  "User": null
}
```

