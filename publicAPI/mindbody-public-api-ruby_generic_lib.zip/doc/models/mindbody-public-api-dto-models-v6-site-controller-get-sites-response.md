
# Mindbody Public Api Dto Models V6 Site Controller Get Sites Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetSitesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `Sites` | [`List<Models.MindbodyPublicApiDtoModelsV6Site>`](../../doc/models/mindbody-public-api-dto-models-v6-site.md) | Optional | Contains information about the sites. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Sites": null
}
```

