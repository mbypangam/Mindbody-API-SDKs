
# Mindbody Public Api Dto Models V6 Client Controller Get Client Rewards Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | The ID of the client whose reward information is being requested. |
| `StartDate` | `DateTime?` | Optional | Filters the results to rewards transactions created on or after this date.<br /><br>Default: **the current date** |
| `EndDate` | `DateTime?` | Optional | Filters the results to rewards transactions created before this date.<br /><br>Default: **the start date** |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "StartDate": null,
  "EndDate": null,
  "Limit": null,
  "Offset": null
}
```

