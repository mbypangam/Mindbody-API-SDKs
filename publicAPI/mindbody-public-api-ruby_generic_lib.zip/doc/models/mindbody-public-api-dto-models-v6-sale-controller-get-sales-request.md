
# Mindbody Public Api Dto Models V6 Sale Controller Get Sales Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetSalesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SaleId` | `long?` | Optional | Filters results to the requested sale ID. |
| `StartSaleDateTime` | `DateTime?` | Optional | Filters results to sales that happened after this date and time. |
| `EndSaleDateTime` | `DateTime?` | Optional | Filters results to sales that happened before this date and time. |
| `PaymentMethodId` | `int?` | Optional | Filters results to sales paid for by the given payment method ID. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "SaleId": null,
  "StartSaleDateTime": null,
  "EndSaleDateTime": null,
  "PaymentMethodId": null,
  "Limit": null,
  "Offset": null
}
```

