
# Mindbody Public Api Dto Models V6 Site Controller Get Mobile Providers Request

Get Mobile Providers Request Object

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetMobileProvidersRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Active` | `bool?` | Optional | When true, the response only contains mobile providers which are activated. When false, only deactivated mobile providers are returned. Default: All Mobile Providers |

## Example (as JSON)

```json
{
  "Active": null
}
```

