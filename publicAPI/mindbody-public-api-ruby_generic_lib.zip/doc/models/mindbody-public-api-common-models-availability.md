
# Mindbody Public Api Common Models Availability

## Structure

`MindbodyPublicApiCommonModelsAvailability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Staff` | [`Models.MindbodyPublicApiCommonModelsStaff`](../../doc/models/mindbody-public-api-common-models-staff.md) | Optional | - |
| `SessionType` | [`Models.MindbodyPublicApiCommonModelsSessionType`](../../doc/models/mindbody-public-api-common-models-session-type.md) | Optional | - |
| `Programs` | [`List<Models.MindbodyPublicApiCommonModelsProgram>`](../../doc/models/mindbody-public-api-common-models-program.md) | Optional | - |
| `StartDateTime` | `DateTime?` | Optional | - |
| `EndDateTime` | `DateTime?` | Optional | - |
| `BookableEndDateTime` | `DateTime?` | Optional | - |
| `Location` | [`Models.MindbodyPublicApiCommonModelsLocation`](../../doc/models/mindbody-public-api-common-models-location.md) | Optional | - |
| `PrepTime` | `int?` | Optional | - |
| `FinishTime` | `int?` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

