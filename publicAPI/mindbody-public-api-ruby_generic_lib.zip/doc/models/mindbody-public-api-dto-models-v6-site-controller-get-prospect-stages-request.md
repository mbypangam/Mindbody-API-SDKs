
# Mindbody Public Api Dto Models V6 Site Controller Get Prospect Stages Request

Get Prospect Stages Request Model

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetProspectStagesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Active` | `bool?` | Optional | The requested Active type Prospect Stages. true indicates for Active Prospect Stages and false indicates for Deactivated Prospect Stages. |

## Example (as JSON)

```json
{
  "Active": null
}
```

