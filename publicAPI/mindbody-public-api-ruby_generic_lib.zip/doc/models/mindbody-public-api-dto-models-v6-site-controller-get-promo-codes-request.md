
# Mindbody Public Api Dto Models V6 Site Controller Get Promo Codes Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetPromoCodesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ActiveOnly` | `bool?` | Optional | Filter only active, defaults to true |
| `OnlineOnly` | `bool?` | Optional | Filter only the ones that can be sold online |
| `StartDate` | `DateTime?` | Optional | Filter by activation start date |
| `EndDate` | `DateTime?` | Optional | Filter by activation end date |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ActiveOnly": null,
  "OnlineOnly": null,
  "StartDate": null,
  "EndDate": null,
  "Limit": null,
  "Offset": null
}
```

