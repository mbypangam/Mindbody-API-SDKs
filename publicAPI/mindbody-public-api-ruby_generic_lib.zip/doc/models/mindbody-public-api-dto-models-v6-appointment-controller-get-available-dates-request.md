
# Mindbody Public Api Dto Models V6 Appointment Controller Get Available Dates Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionTypeId` | `int` | Required | required requested session type ID. |
| `LocationId` | `int?` | Optional | optional requested location ID. |
| `StaffId` | `long?` | Optional | optional requested staff ID. |
| `StartDate` | `DateTime?` | Optional | The start date of the requested date range.<br><br />Default: **today’s date** |
| `EndDate` | `DateTime?` | Optional | The end date of the requested date range.<br><br />Default: **StartDate** |

## Example (as JSON)

```json
{
  "SessionTypeId": 50,
  "LocationId": null,
  "StaffId": null,
  "StartDate": null,
  "EndDate": null
}
```

