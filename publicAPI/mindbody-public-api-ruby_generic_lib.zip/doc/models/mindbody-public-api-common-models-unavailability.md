
# Mindbody Public Api Common Models Unavailability

## Structure

`MindbodyPublicApiCommonModelsUnavailability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `StartDateTime` | `DateTime?` | Optional | - |
| `EndDateTime` | `DateTime?` | Optional | - |
| `Description` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Description": null
}
```

