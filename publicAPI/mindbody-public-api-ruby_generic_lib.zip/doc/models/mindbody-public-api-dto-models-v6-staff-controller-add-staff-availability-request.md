
# Mindbody Public Api Dto Models V6 Staff Controller Add Staff Availability Request

Add Staff Availability/Unavailability Schedule

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StaffId` | `long` | Required | The unique id of the staff |
| `IsAvailability` | `bool` | Required | IsAvailability = true means this is staff available schedule, false means unavailability |
| `Description` | `string` | Optional | Description is required if IsAvailability=false |
| `ProgramIds` | `List<int>` | Optional | List of ProgramIds - for session types the staff member performs, required if IsAvailability=true must be an Active ProgramId between 1 and 21 |
| `LocationId` | `int?` | Optional | The Location for the Availability, will default to 0 when isAvailability=false |
| `DaysOfWeek` | `List<string>` | Required | Day of week for the schedule "Monday", "Tuesday", etc... |
| `StartTime` | `string` | Required | The starting time in site local time format "HH:MM:SS"<br>**Constraints**: *Pattern*: `^(?:(?:([01]?\d\|2[0-3]):)?([0-5]?\d):)?([0-5]?\d)$` |
| `EndTime` | `string` | Required | The ending time in site local time format "HH:MM:SS"<br>**Constraints**: *Pattern*: `^(?:(?:([01]?\d\|2[0-3]):)?([0-5]?\d):)?([0-5]?\d)$` |
| `StartDate` | `string` | Required | The ending time in site local time format "HH:MM:SS"<br>**Constraints**: *Pattern*: `^\d{4}-((0\d)\|(1[012]))-(([012]\d)\|3[01])$` |
| `EndDate` | `string` | Required | The ending time in site local time format "HH:MM:SS"<br>**Constraints**: *Pattern*: `^\d{4}-((0\d)\|(1[012]))-(([012]\d)\|3[01])$` |
| `Status` | `string` | Optional | one of "Public", "Masked", "Hidden", default "Public") - Schedule privacy. "Masked" only valid if IsAavailability=true |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "IsAvailability": false,
  "Description": null,
  "ProgramIds": null,
  "LocationId": null,
  "DaysOfWeek": [
    "DaysOfWeek3",
    "DaysOfWeek4",
    "DaysOfWeek5"
  ],
  "StartTime": "StartTime8",
  "EndTime": "EndTime4",
  "StartDate": "StartDate4",
  "EndDate": "EndDate0",
  "Status": null
}
```

