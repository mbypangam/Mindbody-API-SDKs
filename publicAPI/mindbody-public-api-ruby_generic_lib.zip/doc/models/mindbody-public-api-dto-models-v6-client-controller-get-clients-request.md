
# Mindbody Public Api Dto Models V6 Client Controller Get Clients Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientIDs` | `List<string>` | Optional | The requested client IDs.<br>Default: **all IDs** that the authenticated user’s access level allows. |
| `SearchText` | `string` | Optional | Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided. |
| `IsProspect` | `bool?` | Optional | When `true`, filters the results to include only those clients marked as prospects for the business.<br /><br>When `false`, indicates that only those clients who are not marked prospects should be returned. |
| `LastModifiedDate` | `DateTime?` | Optional | Filters the results to include only the clients that have been modified on or after this date. |
| `UniqueIds` | `List<long>` | Optional | Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.<br>Default: **all UniqueIDs** that the authenticated user’s access level allows. |
| `IncludeInactive` | `bool?` | Optional | When `true`, indicates the results to include active and inactive clients.<br /><br>When `false`, indicates that only those clients who are marked as active should be returned. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ClientIDs": null,
  "SearchText": null,
  "IsProspect": null,
  "LastModifiedDate": null,
  "UniqueIds": null,
  "IncludeInactive": null,
  "Limit": null,
  "Offset": null
}
```

