
# Mindbody Public Api Dto Models V6 Client Controller Get Client Purchases Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | The ID of the client you are querying for purchases. |
| `StartDate` | `DateTime?` | Optional | Filters results to purchases made on or after this timestamp.<br /><br>Default: **now** |
| `EndDate` | `DateTime?` | Optional | Filters results to purchases made before this timestamp.<br /><br>Default: **end of today** |
| `SaleId` | `int?` | Optional | Filters results to the single record associated with this ID. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "StartDate": null,
  "EndDate": null,
  "SaleId": null,
  "Limit": null,
  "Offset": null
}
```

