
# Mindbody Public Api Dto Models V6 Site Controller Add Promo Code Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Code` | `string` | Required | Promotion Code. |
| `Name` | `string` | Required | Promotion Name. |
| `Active` | `bool?` | Optional | Active status |
| `Discount` | [`Models.MindbodyPublicApiDtoModelsV6Discount`](../../doc/models/mindbody-public-api-dto-models-v6-discount.md) | Optional | Discount for a promo code |
| `ActivationDate` | `DateTime?` | Optional | Date activated |
| `ExpirationDate` | `DateTime?` | Optional | Date expired |
| `MaxUses` | `int?` | Optional | How many times it can be used |
| `DaysAfterCloseDate` | `int?` | Optional | Days after close date |
| `AllowOnline` | `bool?` | Optional | Whether it can be used online |
| `DaysValid` | `List<string>` | Optional | What days the promo code can be used |
| `ApplicableItems` | [`List<Models.MindbodyPublicApiDtoModelsV6ApplicableItem>`](../../doc/models/mindbody-public-api-dto-models-v6-applicable-item.md) | Optional | Items that the promo code will have the discount for.<br>If Null, promo code applies to all items. |

## Example (as JSON)

```json
{
  "Code": "Code0",
  "Name": "Name0",
  "Active": null,
  "Discount": null,
  "ActivationDate": null,
  "ExpirationDate": null,
  "MaxUses": null,
  "DaysAfterCloseDate": null,
  "AllowOnline": null,
  "DaysValid": null,
  "ApplicableItems": null
}
```

