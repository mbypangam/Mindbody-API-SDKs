
# Mindbody Public Api Common Models Add on Small

## Structure

`MindbodyPublicApiCommonModelsAddOnSmall`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | - |
| `Name` | `string` | Optional | - |
| `StaffId` | `long?` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "StaffId": null
}
```

