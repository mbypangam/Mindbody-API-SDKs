
# Mindbody Public Api Dto Models V6 Class Controller Get Waitlist Entries Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClassIds` | `List<int>` | Optional | The requested class IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request. <br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClassIds** |
| `ClassScheduleIds` | `List<int>` | Optional | The requested class schedule IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClassScheduleIds** |
| `ClientIds` | `List<string>` | Optional | The requested client IDs.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all ClientIds** |
| `HidePastEntries` | `bool?` | Optional | When `true`, indicates that past waiting list entries are hidden from clients.<br /><br>When `false`, indicates that past entries are not hidden from clients.<br /><br>Default: **false** |
| `WaitlistEntryIds` | `List<int>` | Optional | The requested waiting list entry IDs.<br /><br>Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br /><br>Default: **all WaitlistEntryIds** |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ClassIds": null,
  "ClassScheduleIds": null,
  "ClientIds": null,
  "HidePastEntries": null,
  "WaitlistEntryIds": null,
  "Limit": null,
  "Offset": null
}
```

