
# Mindbody Public Api Dto Models V6 Class Controller Get Semesters Request

Get Semesters Request Model

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetSemestersRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SemesterIDs` | `List<int>` | Optional | Get with semester ids |
| `StartDate` | `DateTime?` | Optional | Filter semesters with start date |
| `EndDate` | `DateTime?` | Optional | Filter semesters with end date |
| `Active` | `bool?` | Optional | Get Active semesters |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "SemesterIDs": null,
  "StartDate": null,
  "EndDate": null,
  "Active": null,
  "Limit": null,
  "Offset": null
}
```

