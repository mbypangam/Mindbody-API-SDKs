
# Mindbody Public Api Dto Models V6 Appointment Controller Get Staff Appointments Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AppointmentIds` | `List<int>` | Optional | A list of the requested appointment IDs. |
| `LocationIds` | `List<int>` | Optional | A list of the requested location IDs. |
| `StartDate` | `DateTime?` | Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today’s date** |
| `EndDate` | `DateTime?` | Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `StaffIds` | `List<long>` | Optional | List of staff IDs to be returned. Use a value of zero to return all staff appointments. |
| `ClientId` | `string` | Optional | The client ID to be returned. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "AppointmentIds": null,
  "LocationIds": null,
  "StartDate": null,
  "EndDate": null,
  "StaffIds": null,
  "ClientId": null,
  "Limit": null,
  "Offset": null
}
```

