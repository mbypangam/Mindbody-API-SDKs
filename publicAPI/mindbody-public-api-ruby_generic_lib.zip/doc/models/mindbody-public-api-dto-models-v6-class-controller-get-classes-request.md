
# Mindbody Public Api Dto Models V6 Class Controller Get Classes Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetClassesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClassDescriptionIds` | `List<int>` | Optional | The requested class description IDs. |
| `ClassIds` | `List<int>` | Optional | The requested class IDs. |
| `ClassScheduleIds` | `List<int>` | Optional | The requested classScheduleIds. |
| `StaffIds` | `List<long>` | Optional | The requested IDs of the teaching staff members. |
| `StartDateTime` | `DateTime?` | Optional | The requested start date for filtering.<br><br />Default: **today’s date** |
| `EndDateTime` | `DateTime?` | Optional | The requested end date for filtering.<br><br />Default: **today’s date** |
| `ClientId` | `string` | Optional | The client ID of the client who is viewing this class list. Based on identity, the client may be able to see additional information, such as membership specials. |
| `ProgramIds` | `List<int>` | Optional | A list of program IDs on which to base the search. |
| `SessionTypeIds` | `List<int>` | Optional | A list of session type IDs on which to base the search. |
| `LocationIds` | `List<int>` | Optional | A list of location IDs on which to base the search. |
| `SemesterIds` | `List<int>` | Optional | A list of semester IDs on which to base the search. |
| `HideCanceledClasses` | `bool?` | Optional | When `true`, canceled classes are removed from the response.<br /><br>When `false`, canceled classes are included in the response.<br /><br>Default: **false** |
| `SchedulingWindow` | `bool?` | Optional | When `true`, classes outside scheduling window are removed from the response.<br /><br>When `false`, classes are included in the response, regardless of the scheduling window.<br /><br>Default: **false** |
| `LastModifiedDate` | `DateTime?` | Optional | When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ClassDescriptionIds": null,
  "ClassIds": null,
  "ClassScheduleIds": null,
  "StaffIds": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "ClientId": null,
  "ProgramIds": null,
  "SessionTypeIds": null,
  "LocationIds": null,
  "SemesterIds": null,
  "HideCanceledClasses": null,
  "SchedulingWindow": null,
  "LastModifiedDate": null,
  "Limit": null,
  "Offset": null
}
```

