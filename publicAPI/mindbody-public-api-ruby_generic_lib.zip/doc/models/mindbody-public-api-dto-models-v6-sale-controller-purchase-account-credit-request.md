
# Mindbody Public Api Dto Models V6 Sale Controller Purchase Account Credit Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Test` | `bool?` | Optional | When `true`, the Public API validates input information, but does not commit it, so no client data is affected.<br /><br>When `false` or omitted, the transaction is committed, and client data is affected.<br /><br>Default: **false** |
| `LocationId` | `int?` | Optional | The ID of the location where the client is purchasing the contract; used for AutoPays. |
| `ClientId` | `string` | Required | The ID of the client. Note that this is not the same as the client’s unique ID. |
| `SendEmailReceipt` | `bool?` | Optional | When `true`, indicates that a purchase receipt email should be sent to the purchasing client, if all settings are correctly configured.<br /><br>When `false`, no email is sent to the purchaser. |
| `SalesRepId` | `long?` | Optional | The ID of the staff member who is to be marked as the sales rep for this gift card purchase. |
| `ConsumerPresent` | `bool?` | Optional | When `true`, indicates that the consumer is available to address any SCA challenge issued by the bank.  EU Only.<br /><br>Default: **false** |
| `PaymentAuthenticationCallbackUrl` | `string` | Optional | This is the Url the consumer will be redirected back to after completion of the Banks SCA challenge. |
| `PaymentInfo` | [`Models.MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-checkout-request-payments-checkout-payment-info.md) | Optional | - |

## Example (as JSON)

```json
{
  "Test": null,
  "LocationId": null,
  "ClientId": "ClientId6",
  "SendEmailReceipt": null,
  "SalesRepId": null,
  "ConsumerPresent": null,
  "PaymentAuthenticationCallbackUrl": null,
  "PaymentInfo": null
}
```

