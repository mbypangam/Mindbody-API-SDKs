
# Mindbody Public Api Dto Models V6 Client Controller Terminate Contract Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | The RSSID of the client for whom the contract is getting terminated. |
| `ClientContractId` | `int` | Required | The unique ID of the sale of the contract |
| `TerminationDate` | `DateTime` | Required | The date to terminate contract |
| `TerminationCode` | `string` | Optional | The termination code |
| `TerminationComments` | `string` | Optional | The termination comments |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "ClientContractId": 86,
  "TerminationDate": "2016-03-13T12:52:32.123Z",
  "TerminationCode": null,
  "TerminationComments": null
}
```

