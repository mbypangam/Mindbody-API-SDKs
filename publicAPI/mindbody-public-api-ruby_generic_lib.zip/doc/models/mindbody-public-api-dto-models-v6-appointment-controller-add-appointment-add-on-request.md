
# Mindbody Public Api Dto Models V6 Appointment Controller Add Appointment Add on Request

Creates an add-on for an appointment

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ApplyPayment` | `bool?` | Optional | Currently not supported Apply Payment for this add-on service.  Optional defaults to true |
| `AppointmentId` | `long?` | Optional | The unique identifier for the appointment we are adding on to |
| `SessionTypeId` | `int?` | Optional | The service we are adding on to the appointment |
| `StaffId` | `long?` | Optional | Optional.  The staff performing the service will default to the appointment staff if unspecified |
| `Test` | `bool?` | Optional | Optional.  When true only performs validation of the request.  Defaults to False. |

## Example (as JSON)

```json
{
  "ApplyPayment": null,
  "AppointmentId": null,
  "SessionTypeId": null,
  "StaffId": null,
  "Test": null
}
```

