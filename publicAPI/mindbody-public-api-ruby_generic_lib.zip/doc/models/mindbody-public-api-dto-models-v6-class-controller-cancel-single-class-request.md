
# Mindbody Public Api Dto Models V6 Class Controller Cancel Single Class Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClassID` | `long?` | Optional | Class ID to lookup. |
| `HideCancel` | `bool?` | Optional | Hide canceled class. |
| `SendClientEmail` | `bool?` | Optional | Client auto email. |
| `SendStaffEmail` | `bool?` | Optional | Staff auto email. |

## Example (as JSON)

```json
{
  "ClassID": null,
  "HideCancel": null,
  "SendClientEmail": null,
  "SendStaffEmail": null
}
```

