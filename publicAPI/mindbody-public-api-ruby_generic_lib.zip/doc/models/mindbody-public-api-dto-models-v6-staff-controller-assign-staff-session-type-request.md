
# Mindbody Public Api Dto Models V6 Staff Controller Assign Staff Session Type Request

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StaffId` | `long` | Required | Id of the staff memeber<br>**Constraints**: `>= 1` |
| `SessionTypeId` | `int` | Required | Id of the session type to assign to the staff<br>**Constraints**: `>= 1`, `<= 2147483647` |
| `Active` | `bool` | Required | Whether the the staff members association to this session type is active. |
| `TimeLength` | `int?` | Optional | - |
| `PrepTime` | `int?` | Optional | Prep time in minutes |
| `FinishTime` | `int?` | Optional | Finish time in minutes |
| `PayRateType` | `string` | Optional | The pay rate type. Can be one of the following (case insensitive):<br>Percent<br>Flat<br>No Pay |
| `PayRateAmount` | `double?` | Optional | The pay rate amount. It's units are based on the PayRateType |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "SessionTypeId": 50,
  "Active": false,
  "TimeLength": null,
  "PrepTime": null,
  "FinishTime": null,
  "PayRateType": null,
  "PayRateAmount": null
}
```

