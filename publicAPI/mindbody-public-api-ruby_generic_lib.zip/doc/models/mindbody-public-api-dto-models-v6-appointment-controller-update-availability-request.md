
# Mindbody Public Api Dto Models V6 Appointment Controller Update Availability Request

This is the update avaialability request coming DTO

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AvailabilityIds` | `List<int>` | Optional | Availability Ids that are to be updated |
| `PublicDisplay` | [`Models.PublicDisplayEnum?`](../../doc/models/public-display-enum.md) | Optional | Choice that decides whether the availablity should be publicly visible, masked or hidden. |
| `DaysOfWeek` | [`List<Models.DaysOfWeekEnum>`](../../doc/models/days-of-week-enum.md) | Optional | The day of the week |
| `ProgramIds` | `List<int>` | Optional | The program Ids |
| `StartDateTime` | `DateTime?` | Optional | - |
| `EndDateTime` | `DateTime?` | Optional | The end date and time |
| `LocationId` | `int?` | Optional | The location id |
| `UnavailableDescription` | `string` | Optional | The description for the unavailability |
| `Test` | `bool?` | Optional | The test flag |

## Example (as JSON)

```json
{
  "AvailabilityIds": null,
  "PublicDisplay": null,
  "DaysOfWeek": null,
  "ProgramIds": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "LocationId": null,
  "UnavailableDescription": null,
  "Test": null
}
```

