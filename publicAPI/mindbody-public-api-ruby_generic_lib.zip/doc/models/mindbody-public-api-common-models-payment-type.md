
# Mindbody Public Api Common Models Payment Type

## Structure

`MindbodyPublicApiCommonModelsPaymentType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `PaymentTypeName` | `string` | Optional | - |
| `Active` | `bool?` | Optional | - |
| `Fee` | `double?` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "PaymentTypeName": null,
  "Active": null,
  "Fee": null
}
```

