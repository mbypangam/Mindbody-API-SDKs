
# Mindbody Public Api Dto Models V6 Client Controller Get Contact Log Types Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `ContactLogTypes` | [`List<Models.MindbodyPublicApiDtoModelsV6ContactLogType>`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log-type.md) | Optional | Contains the information about the contact log types. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ContactLogTypes": null
}
```

