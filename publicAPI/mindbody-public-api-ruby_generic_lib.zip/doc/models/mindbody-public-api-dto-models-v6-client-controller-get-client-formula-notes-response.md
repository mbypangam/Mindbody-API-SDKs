
# Mindbody Public Api Dto Models V6 Client Controller Get Client Formula Notes Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `FormulaNotes` | [`List<Models.MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-formula-note-response.md) | Optional | Contains details about the client’s formula. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "FormulaNotes": null
}
```

