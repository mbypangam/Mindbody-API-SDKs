
# Mindbody Public Api Common Models Amenity

## Structure

`MindbodyPublicApiCommonModelsAmenity`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

