
# Mindbody Public Api Dto Models V6 Class Controller Get Courses Request

This is the request class for the get courses API

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LocationIDs` | `List<int>` | Optional | (optional) The requested locations. |
| `CourseIDs` | `List<long>` | Optional | (optional) The requested course IDs. |
| `StaffIDs` | `List<long>` | Optional | (optional) The requested StaffIDs. |
| `ProgramIDs` | `List<int>` | Optional | (optional) The requested program IDs. |
| `StartDate` | `DateTime?` | Optional | The start date range. Any active courses that are on or after this day.<br><br />(optional) Defaults to today. |
| `EndDate` | `DateTime?` | Optional | The end date range. Any active courses that are on or before this day.<br><br />(optional) Defaults to StartDate. |
| `SemesterIDs` | `List<int>` | Optional | (optional) The requested semester IDs. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "LocationIDs": null,
  "CourseIDs": null,
  "StaffIDs": null,
  "ProgramIDs": null,
  "StartDate": null,
  "EndDate": null,
  "SemesterIDs": null,
  "Limit": null,
  "Offset": null
}
```

