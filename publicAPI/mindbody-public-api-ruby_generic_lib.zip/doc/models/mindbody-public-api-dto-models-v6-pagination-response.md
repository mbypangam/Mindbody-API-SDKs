
# Mindbody Public Api Dto Models V6 Pagination Response

## Structure

`MindbodyPublicApiDtoModelsV6PaginationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `RequestedLimit` | `int?` | Optional | Limit from pagination request |
| `RequestedOffset` | `int?` | Optional | Offset from pagination request |
| `PageSize` | `int?` | Optional | Number of results returned in this response |
| `TotalResults` | `int?` | Optional | Total number of results in dataset |

## Example (as JSON)

```json
{
  "RequestedLimit": null,
  "RequestedOffset": null,
  "PageSize": null,
  "TotalResults": null
}
```

