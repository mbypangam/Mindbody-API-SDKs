
# Mindbody Public Api Dto Models V6 Client Controller Formula Note Response

An individual Client Formula Note.

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The unique Id of the Formula Note. |
| `ClientId` | `string` | Optional | The unique Id of the Client for the formula note |
| `AppointmentId` | `long?` | Optional | The unique Id of the Appointment if the Formula Note was added to a specific appointment. |
| `EntryDate` | `DateTime?` | Optional | The Date the Formula Note was created. |
| `Note` | `string` | Optional | The Note itself |
| `SiteId` | `int?` | Optional | The SiteId where the Formula Note originated. |
| `SiteName` | `string` | Optional | The name of the Site where the Formula Note originated. |
| `StaffFirstName` | `string` | Optional | The first name of the Staff for the associated appointment. |
| `StaffLastName` | `string` | Optional | The last name of the Staff for the associated appointment. |
| `StaffDisplayName` | `string` | Optional | The display name of the Staff for the associated appointment. |

## Example (as JSON)

```json
{
  "Id": null,
  "ClientId": null,
  "AppointmentId": null,
  "EntryDate": null,
  "Note": null,
  "SiteId": null,
  "SiteName": null,
  "StaffFirstName": null,
  "StaffLastName": null,
  "StaffDisplayName": null
}
```

