
# Schedule Type 3 Enum

A schedule type used to filter the returned results.

## Enumeration

`ScheduleType3Enum`

## Fields

| Name |
|  --- |
| `All` |
| `Class` |
| `Enrollment` |
| `Appointment` |
| `Resource` |
| `Media` |
| `Arrival` |

