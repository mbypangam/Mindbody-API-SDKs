
# Mindbody Public Api Dto Models V6 Client Controller Delete Contact Log Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerDeleteContactLogRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | The client ID of the client whose Contact Log is being deleted. |
| `ContactLogId` | `long` | Required | The Contact Log ID. |
| `Test` | `bool?` | Optional | When `true`, indicates that this is a test request and no data is inserted into the subscriber’s database.<br>When `false`, the database is updated. |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "ContactLogId": 62,
  "Test": null
}
```

