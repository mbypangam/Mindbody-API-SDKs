
# Schedule Type Enum

The service category’s schedule type.

## Enumeration

`ScheduleTypeEnum`

## Fields

| Name |
|  --- |
| `All` |
| `Class` |
| `Enrollment` |
| `Appointment` |
| `Resource` |
| `Media` |
| `Arrival` |

