
# Mindbody Public Api Dto Models V6 Sale Controller Initialize Credit Card Entry Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Optional | - |
| `MerchantAccountId` | `string` | Optional | - |
| `LocationId` | `int?` | Optional | - |

## Example (as JSON)

```json
{
  "ClientId": null,
  "MerchantAccountId": null,
  "LocationId": null
}
```

