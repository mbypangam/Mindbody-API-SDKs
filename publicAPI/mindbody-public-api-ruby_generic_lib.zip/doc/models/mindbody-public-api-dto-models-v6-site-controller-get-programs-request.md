
# Mindbody Public Api Dto Models V6 Site Controller Get Programs Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetProgramsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ScheduleType` | [`Models.ScheduleType3Enum?`](../../doc/models/schedule-type-3-enum.md) | Optional | A schedule type used to filter the returned results. |
| `OnlineOnly` | `bool?` | Optional | If `true`, filters results to show only those programs that are shown online.<br /><br>If `false`, all programs are returned.<br /><br>Default: **false** |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ScheduleType": null,
  "OnlineOnly": null,
  "Limit": null,
  "Offset": null
}
```

