
# Action 9 Enum

Action that was performed

## Enumeration

`Action9Enum`

## Fields

| Name |
|  --- |
| `Earned` |
| `Redeemed` |
| `Returned` |
| `Removed` |
| `LateCanceled` |

