
# Mindbody Public Api Dto Models V6 Appointment

Contains information about an appointment.

## Structure

`MindbodyPublicApiDtoModelsV6Appointment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `GenderPreference` | [`Models.GenderPreferenceEnum?`](../../doc/models/gender-preference-enum.md) | Optional | The preferred gender of the appointment provider. |
| `Duration` | `int?` | Optional | The duration of the appointment. |
| `ProviderId` | `string` | Optional | If a user has Complementary and Alternative Medicine features enabled, this property indicates the provider assigned to the appointment. |
| `Id` | `long?` | Optional | The unique ID of the appointment. |
| `Status` | [`Models.StatusEnum?`](../../doc/models/status-enum.md) | Optional | The status of this appointment. |
| `StartDateTime` | `DateTime?` | Optional | The date and time the appointment is to start. |
| `EndDateTime` | `DateTime?` | Optional | The date and time the appointment is to end. |
| `Notes` | `string` | Optional | Any notes associated with the appointment. |
| `StaffRequested` | `bool?` | Optional | When `true`, indicates that the staff member was requested specifically by the client. |
| `ProgramId` | `int?` | Optional | The ID of the program to which this appointment belongs. |
| `SessionTypeId` | `int?` | Optional | The ID of the session type of this appointment. |
| `LocationId` | `int?` | Optional | The ID of the location where this appointment is to take place. |
| `StaffId` | `long?` | Optional | The ID of the staff member providing the service for this appointment. |
| `ClientId` | `string` | Optional | The RSSID of the client who is booked for this appointment. |
| `FirstAppointment` | `bool?` | Optional | When `true`, indicates that this is the client’s first appointment at this site. |
| `ClientServiceId` | `long?` | Optional | The ID of the pass on the client’s account that is to pay for this appointment. |
| `Resources` | [`List<Models.MindbodyPublicApiDtoModelsV6Resource>`](../../doc/models/mindbody-public-api-dto-models-v6-resource.md) | Optional | The resources this appointment is to use. |
| `AddOns` | [`List<Models.MindbodyPublicApiDtoModelsV6AddOnSmall>`](../../doc/models/mindbody-public-api-dto-models-v6-add-on-small.md) | Optional | Any AddOns associated with the appointment |
| `OnlineDescription` | `string` | Optional | Online Description associated with the appointment |

## Example (as JSON)

```json
{
  "GenderPreference": null,
  "Duration": null,
  "ProviderId": null,
  "Id": null,
  "Status": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Notes": null,
  "StaffRequested": null,
  "ProgramId": null,
  "SessionTypeId": null,
  "LocationId": null,
  "StaffId": null,
  "ClientId": null,
  "FirstAppointment": null,
  "ClientServiceId": null,
  "Resources": null,
  "AddOns": null,
  "OnlineDescription": null
}
```

