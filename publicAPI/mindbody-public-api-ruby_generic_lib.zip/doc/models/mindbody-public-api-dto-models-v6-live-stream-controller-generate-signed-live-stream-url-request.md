
# Mindbody Public Api Dto Models V6 Live Stream Controller Generate Signed Live Stream Url Request

Request to create an encrypted live stream url

## Structure

`MindbodyPublicApiDtoModelsV6LiveStreamControllerGenerateSignedLiveStreamUrlRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `long?` | Optional | Id of client at the studio |
| `SubscriberId` | `int?` | Optional | Id of studio aka studioId/siteId |
| `UserDisplayName` | `string` | Optional | User name displayed in VWP live stream |
| `ServiceId` | `int?` | Optional | Id of class instance at studio on given date/time right now since it only supports classes (different from class id) |
| `ApiUser` | `string` | Optional | Identification of 3rd party integrator |
| `ServiceType` | `string` | Optional | Possible values are: "class", "appointment" |

## Example (as JSON)

```json
{
  "ClientId": null,
  "SubscriberId": null,
  "UserDisplayName": null,
  "ServiceId": null,
  "ApiUser": null,
  "ServiceType": null
}
```

