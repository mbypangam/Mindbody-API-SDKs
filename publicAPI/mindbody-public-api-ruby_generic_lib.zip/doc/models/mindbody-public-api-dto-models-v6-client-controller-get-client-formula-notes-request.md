
# Mindbody Public Api Dto Models V6 Client Controller Get Client Formula Notes Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Optional | The client ID of the client whose formula notes are being requested. |
| `AppointmentId` | `long?` | Optional | The appointment ID of the appointment that the formula notes are related to. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ClientId": null,
  "AppointmentId": null,
  "Limit": null,
  "Offset": null
}
```

