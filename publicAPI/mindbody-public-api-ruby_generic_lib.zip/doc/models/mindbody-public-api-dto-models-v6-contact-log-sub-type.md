
# Mindbody Public Api Dto Models V6 Contact Log Sub Type

A contact log subtype.

## Structure

`MindbodyPublicApiDtoModelsV6ContactLogSubType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The contact log subtype’s ID. |

## Example (as JSON)

```json
{
  "Id": null
}
```

