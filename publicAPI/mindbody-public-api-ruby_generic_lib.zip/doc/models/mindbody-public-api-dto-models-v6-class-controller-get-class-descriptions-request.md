
# Mindbody Public Api Dto Models V6 Class Controller Get Class Descriptions Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClassDescriptionId` | `int?` | Optional | Filters to the single result with the given ID. |
| `ProgramIds` | `List<int>` | Optional | Filters results to class descriptions belonging to the given programs. |
| `StartClassDateTime` | `DateTime?` | Optional | Filters the results to class descriptions for scheduled classes that happen on or after the given date and time. |
| `EndClassDateTime` | `DateTime?` | Optional | Filters the results to class descriptions for scheduled classes that happen before the given date and time. |
| `StaffId` | `long?` | Optional | Filters results to class descriptions for scheduled classes taught by the given staff member. |
| `LocationId` | `int?` | Optional | Filters results to classes descriptions for schedule classes as the given location. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ClassDescriptionId": null,
  "ProgramIds": null,
  "StartClassDateTime": null,
  "EndClassDateTime": null,
  "StaffId": null,
  "LocationId": null,
  "Limit": null,
  "Offset": null
}
```

