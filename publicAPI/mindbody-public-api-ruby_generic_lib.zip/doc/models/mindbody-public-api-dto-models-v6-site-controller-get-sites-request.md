
# Mindbody Public Api Dto Models V6 Site Controller Get Sites Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetSitesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SiteIds` | `List<int>` | Optional | List of the requested site IDs. When omitted, returns all sites that the source has access to. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "SiteIds": null,
  "Limit": null,
  "Offset": null
}
```

