
# Mindbody Public Api Dto Models V6 Staff Controller Get Staff Session Types Request

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StaffId` | `long` | Required | Filters returned session types to only those the staff member performs.  Staff should be active. |
| `ProgramIds` | `List<int>` | Optional | Filters results to session types that belong in program IDs. |
| `OnlineOnly` | `bool?` | Optional | Only session types that can be booked online. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "ProgramIds": null,
  "OnlineOnly": null,
  "Limit": null,
  "Offset": null
}
```

