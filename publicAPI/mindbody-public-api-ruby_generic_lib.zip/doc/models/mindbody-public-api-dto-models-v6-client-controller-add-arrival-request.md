
# Mindbody Public Api Dto Models V6 Client Controller Add Arrival Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | The ID of the requested client. |
| `LocationId` | `int` | Required | The ID of the location for the requested arrival. |
| `ArrivalTypeId` | `int?` | Optional | The ID of the arrival type to take.<br>OPTIONAL: will take first payment found if not provided |
| `Test` | `bool?` | Optional | OPTIONAL: If test is true only validation is ran |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "LocationId": 50,
  "ArrivalTypeId": null,
  "Test": null
}
```

