
# Mindbody Public Api Dto Models V6 Sale Controller Return Sale Request

ReturnSaleRequest

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SaleId` | `long?` | Optional | SaleId |
| `ReturnReason` | `string` | Optional | ReturnReason |

## Example (as JSON)

```json
{
  "SaleId": null,
  "ReturnReason": null
}
```

