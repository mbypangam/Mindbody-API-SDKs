
# Mindbody Public Api Dto Models V6 Class Controller Get Enrollments Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClassScheduleIds` | `List<int>` | Optional | A list of the requested class schedule IDs. If omitted, all class schedule IDs return. |
| `EndDate` | `DateTime?` | Optional | The end of the date range. The response returns any active enrollments that occur on or before this day.<br /><br>Default: **StartDate** |
| `LocationIds` | `List<int>` | Optional | List of the IDs for the requested locations. If omitted, all location IDs return. |
| `ProgramIds` | `List<int>` | Optional | List of the IDs for the requested programs. If omitted, all program IDs return. |
| `SessionTypeIds` | `List<int>` | Optional | List of the IDs for the requested session types. If omitted, all session types IDs return. |
| `StaffIds` | `List<long>` | Optional | List of the IDs for the requested staff IDs. If omitted, all staff IDs return. |
| `StartDate` | `DateTime?` | Optional | The start of the date range. The response returns any active enrollments that occur on or after this day.<br /><br>Default: **today’s date** |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ClassScheduleIds": null,
  "EndDate": null,
  "LocationIds": null,
  "ProgramIds": null,
  "SessionTypeIds": null,
  "StaffIds": null,
  "StartDate": null,
  "Limit": null,
  "Offset": null
}
```

