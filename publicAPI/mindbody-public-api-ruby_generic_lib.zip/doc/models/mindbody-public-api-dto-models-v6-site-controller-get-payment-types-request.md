
# Mindbody Public Api Dto Models V6 Site Controller Get Payment Types Request

Get Payment Types Request Model

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetPaymentTypesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Active` | `bool?` | Optional | The requested Active payment types. true indicates for Active payment types and false indicates for Deactivated payment types. |

## Example (as JSON)

```json
{
  "Active": null
}
```

