
# Mindbody Public Api Dto Models V6 Site Controller Get Resources Request

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetResourcesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SessionTypeIds` | `List<int>` | Optional | List of session type IDs.<br /><br>Default: **all** |
| `LocationId` | `int?` | Optional | The location of the resource. This parameter is ignored if `EndDateTime` or `LocationID` is not set.<br /><br>Default: **all** |
| `StartDateTime` | `DateTime?` | Optional | The time the resource starts. This parameter is ignored if `EndDateTime` or `LocationID` is not set. |
| `EndDateTime` | `DateTime?` | Optional | The time the resource ends. This parameter is ignored if `EndDateTime` or `LocationID` is not set. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "SessionTypeIds": null,
  "LocationId": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Limit": null,
  "Offset": null
}
```

