
# Mindbody Public Api Dto Models V6 Client Controller Get Contact Log Types Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ContactLogTypeId` | `int?` | Optional | The ID of the Contact Log Type |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ContactLogTypeId": null,
  "Limit": null,
  "Offset": null
}
```

