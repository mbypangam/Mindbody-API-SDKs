
# Mindbody Public Api Dto Models V6 Sale Controller Update Product Request

Update Product Request Model

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BarcodeId` | `string` | Optional | The unique ID of the product variant, for example, a particular size and color combination. |
| `Price` | `double?` | Optional | The price of the product.<br>**Constraints**: `>= 0` |
| `OnlinePrice` | `double?` | Optional | The online price of the product.<br>**Constraints**: `>= 0` |

## Example (as JSON)

```json
{
  "BarcodeId": null,
  "Price": null,
  "OnlinePrice": null
}
```

