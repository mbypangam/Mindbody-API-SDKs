
# Mindbody Public Api Dto Models V6 Client Controller Get Client Referral Types Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IncludeInactive` | `bool?` | Optional | When `true`, filters the results to include subtypes and inactive referral types.<br /><br>When `false`, includes no subtypes and only active types. |

## Example (as JSON)

```json
{
  "IncludeInactive": null
}
```

