
# Mindbody Public Api Dto Models V6 Staff Controller Get Sales Reps Response

This is the response class for the get sales reps API

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `SalesReps` | [`List<Models.MindbodyPublicApiDtoModelsV6SalesRepResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sales-rep-response.md) | Optional | This the list of sales reps and their details |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "SalesReps": null
}
```

