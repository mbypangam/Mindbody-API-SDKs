
# Mindbody Public Api Dto Models V6 Client Controller Get Client Account Balances Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BalanceDate` | `DateTime?` | Optional | The date you want a balance relative to.<br>Default: **the current date** |
| `ClassId` | `int?` | Optional | The class ID of the event for which you want a balance. |
| `ClientIds` | `List<string>` | Required | The list of clients IDs for which you want account balances. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "BalanceDate": null,
  "ClassId": null,
  "ClientIds": [
    "ClientIds3",
    "ClientIds4"
  ],
  "Limit": null,
  "Offset": null
}
```

