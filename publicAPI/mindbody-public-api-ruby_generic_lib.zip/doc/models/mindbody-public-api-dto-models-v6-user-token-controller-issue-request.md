
# Mindbody Public Api Dto Models V6 User Token Controller Issue Request

POST UserToken/Issue request

## Structure

`MindbodyPublicApiDtoModelsV6UserTokenControllerIssueRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Username` | `string` | Optional | The staff member’s username. |
| `Password` | `string` | Optional | The staff member’s password. |

## Example (as JSON)

```json
{
  "Username": null,
  "Password": null
}
```

