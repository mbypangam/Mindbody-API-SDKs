
# Mindbody Public Api Common Models Sub Category

## Structure

`MindbodyPublicApiCommonModelsSubCategory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `SubCategoryName` | `string` | Optional | - |
| `Active` | `bool?` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "SubCategoryName": null,
  "Active": null
}
```

