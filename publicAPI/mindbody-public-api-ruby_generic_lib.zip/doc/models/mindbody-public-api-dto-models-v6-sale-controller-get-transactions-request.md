
# Mindbody Public Api Dto Models V6 Sale Controller Get Transactions Request

Transactions Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SaleId` | `long?` | Optional | Filters results to the requested sale ID. |
| `TransactionId` | `int?` | Optional | Filters results to the requested transaction ID. |
| `ClientId` | `long?` | Optional | Filters results to the requested client ID. |
| `LocationId` | `int?` | Optional | Filters results to the requested location ID. |
| `Status` | `string` | Optional | Filters results to the requested status. |
| `TransactionStartDateTime` | `DateTime?` | Optional | Filters results to transactions that happened after this date and time. |
| `TransactionEndDateTime` | `DateTime?` | Optional | Filters results to transactions that happened before this date and time. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "SaleId": null,
  "TransactionId": null,
  "ClientId": null,
  "LocationId": null,
  "Status": null,
  "TransactionStartDateTime": null,
  "TransactionEndDateTime": null,
  "Limit": null,
  "Offset": null
}
```

