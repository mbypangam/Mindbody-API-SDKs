
# Mindbody Public Api Dto Models V6 Client Reward Transaction

Client reward transaction

## Structure

`MindbodyPublicApiDtoModelsV6ClientRewardTransaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ActionDateTime` | `DateTime?` | Optional | Timestamp of the transaction |
| `Action` | [`Models.Action9Enum?`](../../doc/models/action-9-enum.md) | Optional | Action that was performed |
| `Source` | `string` | Optional | Source of transaction |
| `SourceID` | `long?` | Optional | Unique ID of transaction type |
| `ExpirationDateTime` | `DateTime?` | Optional | Expiration of earned points |
| `Points` | `long?` | Optional | Value of the transaction |

## Example (as JSON)

```json
{
  "ActionDateTime": null,
  "Action": null,
  "Source": null,
  "SourceID": null,
  "ExpirationDateTime": null,
  "Points": null
}
```

