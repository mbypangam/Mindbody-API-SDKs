
# Mindbody Public Api Dto Models V6 Appointment Controller Get Schedule Items Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LocationIds` | `List<int>` | Optional | A list of requested location IDs. |
| `StaffIds` | `List<long>` | Optional | A list of requested staff IDs. |
| `StartDate` | `DateTime?` | Optional | The start date of the requested date range.<br><br />Default: **today’s date** |
| `EndDate` | `DateTime?` | Optional | The end date of the requested date range.<br><br />Default: **today’s date** |
| `IgnorePrepFinishTimes` | `bool?` | Optional | When `true`, appointment preparation and finish unavailabilities are not returned.<br><br />Default: **false** |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "LocationIds": null,
  "StaffIds": null,
  "StartDate": null,
  "EndDate": null,
  "IgnorePrepFinishTimes": null,
  "Limit": null,
  "Offset": null
}
```

