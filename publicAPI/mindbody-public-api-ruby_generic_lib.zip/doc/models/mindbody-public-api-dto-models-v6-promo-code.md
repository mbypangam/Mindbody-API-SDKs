
# Mindbody Public Api Dto Models V6 Promo Code

## Structure

`MindbodyPublicApiDtoModelsV6PromoCode`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | Name of the promo code |
| `Code` | `string` | Optional | Code to be used at purchase for discount |
| `Active` | `bool?` | Optional | Active status |
| `Discount` | [`Models.MindbodyPublicApiDtoModelsV6Discount`](../../doc/models/mindbody-public-api-dto-models-v6-discount.md) | Optional | Discount for a promo code |
| `ActivationDate` | `DateTime?` | Optional | Date activated |
| `ExpirationDate` | `DateTime?` | Optional | Date expired |
| `MaxUses` | `int?` | Optional | How many times it can be used |
| `DaysAfterCloseDate` | `int?` | Optional | Days after close date |
| `AllowOnline` | `bool?` | Optional | Whether it can be used online |
| `DaysValid` | [`List<Models.DaysValidEnum>`](../../doc/models/days-valid-enum.md) | Optional | What days the promo code can be used |
| `ApplicableItems` | [`List<Models.MindbodyPublicApiDtoModelsV6ApplicableItem>`](../../doc/models/mindbody-public-api-dto-models-v6-applicable-item.md) | Optional | Items that the promo code will have the discount for |

## Example (as JSON)

```json
{
  "Name": null,
  "Code": null,
  "Active": null,
  "Discount": null,
  "ActivationDate": null,
  "ExpirationDate": null,
  "MaxUses": null,
  "DaysAfterCloseDate": null,
  "AllowOnline": null,
  "DaysValid": null,
  "ApplicableItems": null
}
```

