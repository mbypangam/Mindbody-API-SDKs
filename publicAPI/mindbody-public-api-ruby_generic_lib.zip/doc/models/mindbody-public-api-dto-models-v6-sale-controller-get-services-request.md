
# Mindbody Public Api Dto Models V6 Sale Controller Get Services Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetServicesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProgramIds` | `List<int>` | Optional | Filters to pricing options with the specified program IDs. |
| `SessionTypeIds` | `List<int>` | Optional | Filters to the pricing options with the specified session types IDs. |
| `ServiceIds` | `List<string>` | Optional | Filters to the pricing options with the specified IDs. In this context, service and pricing option are used interchangeably. |
| `ClassId` | `int?` | Optional | Filters to the pricing options for the specified class ID. |
| `ClassScheduleId` | `int?` | Optional | Filters to the pricing options for the specified class schedule ID. |
| `SellOnline` | `bool?` | Optional | When `true`, filters to the pricing options that can be sold online.<br /><br>Default: **false** |
| `LocationId` | `int?` | Optional | When specified, for each returned pricing option, `TaxRate` and `TaxIncluded` are calculated according to the specified location. Note that this does not filter results to only services provided at the given location, and for locations where Value-Added Tax (VAT) rules apply, the `TaxRate` is set to zero. |
| `HideRelatedPrograms` | `bool?` | Optional | When `true`, indicates that pricing options of related programs are omitted from the response.<br /><br>Default: **false** |
| `StaffId` | `long?` | Optional | Sets `Price` and `OnlinePrice` to the particular pricing of a specific staff member, if allowed by the business. |
| `IncludeDiscontinued` | `bool?` | Optional | When `true`, indicates that the filtered pricing option list includes discontinued pricing options.<br /><br>Default: **false** |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "ProgramIds": null,
  "SessionTypeIds": null,
  "ServiceIds": null,
  "ClassId": null,
  "ClassScheduleId": null,
  "SellOnline": null,
  "LocationId": null,
  "HideRelatedPrograms": null,
  "StaffId": null,
  "IncludeDiscontinued": null,
  "Limit": null,
  "Offset": null
}
```

