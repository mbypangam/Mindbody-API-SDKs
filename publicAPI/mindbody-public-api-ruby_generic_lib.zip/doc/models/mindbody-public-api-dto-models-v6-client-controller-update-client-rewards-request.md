
# Mindbody Public Api Dto Models V6 Client Controller Update Client Rewards Request

Request object for using the API to Earn or Redeem reward points

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | Required.  The client’s ID, as configured by the business owner. This is the client’s barcode ID if the business owner assigns barcodes to clients. |
| `Points` | `long` | Required | Required. The amount of Rewards Points we are earning/redeeming<br>**Constraints**: `>= 1` |
| `Source` | `string` | Optional | Required if Action is "Earned".  Must be one of "Sale","Class Booking","Appointment Booking", or "Referral" |
| `SourceId` | `long?` | Optional | Optional.  The unique Id in the MINDBODY System for the Source of the reward.  For example, If the Action is "Earned" and Source is "Sale" then the SourceId is the unique Id for the<br>sale in the MINDBODY System.  If action is redeemed, the RedemptionType will be "Purchase" and if provided the SourceId is the unique id of the sale in the MINDBODY system where the points were redeemed. |
| `Action` | `string` | Required | Required.  The Action we are taking on the rewards points.  Must be either "Earned" or "Redeemed" |
| `ActionDateTime` | `DateTime?` | Optional | Optional.  The Date and Time the Action Occurred in UTC.  May not be in the future, if omitted defaults to current Date/Time in UTC. |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "Points": 22,
  "Source": null,
  "SourceId": null,
  "Action": "Action0",
  "ActionDateTime": null
}
```

