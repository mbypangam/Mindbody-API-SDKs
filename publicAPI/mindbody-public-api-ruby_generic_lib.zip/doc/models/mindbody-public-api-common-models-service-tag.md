
# Mindbody Public Api Common Models Service Tag

## Structure

`MindbodyPublicApiCommonModelsServiceTag`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

