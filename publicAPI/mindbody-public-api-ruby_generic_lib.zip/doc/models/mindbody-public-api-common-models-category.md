
# Mindbody Public Api Common Models Category

## Structure

`MindbodyPublicApiCommonModelsCategory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `CategoryName` | `string` | Optional | - |
| `Description` | `string` | Optional | - |
| `Service` | `bool?` | Optional | - |
| `Active` | `bool?` | Optional | - |
| `IsPrimary` | `bool?` | Optional | - |
| `IsSecondary` | `bool?` | Optional | - |
| `CreatedDateTimeUTC` | `DateTime?` | Optional | - |
| `ModifiedDateTimeUTC` | `DateTime?` | Optional | - |
| `SubCategories` | [`List<Models.MindbodyPublicApiCommonModelsSubCategory>`](../../doc/models/mindbody-public-api-common-models-sub-category.md) | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "CategoryName": null,
  "Description": null,
  "Service": null,
  "Active": null,
  "IsPrimary": null,
  "IsSecondary": null,
  "CreatedDateTimeUTC": null,
  "ModifiedDateTimeUTC": null,
  "SubCategories": null
}
```

