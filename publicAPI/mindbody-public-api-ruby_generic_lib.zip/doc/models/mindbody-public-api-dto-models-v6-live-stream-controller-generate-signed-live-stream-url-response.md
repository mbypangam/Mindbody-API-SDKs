
# Mindbody Public Api Dto Models V6 Live Stream Controller Generate Signed Live Stream Url Response

Response with encrypted live stream url

## Structure

`MindbodyPublicApiDtoModelsV6LiveStreamControllerGenerateSignedLiveStreamUrlResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SignedUrl` | `string` | Optional | Encrypted URL that will allow a user to join a live stream without logging in. |

## Example (as JSON)

```json
{
  "SignedUrl": null
}
```

