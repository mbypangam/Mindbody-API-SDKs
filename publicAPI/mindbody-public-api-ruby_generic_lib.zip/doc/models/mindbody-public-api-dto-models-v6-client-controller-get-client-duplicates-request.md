
# Mindbody Public Api Dto Models V6 Client Controller Get Client Duplicates Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FirstName` | `string` | Optional | The client first name to match on when searching for duplicates. |
| `LastName` | `string` | Optional | The client last name to match on when searching for duplicates. |
| `Email` | `string` | Optional | The client email to match on when searching for duplicates. |
| `Limit` | `int?` | Optional | Number of results to include, defaults to 100 |
| `Offset` | `int?` | Optional | Page offset, defaults to 0. |

## Example (as JSON)

```json
{
  "FirstName": null,
  "LastName": null,
  "Email": null,
  "Limit": null,
  "Offset": null
}
```

