
# Status 1 Enum

## Enumeration

`Status1Enum`

## Fields

| Name |
|  --- |
| `Booked` |
| `Completed` |
| `Confirmed` |
| `Arrived` |
| `NoShow` |
| `Cancelled` |
| `LateCancelled` |

