
# Mindbody Public Api Dto Models V6 Substitute Teacher Class

Represents a single class instance. Used in SubstituteClassTeacher endpoint.

## Structure

`MindbodyPublicApiDtoModelsV6SubstituteTeacherClass`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClassScheduleId` | `int?` | Optional | The class schedule ID of the requested class. |
| `Location` | [`Models.MindbodyPublicApiDtoModelsV6Location`](../../doc/models/mindbody-public-api-dto-models-v6-location.md) | Optional | - |
| `MaxCapacity` | `int?` | Optional | The total number of bookings allowed in the class. |
| `WebCapacity` | `int?` | Optional | The total number of online bookings allowed in the class. |
| `TotalBooked` | `int?` | Optional | The total number of clients who are booked into the class prior to this call being made. |
| `TotalBookedWaitlist` | `int?` | Optional | The total number of booked clients who are on the waiting list for the class prior to this call being made. |
| `WebBooked` | `int?` | Optional | The total number of bookings in the class made by online users, prior to this call being made. This property is the current number of bookings counted toward the `WebCapacity` limit. |
| `SemesterId` | `int?` | Optional | Identifies the semester assigned to this class. |
| `IsCanceled` | `bool?` | Optional | When `true`, indicates that the class has been canceled.<br /><br>When `false`, indicates that the class has not been canceled and may still be bookable. |
| `Substitute` | `bool?` | Optional | When `true`, indicates that the class is being taught by a substitute teacher. |
| `Active` | `bool?` | Optional | When `true`, indicates that the class is being shown to clients in consumer mode. |
| `IsWaitlistAvailable` | `bool?` | Optional | When `true`, indicates that the class has a waiting list and there is space available on the waiting list for another client.<br /><br>When `false`, indicates either that the class does not have a waiting list or there is no space available on the class waiting list. |
| `HideCancel` | `bool?` | Optional | When `true`, indicates that this class is should not be shown to clients when `IsCancelled` is `true`.<br /><br>When `false`, indicates that this class is should be shown to clients when `IsCancelled` is `true`.<br /><br>This property can be ignored when the `IsCancelled` property is `false`. |
| `Id` | `int?` | Optional | The unique identifier of the class. |
| `IsAvailable` | `bool?` | Optional | When `true`, indicates that the class can be booked.<br /><br>When `false`, that the class cannot be booked at this time. |
| `StartDateTime` | `DateTime?` | Optional | The date and time that this class is scheduled to start. |
| `EndDateTime` | `DateTime?` | Optional | The date and time when this class is scheduled to end. |
| `LastModifiedDateTime` | `DateTime?` | Optional | The last time the class was modified. |
| `ClassDescription` | [`Models.MindbodyPublicApiDtoModelsV6ClassDescription`](../../doc/models/mindbody-public-api-dto-models-v6-class-description.md) | Optional | Represents a class definition. The class meets at the start time, goes until the end time. |
| `Staff` | [`Models.MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | - |
| `VirtualStreamLink` | `string` | Optional | The URL for the pre-recorded live stream for the class if hosted on the mindbody virtual wellness platform |

## Example (as JSON)

```json
{
  "ClassScheduleId": null,
  "Location": null,
  "MaxCapacity": null,
  "WebCapacity": null,
  "TotalBooked": null,
  "TotalBookedWaitlist": null,
  "WebBooked": null,
  "SemesterId": null,
  "IsCanceled": null,
  "Substitute": null,
  "Active": null,
  "IsWaitlistAvailable": null,
  "HideCancel": null,
  "Id": null,
  "IsAvailable": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "LastModifiedDateTime": null,
  "ClassDescription": null,
  "Staff": null,
  "VirtualStreamLink": null
}
```

