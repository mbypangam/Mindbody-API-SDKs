// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesRequest"/> class.
        /// </summary>
        /// <param name="classIds">ClassIds.</param>
        /// <param name="classScheduleIds">ClassScheduleIds.</param>
        /// <param name="clientIds">ClientIds.</param>
        /// <param name="hidePastEntries">HidePastEntries.</param>
        /// <param name="waitlistEntryIds">WaitlistEntryIds.</param>
        /// <param name="limit">Limit.</param>
        /// <param name="offset">Offset.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesRequest(
            List<int> classIds = null,
            List<int> classScheduleIds = null,
            List<string> clientIds = null,
            bool? hidePastEntries = null,
            List<int> waitlistEntryIds = null,
            int? limit = null,
            int? offset = null)
        {
            this.ClassIds = classIds;
            this.ClassScheduleIds = classScheduleIds;
            this.ClientIds = clientIds;
            this.HidePastEntries = hidePastEntries;
            this.WaitlistEntryIds = waitlistEntryIds;
            this.Limit = limit;
            this.Offset = offset;
        }

        /// <summary>
        /// The requested class IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request. <br />
        /// Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />
        /// Default: **all ClassIds**
        /// </summary>
        [JsonProperty("ClassIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ClassIds { get; set; }

        /// <summary>
        /// The requested class schedule IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request.<br />
        /// Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />
        /// Default: **all ClassScheduleIds**
        /// </summary>
        [JsonProperty("ClassScheduleIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ClassScheduleIds { get; set; }

        /// <summary>
        /// The requested client IDs.<br />
        /// Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />
        /// Default: **all ClientIds**
        /// </summary>
        [JsonProperty("ClientIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> ClientIds { get; set; }

        /// <summary>
        /// When `true`, indicates that past waiting list entries are hidden from clients.<br />
        /// When `false`, indicates that past entries are not hidden from clients.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("HidePastEntries", NullValueHandling = NullValueHandling.Ignore)]
        public bool? HidePastEntries { get; set; }

        /// <summary>
        /// The requested waiting list entry IDs.<br />
        /// Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />
        /// Default: **all WaitlistEntryIds**
        /// </summary>
        [JsonProperty("WaitlistEntryIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> WaitlistEntryIds { get; set; }

        /// <summary>
        /// Number of results to include, defaults to 100
        /// </summary>
        [JsonProperty("Limit", NullValueHandling = NullValueHandling.Ignore)]
        public int? Limit { get; set; }

        /// <summary>
        /// Page offset, defaults to 0.
        /// </summary>
        [JsonProperty("Offset", NullValueHandling = NullValueHandling.Ignore)]
        public int? Offset { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesRequest other &&
                ((this.ClassIds == null && other.ClassIds == null) || (this.ClassIds?.Equals(other.ClassIds) == true)) &&
                ((this.ClassScheduleIds == null && other.ClassScheduleIds == null) || (this.ClassScheduleIds?.Equals(other.ClassScheduleIds) == true)) &&
                ((this.ClientIds == null && other.ClientIds == null) || (this.ClientIds?.Equals(other.ClientIds) == true)) &&
                ((this.HidePastEntries == null && other.HidePastEntries == null) || (this.HidePastEntries?.Equals(other.HidePastEntries) == true)) &&
                ((this.WaitlistEntryIds == null && other.WaitlistEntryIds == null) || (this.WaitlistEntryIds?.Equals(other.WaitlistEntryIds) == true)) &&
                ((this.Limit == null && other.Limit == null) || (this.Limit?.Equals(other.Limit) == true)) &&
                ((this.Offset == null && other.Offset == null) || (this.Offset?.Equals(other.Offset) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClassIds = {(this.ClassIds == null ? "null" : $"[{string.Join(", ", this.ClassIds)} ]")}");
            toStringOutput.Add($"this.ClassScheduleIds = {(this.ClassScheduleIds == null ? "null" : $"[{string.Join(", ", this.ClassScheduleIds)} ]")}");
            toStringOutput.Add($"this.ClientIds = {(this.ClientIds == null ? "null" : $"[{string.Join(", ", this.ClientIds)} ]")}");
            toStringOutput.Add($"this.HidePastEntries = {(this.HidePastEntries == null ? "null" : this.HidePastEntries.ToString())}");
            toStringOutput.Add($"this.WaitlistEntryIds = {(this.WaitlistEntryIds == null ? "null" : $"[{string.Join(", ", this.WaitlistEntryIds)} ]")}");
            toStringOutput.Add($"this.Limit = {(this.Limit == null ? "null" : this.Limit.ToString())}");
            toStringOutput.Add($"this.Offset = {(this.Offset == null ? "null" : this.Offset.ToString())}");
        }
    }
}