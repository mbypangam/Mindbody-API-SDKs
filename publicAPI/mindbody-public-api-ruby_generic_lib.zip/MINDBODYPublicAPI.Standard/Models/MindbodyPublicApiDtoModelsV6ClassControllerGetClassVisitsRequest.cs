// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsRequest"/> class.
        /// </summary>
        /// <param name="classID">ClassID.</param>
        /// <param name="lastModifiedDate">LastModifiedDate.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsRequest(
            long? classID = null,
            DateTime? lastModifiedDate = null)
        {
            this.ClassID = classID;
            this.LastModifiedDate = lastModifiedDate;
        }

        /// <summary>
        /// The class ID.
        /// </summary>
        [JsonProperty("ClassID", NullValueHandling = NullValueHandling.Ignore)]
        public long? ClassID { get; set; }

        /// <summary>
        /// When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("LastModifiedDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? LastModifiedDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsRequest other &&
                ((this.ClassID == null && other.ClassID == null) || (this.ClassID?.Equals(other.ClassID) == true)) &&
                ((this.LastModifiedDate == null && other.LastModifiedDate == null) || (this.LastModifiedDate?.Equals(other.LastModifiedDate) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClassID = {(this.ClassID == null ? "null" : this.ClassID.ToString())}");
            toStringOutput.Add($"this.LastModifiedDate = {(this.LastModifiedDate == null ? "null" : this.LastModifiedDate.ToString())}");
        }
    }
}