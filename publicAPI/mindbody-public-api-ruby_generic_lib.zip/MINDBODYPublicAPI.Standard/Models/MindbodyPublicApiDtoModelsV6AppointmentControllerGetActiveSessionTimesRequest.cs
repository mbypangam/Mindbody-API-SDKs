// <copyright file="MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesRequest"/> class.
        /// </summary>
        /// <param name="scheduleType">ScheduleType.</param>
        /// <param name="sessionTypeIds">SessionTypeIds.</param>
        /// <param name="startTime">StartTime.</param>
        /// <param name="endTime">EndTime.</param>
        /// <param name="limit">Limit.</param>
        /// <param name="offset">Offset.</param>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesRequest(
            Models.ScheduleType1Enum? scheduleType = null,
            List<int> sessionTypeIds = null,
            DateTime? startTime = null,
            DateTime? endTime = null,
            int? limit = null,
            int? offset = null)
        {
            this.ScheduleType = scheduleType;
            this.SessionTypeIds = sessionTypeIds;
            this.StartTime = startTime;
            this.EndTime = endTime;
            this.Limit = limit;
            this.Offset = offset;
        }

        /// <summary>
        /// Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided.
        /// </summary>
        [JsonProperty("ScheduleType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.ScheduleType1Enum? ScheduleType { get; set; }

        /// <summary>
        /// Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided.
        /// </summary>
        [JsonProperty("SessionTypeIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> SessionTypeIds { get; set; }

        /// <summary>
        /// Filters results to times that start on or after this time on the current date. Any date provided is ignored.
        /// <br />Default: **00:00:00**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartTime { get; set; }

        /// <summary>
        /// Filters results to times that end on or before this time on the current date. Any date provided is ignored..
        /// <br />Default: **23:59:59**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndTime { get; set; }

        /// <summary>
        /// Number of results to include, defaults to 100
        /// </summary>
        [JsonProperty("Limit", NullValueHandling = NullValueHandling.Ignore)]
        public int? Limit { get; set; }

        /// <summary>
        /// Page offset, defaults to 0.
        /// </summary>
        [JsonProperty("Offset", NullValueHandling = NullValueHandling.Ignore)]
        public int? Offset { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesRequest other &&
                ((this.ScheduleType == null && other.ScheduleType == null) || (this.ScheduleType?.Equals(other.ScheduleType) == true)) &&
                ((this.SessionTypeIds == null && other.SessionTypeIds == null) || (this.SessionTypeIds?.Equals(other.SessionTypeIds) == true)) &&
                ((this.StartTime == null && other.StartTime == null) || (this.StartTime?.Equals(other.StartTime) == true)) &&
                ((this.EndTime == null && other.EndTime == null) || (this.EndTime?.Equals(other.EndTime) == true)) &&
                ((this.Limit == null && other.Limit == null) || (this.Limit?.Equals(other.Limit) == true)) &&
                ((this.Offset == null && other.Offset == null) || (this.Offset?.Equals(other.Offset) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ScheduleType = {(this.ScheduleType == null ? "null" : this.ScheduleType.ToString())}");
            toStringOutput.Add($"this.SessionTypeIds = {(this.SessionTypeIds == null ? "null" : $"[{string.Join(", ", this.SessionTypeIds)} ]")}");
            toStringOutput.Add($"this.StartTime = {(this.StartTime == null ? "null" : this.StartTime.ToString())}");
            toStringOutput.Add($"this.EndTime = {(this.EndTime == null ? "null" : this.EndTime.ToString())}");
            toStringOutput.Add($"this.Limit = {(this.Limit == null ? "null" : this.Limit.ToString())}");
            toStringOutput.Add($"this.Offset = {(this.Offset == null ? "null" : this.Offset.ToString())}");
        }
    }
}