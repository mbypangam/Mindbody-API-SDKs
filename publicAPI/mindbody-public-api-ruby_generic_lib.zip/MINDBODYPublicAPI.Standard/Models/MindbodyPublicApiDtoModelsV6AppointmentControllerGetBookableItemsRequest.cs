// <copyright file="MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsRequest"/> class.
        /// </summary>
        /// <param name="sessionTypeIds">SessionTypeIds.</param>
        /// <param name="locationIds">LocationIds.</param>
        /// <param name="staffIds">StaffIds.</param>
        /// <param name="startDate">StartDate.</param>
        /// <param name="endDate">EndDate.</param>
        /// <param name="appointmentId">AppointmentId.</param>
        /// <param name="ignoreDefaultSessionLength">IgnoreDefaultSessionLength.</param>
        /// <param name="limit">Limit.</param>
        /// <param name="offset">Offset.</param>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsRequest(
            List<int> sessionTypeIds,
            List<int> locationIds = null,
            List<long> staffIds = null,
            DateTime? startDate = null,
            DateTime? endDate = null,
            long? appointmentId = null,
            bool? ignoreDefaultSessionLength = null,
            int? limit = null,
            int? offset = null)
        {
            this.SessionTypeIds = sessionTypeIds;
            this.LocationIds = locationIds;
            this.StaffIds = staffIds;
            this.StartDate = startDate;
            this.EndDate = endDate;
            this.AppointmentId = appointmentId;
            this.IgnoreDefaultSessionLength = ignoreDefaultSessionLength;
            this.Limit = limit;
            this.Offset = offset;
        }

        /// <summary>
        /// A list of the requested session type IDs.
        /// </summary>
        [JsonProperty("SessionTypeIds")]
        public List<int> SessionTypeIds { get; set; }

        /// <summary>
        /// A list of the requested location IDs.
        /// </summary>
        [JsonProperty("LocationIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> LocationIds { get; set; }

        /// <summary>
        /// A list of the requested staff IDs.
        /// </summary>
        [JsonProperty("StaffIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<long> StaffIds { get; set; }

        /// <summary>
        /// The start date of the requested date range.
        /// <br />Default: **today’s date**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// The end date of the requested date range.
        /// <br />Default: **StartDate**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// If provided, filters out the appointment with this ID.
        /// </summary>
        [JsonProperty("AppointmentId", NullValueHandling = NullValueHandling.Ignore)]
        public long? AppointmentId { get; set; }

        /// <summary>
        /// When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br />
        /// When `false`, only availabilities that have the default session length return.
        /// </summary>
        [JsonProperty("IgnoreDefaultSessionLength", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IgnoreDefaultSessionLength { get; set; }

        /// <summary>
        /// Number of results to include, defaults to 100
        /// </summary>
        [JsonProperty("Limit", NullValueHandling = NullValueHandling.Ignore)]
        public int? Limit { get; set; }

        /// <summary>
        /// Page offset, defaults to 0.
        /// </summary>
        [JsonProperty("Offset", NullValueHandling = NullValueHandling.Ignore)]
        public int? Offset { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsRequest other &&
                ((this.SessionTypeIds == null && other.SessionTypeIds == null) || (this.SessionTypeIds?.Equals(other.SessionTypeIds) == true)) &&
                ((this.LocationIds == null && other.LocationIds == null) || (this.LocationIds?.Equals(other.LocationIds) == true)) &&
                ((this.StaffIds == null && other.StaffIds == null) || (this.StaffIds?.Equals(other.StaffIds) == true)) &&
                ((this.StartDate == null && other.StartDate == null) || (this.StartDate?.Equals(other.StartDate) == true)) &&
                ((this.EndDate == null && other.EndDate == null) || (this.EndDate?.Equals(other.EndDate) == true)) &&
                ((this.AppointmentId == null && other.AppointmentId == null) || (this.AppointmentId?.Equals(other.AppointmentId) == true)) &&
                ((this.IgnoreDefaultSessionLength == null && other.IgnoreDefaultSessionLength == null) || (this.IgnoreDefaultSessionLength?.Equals(other.IgnoreDefaultSessionLength) == true)) &&
                ((this.Limit == null && other.Limit == null) || (this.Limit?.Equals(other.Limit) == true)) &&
                ((this.Offset == null && other.Offset == null) || (this.Offset?.Equals(other.Offset) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SessionTypeIds = {(this.SessionTypeIds == null ? "null" : $"[{string.Join(", ", this.SessionTypeIds)} ]")}");
            toStringOutput.Add($"this.LocationIds = {(this.LocationIds == null ? "null" : $"[{string.Join(", ", this.LocationIds)} ]")}");
            toStringOutput.Add($"this.StaffIds = {(this.StaffIds == null ? "null" : $"[{string.Join(", ", this.StaffIds)} ]")}");
            toStringOutput.Add($"this.StartDate = {(this.StartDate == null ? "null" : this.StartDate.ToString())}");
            toStringOutput.Add($"this.EndDate = {(this.EndDate == null ? "null" : this.EndDate.ToString())}");
            toStringOutput.Add($"this.AppointmentId = {(this.AppointmentId == null ? "null" : this.AppointmentId.ToString())}");
            toStringOutput.Add($"this.IgnoreDefaultSessionLength = {(this.IgnoreDefaultSessionLength == null ? "null" : this.IgnoreDefaultSessionLength.ToString())}");
            toStringOutput.Add($"this.Limit = {(this.Limit == null ? "null" : this.Limit.ToString())}");
            toStringOutput.Add($"this.Offset = {(this.Offset == null ? "null" : this.Offset.ToString())}");
        }
    }
}