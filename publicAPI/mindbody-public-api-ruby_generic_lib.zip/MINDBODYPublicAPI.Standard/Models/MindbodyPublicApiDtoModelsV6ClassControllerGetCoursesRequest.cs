// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesRequest"/> class.
        /// </summary>
        /// <param name="locationIDs">LocationIDs.</param>
        /// <param name="courseIDs">CourseIDs.</param>
        /// <param name="staffIDs">StaffIDs.</param>
        /// <param name="programIDs">ProgramIDs.</param>
        /// <param name="startDate">StartDate.</param>
        /// <param name="endDate">EndDate.</param>
        /// <param name="semesterIDs">SemesterIDs.</param>
        /// <param name="limit">Limit.</param>
        /// <param name="offset">Offset.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesRequest(
            List<int> locationIDs = null,
            List<long> courseIDs = null,
            List<long> staffIDs = null,
            List<int> programIDs = null,
            DateTime? startDate = null,
            DateTime? endDate = null,
            List<int> semesterIDs = null,
            int? limit = null,
            int? offset = null)
        {
            this.LocationIDs = locationIDs;
            this.CourseIDs = courseIDs;
            this.StaffIDs = staffIDs;
            this.ProgramIDs = programIDs;
            this.StartDate = startDate;
            this.EndDate = endDate;
            this.SemesterIDs = semesterIDs;
            this.Limit = limit;
            this.Offset = offset;
        }

        /// <summary>
        /// (optional) The requested locations.
        /// </summary>
        [JsonProperty("LocationIDs", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> LocationIDs { get; set; }

        /// <summary>
        /// (optional) The requested course IDs.
        /// </summary>
        [JsonProperty("CourseIDs", NullValueHandling = NullValueHandling.Ignore)]
        public List<long> CourseIDs { get; set; }

        /// <summary>
        /// (optional) The requested StaffIDs.
        /// </summary>
        [JsonProperty("StaffIDs", NullValueHandling = NullValueHandling.Ignore)]
        public List<long> StaffIDs { get; set; }

        /// <summary>
        /// (optional) The requested program IDs.
        /// </summary>
        [JsonProperty("ProgramIDs", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ProgramIDs { get; set; }

        /// <summary>
        /// The start date range. Any active courses that are on or after this day.
        /// <br />(optional) Defaults to today.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// The end date range. Any active courses that are on or before this day.
        /// <br />(optional) Defaults to StartDate.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// (optional) The requested semester IDs.
        /// </summary>
        [JsonProperty("SemesterIDs", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> SemesterIDs { get; set; }

        /// <summary>
        /// Number of results to include, defaults to 100
        /// </summary>
        [JsonProperty("Limit", NullValueHandling = NullValueHandling.Ignore)]
        public int? Limit { get; set; }

        /// <summary>
        /// Page offset, defaults to 0.
        /// </summary>
        [JsonProperty("Offset", NullValueHandling = NullValueHandling.Ignore)]
        public int? Offset { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesRequest other &&
                ((this.LocationIDs == null && other.LocationIDs == null) || (this.LocationIDs?.Equals(other.LocationIDs) == true)) &&
                ((this.CourseIDs == null && other.CourseIDs == null) || (this.CourseIDs?.Equals(other.CourseIDs) == true)) &&
                ((this.StaffIDs == null && other.StaffIDs == null) || (this.StaffIDs?.Equals(other.StaffIDs) == true)) &&
                ((this.ProgramIDs == null && other.ProgramIDs == null) || (this.ProgramIDs?.Equals(other.ProgramIDs) == true)) &&
                ((this.StartDate == null && other.StartDate == null) || (this.StartDate?.Equals(other.StartDate) == true)) &&
                ((this.EndDate == null && other.EndDate == null) || (this.EndDate?.Equals(other.EndDate) == true)) &&
                ((this.SemesterIDs == null && other.SemesterIDs == null) || (this.SemesterIDs?.Equals(other.SemesterIDs) == true)) &&
                ((this.Limit == null && other.Limit == null) || (this.Limit?.Equals(other.Limit) == true)) &&
                ((this.Offset == null && other.Offset == null) || (this.Offset?.Equals(other.Offset) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.LocationIDs = {(this.LocationIDs == null ? "null" : $"[{string.Join(", ", this.LocationIDs)} ]")}");
            toStringOutput.Add($"this.CourseIDs = {(this.CourseIDs == null ? "null" : $"[{string.Join(", ", this.CourseIDs)} ]")}");
            toStringOutput.Add($"this.StaffIDs = {(this.StaffIDs == null ? "null" : $"[{string.Join(", ", this.StaffIDs)} ]")}");
            toStringOutput.Add($"this.ProgramIDs = {(this.ProgramIDs == null ? "null" : $"[{string.Join(", ", this.ProgramIDs)} ]")}");
            toStringOutput.Add($"this.StartDate = {(this.StartDate == null ? "null" : this.StartDate.ToString())}");
            toStringOutput.Add($"this.EndDate = {(this.EndDate == null ? "null" : this.EndDate.ToString())}");
            toStringOutput.Add($"this.SemesterIDs = {(this.SemesterIDs == null ? "null" : $"[{string.Join(", ", this.SemesterIDs)} ]")}");
            toStringOutput.Add($"this.Limit = {(this.Limit == null ? "null" : this.Limit.ToString())}");
            toStringOutput.Add($"this.Offset = {(this.Offset == null ? "null" : this.Offset.ToString())}");
        }
    }
}