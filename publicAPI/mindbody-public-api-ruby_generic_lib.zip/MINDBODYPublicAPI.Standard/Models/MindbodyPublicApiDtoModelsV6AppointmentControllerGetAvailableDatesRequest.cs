// <copyright file="MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesRequest"/> class.
        /// </summary>
        /// <param name="sessionTypeId">SessionTypeId.</param>
        /// <param name="locationId">LocationId.</param>
        /// <param name="staffId">StaffId.</param>
        /// <param name="startDate">StartDate.</param>
        /// <param name="endDate">EndDate.</param>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesRequest(
            int sessionTypeId,
            int? locationId = null,
            long? staffId = null,
            DateTime? startDate = null,
            DateTime? endDate = null)
        {
            this.SessionTypeId = sessionTypeId;
            this.LocationId = locationId;
            this.StaffId = staffId;
            this.StartDate = startDate;
            this.EndDate = endDate;
        }

        /// <summary>
        /// required requested session type ID.
        /// </summary>
        [JsonProperty("SessionTypeId")]
        public int SessionTypeId { get; set; }

        /// <summary>
        /// optional requested location ID.
        /// </summary>
        [JsonProperty("LocationId", NullValueHandling = NullValueHandling.Ignore)]
        public int? LocationId { get; set; }

        /// <summary>
        /// optional requested staff ID.
        /// </summary>
        [JsonProperty("StaffId", NullValueHandling = NullValueHandling.Ignore)]
        public long? StaffId { get; set; }

        /// <summary>
        /// The start date of the requested date range.
        /// <br />Default: **today’s date**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// The end date of the requested date range.
        /// <br />Default: **StartDate**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesRequest other &&
                this.SessionTypeId.Equals(other.SessionTypeId) &&
                ((this.LocationId == null && other.LocationId == null) || (this.LocationId?.Equals(other.LocationId) == true)) &&
                ((this.StaffId == null && other.StaffId == null) || (this.StaffId?.Equals(other.StaffId) == true)) &&
                ((this.StartDate == null && other.StartDate == null) || (this.StartDate?.Equals(other.StartDate) == true)) &&
                ((this.EndDate == null && other.EndDate == null) || (this.EndDate?.Equals(other.EndDate) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SessionTypeId = {this.SessionTypeId}");
            toStringOutput.Add($"this.LocationId = {(this.LocationId == null ? "null" : this.LocationId.ToString())}");
            toStringOutput.Add($"this.StaffId = {(this.StaffId == null ? "null" : this.StaffId.ToString())}");
            toStringOutput.Add($"this.StartDate = {(this.StartDate == null ? "null" : this.StartDate.ToString())}");
            toStringOutput.Add($"this.EndDate = {(this.EndDate == null ? "null" : this.EndDate.ToString())}");
        }
    }
}