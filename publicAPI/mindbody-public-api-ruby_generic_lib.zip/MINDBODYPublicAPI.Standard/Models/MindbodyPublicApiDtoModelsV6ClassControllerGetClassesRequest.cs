// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerGetClassesRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerGetClassesRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerGetClassesRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetClassesRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetClassesRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetClassesRequest"/> class.
        /// </summary>
        /// <param name="classDescriptionIds">ClassDescriptionIds.</param>
        /// <param name="classIds">ClassIds.</param>
        /// <param name="classScheduleIds">ClassScheduleIds.</param>
        /// <param name="staffIds">StaffIds.</param>
        /// <param name="startDateTime">StartDateTime.</param>
        /// <param name="endDateTime">EndDateTime.</param>
        /// <param name="clientId">ClientId.</param>
        /// <param name="programIds">ProgramIds.</param>
        /// <param name="sessionTypeIds">SessionTypeIds.</param>
        /// <param name="locationIds">LocationIds.</param>
        /// <param name="semesterIds">SemesterIds.</param>
        /// <param name="hideCanceledClasses">HideCanceledClasses.</param>
        /// <param name="schedulingWindow">SchedulingWindow.</param>
        /// <param name="lastModifiedDate">LastModifiedDate.</param>
        /// <param name="limit">Limit.</param>
        /// <param name="offset">Offset.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetClassesRequest(
            List<int> classDescriptionIds = null,
            List<int> classIds = null,
            List<int> classScheduleIds = null,
            List<long> staffIds = null,
            DateTime? startDateTime = null,
            DateTime? endDateTime = null,
            string clientId = null,
            List<int> programIds = null,
            List<int> sessionTypeIds = null,
            List<int> locationIds = null,
            List<int> semesterIds = null,
            bool? hideCanceledClasses = null,
            bool? schedulingWindow = null,
            DateTime? lastModifiedDate = null,
            int? limit = null,
            int? offset = null)
        {
            this.ClassDescriptionIds = classDescriptionIds;
            this.ClassIds = classIds;
            this.ClassScheduleIds = classScheduleIds;
            this.StaffIds = staffIds;
            this.StartDateTime = startDateTime;
            this.EndDateTime = endDateTime;
            this.ClientId = clientId;
            this.ProgramIds = programIds;
            this.SessionTypeIds = sessionTypeIds;
            this.LocationIds = locationIds;
            this.SemesterIds = semesterIds;
            this.HideCanceledClasses = hideCanceledClasses;
            this.SchedulingWindow = schedulingWindow;
            this.LastModifiedDate = lastModifiedDate;
            this.Limit = limit;
            this.Offset = offset;
        }

        /// <summary>
        /// The requested class description IDs.
        /// </summary>
        [JsonProperty("ClassDescriptionIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ClassDescriptionIds { get; set; }

        /// <summary>
        /// The requested class IDs.
        /// </summary>
        [JsonProperty("ClassIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ClassIds { get; set; }

        /// <summary>
        /// The requested classScheduleIds.
        /// </summary>
        [JsonProperty("ClassScheduleIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ClassScheduleIds { get; set; }

        /// <summary>
        /// The requested IDs of the teaching staff members.
        /// </summary>
        [JsonProperty("StaffIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<long> StaffIds { get; set; }

        /// <summary>
        /// The requested start date for filtering.
        /// <br />Default: **today’s date**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDateTime { get; set; }

        /// <summary>
        /// The requested end date for filtering.
        /// <br />Default: **today’s date**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDateTime { get; set; }

        /// <summary>
        /// The client ID of the client who is viewing this class list. Based on identity, the client may be able to see additional information, such as membership specials.
        /// </summary>
        [JsonProperty("ClientId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientId { get; set; }

        /// <summary>
        /// A list of program IDs on which to base the search.
        /// </summary>
        [JsonProperty("ProgramIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ProgramIds { get; set; }

        /// <summary>
        /// A list of session type IDs on which to base the search.
        /// </summary>
        [JsonProperty("SessionTypeIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> SessionTypeIds { get; set; }

        /// <summary>
        /// A list of location IDs on which to base the search.
        /// </summary>
        [JsonProperty("LocationIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> LocationIds { get; set; }

        /// <summary>
        /// A list of semester IDs on which to base the search.
        /// </summary>
        [JsonProperty("SemesterIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> SemesterIds { get; set; }

        /// <summary>
        /// When `true`, canceled classes are removed from the response.<br />
        /// When `false`, canceled classes are included in the response.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("HideCanceledClasses", NullValueHandling = NullValueHandling.Ignore)]
        public bool? HideCanceledClasses { get; set; }

        /// <summary>
        /// When `true`, classes outside scheduling window are removed from the response.<br />
        /// When `false`, classes are included in the response, regardless of the scheduling window.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("SchedulingWindow", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SchedulingWindow { get; set; }

        /// <summary>
        /// When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("LastModifiedDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? LastModifiedDate { get; set; }

        /// <summary>
        /// Number of results to include, defaults to 100
        /// </summary>
        [JsonProperty("Limit", NullValueHandling = NullValueHandling.Ignore)]
        public int? Limit { get; set; }

        /// <summary>
        /// Page offset, defaults to 0.
        /// </summary>
        [JsonProperty("Offset", NullValueHandling = NullValueHandling.Ignore)]
        public int? Offset { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerGetClassesRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerGetClassesRequest other &&
                ((this.ClassDescriptionIds == null && other.ClassDescriptionIds == null) || (this.ClassDescriptionIds?.Equals(other.ClassDescriptionIds) == true)) &&
                ((this.ClassIds == null && other.ClassIds == null) || (this.ClassIds?.Equals(other.ClassIds) == true)) &&
                ((this.ClassScheduleIds == null && other.ClassScheduleIds == null) || (this.ClassScheduleIds?.Equals(other.ClassScheduleIds) == true)) &&
                ((this.StaffIds == null && other.StaffIds == null) || (this.StaffIds?.Equals(other.StaffIds) == true)) &&
                ((this.StartDateTime == null && other.StartDateTime == null) || (this.StartDateTime?.Equals(other.StartDateTime) == true)) &&
                ((this.EndDateTime == null && other.EndDateTime == null) || (this.EndDateTime?.Equals(other.EndDateTime) == true)) &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.ProgramIds == null && other.ProgramIds == null) || (this.ProgramIds?.Equals(other.ProgramIds) == true)) &&
                ((this.SessionTypeIds == null && other.SessionTypeIds == null) || (this.SessionTypeIds?.Equals(other.SessionTypeIds) == true)) &&
                ((this.LocationIds == null && other.LocationIds == null) || (this.LocationIds?.Equals(other.LocationIds) == true)) &&
                ((this.SemesterIds == null && other.SemesterIds == null) || (this.SemesterIds?.Equals(other.SemesterIds) == true)) &&
                ((this.HideCanceledClasses == null && other.HideCanceledClasses == null) || (this.HideCanceledClasses?.Equals(other.HideCanceledClasses) == true)) &&
                ((this.SchedulingWindow == null && other.SchedulingWindow == null) || (this.SchedulingWindow?.Equals(other.SchedulingWindow) == true)) &&
                ((this.LastModifiedDate == null && other.LastModifiedDate == null) || (this.LastModifiedDate?.Equals(other.LastModifiedDate) == true)) &&
                ((this.Limit == null && other.Limit == null) || (this.Limit?.Equals(other.Limit) == true)) &&
                ((this.Offset == null && other.Offset == null) || (this.Offset?.Equals(other.Offset) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClassDescriptionIds = {(this.ClassDescriptionIds == null ? "null" : $"[{string.Join(", ", this.ClassDescriptionIds)} ]")}");
            toStringOutput.Add($"this.ClassIds = {(this.ClassIds == null ? "null" : $"[{string.Join(", ", this.ClassIds)} ]")}");
            toStringOutput.Add($"this.ClassScheduleIds = {(this.ClassScheduleIds == null ? "null" : $"[{string.Join(", ", this.ClassScheduleIds)} ]")}");
            toStringOutput.Add($"this.StaffIds = {(this.StaffIds == null ? "null" : $"[{string.Join(", ", this.StaffIds)} ]")}");
            toStringOutput.Add($"this.StartDateTime = {(this.StartDateTime == null ? "null" : this.StartDateTime.ToString())}");
            toStringOutput.Add($"this.EndDateTime = {(this.EndDateTime == null ? "null" : this.EndDateTime.ToString())}");
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.ProgramIds = {(this.ProgramIds == null ? "null" : $"[{string.Join(", ", this.ProgramIds)} ]")}");
            toStringOutput.Add($"this.SessionTypeIds = {(this.SessionTypeIds == null ? "null" : $"[{string.Join(", ", this.SessionTypeIds)} ]")}");
            toStringOutput.Add($"this.LocationIds = {(this.LocationIds == null ? "null" : $"[{string.Join(", ", this.LocationIds)} ]")}");
            toStringOutput.Add($"this.SemesterIds = {(this.SemesterIds == null ? "null" : $"[{string.Join(", ", this.SemesterIds)} ]")}");
            toStringOutput.Add($"this.HideCanceledClasses = {(this.HideCanceledClasses == null ? "null" : this.HideCanceledClasses.ToString())}");
            toStringOutput.Add($"this.SchedulingWindow = {(this.SchedulingWindow == null ? "null" : this.SchedulingWindow.ToString())}");
            toStringOutput.Add($"this.LastModifiedDate = {(this.LastModifiedDate == null ? "null" : this.LastModifiedDate.ToString())}");
            toStringOutput.Add($"this.Limit = {(this.Limit == null ? "null" : this.Limit.ToString())}");
            toStringOutput.Add($"this.Offset = {(this.Offset == null ? "null" : this.Offset.ToString())}");
        }
    }
}