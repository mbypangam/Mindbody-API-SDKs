// <copyright file="MindbodyPublicApiDtoModelsV6AppointmentControllerDeleteAvailabilityRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6AppointmentControllerDeleteAvailabilityRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6AppointmentControllerDeleteAvailabilityRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerDeleteAvailabilityRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerDeleteAvailabilityRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerDeleteAvailabilityRequest"/> class.
        /// </summary>
        /// <param name="availabilityId">AvailabilityId.</param>
        /// <param name="test">Test.</param>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerDeleteAvailabilityRequest(
            int? availabilityId = null,
            bool? test = null)
        {
            this.AvailabilityId = availabilityId;
            this.Test = test;
        }

        /// <summary>
        /// Availability Id to be deleted
        /// </summary>
        [JsonProperty("AvailabilityId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AvailabilityId { get; set; }

        /// <summary>
        /// The test flag
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6AppointmentControllerDeleteAvailabilityRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6AppointmentControllerDeleteAvailabilityRequest other &&
                ((this.AvailabilityId == null && other.AvailabilityId == null) || (this.AvailabilityId?.Equals(other.AvailabilityId) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AvailabilityId = {(this.AvailabilityId == null ? "null" : this.AvailabilityId.ToString())}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
        }
    }
}