// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsRequest"/> class.
        /// </summary>
        /// <param name="classScheduleIds">ClassScheduleIds.</param>
        /// <param name="endDate">EndDate.</param>
        /// <param name="locationIds">LocationIds.</param>
        /// <param name="programIds">ProgramIds.</param>
        /// <param name="sessionTypeIds">SessionTypeIds.</param>
        /// <param name="staffIds">StaffIds.</param>
        /// <param name="startDate">StartDate.</param>
        /// <param name="limit">Limit.</param>
        /// <param name="offset">Offset.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsRequest(
            List<int> classScheduleIds = null,
            DateTime? endDate = null,
            List<int> locationIds = null,
            List<int> programIds = null,
            List<int> sessionTypeIds = null,
            List<long> staffIds = null,
            DateTime? startDate = null,
            int? limit = null,
            int? offset = null)
        {
            this.ClassScheduleIds = classScheduleIds;
            this.EndDate = endDate;
            this.LocationIds = locationIds;
            this.ProgramIds = programIds;
            this.SessionTypeIds = sessionTypeIds;
            this.StaffIds = staffIds;
            this.StartDate = startDate;
            this.Limit = limit;
            this.Offset = offset;
        }

        /// <summary>
        /// A list of the requested class schedule IDs. If omitted, all class schedule IDs return.
        /// </summary>
        [JsonProperty("ClassScheduleIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ClassScheduleIds { get; set; }

        /// <summary>
        /// The end of the date range. The response returns any active enrollments that occur on or before this day.<br />
        /// Default: **StartDate**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// List of the IDs for the requested locations. If omitted, all location IDs return.
        /// </summary>
        [JsonProperty("LocationIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> LocationIds { get; set; }

        /// <summary>
        /// List of the IDs for the requested programs. If omitted, all program IDs return.
        /// </summary>
        [JsonProperty("ProgramIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ProgramIds { get; set; }

        /// <summary>
        /// List of the IDs for the requested session types. If omitted, all session types IDs return.
        /// </summary>
        [JsonProperty("SessionTypeIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> SessionTypeIds { get; set; }

        /// <summary>
        /// List of the IDs for the requested staff IDs. If omitted, all staff IDs return.
        /// </summary>
        [JsonProperty("StaffIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<long> StaffIds { get; set; }

        /// <summary>
        /// The start of the date range. The response returns any active enrollments that occur on or after this day.<br />
        /// Default: **today’s date**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// Number of results to include, defaults to 100
        /// </summary>
        [JsonProperty("Limit", NullValueHandling = NullValueHandling.Ignore)]
        public int? Limit { get; set; }

        /// <summary>
        /// Page offset, defaults to 0.
        /// </summary>
        [JsonProperty("Offset", NullValueHandling = NullValueHandling.Ignore)]
        public int? Offset { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsRequest other &&
                ((this.ClassScheduleIds == null && other.ClassScheduleIds == null) || (this.ClassScheduleIds?.Equals(other.ClassScheduleIds) == true)) &&
                ((this.EndDate == null && other.EndDate == null) || (this.EndDate?.Equals(other.EndDate) == true)) &&
                ((this.LocationIds == null && other.LocationIds == null) || (this.LocationIds?.Equals(other.LocationIds) == true)) &&
                ((this.ProgramIds == null && other.ProgramIds == null) || (this.ProgramIds?.Equals(other.ProgramIds) == true)) &&
                ((this.SessionTypeIds == null && other.SessionTypeIds == null) || (this.SessionTypeIds?.Equals(other.SessionTypeIds) == true)) &&
                ((this.StaffIds == null && other.StaffIds == null) || (this.StaffIds?.Equals(other.StaffIds) == true)) &&
                ((this.StartDate == null && other.StartDate == null) || (this.StartDate?.Equals(other.StartDate) == true)) &&
                ((this.Limit == null && other.Limit == null) || (this.Limit?.Equals(other.Limit) == true)) &&
                ((this.Offset == null && other.Offset == null) || (this.Offset?.Equals(other.Offset) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClassScheduleIds = {(this.ClassScheduleIds == null ? "null" : $"[{string.Join(", ", this.ClassScheduleIds)} ]")}");
            toStringOutput.Add($"this.EndDate = {(this.EndDate == null ? "null" : this.EndDate.ToString())}");
            toStringOutput.Add($"this.LocationIds = {(this.LocationIds == null ? "null" : $"[{string.Join(", ", this.LocationIds)} ]")}");
            toStringOutput.Add($"this.ProgramIds = {(this.ProgramIds == null ? "null" : $"[{string.Join(", ", this.ProgramIds)} ]")}");
            toStringOutput.Add($"this.SessionTypeIds = {(this.SessionTypeIds == null ? "null" : $"[{string.Join(", ", this.SessionTypeIds)} ]")}");
            toStringOutput.Add($"this.StaffIds = {(this.StaffIds == null ? "null" : $"[{string.Join(", ", this.StaffIds)} ]")}");
            toStringOutput.Add($"this.StartDate = {(this.StartDate == null ? "null" : this.StartDate.ToString())}");
            toStringOutput.Add($"this.Limit = {(this.Limit == null ? "null" : this.Limit.ToString())}");
            toStringOutput.Add($"this.Offset = {(this.Offset == null ? "null" : this.Offset.ToString())}");
        }
    }
}