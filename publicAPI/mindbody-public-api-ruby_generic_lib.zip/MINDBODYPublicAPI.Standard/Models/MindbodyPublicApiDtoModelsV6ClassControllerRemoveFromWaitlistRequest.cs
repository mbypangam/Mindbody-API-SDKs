// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerRemoveFromWaitlistRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerRemoveFromWaitlistRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerRemoveFromWaitlistRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerRemoveFromWaitlistRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerRemoveFromWaitlistRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerRemoveFromWaitlistRequest"/> class.
        /// </summary>
        /// <param name="waitlistEntryIds">WaitlistEntryIds.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerRemoveFromWaitlistRequest(
            List<int> waitlistEntryIds)
        {
            this.WaitlistEntryIds = waitlistEntryIds;
        }

        /// <summary>
        /// A list of waiting list IDs to remove from waiting lists.
        /// </summary>
        [JsonProperty("WaitlistEntryIds")]
        public List<int> WaitlistEntryIds { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerRemoveFromWaitlistRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerRemoveFromWaitlistRequest other &&
                ((this.WaitlistEntryIds == null && other.WaitlistEntryIds == null) || (this.WaitlistEntryIds?.Equals(other.WaitlistEntryIds) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.WaitlistEntryIds = {(this.WaitlistEntryIds == null ? "null" : $"[{string.Join(", ", this.WaitlistEntryIds)} ]")}");
        }
    }
}