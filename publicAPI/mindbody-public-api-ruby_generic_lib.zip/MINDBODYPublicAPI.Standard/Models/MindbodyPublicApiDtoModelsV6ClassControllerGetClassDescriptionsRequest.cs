// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsRequest"/> class.
        /// </summary>
        /// <param name="classDescriptionId">ClassDescriptionId.</param>
        /// <param name="programIds">ProgramIds.</param>
        /// <param name="startClassDateTime">StartClassDateTime.</param>
        /// <param name="endClassDateTime">EndClassDateTime.</param>
        /// <param name="staffId">StaffId.</param>
        /// <param name="locationId">LocationId.</param>
        /// <param name="limit">Limit.</param>
        /// <param name="offset">Offset.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsRequest(
            int? classDescriptionId = null,
            List<int> programIds = null,
            DateTime? startClassDateTime = null,
            DateTime? endClassDateTime = null,
            long? staffId = null,
            int? locationId = null,
            int? limit = null,
            int? offset = null)
        {
            this.ClassDescriptionId = classDescriptionId;
            this.ProgramIds = programIds;
            this.StartClassDateTime = startClassDateTime;
            this.EndClassDateTime = endClassDateTime;
            this.StaffId = staffId;
            this.LocationId = locationId;
            this.Limit = limit;
            this.Offset = offset;
        }

        /// <summary>
        /// Filters to the single result with the given ID.
        /// </summary>
        [JsonProperty("ClassDescriptionId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ClassDescriptionId { get; set; }

        /// <summary>
        /// Filters results to class descriptions belonging to the given programs.
        /// </summary>
        [JsonProperty("ProgramIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ProgramIds { get; set; }

        /// <summary>
        /// Filters the results to class descriptions for scheduled classes that happen on or after the given date and time.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartClassDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartClassDateTime { get; set; }

        /// <summary>
        /// Filters the results to class descriptions for scheduled classes that happen before the given date and time.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndClassDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndClassDateTime { get; set; }

        /// <summary>
        /// Filters results to class descriptions for scheduled classes taught by the given staff member.
        /// </summary>
        [JsonProperty("StaffId", NullValueHandling = NullValueHandling.Ignore)]
        public long? StaffId { get; set; }

        /// <summary>
        /// Filters results to classes descriptions for schedule classes as the given location.
        /// </summary>
        [JsonProperty("LocationId", NullValueHandling = NullValueHandling.Ignore)]
        public int? LocationId { get; set; }

        /// <summary>
        /// Number of results to include, defaults to 100
        /// </summary>
        [JsonProperty("Limit", NullValueHandling = NullValueHandling.Ignore)]
        public int? Limit { get; set; }

        /// <summary>
        /// Page offset, defaults to 0.
        /// </summary>
        [JsonProperty("Offset", NullValueHandling = NullValueHandling.Ignore)]
        public int? Offset { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsRequest other &&
                ((this.ClassDescriptionId == null && other.ClassDescriptionId == null) || (this.ClassDescriptionId?.Equals(other.ClassDescriptionId) == true)) &&
                ((this.ProgramIds == null && other.ProgramIds == null) || (this.ProgramIds?.Equals(other.ProgramIds) == true)) &&
                ((this.StartClassDateTime == null && other.StartClassDateTime == null) || (this.StartClassDateTime?.Equals(other.StartClassDateTime) == true)) &&
                ((this.EndClassDateTime == null && other.EndClassDateTime == null) || (this.EndClassDateTime?.Equals(other.EndClassDateTime) == true)) &&
                ((this.StaffId == null && other.StaffId == null) || (this.StaffId?.Equals(other.StaffId) == true)) &&
                ((this.LocationId == null && other.LocationId == null) || (this.LocationId?.Equals(other.LocationId) == true)) &&
                ((this.Limit == null && other.Limit == null) || (this.Limit?.Equals(other.Limit) == true)) &&
                ((this.Offset == null && other.Offset == null) || (this.Offset?.Equals(other.Offset) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClassDescriptionId = {(this.ClassDescriptionId == null ? "null" : this.ClassDescriptionId.ToString())}");
            toStringOutput.Add($"this.ProgramIds = {(this.ProgramIds == null ? "null" : $"[{string.Join(", ", this.ProgramIds)} ]")}");
            toStringOutput.Add($"this.StartClassDateTime = {(this.StartClassDateTime == null ? "null" : this.StartClassDateTime.ToString())}");
            toStringOutput.Add($"this.EndClassDateTime = {(this.EndClassDateTime == null ? "null" : this.EndClassDateTime.ToString())}");
            toStringOutput.Add($"this.StaffId = {(this.StaffId == null ? "null" : this.StaffId.ToString())}");
            toStringOutput.Add($"this.LocationId = {(this.LocationId == null ? "null" : this.LocationId.ToString())}");
            toStringOutput.Add($"this.Limit = {(this.Limit == null ? "null" : this.Limit.ToString())}");
            toStringOutput.Add($"this.Offset = {(this.Offset == null ? "null" : this.Offset.ToString())}");
        }
    }
}