// <copyright file="SaleController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Http.Request;
    using MINDBODYPublicAPI.Standard.Http.Request.Configuration;
    using MINDBODYPublicAPI.Standard.Http.Response;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// SaleController.
    /// </summary>
    public class SaleController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SaleController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal SaleController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Get retail products available for purchase at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestCategoryIds">Optional parameter: A list of category IDs to filter by..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: The location ID to use to determine the tax for the products that this request returns.<br />  Default: **online store**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProductIds">Optional parameter: An ID filter for products..</param>
        /// <param name="requestSearchText">Optional parameter: A search filter, used for searching by term..</param>
        /// <param name="requestSellOnline">Optional parameter: When `true`, only products that can be sold online are returned.<br />  When `false`, all products are returned.<br />  Default: **false**.</param>
        /// <param name="requestSubCategoryIds">Optional parameter: A list of subcategory IDs to filter by..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse SaleGetProducts(
                string siteId,
                string version,
                string authorization = null,
                List<int> requestCategoryIds = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<string> requestProductIds = null,
                string requestSearchText = null,
                bool? requestSellOnline = null,
                List<int> requestSubCategoryIds = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse> t = this.SaleGetProductsAsync(siteId, version, authorization, requestCategoryIds, requestLimit, requestLocationId, requestOffset, requestProductIds, requestSearchText, requestSellOnline, requestSubCategoryIds);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get retail products available for purchase at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestCategoryIds">Optional parameter: A list of category IDs to filter by..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: The location ID to use to determine the tax for the products that this request returns.<br />  Default: **online store**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProductIds">Optional parameter: An ID filter for products..</param>
        /// <param name="requestSearchText">Optional parameter: A search filter, used for searching by term..</param>
        /// <param name="requestSellOnline">Optional parameter: When `true`, only products that can be sold online are returned.<br />  When `false`, all products are returned.<br />  Default: **false**.</param>
        /// <param name="requestSubCategoryIds">Optional parameter: A list of subcategory IDs to filter by..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse> SaleGetProductsAsync(
                string siteId,
                string version,
                string authorization = null,
                List<int> requestCategoryIds = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<string> requestProductIds = null,
                string requestSearchText = null,
                bool? requestSellOnline = null,
                List<int> requestSubCategoryIds = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/products");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.categoryIds", requestCategoryIds },
                { "request.limit", requestLimit },
                { "request.locationId", requestLocationId },
                { "request.offset", requestOffset },
                { "request.productIds", requestProductIds },
                { "request.searchText", requestSearchText },
                { "request.sellOnline", requestSellOnline },
                { "request.subCategoryIds", requestSubCategoryIds },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse>(response.Body);
        }

        /// <summary>
        /// Get sales completed at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndSaleDateTime">Optional parameter: Filters results to sales that happened before this date and time..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestPaymentMethodId">Optional parameter: Filters results to sales paid for by the given payment method ID..</param>
        /// <param name="requestSaleId">Optional parameter: Filters results to the requested sale ID..</param>
        /// <param name="requestStartSaleDateTime">Optional parameter: Filters results to sales that happened after this date and time..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse SaleGetSales(
                string siteId,
                string version,
                string authorization = null,
                DateTime? requestEndSaleDateTime = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestPaymentMethodId = null,
                long? requestSaleId = null,
                DateTime? requestStartSaleDateTime = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse> t = this.SaleGetSalesAsync(siteId, version, authorization, requestEndSaleDateTime, requestLimit, requestOffset, requestPaymentMethodId, requestSaleId, requestStartSaleDateTime);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get sales completed at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndSaleDateTime">Optional parameter: Filters results to sales that happened before this date and time..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestPaymentMethodId">Optional parameter: Filters results to sales paid for by the given payment method ID..</param>
        /// <param name="requestSaleId">Optional parameter: Filters results to the requested sale ID..</param>
        /// <param name="requestStartSaleDateTime">Optional parameter: Filters results to sales that happened after this date and time..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse> SaleGetSalesAsync(
                string siteId,
                string version,
                string authorization = null,
                DateTime? requestEndSaleDateTime = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestPaymentMethodId = null,
                long? requestSaleId = null,
                DateTime? requestStartSaleDateTime = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/sales");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.endSaleDateTime", requestEndSaleDateTime.HasValue ? requestEndSaleDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.paymentMethodId", requestPaymentMethodId },
                { "request.saleId", requestSaleId },
                { "request.startSaleDateTime", requestStartSaleDateTime.HasValue ? requestStartSaleDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse>(response.Body);
        }

        /// <summary>
        /// Retunn sale.
        /// </summary>
        /// <param name="returnSaleRequest">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleResponse SaleReturnSale(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleRequest returnSaleRequest,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleResponse> t = this.SaleReturnSaleAsync(returnSaleRequest, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Retunn sale.
        /// </summary>
        /// <param name="returnSaleRequest">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleResponse> SaleReturnSaleAsync(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleRequest returnSaleRequest,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/returnsale");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(returnSaleRequest);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleResponse>(response.Body);
        }

        /// <summary>
        /// Allows a client to sign up for a contract or autopay using the information returned from the `GET Contracts` endpoint. The client can pay with a new credit card or with a stored credit card. The client must exist at the site specified before this call is made.
        /// This endpoint allows a developer to specify whether a client pays now or pays on the `StartDate`.If you are building a client-facing experience, you should talk with the business owner to understand the owner’s policies before you give clients a choice of the two payment types.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractResponse SalePurchaseContract(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractResponse> t = this.SalePurchaseContractAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Allows a client to sign up for a contract or autopay using the information returned from the `GET Contracts` endpoint. The client can pay with a new credit card or with a stored credit card. The client must exist at the site specified before this call is made.
        /// This endpoint allows a developer to specify whether a client pays now or pays on the `StartDate`.If you are building a client-facing experience, you should talk with the business owner to understand the owner’s policies before you give clients a choice of the two payment types.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractResponse> SalePurchaseContractAsync(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/purchasecontract");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint provides a wide range of functionality. For example, you can use it when a client purchases new pricing options, retail products, packages, and tips. You can also combine purchasing a new pricing option and many other functions, such as booking a client into a class, booking a new appointment for a client, enrolling a client into an enrollment or course, or reconciling an unpaid, already booked appointment or class. Use this call when a client purchases:.
        /// * a pricing option, after calling `GET Services` and choosing a specific pricing option’s ID.
        /// * a retail product, after calling `GET Products` and choosing a specific retail product’s ID.
        /// * a package, after calling `GET Packages` and choosing a specific package’s ID.
        /// * a tip to give to a staff member, after calling `GET Staff` and choosing a specific staff member ID, and the amount that the client wants to tip.
        /// The documentation provides explanations of the request body and response, as well as the cart item metadata, payment item metadata, and purchased cart items.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object SaleCheckoutShoppingCart(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutShoppingCartRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<object> t = this.SaleCheckoutShoppingCartAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint provides a wide range of functionality. For example, you can use it when a client purchases new pricing options, retail products, packages, and tips. You can also combine purchasing a new pricing option and many other functions, such as booking a client into a class, booking a new appointment for a client, enrolling a client into an enrollment or course, or reconciling an unpaid, already booked appointment or class. Use this call when a client purchases:.
        /// * a pricing option, after calling `GET Services` and choosing a specific pricing option’s ID.
        /// * a retail product, after calling `GET Products` and choosing a specific retail product’s ID.
        /// * a package, after calling `GET Packages` and choosing a specific package’s ID.
        /// * a tip to give to a staff member, after calling `GET Staff` and choosing a specific staff member ID, and the amount that the client wants to tip.
        /// The documentation provides explanations of the request body and response, as well as the cart item metadata, payment item metadata, and purchased cart items.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> SaleCheckoutShoppingCartAsync(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutShoppingCartRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/checkoutshoppingcart");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return response.Body;
        }

        /// <summary>
        /// Get gift cards available for purchase at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestIds">Optional parameter: Filters the results to the requested gift card IDs.<br />  Default: **all** gift cards..</param>
        /// <param name="requestIncludeCustomLayouts">Optional parameter: When `true`, includes custom gift card layouts.<br />  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: When included, returns gift cards that are sold at the provided location ID..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSoldOnline">Optional parameter: When `true`, only returns gift cards that are sold online.<br />  Default: **false**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardResponse SaleGetGiftCards(
                string siteId,
                string version,
                string authorization = null,
                List<int> requestIds = null,
                bool? requestIncludeCustomLayouts = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                bool? requestSoldOnline = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardResponse> t = this.SaleGetGiftCardsAsync(siteId, version, authorization, requestIds, requestIncludeCustomLayouts, requestLimit, requestLocationId, requestOffset, requestSoldOnline);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get gift cards available for purchase at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestIds">Optional parameter: Filters the results to the requested gift card IDs.<br />  Default: **all** gift cards..</param>
        /// <param name="requestIncludeCustomLayouts">Optional parameter: When `true`, includes custom gift card layouts.<br />  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: When included, returns gift cards that are sold at the provided location ID..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSoldOnline">Optional parameter: When `true`, only returns gift cards that are sold online.<br />  Default: **false**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardResponse> SaleGetGiftCardsAsync(
                string siteId,
                string version,
                string authorization = null,
                List<int> requestIds = null,
                bool? requestIncludeCustomLayouts = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                bool? requestSoldOnline = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/giftcards");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.ids", requestIds },
                { "request.includeCustomLayouts", requestIncludeCustomLayouts },
                { "request.limit", requestLimit },
                { "request.locationId", requestLocationId },
                { "request.offset", requestOffset },
                { "request.soldOnline", requestSoldOnline },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardResponse>(response.Body);
        }

        /// <summary>
        /// Get pricing options available for purchase at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassId">Optional parameter: Filters to the pricing options for the specified class ID..</param>
        /// <param name="requestClassScheduleId">Optional parameter: Filters to the pricing options for the specified class schedule ID..</param>
        /// <param name="requestHideRelatedPrograms">Optional parameter: When `true`, indicates that pricing options of related programs are omitted from the response.<br />  Default: **false**.</param>
        /// <param name="requestIncludeDiscontinued">Optional parameter: When `true`, indicates that the filtered pricing option list includes discontinued pricing options.<br />  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: When specified, for each returned pricing option, `TaxRate` and `TaxIncluded` are calculated according to the specified location. Note that this does not filter results to only services provided at the given location, and for locations where Value-Added Tax (VAT) rules apply, the `TaxRate` is set to zero..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filters to pricing options with the specified program IDs..</param>
        /// <param name="requestSellOnline">Optional parameter: When `true`, filters to the pricing options that can be sold online.<br />  Default: **false**.</param>
        /// <param name="requestServiceIds">Optional parameter: Filters to the pricing options with the specified IDs. In this context, service and pricing option are used interchangeably..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: Filters to the pricing options with the specified session types IDs..</param>
        /// <param name="requestStaffId">Optional parameter: Sets `Price` and `OnlinePrice` to the particular pricing of a specific staff member, if allowed by the business..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse SaleGetServices(
                string siteId,
                string version,
                string authorization = null,
                int? requestClassId = null,
                int? requestClassScheduleId = null,
                bool? requestHideRelatedPrograms = null,
                bool? requestIncludeDiscontinued = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                bool? requestSellOnline = null,
                List<string> requestServiceIds = null,
                List<int> requestSessionTypeIds = null,
                long? requestStaffId = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse> t = this.SaleGetServicesAsync(siteId, version, authorization, requestClassId, requestClassScheduleId, requestHideRelatedPrograms, requestIncludeDiscontinued, requestLimit, requestLocationId, requestOffset, requestProgramIds, requestSellOnline, requestServiceIds, requestSessionTypeIds, requestStaffId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get pricing options available for purchase at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassId">Optional parameter: Filters to the pricing options for the specified class ID..</param>
        /// <param name="requestClassScheduleId">Optional parameter: Filters to the pricing options for the specified class schedule ID..</param>
        /// <param name="requestHideRelatedPrograms">Optional parameter: When `true`, indicates that pricing options of related programs are omitted from the response.<br />  Default: **false**.</param>
        /// <param name="requestIncludeDiscontinued">Optional parameter: When `true`, indicates that the filtered pricing option list includes discontinued pricing options.<br />  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: When specified, for each returned pricing option, `TaxRate` and `TaxIncluded` are calculated according to the specified location. Note that this does not filter results to only services provided at the given location, and for locations where Value-Added Tax (VAT) rules apply, the `TaxRate` is set to zero..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filters to pricing options with the specified program IDs..</param>
        /// <param name="requestSellOnline">Optional parameter: When `true`, filters to the pricing options that can be sold online.<br />  Default: **false**.</param>
        /// <param name="requestServiceIds">Optional parameter: Filters to the pricing options with the specified IDs. In this context, service and pricing option are used interchangeably..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: Filters to the pricing options with the specified session types IDs..</param>
        /// <param name="requestStaffId">Optional parameter: Sets `Price` and `OnlinePrice` to the particular pricing of a specific staff member, if allowed by the business..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse> SaleGetServicesAsync(
                string siteId,
                string version,
                string authorization = null,
                int? requestClassId = null,
                int? requestClassScheduleId = null,
                bool? requestHideRelatedPrograms = null,
                bool? requestIncludeDiscontinued = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                bool? requestSellOnline = null,
                List<string> requestServiceIds = null,
                List<int> requestSessionTypeIds = null,
                long? requestStaffId = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/services");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.classId", requestClassId },
                { "request.classScheduleId", requestClassScheduleId },
                { "request.hideRelatedPrograms", requestHideRelatedPrograms },
                { "request.includeDiscontinued", requestIncludeDiscontinued },
                { "request.limit", requestLimit },
                { "request.locationId", requestLocationId },
                { "request.offset", requestOffset },
                { "request.programIds", requestProgramIds },
                { "request.sellOnline", requestSellOnline },
                { "request.serviceIds", requestServiceIds },
                { "request.sessionTypeIds", requestSessionTypeIds },
                { "request.staffId", requestStaffId },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse>(response.Body);
        }

        /// <summary>
        /// Update unit price and online price of provided services.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateServicesRequest">Required parameter: Example: .</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse SaleUpdateServices(
                string siteId,
                List<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceRequest> updateServicesRequest,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse> t = this.SaleUpdateServicesAsync(siteId, updateServicesRequest, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Update unit price and online price of provided services.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateServicesRequest">Required parameter: Example: .</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse> SaleUpdateServicesAsync(
                string siteId,
                List<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceRequest> updateServicesRequest,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/services");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(updateServicesRequest);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PutBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse>(response.Body);
        }

        /// <summary>
        /// Get retail products inventory data available at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestBarcodeIds">Optional parameter: An IDs is barcodeId to filter for products inventory data..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: The location IDs to use to determine the inventory data of the product of specific location.<br />  Default: **online store**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProductIds">Optional parameter: An IDs filter for products inventory data..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse SaleGetProductsInventory(
                string siteId,
                string version,
                string authorization = null,
                List<string> requestBarcodeIds = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<string> requestProductIds = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse> t = this.SaleGetProductsInventoryAsync(siteId, version, authorization, requestBarcodeIds, requestLimit, requestLocationIds, requestOffset, requestProductIds);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get retail products inventory data available at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestBarcodeIds">Optional parameter: An IDs is barcodeId to filter for products inventory data..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: The location IDs to use to determine the inventory data of the product of specific location.<br />  Default: **online store**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProductIds">Optional parameter: An IDs filter for products inventory data..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse> SaleGetProductsInventoryAsync(
                string siteId,
                string version,
                string authorization = null,
                List<string> requestBarcodeIds = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<string> requestProductIds = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/productsinventory");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.barcodeIds", requestBarcodeIds },
                { "request.limit", requestLimit },
                { "request.locationIds", requestLocationIds },
                { "request.offset", requestOffset },
                { "request.productIds", requestProductIds },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse>(response.Body);
        }

        /// <summary>
        /// Gets a list of card types that the site accepts. You can also use `GET Sites` to return the Site object, which contains individual accepted card types for requested sites.
        /// This endpoint has no query parameters.The response returns a list of strings. Possible values are:.
        /// * Visa.
        /// * MasterCard.
        /// * Discover.
        /// * AMEX.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the List of string response from the API call.</returns>
        public List<string> SaleGetAcceptedCardTypes(
                string siteId,
                string version,
                string authorization = null)
        {
            Task<List<string>> t = this.SaleGetAcceptedCardTypesAsync(siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Gets a list of card types that the site accepts. You can also use `GET Sites` to return the Site object, which contains individual accepted card types for requested sites.
        /// This endpoint has no query parameters.The response returns a list of strings. Possible values are:.
        /// * Visa.
        /// * MasterCard.
        /// * Discover.
        /// * AMEX.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the List of string response from the API call.</returns>
        public async Task<List<string>> SaleGetAcceptedCardTypesAsync(
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/acceptedcardtypes");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<List<string>>(response.Body);
        }

        /// <summary>
        /// Get contracts available for purchase at a site.
        /// </summary>
        /// <param name="requestLocationId">Required parameter: The ID of the location that has the requested contracts and AutoPay options..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestConsumerId">Optional parameter: The ID of the client..</param>
        /// <param name="requestContractIds">Optional parameter: When included, the response only contains details about the specified contract IDs..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSoldOnline">Optional parameter: When `true`, the response only contains details about contracts and AutoPay options that can be sold online.<br />  When `false`, only contracts that are not intended to be sold online are returned.<br />  Default: **all contracts**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse SaleGetContracts(
                int requestLocationId,
                string siteId,
                string version,
                string authorization = null,
                long? requestConsumerId = null,
                List<int> requestContractIds = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestSoldOnline = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse> t = this.SaleGetContractsAsync(requestLocationId, siteId, version, authorization, requestConsumerId, requestContractIds, requestLimit, requestOffset, requestSoldOnline);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get contracts available for purchase at a site.
        /// </summary>
        /// <param name="requestLocationId">Required parameter: The ID of the location that has the requested contracts and AutoPay options..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestConsumerId">Optional parameter: The ID of the client..</param>
        /// <param name="requestContractIds">Optional parameter: When included, the response only contains details about the specified contract IDs..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSoldOnline">Optional parameter: When `true`, the response only contains details about contracts and AutoPay options that can be sold online.<br />  When `false`, only contracts that are not intended to be sold online are returned.<br />  Default: **all contracts**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse> SaleGetContractsAsync(
                int requestLocationId,
                string siteId,
                string version,
                string authorization = null,
                long? requestConsumerId = null,
                List<int> requestContractIds = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestSoldOnline = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/contracts");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.locationId", requestLocationId },
                { "request.consumerId", requestConsumerId },
                { "request.contractIds", requestContractIds },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.soldOnline", requestSoldOnline },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse>(response.Body);
        }

        /// <summary>
        /// Get payment methods that can be used to pay for sales at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse SaleGetCustomPaymentMethods(
                string siteId,
                string version,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse> t = this.SaleGetCustomPaymentMethodsAsync(siteId, version, authorization, requestLimit, requestOffset);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get payment methods that can be used to pay for sales at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse> SaleGetCustomPaymentMethodsAsync(
                string siteId,
                string version,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/custompaymentmethods");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse>(response.Body);
        }

        /// <summary>
        /// Purchases account credit for a client.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditResponse SalePurchaseAccountCredit(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditResponse> t = this.SalePurchaseAccountCreditAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Purchases account credit for a client.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditResponse> SalePurchaseAccountCreditAsync(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/purchaseaccountcredit");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditResponse>(response.Body);
        }

        /// <summary>
        /// Allows a client to purchase a gift card from a business in a variety of designs. The card can be emailed to the recipient on a specific day, and a card title and a personal message can be added.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardResponse SalePurchaseGiftCard(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardResponse> t = this.SalePurchaseGiftCardAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Allows a client to purchase a gift card from a business in a variety of designs. The card can be emailed to the recipient on a specific day, and a card title and a personal message can be added.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardResponse> SalePurchaseGiftCardAsync(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/purchasegiftcard");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardResponse>(response.Body);
        }

        /// <summary>
        /// A package is typically used to combine multiple services and/or products into a single offering. Staff members can check out multiple appointments while selling the package, and can discount the items included. For example, a spa might bundle a massage, a pedicure, a manicure, a facial, and a few selected beauty products into a package.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: The location ID to use to determine the tax for the products that this request returns.<br />  Default: **online store**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestPackageIds">Optional parameter: A list of the packages IDs to filter by..</param>
        /// <param name="requestSellOnline">Optional parameter: When `true`, only returns products that can be sold online.<br />  When `false`, all products are returned.<br />  Default: **false**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse SaleGetPackages(
                string siteId,
                string version,
                string authorization = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestPackageIds = null,
                bool? requestSellOnline = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse> t = this.SaleGetPackagesAsync(siteId, version, authorization, requestLimit, requestLocationId, requestOffset, requestPackageIds, requestSellOnline);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// A package is typically used to combine multiple services and/or products into a single offering. Staff members can check out multiple appointments while selling the package, and can discount the items included. For example, a spa might bundle a massage, a pedicure, a manicure, a facial, and a few selected beauty products into a package.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: The location ID to use to determine the tax for the products that this request returns.<br />  Default: **online store**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestPackageIds">Optional parameter: A list of the packages IDs to filter by..</param>
        /// <param name="requestSellOnline">Optional parameter: When `true`, only returns products that can be sold online.<br />  When `false`, all products are returned.<br />  Default: **false**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse> SaleGetPackagesAsync(
                string siteId,
                string version,
                string authorization = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestPackageIds = null,
                bool? requestSellOnline = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/packages");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.limit", requestLimit },
                { "request.locationId", requestLocationId },
                { "request.offset", requestOffset },
                { "request.packageIds", requestPackageIds },
                { "request.sellOnline", requestSellOnline },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse>(response.Body);
        }

        /// <summary>
        /// Get a gift card's remaining balance.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="barcodeId">Optional parameter: The barcode ID of the gift card for which you want the balance..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse SaleGetGiftCardBalance(
                string siteId,
                string version,
                string authorization = null,
                string barcodeId = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse> t = this.SaleGetGiftCardBalanceAsync(siteId, version, authorization, barcodeId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get a gift card's remaining balance.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="barcodeId">Optional parameter: The barcode ID of the gift card for which you want the balance..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse> SaleGetGiftCardBalanceAsync(
                string siteId,
                string version,
                string authorization = null,
                string barcodeId = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/giftcardbalance");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "barcodeId", barcodeId },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse>(response.Body);
        }

        /// <summary>
        /// Get transactions completed at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientId">Optional parameter: Filters results to the requested client ID..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to the requested location ID..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSaleId">Optional parameter: Filters results to the requested sale ID..</param>
        /// <param name="requestStatus">Optional parameter: Filters results to the requested status..</param>
        /// <param name="requestTransactionEndDateTime">Optional parameter: Filters results to transactions that happened before this date and time..</param>
        /// <param name="requestTransactionId">Optional parameter: Filters results to the requested transaction ID..</param>
        /// <param name="requestTransactionStartDateTime">Optional parameter: Filters results to transactions that happened after this date and time..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsResponse SaleGetTransactions(
                string siteId,
                string version,
                string authorization = null,
                long? requestClientId = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                long? requestSaleId = null,
                string requestStatus = null,
                DateTime? requestTransactionEndDateTime = null,
                int? requestTransactionId = null,
                DateTime? requestTransactionStartDateTime = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsResponse> t = this.SaleGetTransactionsAsync(siteId, version, authorization, requestClientId, requestLimit, requestLocationId, requestOffset, requestSaleId, requestStatus, requestTransactionEndDateTime, requestTransactionId, requestTransactionStartDateTime);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get transactions completed at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientId">Optional parameter: Filters results to the requested client ID..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to the requested location ID..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSaleId">Optional parameter: Filters results to the requested sale ID..</param>
        /// <param name="requestStatus">Optional parameter: Filters results to the requested status..</param>
        /// <param name="requestTransactionEndDateTime">Optional parameter: Filters results to transactions that happened before this date and time..</param>
        /// <param name="requestTransactionId">Optional parameter: Filters results to the requested transaction ID..</param>
        /// <param name="requestTransactionStartDateTime">Optional parameter: Filters results to transactions that happened after this date and time..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsResponse> SaleGetTransactionsAsync(
                string siteId,
                string version,
                string authorization = null,
                long? requestClientId = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                long? requestSaleId = null,
                string requestStatus = null,
                DateTime? requestTransactionEndDateTime = null,
                int? requestTransactionId = null,
                DateTime? requestTransactionStartDateTime = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/transactions");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.clientId", requestClientId },
                { "request.limit", requestLimit },
                { "request.locationId", requestLocationId },
                { "request.offset", requestOffset },
                { "request.saleId", requestSaleId },
                { "request.status", requestStatus },
                { "request.transactionEndDateTime", requestTransactionEndDateTime.HasValue ? requestTransactionEndDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.transactionId", requestTransactionId },
                { "request.transactionStartDateTime", requestTransactionStartDateTime.HasValue ? requestTransactionStartDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsResponse>(response.Body);
        }

        /// <summary>
        /// Update retail product's unit and online price.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceResponse SaleUpdateProductPrice(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceResponse> t = this.SaleUpdateProductPriceAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Update retail product's unit and online price.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceResponse> SaleUpdateProductPriceAsync(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/updateproductprice");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceResponse>(response.Body);
        }

        /// <summary>
        /// Sale_UpdateSaleDate EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse SaleUpdateSaleDate(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse> t = this.SaleUpdateSaleDateAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Sale_UpdateSaleDate EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse> SaleUpdateSaleDateAsync(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/updatesaledate");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PutBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse>(response.Body);
        }

        /// <summary>
        /// Sale_InitializeCreditCardEntry EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse SaleInitializeCreditCardEntry(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse> t = this.SaleInitializeCreditCardEntryAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Sale_InitializeCreditCardEntry EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse> SaleInitializeCreditCardEntryAsync(
                Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/initializecreditcardentry");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse>(response.Body);
        }
    }
}