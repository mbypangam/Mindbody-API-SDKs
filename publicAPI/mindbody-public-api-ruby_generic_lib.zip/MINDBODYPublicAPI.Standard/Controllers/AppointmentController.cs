// <copyright file="AppointmentController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Http.Request;
    using MINDBODYPublicAPI.Standard.Http.Request.Configuration;
    using MINDBODYPublicAPI.Standard.Http.Response;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AppointmentController.
    /// </summary>
    public class AppointmentController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AppointmentController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal AppointmentController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// To book an appointment, you must use a location ID, staff ID, client ID, session type ID, and the `StartDateTime` of the appointment. You can get most of this information using `GET BookableItems`.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse AppointmentAddAppointment(
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse> t = this.AppointmentAddAppointmentAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// To book an appointment, you must use a location ID, staff ID, client ID, session type ID, and the `StartDateTime` of the appointment. You can get most of this information using `GET BookableItems`.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse> AppointmentAddAppointmentAsync(
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/addappointment");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse>(response.Body);
        }

        /// <summary>
        /// To update the information for a specific appointment, you must have a staff user token with the proper permissions. Note that you can only update the appointment’s `StartDateTime`, `EndDateTime`, `StaffId`, `Notes`, and `SessionTypeId`.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse AppointmentUpdateAppointment(
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse> t = this.AppointmentUpdateAppointmentAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// To update the information for a specific appointment, you must have a staff user token with the proper permissions. Note that you can only update the appointment’s `StartDateTime`, `EndDateTime`, `StaffId`, `Notes`, and `SessionTypeId`.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse> AppointmentUpdateAppointmentAsync(
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/updateappointment");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse>(response.Body);
        }

        /// <summary>
        /// Returns a list of available dates for the given session types.
        /// </summary>
        /// <param name="requestSessionTypeId">Required parameter: required requested session type ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestLocationId">Optional parameter: optional requested location ID..</param>
        /// <param name="requestStaffId">Optional parameter: optional requested staff ID..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse AppointmentGetAvailableDates(
                int requestSessionTypeId,
                string siteId,
                string version,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLocationId = null,
                long? requestStaffId = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse> t = this.AppointmentGetAvailableDatesAsync(requestSessionTypeId, siteId, version, authorization, requestEndDate, requestLocationId, requestStaffId, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of available dates for the given session types.
        /// </summary>
        /// <param name="requestSessionTypeId">Required parameter: required requested session type ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestLocationId">Optional parameter: optional requested location ID..</param>
        /// <param name="requestStaffId">Optional parameter: optional requested staff ID..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse> AppointmentGetAvailableDatesAsync(
                int requestSessionTypeId,
                string siteId,
                string version,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLocationId = null,
                long? requestStaffId = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/availabledates");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.sessionTypeId", requestSessionTypeId },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.locationId", requestLocationId },
                { "request.staffId", requestStaffId },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse>(response.Body);
        }

        /// <summary>
        /// Returns a list of availabilities with the information needed to book appointments. Availabilities include information such as the location and its amenities, staff members, programs, and session types.
        /// </summary>
        /// <param name="requestSessionTypeIds">Required parameter: A list of the requested session type IDs..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentId">Optional parameter: If provided, filters out the appointment with this ID..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestIgnoreDefaultSessionLength">Optional parameter: When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br />  When `false`, only availabilities that have the default session length return..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of the requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of the requested staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse AppointmentGetBookableItems(
                List<int> requestSessionTypeIds,
                string siteId,
                string version,
                string authorization = null,
                long? requestAppointmentId = null,
                DateTime? requestEndDate = null,
                bool? requestIgnoreDefaultSessionLength = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse> t = this.AppointmentGetBookableItemsAsync(requestSessionTypeIds, siteId, version, authorization, requestAppointmentId, requestEndDate, requestIgnoreDefaultSessionLength, requestLimit, requestLocationIds, requestOffset, requestStaffIds, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of availabilities with the information needed to book appointments. Availabilities include information such as the location and its amenities, staff members, programs, and session types.
        /// </summary>
        /// <param name="requestSessionTypeIds">Required parameter: A list of the requested session type IDs..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentId">Optional parameter: If provided, filters out the appointment with this ID..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestIgnoreDefaultSessionLength">Optional parameter: When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br />  When `false`, only availabilities that have the default session length return..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of the requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of the requested staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse> AppointmentGetBookableItemsAsync(
                List<int> requestSessionTypeIds,
                string siteId,
                string version,
                string authorization = null,
                long? requestAppointmentId = null,
                DateTime? requestEndDate = null,
                bool? requestIgnoreDefaultSessionLength = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/bookableitems");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.sessionTypeIds", requestSessionTypeIds },
                { "request.appointmentId", requestAppointmentId },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.ignoreDefaultSessionLength", requestIgnoreDefaultSessionLength },
                { "request.limit", requestLimit },
                { "request.locationIds", requestLocationIds },
                { "request.offset", requestOffset },
                { "request.staffIds", requestStaffIds },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse>(response.Body);
        }

        /// <summary>
        /// Returns a list of the times that can be booked for a given program schedule type. `ActiveSessionTimes` represent the scheduling increments that can be booked during the active business hours for services.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndTime">Optional parameter: Filters results to times that end on or before this time on the current date. Any date provided is ignored..  <br />Default: **23:59:59**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestScheduleType">Optional parameter: Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided..</param>
        /// <param name="requestStartTime">Optional parameter: Filters results to times that start on or after this time on the current date. Any date provided is ignored.  <br />Default: **00:00:00**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse AppointmentGetActiveSessionTimes(
                string siteId,
                string version,
                string authorization = null,
                DateTime? requestEndTime = null,
                int? requestLimit = null,
                int? requestOffset = null,
                Models.RequestScheduleTypeEnum? requestScheduleType = null,
                List<int> requestSessionTypeIds = null,
                DateTime? requestStartTime = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse> t = this.AppointmentGetActiveSessionTimesAsync(siteId, version, authorization, requestEndTime, requestLimit, requestOffset, requestScheduleType, requestSessionTypeIds, requestStartTime);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of the times that can be booked for a given program schedule type. `ActiveSessionTimes` represent the scheduling increments that can be booked during the active business hours for services.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndTime">Optional parameter: Filters results to times that end on or before this time on the current date. Any date provided is ignored..  <br />Default: **23:59:59**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestScheduleType">Optional parameter: Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided..</param>
        /// <param name="requestStartTime">Optional parameter: Filters results to times that start on or after this time on the current date. Any date provided is ignored.  <br />Default: **00:00:00**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse> AppointmentGetActiveSessionTimesAsync(
                string siteId,
                string version,
                string authorization = null,
                DateTime? requestEndTime = null,
                int? requestLimit = null,
                int? requestOffset = null,
                Models.RequestScheduleTypeEnum? requestScheduleType = null,
                List<int> requestSessionTypeIds = null,
                DateTime? requestStartTime = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/activesessiontimes");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.endTime", requestEndTime.HasValue ? requestEndTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.scheduleType", (requestScheduleType.HasValue) ? ApiHelper.JsonSerialize(requestScheduleType.Value).Trim('\"') : null },
                { "request.sessionTypeIds", requestSessionTypeIds },
                { "request.startTime", requestStartTime.HasValue ? requestStartTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse>(response.Body);
        }

        /// <summary>
        /// Returns a list of schedule items, including appointments, availabilities, and unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="requestIgnorePrepFinishTimes">Optional parameter: When `true`, appointment preparation and finish unavailabilities are not returned.   <br />Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of requested staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse AppointmentGetScheduleItems(
                string siteId,
                string version,
                string authorization = null,
                DateTime? requestEndDate = null,
                bool? requestIgnorePrepFinishTimes = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse> t = this.AppointmentGetScheduleItemsAsync(siteId, version, authorization, requestEndDate, requestIgnorePrepFinishTimes, requestLimit, requestLocationIds, requestOffset, requestStaffIds, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of schedule items, including appointments, availabilities, and unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="requestIgnorePrepFinishTimes">Optional parameter: When `true`, appointment preparation and finish unavailabilities are not returned.   <br />Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of requested staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse> AppointmentGetScheduleItemsAsync(
                string siteId,
                string version,
                string authorization = null,
                DateTime? requestEndDate = null,
                bool? requestIgnorePrepFinishTimes = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/scheduleitems");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.ignorePrepFinishTimes", requestIgnorePrepFinishTimes },
                { "request.limit", requestLimit },
                { "request.locationIds", requestLocationIds },
                { "request.offset", requestOffset },
                { "request.staffIds", requestStaffIds },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint has no query parameters.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse AppointmentGetAppointmentOptions(
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse> t = this.AppointmentGetAppointmentOptionsAsync(siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint has no query parameters.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse> AppointmentGetAppointmentOptionsAsync(
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/appointmentoptions");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse>(response.Body);
        }

        /// <summary>
        /// Returns a list of appointments by staff member.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentIds">Optional parameter: A list of the requested appointment IDs..</param>
        /// <param name="requestClientId">Optional parameter: The client ID to be returned..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of the requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: List of staff IDs to be returned. Use a value of zero to return all staff appointments..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range. If omitted, the default is used.   <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse AppointmentGetStaffAppointments(
                string siteId,
                string version,
                string authorization = null,
                List<int> requestAppointmentIds = null,
                string requestClientId = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse> t = this.AppointmentGetStaffAppointmentsAsync(siteId, version, authorization, requestAppointmentIds, requestClientId, requestEndDate, requestLimit, requestLocationIds, requestOffset, requestStaffIds, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of appointments by staff member.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentIds">Optional parameter: A list of the requested appointment IDs..</param>
        /// <param name="requestClientId">Optional parameter: The client ID to be returned..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of the requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: List of staff IDs to be returned. Use a value of zero to return all staff appointments..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range. If omitted, the default is used.   <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse> AppointmentGetStaffAppointmentsAsync(
                string siteId,
                string version,
                string authorization = null,
                List<int> requestAppointmentIds = null,
                string requestClientId = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/staffappointments");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.appointmentIds", requestAppointmentIds },
                { "request.clientId", requestClientId },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.locationIds", requestLocationIds },
                { "request.offset", requestOffset },
                { "request.staffIds", requestStaffIds },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse>(response.Body);
        }

        /// <summary>
        /// Returns a list of appointment addons optionally filtered by those that can be performed by the given staff member.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffId">Optional parameter: Optionally filter add ons that can be performed by this staff.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse AppointmentGetAddOns(
                string siteId,
                string version,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestStaffId = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse> t = this.AppointmentGetAddOnsAsync(siteId, version, authorization, requestLimit, requestOffset, requestStaffId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of appointment addons optionally filtered by those that can be performed by the given staff member.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffId">Optional parameter: Optionally filter add ons that can be performed by this staff.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse> AppointmentGetAddOnsAsync(
                string siteId,
                string version,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestStaffId = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/addons");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.staffId", requestStaffId },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse>(response.Body);
        }

        /// <summary>
        /// Creates an Add On to an existing appointment.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse AppointmentAddAppointmentAddOn(
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse> t = this.AppointmentAddAppointmentAddOnAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Creates an Add On to an existing appointment.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse> AppointmentAddAppointmentAddOnAsync(
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/addappointmentaddon");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse>(response.Body);
        }

        /// <summary>
        /// Cross Regional Add On payments are not currently supported.  Returns 204 No Content on success.
        /// </summary>
        /// <param name="id">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        public void AppointmentDeleteAppointmentAddOn(
                long id,
                string siteId,
                string version,
                string authorization = null)
        {
            Task t = this.AppointmentDeleteAppointmentAddOnAsync(id, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Cross Regional Add On payments are not currently supported.  Returns 204 No Content on success.
        /// </summary>
        /// <param name="id">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task AppointmentDeleteAppointmentAddOnAsync(
                long id,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/deleteappointmentaddon");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "id", id },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Update availability/unavailability of the staff.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateAvailabilityRequest">Required parameter: Example: .</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse AppointmentUpdateAvailability(
                string siteId,
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest updateAvailabilityRequest,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse> t = this.AppointmentUpdateAvailabilityAsync(siteId, updateAvailabilityRequest, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Update availability/unavailability of the staff.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateAvailabilityRequest">Required parameter: Example: .</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse> AppointmentUpdateAvailabilityAsync(
                string siteId,
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest updateAvailabilityRequest,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/availabilities");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(updateAvailabilityRequest);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PutBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse>(response.Body);
        }

        /// <summary>
        /// To Add Availabillity/Unavailabillity, you must use a location ID, staff IDs and the `StartDate/EndDate` of the Availabillity/Unavailabillity.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse AppointmentAddAvailabilities(
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse> t = this.AppointmentAddAvailabilitiesAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// To Add Availabillity/Unavailabillity, you must use a location ID, staff IDs and the `StartDate/EndDate` of the Availabillity/Unavailabillity.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse> AppointmentAddAvailabilitiesAsync(
                Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/availabilities");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse>(response.Body);
        }

        /// <summary>
        /// Delete availability/unavailability of the staff.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="deleteAvailabilityRequestAvailabilityId">Optional parameter: Availability Id to be deleted.</param>
        /// <param name="deleteAvailabilityRequestTest">Optional parameter: The test flag.</param>
        public void AppointmentDeleteAvailability(
                string siteId,
                string version,
                string authorization = null,
                int? deleteAvailabilityRequestAvailabilityId = null,
                bool? deleteAvailabilityRequestTest = null)
        {
            Task t = this.AppointmentDeleteAvailabilityAsync(siteId, version, authorization, deleteAvailabilityRequestAvailabilityId, deleteAvailabilityRequestTest);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Delete availability/unavailability of the staff.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="deleteAvailabilityRequestAvailabilityId">Optional parameter: Availability Id to be deleted.</param>
        /// <param name="deleteAvailabilityRequestTest">Optional parameter: The test flag.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task AppointmentDeleteAvailabilityAsync(
                string siteId,
                string version,
                string authorization = null,
                int? deleteAvailabilityRequestAvailabilityId = null,
                bool? deleteAvailabilityRequestTest = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/appointment/availability");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "deleteAvailabilityRequest.availabilityId", deleteAvailabilityRequestAvailabilityId },
                { "deleteAvailabilityRequest.test", deleteAvailabilityRequestTest },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }
    }
}