// <copyright file="ProductController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Http.Request;
    using MINDBODYPublicAPI.Standard.Http.Request.Configuration;
    using MINDBODYPublicAPI.Standard.Http.Response;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ProductController.
    /// </summary>
    public class ProductController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal ProductController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Update retail products available for purchase at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateProductsRequests">Required parameter: Example: .</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse ProductUpdateProducts(
                string siteId,
                List<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest> updateProductsRequests,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse> t = this.ProductUpdateProductsAsync(siteId, updateProductsRequests, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Update retail products available for purchase at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateProductsRequests">Required parameter: Example: .</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse> ProductUpdateProductsAsync(
                string siteId,
                List<Models.MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductRequest> updateProductsRequests,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/sale/products");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(updateProductsRequests);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PutBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse>(response.Body);
        }
    }
}