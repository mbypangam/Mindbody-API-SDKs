// <copyright file="StaffController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Http.Request;
    using MINDBODYPublicAPI.Standard.Http.Request.Configuration;
    using MINDBODYPublicAPI.Standard.Http.Response;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// StaffController.
    /// </summary>
    public class StaffController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StaffController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal StaffController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Get staff members at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestFilters">Optional parameter: Filters to apply to the search. Possible values are:  * StaffViewable  * AppointmentInstructor  * ClassInstructor  * Male  * Female.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSessionTypeId">Optional parameter: Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of the requested staff IDs..</param>
        /// <param name="requestStartDateTime">Optional parameter: Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse StaffGetStaff(
                string siteId,
                string version,
                string authorization = null,
                List<string> requestFilters = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                int? requestSessionTypeId = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDateTime = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse> t = this.StaffGetStaffAsync(siteId, version, authorization, requestFilters, requestLimit, requestLocationId, requestOffset, requestSessionTypeId, requestStaffIds, requestStartDateTime);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get staff members at a site.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestFilters">Optional parameter: Filters to apply to the search. Possible values are:  * StaffViewable  * AppointmentInstructor  * ClassInstructor  * Male  * Female.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSessionTypeId">Optional parameter: Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of the requested staff IDs..</param>
        /// <param name="requestStartDateTime">Optional parameter: Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse> StaffGetStaffAsync(
                string siteId,
                string version,
                string authorization = null,
                List<string> requestFilters = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                int? requestSessionTypeId = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDateTime = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/staff");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.filters", requestFilters },
                { "request.limit", requestLimit },
                { "request.locationId", requestLocationId },
                { "request.offset", requestOffset },
                { "request.sessionTypeId", requestSessionTypeId },
                { "request.staffIds", requestStaffIds },
                { "request.startDateTime", requestStartDateTime.HasValue ? requestStartDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse>(response.Body);
        }

        /// <summary>
        /// Get configured staff permissions for a staff member.
        /// </summary>
        /// <param name="requestStaffId">Required parameter: The ID of the staff member whose permissions you want to return..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse StaffGetStaffPermissions(
                long requestStaffId,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse> t = this.StaffGetStaffPermissionsAsync(requestStaffId, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get configured staff permissions for a staff member.
        /// </summary>
        /// <param name="requestStaffId">Required parameter: The ID of the staff member whose permissions you want to return..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse> StaffGetStaffPermissionsAsync(
                long requestStaffId,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/staffpermissions");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.staffId", requestStaffId },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse>(response.Body);
        }

        /// <summary>
        /// Get image URLs for the given staff ID in the request.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestStaffId">Optional parameter: A requested staff ID..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse StaffGetStaffImageURL(
                string siteId,
                string version,
                string authorization = null,
                long? requestStaffId = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse> t = this.StaffGetStaffImageURLAsync(siteId, version, authorization, requestStaffId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get image URLs for the given staff ID in the request.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestStaffId">Optional parameter: A requested staff ID..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse> StaffGetStaffImageURLAsync(
                string siteId,
                string version,
                string authorization = null,
                long? requestStaffId = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/imageurl");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.staffId", requestStaffId },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse>(response.Body);
        }

        /// <summary>
        /// Staff_UpdateStaffPermissions EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse StaffUpdateStaffPermissions(
                Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse> t = this.StaffUpdateStaffPermissionsAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Staff_UpdateStaffPermissions EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse> StaffUpdateStaffPermissionsAsync(
                Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/updatestaffpermissions");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse>(response.Body);
        }

        /// <summary>
        /// Staff_AddStaff EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse StaffAddStaff(
                Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse> t = this.StaffAddStaffAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Staff_AddStaff EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse> StaffAddStaffAsync(
                Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/addstaff");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse>(response.Body);
        }

        /// <summary>
        /// Staff_UpdateStaff EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse StaffUpdateStaff(
                Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse> t = this.StaffUpdateStaffAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Staff_UpdateStaff EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse> StaffUpdateStaffAsync(
                Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/updatestaff");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse>(response.Body);
        }

        /// <summary>
        /// Staff_AddStaffAvailability EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        public void StaffAddStaffAvailability(
                Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task t = this.StaffAddStaffAvailabilityAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Staff_AddStaffAvailability EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task StaffAddStaffAvailabilityAsync(
                Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/staffavailability");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Get the session types used at a site for a staff member.
        /// </summary>
        /// <param name="requestStaffId">Required parameter: Filters returned session types to only those the staff member performs.  Staff should be active..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: Only session types that can be booked online..</param>
        /// <param name="requestProgramIds">Optional parameter: Filters results to session types that belong in program IDs..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse StaffGetStaffSessionTypes(
                long requestStaffId,
                string siteId,
                string version,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                List<int> requestProgramIds = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse> t = this.StaffGetStaffSessionTypesAsync(requestStaffId, siteId, version, authorization, requestLimit, requestOffset, requestOnlineOnly, requestProgramIds);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get the session types used at a site for a staff member.
        /// </summary>
        /// <param name="requestStaffId">Required parameter: Filters returned session types to only those the staff member performs.  Staff should be active..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: Only session types that can be booked online..</param>
        /// <param name="requestProgramIds">Optional parameter: Filters results to session types that belong in program IDs..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse> StaffGetStaffSessionTypesAsync(
                long requestStaffId,
                string siteId,
                string version,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                List<int> requestProgramIds = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/sessiontypes");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.staffId", requestStaffId },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.onlineOnly", requestOnlineOnly },
                { "request.programIds", requestProgramIds },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse>(response.Body);
        }

        /// <summary>
        /// Staff_AssignStaffSessionType EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse StaffAssignStaffSessionType(
                Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse> t = this.StaffAssignStaffSessionTypeAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Staff_AssignStaffSessionType EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse> StaffAssignStaffSessionTypeAsync(
                Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/assignsessiontype");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse>(response.Body);
        }

        /// <summary>
        /// Staff_GetSalesReps EndPoint.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActiveOnly">Optional parameter: This is to filter out the active sales rep from the list.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSalesRepNumbers">Optional parameter: This is the list of rep numbers to be fetched.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse StaffGetSalesReps(
                string siteId,
                string version,
                string authorization = null,
                bool? requestActiveOnly = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSalesRepNumbers = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse> t = this.StaffGetSalesRepsAsync(siteId, version, authorization, requestActiveOnly, requestLimit, requestOffset, requestSalesRepNumbers);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Staff_GetSalesReps EndPoint.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActiveOnly">Optional parameter: This is to filter out the active sales rep from the list.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSalesRepNumbers">Optional parameter: This is the list of rep numbers to be fetched.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse> StaffGetSalesRepsAsync(
                string siteId,
                string version,
                string authorization = null,
                bool? requestActiveOnly = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSalesRepNumbers = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/salesreps");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.activeOnly", requestActiveOnly },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.salesRepNumbers", requestSalesRepNumbers },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse>(response.Body);
        }
    }
}