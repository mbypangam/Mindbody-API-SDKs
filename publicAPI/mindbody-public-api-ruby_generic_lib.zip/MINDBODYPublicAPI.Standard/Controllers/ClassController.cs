// <copyright file="ClassController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Http.Request;
    using MINDBODYPublicAPI.Standard.Http.Request.Configuration;
    using MINDBODYPublicAPI.Standard.Http.Response;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ClassController.
    /// </summary>
    public class ClassController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClassController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal ClassController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// Get scheduled classes.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassDescriptionIds">Optional parameter: The requested class description IDs..</param>
        /// <param name="requestClassIds">Optional parameter: The requested class IDs..</param>
        /// <param name="requestClassScheduleIds">Optional parameter: The requested classScheduleIds..</param>
        /// <param name="requestClientId">Optional parameter: The client ID of the client who is viewing this class list. Based on identity, the client may be able to see additional information, such as membership specials..</param>
        /// <param name="requestEndDateTime">Optional parameter: The requested end date for filtering.  <br />Default: **today’s date**.</param>
        /// <param name="requestHideCanceledClasses">Optional parameter: When `true`, canceled classes are removed from the response.<br />  When `false`, canceled classes are included in the response.<br />  Default: **false**.</param>
        /// <param name="requestLastModifiedDate">Optional parameter: When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of location IDs on which to base the search..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: A list of program IDs on which to base the search..</param>
        /// <param name="requestSchedulingWindow">Optional parameter: When `true`, classes outside scheduling window are removed from the response.<br />  When `false`, classes are included in the response, regardless of the scheduling window.<br />  Default: **false**.</param>
        /// <param name="requestSemesterIds">Optional parameter: A list of semester IDs on which to base the search..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: A list of session type IDs on which to base the search..</param>
        /// <param name="requestStaffIds">Optional parameter: The requested IDs of the teaching staff members..</param>
        /// <param name="requestStartDateTime">Optional parameter: The requested start date for filtering.   <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassesResponse ClassGetClasses(
                string siteId,
                string version,
                string authorization = null,
                List<int> requestClassDescriptionIds = null,
                List<int> requestClassIds = null,
                List<int> requestClassScheduleIds = null,
                string requestClientId = null,
                DateTime? requestEndDateTime = null,
                bool? requestHideCanceledClasses = null,
                DateTime? requestLastModifiedDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                bool? requestSchedulingWindow = null,
                List<int> requestSemesterIds = null,
                List<int> requestSessionTypeIds = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDateTime = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassesResponse> t = this.ClassGetClassesAsync(siteId, version, authorization, requestClassDescriptionIds, requestClassIds, requestClassScheduleIds, requestClientId, requestEndDateTime, requestHideCanceledClasses, requestLastModifiedDate, requestLimit, requestLocationIds, requestOffset, requestProgramIds, requestSchedulingWindow, requestSemesterIds, requestSessionTypeIds, requestStaffIds, requestStartDateTime);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get scheduled classes.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassDescriptionIds">Optional parameter: The requested class description IDs..</param>
        /// <param name="requestClassIds">Optional parameter: The requested class IDs..</param>
        /// <param name="requestClassScheduleIds">Optional parameter: The requested classScheduleIds..</param>
        /// <param name="requestClientId">Optional parameter: The client ID of the client who is viewing this class list. Based on identity, the client may be able to see additional information, such as membership specials..</param>
        /// <param name="requestEndDateTime">Optional parameter: The requested end date for filtering.  <br />Default: **today’s date**.</param>
        /// <param name="requestHideCanceledClasses">Optional parameter: When `true`, canceled classes are removed from the response.<br />  When `false`, canceled classes are included in the response.<br />  Default: **false**.</param>
        /// <param name="requestLastModifiedDate">Optional parameter: When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of location IDs on which to base the search..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: A list of program IDs on which to base the search..</param>
        /// <param name="requestSchedulingWindow">Optional parameter: When `true`, classes outside scheduling window are removed from the response.<br />  When `false`, classes are included in the response, regardless of the scheduling window.<br />  Default: **false**.</param>
        /// <param name="requestSemesterIds">Optional parameter: A list of semester IDs on which to base the search..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: A list of session type IDs on which to base the search..</param>
        /// <param name="requestStaffIds">Optional parameter: The requested IDs of the teaching staff members..</param>
        /// <param name="requestStartDateTime">Optional parameter: The requested start date for filtering.   <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassesResponse> ClassGetClassesAsync(
                string siteId,
                string version,
                string authorization = null,
                List<int> requestClassDescriptionIds = null,
                List<int> requestClassIds = null,
                List<int> requestClassScheduleIds = null,
                string requestClientId = null,
                DateTime? requestEndDateTime = null,
                bool? requestHideCanceledClasses = null,
                DateTime? requestLastModifiedDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                bool? requestSchedulingWindow = null,
                List<int> requestSemesterIds = null,
                List<int> requestSessionTypeIds = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDateTime = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/classes");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.classDescriptionIds", requestClassDescriptionIds },
                { "request.classIds", requestClassIds },
                { "request.classScheduleIds", requestClassScheduleIds },
                { "request.clientId", requestClientId },
                { "request.endDateTime", requestEndDateTime.HasValue ? requestEndDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.hideCanceledClasses", requestHideCanceledClasses },
                { "request.lastModifiedDate", requestLastModifiedDate.HasValue ? requestLastModifiedDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.locationIds", requestLocationIds },
                { "request.offset", requestOffset },
                { "request.programIds", requestProgramIds },
                { "request.schedulingWindow", requestSchedulingWindow },
                { "request.semesterIds", requestSemesterIds },
                { "request.sessionTypeIds", requestSessionTypeIds },
                { "request.staffIds", requestStaffIds },
                { "request.startDateTime", requestStartDateTime.HasValue ? requestStartDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassesResponse>(response.Body);
        }

        /// <summary>
        /// To find class descriptions associated with **scheduled classes**, pass `StaffId`, `StartClassDateTime`, `EndClassDateTime`, or `LocationId` in the request.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassDescriptionId">Optional parameter: Filters to the single result with the given ID..</param>
        /// <param name="requestEndClassDateTime">Optional parameter: Filters the results to class descriptions for scheduled classes that happen before the given date and time..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to classes descriptions for schedule classes as the given location..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filters results to class descriptions belonging to the given programs..</param>
        /// <param name="requestStaffId">Optional parameter: Filters results to class descriptions for scheduled classes taught by the given staff member..</param>
        /// <param name="requestStartClassDateTime">Optional parameter: Filters the results to class descriptions for scheduled classes that happen on or after the given date and time..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsResponse ClassGetClassDescriptions(
                string siteId,
                string version,
                string authorization = null,
                int? requestClassDescriptionId = null,
                DateTime? requestEndClassDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                long? requestStaffId = null,
                DateTime? requestStartClassDateTime = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsResponse> t = this.ClassGetClassDescriptionsAsync(siteId, version, authorization, requestClassDescriptionId, requestEndClassDateTime, requestLimit, requestLocationId, requestOffset, requestProgramIds, requestStaffId, requestStartClassDateTime);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// To find class descriptions associated with **scheduled classes**, pass `StaffId`, `StartClassDateTime`, `EndClassDateTime`, or `LocationId` in the request.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassDescriptionId">Optional parameter: Filters to the single result with the given ID..</param>
        /// <param name="requestEndClassDateTime">Optional parameter: Filters the results to class descriptions for scheduled classes that happen before the given date and time..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to classes descriptions for schedule classes as the given location..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filters results to class descriptions belonging to the given programs..</param>
        /// <param name="requestStaffId">Optional parameter: Filters results to class descriptions for scheduled classes taught by the given staff member..</param>
        /// <param name="requestStartClassDateTime">Optional parameter: Filters the results to class descriptions for scheduled classes that happen on or after the given date and time..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsResponse> ClassGetClassDescriptionsAsync(
                string siteId,
                string version,
                string authorization = null,
                int? requestClassDescriptionId = null,
                DateTime? requestEndClassDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                long? requestStaffId = null,
                DateTime? requestStartClassDateTime = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/classdescriptions");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.classDescriptionId", requestClassDescriptionId },
                { "request.endClassDateTime", requestEndClassDateTime.HasValue ? requestEndClassDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.locationId", requestLocationId },
                { "request.offset", requestOffset },
                { "request.programIds", requestProgramIds },
                { "request.staffId", requestStaffId },
                { "request.startClassDateTime", requestStartClassDateTime.HasValue ? requestStartClassDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsResponse>(response.Body);
        }

        /// <summary>
        /// Returns a list of visits that contain information for a specified class. On success, this request returns the class object in the response with a list of visits.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassID">Optional parameter: The class ID..</param>
        /// <param name="requestLastModifiedDate">Optional parameter: When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse ClassGetClassVisits(
                string siteId,
                string version,
                string authorization = null,
                long? requestClassID = null,
                DateTime? requestLastModifiedDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse> t = this.ClassGetClassVisitsAsync(siteId, version, authorization, requestClassID, requestLastModifiedDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of visits that contain information for a specified class. On success, this request returns the class object in the response with a list of visits.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassID">Optional parameter: The class ID..</param>
        /// <param name="requestLastModifiedDate">Optional parameter: When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse> ClassGetClassVisitsAsync(
                string siteId,
                string version,
                string authorization = null,
                long? requestClassID = null,
                DateTime? requestLastModifiedDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/classvisits");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.classID", requestClassID },
                { "request.lastModifiedDate", requestLastModifiedDate.HasValue ? requestLastModifiedDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse>(response.Body);
        }

        /// <summary>
        /// Remove a client from a class.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassResponse ClassRemoveClientFromClass(
                Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassResponse> t = this.ClassRemoveClientFromClassAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Remove a client from a class.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassResponse> ClassRemoveClientFromClassAsync(
                Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/removeclientfromclass");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassResponse>(response.Body);
        }

        /// <summary>
        /// Class_AddClassSchedule EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object ClassAddClassSchedule(
                Models.MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<object> t = this.ClassAddClassScheduleAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Class_AddClassSchedule EndPoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> ClassAddClassScheduleAsync(
                Models.MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/addclassschedule");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return response.Body;
        }

        /// <summary>
        /// This endpoint adds a client to a class or to a class waiting list. It is helpful to use this endpoint in the following situations:.
        /// * Use after calling `GET Clients` and `GET Classes` so that you are sure which client to book in which class.
        /// * If adding a client to a class from a waiting list, use this call after you call `GET WaitlistEntries` and determine the ID of the waiting list from which you are moving the client.
        /// * If adding a client to a class and using a pricing option that the client has already purchased, use this call after you call `GET ClientServices` to determine the ID of the pricing option that the client wants to use.
        /// If you add a client to a class and the client purchases a new pricing option, use `GET Services`, `GET Classes`, and then `POST CheckoutShoppingCart` in place of this call.
        /// This endpoint also supports cross-regional class bookings. If you want to perform a cross-regional class booking, set `CrossRegionalBooking` to `true`. This endpoint does not support adding a user to a waiting list using a cross-regional client pricing option(service). Cross-regional booking workflows do not support client service scheduling restrictions.
        /// When performing a cross-regional class booking, this endpoint loops through the first ten sites that the client is associated with, looks for client pricing options at each of those sites, and then uses the oldest client pricing option found.It is important to note that this endpoint only loops through a maximum of ten associated client sites. If a `ClientID` is associated with more than ten sites in an organization, this endpoint only loops through the first ten.If you know that a client has a client service at another site, you can specify that site using the `CrossRegionalBookingClientServiceSiteId` query parameter.
        /// If you perform a cross-regional booking, two additional fields are included in the `SessionType` object of the response:.
        /// * `SiteID`, which specifies where the client service is coming from.
        /// * `CrossRegionalBookingPerformed`, a Boolean field that is set to `true`.
        /// As a prerequisite to using this endpoint, your `SourceName` must have been granted access to the organization to which the site belongs.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassResponse ClassAddClientToClass(
                Models.MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassResponse> t = this.ClassAddClientToClassAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint adds a client to a class or to a class waiting list. It is helpful to use this endpoint in the following situations:.
        /// * Use after calling `GET Clients` and `GET Classes` so that you are sure which client to book in which class.
        /// * If adding a client to a class from a waiting list, use this call after you call `GET WaitlistEntries` and determine the ID of the waiting list from which you are moving the client.
        /// * If adding a client to a class and using a pricing option that the client has already purchased, use this call after you call `GET ClientServices` to determine the ID of the pricing option that the client wants to use.
        /// If you add a client to a class and the client purchases a new pricing option, use `GET Services`, `GET Classes`, and then `POST CheckoutShoppingCart` in place of this call.
        /// This endpoint also supports cross-regional class bookings. If you want to perform a cross-regional class booking, set `CrossRegionalBooking` to `true`. This endpoint does not support adding a user to a waiting list using a cross-regional client pricing option(service). Cross-regional booking workflows do not support client service scheduling restrictions.
        /// When performing a cross-regional class booking, this endpoint loops through the first ten sites that the client is associated with, looks for client pricing options at each of those sites, and then uses the oldest client pricing option found.It is important to note that this endpoint only loops through a maximum of ten associated client sites. If a `ClientID` is associated with more than ten sites in an organization, this endpoint only loops through the first ten.If you know that a client has a client service at another site, you can specify that site using the `CrossRegionalBookingClientServiceSiteId` query parameter.
        /// If you perform a cross-regional booking, two additional fields are included in the `SessionType` object of the response:.
        /// * `SiteID`, which specifies where the client service is coming from.
        /// * `CrossRegionalBookingPerformed`, a Boolean field that is set to `true`.
        /// As a prerequisite to using this endpoint, your `SourceName` must have been granted access to the organization to which the site belongs.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassResponse> ClassAddClientToClassAsync(
                Models.MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/addclienttoclass");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassControllerAddClientToClassResponse>(response.Body);
        }

        /// <summary>
        /// Get class schedules.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassScheduleIds">Optional parameter: The class schedule IDs.  <br />Default: **all**.</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the range. Return any active enrollments that occur on or before this day.  <br />Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: The location IDs.   <br />Default: **all**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: The program IDs.   <br />Default: **all**.</param>
        /// <param name="requestSessionTypeIds">Optional parameter: The session type IDs.   <br />Default: **all**.</param>
        /// <param name="requestStaffIds">Optional parameter: The staff IDs.   <br />Default: **all**.</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the range. Return any active enrollments that occur on or after this day.  <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassSchedulesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassSchedulesResponse ClassGetClassSchedules(
                string siteId,
                string version,
                string authorization = null,
                List<int> requestClassScheduleIds = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                List<int> requestSessionTypeIds = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassSchedulesResponse> t = this.ClassGetClassSchedulesAsync(siteId, version, authorization, requestClassScheduleIds, requestEndDate, requestLimit, requestLocationIds, requestOffset, requestProgramIds, requestSessionTypeIds, requestStaffIds, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get class schedules.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassScheduleIds">Optional parameter: The class schedule IDs.  <br />Default: **all**.</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the range. Return any active enrollments that occur on or before this day.  <br />Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: The location IDs.   <br />Default: **all**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: The program IDs.   <br />Default: **all**.</param>
        /// <param name="requestSessionTypeIds">Optional parameter: The session type IDs.   <br />Default: **all**.</param>
        /// <param name="requestStaffIds">Optional parameter: The staff IDs.   <br />Default: **all**.</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the range. Return any active enrollments that occur on or after this day.  <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassSchedulesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassSchedulesResponse> ClassGetClassSchedulesAsync(
                string siteId,
                string version,
                string authorization = null,
                List<int> requestClassScheduleIds = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                List<int> requestSessionTypeIds = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/classschedules");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.classScheduleIds", requestClassScheduleIds },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.locationIds", requestLocationIds },
                { "request.offset", requestOffset },
                { "request.programIds", requestProgramIds },
                { "request.sessionTypeIds", requestSessionTypeIds },
                { "request.staffIds", requestStaffIds },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetClassSchedulesResponse>(response.Body);
        }

        /// <summary>
        /// Returns a list of waiting list entries for a specified class schedule or class. The request requires staff credentials and either a class schedule ID or class ID.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassIds">Optional parameter: The requested class IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request. <br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all ClassIds**.</param>
        /// <param name="requestClassScheduleIds">Optional parameter: The requested class schedule IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request.<br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all ClassScheduleIds**.</param>
        /// <param name="requestClientIds">Optional parameter: The requested client IDs.<br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all ClientIds**.</param>
        /// <param name="requestHidePastEntries">Optional parameter: When `true`, indicates that past waiting list entries are hidden from clients.<br />  When `false`, indicates that past entries are not hidden from clients.<br />  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestWaitlistEntryIds">Optional parameter: The requested waiting list entry IDs.<br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all WaitlistEntryIds**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesResponse ClassGetWaitlistEntries(
                string siteId,
                string version,
                string authorization = null,
                List<int> requestClassIds = null,
                List<int> requestClassScheduleIds = null,
                List<string> requestClientIds = null,
                bool? requestHidePastEntries = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestWaitlistEntryIds = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesResponse> t = this.ClassGetWaitlistEntriesAsync(siteId, version, authorization, requestClassIds, requestClassScheduleIds, requestClientIds, requestHidePastEntries, requestLimit, requestOffset, requestWaitlistEntryIds);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Returns a list of waiting list entries for a specified class schedule or class. The request requires staff credentials and either a class schedule ID or class ID.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassIds">Optional parameter: The requested class IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request. <br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all ClassIds**.</param>
        /// <param name="requestClassScheduleIds">Optional parameter: The requested class schedule IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request.<br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all ClassScheduleIds**.</param>
        /// <param name="requestClientIds">Optional parameter: The requested client IDs.<br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all ClientIds**.</param>
        /// <param name="requestHidePastEntries">Optional parameter: When `true`, indicates that past waiting list entries are hidden from clients.<br />  When `false`, indicates that past entries are not hidden from clients.<br />  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestWaitlistEntryIds">Optional parameter: The requested waiting list entry IDs.<br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all WaitlistEntryIds**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesResponse> ClassGetWaitlistEntriesAsync(
                string siteId,
                string version,
                string authorization = null,
                List<int> requestClassIds = null,
                List<int> requestClassScheduleIds = null,
                List<string> requestClientIds = null,
                bool? requestHidePastEntries = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestWaitlistEntryIds = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/waitlistentries");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.classIds", requestClassIds },
                { "request.classScheduleIds", requestClassScheduleIds },
                { "request.clientIds", requestClientIds },
                { "request.hidePastEntries", requestHidePastEntries },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.waitlistEntryIds", requestWaitlistEntryIds },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetWaitlistEntriesResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint does not return a response. If a call to this endpoint results in a 200 OK HTTP status code, then the call was successful.
        /// </summary>
        /// <param name="requestWaitlistEntryIds">Required parameter: A list of waiting list IDs to remove from waiting lists..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object ClassRemoveFromWaitlist(
                List<int> requestWaitlistEntryIds,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<object> t = this.ClassRemoveFromWaitlistAsync(requestWaitlistEntryIds, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint does not return a response. If a call to this endpoint results in a 200 OK HTTP status code, then the call was successful.
        /// </summary>
        /// <param name="requestWaitlistEntryIds">Required parameter: A list of waiting list IDs to remove from waiting lists..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> ClassRemoveFromWaitlistAsync(
                List<int> requestWaitlistEntryIds,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/removefromwaitlist");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.waitlistEntryIds", requestWaitlistEntryIds },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Post(queryBuilder.ToString(), headers, null, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return response.Body;
        }

        /// <summary>
        /// Substitute a class teacher.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse ClassSubstituteClassTeacher(
                Models.MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse> t = this.ClassSubstituteClassTeacherAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Substitute a class teacher.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse> ClassSubstituteClassTeacherAsync(
                Models.MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/substituteclassteacher");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse>(response.Body);
        }

        /// <summary>
        /// Remove a clients from a classes.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesResponse ClassRemoveClientsFromClasses(
                Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesResponse> t = this.ClassRemoveClientsFromClassesAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Remove a clients from a classes.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesResponse> ClassRemoveClientsFromClassesAsync(
                Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/removeclientsfromclasses");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientsFromClassesResponse>(response.Body);
        }

        /// <summary>
        /// Fetch the list of the course for a studio.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="getCoursesRequestCourseIDs">Optional parameter: (optional) The requested course IDs..</param>
        /// <param name="getCoursesRequestEndDate">Optional parameter: The end date range. Any active courses that are on or before this day.  <br />(optional) Defaults to StartDate..</param>
        /// <param name="getCoursesRequestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="getCoursesRequestLocationIDs">Optional parameter: (optional) The requested locations..</param>
        /// <param name="getCoursesRequestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="getCoursesRequestProgramIDs">Optional parameter: (optional) The requested program IDs..</param>
        /// <param name="getCoursesRequestSemesterIDs">Optional parameter: (optional) The requested semester IDs..</param>
        /// <param name="getCoursesRequestStaffIDs">Optional parameter: (optional) The requested StaffIDs..</param>
        /// <param name="getCoursesRequestStartDate">Optional parameter: The start date range. Any active courses that are on or after this day.  <br />(optional) Defaults to today..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesReponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesReponse ClassGetCourses(
                string siteId,
                string version,
                string authorization = null,
                List<long> getCoursesRequestCourseIDs = null,
                DateTime? getCoursesRequestEndDate = null,
                int? getCoursesRequestLimit = null,
                List<int> getCoursesRequestLocationIDs = null,
                int? getCoursesRequestOffset = null,
                List<int> getCoursesRequestProgramIDs = null,
                List<int> getCoursesRequestSemesterIDs = null,
                List<long> getCoursesRequestStaffIDs = null,
                DateTime? getCoursesRequestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesReponse> t = this.ClassGetCoursesAsync(siteId, version, authorization, getCoursesRequestCourseIDs, getCoursesRequestEndDate, getCoursesRequestLimit, getCoursesRequestLocationIDs, getCoursesRequestOffset, getCoursesRequestProgramIDs, getCoursesRequestSemesterIDs, getCoursesRequestStaffIDs, getCoursesRequestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Fetch the list of the course for a studio.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="getCoursesRequestCourseIDs">Optional parameter: (optional) The requested course IDs..</param>
        /// <param name="getCoursesRequestEndDate">Optional parameter: The end date range. Any active courses that are on or before this day.  <br />(optional) Defaults to StartDate..</param>
        /// <param name="getCoursesRequestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="getCoursesRequestLocationIDs">Optional parameter: (optional) The requested locations..</param>
        /// <param name="getCoursesRequestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="getCoursesRequestProgramIDs">Optional parameter: (optional) The requested program IDs..</param>
        /// <param name="getCoursesRequestSemesterIDs">Optional parameter: (optional) The requested semester IDs..</param>
        /// <param name="getCoursesRequestStaffIDs">Optional parameter: (optional) The requested StaffIDs..</param>
        /// <param name="getCoursesRequestStartDate">Optional parameter: The start date range. Any active courses that are on or after this day.  <br />(optional) Defaults to today..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesReponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesReponse> ClassGetCoursesAsync(
                string siteId,
                string version,
                string authorization = null,
                List<long> getCoursesRequestCourseIDs = null,
                DateTime? getCoursesRequestEndDate = null,
                int? getCoursesRequestLimit = null,
                List<int> getCoursesRequestLocationIDs = null,
                int? getCoursesRequestOffset = null,
                List<int> getCoursesRequestProgramIDs = null,
                List<int> getCoursesRequestSemesterIDs = null,
                List<long> getCoursesRequestStaffIDs = null,
                DateTime? getCoursesRequestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/courses");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "getCoursesRequest.courseIDs", getCoursesRequestCourseIDs },
                { "getCoursesRequest.endDate", getCoursesRequestEndDate.HasValue ? getCoursesRequestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "getCoursesRequest.limit", getCoursesRequestLimit },
                { "getCoursesRequest.locationIDs", getCoursesRequestLocationIDs },
                { "getCoursesRequest.offset", getCoursesRequestOffset },
                { "getCoursesRequest.programIDs", getCoursesRequestProgramIDs },
                { "getCoursesRequest.semesterIDs", getCoursesRequestSemesterIDs },
                { "getCoursesRequest.staffIDs", getCoursesRequestStaffIDs },
                { "getCoursesRequest.startDate", getCoursesRequestStartDate.HasValue ? getCoursesRequestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesReponse>(response.Body);
        }

        /// <summary>
        /// Cancels a single class instance.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassResponse ClassCancelSingleClass(
                Models.MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassRequest request,
                string siteId,
                string version,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassResponse> t = this.ClassCancelSingleClassAsync(request, siteId, version, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Cancels a single class instance.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassResponse> ClassCancelSingleClassAsync(
                Models.MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassRequest request,
                string siteId,
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/cancelsingleclass");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassResponse>(response.Body);
        }

        /// <summary>
        /// Fetch the list of the Semesters.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: Get Active semesters.</param>
        /// <param name="requestEndDate">Optional parameter: Filter semesters with end date.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSemesterIDs">Optional parameter: Get with semester ids.</param>
        /// <param name="requestStartDate">Optional parameter: Filter semesters with start date.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetSemestersResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClassControllerGetSemestersResponse ClassGetSemestersAsync(
                string siteId,
                string version,
                string authorization = null,
                bool? requestActive = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSemesterIDs = null,
                DateTime? requestStartDate = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetSemestersResponse> t = this.ClassGetSemestersAsyncAsync(siteId, version, authorization, requestActive, requestEndDate, requestLimit, requestOffset, requestSemesterIDs, requestStartDate);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Fetch the list of the Semesters.
        /// </summary>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="version">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: Get Active semesters.</param>
        /// <param name="requestEndDate">Optional parameter: Filter semesters with end date.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSemesterIDs">Optional parameter: Get with semester ids.</param>
        /// <param name="requestStartDate">Optional parameter: Filter semesters with start date.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClassControllerGetSemestersResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetSemestersResponse> ClassGetSemestersAsyncAsync(
                string siteId,
                string version,
                string authorization = null,
                bool? requestActive = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSemesterIDs = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/class/semesters");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.active", requestActive },
                { "request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.semesterIDs", requestSemesterIDs },
                { "request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetSemestersResponse>(response.Body);
        }
    }
}