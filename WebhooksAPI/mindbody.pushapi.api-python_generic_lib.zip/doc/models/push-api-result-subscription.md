
# Push Api Result Subscription

A result returned for every request to the push API

## Structure

`PushApiResultSubscription`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `is_success` | `bool` | Optional | - |
| `value` | [`Subscription`](../../doc/models/subscription.md) | Optional | A webhook subscription |
| `error_information` | [`List of PushApiError`](../../doc/models/push-api-error.md) | Optional | - |

## Example (as JSON)

```json
{
  "isSuccess": null,
  "value": null,
  "errorInformation": null
}
```

