
# Push Api Result Get Subscriptions Response

A result returned for every request to the push API

## Structure

`PushApiResultGetSubscriptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `is_success` | `bool` | Optional | - |
| `value` | [`GetSubscriptionsResponse`](../../doc/models/get-subscriptions-response.md) | Optional | A wrapper for a get subscriptions request |
| `error_information` | [`List[PushApiError]`](../../doc/models/push-api-error.md) | Optional | - |

## Example (as JSON)

```json
{
  "isSuccess": false,
  "value": {
    "items": [
      {
        "subscriptionId": "00000f59-0000-0000-0000-000000000000",
        "status": "status1",
        "subscriptionCreationDateTime": "2016-03-13T12:52:32.123Z",
        "statusChangeDate": "2016-03-13T12:52:32.123Z",
        "statusChangeMessage": "statusChangeMessage1"
      },
      {
        "subscriptionId": "00000f5a-0000-0000-0000-000000000000",
        "status": "status2",
        "subscriptionCreationDateTime": "2016-03-13T12:52:32.123Z",
        "statusChangeDate": "2016-03-13T12:52:32.123Z",
        "statusChangeMessage": "statusChangeMessage2"
      },
      {
        "subscriptionId": "00000f5b-0000-0000-0000-000000000000",
        "status": "status3",
        "subscriptionCreationDateTime": "2016-03-13T12:52:32.123Z",
        "statusChangeDate": "2016-03-13T12:52:32.123Z",
        "statusChangeMessage": "statusChangeMessage3"
      }
    ]
  },
  "errorInformation": [
    {
      "errorCode": 63,
      "errorMessage": "errorMessage7",
      "errorType": "errorType1"
    },
    {
      "errorCode": 64,
      "errorMessage": "errorMessage8",
      "errorType": "errorType0"
    }
  ]
}
```

