
# Push Api Result Get Subscriptions Response

A result returned for every request to the push API

## Structure

`PushApiResultGetSubscriptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error_information` | [`List[PushApiError]`](../../doc/models/push-api-error.md) | Optional | - |
| `is_success` | `bool` | Optional | - |
| `value` | [`GetSubscriptionsResponse`](../../doc/models/get-subscriptions-response.md) | Optional | A wrapper for a get subscriptions request |

## Example (as JSON)

```json
{
  "errorInformation": [
    {
      "errorCode": 122,
      "errorMessage": "errorMessage6",
      "errorType": "errorType8"
    }
  ],
  "isSuccess": false,
  "value": {
    "items": [
      {
        "eventIds": [
          "eventIds2"
        ],
        "eventSchemaVersion": 181.18,
        "referenceId": "referenceId0",
        "status": "status0",
        "statusChangeDate": "2016-03-13T12:52:32.123Z"
      },
      {
        "eventIds": [
          "eventIds2"
        ],
        "eventSchemaVersion": 181.18,
        "referenceId": "referenceId0",
        "status": "status0",
        "statusChangeDate": "2016-03-13T12:52:32.123Z"
      },
      {
        "eventIds": [
          "eventIds2"
        ],
        "eventSchemaVersion": 181.18,
        "referenceId": "referenceId0",
        "status": "status0",
        "statusChangeDate": "2016-03-13T12:52:32.123Z"
      }
    ]
  }
}
```

