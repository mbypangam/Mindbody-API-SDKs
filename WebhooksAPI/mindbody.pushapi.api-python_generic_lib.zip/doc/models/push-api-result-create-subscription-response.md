
# Push Api Result Create Subscription Response

A result returned for every request to the push API

## Structure

`PushApiResultCreateSubscriptionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `is_success` | `bool` | Optional | - |
| `value` | [`CreateSubscriptionResponse`](../../doc/models/create-subscription-response.md) | Optional | The created subscription |
| `error_information` | [`List of PushApiError`](../../doc/models/push-api-error.md) | Optional | - |

## Example (as JSON)

```json
{
  "value": null
}
```

