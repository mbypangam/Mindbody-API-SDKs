
# Create Subscription Request

Request used to add a webhook subscription for the requesting developer

## Structure

`CreateSubscriptionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `event_ids` | `List of string` | Optional | The events you want to be sent to the specified `webhookUrl`. |
| `event_schema_version` | `float` | Optional | The event schema version for this subscription. `1` is currently the only accepted value. |
| `reference_id` | `string` | Optional | An arbitrary field that you can set to a value of your choice. Mindbody stores and returns this value for the subscription you are creating. Most commonly, this field stores a GUID that you can use in your application. |
| `webhook_url` | `string` | Optional | The URL that Mindbody posts the event notifications to. Webhook URL Requirements lists considerations and requirements for this URL. |

## Example (as JSON)

```json
{
  "eventIds": [
    "eventIds6",
    "eventIds7"
  ],
  "eventSchemaVersion": 30.6,
  "referenceId": "referenceId8",
  "webhookUrl": "webhookUrl2"
}
```

