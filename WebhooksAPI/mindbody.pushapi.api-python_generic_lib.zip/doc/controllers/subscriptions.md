# Subscriptions

```python
subscriptions_controller = client.subscriptions
```

## Class Name

`SubscriptionsController`

## Methods

* [Subscriptions Get](../../doc/controllers/subscriptions.md#subscriptions-get)
* [Subscriptions Create](../../doc/controllers/subscriptions.md#subscriptions-create)
* [Subscriptions Get 1](../../doc/controllers/subscriptions.md#subscriptions-get-1)
* [Subscriptions Delete](../../doc/controllers/subscriptions.md#subscriptions-delete)
* [Subscriptions Patch](../../doc/controllers/subscriptions.md#subscriptions-patch)


# Subscriptions Get

This endpoint searches for subscriptions associated with your developer portal account:

You can retrieve a specific subscription by calling GET(by ID).

```python
def subscriptions_get(self)
```

## Response Type

[`PushApiResultGetSubscriptionsResponse`](../../doc/models/push-api-result-get-subscriptions-response.md)

## Example Usage

```python
result = subscriptions_controller.subscriptions_get()
```


# Subscriptions Create

This endpoint creates a pending subscription that is linked to your developer portal account. After you have created a subscription, you can activate it using the PATCH Subscription endpoint.

```python
def subscriptions_create(self,
                        request)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`CreateSubscriptionRequest`](../../doc/models/create-subscription-request.md) | Body, Required | - |

## Response Type

[`PushApiResultCreateSubscriptionResponse`](../../doc/models/push-api-result-create-subscription-response.md)

## Example Usage

```python
request = CreateSubscriptionRequest()

result = subscriptions_controller.subscriptions_create(request)
```


# Subscriptions Get 1

This endpoint finds and returns the single subscription associated with the passed ID.

```python
def subscriptions_get_1(self,
                       subscription_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscription_id` | `string` | Template, Required | Returns the single location identified by this ID (a GUID). |

## Response Type

[`PushApiResultSubscription`](../../doc/models/push-api-result-subscription.md)

## Example Usage

```python
subscription_id = 'subscriptionId0'

result = subscriptions_controller.subscriptions_get_1(subscription_id)
```


# Subscriptions Delete

This endpoint deactivates a subscription associated with the passed ID.

```python
def subscriptions_delete(self,
                        subscription_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscription_id` | `string` | Template, Required | The subscription ID (a GUID) that you are deactivating. |

## Response Type

[`PushApiResultDeactivateSubscriptionResponse`](../../doc/models/push-api-result-deactivate-subscription-response.md)

## Example Usage

```python
subscription_id = 'subscriptionId0'

result = subscriptions_controller.subscriptions_delete(subscription_id)
```


# Subscriptions Patch

This endpoint can activate a new subscription or reactivate an inactive subscription that is associated with your developer portal account, by updating the status. You can also update your subscription’s eventIds, eventSchemaVersion, referenceId, and webhookUrl.

```python
def subscriptions_patch(self,
                       subscription_id,
                       request)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscription_id` | `string` | Template, Required | The subscription’s ID (a GUID). |
| `request` | [`PatchSubscriptionRequest`](../../doc/models/patch-subscription-request.md) | Body, Required | The patch request for the given subscription. |

## Response Type

[`PushApiResultSubscription`](../../doc/models/push-api-result-subscription.md)

## Example Usage

```python
subscription_id = 'subscriptionId0'
request = PatchSubscriptionRequest()

result = subscriptions_controller.subscriptions_patch(subscription_id, request)
```

