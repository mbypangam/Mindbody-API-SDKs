# Subscriptions

```python
subscriptions_controller = client.subscriptions
```

## Class Name

`SubscriptionsController`

## Methods

* [Get Subscriptions](../../doc/controllers/subscriptions.md#get-subscriptions)
* [Create Subscription](../../doc/controllers/subscriptions.md#create-subscription)
* [Get Subscription](../../doc/controllers/subscriptions.md#get-subscription)
* [Delete Subscription](../../doc/controllers/subscriptions.md#delete-subscription)
* [Patch Subscription](../../doc/controllers/subscriptions.md#patch-subscription)


# Get Subscriptions

This endpoint searches for subscriptions associated with your developer portal account:

You can retrieve a specific subscription by calling GET(by ID).

```python
def get_subscriptions(self)
```

## Response Type

[`PushApiResultGetSubscriptionsResponse`](../../doc/models/push-api-result-get-subscriptions-response.md)

## Example Usage

```python
result = subscriptions_controller.get_subscriptions()
print(result)
```


# Create Subscription

This endpoint creates a pending subscription that is linked to your developer portal account. After you have created a subscription, you can activate it using the PATCH Subscription endpoint.

```python
def create_subscription(self,
                       request)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`CreateSubscriptionRequest`](../../doc/models/create-subscription-request.md) | Body, Required | - |

## Response Type

[`PushApiResultCreateSubscriptionResponse`](../../doc/models/push-api-result-create-subscription-response.md)

## Example Usage

```python
request = CreateSubscriptionRequest()

result = subscriptions_controller.create_subscription(request)
print(result)
```


# Get Subscription

This endpoint finds and returns the single subscription associated with the passed ID.

```python
def get_subscription(self,
                    subscription_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscription_id` | `str` | Template, Required | Returns the single location identified by this ID (a GUID). |

## Response Type

[`PushApiResultSubscription`](../../doc/models/push-api-result-subscription.md)

## Example Usage

```python
subscription_id = 'subscriptionId0'

result = subscriptions_controller.get_subscription(subscription_id)
print(result)
```


# Delete Subscription

This endpoint deactivates a subscription associated with the passed ID.

```python
def delete_subscription(self,
                       subscription_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscription_id` | `str` | Template, Required | The subscription ID (a GUID) that you are deactivating. |

## Response Type

[`PushApiResultDeactivateSubscriptionResponse`](../../doc/models/push-api-result-deactivate-subscription-response.md)

## Example Usage

```python
subscription_id = 'subscriptionId0'

result = subscriptions_controller.delete_subscription(subscription_id)
print(result)
```


# Patch Subscription

This endpoint can activate a new subscription or reactivate an inactive subscription that is associated with your developer portal account, by updating the status. You can also update your subscription’s eventIds, eventSchemaVersion, referenceId, and webhookUrl.

```python
def patch_subscription(self,
                      subscription_id,
                      request)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscription_id` | `str` | Template, Required | The subscription’s ID (a GUID). |
| `request` | [`PatchSubscriptionRequest`](../../doc/models/patch-subscription-request.md) | Body, Required | The patch request for the given subscription. |

## Response Type

[`PushApiResultSubscription`](../../doc/models/push-api-result-subscription.md)

## Example Usage

```python
subscription_id = 'subscriptionId0'

request = PatchSubscriptionRequest()

result = subscriptions_controller.patch_subscription(
    subscription_id,
    request
)
print(result)
```

