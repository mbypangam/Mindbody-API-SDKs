# Metrics

```python
metrics_controller = client.metrics
```

## Class Name

`MetricsController`


# Get Metrics

This endpoint gets metrics for all the subscriptions associated with your Public API developer account.

```python
def get_metrics(self)
```

## Response Type

[`GetMetricsResponse`](../../doc/models/get-metrics-response.md)

## Example Usage

```python
result = metrics_controller.get_metrics()
print(result)
```

