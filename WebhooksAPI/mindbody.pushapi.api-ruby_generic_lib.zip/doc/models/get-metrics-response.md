
# Get Metrics Response

A wrapper for returning subscription metrics to API users

## Structure

`GetMetricsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `items` | [`Array<Metric>`](../../doc/models/metric.md) | Optional | Contains the metrics for the passed subscription |

## Example (as JSON)

```json
{
  "items": [
    {
      "subscriptionId": "00001aa7-0000-0000-0000-000000000000",
      "status": "status1",
      "statusChangeDate": "2016-03-13T12:52:32.123Z",
      "creationDateTime": "2016-03-13T12:52:32.123Z",
      "messagesAttempted": 161
    },
    {
      "subscriptionId": "00001aa6-0000-0000-0000-000000000000",
      "status": "status0",
      "statusChangeDate": "2016-03-13T12:52:32.123Z",
      "creationDateTime": "2016-03-13T12:52:32.123Z",
      "messagesAttempted": 160
    }
  ]
}
```

