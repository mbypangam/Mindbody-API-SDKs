
# Push Api Result Get Subscriptions Response

A result returned for every request to the push API

## Structure

`PushApiResultGetSubscriptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error_information` | [`Array<PushApiError>`](../../doc/models/push-api-error.md) | Optional | - |
| `is_success` | `TrueClass \| FalseClass` | Optional | - |
| `value` | [`GetSubscriptionsResponse`](../../doc/models/get-subscriptions-response.md) | Optional | A wrapper for a get subscriptions request |

## Example (as JSON)

```json
{
  "errorInformation": [
    {
      "errorCode": 63,
      "errorMessage": "errorMessage7",
      "errorType": "errorType1"
    },
    {
      "errorCode": 64,
      "errorMessage": "errorMessage8",
      "errorType": "errorType0"
    }
  ],
  "isSuccess": false,
  "value": {
    "items": [
      {
        "eventIds": [
          "eventIds1"
        ],
        "eventSchemaVersion": 251.99,
        "referenceId": "referenceId1",
        "status": "status1",
        "statusChangeDate": "2016-03-13T12:52:32.123Z"
      },
      {
        "eventIds": [
          "eventIds2",
          "eventIds3"
        ],
        "eventSchemaVersion": 252.0,
        "referenceId": "referenceId2",
        "status": "status2",
        "statusChangeDate": "2016-03-13T12:52:32.123Z"
      },
      {
        "eventIds": [
          "eventIds3",
          "eventIds4",
          "eventIds5"
        ],
        "eventSchemaVersion": 252.01,
        "referenceId": "referenceId3",
        "status": "status3",
        "statusChangeDate": "2016-03-13T12:52:32.123Z"
      }
    ]
  }
}
```

