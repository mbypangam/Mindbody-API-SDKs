
# Push Api Result Get Subscriptions Response

A result returned for every request to the push API

## Structure

`PushApiResultGetSubscriptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `is_success` | `TrueClass\|FalseClass` | Optional | - |
| `value` | [`GetSubscriptionsResponse`](../../doc/models/get-subscriptions-response.md) | Optional | A wrapper for a get subscriptions request |
| `error_information` | [`Array<PushApiError>`](../../doc/models/push-api-error.md) | Optional | - |

## Example (as JSON)

```json
{
  "value": null
}
```

