
# Push Api Result Subscription

A result returned for every request to the push API

## Structure

`PushApiResultSubscription`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error_information` | [`Array<PushApiError>`](../../doc/models/push-api-error.md) | Optional | - |
| `is_success` | `TrueClass\|FalseClass` | Optional | - |
| `value` | [`Subscription`](../../doc/models/subscription.md) | Optional | A webhook subscription |

## Example (as JSON)

```json
{
  "errorInformation": null,
  "isSuccess": null,
  "value": null
}
```

