
# Push Api Result Subscription

A result returned for every request to the push API

## Structure

`PushApiResultSubscription`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `is_success` | `TrueClass \| FalseClass` | Optional | - |
| `value` | [`Subscription`](../../doc/models/subscription.md) | Optional | A webhook subscription |
| `error_information` | [`Array<PushApiError>`](../../doc/models/push-api-error.md) | Optional | - |

## Example (as JSON)

```json
{
  "isSuccess": false,
  "value": {
    "subscriptionId": "0000053e-0000-0000-0000-000000000000",
    "status": "status4",
    "subscriptionCreationDateTime": "2016-03-13T12:52:32.123Z",
    "statusChangeDate": "2016-03-13T12:52:32.123Z",
    "statusChangeMessage": "statusChangeMessage4"
  },
  "errorInformation": [
    {
      "errorCode": 63,
      "errorMessage": "errorMessage7",
      "errorType": "errorType1"
    },
    {
      "errorCode": 64,
      "errorMessage": "errorMessage8",
      "errorType": "errorType0"
    }
  ]
}
```

