# Subscriptions

```ruby
subscriptions_controller = client.subscriptions
```

## Class Name

`SubscriptionsController`

## Methods

* [Get Subscriptions](../../doc/controllers/subscriptions.md#get-subscriptions)
* [Create Subscription](../../doc/controllers/subscriptions.md#create-subscription)
* [Delete Subscription](../../doc/controllers/subscriptions.md#delete-subscription)
* [Get Subscription](../../doc/controllers/subscriptions.md#get-subscription)
* [Patch Subscription](../../doc/controllers/subscriptions.md#patch-subscription)


# Get Subscriptions

This endpoint searches for subscriptions associated with your developer portal account:

You can retrieve a specific subscription by calling GET(by ID).

:information_source: **Note** This endpoint does not require authentication.

```ruby
def get_subscriptions
```

## Response Type

[`PushApiResultGetSubscriptionsResponse`](../../doc/models/push-api-result-get-subscriptions-response.md)

## Example Usage

```ruby
result = subscriptions_controller.get_subscriptions
```


# Create Subscription

This endpoint creates a pending subscription that is linked to your developer portal account. After you have created a subscription, you can activate it using the PATCH Subscription endpoint.

:information_source: **Note** This endpoint does not require authentication.

```ruby
def create_subscription(request)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`CreateSubscriptionRequest`](../../doc/models/create-subscription-request.md) | Body, Required | - |

## Response Type

[`PushApiResultCreateSubscriptionResponse`](../../doc/models/push-api-result-create-subscription-response.md)

## Example Usage

```ruby
request = CreateSubscriptionRequest.new

result = subscriptions_controller.create_subscription(request)
```


# Delete Subscription

This endpoint deactivates a subscription associated with the passed ID.

:information_source: **Note** This endpoint does not require authentication.

```ruby
def delete_subscription(subscription_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscription_id` | `String` | Template, Required | The subscription ID (a GUID) that you are deactivating. |

## Response Type

[`PushApiResultDeactivateSubscriptionResponse`](../../doc/models/push-api-result-deactivate-subscription-response.md)

## Example Usage

```ruby
subscription_id = 'subscriptionId0'

result = subscriptions_controller.delete_subscription(subscription_id)
```


# Get Subscription

This endpoint finds and returns the single subscription associated with the passed ID.

:information_source: **Note** This endpoint does not require authentication.

```ruby
def get_subscription(subscription_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscription_id` | `String` | Template, Required | Returns the single location identified by this ID (a GUID). |

## Response Type

[`PushApiResultSubscription`](../../doc/models/push-api-result-subscription.md)

## Example Usage

```ruby
subscription_id = 'subscriptionId0'

result = subscriptions_controller.get_subscription(subscription_id)
```


# Patch Subscription

This endpoint can activate a new subscription or reactivate an inactive subscription that is associated with your developer portal account, by updating the status. You can also update your subscription’s eventIds, eventSchemaVersion, referenceId, and webhookUrl.

:information_source: **Note** This endpoint does not require authentication.

```ruby
def patch_subscription(subscription_id,
                       request)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscription_id` | `String` | Template, Required | The subscription’s ID (a GUID). |
| `request` | [`PatchSubscriptionRequest`](../../doc/models/patch-subscription-request.md) | Body, Required | The patch request for the given subscription. |

## Response Type

[`PushApiResultSubscription`](../../doc/models/push-api-result-subscription.md)

## Example Usage

```ruby
subscription_id = 'subscriptionId0'

request = PatchSubscriptionRequest.new

result = subscriptions_controller.patch_subscription(
  subscription_id,
  request
)
```

