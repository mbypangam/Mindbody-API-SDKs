# Metrics

```ruby
metrics_controller = client.metrics
```

## Class Name

`MetricsController`


# Get Metrics

This endpoint gets metrics for all the subscriptions associated with your Public API developer account.

```ruby
def get_metrics
```

## Response Type

[`GetMetricsResponse`](../../doc/models/get-metrics-response.md)

## Example Usage

```ruby
result = metrics_controller.get_metrics()
```

