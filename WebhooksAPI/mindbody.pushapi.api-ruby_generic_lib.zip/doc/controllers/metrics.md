# Metrics

```ruby
metrics_controller = client.metrics
```

## Class Name

`MetricsController`


# Metrics Get

This endpoint gets metrics for all the subscriptions associated with your Public API developer account.

```ruby
def metrics_get
```

## Response Type

[`PushApiResultGetMetricsResponse`](../../doc/models/push-api-result-get-metrics-response.md)

## Example Usage

```ruby
result = metrics_controller.metrics_get()
```

