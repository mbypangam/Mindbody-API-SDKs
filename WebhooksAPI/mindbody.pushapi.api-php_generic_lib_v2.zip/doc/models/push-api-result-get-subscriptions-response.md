
# Push Api Result Get Subscriptions Response

A result returned for every request to the push API

## Structure

`PushApiResultGetSubscriptionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `errorInformation` | [`?(PushApiError[])`](../../doc/models/push-api-error.md) | Optional | - | getErrorInformation(): ?array | setErrorInformation(?array errorInformation): void |
| `isSuccess` | `?bool` | Optional | - | getIsSuccess(): ?bool | setIsSuccess(?bool isSuccess): void |
| `value` | [`?GetSubscriptionsResponse`](../../doc/models/get-subscriptions-response.md) | Optional | A wrapper for a get subscriptions request | getValue(): ?GetSubscriptionsResponse | setValue(?GetSubscriptionsResponse value): void |

## Example (as JSON)

```json
{
  "errorInformation": [
    {
      "errorCode": 122,
      "errorMessage": "errorMessage6",
      "errorType": "errorType8"
    }
  ],
  "isSuccess": false,
  "value": {
    "items": [
      {
        "eventIds": [
          "eventIds2"
        ],
        "eventSchemaVersion": 181.18,
        "referenceId": "referenceId0",
        "status": "status0",
        "statusChangeDate": "2016-03-13T12:52:32.123Z"
      },
      {
        "eventIds": [
          "eventIds2"
        ],
        "eventSchemaVersion": 181.18,
        "referenceId": "referenceId0",
        "status": "status0",
        "statusChangeDate": "2016-03-13T12:52:32.123Z"
      },
      {
        "eventIds": [
          "eventIds2"
        ],
        "eventSchemaVersion": 181.18,
        "referenceId": "referenceId0",
        "status": "status0",
        "statusChangeDate": "2016-03-13T12:52:32.123Z"
      }
    ]
  }
}
```

