
# Get Metrics Response

A wrapper for returning subscription metrics to API users

## Structure

`GetMetricsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `items` | [`?(Metric[])`](../../doc/models/metric.md) | Optional | Contains the metrics for the passed subscription | getItems(): ?array | setItems(?array items): void |

## Example (as JSON)

```json
{
  "items": [
    {
      "creationDateTime": "2016-03-13T12:52:32.123Z",
      "messagesAttempted": 10,
      "messagesDelivered": 166,
      "messagesFailed": 116,
      "messagesUndelivered": 232
    },
    {
      "creationDateTime": "2016-03-13T12:52:32.123Z",
      "messagesAttempted": 10,
      "messagesDelivered": 166,
      "messagesFailed": 116,
      "messagesUndelivered": 232
    }
  ]
}
```

