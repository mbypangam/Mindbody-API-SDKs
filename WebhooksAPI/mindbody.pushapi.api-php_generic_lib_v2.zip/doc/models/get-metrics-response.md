
# Get Metrics Response

A wrapper for returning subscription metrics to API users

## Structure

`GetMetricsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `items` | [`?(Metric[])`](../../doc/models/metric.md) | Optional | Contains the metrics for the passed subscription | getItems(): ?array | setItems(?array items): void |

## Example (as JSON)

```json
{
  "items": [
    {
      "creationDateTime": "2016-03-13T12:52:32.123Z",
      "messagesAttempted": 161,
      "messagesDelivered": 15,
      "messagesFailed": 221,
      "messagesUndelivered": 81,
      "status": "status1",
      "statusChangeDate": "2016-03-13T12:52:32.123Z",
      "subscriptionId": "00001aa7-0000-0000-0000-000000000000"
    },
    {
      "creationDateTime": "2016-03-13T12:52:32.123Z",
      "messagesAttempted": 160,
      "messagesDelivered": 16,
      "messagesFailed": 222,
      "messagesUndelivered": 82,
      "status": "status0",
      "statusChangeDate": "2016-03-13T12:52:32.123Z",
      "subscriptionId": "00001aa6-0000-0000-0000-000000000000"
    }
  ]
}
```

