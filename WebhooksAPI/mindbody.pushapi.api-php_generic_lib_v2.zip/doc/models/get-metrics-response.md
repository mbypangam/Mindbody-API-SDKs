
# Get Metrics Response

A wrapper for returning subscription metrics to API users

## Structure

`GetMetricsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `items` | [`?(Metric[])`](../../doc/models/metric.md) | Optional | Contains the metrics for the passed subscription | getItems(): ?array | setItems(?array items): void |

## Example (as JSON)

```json
{
  "items": null
}
```

