
# Patch Subscription Request

A request to patch update a subscription

## Structure

`PatchSubscriptionRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `eventIds` | `?(string[])` | Optional | A list of event IDs that you want to update or subscribe to. | getEventIds(): ?array | setEventIds(?array eventIds): void |
| `eventSchemaVersion` | `?float` | Optional | The event schema version associated with the subscription. Currently, this is always `1`. | getEventSchemaVersion(): ?float | setEventSchemaVersion(?float eventSchemaVersion): void |
| `referenceId` | `?string` | Optional | An arbitrary field that you can set to a value of your choice. Mindbody stores and returns this value for the subscription you are activating. Most commonly, this field stores a GUID that you can use in your application. | getReferenceId(): ?string | setReferenceId(?string referenceId): void |
| `status` | `?string` | Optional | The subscription’s current status, as of the last update. | getStatus(): ?string | setStatus(?string status): void |
| `webhookUrl` | `?string` | Optional | The URL registered as the target of the webhook deliveries. Mindbody posts the event notifications to this URL. Webhook URL Requirements lists considerations and requirements for this URL. | getWebhookUrl(): ?string | setWebhookUrl(?string webhookUrl): void |

## Example (as JSON)

```json
{
  "eventIds": [
    "eventIds6",
    "eventIds7"
  ],
  "eventSchemaVersion": 30.6,
  "referenceId": "referenceId8",
  "status": "status8",
  "webhookUrl": "webhookUrl2"
}
```

