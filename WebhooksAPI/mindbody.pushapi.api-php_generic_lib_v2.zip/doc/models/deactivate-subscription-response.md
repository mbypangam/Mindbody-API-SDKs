
# Deactivate Subscription Response

Returned after a subscription is deactivated

## Structure

`DeactivateSubscriptionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `deactivationDateTime` | `?\DateTime` | Optional | The UTC date and time when the deactivation took place. | getDeactivationDateTime(): ?\DateTime | setDeactivationDateTime(?\DateTime deactivationDateTime): void |
| `message` | `?string` | Optional | A message about the deactivation request. Unless an error occurs, this message always `"Subscription deactivated successfully."`. | getMessage(): ?string | setMessage(?string message): void |
| `referenceId` | `?string` | Optional | The subscription's reference ID, assigned when the subscription was created. | getReferenceId(): ?string | setReferenceId(?string referenceId): void |
| `subscriptionId` | `?string` | Optional | The subscription ID (a GUID). | getSubscriptionId(): ?string | setSubscriptionId(?string subscriptionId): void |

## Example (as JSON)

```json
{
  "deactivationDateTime": null,
  "message": null,
  "referenceId": null,
  "subscriptionId": null
}
```

