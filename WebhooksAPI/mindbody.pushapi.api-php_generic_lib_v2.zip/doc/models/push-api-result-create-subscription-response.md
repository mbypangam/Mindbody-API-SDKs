
# Push Api Result Create Subscription Response

A result returned for every request to the push API

## Structure

`PushApiResultCreateSubscriptionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `isSuccess` | `?bool` | Optional | - | getIsSuccess(): ?bool | setIsSuccess(?bool isSuccess): void |
| `value` | [`?CreateSubscriptionResponse`](../../doc/models/create-subscription-response.md) | Optional | The created subscription | getValue(): ?CreateSubscriptionResponse | setValue(?CreateSubscriptionResponse value): void |
| `errorInformation` | [`?(PushApiError[])`](../../doc/models/push-api-error.md) | Optional | - | getErrorInformation(): ?array | setErrorInformation(?array errorInformation): void |

## Example (as JSON)

```json
{
  "value": null
}
```

