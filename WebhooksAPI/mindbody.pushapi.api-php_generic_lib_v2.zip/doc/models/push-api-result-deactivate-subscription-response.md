
# Push Api Result Deactivate Subscription Response

A result returned for every request to the push API

## Structure

`PushApiResultDeactivateSubscriptionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `errorInformation` | [`?(PushApiError[])`](../../doc/models/push-api-error.md) | Optional | - | getErrorInformation(): ?array | setErrorInformation(?array errorInformation): void |
| `isSuccess` | `?bool` | Optional | - | getIsSuccess(): ?bool | setIsSuccess(?bool isSuccess): void |
| `value` | [`?DeactivateSubscriptionResponse`](../../doc/models/deactivate-subscription-response.md) | Optional | Returned after a subscription is deactivated | getValue(): ?DeactivateSubscriptionResponse | setValue(?DeactivateSubscriptionResponse value): void |

## Example (as JSON)

```json
{
  "errorInformation": null,
  "isSuccess": null,
  "value": null
}
```

