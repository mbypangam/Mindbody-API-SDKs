
# Push Api Result Deactivate Subscription Response

A result returned for every request to the push API

## Structure

`PushApiResultDeactivateSubscriptionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `isSuccess` | `?bool` | Optional | - | getIsSuccess(): ?bool | setIsSuccess(?bool isSuccess): void |
| `value` | [`?DeactivateSubscriptionResponse`](../../doc/models/deactivate-subscription-response.md) | Optional | Returned after a subscription is deactivated | getValue(): ?DeactivateSubscriptionResponse | setValue(?DeactivateSubscriptionResponse value): void |
| `errorInformation` | [`?(PushApiError[])`](../../doc/models/push-api-error.md) | Optional | - | getErrorInformation(): ?array | setErrorInformation(?array errorInformation): void |

## Example (as JSON)

```json
{
  "isSuccess": false,
  "value": {
    "message": "message2",
    "deactivationDateTime": "2016-03-13T12:52:32.123Z",
    "subscriptionId": "0000053e-0000-0000-0000-000000000000",
    "referenceId": "referenceId4"
  },
  "errorInformation": [
    {
      "errorCode": 63,
      "errorMessage": "errorMessage7",
      "errorType": "errorType1"
    },
    {
      "errorCode": 64,
      "errorMessage": "errorMessage8",
      "errorType": "errorType0"
    }
  ]
}
```

