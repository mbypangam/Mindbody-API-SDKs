
# Push Api Result Get Metrics Response

A result returned for every request to the push API

## Structure

`PushApiResultGetMetricsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `isSuccess` | `?bool` | Optional | - | getIsSuccess(): ?bool | setIsSuccess(?bool isSuccess): void |
| `value` | [`?GetMetricsResponse`](../../doc/models/get-metrics-response.md) | Optional | A wrapper for returning subscription metrics to API users | getValue(): ?GetMetricsResponse | setValue(?GetMetricsResponse value): void |
| `errorInformation` | [`?(PushApiError[])`](../../doc/models/push-api-error.md) | Optional | - | getErrorInformation(): ?array | setErrorInformation(?array errorInformation): void |

## Example (as JSON)

```json
{
  "value": null
}
```

