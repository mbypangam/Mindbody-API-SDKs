
# Get Subscriptions Response

A wrapper for a get subscriptions request

## Structure

`GetSubscriptionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `items` | [`?(Subscription[])`](../../doc/models/subscription.md) | Optional | A list of subscriptions | getItems(): ?array | setItems(?array items): void |

## Example (as JSON)

```json
{
  "items": [
    {
      "subscriptionId": "00001aa7-0000-0000-0000-000000000000",
      "status": "status1",
      "subscriptionCreationDateTime": "2016-03-13T12:52:32.123Z",
      "statusChangeDate": "2016-03-13T12:52:32.123Z",
      "statusChangeMessage": "statusChangeMessage9"
    },
    {
      "subscriptionId": "00001aa6-0000-0000-0000-000000000000",
      "status": "status0",
      "subscriptionCreationDateTime": "2016-03-13T12:52:32.123Z",
      "statusChangeDate": "2016-03-13T12:52:32.123Z",
      "statusChangeMessage": "statusChangeMessage0"
    }
  ]
}
```

