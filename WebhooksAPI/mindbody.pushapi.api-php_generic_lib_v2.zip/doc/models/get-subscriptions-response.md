
# Get Subscriptions Response

A wrapper for a get subscriptions request

## Structure

`GetSubscriptionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `items` | [`?(Subscription[])`](../../doc/models/subscription.md) | Optional | A list of subscriptions | getItems(): ?array | setItems(?array items): void |

## Example (as JSON)

```json
{
  "items": null
}
```

