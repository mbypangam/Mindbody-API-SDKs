
# Get Subscriptions Response

A wrapper for a get subscriptions request

## Structure

`GetSubscriptionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `items` | [`?(Subscription[])`](../../doc/models/subscription.md) | Optional | A list of subscriptions | getItems(): ?array | setItems(?array items): void |

## Example (as JSON)

```json
{
  "items": [
    {
      "eventIds": [
        "eventIds1",
        "eventIds0",
        "eventIds9"
      ],
      "eventSchemaVersion": 0.47,
      "referenceId": "referenceId1",
      "status": "status1",
      "statusChangeDate": "2016-03-13T12:52:32.123Z"
    },
    {
      "eventIds": [
        "eventIds0"
      ],
      "eventSchemaVersion": 0.48,
      "referenceId": "referenceId0",
      "status": "status0",
      "statusChangeDate": "2016-03-13T12:52:32.123Z"
    }
  ]
}
```

