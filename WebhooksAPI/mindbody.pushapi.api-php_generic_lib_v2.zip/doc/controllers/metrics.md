# Metrics

```php
$metricsController = $client->getMetricsController();
```

## Class Name

`MetricsController`


# Metrics Get

This endpoint gets metrics for all the subscriptions associated with your Public API developer account.

```php
function metricsGet(): PushApiResultGetMetricsResponse
```

## Response Type

[`PushApiResultGetMetricsResponse`](../../doc/models/push-api-result-get-metrics-response.md)

## Example Usage

```php
$result = $metricsController->metricsGet();
```

