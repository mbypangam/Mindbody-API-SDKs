# Metrics

```php
$metricsController = $client->getMetricsController();
```

## Class Name

`MetricsController`


# Get Metrics

This endpoint gets metrics for all the subscriptions associated with your Public API developer account.

:information_source: **Note** This endpoint does not require authentication.

```php
function getMetrics(): GetMetricsResponse
```

## Response Type

[`GetMetricsResponse`](../../doc/models/get-metrics-response.md)

## Example Usage

```php
$result = $metricsController->getMetrics();
```

