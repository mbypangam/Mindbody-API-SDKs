// <copyright file="CustomHeaderAuthenticationManager.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MindbodyPushApiApi.Standard.Http.Request;
using APIMatic.Core.Authentication;

namespace MindbodyPushApiApi.Standard.Authentication
{
    /// <summary>
    /// CustomHeaderAuthenticationManager Class.
    /// </summary>
    internal class CustomHeaderAuthenticationManager : AuthManager, ICustomHeaderAuthenticationCredentials
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomHeaderAuthenticationManager"/> class.
        /// </summary>
        /// <param name="customHeaderAuthentication">CustomHeaderAuthentication.</param>
        public CustomHeaderAuthenticationManager(CustomHeaderAuthenticationModel customHeaderAuthenticationModel)
        {
            APIKey = customHeaderAuthenticationModel?.APIKey;
            Parameters(paramBuilder => paramBuilder
                .Header(header => header.Setup("API-Key", APIKey).Required())
            );
        }

        /// <summary>
        /// Gets string value for aPIKey.
        /// </summary>
        public string APIKey { get; }

        /// <summary>
        /// Check if credentials match.
        /// </summary>
        /// <param name="aPIKey"> The string value for credentials.</param>
        /// <returns> True if credentials matched.</returns>
        public bool Equals(string aPIKey)
        {
            return aPIKey.Equals(this.APIKey);
        }
    }

    public sealed class CustomHeaderAuthenticationModel
    {
        internal CustomHeaderAuthenticationModel()
        {
        }

        internal string APIKey { get; set; }

        /// <summary>
        /// Creates an object of the CustomHeaderAuthenticationModel using the values provided for the builder.
        /// </summary>
        /// <returns>Builder.</returns>
        public Builder ToBuilder()
        {
            return new Builder(APIKey);
        }

        /// <summary>
        /// Builder class for CustomHeaderAuthenticationModel.
        /// </summary>
        public class Builder
        {
            private string aPIKey;

            public Builder(string aPIKey)
            {
                this.aPIKey = aPIKey ?? throw new ArgumentNullException(nameof(aPIKey));
            }

            /// <summary>
            /// Sets APIKey.
            /// </summary>
            /// <param name="aPIKey">APIKey.</param>
            /// <returns>Builder.</returns>
            public Builder APIKey(string aPIKey)
            {
                this.aPIKey = aPIKey ?? throw new ArgumentNullException(nameof(aPIKey));
                return this;
            }


            /// <summary>
            /// Creates an object of the CustomHeaderAuthenticationModel using the values provided for the builder.
            /// </summary>
            /// <returns>CustomHeaderAuthenticationModel.</returns>
            public CustomHeaderAuthenticationModel Build()
            {
                return new CustomHeaderAuthenticationModel()
                {
                    APIKey = this.aPIKey
                };
            }
        }
    }
    
}