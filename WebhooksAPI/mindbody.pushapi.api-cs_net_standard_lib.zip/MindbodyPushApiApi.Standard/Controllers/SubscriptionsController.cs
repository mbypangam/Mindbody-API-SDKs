// <copyright file="SubscriptionsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyPushApiApi.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using MindbodyPushApiApi.Standard;
    using MindbodyPushApiApi.Standard.Authentication;
    using MindbodyPushApiApi.Standard.Http.Client;
    using MindbodyPushApiApi.Standard.Http.Request;
    using MindbodyPushApiApi.Standard.Http.Request.Configuration;
    using MindbodyPushApiApi.Standard.Http.Response;
    using MindbodyPushApiApi.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// SubscriptionsController.
    /// </summary>
    public class SubscriptionsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SubscriptionsController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal SubscriptionsController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// This endpoint searches for subscriptions associated with your developer portal account:.
        ///             .
        /// You can retrieve a specific subscription by calling GET(by ID).
        /// </summary>
        /// <returns>Returns the Models.PushApiResultGetSubscriptionsResponse response from the API call.</returns>
        public Models.PushApiResultGetSubscriptionsResponse SubscriptionsGet()
        {
            Task<Models.PushApiResultGetSubscriptionsResponse> t = this.SubscriptionsGetAsync();
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint searches for subscriptions associated with your developer portal account:.
        ///             .
        /// You can retrieve a specific subscription by calling GET(by ID).
        /// </summary>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PushApiResultGetSubscriptionsResponse response from the API call.</returns>
        public async Task<Models.PushApiResultGetSubscriptionsResponse> SubscriptionsGetAsync(CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v1/subscriptions");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PushApiResultGetSubscriptionsResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint creates a pending subscription that is linked to your developer portal account. After you have created a subscription, you can activate it using the PATCH Subscription endpoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <returns>Returns the Models.PushApiResultCreateSubscriptionResponse response from the API call.</returns>
        public Models.PushApiResultCreateSubscriptionResponse SubscriptionsCreate(
                Models.CreateSubscriptionRequest request)
        {
            Task<Models.PushApiResultCreateSubscriptionResponse> t = this.SubscriptionsCreateAsync(request);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint creates a pending subscription that is linked to your developer portal account. After you have created a subscription, you can activate it using the PATCH Subscription endpoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PushApiResultCreateSubscriptionResponse response from the API call.</returns>
        public async Task<Models.PushApiResultCreateSubscriptionResponse> SubscriptionsCreateAsync(
                Models.CreateSubscriptionRequest request,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v1/subscriptions");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PushApiResultCreateSubscriptionResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint finds and returns the single subscription associated with the passed ID.
        /// </summary>
        /// <param name="subscriptionId">Required parameter: Returns the single location identified by this ID (a GUID)..</param>
        /// <returns>Returns the Models.PushApiResultSubscription response from the API call.</returns>
        public Models.PushApiResultSubscription SubscriptionsGet1(
                string subscriptionId)
        {
            Task<Models.PushApiResultSubscription> t = this.SubscriptionsGet1Async(subscriptionId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint finds and returns the single subscription associated with the passed ID.
        /// </summary>
        /// <param name="subscriptionId">Required parameter: Returns the single location identified by this ID (a GUID)..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PushApiResultSubscription response from the API call.</returns>
        public async Task<Models.PushApiResultSubscription> SubscriptionsGet1Async(
                string subscriptionId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v1/subscriptions/{subscriptionId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "subscriptionId", subscriptionId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PushApiResultSubscription>(response.Body);
        }

        /// <summary>
        /// This endpoint deactivates a subscription associated with the passed ID.
        /// </summary>
        /// <param name="subscriptionId">Required parameter: The subscription ID (a GUID) that you are deactivating..</param>
        /// <returns>Returns the Models.PushApiResultDeactivateSubscriptionResponse response from the API call.</returns>
        public Models.PushApiResultDeactivateSubscriptionResponse SubscriptionsDelete(
                string subscriptionId)
        {
            Task<Models.PushApiResultDeactivateSubscriptionResponse> t = this.SubscriptionsDeleteAsync(subscriptionId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint deactivates a subscription associated with the passed ID.
        /// </summary>
        /// <param name="subscriptionId">Required parameter: The subscription ID (a GUID) that you are deactivating..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PushApiResultDeactivateSubscriptionResponse response from the API call.</returns>
        public async Task<Models.PushApiResultDeactivateSubscriptionResponse> SubscriptionsDeleteAsync(
                string subscriptionId,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v1/subscriptions/{subscriptionId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "subscriptionId", subscriptionId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Delete(queryBuilder.ToString(), headers, null);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PushApiResultDeactivateSubscriptionResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint can activate a new subscription or reactivate an inactive subscription that is associated with your developer portal account, by updating the status. You can also update your subscription’s eventIds, eventSchemaVersion, referenceId, and webhookUrl.
        /// </summary>
        /// <param name="subscriptionId">Required parameter: The subscription’s ID (a GUID)..</param>
        /// <param name="request">Required parameter: The patch request for the given subscription..</param>
        /// <returns>Returns the Models.PushApiResultSubscription response from the API call.</returns>
        public Models.PushApiResultSubscription SubscriptionsPatch(
                string subscriptionId,
                Models.PatchSubscriptionRequest request)
        {
            Task<Models.PushApiResultSubscription> t = this.SubscriptionsPatchAsync(subscriptionId, request);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint can activate a new subscription or reactivate an inactive subscription that is associated with your developer portal account, by updating the status. You can also update your subscription’s eventIds, eventSchemaVersion, referenceId, and webhookUrl.
        /// </summary>
        /// <param name="subscriptionId">Required parameter: The subscription’s ID (a GUID)..</param>
        /// <param name="request">Required parameter: The patch request for the given subscription..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PushApiResultSubscription response from the API call.</returns>
        public async Task<Models.PushApiResultSubscription> SubscriptionsPatchAsync(
                string subscriptionId,
                Models.PatchSubscriptionRequest request,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v1/subscriptions/{subscriptionId}");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "subscriptionId", subscriptionId },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "Content-Type", "application/json" },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PatchBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PushApiResultSubscription>(response.Body);
        }
    }
}