// <copyright file="SubscriptionsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyPushApiApi.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using MindbodyPushApiApi.Standard;
    using MindbodyPushApiApi.Standard.Http.Client;
    using MindbodyPushApiApi.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// SubscriptionsController.
    /// </summary>
    public class SubscriptionsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SubscriptionsController"/> class.
        /// </summary>
        internal SubscriptionsController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// This endpoint searches for subscriptions associated with your developer portal account:.
        ///             .
        /// You can retrieve a specific subscription by calling GET(by ID).
        /// </summary>
        /// <returns>Returns the Models.PushApiResultGetSubscriptionsResponse response from the API call.</returns>
        public Models.PushApiResultGetSubscriptionsResponse GetSubscriptions()
            => CoreHelper.RunTask(GetSubscriptionsAsync());

        /// <summary>
        /// This endpoint searches for subscriptions associated with your developer portal account:.
        ///             .
        /// You can retrieve a specific subscription by calling GET(by ID).
        /// </summary>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PushApiResultGetSubscriptionsResponse response from the API call.</returns>
        public async Task<Models.PushApiResultGetSubscriptionsResponse> GetSubscriptionsAsync(CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PushApiResultGetSubscriptionsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/api/v1/subscriptions"))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint creates a pending subscription that is linked to your developer portal account. After you have created a subscription, you can activate it using the PATCH Subscription endpoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <returns>Returns the Models.PushApiResultCreateSubscriptionResponse response from the API call.</returns>
        public Models.PushApiResultCreateSubscriptionResponse CreateSubscription(
                Models.CreateSubscriptionRequest request)
            => CoreHelper.RunTask(CreateSubscriptionAsync(request));

        /// <summary>
        /// This endpoint creates a pending subscription that is linked to your developer portal account. After you have created a subscription, you can activate it using the PATCH Subscription endpoint.
        /// </summary>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PushApiResultCreateSubscriptionResponse response from the API call.</returns>
        public async Task<Models.PushApiResultCreateSubscriptionResponse> CreateSubscriptionAsync(
                Models.CreateSubscriptionRequest request,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PushApiResultCreateSubscriptionResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/api/v1/subscriptions")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint deactivates a subscription associated with the passed ID.
        /// </summary>
        /// <param name="subscriptionId">Required parameter: The subscription ID (a GUID) that you are deactivating..</param>
        /// <returns>Returns the Models.PushApiResultDeactivateSubscriptionResponse response from the API call.</returns>
        public Models.PushApiResultDeactivateSubscriptionResponse DeleteSubscription(
                string subscriptionId)
            => CoreHelper.RunTask(DeleteSubscriptionAsync(subscriptionId));

        /// <summary>
        /// This endpoint deactivates a subscription associated with the passed ID.
        /// </summary>
        /// <param name="subscriptionId">Required parameter: The subscription ID (a GUID) that you are deactivating..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PushApiResultDeactivateSubscriptionResponse response from the API call.</returns>
        public async Task<Models.PushApiResultDeactivateSubscriptionResponse> DeleteSubscriptionAsync(
                string subscriptionId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PushApiResultDeactivateSubscriptionResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/api/v1/subscriptions/{subscriptionId}")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("subscriptionId", subscriptionId))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint finds and returns the single subscription associated with the passed ID.
        /// </summary>
        /// <param name="subscriptionId">Required parameter: Returns the single location identified by this ID (a GUID)..</param>
        /// <returns>Returns the Models.PushApiResultSubscription response from the API call.</returns>
        public Models.PushApiResultSubscription GetSubscription(
                string subscriptionId)
            => CoreHelper.RunTask(GetSubscriptionAsync(subscriptionId));

        /// <summary>
        /// This endpoint finds and returns the single subscription associated with the passed ID.
        /// </summary>
        /// <param name="subscriptionId">Required parameter: Returns the single location identified by this ID (a GUID)..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PushApiResultSubscription response from the API call.</returns>
        public async Task<Models.PushApiResultSubscription> GetSubscriptionAsync(
                string subscriptionId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PushApiResultSubscription>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/api/v1/subscriptions/{subscriptionId}")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("subscriptionId", subscriptionId))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint can activate a new subscription or reactivate an inactive subscription that is associated with your developer portal account, by updating the status. You can also update your subscription’s eventIds, eventSchemaVersion, referenceId, and webhookUrl.
        /// </summary>
        /// <param name="subscriptionId">Required parameter: The subscription’s ID (a GUID)..</param>
        /// <param name="request">Required parameter: The patch request for the given subscription..</param>
        /// <returns>Returns the Models.PushApiResultSubscription response from the API call.</returns>
        public Models.PushApiResultSubscription PatchSubscription(
                string subscriptionId,
                Models.PatchSubscriptionRequest request)
            => CoreHelper.RunTask(PatchSubscriptionAsync(subscriptionId, request));

        /// <summary>
        /// This endpoint can activate a new subscription or reactivate an inactive subscription that is associated with your developer portal account, by updating the status. You can also update your subscription’s eventIds, eventSchemaVersion, referenceId, and webhookUrl.
        /// </summary>
        /// <param name="subscriptionId">Required parameter: The subscription’s ID (a GUID)..</param>
        /// <param name="request">Required parameter: The patch request for the given subscription..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PushApiResultSubscription response from the API call.</returns>
        public async Task<Models.PushApiResultSubscription> PatchSubscriptionAsync(
                string subscriptionId,
                Models.PatchSubscriptionRequest request,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PushApiResultSubscription>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(new HttpMethod("PATCH"), "/api/v1/subscriptions/{subscriptionId}")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("subscriptionId", subscriptionId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}