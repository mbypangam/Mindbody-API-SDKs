// <copyright file="MetricsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyPushApiApi.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using MindbodyPushApiApi.Standard;
    using MindbodyPushApiApi.Standard.Http.Client;
    using MindbodyPushApiApi.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// MetricsController.
    /// </summary>
    public class MetricsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MetricsController"/> class.
        /// </summary>
        internal MetricsController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// This endpoint gets metrics for all the subscriptions associated with your Public API developer account.
        /// </summary>
        /// <returns>Returns the Models.GetMetricsResponse response from the API call.</returns>
        public Models.GetMetricsResponse GetMetrics()
            => CoreHelper.RunTask(GetMetricsAsync());

        /// <summary>
        /// This endpoint gets metrics for all the subscriptions associated with your Public API developer account.
        /// </summary>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetMetricsResponse response from the API call.</returns>
        public async Task<Models.GetMetricsResponse> GetMetricsAsync(CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetMetricsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/api/v1/metrics"))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}