// <copyright file="MetricsController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyPushApiApi.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using MindbodyPushApiApi.Standard;
    using MindbodyPushApiApi.Standard.Authentication;
    using MindbodyPushApiApi.Standard.Http.Client;
    using MindbodyPushApiApi.Standard.Http.Request;
    using MindbodyPushApiApi.Standard.Http.Request.Configuration;
    using MindbodyPushApiApi.Standard.Http.Response;
    using MindbodyPushApiApi.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MetricsController.
    /// </summary>
    public class MetricsController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MetricsController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal MetricsController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// This endpoint gets metrics for all the subscriptions associated with your Public API developer account.
        /// </summary>
        /// <returns>Returns the Models.PushApiResultGetMetricsResponse response from the API call.</returns>
        public Models.PushApiResultGetMetricsResponse MetricsGet()
        {
            Task<Models.PushApiResultGetMetricsResponse> t = this.MetricsGetAsync();
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint gets metrics for all the subscriptions associated with your Public API developer account.
        /// </summary>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PushApiResultGetMetricsResponse response from the API call.</returns>
        public async Task<Models.PushApiResultGetMetricsResponse> MetricsGetAsync(CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/api/v1/metrics");

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.PushApiResultGetMetricsResponse>(response.Body);
        }
    }
}