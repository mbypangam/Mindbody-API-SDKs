// <copyright file="PatchSubscriptionRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyPushApiApi.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MindbodyPushApiApi.Standard;
    using MindbodyPushApiApi.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PatchSubscriptionRequest.
    /// </summary>
    public class PatchSubscriptionRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PatchSubscriptionRequest"/> class.
        /// </summary>
        public PatchSubscriptionRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PatchSubscriptionRequest"/> class.
        /// </summary>
        /// <param name="eventIds">eventIds.</param>
        /// <param name="eventSchemaVersion">eventSchemaVersion.</param>
        /// <param name="referenceId">referenceId.</param>
        /// <param name="status">status.</param>
        /// <param name="webhookUrl">webhookUrl.</param>
        public PatchSubscriptionRequest(
            List<string> eventIds = null,
            double? eventSchemaVersion = null,
            string referenceId = null,
            string status = null,
            string webhookUrl = null)
        {
            this.EventIds = eventIds;
            this.EventSchemaVersion = eventSchemaVersion;
            this.ReferenceId = referenceId;
            this.Status = status;
            this.WebhookUrl = webhookUrl;
        }

        /// <summary>
        /// A list of event IDs that you want to update or subscribe to.
        /// </summary>
        [JsonProperty("eventIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> EventIds { get; set; }

        /// <summary>
        /// The event schema version associated with the subscription. Currently, this is always `1`.
        /// </summary>
        [JsonProperty("eventSchemaVersion", NullValueHandling = NullValueHandling.Ignore)]
        public double? EventSchemaVersion { get; set; }

        /// <summary>
        /// An arbitrary field that you can set to a value of your choice. Mindbody stores and returns this value for the subscription you are activating. Most commonly, this field stores a GUID that you can use in your application.
        /// </summary>
        [JsonProperty("referenceId", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceId { get; set; }

        /// <summary>
        /// The subscription’s current status, as of the last update.
        /// </summary>
        [JsonProperty("status", NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; }

        /// <summary>
        /// The URL registered as the target of the webhook deliveries. Mindbody posts the event notifications to this URL. Webhook URL Requirements lists considerations and requirements for this URL.
        /// </summary>
        [JsonProperty("webhookUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string WebhookUrl { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PatchSubscriptionRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is PatchSubscriptionRequest other &&                ((this.EventIds == null && other.EventIds == null) || (this.EventIds?.Equals(other.EventIds) == true)) &&
                ((this.EventSchemaVersion == null && other.EventSchemaVersion == null) || (this.EventSchemaVersion?.Equals(other.EventSchemaVersion) == true)) &&
                ((this.ReferenceId == null && other.ReferenceId == null) || (this.ReferenceId?.Equals(other.ReferenceId) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.WebhookUrl == null && other.WebhookUrl == null) || (this.WebhookUrl?.Equals(other.WebhookUrl) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.EventIds = {(this.EventIds == null ? "null" : $"[{string.Join(", ", this.EventIds)} ]")}");
            toStringOutput.Add($"this.EventSchemaVersion = {(this.EventSchemaVersion == null ? "null" : this.EventSchemaVersion.ToString())}");
            toStringOutput.Add($"this.ReferenceId = {(this.ReferenceId == null ? "null" : this.ReferenceId)}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status)}");
            toStringOutput.Add($"this.WebhookUrl = {(this.WebhookUrl == null ? "null" : this.WebhookUrl)}");
        }
    }
}