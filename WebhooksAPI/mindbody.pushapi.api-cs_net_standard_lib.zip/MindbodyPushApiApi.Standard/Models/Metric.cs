// <copyright file="Metric.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyPushApiApi.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MindbodyPushApiApi.Standard;
    using MindbodyPushApiApi.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Metric.
    /// </summary>
    public class Metric
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Metric"/> class.
        /// </summary>
        public Metric()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Metric"/> class.
        /// </summary>
        /// <param name="subscriptionId">subscriptionId.</param>
        /// <param name="status">status.</param>
        /// <param name="statusChangeDate">statusChangeDate.</param>
        /// <param name="creationDateTime">creationDateTime.</param>
        /// <param name="messagesAttempted">messagesAttempted.</param>
        /// <param name="messagesDelivered">messagesDelivered.</param>
        /// <param name="messagesUndelivered">messagesUndelivered.</param>
        /// <param name="messagesFailed">messagesFailed.</param>
        public Metric(
            Guid? subscriptionId = null,
            string status = null,
            DateTime? statusChangeDate = null,
            DateTime? creationDateTime = null,
            long? messagesAttempted = null,
            long? messagesDelivered = null,
            long? messagesUndelivered = null,
            long? messagesFailed = null)
        {
            this.SubscriptionId = subscriptionId;
            this.Status = status;
            this.StatusChangeDate = statusChangeDate;
            this.CreationDateTime = creationDateTime;
            this.MessagesAttempted = messagesAttempted;
            this.MessagesDelivered = messagesDelivered;
            this.MessagesUndelivered = messagesUndelivered;
            this.MessagesFailed = messagesFailed;
        }

        /// <summary>
        /// The subscription's ID (a GUID).
        /// </summary>
        [JsonProperty("subscriptionId", NullValueHandling = NullValueHandling.Ignore)]
        public Guid? SubscriptionId { get; set; }

        /// <summary>
        /// The subscription's current status. **Possible Values**:<br />
        /// `PendingActivation` - The subscription is created but not receiving event notifications.To start receiving event notifications, set the subscription’s status to Active using the PATCH Subscription endpoint.<br />
        /// `Active` - The subscription is active and can receive event notifications.<br />
        /// `DeactivatedByUser` - You deactivated the subscription.<br />
        /// `DeactivatedByAdmin` - Mindbody deactivated your subscription.<br />
        /// `DeactivatedTooManyFailedMessageDeliveryAttempts` - The subscription was deactivated because Mindbody stopped receiving a 2xx HTTP status code from the webhookUrl when posting events. An automated email will be sent to the developer portal email on the account with additional details.<br />
        /// `DeactivatedByEventDeactivation` - One of the event IDs associated with the subscription was deactivated, which invalidated and deactivated the subscription. If this occurs, you must create a new subscription using only up-to-date event IDs.<br />
        /// </summary>
        [JsonProperty("status", NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; }

        /// <summary>
        /// The UTC date and time when the subscription `status` was last updated.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("statusChangeDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StatusChangeDate { get; set; }

        /// <summary>
        /// The UTC date and time when the subscription was created.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("creationDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? CreationDateTime { get; set; }

        /// <summary>
        /// The number of event notifications Mindbody attempted to deliver to the subscription `webhookUrl`, including retries.
        /// </summary>
        [JsonProperty("messagesAttempted", NullValueHandling = NullValueHandling.Ignore)]
        public long? MessagesAttempted { get; set; }

        /// <summary>
        /// The number of event notifications Mindbody successfully delivered to the subscription `webhookUrl`.
        /// </summary>
        [JsonProperty("messagesDelivered", NullValueHandling = NullValueHandling.Ignore)]
        public long? MessagesDelivered { get; set; }

        /// <summary>
        /// The number of event notifications where MINDBODY received a failure response from the subscription `webhookUrl`.
        /// </summary>
        [JsonProperty("messagesUndelivered", NullValueHandling = NullValueHandling.Ignore)]
        public long? MessagesUndelivered { get; set; }

        /// <summary>
        /// The number of event notifications that Mindbody stopped trying to send after 3 hours.
        /// </summary>
        [JsonProperty("messagesFailed", NullValueHandling = NullValueHandling.Ignore)]
        public long? MessagesFailed { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Metric : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Metric other &&
                ((this.SubscriptionId == null && other.SubscriptionId == null) || (this.SubscriptionId?.Equals(other.SubscriptionId) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.StatusChangeDate == null && other.StatusChangeDate == null) || (this.StatusChangeDate?.Equals(other.StatusChangeDate) == true)) &&
                ((this.CreationDateTime == null && other.CreationDateTime == null) || (this.CreationDateTime?.Equals(other.CreationDateTime) == true)) &&
                ((this.MessagesAttempted == null && other.MessagesAttempted == null) || (this.MessagesAttempted?.Equals(other.MessagesAttempted) == true)) &&
                ((this.MessagesDelivered == null && other.MessagesDelivered == null) || (this.MessagesDelivered?.Equals(other.MessagesDelivered) == true)) &&
                ((this.MessagesUndelivered == null && other.MessagesUndelivered == null) || (this.MessagesUndelivered?.Equals(other.MessagesUndelivered) == true)) &&
                ((this.MessagesFailed == null && other.MessagesFailed == null) || (this.MessagesFailed?.Equals(other.MessagesFailed) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SubscriptionId = {(this.SubscriptionId == null ? "null" : this.SubscriptionId.ToString())}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status == string.Empty ? "" : this.Status)}");
            toStringOutput.Add($"this.StatusChangeDate = {(this.StatusChangeDate == null ? "null" : this.StatusChangeDate.ToString())}");
            toStringOutput.Add($"this.CreationDateTime = {(this.CreationDateTime == null ? "null" : this.CreationDateTime.ToString())}");
            toStringOutput.Add($"this.MessagesAttempted = {(this.MessagesAttempted == null ? "null" : this.MessagesAttempted.ToString())}");
            toStringOutput.Add($"this.MessagesDelivered = {(this.MessagesDelivered == null ? "null" : this.MessagesDelivered.ToString())}");
            toStringOutput.Add($"this.MessagesUndelivered = {(this.MessagesUndelivered == null ? "null" : this.MessagesUndelivered.ToString())}");
            toStringOutput.Add($"this.MessagesFailed = {(this.MessagesFailed == null ? "null" : this.MessagesFailed.ToString())}");
        }
    }
}