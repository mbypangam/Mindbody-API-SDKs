// <copyright file="PushApiResultDeactivateSubscriptionResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyPushApiApi.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MindbodyPushApiApi.Standard;
    using MindbodyPushApiApi.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PushApiResultDeactivateSubscriptionResponse.
    /// </summary>
    public class PushApiResultDeactivateSubscriptionResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PushApiResultDeactivateSubscriptionResponse"/> class.
        /// </summary>
        public PushApiResultDeactivateSubscriptionResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PushApiResultDeactivateSubscriptionResponse"/> class.
        /// </summary>
        /// <param name="isSuccess">isSuccess.</param>
        /// <param name="mValue">value.</param>
        /// <param name="errorInformation">errorInformation.</param>
        public PushApiResultDeactivateSubscriptionResponse(
            bool? isSuccess = null,
            Models.DeactivateSubscriptionResponse mValue = null,
            List<Models.PushApiError> errorInformation = null)
        {
            this.IsSuccess = isSuccess;
            this.MValue = mValue;
            this.ErrorInformation = errorInformation;
        }

        /// <summary>
        /// Gets or sets IsSuccess.
        /// </summary>
        [JsonProperty("isSuccess", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsSuccess { get; set; }

        /// <summary>
        /// Returned after a subscription is deactivated
        /// </summary>
        [JsonProperty("value", NullValueHandling = NullValueHandling.Ignore)]
        public Models.DeactivateSubscriptionResponse MValue { get; set; }

        /// <summary>
        /// Gets or sets ErrorInformation.
        /// </summary>
        [JsonProperty("errorInformation", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.PushApiError> ErrorInformation { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PushApiResultDeactivateSubscriptionResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PushApiResultDeactivateSubscriptionResponse other &&
                ((this.IsSuccess == null && other.IsSuccess == null) || (this.IsSuccess?.Equals(other.IsSuccess) == true)) &&
                ((this.MValue == null && other.MValue == null) || (this.MValue?.Equals(other.MValue) == true)) &&
                ((this.ErrorInformation == null && other.ErrorInformation == null) || (this.ErrorInformation?.Equals(other.ErrorInformation) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.IsSuccess = {(this.IsSuccess == null ? "null" : this.IsSuccess.ToString())}");
            toStringOutput.Add($"this.MValue = {(this.MValue == null ? "null" : this.MValue.ToString())}");
            toStringOutput.Add($"this.ErrorInformation = {(this.ErrorInformation == null ? "null" : $"[{string.Join(", ", this.ErrorInformation)} ]")}");
        }
    }
}