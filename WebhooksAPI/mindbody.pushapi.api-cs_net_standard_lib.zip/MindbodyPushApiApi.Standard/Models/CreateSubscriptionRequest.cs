// <copyright file="CreateSubscriptionRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyPushApiApi.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MindbodyPushApiApi.Standard;
    using MindbodyPushApiApi.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CreateSubscriptionRequest.
    /// </summary>
    public class CreateSubscriptionRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateSubscriptionRequest"/> class.
        /// </summary>
        public CreateSubscriptionRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateSubscriptionRequest"/> class.
        /// </summary>
        /// <param name="eventIds">eventIds.</param>
        /// <param name="eventSchemaVersion">eventSchemaVersion.</param>
        /// <param name="referenceId">referenceId.</param>
        /// <param name="webhookUrl">webhookUrl.</param>
        public CreateSubscriptionRequest(
            List<string> eventIds = null,
            double? eventSchemaVersion = null,
            string referenceId = null,
            string webhookUrl = null)
        {
            this.EventIds = eventIds;
            this.EventSchemaVersion = eventSchemaVersion;
            this.ReferenceId = referenceId;
            this.WebhookUrl = webhookUrl;
        }

        /// <summary>
        /// The events you want to be sent to the specified `webhookUrl`.
        /// </summary>
        [JsonProperty("eventIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> EventIds { get; set; }

        /// <summary>
        /// The event schema version for this subscription. `1` is currently the only accepted value.
        /// </summary>
        [JsonProperty("eventSchemaVersion", NullValueHandling = NullValueHandling.Ignore)]
        public double? EventSchemaVersion { get; set; }

        /// <summary>
        /// An arbitrary field that you can set to a value of your choice. Mindbody stores and returns this value for the subscription you are creating. Most commonly, this field stores a GUID that you can use in your application.
        /// </summary>
        [JsonProperty("referenceId", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceId { get; set; }

        /// <summary>
        /// The URL that Mindbody posts the event notifications to. Webhook URL Requirements lists considerations and requirements for this URL.
        /// </summary>
        [JsonProperty("webhookUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string WebhookUrl { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CreateSubscriptionRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is CreateSubscriptionRequest other &&                ((this.EventIds == null && other.EventIds == null) || (this.EventIds?.Equals(other.EventIds) == true)) &&
                ((this.EventSchemaVersion == null && other.EventSchemaVersion == null) || (this.EventSchemaVersion?.Equals(other.EventSchemaVersion) == true)) &&
                ((this.ReferenceId == null && other.ReferenceId == null) || (this.ReferenceId?.Equals(other.ReferenceId) == true)) &&
                ((this.WebhookUrl == null && other.WebhookUrl == null) || (this.WebhookUrl?.Equals(other.WebhookUrl) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.EventIds = {(this.EventIds == null ? "null" : $"[{string.Join(", ", this.EventIds)} ]")}");
            toStringOutput.Add($"this.EventSchemaVersion = {(this.EventSchemaVersion == null ? "null" : this.EventSchemaVersion.ToString())}");
            toStringOutput.Add($"this.ReferenceId = {(this.ReferenceId == null ? "null" : this.ReferenceId == string.Empty ? "" : this.ReferenceId)}");
            toStringOutput.Add($"this.WebhookUrl = {(this.WebhookUrl == null ? "null" : this.WebhookUrl == string.Empty ? "" : this.WebhookUrl)}");
        }
    }
}