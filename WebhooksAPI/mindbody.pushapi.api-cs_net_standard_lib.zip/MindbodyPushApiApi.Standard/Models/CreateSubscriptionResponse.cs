// <copyright file="CreateSubscriptionResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyPushApiApi.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MindbodyPushApiApi.Standard;
    using MindbodyPushApiApi.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CreateSubscriptionResponse.
    /// </summary>
    public class CreateSubscriptionResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateSubscriptionResponse"/> class.
        /// </summary>
        public CreateSubscriptionResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateSubscriptionResponse"/> class.
        /// </summary>
        /// <param name="eventIds">eventIds.</param>
        /// <param name="eventSchemaVersion">eventSchemaVersion.</param>
        /// <param name="messageSignatureKey">messageSignatureKey.</param>
        /// <param name="referenceId">referenceId.</param>
        /// <param name="status">status.</param>
        /// <param name="statusChangeDate">statusChangeDate.</param>
        /// <param name="statusChangeMessage">statusChangeMessage.</param>
        /// <param name="statusChangeUser">statusChangeUser.</param>
        /// <param name="subscriptionCreationDateTime">subscriptionCreationDateTime.</param>
        /// <param name="subscriptionId">subscriptionId.</param>
        /// <param name="webhookUrl">webhookUrl.</param>
        public CreateSubscriptionResponse(
            List<string> eventIds = null,
            double? eventSchemaVersion = null,
            string messageSignatureKey = null,
            string referenceId = null,
            string status = null,
            DateTime? statusChangeDate = null,
            string statusChangeMessage = null,
            string statusChangeUser = null,
            DateTime? subscriptionCreationDateTime = null,
            Guid? subscriptionId = null,
            string webhookUrl = null)
        {
            this.EventIds = eventIds;
            this.EventSchemaVersion = eventSchemaVersion;
            this.MessageSignatureKey = messageSignatureKey;
            this.ReferenceId = referenceId;
            this.Status = status;
            this.StatusChangeDate = statusChangeDate;
            this.StatusChangeMessage = statusChangeMessage;
            this.StatusChangeUser = statusChangeUser;
            this.SubscriptionCreationDateTime = subscriptionCreationDateTime;
            this.SubscriptionId = subscriptionId;
            this.WebhookUrl = webhookUrl;
        }

        /// <summary>
        /// The events that are to be sent to this subscription's `webhookUrl`.
        /// </summary>
        [JsonProperty("eventIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> EventIds { get; set; }

        /// <summary>
        /// The event schema version associated with the subscription. Currently, this is always `1`.
        /// </summary>
        [JsonProperty("eventSchemaVersion", NullValueHandling = NullValueHandling.Ignore)]
        public double? EventSchemaVersion { get; set; }

        /// <summary>
        /// The subscription security key that you can use to verify an event payload's authenticity. It is important that you store this value because this is the only endpoint that returns it See X-Mindbody Signature Header for more details.
        /// </summary>
        [JsonProperty("messageSignatureKey", NullValueHandling = NullValueHandling.Ignore)]
        public string MessageSignatureKey { get; set; }

        /// <summary>
        /// An arbitrary ID that can be specified in the POST Subscription request body, and is saved for the requesting developer's use.
        /// </summary>
        [JsonProperty("referenceId", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceId { get; set; }

        /// <summary>
        /// The subscription's current status.
        /// *Possible Values:*
        ///  1. `PendingActivation` - The subscription is created but not receiving event notifications.
        ///  To start receiving event notifications,
        ///  set the subscription’s status to `Active` using the PATCH Subscription endpoint.
        /// 
        ///  2. `Active` - The subscription is active and can receive event notifications.
        /// 
        ///  3. `DeactivatedByUser` - You deactivated the subscription.
        /// 
        ///  4. `DeactivatedByAdmin` - Mindbody deactivated your subscription.
        /// 
        ///  5. `DeactivatedTooManyFailedMessageDeliveryAttempts` - The subscription was deactivated because Mindbody stopped receiving
        ///  a 2xx HTTP status code from the webhookUrl when posting events.
        /// 
        ///  6. `DeactivatedByEventDeactivation` - One of the event IDs associated with the subscription was deactivated,
        ///  which invalidated and deactivated the subscription.
        ///  If this occurs, you must create a new subscription using only up-to-date event IDs.
        /// </summary>
        [JsonProperty("status", NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; }

        /// <summary>
        /// The UTC date and time when the subscription's status was last updated.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("statusChangeDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StatusChangeDate { get; set; }

        /// <summary>
        /// A message generated by Mindbody that explains why a subscription's status changed.
        /// </summary>
        [JsonProperty("statusChangeMessage", NullValueHandling = NullValueHandling.Ignore)]
        public string StatusChangeMessage { get; set; }

        /// <summary>
        /// The first name of the developer or Mindbody staff member who changed the subscription's status.
        /// </summary>
        [JsonProperty("statusChangeUser", NullValueHandling = NullValueHandling.Ignore)]
        public string StatusChangeUser { get; set; }

        /// <summary>
        /// The UTC date and time when the subscription was created.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("subscriptionCreationDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? SubscriptionCreationDateTime { get; set; }

        /// <summary>
        /// The subscription's ID (a GUID).
        /// </summary>
        [JsonProperty("subscriptionId", NullValueHandling = NullValueHandling.Ignore)]
        public Guid? SubscriptionId { get; set; }

        /// <summary>
        /// The webhook to which the listed `eventIds` are sent.
        /// </summary>
        [JsonProperty("webhookUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string WebhookUrl { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CreateSubscriptionResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CreateSubscriptionResponse other &&
                ((this.EventIds == null && other.EventIds == null) || (this.EventIds?.Equals(other.EventIds) == true)) &&
                ((this.EventSchemaVersion == null && other.EventSchemaVersion == null) || (this.EventSchemaVersion?.Equals(other.EventSchemaVersion) == true)) &&
                ((this.MessageSignatureKey == null && other.MessageSignatureKey == null) || (this.MessageSignatureKey?.Equals(other.MessageSignatureKey) == true)) &&
                ((this.ReferenceId == null && other.ReferenceId == null) || (this.ReferenceId?.Equals(other.ReferenceId) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.StatusChangeDate == null && other.StatusChangeDate == null) || (this.StatusChangeDate?.Equals(other.StatusChangeDate) == true)) &&
                ((this.StatusChangeMessage == null && other.StatusChangeMessage == null) || (this.StatusChangeMessage?.Equals(other.StatusChangeMessage) == true)) &&
                ((this.StatusChangeUser == null && other.StatusChangeUser == null) || (this.StatusChangeUser?.Equals(other.StatusChangeUser) == true)) &&
                ((this.SubscriptionCreationDateTime == null && other.SubscriptionCreationDateTime == null) || (this.SubscriptionCreationDateTime?.Equals(other.SubscriptionCreationDateTime) == true)) &&
                ((this.SubscriptionId == null && other.SubscriptionId == null) || (this.SubscriptionId?.Equals(other.SubscriptionId) == true)) &&
                ((this.WebhookUrl == null && other.WebhookUrl == null) || (this.WebhookUrl?.Equals(other.WebhookUrl) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.EventIds = {(this.EventIds == null ? "null" : $"[{string.Join(", ", this.EventIds)} ]")}");
            toStringOutput.Add($"this.EventSchemaVersion = {(this.EventSchemaVersion == null ? "null" : this.EventSchemaVersion.ToString())}");
            toStringOutput.Add($"this.MessageSignatureKey = {(this.MessageSignatureKey == null ? "null" : this.MessageSignatureKey == string.Empty ? "" : this.MessageSignatureKey)}");
            toStringOutput.Add($"this.ReferenceId = {(this.ReferenceId == null ? "null" : this.ReferenceId == string.Empty ? "" : this.ReferenceId)}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status == string.Empty ? "" : this.Status)}");
            toStringOutput.Add($"this.StatusChangeDate = {(this.StatusChangeDate == null ? "null" : this.StatusChangeDate.ToString())}");
            toStringOutput.Add($"this.StatusChangeMessage = {(this.StatusChangeMessage == null ? "null" : this.StatusChangeMessage == string.Empty ? "" : this.StatusChangeMessage)}");
            toStringOutput.Add($"this.StatusChangeUser = {(this.StatusChangeUser == null ? "null" : this.StatusChangeUser == string.Empty ? "" : this.StatusChangeUser)}");
            toStringOutput.Add($"this.SubscriptionCreationDateTime = {(this.SubscriptionCreationDateTime == null ? "null" : this.SubscriptionCreationDateTime.ToString())}");
            toStringOutput.Add($"this.SubscriptionId = {(this.SubscriptionId == null ? "null" : this.SubscriptionId.ToString())}");
            toStringOutput.Add($"this.WebhookUrl = {(this.WebhookUrl == null ? "null" : this.WebhookUrl == string.Empty ? "" : this.WebhookUrl)}");
        }
    }
}