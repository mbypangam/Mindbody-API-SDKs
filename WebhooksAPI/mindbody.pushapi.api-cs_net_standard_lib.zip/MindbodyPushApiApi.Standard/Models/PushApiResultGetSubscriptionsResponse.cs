// <copyright file="PushApiResultGetSubscriptionsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyPushApiApi.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MindbodyPushApiApi.Standard;
    using MindbodyPushApiApi.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PushApiResultGetSubscriptionsResponse.
    /// </summary>
    public class PushApiResultGetSubscriptionsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PushApiResultGetSubscriptionsResponse"/> class.
        /// </summary>
        public PushApiResultGetSubscriptionsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PushApiResultGetSubscriptionsResponse"/> class.
        /// </summary>
        /// <param name="isSuccess">isSuccess.</param>
        /// <param name="mValue">value.</param>
        /// <param name="errorInformation">errorInformation.</param>
        public PushApiResultGetSubscriptionsResponse(
            bool? isSuccess = null,
            Models.GetSubscriptionsResponse mValue = null,
            List<Models.PushApiError> errorInformation = null)
        {
            this.IsSuccess = isSuccess;
            this.MValue = mValue;
            this.ErrorInformation = errorInformation;
        }

        /// <summary>
        /// Gets or sets IsSuccess.
        /// </summary>
        [JsonProperty("isSuccess", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsSuccess { get; set; }

        /// <summary>
        /// A wrapper for a get subscriptions request
        /// </summary>
        [JsonProperty("value", NullValueHandling = NullValueHandling.Ignore)]
        public Models.GetSubscriptionsResponse MValue { get; set; }

        /// <summary>
        /// Gets or sets ErrorInformation.
        /// </summary>
        [JsonProperty("errorInformation", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.PushApiError> ErrorInformation { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"PushApiResultGetSubscriptionsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is PushApiResultGetSubscriptionsResponse other &&
                ((this.IsSuccess == null && other.IsSuccess == null) || (this.IsSuccess?.Equals(other.IsSuccess) == true)) &&
                ((this.MValue == null && other.MValue == null) || (this.MValue?.Equals(other.MValue) == true)) &&
                ((this.ErrorInformation == null && other.ErrorInformation == null) || (this.ErrorInformation?.Equals(other.ErrorInformation) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.IsSuccess = {(this.IsSuccess == null ? "null" : this.IsSuccess.ToString())}");
            toStringOutput.Add($"this.MValue = {(this.MValue == null ? "null" : this.MValue.ToString())}");
            toStringOutput.Add($"this.ErrorInformation = {(this.ErrorInformation == null ? "null" : $"[{string.Join(", ", this.ErrorInformation)} ]")}");
        }
    }
}