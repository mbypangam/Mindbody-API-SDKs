// <copyright file="DeactivateSubscriptionResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MindbodyPushApiApi.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MindbodyPushApiApi.Standard;
    using MindbodyPushApiApi.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// DeactivateSubscriptionResponse.
    /// </summary>
    public class DeactivateSubscriptionResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DeactivateSubscriptionResponse"/> class.
        /// </summary>
        public DeactivateSubscriptionResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DeactivateSubscriptionResponse"/> class.
        /// </summary>
        /// <param name="message">message.</param>
        /// <param name="deactivationDateTime">deactivationDateTime.</param>
        /// <param name="subscriptionId">subscriptionId.</param>
        /// <param name="referenceId">referenceId.</param>
        public DeactivateSubscriptionResponse(
            string message = null,
            DateTime? deactivationDateTime = null,
            Guid? subscriptionId = null,
            string referenceId = null)
        {
            this.Message = message;
            this.DeactivationDateTime = deactivationDateTime;
            this.SubscriptionId = subscriptionId;
            this.ReferenceId = referenceId;
        }

        /// <summary>
        /// A message about the deactivation request. Unless an error occurs, this message always `"Subscription deactivated successfully."`.
        /// </summary>
        [JsonProperty("message", NullValueHandling = NullValueHandling.Ignore)]
        public string Message { get; set; }

        /// <summary>
        /// The UTC date and time when the deactivation took place.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("deactivationDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DeactivationDateTime { get; set; }

        /// <summary>
        /// The subscription ID (a GUID).
        /// </summary>
        [JsonProperty("subscriptionId", NullValueHandling = NullValueHandling.Ignore)]
        public Guid? SubscriptionId { get; set; }

        /// <summary>
        /// The subscription's reference ID, assigned when the subscription was created.
        /// </summary>
        [JsonProperty("referenceId", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"DeactivateSubscriptionResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is DeactivateSubscriptionResponse other &&
                ((this.Message == null && other.Message == null) || (this.Message?.Equals(other.Message) == true)) &&
                ((this.DeactivationDateTime == null && other.DeactivationDateTime == null) || (this.DeactivationDateTime?.Equals(other.DeactivationDateTime) == true)) &&
                ((this.SubscriptionId == null && other.SubscriptionId == null) || (this.SubscriptionId?.Equals(other.SubscriptionId) == true)) &&
                ((this.ReferenceId == null && other.ReferenceId == null) || (this.ReferenceId?.Equals(other.ReferenceId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Message = {(this.Message == null ? "null" : this.Message == string.Empty ? "" : this.Message)}");
            toStringOutput.Add($"this.DeactivationDateTime = {(this.DeactivationDateTime == null ? "null" : this.DeactivationDateTime.ToString())}");
            toStringOutput.Add($"this.SubscriptionId = {(this.SubscriptionId == null ? "null" : this.SubscriptionId.ToString())}");
            toStringOutput.Add($"this.ReferenceId = {(this.ReferenceId == null ? "null" : this.ReferenceId == string.Empty ? "" : this.ReferenceId)}");
        }
    }
}