
# Push Api Result Create Subscription Response

A result returned for every request to the push API

## Structure

`PushApiResultCreateSubscriptionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ErrorInformation` | [`List<Models.PushApiError>`](../../doc/models/push-api-error.md) | Optional | - |
| `IsSuccess` | `bool?` | Optional | - |
| `MValue` | [`Models.CreateSubscriptionResponse`](../../doc/models/create-subscription-response.md) | Optional | The created subscription |

## Example (as JSON)

```json
{
  "errorInformation": [
    {
      "errorCode": 63,
      "errorMessage": "errorMessage7",
      "errorType": "errorType1"
    },
    {
      "errorCode": 64,
      "errorMessage": "errorMessage8",
      "errorType": "errorType0"
    }
  ],
  "isSuccess": false,
  "value": {
    "eventIds": [
      "eventIds4"
    ],
    "eventSchemaVersion": 26.12,
    "messageSignatureKey": "messageSignatureKey4",
    "referenceId": "referenceId4",
    "status": "status4"
  }
}
```

