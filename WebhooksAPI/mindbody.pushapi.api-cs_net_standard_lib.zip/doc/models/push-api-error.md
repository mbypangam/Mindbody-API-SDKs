
# Push Api Error

An error returned by the push API for application errors

## Structure

`PushApiError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ErrorCode` | `int?` | Optional | A unique ID for the returned error code |
| `ErrorMessage` | `string` | Optional | A message indicating what went wrong |
| `ErrorType` | `string` | Optional | A category/type associated with the error |

## Example (as JSON)

```json
{
  "errorCode": 58,
  "errorMessage": "errorMessage6",
  "errorType": "errorType2"
}
```

