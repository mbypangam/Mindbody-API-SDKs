
# Push Api Result Get Subscriptions Response

A result returned for every request to the push API

## Structure

`PushApiResultGetSubscriptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ErrorInformation` | [`List<Models.PushApiError>`](../../doc/models/push-api-error.md) | Optional | - |
| `IsSuccess` | `bool?` | Optional | - |
| `MValue` | [`Models.GetSubscriptionsResponse`](../../doc/models/get-subscriptions-response.md) | Optional | A wrapper for a get subscriptions request |

## Example (as JSON)

```json
{
  "errorInformation": null,
  "isSuccess": null,
  "value": null
}
```

