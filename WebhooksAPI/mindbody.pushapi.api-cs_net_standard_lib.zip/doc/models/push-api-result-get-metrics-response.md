
# Push Api Result Get Metrics Response

A result returned for every request to the push API

## Structure

`PushApiResultGetMetricsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IsSuccess` | `bool?` | Optional | - |
| `MValue` | [`Models.GetMetricsResponse`](../../doc/models/get-metrics-response.md) | Optional | A wrapper for returning subscription metrics to API users |
| `ErrorInformation` | [`List<Models.PushApiError>`](../../doc/models/push-api-error.md) | Optional | - |

## Example (as JSON)

```json
{
  "value": null
}
```

