
# Push Api Result Subscription

A result returned for every request to the push API

## Structure

`PushApiResultSubscription`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `IsSuccess` | `bool?` | Optional | - |
| `MValue` | [`Models.Subscription`](../../doc/models/subscription.md) | Optional | A webhook subscription |
| `ErrorInformation` | [`List<Models.PushApiError>`](../../doc/models/push-api-error.md) | Optional | - |

## Example (as JSON)

```json
{
  "value": null
}
```

