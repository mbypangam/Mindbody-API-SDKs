
# Push Api Result Subscription

A result returned for every request to the push API

## Structure

`PushApiResultSubscription`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ErrorInformation` | [`List<Models.PushApiError>`](../../doc/models/push-api-error.md) | Optional | - |
| `IsSuccess` | `bool?` | Optional | - |
| `MValue` | [`Models.Subscription`](../../doc/models/subscription.md) | Optional | A webhook subscription |

## Example (as JSON)

```json
{
  "errorInformation": null,
  "isSuccess": null,
  "value": null
}
```

