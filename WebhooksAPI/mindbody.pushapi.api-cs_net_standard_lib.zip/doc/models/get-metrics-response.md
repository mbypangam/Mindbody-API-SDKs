
# Get Metrics Response

A wrapper for returning subscription metrics to API users

## Structure

`GetMetricsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Items` | [`List<Metric>`](../../doc/models/metric.md) | Optional | Contains the metrics for the passed subscription |

## Example (as JSON)

```json
{
  "items": [
    {
      "creationDateTime": "2016-03-13T12:52:32.123Z",
      "messagesAttempted": 161,
      "messagesDelivered": 15,
      "messagesFailed": 221,
      "messagesUndelivered": 81
    },
    {
      "creationDateTime": "2016-03-13T12:52:32.123Z",
      "messagesAttempted": 160,
      "messagesDelivered": 16,
      "messagesFailed": 222,
      "messagesUndelivered": 82
    }
  ]
}
```

