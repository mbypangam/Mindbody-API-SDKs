# Metrics

```csharp
MetricsController metricsController = client.MetricsController;
```

## Class Name

`MetricsController`


# Metrics Get

This endpoint gets metrics for all the subscriptions associated with your Public API developer account.

```csharp
MetricsGetAsync()
```

## Response Type

[`Task<Models.PushApiResultGetMetricsResponse>`](../../doc/models/push-api-result-get-metrics-response.md)

## Example Usage

```csharp
try
{
    PushApiResultGetMetricsResponse result = await metricsController.MetricsGetAsync();
}
catch (ApiException e){};
```

