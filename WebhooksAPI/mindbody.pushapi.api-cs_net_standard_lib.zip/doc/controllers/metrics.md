# Metrics

```csharp
MetricsController metricsController = client.MetricsController;
```

## Class Name

`MetricsController`


# Get Metrics

This endpoint gets metrics for all the subscriptions associated with your Public API developer account.

```csharp
GetMetricsAsync()
```

## Response Type

[`Task<Models.GetMetricsResponse>`](../../doc/models/get-metrics-response.md)

## Example Usage

```csharp
try
{
    GetMetricsResponse result = await metricsController.GetMetricsAsync();
}
catch (ApiException e){};
```

