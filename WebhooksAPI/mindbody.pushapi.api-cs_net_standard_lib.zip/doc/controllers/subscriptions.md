# Subscriptions

```csharp
SubscriptionsController subscriptionsController = client.SubscriptionsController;
```

## Class Name

`SubscriptionsController`

## Methods

* [Subscriptions Get](../../doc/controllers/subscriptions.md#subscriptions-get)
* [Subscriptions Create](../../doc/controllers/subscriptions.md#subscriptions-create)
* [Subscriptions Get 1](../../doc/controllers/subscriptions.md#subscriptions-get-1)
* [Subscriptions Delete](../../doc/controllers/subscriptions.md#subscriptions-delete)
* [Subscriptions Patch](../../doc/controllers/subscriptions.md#subscriptions-patch)


# Subscriptions Get

This endpoint searches for subscriptions associated with your developer portal account:

You can retrieve a specific subscription by calling GET(by ID).

```csharp
SubscriptionsGetAsync()
```

## Response Type

[`Task<Models.PushApiResultGetSubscriptionsResponse>`](../../doc/models/push-api-result-get-subscriptions-response.md)

## Example Usage

```csharp
try
{
    PushApiResultGetSubscriptionsResponse result = await subscriptionsController.SubscriptionsGetAsync();
}
catch (ApiException e){};
```


# Subscriptions Create

This endpoint creates a pending subscription that is linked to your developer portal account. After you have created a subscription, you can activate it using the PATCH Subscription endpoint.

```csharp
SubscriptionsCreateAsync(
    Models.CreateSubscriptionRequest request)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.CreateSubscriptionRequest`](../../doc/models/create-subscription-request.md) | Body, Required | - |

## Response Type

[`Task<Models.PushApiResultCreateSubscriptionResponse>`](../../doc/models/push-api-result-create-subscription-response.md)

## Example Usage

```csharp
var request = new CreateSubscriptionRequest();

try
{
    PushApiResultCreateSubscriptionResponse result = await subscriptionsController.SubscriptionsCreateAsync(request);
}
catch (ApiException e){};
```


# Subscriptions Get 1

This endpoint finds and returns the single subscription associated with the passed ID.

```csharp
SubscriptionsGet1Async(
    string subscriptionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscriptionId` | `string` | Template, Required | The id of the subscription to be retrieved. |

## Response Type

[`Task<Models.PushApiResultSubscription>`](../../doc/models/push-api-result-subscription.md)

## Example Usage

```csharp
string subscriptionId = "subscriptionId0";

try
{
    PushApiResultSubscription result = await subscriptionsController.SubscriptionsGet1Async(subscriptionId);
}
catch (ApiException e){};
```


# Subscriptions Delete

This endpoint deactivates a subscription associated with the passed ID.

```csharp
SubscriptionsDeleteAsync(
    string subscriptionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscriptionId` | `string` | Template, Required | The id of the subscription to be deleted. |

## Response Type

[`Task<Models.PushApiResultDeactivateSubscriptionResponse>`](../../doc/models/push-api-result-deactivate-subscription-response.md)

## Example Usage

```csharp
string subscriptionId = "subscriptionId0";

try
{
    PushApiResultDeactivateSubscriptionResponse result = await subscriptionsController.SubscriptionsDeleteAsync(subscriptionId);
}
catch (ApiException e){};
```


# Subscriptions Patch

This endpoint can activate a new subscription or reactivate an inactive subscription that is associated with your developer portal account, by updating the status. You can also update your subscription’s eventIds, eventSchemaVersion, referenceId, and webhookUrl.

```csharp
SubscriptionsPatchAsync(
    string subscriptionId,
    Models.PatchSubscriptionRequest request)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscriptionId` | `string` | Template, Required | The id of the subscription that was patched. |
| `request` | [`Models.PatchSubscriptionRequest`](../../doc/models/patch-subscription-request.md) | Body, Required | The patch request for the given subscription. |

## Response Type

[`Task<Models.PushApiResultSubscription>`](../../doc/models/push-api-result-subscription.md)

## Example Usage

```csharp
string subscriptionId = "subscriptionId0";
var request = new PatchSubscriptionRequest();

try
{
    PushApiResultSubscription result = await subscriptionsController.SubscriptionsPatchAsync(subscriptionId, request);
}
catch (ApiException e){};
```

