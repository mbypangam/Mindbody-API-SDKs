# Subscriptions

```csharp
SubscriptionsController subscriptionsController = client.SubscriptionsController;
```

## Class Name

`SubscriptionsController`

## Methods

* [Get Subscriptions](../../doc/controllers/subscriptions.md#get-subscriptions)
* [Create Subscription](../../doc/controllers/subscriptions.md#create-subscription)
* [Delete Subscription](../../doc/controllers/subscriptions.md#delete-subscription)
* [Get Subscription](../../doc/controllers/subscriptions.md#get-subscription)
* [Patch Subscription](../../doc/controllers/subscriptions.md#patch-subscription)


# Get Subscriptions

This endpoint searches for subscriptions associated with your developer portal account:

You can retrieve a specific subscription by calling GET(by ID).

```csharp
GetSubscriptionsAsync()
```

## Response Type

[`Task<Models.PushApiResultGetSubscriptionsResponse>`](../../doc/models/push-api-result-get-subscriptions-response.md)

## Example Usage

```csharp
try
{
    PushApiResultGetSubscriptionsResponse result = await subscriptionsController.GetSubscriptionsAsync();
}
catch (ApiException e){};
```


# Create Subscription

This endpoint creates a pending subscription that is linked to your developer portal account. After you have created a subscription, you can activate it using the PATCH Subscription endpoint.

```csharp
CreateSubscriptionAsync(
    Models.CreateSubscriptionRequest request)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request` | [`Models.CreateSubscriptionRequest`](../../doc/models/create-subscription-request.md) | Body, Required | - |

## Response Type

[`Task<Models.PushApiResultCreateSubscriptionResponse>`](../../doc/models/push-api-result-create-subscription-response.md)

## Example Usage

```csharp
var request = new CreateSubscriptionRequest();

try
{
    PushApiResultCreateSubscriptionResponse result = await subscriptionsController.CreateSubscriptionAsync(request);
}
catch (ApiException e){};
```


# Delete Subscription

This endpoint deactivates a subscription associated with the passed ID.

```csharp
DeleteSubscriptionAsync(
    string subscriptionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscriptionId` | `string` | Template, Required | The subscription ID (a GUID) that you are deactivating. |

## Response Type

[`Task<Models.PushApiResultDeactivateSubscriptionResponse>`](../../doc/models/push-api-result-deactivate-subscription-response.md)

## Example Usage

```csharp
string subscriptionId = "subscriptionId0";

try
{
    PushApiResultDeactivateSubscriptionResponse result = await subscriptionsController.DeleteSubscriptionAsync(subscriptionId);
}
catch (ApiException e){};
```


# Get Subscription

This endpoint finds and returns the single subscription associated with the passed ID.

```csharp
GetSubscriptionAsync(
    string subscriptionId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscriptionId` | `string` | Template, Required | Returns the single location identified by this ID (a GUID). |

## Response Type

[`Task<Models.PushApiResultSubscription>`](../../doc/models/push-api-result-subscription.md)

## Example Usage

```csharp
string subscriptionId = "subscriptionId0";

try
{
    PushApiResultSubscription result = await subscriptionsController.GetSubscriptionAsync(subscriptionId);
}
catch (ApiException e){};
```


# Patch Subscription

This endpoint can activate a new subscription or reactivate an inactive subscription that is associated with your developer portal account, by updating the status. You can also update your subscription’s eventIds, eventSchemaVersion, referenceId, and webhookUrl.

```csharp
PatchSubscriptionAsync(
    string subscriptionId,
    Models.PatchSubscriptionRequest request)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `subscriptionId` | `string` | Template, Required | The subscription’s ID (a GUID). |
| `request` | [`Models.PatchSubscriptionRequest`](../../doc/models/patch-subscription-request.md) | Body, Required | The patch request for the given subscription. |

## Response Type

[`Task<Models.PushApiResultSubscription>`](../../doc/models/push-api-result-subscription.md)

## Example Usage

```csharp
string subscriptionId = "subscriptionId0";
var request = new PatchSubscriptionRequest();

try
{
    PushApiResultSubscription result = await subscriptionsController.PatchSubscriptionAsync(subscriptionId, request);
}
catch (ApiException e){};
```

