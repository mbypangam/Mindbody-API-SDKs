
# Get Client Complete Info Response

Contains information about the requested client.

## Structure

`GetClientCompleteInfoResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client` | [`ClientWithSuspensionInfo`](../../doc/models/client-with-suspension-info.md) | Optional | Contains information about the requested client. |
| `client_services` | [`List of ClientService`](../../doc/models/client-service.md) | Optional | Contains information about client pricing options. |
| `client_contracts` | [`List of ClientContract`](../../doc/models/client-contract.md) | Optional | Contains information about client contract. |
| `client_memberships` | [`List of ClientMembership`](../../doc/models/client-membership.md) | Optional | Contains information about client Memberships. |
| `client_arrivals` | [`List of ClientArrival`](../../doc/models/client-arrival.md) | Optional | Contains information about client arrival services. |

## Example (as JSON)

```json
{
  "Client": null,
  "ClientServices": null,
  "ClientContracts": null,
  "ClientMemberships": null,
  "ClientArrivals": null
}
```

