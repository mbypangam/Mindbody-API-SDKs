
# Get Client Complete Info Response

Contains information about the requested client.

## Structure

`GetClientCompleteInfoResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client` | [`MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo`](../../doc/models/mindbody-public-api-dto-models-v6-client-with-suspension-info.md) | Optional | Contains information about the requested client. |
| `client_services` | [`List of MindbodyPublicApiDtoModelsV6ClientService`](../../doc/models/mindbody-public-api-dto-models-v6-client-service.md) | Optional | Contains information about client pricing options. |
| `client_contracts` | [`List of MindbodyPublicApiDtoModelsV6ClientContract`](../../doc/models/mindbody-public-api-dto-models-v6-client-contract.md) | Optional | Contains information about client contract. |
| `client_memberships` | [`List of MindbodyPublicApiDtoModelsV6ClientMembership`](../../doc/models/mindbody-public-api-dto-models-v6-client-membership.md) | Optional | Contains information about client Memberships. |
| `client_arrivals` | [`List of MindbodyPublicApiDtoModelsV6ClientArrival`](../../doc/models/mindbody-public-api-dto-models-v6-client-arrival.md) | Optional | Contains information about client arrival services. |

## Example (as JSON)

```json
{
  "Client": null,
  "ClientServices": null,
  "ClientContracts": null,
  "ClientMemberships": null,
  "ClientArrivals": null
}
```

