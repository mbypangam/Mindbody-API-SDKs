
# Mindbody Public Api Dto Models V6 Cross Regional Client Association

A client cross region association

## Structure

`MindbodyPublicApiDtoModelsV6CrossRegionalClientAssociation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `int` | Optional | The ID of the site to which the client belongs. |
| `client_id` | `string` | Optional | The client?s RSSID. |
| `unique_id` | `long\|int` | Optional | The client?s unique ID. |

## Example (as JSON)

```json
{
  "SiteId": null,
  "ClientId": null,
  "UniqueId": null
}
```

