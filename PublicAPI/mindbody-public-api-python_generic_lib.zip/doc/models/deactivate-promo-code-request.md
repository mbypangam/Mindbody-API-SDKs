
# Deactivate Promo Code Request

## Structure

`DeactivatePromoCodeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promotion_id` | `int` | Required | The promocodeID |

## Example (as JSON)

```json
{
  "PromotionId": 74
}
```

