
# Relationship

Jim is a RelationshipName1 of John. John is a RelationshipName2 of Jim.

## Structure

`Relationship`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The ID of the relationship. |
| `relationship_name_1` | `string` | Optional | The name of the first relationship. |
| `relationship_name_2` | `string` | Optional | The name of the second relationship. |

## Example (as JSON)

```json
{
  "Id": null,
  "RelationshipName1": null,
  "RelationshipName2": null
}
```

