
# Get Tips Response

## Structure

`GetTipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `tips` | [`List of Tip`](../../doc/models/tip.md) | Optional | Contains information about tips given to staff members within the given date range. Results are ordered by StaffId. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Tips": null
}
```

