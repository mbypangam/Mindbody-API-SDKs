
# Get Contact Logs Response

## Structure

`GetContactLogsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `contact_logs` | [`List of MindbodyPublicApiDtoModelsV6ContactLog`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log.md) | Optional | Contains the information about the contact logs. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ContactLogs": null
}
```

