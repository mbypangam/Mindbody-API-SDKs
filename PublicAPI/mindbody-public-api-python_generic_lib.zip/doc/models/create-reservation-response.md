
# Create Reservation Response

Create reservation response.

## Structure

`CreateReservationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reservation` | [`Reservation`](../../doc/models/reservation.md) | Optional | Reservation details. |
| `response_details` | [`ResponseDetails`](../../doc/models/response-details.md) | Optional | Response details, e.g. status, transactionId. |

## Example (as JSON)

```json
{
  "Reservation": null,
  "ResponseDetails": null
}
```

