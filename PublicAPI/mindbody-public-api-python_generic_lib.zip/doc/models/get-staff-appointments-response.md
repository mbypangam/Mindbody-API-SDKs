
# Get Staff Appointments Response

Get Staff Appointments Response Model

## Structure

`GetStaffAppointmentsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `appointments` | [`List of Appointment`](../../doc/models/appointment.md) | Optional | Contains information about appointments and their details. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Appointments": null
}
```

