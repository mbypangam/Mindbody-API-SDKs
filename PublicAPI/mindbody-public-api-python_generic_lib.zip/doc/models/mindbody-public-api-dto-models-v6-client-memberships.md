
# Mindbody Public Api Dto Models V6 Client Memberships

## Structure

`MindbodyPublicApiDtoModelsV6ClientMemberships`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `string` | Optional | ID of the client. |
| `memberships` | [`List of MindbodyPublicApiDtoModelsV6ClientMembership`](../../doc/models/mindbody-public-api-dto-models-v6-client-membership.md) | Optional | Contains information about the Client Memberships details. |
| `error_message` | `string` | Optional | Incase if invalid clientID passed, we get ErrorMessage instead of Memberships. |

## Example (as JSON)

```json
{
  "ClientId": null,
  "Memberships": null,
  "ErrorMessage": null
}
```

