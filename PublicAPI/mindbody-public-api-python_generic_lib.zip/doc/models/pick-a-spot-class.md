
# Pick a Spot Class

Pick A Spot class detail.

## Structure

`PickASpotClass`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `int` | Optional | Site ID. |
| `location_id` | `int` | Optional | Location ID. |
| `class_id` | `string` | Optional | Class ID. |
| `class_external_id` | `string` | Optional | Class external ID. |
| `class_name` | `string` | Optional | Class Name. |
| `class_start_time` | `datetime` | Optional | Class start time. |
| `class_end_time` | `datetime` | Optional | Class end time. |
| `class_maximum_capacity` | `int` | Optional | Class maximum capacity |
| `room_id` | `string` | Optional | - |
| `spots` | [`Spot`](../../doc/models/spot.md) | Optional | - |
| `reservations` | [`List of Reservation`](../../doc/models/reservation.md) | Optional | - |

## Example (as JSON)

```json
{
  "SiteId": null,
  "LocationId": null,
  "ClassId": null,
  "ClassExternalId": null,
  "ClassName": null,
  "ClassStartTime": null,
  "ClassEndTime": null,
  "ClassMaximumCapacity": null,
  "RoomId": null,
  "Spots": null,
  "Reservations": null
}
```

