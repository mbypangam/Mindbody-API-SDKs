
# Get Client Duplicates Response

## Structure

`GetClientDuplicatesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `client_duplicates` | [`List[ClientDuplicate]`](../../doc/models/client-duplicate.md) | Optional | The requested clients. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "ClientDuplicates": [
    {
      "Id": "Id3",
      "UniqueId": 205,
      "FirstName": "FirstName3",
      "LastName": "LastName3",
      "Email": "Email3"
    }
  ]
}
```

