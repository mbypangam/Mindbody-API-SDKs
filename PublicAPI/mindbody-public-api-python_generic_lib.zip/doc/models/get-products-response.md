
# Get Products Response

## Structure

`GetProductsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `products` | [`List of Product`](../../doc/models/product.md) | Optional | Contains information about the products. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Products": [
    {
      "ProductId": 98,
      "Id": "Id8",
      "CategoryId": 54,
      "SubCategoryId": 166,
      "Price": 39.42
    },
    {
      "ProductId": 99,
      "Id": "Id9",
      "CategoryId": 55,
      "SubCategoryId": 165,
      "Price": 39.43
    }
  ]
}
```

