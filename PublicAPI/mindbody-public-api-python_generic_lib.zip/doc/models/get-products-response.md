
# Get Products Response

## Structure

`GetProductsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `products` | [`List of Product`](../../doc/models/product.md) | Optional | Contains information about the products. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Products": null
}
```

