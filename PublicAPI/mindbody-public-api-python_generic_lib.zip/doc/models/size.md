
# Size

## Structure

`Size`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The unique ID of the product size. |
| `name` | `string` | Optional | The name of the size of product. |

## Example (as JSON)

```json
{
  "Id": 146,
  "Name": "Name0"
}
```

