
# Size

## Structure

`Size`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The unique ID of the product size. |
| `name` | `str` | Optional | The name of the size of product. |

## Example (as JSON)

```json
{
  "Id": 112,
  "Name": "Name8"
}
```

