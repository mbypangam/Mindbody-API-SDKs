
# Mindbody Public Api Dto Models V6 Client Arrival

## Structure

`MindbodyPublicApiDtoModelsV6ClientArrival`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `arrival_program_id` | `int` | Optional | Arrival program id |
| `arrival_program_name` | `string` | Optional | Arrival program name |
| `can_access` | `bool` | Optional | Property to check client can access arrival service. |
| `locations_i_ds` | `List of int` | Optional | List of locations where arrival service can availed |

## Example (as JSON)

```json
{
  "ArrivalProgramID": null,
  "ArrivalProgramName": null,
  "CanAccess": null,
  "LocationsIDs": null
}
```

