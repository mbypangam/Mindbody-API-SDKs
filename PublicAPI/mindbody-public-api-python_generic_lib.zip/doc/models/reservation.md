
# Reservation

## Structure

`Reservation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reservation_id` | `string` | Optional | - |
| `reservation_external_id` | `string` | Optional | - |
| `class_id` | `string` | Optional | - |
| `class_external_id` | `string` | Optional | - |
| `member_external_id` | `string` | Optional | - |
| `reservation_type` | `string` | Optional | - |
| `spots` | [`Spot`](../../doc/models/spot.md) | Optional | - |
| `is_confirmed` | `bool` | Optional | - |
| `confirmation_date` | `datetime` | Optional | - |

## Example (as JSON)

```json
{
  "ReservationId": null,
  "ReservationExternalId": null,
  "ClassId": null,
  "ClassExternalId": null,
  "MemberExternalId": null,
  "ReservationType": null,
  "Spots": null,
  "IsConfirmed": null,
  "ConfirmationDate": null
}
```

