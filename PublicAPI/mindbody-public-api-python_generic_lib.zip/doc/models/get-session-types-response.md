
# Get Session Types Response

## Structure

`GetSessionTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `session_types` | [`List of SessionType`](../../doc/models/session-type.md) | Optional | Contains information about sessions. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "SessionTypes": [
    {
      "Type": "All",
      "DefaultTimeLength": 59,
      "StaffTimeLength": 219,
      "Id": 219,
      "Name": "Name9"
    }
  ]
}
```

