
# Get Resources Response

## Structure

`GetResourcesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `resources` | [`List[Resource1]`](../../doc/models/resource-1.md) | Optional | - |

## Example (as JSON)

```json
{
  "Resources": [
    {
      "Id": 181,
      "Name": "Name3",
      "LocationId": 15,
      "IsActive": true,
      "ScheduleTypes": [
        "Enrollment",
        "Appointment"
      ]
    },
    {
      "Id": 182,
      "Name": "Name4",
      "LocationId": 14,
      "IsActive": false,
      "ScheduleTypes": [
        "Appointment",
        "Resource",
        "Media"
      ]
    }
  ]
}
```

