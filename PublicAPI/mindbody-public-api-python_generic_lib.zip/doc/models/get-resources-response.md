
# Get Resources Response

## Structure

`GetResourcesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `resources` | [`List of Resource`](../../doc/models/resource.md) | Optional | Contains information about resources as the business. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Resources": null
}
```

