
# Mindbody Public Api Dto Models V6 Location

## Structure

`MindbodyPublicApiDtoModelsV6Location`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `additional_image_ur_ls` | `List of string` | Optional | A list of URLs of any images associated with this location. |
| `address` | `string` | Optional | The first line of the location's street address. |
| `address_2` | `string` | Optional | A second address line for the location's street address, if needed. |
| `amenities` | [`List of MindbodyPublicApiDtoModelsV6Amenity`](../../doc/models/mindbody-public-api-dto-models-v6-amenity.md) | Optional | A list of strings representing amenities available at the location. |
| `business_description` | `string` | Optional | The business description for the location, as configured by the business owner. |
| `city` | `string` | Optional | The location's city. |
| `description` | `string` | Optional | A description of the location. |
| `has_classes` | `bool` | Optional | When `true`, indicates that classes are held at this location.<br /><br>When `false`, Indicates that classes are not held at this location. |
| `id` | `int` | Optional | The ID assigned to this location. |
| `latitude` | `float` | Optional | The location's latitude. |
| `longitude` | `float` | Optional | The location's longitude. |
| `name` | `string` | Optional | The name of this location. |
| `phone` | `string` | Optional | The location's phone number. |
| `phone_extension` | `string` | Optional | The location's phone extension. |
| `postal_code` | `string` | Optional | The location's postal code. |
| `site_id` | `int` | Optional | The ID number assigned to this location. |
| `state_prov_code` | `string` | Optional | The location's state or province code. |
| `tax_1` | `float` | Optional | A decimal representation of the location's first tax rate. Tax properties are provided to apply all taxes to the purchase price that the purchase is subject to. Use as many tax properties as needed to represent all the taxes that apply in the location. Enter a decimal number that represents the appropriate tax rate. For example, for an 8% sales tax, enter 0.08. |
| `tax_2` | `float` | Optional | A decimal representation of the location's second tax rate. See the example in the description of Tax1. |
| `tax_3` | `float` | Optional | A decimal representation of the location's third tax rate. See the example in the description of Tax1. |
| `tax_4` | `float` | Optional | A decimal representation of the location's fourth tax rate. See the example in the description of Tax1. |
| `tax_5` | `float` | Optional | A decimal representation of the location's fifth tax rate. See the example in the description of Tax1. |
| `total_number_of_ratings` | `int` | Optional | The number of reviews that clients have left for this location. |
| `average_rating` | `float` | Optional | The average rating for the location, out of five stars. |
| `total_number_of_deals` | `long\|int` | Optional | The number of distinct introductory pricing options available for purchase at this location. |

## Example (as JSON)

```json
{
  "AdditionalImageURLs": null,
  "Address": null,
  "Address2": null,
  "Amenities": null,
  "BusinessDescription": null,
  "City": null,
  "Description": null,
  "HasClasses": null,
  "Id": null,
  "Latitude": null,
  "Longitude": null,
  "Name": null,
  "Phone": null,
  "PhoneExtension": null,
  "PostalCode": null,
  "SiteID": null,
  "StateProvCode": null,
  "Tax1": null,
  "Tax2": null,
  "Tax3": null,
  "Tax4": null,
  "Tax5": null,
  "TotalNumberOfRatings": null,
  "AverageRating": null,
  "TotalNumberOfDeals": null
}
```

