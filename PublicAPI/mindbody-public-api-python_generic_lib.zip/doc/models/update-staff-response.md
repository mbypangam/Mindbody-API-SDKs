
# Update Staff Response

## Structure

`UpdateStaffResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `staff` | [`MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Contains information about the staff |

## Example (as JSON)

```json
{
  "Staff": null
}
```

