
# Class Schedule

Represents a single class instance. The class meets at the start time, goes until the end time.

## Structure

`ClassSchedule`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `classes` | [`List of Class`](../../doc/models/class.md) | Optional | Contains information about a class. |
| `clients` | [`List of Client`](../../doc/models/client.md) | Optional | Contains information about clients. |
| `course` | [`Course`](../../doc/models/course.md) | Optional | A course. |
| `semester_id` | `int` | Optional | The semester ID for the enrollment (if any). |
| `is_available` | `bool` | Optional | When `true`, indicates that the enrollment shows in consumer mode, has not started yet, and there is room in each class of the enrollment.<br /><br>When `false`, indicates that either the enrollment does not show in consumer mode, has already started, or there is no room in some classes of the enrollment. |
| `id` | `int` | Optional | The unique ID of the class schedule. |
| `class_description` | [`ClassDescription`](../../doc/models/class-description.md) | Optional | Represents a class definition. The class meets at the start time, goes until the end time. |
| `day_sunday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Sundays. |
| `day_monday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Mondays. |
| `day_tuesday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Tuesdays. |
| `day_wednesday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Wednesdays. |
| `day_thursday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Thursdays. |
| `day_friday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Fridays. |
| `day_saturday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Saturdays. |
| `allow_open_enrollment` | `bool` | Optional | When `true`, indicates that the enrollment allows booking after the enrollment has started. |
| `allow_date_forward_enrollment` | `bool` | Optional | When `true`, indicates that this the enrollment shows in consumer mode, the enrollment has not started yet, and there is room in each class of the enrollment. |
| `start_time` | `datetime` | Optional | The time this class schedule starts. |
| `end_time` | `datetime` | Optional | The time this class schedule ends. |
| `start_date` | `datetime` | Optional | The date this class schedule starts. |
| `end_date` | `datetime` | Optional | The date this class schedule ends. |
| `staff` | [`Staff`](../../doc/models/staff.md) | Optional | The Staff |
| `location` | [`Location`](../../doc/models/location.md) | Optional | - |

## Example (as JSON)

```json
{
  "Classes": [
    {
      "ClassScheduleId": 27,
      "Visits": [
        {
          "AppointmentId": 122,
          "AppointmentGenderPreference": "Female",
          "AppointmentStatus": "NoShow",
          "ClassId": 214,
          "ClientId": "ClientId6"
        },
        {
          "AppointmentId": 121,
          "AppointmentGenderPreference": "Male",
          "AppointmentStatus": "Arrived",
          "ClassId": 215,
          "ClientId": "ClientId5"
        },
        {
          "AppointmentId": 120,
          "AppointmentGenderPreference": "None",
          "AppointmentStatus": "Confirmed",
          "ClassId": 216,
          "ClientId": "ClientId4"
        }
      ],
      "Clients": [
        {
          "AppointmentGenderPreference": "Female",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country2",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value3",
              "Id": 35,
              "DataType": "DataType9",
              "Name": "Name5"
            },
            {
              "Value": "Value4",
              "Id": 36,
              "DataType": "DataType0",
              "Name": "Name6"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "Male",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country3",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value4",
              "Id": 36,
              "DataType": "DataType0",
              "Name": "Name6"
            },
            {
              "Value": "Value5",
              "Id": 37,
              "DataType": "DataType1",
              "Name": "Name7"
            },
            {
              "Value": "Value6",
              "Id": 38,
              "DataType": "DataType2",
              "Name": "Name8"
            }
          ]
        }
      ],
      "Location": {},
      "Resource": {
        "Id": 255,
        "Name": "Name3"
      }
    },
    {
      "ClassScheduleId": 28,
      "Visits": [
        {
          "AppointmentId": 121,
          "AppointmentGenderPreference": "Male",
          "AppointmentStatus": "Arrived",
          "ClassId": 215,
          "ClientId": "ClientId5"
        }
      ],
      "Clients": [
        {
          "AppointmentGenderPreference": "Male",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country3",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value4",
              "Id": 36,
              "DataType": "DataType0",
              "Name": "Name6"
            },
            {
              "Value": "Value5",
              "Id": 37,
              "DataType": "DataType1",
              "Name": "Name7"
            },
            {
              "Value": "Value6",
              "Id": 38,
              "DataType": "DataType2",
              "Name": "Name8"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "None",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country4",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value5",
              "Id": 37,
              "DataType": "DataType1",
              "Name": "Name7"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "Female",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country5",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value6",
              "Id": 38,
              "DataType": "DataType2",
              "Name": "Name8"
            },
            {
              "Value": "Value7",
              "Id": 39,
              "DataType": "DataType3",
              "Name": "Name9"
            }
          ]
        }
      ],
      "Location": {},
      "Resource": {
        "Id": 254,
        "Name": "Name2"
      }
    }
  ],
  "Clients": [
    {
      "AppointmentGenderPreference": "Male",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country9",
      "CreationDate": "2016-03-13T12:52:32.123Z",
      "CustomClientFields": [
        {
          "Value": "Value0",
          "Id": 12,
          "DataType": "DataType6",
          "Name": "Name2"
        },
        {
          "Value": "Value1",
          "Id": 13,
          "DataType": "DataType7",
          "Name": "Name3"
        },
        {
          "Value": "Value2",
          "Id": 14,
          "DataType": "DataType8",
          "Name": "Name4"
        }
      ]
    },
    {
      "AppointmentGenderPreference": "None",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country0",
      "CreationDate": "2016-03-13T12:52:32.123Z",
      "CustomClientFields": [
        {
          "Value": "Value1",
          "Id": 13,
          "DataType": "DataType7",
          "Name": "Name3"
        }
      ]
    },
    {
      "AppointmentGenderPreference": "Female",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country1",
      "CreationDate": "2016-03-13T12:52:32.123Z",
      "CustomClientFields": [
        {
          "Value": "Value2",
          "Id": 14,
          "DataType": "DataType8",
          "Name": "Name4"
        },
        {
          "Value": "Value3",
          "Id": 15,
          "DataType": "DataType9",
          "Name": "Name5"
        }
      ]
    }
  ],
  "Course": {
    "Id": 0,
    "Name": "Name6",
    "Description": "Description0",
    "Notes": "Notes2",
    "StartDate": "2016-03-13T12:52:32.123Z"
  },
  "SemesterId": 192,
  "IsAvailable": false
}
```

