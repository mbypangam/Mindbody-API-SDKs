
# Upload Client Document Response

## Structure

`UploadClientDocumentResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `file_size` | `long\|int` | Optional | The size of the uploaded file. |
| `file_name` | `string` | Optional | The name of the uploaded file. |

## Example (as JSON)

```json
{
  "FileSize": 214,
  "FileName": "FileName6"
}
```

