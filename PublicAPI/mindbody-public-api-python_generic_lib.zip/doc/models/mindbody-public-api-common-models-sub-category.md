
# Mindbody Public Api Common Models Sub Category

## Structure

`MindbodyPublicApiCommonModelsSubCategory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The Id of the subcategory. |
| `sub_category_name` | `string` | Optional | The name of the subcategory. |
| `active` | `bool` | Optional | When `true`, indicates that the subcategory is active. |

## Example (as JSON)

```json
{
  "Id": null,
  "SubCategoryName": null,
  "Active": null
}
```

