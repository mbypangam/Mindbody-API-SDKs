
# Mindbody Public Api Dto Models V6 Sale Controller Checkout Shopping Cart Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerCheckoutShoppingCartResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shopping_cart` | [`MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleShoppingCart`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-completed-sale-shopping-cart.md) | Optional | Contains information about the shopping cart. |
| `classes` | [`List of MindbodyPublicApiDtoModelsV6Class`](../../doc/models/mindbody-public-api-dto-models-v6-class.md) | Optional | Contains information about the classes. |
| `appointments` | [`List of MindbodyPublicApiDtoModelsV6Appointment`](../../doc/models/mindbody-public-api-dto-models-v6-appointment.md) | Optional | Contains information about the appointments. |
| `enrollments` | [`List of MindbodyPublicApiDtoModelsV6ClassSchedule`](../../doc/models/mindbody-public-api-dto-models-v6-class-schedule.md) | Optional | Contains information about enrollment class schedules. |

## Example (as JSON)

```json
{
  "ShoppingCart": null,
  "Classes": null,
  "Appointments": null,
  "Enrollments": null
}
```

