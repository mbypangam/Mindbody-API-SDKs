
# Get Client Formula Notes Response

Enables to retrieve cross regional formula notes for a client, or for a specific appointment. The two parameters are optional, however at least one must be provided. This endpoint supports pagination.

## Structure

`GetClientFormulaNotesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `formula_notes` | [`List of FormulaNoteResponse`](../../doc/models/formula-note-response.md) | Optional | Contains details about the client’s formula. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "FormulaNotes": null
}
```

