
# Mindbody Public Api Dto Models V6 Sale Controller Completed Sale Transaction Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleTransactionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transaction_id` | `int` | Optional | The Transaction ID. |
| `authentication_url` | `string` | Optional | The optional valid URL provided by the bank. |

## Example (as JSON)

```json
{
  "TransactionId": null,
  "AuthenticationUrl": null
}
```

