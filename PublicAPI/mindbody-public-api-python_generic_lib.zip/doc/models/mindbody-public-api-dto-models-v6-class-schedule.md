
# Mindbody Public Api Dto Models V6 Class Schedule

Represents a single class instance. The class meets at the start time, goes until the end time.

## Structure

`MindbodyPublicApiDtoModelsV6ClassSchedule`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `classes` | [`List of MindbodyPublicApiDtoModelsV6Class`](../../doc/models/mindbody-public-api-dto-models-v6-class.md) | Optional | Contains information about a class. |
| `clients` | [`List of MindbodyPublicApiDtoModelsV6Client`](../../doc/models/mindbody-public-api-dto-models-v6-client.md) | Optional | Contains information about clients. |
| `course` | [`MindbodyPublicApiDtoModelsV6Course`](../../doc/models/mindbody-public-api-dto-models-v6-course.md) | Optional | Contains information about the course that the enrollment is a part of. |
| `semester_id` | `int` | Optional | The semester ID for the enrollment (if any). |
| `is_available` | `bool` | Optional | When `true`, indicates that the enrollment shows in consumer mode, has not started yet, and there is room in each class of the enrollment.<br /><br>When `false`, indicates that either the enrollment does not show in consumer mode, has already started, or there is no room in some classes of the enrollment. |
| `id` | `int` | Optional | The unique ID of the class schedule. |
| `class_description` | [`MindbodyPublicApiDtoModelsV6ClassDescription`](../../doc/models/mindbody-public-api-dto-models-v6-class-description.md) | Optional | Contains information about the class. |
| `day_sunday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Sundays. |
| `day_monday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Mondays. |
| `day_tuesday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Tuesdays. |
| `day_wednesday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Wednesdays. |
| `day_thursday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Thursdays. |
| `day_friday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Fridays. |
| `day_saturday` | `bool` | Optional | When `true`, indicates that this schedule occurs on Saturdays. |
| `allow_open_enrollment` | `bool` | Optional | When `true`, indicates that the enrollment allows booking after the enrollment has started. |
| `allow_date_forward_enrollment` | `bool` | Optional | When `true`, indicates that this the enrollment shows in consumer mode, the enrollment has not started yet, and there is room in each class of the enrollment. |
| `start_time` | `datetime` | Optional | The time this class schedule starts. |
| `end_time` | `datetime` | Optional | The time this class schedule ends. |
| `start_date` | `datetime` | Optional | The date this class schedule starts. |
| `end_date` | `datetime` | Optional | The date this class schedule ends. |
| `staff` | [`MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Contains information about the staff member who is regularly scheduled to teach the class. |
| `location` | [`MindbodyPublicApiDtoModelsV6Location`](../../doc/models/mindbody-public-api-dto-models-v6-location.md) | Optional | Contains information about the regularly scheduled location of this class. |

## Example (as JSON)

```json
{
  "Classes": null,
  "Clients": null,
  "Course": null,
  "SemesterId": null,
  "IsAvailable": null,
  "Id": null,
  "ClassDescription": null,
  "DaySunday": null,
  "DayMonday": null,
  "DayTuesday": null,
  "DayWednesday": null,
  "DayThursday": null,
  "DayFriday": null,
  "DaySaturday": null,
  "AllowOpenEnrollment": null,
  "AllowDateForwardEnrollment": null,
  "StartTime": null,
  "EndTime": null,
  "StartDate": null,
  "EndDate": null,
  "Staff": null,
  "Location": null
}
```

