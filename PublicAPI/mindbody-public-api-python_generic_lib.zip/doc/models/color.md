
# Color

A color used by products.

## Structure

`Color`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The unique ID of the product color. |
| `name` | `string` | Optional | The name of the color of product. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

