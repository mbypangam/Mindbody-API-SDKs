
# Get Waitlist Entries Response

## Structure

`GetWaitlistEntriesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `waitlist_entries` | [`List of WaitlistEntry`](../../doc/models/waitlist-entry.md) | Optional | Contains information about the waiting list entries. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "WaitlistEntries": [
    {
      "ClassDate": "2016-03-13T12:52:32.123Z",
      "ClassId": 192,
      "ClassSchedule": {
        "Classes": [
          {
            "ClassScheduleId": 203,
            "Visits": [
              {
                "AppointmentId": 120,
                "AppointmentGenderPreference": "Male",
                "AppointmentStatus": "Booked",
                "ClassId": 216,
                "ClientId": "ClientId0"
              }
            ],
            "Clients": [
              {
                "AppointmentGenderPreference": "Male",
                "BirthDate": "2016-03-13T12:52:32.123Z",
                "Country": "Country6",
                "CreationDate": "2016-03-13T12:52:32.123Z",
                "CustomClientFields": [
                  {
                    "Value": "Value7",
                    "Id": 211,
                    "DataType": "DataType3",
                    "Name": "Name9"
                  },
                  {
                    "Value": "Value8",
                    "Id": 212,
                    "DataType": "DataType4",
                    "Name": "Name0"
                  },
                  {
                    "Value": "Value9",
                    "Id": 213,
                    "DataType": "DataType5",
                    "Name": "Name1"
                  }
                ]
              },
              {
                "AppointmentGenderPreference": "None",
                "BirthDate": "2016-03-13T12:52:32.123Z",
                "Country": "Country7",
                "CreationDate": "2016-03-13T12:52:32.123Z",
                "CustomClientFields": [
                  {
                    "Value": "Value8",
                    "Id": 212,
                    "DataType": "DataType4",
                    "Name": "Name0"
                  }
                ]
              },
              {
                "AppointmentGenderPreference": "Female",
                "BirthDate": "2016-03-13T12:52:32.123Z",
                "Country": "Country8",
                "CreationDate": "2016-03-13T12:52:32.123Z",
                "CustomClientFields": [
                  {
                    "Value": "Value9",
                    "Id": 213,
                    "DataType": "DataType5",
                    "Name": "Name1"
                  },
                  {
                    "Value": "Value0",
                    "Id": 214,
                    "DataType": "DataType6",
                    "Name": "Name2"
                  }
                ]
              }
            ],
            "Location": {},
            "Resource": {
              "Id": 79,
              "Name": "Name9"
            }
          },
          {
            "ClassScheduleId": 204,
            "Visits": [
              {
                "AppointmentId": 119,
                "AppointmentGenderPreference": "None",
                "AppointmentStatus": "Requested",
                "ClassId": 217,
                "ClientId": "ClientId9"
              },
              {
                "AppointmentId": 120,
                "AppointmentGenderPreference": "Male",
                "AppointmentStatus": "Booked",
                "ClassId": 216,
                "ClientId": "ClientId0"
              },
              {
                "AppointmentId": 121,
                "AppointmentGenderPreference": "Female",
                "AppointmentStatus": "Completed",
                "ClassId": 215,
                "ClientId": "ClientId1"
              }
            ],
            "Clients": [
              {
                "AppointmentGenderPreference": "None",
                "BirthDate": "2016-03-13T12:52:32.123Z",
                "Country": "Country7",
                "CreationDate": "2016-03-13T12:52:32.123Z",
                "CustomClientFields": [
                  {
                    "Value": "Value8",
                    "Id": 212,
                    "DataType": "DataType4",
                    "Name": "Name0"
                  }
                ]
              }
            ],
            "Location": {},
            "Resource": {
              "Id": 78,
              "Name": "Name8"
            }
          },
          {
            "ClassScheduleId": 205,
            "Visits": [
              {
                "AppointmentId": 118,
                "AppointmentGenderPreference": "Female",
                "AppointmentStatus": "None",
                "ClassId": 218,
                "ClientId": "ClientId8"
              },
              {
                "AppointmentId": 119,
                "AppointmentGenderPreference": "None",
                "AppointmentStatus": "Requested",
                "ClassId": 217,
                "ClientId": "ClientId9"
              }
            ],
            "Clients": [
              {
                "AppointmentGenderPreference": "Female",
                "BirthDate": "2016-03-13T12:52:32.123Z",
                "Country": "Country8",
                "CreationDate": "2016-03-13T12:52:32.123Z",
                "CustomClientFields": [
                  {
                    "Value": "Value9",
                    "Id": 213,
                    "DataType": "DataType5",
                    "Name": "Name1"
                  },
                  {
                    "Value": "Value0",
                    "Id": 214,
                    "DataType": "DataType6",
                    "Name": "Name2"
                  }
                ]
              },
              {
                "AppointmentGenderPreference": "Male",
                "BirthDate": "2016-03-13T12:52:32.123Z",
                "Country": "Country9",
                "CreationDate": "2016-03-13T12:52:32.123Z",
                "CustomClientFields": [
                  {
                    "Value": "Value0",
                    "Id": 214,
                    "DataType": "DataType6",
                    "Name": "Name2"
                  },
                  {
                    "Value": "Value1",
                    "Id": 215,
                    "DataType": "DataType7",
                    "Name": "Name3"
                  },
                  {
                    "Value": "Value2",
                    "Id": 216,
                    "DataType": "DataType8",
                    "Name": "Name4"
                  }
                ]
              }
            ],
            "Location": {},
            "Resource": {
              "Id": 77,
              "Name": "Name7"
            }
          }
        ],
        "Clients": [
          {},
          {}
        ],
        "Course": {
          "Id": 80,
          "Name": "Name2",
          "Description": "Description6",
          "Notes": "Notes4",
          "StartDate": "2016-03-13T12:52:32.123Z"
        },
        "SemesterId": 144,
        "IsAvailable": false
      },
      "Client": {},
      "EnrollmentDateForward": "2016-03-13T12:52:32.123Z"
    },
    {
      "ClassDate": "2016-03-13T12:52:32.123Z",
      "ClassId": 193,
      "ClassSchedule": {
        "Classes": [
          {
            "ClassScheduleId": 204,
            "Visits": [
              {
                "AppointmentId": 119,
                "AppointmentGenderPreference": "None",
                "AppointmentStatus": "Requested",
                "ClassId": 217,
                "ClientId": "ClientId9"
              },
              {
                "AppointmentId": 120,
                "AppointmentGenderPreference": "Male",
                "AppointmentStatus": "Booked",
                "ClassId": 216,
                "ClientId": "ClientId0"
              },
              {
                "AppointmentId": 121,
                "AppointmentGenderPreference": "Female",
                "AppointmentStatus": "Completed",
                "ClassId": 215,
                "ClientId": "ClientId1"
              }
            ],
            "Clients": [
              {
                "AppointmentGenderPreference": "None",
                "BirthDate": "2016-03-13T12:52:32.123Z",
                "Country": "Country7",
                "CreationDate": "2016-03-13T12:52:32.123Z",
                "CustomClientFields": [
                  {
                    "Value": "Value8",
                    "Id": 212,
                    "DataType": "DataType4",
                    "Name": "Name0"
                  }
                ]
              }
            ],
            "Location": {},
            "Resource": {
              "Id": 78,
              "Name": "Name8"
            }
          }
        ],
        "Clients": [
          {}
        ],
        "Course": {
          "Id": 79,
          "Name": "Name1",
          "Description": "Description5",
          "Notes": "Notes3",
          "StartDate": "2016-03-13T12:52:32.123Z"
        },
        "SemesterId": 143,
        "IsAvailable": true
      },
      "Client": {},
      "EnrollmentDateForward": "2016-03-13T12:52:32.123Z"
    },
    {
      "ClassDate": "2016-03-13T12:52:32.123Z",
      "ClassId": 194,
      "ClassSchedule": {
        "Classes": [
          {
            "ClassScheduleId": 205,
            "Visits": [
              {
                "AppointmentId": 118,
                "AppointmentGenderPreference": "Female",
                "AppointmentStatus": "None",
                "ClassId": 218,
                "ClientId": "ClientId8"
              },
              {
                "AppointmentId": 119,
                "AppointmentGenderPreference": "None",
                "AppointmentStatus": "Requested",
                "ClassId": 217,
                "ClientId": "ClientId9"
              }
            ],
            "Clients": [
              {
                "AppointmentGenderPreference": "Female",
                "BirthDate": "2016-03-13T12:52:32.123Z",
                "Country": "Country8",
                "CreationDate": "2016-03-13T12:52:32.123Z",
                "CustomClientFields": [
                  {
                    "Value": "Value9",
                    "Id": 213,
                    "DataType": "DataType5",
                    "Name": "Name1"
                  },
                  {
                    "Value": "Value0",
                    "Id": 214,
                    "DataType": "DataType6",
                    "Name": "Name2"
                  }
                ]
              },
              {
                "AppointmentGenderPreference": "Male",
                "BirthDate": "2016-03-13T12:52:32.123Z",
                "Country": "Country9",
                "CreationDate": "2016-03-13T12:52:32.123Z",
                "CustomClientFields": [
                  {
                    "Value": "Value0",
                    "Id": 214,
                    "DataType": "DataType6",
                    "Name": "Name2"
                  },
                  {
                    "Value": "Value1",
                    "Id": 215,
                    "DataType": "DataType7",
                    "Name": "Name3"
                  },
                  {
                    "Value": "Value2",
                    "Id": 216,
                    "DataType": "DataType8",
                    "Name": "Name4"
                  }
                ]
              }
            ],
            "Location": {},
            "Resource": {
              "Id": 77,
              "Name": "Name7"
            }
          },
          {
            "ClassScheduleId": 206,
            "Visits": [
              {
                "AppointmentId": 117,
                "AppointmentGenderPreference": "Male",
                "AppointmentStatus": "LateCancelled",
                "ClassId": 219,
                "ClientId": "ClientId7"
              }
            ],
            "Clients": [
              {
                "AppointmentGenderPreference": "Male",
                "BirthDate": "2016-03-13T12:52:32.123Z",
                "Country": "Country9",
                "CreationDate": "2016-03-13T12:52:32.123Z",
                "CustomClientFields": [
                  {
                    "Value": "Value0",
                    "Id": 214,
                    "DataType": "DataType6",
                    "Name": "Name2"
                  },
                  {
                    "Value": "Value1",
                    "Id": 215,
                    "DataType": "DataType7",
                    "Name": "Name3"
                  },
                  {
                    "Value": "Value2",
                    "Id": 216,
                    "DataType": "DataType8",
                    "Name": "Name4"
                  }
                ]
              },
              {
                "AppointmentGenderPreference": "None",
                "BirthDate": "2016-03-13T12:52:32.123Z",
                "Country": "Country0",
                "CreationDate": "2016-03-13T12:52:32.123Z",
                "CustomClientFields": [
                  {
                    "Value": "Value1",
                    "Id": 215,
                    "DataType": "DataType7",
                    "Name": "Name3"
                  }
                ]
              },
              {
                "AppointmentGenderPreference": "Female",
                "BirthDate": "2016-03-13T12:52:32.123Z",
                "Country": "Country1",
                "CreationDate": "2016-03-13T12:52:32.123Z",
                "CustomClientFields": [
                  {
                    "Value": "Value2",
                    "Id": 216,
                    "DataType": "DataType8",
                    "Name": "Name4"
                  },
                  {
                    "Value": "Value3",
                    "Id": 217,
                    "DataType": "DataType9",
                    "Name": "Name5"
                  }
                ]
              }
            ],
            "Location": {},
            "Resource": {
              "Id": 76,
              "Name": "Name6"
            }
          }
        ],
        "Clients": [
          {},
          {},
          {}
        ],
        "Course": {
          "Id": 78,
          "Name": "Name0",
          "Description": "Description4",
          "Notes": "Notes2",
          "StartDate": "2016-03-13T12:52:32.123Z"
        },
        "SemesterId": 142,
        "IsAvailable": false
      },
      "Client": {},
      "EnrollmentDateForward": "2016-03-13T12:52:32.123Z"
    }
  ]
}
```

