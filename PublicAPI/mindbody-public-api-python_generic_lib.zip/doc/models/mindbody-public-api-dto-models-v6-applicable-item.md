
# Mindbody Public Api Dto Models V6 Applicable Item

Item that will be applied to a promo code

## Structure

`MindbodyPublicApiDtoModelsV6ApplicableItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | `string` | Optional | Type of a promo code |
| `id` | `int` | Optional | ID of the item |
| `name` | `string` | Optional | Name of the item |

## Example (as JSON)

```json
{
  "Type": null,
  "Id": null,
  "Name": null
}
```

