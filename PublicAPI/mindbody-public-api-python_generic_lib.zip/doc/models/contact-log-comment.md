
# Contact Log Comment

A contact log comment.

## Structure

`ContactLogComment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The comment’s ID. |
| `text` | `string` | Optional | The comment’s body text. |
| `created_date_time` | `datetime` | Optional | The local time when the comment was created. |
| `created_by` | [`Staff`](../../doc/models/staff.md) | Optional | Information about the staff member who created the comment. |

## Example (as JSON)

```json
{
  "Id": null,
  "Text": null,
  "CreatedDateTime": null,
  "CreatedBy": null
}
```

