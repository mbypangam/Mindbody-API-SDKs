
# Mindbody Public Api Dto Models V6 Client Controller Add Arrival Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `arrival_added` | `bool` | Optional | When `true`, indicates that the arrival was added to the database. |
| `client_service` | [`MindbodyPublicApiDtoModelsV6ClientService`](../../doc/models/mindbody-public-api-dto-models-v6-client-service.md) | Optional | Contains information about the pricing option being used to pay for the client's current service session. |

## Example (as JSON)

```json
{
  "ArrivalAdded": null,
  "ClientService": null
}
```

