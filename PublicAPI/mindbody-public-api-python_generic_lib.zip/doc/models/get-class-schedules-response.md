
# Get Class Schedules Response

## Structure

`GetClassSchedulesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `class_schedules` | [`List of ClassSchedule`](../../doc/models/class-schedule.md) | Optional | Contains information about the class schedules. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClassSchedules": null
}
```

