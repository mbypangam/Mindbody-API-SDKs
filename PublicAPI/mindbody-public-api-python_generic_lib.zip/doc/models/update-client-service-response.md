
# Update Client Service Response

## Structure

`UpdateClientServiceResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_service` | [`MindbodyPublicApiDtoModelsV6ClientService`](../../doc/models/mindbody-public-api-dto-models-v6-client-service.md) | Optional | Contains information about the service to be updated. |

## Example (as JSON)

```json
{
  "ClientService": null
}
```

