
# Resource

## Structure

`Resource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `name` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

