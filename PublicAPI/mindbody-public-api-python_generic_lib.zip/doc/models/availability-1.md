
# Availability 1

The availability of a specific staff

## Structure

`Availability1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | Id of the availability |
| `staff` | [`Staff1`](../../doc/models/staff-1.md) | Optional | - |
| `session_type` | [`SessionType1`](../../doc/models/session-type-1.md) | Optional | - |
| `programs` | [`List of Program1`](../../doc/models/program-1.md) | Optional | Availabilities program list. |
| `start_date_time` | `datetime` | Optional | Availabilities start date and time. |
| `end_date_time` | `datetime` | Optional | Availabilities end date and time. |
| `bookable_end_date_time` | `datetime` | Optional | Availabilities bookable end date and time. |
| `location` | [`Location1`](../../doc/models/location-1.md) | Optional | - |
| `prep_time` | `int` | Optional | Appointment prep time |
| `finish_time` | `int` | Optional | Appointment finish time |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

