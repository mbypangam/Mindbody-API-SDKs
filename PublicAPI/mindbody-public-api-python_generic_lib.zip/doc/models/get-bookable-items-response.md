
# Get Bookable Items Response

## Structure

`GetBookableItemsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `availabilities` | [`List of Availability`](../../doc/models/availability.md) | Optional | Contains information about the availabilities for appointment booking. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Availabilities": [
    {
      "Id": 249,
      "Staff": {
        "Address": "Address3",
        "AppointmentInstructor": true,
        "AlwaysAllowDoubleBooking": true,
        "Bio": "Bio7",
        "City": "City3"
      },
      "SessionType": {
        "Type": "Resource",
        "DefaultTimeLength": 133,
        "StaffTimeLength": 155,
        "Id": 155,
        "Name": "Name3"
      },
      "Programs": [
        {
          "Id": 190,
          "Name": "Name2",
          "ScheduleType": "Resource",
          "CancelOffset": 180,
          "ContentFormats": [
            "ContentFormats3"
          ]
        },
        {
          "Id": 191,
          "Name": "Name3",
          "ScheduleType": "Media",
          "CancelOffset": 181,
          "ContentFormats": [
            "ContentFormats4",
            "ContentFormats5"
          ]
        }
      ],
      "StartDateTime": "2016-03-13T12:52:32.123Z"
    },
    {
      "Id": 250,
      "Staff": {
        "Address": "Address4",
        "AppointmentInstructor": false,
        "AlwaysAllowDoubleBooking": false,
        "Bio": "Bio8",
        "City": "City4"
      },
      "SessionType": {
        "Type": "Media",
        "DefaultTimeLength": 134,
        "StaffTimeLength": 156,
        "Id": 156,
        "Name": "Name4"
      },
      "Programs": [
        {
          "Id": 191,
          "Name": "Name3",
          "ScheduleType": "Media",
          "CancelOffset": 181,
          "ContentFormats": [
            "ContentFormats4",
            "ContentFormats5"
          ]
        },
        {
          "Id": 192,
          "Name": "Name4",
          "ScheduleType": "Arrival",
          "CancelOffset": 182,
          "ContentFormats": [
            "ContentFormats5",
            "ContentFormats6",
            "ContentFormats7"
          ]
        },
        {
          "Id": 193,
          "Name": "Name5",
          "ScheduleType": "All",
          "CancelOffset": 183,
          "ContentFormats": [
            "ContentFormats6"
          ]
        }
      ],
      "StartDateTime": "2016-03-13T12:52:32.123Z"
    }
  ]
}
```

