
# Status Enum

The status of this appointment.

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `ENUM_NONE` |
| `REQUESTED` |
| `BOOKED` |
| `COMPLETED` |
| `CONFIRMED` |
| `ARRIVED` |
| `NOSHOW` |
| `CANCELLED` |
| `LATECANCELLED` |

