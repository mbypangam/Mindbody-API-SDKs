
# Mindbody Public Api Dto Models V6 Level

A session level.

## Structure

`MindbodyPublicApiDtoModelsV6Level`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | Contains the Id given to this level. |
| `name` | `string` | Optional | Contains the name given to this level. |
| `description` | `string` | Optional | Contains a description of this level. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null
}
```

