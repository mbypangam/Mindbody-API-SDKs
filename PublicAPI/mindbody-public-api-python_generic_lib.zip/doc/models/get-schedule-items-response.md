
# Get Schedule Items Response

## Structure

`GetScheduleItemsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `staff_members` | [`List of Staff`](../../doc/models/staff.md) | Optional | Contains information about staff members with schedule items. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "StaffMembers": null
}
```

