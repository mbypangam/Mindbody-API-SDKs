
# Mindbody Public Api Dto Models V6 Sales Rep Response

This is the sales rep DTO

## Structure

`MindbodyPublicApiDtoModelsV6SalesRepResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `long\|int` | Optional | The unique Id of the sales rep |
| `first_name` | `string` | Optional | The firstname of the sales rep |
| `last_name` | `string` | Optional | The lastname of the sales rep |
| `sales_rep_numbers` | `List of int` | Optional | The sales rep Ids that are assigned to the rep |

## Example (as JSON)

```json
{
  "Id": null,
  "FirstName": null,
  "LastName": null,
  "SalesRepNumbers": null
}
```

