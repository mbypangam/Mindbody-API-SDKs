
# Remove Client From Class Response

## Structure

`RemoveClientFromClassResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mclass` | [`Class`](../../doc/models/class.md) | Optional | Represents a single class instance. The class meets at the start time, goes until the end time. |

## Example (as JSON)

```json
{
  "Class": {
    "ClassScheduleId": 206,
    "Visits": [
      {
        "AppointmentId": 199,
        "AppointmentGenderPreference": "None",
        "AppointmentStatus": "Confirmed",
        "ClassId": 137,
        "ClientId": "ClientId9"
      },
      {
        "AppointmentId": 198,
        "AppointmentGenderPreference": "Female",
        "AppointmentStatus": "Completed",
        "ClassId": 138,
        "ClientId": "ClientId8"
      }
    ],
    "Clients": [
      {
        "AppointmentGenderPreference": "None",
        "BirthDate": "2016-03-13T12:52:32.123Z",
        "Country": "Country9",
        "CreationDate": "2016-03-13T12:52:32.123Z",
        "CustomClientFields": [
          {
            "Value": "Value0",
            "Id": 214,
            "DataType": "DataType6",
            "Name": "Name2"
          }
        ]
      }
    ],
    "Location": {
      "AdditionalImageURLs": [
        "AdditionalImageURLs4",
        "AdditionalImageURLs3"
      ],
      "Address": "Address2",
      "Address2": "Address24",
      "Amenities": [
        {
          "Id": 146,
          "Name": "Name2"
        }
      ],
      "BusinessDescription": "BusinessDescription8"
    },
    "Resource": {
      "Id": 76,
      "Name": "Name6"
    }
  }
}
```

