
# Remove Client From Class Response

## Structure

`RemoveClientFromClassResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mclass` | [`Class`](../../doc/models/class.md) | Optional | Contains information about the class from which the client was removed. |

## Example (as JSON)

```json
{
  "Class": null
}
```

