
# Get Programs Response

## Structure

`GetProgramsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `programs` | [`List of Program`](../../doc/models/program.md) | Optional | Contains information about the programs. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Programs": null
}
```

