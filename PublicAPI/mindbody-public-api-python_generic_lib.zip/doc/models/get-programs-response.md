
# Get Programs Response

## Structure

`GetProgramsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `programs` | [`List[Program]`](../../doc/models/program.md) | Optional | Contains information about the programs. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Programs": [
    {
      "Id": 87,
      "Name": "Name7",
      "ScheduleType": "Class",
      "CancelOffset": 77,
      "ContentFormats": [
        "ContentFormats8",
        "ContentFormats9"
      ]
    },
    {
      "Id": 88,
      "Name": "Name8",
      "ScheduleType": "Enrollment",
      "CancelOffset": 78,
      "ContentFormats": [
        "ContentFormats9",
        "ContentFormats0",
        "ContentFormats1"
      ]
    },
    {
      "Id": 89,
      "Name": "Name9",
      "ScheduleType": "Appointment",
      "CancelOffset": 79,
      "ContentFormats": [
        "ContentFormats0"
      ]
    }
  ]
}
```

