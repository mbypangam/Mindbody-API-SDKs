
# Mindbody Public Api Dto Models V6 Staff Controller Get Staff Image URL Response

A response object returned from the GetStaffImgURL API.

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `image_url` | `string` | Optional | A staff member's image URL. |
| `mobile_image_url` | `string` | Optional | A staff member's mobile image URL. |

## Example (as JSON)

```json
{
  "ImageURL": null,
  "MobileImageURL": null
}
```

