
# Add Availabilities Response

## Structure

`AddAvailabilitiesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `staff_members` | [`List of Staff1`](../../doc/models/staff-1.md) | Optional | Contains information about the staff. |
| `errors` | [`List of ApiError1`](../../doc/models/api-error-1.md) | Optional | Contains information about the error. |

## Example (as JSON)

```json
{
  "StaffMembers": null,
  "Errors": null
}
```

