
# Add Availabilities Response

## Structure

`AddAvailabilitiesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `staff_members` | [`List of MindbodyPublicApiCommonModelsStaff`](../../doc/models/mindbody-public-api-common-models-staff.md) | Optional | Contains information about the staff. |
| `errors` | [`List of MindbodyPublicApiCommonModelsApiError`](../../doc/models/mindbody-public-api-common-models-api-error.md) | Optional | Contains information about the error. |

## Example (as JSON)

```json
{
  "StaffMembers": null,
  "Errors": null
}
```

