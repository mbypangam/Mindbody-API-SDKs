
# Update Appointment Response

## Structure

`UpdateAppointmentResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `appointment` | [`Appointment`](../../doc/models/appointment.md) | Optional | Contains information about the appointment. |

## Example (as JSON)

```json
{
  "Appointment": null
}
```

