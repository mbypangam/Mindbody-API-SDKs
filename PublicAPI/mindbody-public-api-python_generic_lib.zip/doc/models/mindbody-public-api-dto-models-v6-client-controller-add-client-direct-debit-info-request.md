
# Mindbody Public Api Dto Models V6 Client Controller Add Client Direct Debit Info Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `test` | `bool` | Optional | When `true`, indicates that test mode is enabled. The information is to be validated, but no data will be added or updated.<br>Default: **false** |
| `client_id` | `string` | Optional | The ID of the client being updated |
| `name_on_account` | `string` | Optional | The name on the bank account being added |
| `routing_number` | `string` | Optional | The routing number of the bank account being added |
| `account_number` | `string` | Optional | The bank account number |
| `account_type` | `string` | Optional | The account type.<br><br>Possible values:<br><br>* Checking<br>* Savings |

## Example (as JSON)

```json
{
  "Test": null,
  "ClientId": null,
  "NameOnAccount": null,
  "RoutingNumber": null,
  "AccountNumber": null,
  "AccountType": null
}
```

