
# Transaction Response

## Structure

`TransactionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transaction_id` | `int` | Optional | The Transaction ID. |
| `authentication_url` | `string` | Optional | The optional valid URL provided by the bank. |

## Example (as JSON)

```json
{
  "TransactionId": null,
  "AuthenticationUrl": null
}
```

