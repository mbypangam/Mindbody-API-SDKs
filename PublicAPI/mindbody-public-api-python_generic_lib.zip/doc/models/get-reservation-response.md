
# Get Reservation Response

Get reservation response

## Structure

`GetReservationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reservations` | [`List of Reservation`](../../doc/models/reservation.md) | Optional | - |
| `pagination` | [`Pagination`](../../doc/models/pagination.md) | Optional | - |
| `response_details` | [`ResponseDetails`](../../doc/models/response-details.md) | Optional | - |

## Example (as JSON)

```json
{
  "Reservations": null,
  "Pagination": null,
  "ResponseDetails": null
}
```

