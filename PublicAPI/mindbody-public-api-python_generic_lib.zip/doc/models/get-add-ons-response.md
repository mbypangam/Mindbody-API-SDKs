
# Get Add Ons Response

## Structure

`GetAddOnsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `add_ons` | [`List of MindbodyPublicApiDtoModelsV6AppointmentAddOn`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-add-on.md) | Optional | A list of available add-ons. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "AddOns": null
}
```

