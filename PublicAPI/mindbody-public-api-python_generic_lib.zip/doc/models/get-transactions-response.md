
# Get Transactions Response

Get Transactions Response Properties

## Structure

`GetTransactionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `transactions` | [`List of Transaction`](../../doc/models/transaction.md) | Optional | Contains the transaction objects, each of which describes the transaction details for a purchase event. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Transactions": null
}
```

