
# Get Packages Response

## Structure

`GetPackagesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `packages` | [`List of MindbodyPublicApiDtoModelsV6Package`](../../doc/models/mindbody-public-api-dto-models-v6-package.md) | Optional | Contains information about the resulting packages. |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |

## Example (as JSON)

```json
{
  "Packages": null,
  "PaginationResponse": null
}
```

