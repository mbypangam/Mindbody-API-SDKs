
# Get Payment Types Response

Get Payment Types Response Model

## Structure

`GetPaymentTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_types` | [`List[PaymentType]`](../../doc/models/payment-type.md) | Optional | The requested payment types. |

## Example (as JSON)

```json
{
  "PaymentTypes": [
    {
      "Id": 74,
      "PaymentTypeName": "PaymentTypeName6",
      "Active": false,
      "Fee": 137.1
    },
    {
      "Id": 75,
      "PaymentTypeName": "PaymentTypeName7",
      "Active": true,
      "Fee": 137.11
    },
    {
      "Id": 76,
      "PaymentTypeName": "PaymentTypeName8",
      "Active": false,
      "Fee": 137.12
    }
  ]
}
```

