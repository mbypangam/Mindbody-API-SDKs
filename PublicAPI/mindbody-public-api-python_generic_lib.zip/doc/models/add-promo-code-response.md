
# Add Promo Code Response

## Structure

`AddPromoCodeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promo_code` | [`PromoCode`](../../doc/models/promo-code.md) | Optional | Contains information about PromoCode |

## Example (as JSON)

```json
{
  "PromoCode": null
}
```

