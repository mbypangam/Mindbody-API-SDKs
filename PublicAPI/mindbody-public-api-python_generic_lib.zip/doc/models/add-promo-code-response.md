
# Add Promo Code Response

## Structure

`AddPromoCodeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `promo_code` | [`MindbodyPublicApiDtoModelsV6PromoCode`](../../doc/models/mindbody-public-api-dto-models-v6-promo-code.md) | Optional | Contains information about PromoCode |

## Example (as JSON)

```json
{
  "PromoCode": null
}
```

