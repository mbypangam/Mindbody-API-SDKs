
# Get Services Response

## Structure

`GetServicesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `services` | [`List of MindbodyPublicApiDtoModelsV6Service`](../../doc/models/mindbody-public-api-dto-models-v6-service.md) | Optional | Contains information about the services. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Services": null
}
```

