
# Get Locations Response

## Structure

`GetLocationsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `locations` | [`List of Location`](../../doc/models/location.md) | Optional | Contains information about the locations. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Locations": [
    {
      "AdditionalImageURLs": [
        "AdditionalImageURLs2"
      ],
      "Address": "Address2",
      "Address2": "Address24",
      "Amenities": [
        {
          "Id": 230,
          "Name": "Name2"
        },
        {
          "Id": 229,
          "Name": "Name3"
        },
        {
          "Id": 228,
          "Name": "Name4"
        }
      ],
      "BusinessDescription": "BusinessDescription8"
    }
  ]
}
```

