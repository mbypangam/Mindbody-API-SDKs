
# Applicable Item

Item that will be applied to a promo code

## Structure

`ApplicableItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | `string` | Optional | Type of a promo code<br>The promotional item type.<br>Possible values are:<br><br>* ServiceCategory<br>* RevenueCategory<br>* Supplier<br>* Item |
| `id` | `int` | Optional | The promotional item ID. |
| `name` | `string` | Optional | The promotional item name. |

## Example (as JSON)

```json
{
  "Type": null,
  "Id": null,
  "Name": null
}
```

