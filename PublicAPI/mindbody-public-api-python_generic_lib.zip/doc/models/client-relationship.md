
# Client Relationship

A relation between two clients.

## Structure

`ClientRelationship`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `related_client_id` | `string` | Optional | The RSSID of the related client. |
| `relationship` | [`Relationship`](../../doc/models/relationship.md) | Optional | Contains details about the relationship between two clients. |
| `relationship_name` | `string` | Optional | The name of the relationship of the related client. |
| `delete` | `bool` | Optional | When true, the associated relationship is removed from the client’s list of relationships.<br><br>This property is ignored in all other use cases.<br>Default: *false* |

## Example (as JSON)

```json
{
  "RelatedClientId": null,
  "Relationship": null,
  "RelationshipName": null,
  "Delete": null
}
```

