
# Mindbody Public Api Dto Models V6 Client Controller Terminate Contract Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contract` | [`MindbodyPublicApiDtoModelsV6ClientContract`](../../doc/models/mindbody-public-api-dto-models-v6-client-contract.md) | Optional | Contains confirmation message for the successful contract termination. |

## Example (as JSON)

```json
{
  "Contract": null
}
```

