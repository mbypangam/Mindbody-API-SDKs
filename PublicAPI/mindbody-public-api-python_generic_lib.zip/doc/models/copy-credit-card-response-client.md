
# Copy Credit Card Response Client

## Structure

`CopyCreditCardResponseClient`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `str` | Optional | ClientId |
| `site_id` | `int` | Optional | SiteId |
| `first_name` | `str` | Optional | First name of ClientId |
| `last_name` | `str` | Optional | Last name of ClientId |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "SiteId": 164,
  "FirstName": "FirstName4",
  "LastName": "LastName4"
}
```

