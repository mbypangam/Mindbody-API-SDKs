
# Schedule Type Enum

## Enumeration

`ScheduleTypeEnum`

## Fields

| Name |
|  --- |
| `ALL` |
| `CLASS` |
| `ENROLLMENT` |
| `APPOINTMENT` |
| `RESOURCE` |
| `MEDIA` |
| `ARRIVAL` |

