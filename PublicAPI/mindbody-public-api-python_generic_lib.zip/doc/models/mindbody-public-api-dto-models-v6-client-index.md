
# Mindbody Public Api Dto Models V6 Client Index

A client index.

## Structure

`MindbodyPublicApiDtoModelsV6ClientIndex`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The unique ID of the client index. |
| `name` | `string` | Optional | The name of the client index. |
| `required_business_mode` | `bool` | Optional | When `true`, indicates that the index is required when creating profiles in business mode. |
| `required_consumer_mode` | `bool` | Optional | When `true`, indicates that the index is required when creating profiles in consumer mode. |
| `values` | [`List of MindbodyPublicApiDtoModelsV6ClientIndexValue`](../../doc/models/mindbody-public-api-dto-models-v6-client-index-value.md) | Optional | Contains a list with a single object representing the index value assigned to the client index. |
| `action` | [`Action7Enum`](../../doc/models/action-7-enum.md) | Optional | The action performed on this object. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "RequiredBusinessMode": null,
  "RequiredConsumerMode": null,
  "Values": null,
  "Action": null
}
```

