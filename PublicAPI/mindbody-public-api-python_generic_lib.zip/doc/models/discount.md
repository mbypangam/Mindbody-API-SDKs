
# Discount

Discount for a promo code

## Structure

`Discount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | `str` | Optional | Type of discount percentage/amount |
| `amount` | `float` | Optional | Amount of discount |

## Example (as JSON)

```json
{
  "Type": "Type0",
  "Amount": 57.88
}
```

