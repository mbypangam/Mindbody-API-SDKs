
# Discount

Discount for a promo code

## Structure

`Discount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | `string` | Optional | Type of discount percentage/amount |
| `amount` | `float` | Optional | Amount of discount |

## Example (as JSON)

```json
{
  "Type": null,
  "Amount": null
}
```

