
# M0 Culture Neutral Public Key Token B77 a 5 C 561934 E 089

## Structure

`M0CultureNeutralPublicKeyTokenB77a5c561934e089`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `str` | Optional | - |
| `value` | `List[str]` | Optional | - |

## Example (as JSON)

```json
{
  "key": "key0",
  "value": [
    "value8",
    "value9"
  ]
}
```

