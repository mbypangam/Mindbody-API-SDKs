
# Mindbody Public Api Dto Models V6 Client Purchase Record

A record of a specific client purchase

## Structure

`MindbodyPublicApiDtoModelsV6ClientPurchaseRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `sale` | [`MindbodyPublicApiDtoModelsV6Sale`](../../doc/models/mindbody-public-api-dto-models-v6-sale.md) | Optional | - |
| `description` | `string` | Optional | The item name and description. |
| `account_payment` | `bool` | Optional | If `true`, the item was a payment credited to an account. |
| `price` | `float` | Optional | The item's price before taxes and discounts. |
| `amount_paid` | `float` | Optional | The amount paid for the item. |
| `discount` | `float` | Optional | The discount amount that was applied to the item. |
| `tax` | `float` | Optional | The amount of tax that was applied to the item. |
| `returned` | `bool` | Optional | The return status of the item. If `true`, this item was returned. |
| `quantity` | `int` | Optional | The quantity of the item purchased. |

## Example (as JSON)

```json
{
  "Sale": null,
  "Description": null,
  "AccountPayment": null,
  "Price": null,
  "AmountPaid": null,
  "Discount": null,
  "Tax": null,
  "Returned": null,
  "Quantity": null
}
```

