
# Mindbody Public Api Dto Models V6 Sale Controller Get Transactions Response

Transactions Response Properties

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. |
| `transactions` | [`List of MindbodyPublicApiDtoModelsV6Transaction`](../../doc/models/mindbody-public-api-dto-models-v6-transaction.md) | Optional | Contains the transaction objects, each of which describes the transaction details for a purchase event. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Transactions": null
}
```

