
# Mindbody Public Api Dto Models V6 Appointment Option

An appointment option name/value pair

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `display_name` | `string` | Optional | The name displayed for this appointment option. |
| `name` | `string` | Optional | The name given to this option. |
| `value` | `string` | Optional | The value of the option. |
| `mtype` | `string` | Optional | The data type of the option value. |

## Example (as JSON)

```json
{
  "DisplayName": null,
  "Name": null,
  "Value": null,
  "Type": null
}
```

