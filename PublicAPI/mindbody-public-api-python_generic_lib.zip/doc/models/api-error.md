
# Api Error

## Structure

`ApiError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `str` | Optional | - |
| `code` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "Message": "Message6",
  "Code": "Code0"
}
```

