
# Mindbody Public Api Dto Models V6 Availability

A staff availability entry

## Structure

`MindbodyPublicApiDtoModelsV6Availability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The ID of the availability. |
| `staff` | [`MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Contains information about staff members. |
| `session_type` | [`MindbodyPublicApiDtoModelsV6SessionType`](../../doc/models/mindbody-public-api-dto-models-v6-session-type.md) | Optional | Contains information about the types of sessions. |
| `programs` | [`List of MindbodyPublicApiDtoModelsV6Program`](../../doc/models/mindbody-public-api-dto-models-v6-program.md) | Optional | Contains information about the programs. |
| `start_date_time` | `datetime` | Optional | The date and time the availability starts. |
| `end_date_time` | `datetime` | Optional | The date and time the availability ends. |
| `bookable_end_date_time` | `datetime` | Optional | The time of day that the last appointment can start. |
| `location` | [`MindbodyPublicApiDtoModelsV6Location`](../../doc/models/mindbody-public-api-dto-models-v6-location.md) | Optional | Contains information about the location. |
| `prep_time` | `int` | Optional | Prep time in minutes |
| `finish_time` | `int` | Optional | Finish time in minutes |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

