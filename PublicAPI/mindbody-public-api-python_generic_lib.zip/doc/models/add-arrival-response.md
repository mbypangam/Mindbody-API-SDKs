
# Add Arrival Response

## Structure

`AddArrivalResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `arrival_added` | `bool` | Optional | When `true`, indicates that the arrival was added to the database. |
| `client_service` | [`ClientService`](../../doc/models/client-service.md) | Optional | Contains information about the pricing option being used to pay for the client’s current service session. |

## Example (as JSON)

```json
{
  "ArrivalAdded": null,
  "ClientService": null
}
```

