
# Pagination

## Structure

`Pagination`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page_number` | `int` | Optional | - |
| `page_size` | `int` | Optional | - |
| `total_result_count` | `int` | Optional | - |
| `total_page_count` | `int` | Optional | - |

## Example (as JSON)

```json
{
  "PageNumber": null,
  "PageSize": null,
  "TotalResultCount": null,
  "TotalPageCount": null
}
```

