
# Mindbody Public Api Dto Models V6 Client Controller Get Client Rewards Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `balance` | `long\|int` | Optional | The total rewards points available to the indicated client after the above transaction. |
| `transactions` | [`List of MindbodyPublicApiDtoModelsV6ClientRewardTransaction`](../../doc/models/mindbody-public-api-dto-models-v6-client-reward-transaction.md) | Optional | Contains information about the reward transaction details. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Balance": null,
  "Transactions": null
}
```

