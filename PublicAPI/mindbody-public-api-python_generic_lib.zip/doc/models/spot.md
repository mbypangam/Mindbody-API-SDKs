
# Spot

## Structure

`Spot`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reserved_spot_numbers` | `List of int` | Optional | - |
| `available_spot_numbers` | `List of int` | Optional | - |
| `unavailable_spot_numbers` | `List of int` | Optional | - |

## Example (as JSON)

```json
{
  "ReservedSpotNumbers": null,
  "AvailableSpotNumbers": null,
  "UnavailableSpotNumbers": null
}
```

