
# Cart Item

## Structure

`CartItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | `object` | Optional | - |
| `discount_amount` | `float` | Optional | The amount of the discount applied to the item. |
| `visit_ids` | `List of long\|int` | Optional | The IDs of the booked classes, enrollments, or courses that were reconciled by this cart item. This list is only returned if a valid visit ID was passed in the request’s `VisitIds` list. |
| `appointment_ids` | `List of long\|int` | Optional | Gets or sets the item. |
| `appointments` | [`List of Appointment`](../../doc/models/appointment.md) | Optional | The IDs of the appointments that were reconciled by this cart item. This list is only returned if a valid appointment ID was passed in the request’s `AppointmentIds` list. |
| `id` | `int` | Optional | The item’s ID in the current cart. |
| `quantity` | `int` | Optional | The quantity of the item being purchased. |

## Example (as JSON)

```json
{
  "Item": null,
  "DiscountAmount": null,
  "VisitIds": null,
  "AppointmentIds": null,
  "Appointments": null,
  "Id": null,
  "Quantity": null
}
```

