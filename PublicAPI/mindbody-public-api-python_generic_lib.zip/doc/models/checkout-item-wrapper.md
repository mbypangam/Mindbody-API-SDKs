
# Checkout Item Wrapper

## Structure

`CheckoutItemWrapper`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | [`CheckoutItem`](../../doc/models/checkout-item.md) | Optional | Information about an item in the cart. |
| `discount_amount` | `float` | Optional | The amount the item is discounted. This parameter is ignored for packages. |
| `appointment_booking_requests` | [`List of CheckoutAppointmentBookingRequest`](../../doc/models/checkout-appointment-booking-request.md) | Optional | A list of appointments to be booked then paid for by this item. This parameter applies only to pricing option items. |
| `enrollment_ids` | `List of int` | Optional | A list of enrollment IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `class_ids` | `List of int` | Optional | A list of class IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `course_ids` | `List of long\|int` | Optional | A list of course IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `visit_ids` | `List of long\|int` | Optional | A list of visit IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `appointment_ids` | `List of long\|int` | Optional | A list of appointment IDs that this item is to reconcile. |
| `id` | `int` | Optional | The item’s unique ID within the cart. |
| `quantity` | `int` | Optional | The number of this item to be purchased. |

## Example (as JSON)

```json
{
  "Item": null,
  "DiscountAmount": null,
  "AppointmentBookingRequests": null,
  "EnrollmentIds": null,
  "ClassIds": null,
  "CourseIds": null,
  "VisitIds": null,
  "AppointmentIds": null,
  "Id": null,
  "Quantity": null
}
```

