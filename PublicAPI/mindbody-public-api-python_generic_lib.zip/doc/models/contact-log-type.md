
# Contact Log Type

A contact log type.

## Structure

`ContactLogType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The Id of the contactlog Type. |
| `name` | `string` | Optional | The name of the contactlog Type. |
| `sub_types` | [`List of ContactLogSubType`](../../doc/models/contact-log-sub-type.md) | Optional | Contains the SubType objects, each of which describes the subtypes for a contactlog Type. |

## Example (as JSON)

```json
{
  "Id": 146,
  "Name": "Name0",
  "SubTypes": [
    {
      "Id": 252,
      "Name": "Name2"
    }
  ]
}
```

