
# Mindbody Public Api Dto Models V6 Promo Code

## Structure

`MindbodyPublicApiDtoModelsV6PromoCode`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Optional | Name of the promo code |
| `code` | `string` | Optional | The code of the promocode. |
| `active` | `bool` | Optional | Indicates that promocode is active. |
| `discount` | [`MindbodyPublicApiDtoModelsV6Discount`](../../doc/models/mindbody-public-api-dto-models-v6-discount.md) | Optional | Contains information about the discount. |
| `activation_date` | `datetime` | Optional | The promocode activation date. |
| `expiration_date` | `datetime` | Optional | The promocode expiration date. |
| `max_uses` | `int` | Optional | The maximun number of uses. |
| `number_of_autopays` | `int` | Optional | Number of Autopays |
| `days_after_close_date` | `int` | Optional | The number of days a client has to use a promocode after they are no longer a prospect. |
| `allow_online` | `bool` | Optional | Indicates if promocode to be redeemed online in consumer mode. |
| `days_valid` | [`List of DaysValidEnum`](../../doc/models/days-valid-enum.md) | Optional | Indicates what days of the week promocode can be redeemed. |
| `applicable_items` | [`List of MindbodyPublicApiDtoModelsV6ApplicableItem`](../../doc/models/mindbody-public-api-dto-models-v6-applicable-item.md) | Optional | Contains information about a promocode applicable items. |

## Example (as JSON)

```json
{
  "Name": null,
  "Code": null,
  "Active": null,
  "Discount": null,
  "ActivationDate": null,
  "ExpirationDate": null,
  "MaxUses": null,
  "NumberOfAutopays": null,
  "DaysAfterCloseDate": null,
  "AllowOnline": null,
  "DaysValid": null,
  "ApplicableItems": null
}
```

