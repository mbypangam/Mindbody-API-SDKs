
# Get Custom Client Fields Response

## Structure

`GetCustomClientFieldsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `custom_client_fields` | [`List of CustomClientField`](../../doc/models/custom-client-field.md) | Optional | Contains information about the available custom client fields. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "CustomClientFields": null
}
```

