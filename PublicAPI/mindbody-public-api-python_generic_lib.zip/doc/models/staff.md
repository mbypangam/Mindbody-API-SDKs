
# Staff

The Staff

## Structure

`Staff`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address` | `string` | Optional | The address of the staff member who is teaching the class. |
| `appointment_instructor` | `bool` | Optional | When `true`, indicates that the staff member offers appointments.<br /><br>When `false`, indicates that the staff member does not offer appointments. |
| `always_allow_double_booking` | `bool` | Optional | When `true`, indicates that the staff member can be scheduled for overlapping services.<br /><br>When `false`, indicates that the staff can only be scheduled for one service at a time in any given time-frame. |
| `bio` | `string` | Optional | The staff member’s biography. This string contains HTML. |
| `city` | `string` | Optional | The staff member’s city. |
| `country` | `string` | Optional | The staff member’s country. |
| `email` | `string` | Optional | The staff member’s email address. |
| `first_name` | `string` | Optional | The staff member’s first name. |
| `display_name` | `string` | Optional | The staff member’s Nickname. |
| `home_phone` | `string` | Optional | The staff member’s home phone number. |
| `id` | `long\|int` | Optional | The ID assigned to the staff member. |
| `independent_contractor` | `bool` | Optional | When `true`, indicates that the staff member is an independent contractor.<br>When `false`, indicates that the staff member is not an independent contractor. |
| `is_male` | `bool` | Optional | When `true`, indicates that the staff member is male.<br>When `false`, indicates that the staff member is female. |
| `last_name` | `string` | Optional | The staff member’s last name. |
| `mobile_phone` | `string` | Optional | The staff member’s mobile phone number. |
| `name` | `string` | Optional | The staff member’s name. |
| `postal_code` | `string` | Optional | The staff member’s postal code. |
| `class_teacher` | `bool` | Optional | When `true`, indicates that the staff member can teach classes.<br>When `false`, indicates that the staff member cannot teach classes. |
| `sort_order` | `int` | Optional | If configured by the business owner, this field determines a staff member’s weight when sorting. Use this field to sort staff members on your interface. |
| `state` | `string` | Optional | The staff member’s state. |
| `work_phone` | `string` | Optional | The staff member’s work phone number. |
| `image_url` | `string` | Optional | The URL of the staff member’s image, if one has been uploaded. |
| `class_assistant` | `bool` | Optional | Is the staff an assistant |
| `class_assistant_2` | `bool` | Optional | Is the staff an assistant2 |
| `employment_start` | `datetime` | Optional | The start date of employment |
| `employment_end` | `datetime` | Optional | The end date of employment |
| `provider_i_ds` | `List of string` | Optional | A list of ProviderIds for the staff. |
| `rep` | `bool` | Optional | return true if staff is sales Rep 1 else false. |
| `rep_2` | `bool` | Optional | return true if staff is sales Rep 2 else false. |
| `rep_3` | `bool` | Optional | return true if staff is sales Rep 3 else false. |
| `rep_4` | `bool` | Optional | return true if staff is sales Rep 4 else false. |
| `rep_5` | `bool` | Optional | return true if staff is sales Rep 5 else false. |
| `rep_6` | `bool` | Optional | return true if staff is sales Rep 6 else false. |
| `staff_settings` | [`StaffSetting`](../../doc/models/staff-setting.md) | Optional | contains the information about the staff settings. |
| `appointments` | [`List of Appointment`](../../doc/models/appointment.md) | Optional | A list of appointments for the staff. |
| `unavailabilities` | [`List of Unavailability`](../../doc/models/unavailability.md) | Optional | A list of unavailabilities for the staff. |
| `availabilities` | [`List of Availability`](../../doc/models/availability.md) | Optional | A list of availabilities for the staff. |
| `emp_id` | `string` | Optional | The EmpID assigned to the staff member. |

## Example (as JSON)

```json
{
  "Address": null,
  "AppointmentInstructor": null,
  "AlwaysAllowDoubleBooking": null,
  "Bio": null,
  "City": null,
  "Country": null,
  "Email": null,
  "FirstName": null,
  "DisplayName": null,
  "HomePhone": null,
  "Id": null,
  "IndependentContractor": null,
  "IsMale": null,
  "LastName": null,
  "MobilePhone": null,
  "Name": null,
  "PostalCode": null,
  "ClassTeacher": null,
  "SortOrder": null,
  "State": null,
  "WorkPhone": null,
  "ImageUrl": null,
  "ClassAssistant": null,
  "ClassAssistant2": null,
  "EmploymentStart": null,
  "EmploymentEnd": null,
  "ProviderIDs": null,
  "Rep": null,
  "Rep2": null,
  "Rep3": null,
  "Rep4": null,
  "Rep5": null,
  "Rep6": null,
  "StaffSettings": null,
  "Appointments": null,
  "Unavailabilities": null,
  "Availabilities": null,
  "EmpID": null
}
```

