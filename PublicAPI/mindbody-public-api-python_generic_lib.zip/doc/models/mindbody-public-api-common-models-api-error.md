
# Mindbody Public Api Common Models Api Error

## Structure

`MindbodyPublicApiCommonModelsApiError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `string` | Optional | - |
| `code` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Message": null,
  "Code": null
}
```

