
# Action 6 Enum

The action performed on this object.

## Enumeration

`Action6Enum`

## Fields

| Name |
|  --- |
| `ENUM_NONE` |
| `ADDED` |
| `UPDATED` |
| `FAILED` |
| `REMOVED` |

