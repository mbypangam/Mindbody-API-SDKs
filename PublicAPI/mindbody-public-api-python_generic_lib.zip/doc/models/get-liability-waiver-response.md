
# Get Liability Waiver Response

## Structure

`GetLiabilityWaiverResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `liability_waiver` | `str` | Optional | Contains Liability Waiver text for a site |

## Example (as JSON)

```json
{
  "LiabilityWaiver": "LiabilityWaiver0"
}
```

