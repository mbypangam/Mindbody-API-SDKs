
# Get Enrollments Response

## Structure

`GetEnrollmentsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `enrollments` | [`List of ClassSchedule`](../../doc/models/class-schedule.md) | Optional | Contains information about the enrollments. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Enrollments": null
}
```

