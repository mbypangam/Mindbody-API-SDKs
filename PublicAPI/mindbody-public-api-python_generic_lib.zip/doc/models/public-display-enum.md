
# Public Display Enum

Choice that decides whether the availablity should be publicly visible, masked or hidden.

## Enumeration

`PublicDisplayEnum`

## Fields

| Name |
|  --- |
| `HIDE` |
| `SHOW` |
| `MASK` |

