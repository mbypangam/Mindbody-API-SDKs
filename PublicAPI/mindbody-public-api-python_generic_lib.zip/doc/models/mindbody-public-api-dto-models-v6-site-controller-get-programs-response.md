
# Mindbody Public Api Dto Models V6 Site Controller Get Programs Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetProgramsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `programs` | [`List of MindbodyPublicApiDtoModelsV6Program`](../../doc/models/mindbody-public-api-dto-models-v6-program.md) | Optional | Contains information about the programs. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Programs": null
}
```

