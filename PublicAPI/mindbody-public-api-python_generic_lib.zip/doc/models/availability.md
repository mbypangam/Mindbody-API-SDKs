
# Availability

A staff availability entry

## Structure

`Availability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The ID of the availability. |
| `staff` | [`Staff`](../../doc/models/staff.md) | Optional | Contains information about staff members. |
| `resources` | [`List of Resource`](../../doc/models/resource.md) | Optional | Available resources |
| `session_type` | [`SessionType`](../../doc/models/session-type.md) | Optional | Contains information about the types of sessions. |
| `programs` | [`List of Program`](../../doc/models/program.md) | Optional | Contains information about the programs. |
| `start_date_time` | `datetime` | Optional | The date and time the availability starts. |
| `end_date_time` | `datetime` | Optional | The date and time the availability ends. |
| `bookable_end_date_time` | `datetime` | Optional | The time of day that the last appointment can start. |
| `location` | [`Location`](../../doc/models/location.md) | Optional | Contains information about the location. |
| `prep_time` | `int` | Optional | Prep time in minutes |
| `finish_time` | `int` | Optional | Finish time in minutes |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "Resources": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

