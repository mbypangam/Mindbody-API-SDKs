
# Get Class Visits Response

## Structure

`GetClassVisitsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mclass` | [`Class`](../../doc/models/class.md) | Optional | Represents a single class instance. The class meets at the start time, goes until the end time. |

## Example (as JSON)

```json
{
  "Class": null
}
```

