
# Mindbody Public Api Dto Models V6 Appointment Controller Add Appointment Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `apply_payment` | `bool` | Optional | When `true`, indicates that a payment should be applied to the appointment.<br><br />Default: **true** |
| `client_id` | `string` | Required | The RRSID of the client for whom the new appointment is being made. |
| `duration` | `int` | Optional | The duration of the appointment. This parameter is used to change the default duration of an appointment. |
| `execute` | `string` | Optional | The action taken to add this appointment. |
| `end_date_time` | `datetime` | Optional | The end date and time of the new appointment. <br /><br>Default: **StartDateTime**, offset by the staff member's default appointment duration. |
| `gender_preference` | `string` | Optional | The client's service provider gender preference. |
| `location_id` | `int` | Required | The ID of the location where the new appointment is to take place. |
| `notes` | `string` | Optional | Any general notes about this appointment. |
| `provider_id` | `string` | Optional | If a user has Complementary and Alternative Medicine features enabled, this parameter assigns a provider ID to the appointment. |
| `resource_ids` | `List of int` | Optional | A list of resource IDs to associate with the new appointment. |
| `send_email` | `bool` | Optional | Whether to send client an email for cancellations. An email is sent only if the client has an email address and automatic emails have been set up.<br><br />Default: **false** |
| `session_type_id` | `int` | Required | The session type associated with the new appointment. |
| `staff_id` | `long\|int` | Required | The ID of the staff member who is adding the new appointment. |
| `staff_requested` | `bool` | Optional | When `true`, indicates that the staff member was requested specifically by the client. |
| `start_date_time` | `datetime` | Required | The start date and time of the new appointment. |
| `test` | `bool` | Optional | When true, indicates that the method is to be validated, but no new appointment data is added.<br><br />Default: **false** |
| `is_waitlist` | `bool` | Optional | When `true`, indicates that the client should be added to a specific appointment waiting list.<br>When `false`, the client should not be added to the waiting list.<br>Default: **false** |
| `partner_external_id` | `string` | Optional | Optional external key for api partners. |

## Example (as JSON)

```json
{
  "ApplyPayment": null,
  "ClientId": "ClientId6",
  "Duration": null,
  "Execute": null,
  "EndDateTime": null,
  "GenderPreference": null,
  "LocationId": 50,
  "Notes": null,
  "ProviderId": null,
  "ResourceIds": null,
  "SendEmail": null,
  "SessionTypeId": 50,
  "StaffId": 156,
  "StaffRequested": null,
  "StartDateTime": "2016-03-13T12:52:32.123Z",
  "Test": null,
  "IsWaitlist": null,
  "PartnerExternalId": null
}
```

