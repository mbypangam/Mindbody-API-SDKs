
# Package

## Structure

`Package`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The ID of the package. |
| `name` | `str` | Optional | The name of the package. |
| `discount_percentage` | `float` | Optional | The discount percentage applied to the package. |
| `sell_online` | `bool` | Optional | When `true`, only products that can be sold online are returned.<br /><br>When `false`, all products are returned. |
| `services` | [`List[Service]`](../../doc/models/service.md) | Optional | Information about the services in the packages. |
| `products` | [`List[Product]`](../../doc/models/product.md) | Optional | Information about the products in the packages. |

## Example (as JSON)

```json
{
  "Id": 146,
  "Name": "Name0",
  "DiscountPercentage": 242.62,
  "SellOnline": false,
  "Services": [
    {
      "Price": 77.35,
      "OnlinePrice": 111.87,
      "TaxIncluded": 184.89,
      "ProgramId": 101,
      "TaxRate": 45.39
    }
  ]
}
```

