
# Get Staff Session Types Response

## Structure

`GetStaffSessionTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `staff_session_types` | [`List of StaffSessionType`](../../doc/models/staff-session-type.md) | Optional | Contains information about staff member session types. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "StaffSessionTypes": null
}
```

