
# Get Memberships Response

## Structure

`GetMembershipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `memberships` | [`List of MindbodyPublicApiDtoModelsV6Membership`](../../doc/models/mindbody-public-api-dto-models-v6-membership.md) | Optional | Details about the memberships. |

## Example (as JSON)

```json
{
  "Memberships": null
}
```

