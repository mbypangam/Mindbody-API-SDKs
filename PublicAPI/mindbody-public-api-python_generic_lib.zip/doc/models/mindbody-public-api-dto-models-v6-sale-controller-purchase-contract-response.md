
# Mindbody Public Api Dto Models V6 Sale Controller Purchase Contract Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `string` | Optional | The ID of the client who is purchasing the contract. |
| `location_id` | `int` | Optional | The ID of the location where the contract is being purchased. |
| `contract_id` | `int` | Optional | The ID of the general contract being purchased. |
| `client_contract_id` | `int` | Optional | The ID of the specific contract being purchased by this specific client, not to be confused with the `ContractId`, which refers to a general contract that the business offers. |
| `payment_processing_failures` | [`List of MindbodyPublicApiDtoModelsV6SaleControllerPaymentProcessingFailure`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-payment-processing-failure.md) | Optional | Any cart processing failures, for example when SCA challenged, the cart is in PaymentAuthenticationRequired state and at least one of the failures listed will provide an authentication Url. |

## Example (as JSON)

```json
{
  "ClientId": null,
  "LocationId": null,
  "ContractId": null,
  "ClientContractId": null,
  "PaymentProcessingFailures": null
}
```

