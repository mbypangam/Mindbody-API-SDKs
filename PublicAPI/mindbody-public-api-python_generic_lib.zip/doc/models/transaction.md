
# Transaction

## Structure

`Transaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transaction_id` | `int` | Optional | The transaction ID. |
| `sale_id` | `long\|int` | Optional | The sale ID. |
| `client_id` | `long\|int` | Optional | The ID of the client who made the purchase. |
| `amount` | `float` | Optional | The amount charged on the card |
| `settled` | `bool` | Optional | Whether it is settled or not |
| `status` | `string` | Optional | Status of the transaction |
| `transaction_time` | `datetime` | Optional | Time of card swiped |
| `auth_time` | `datetime` | Optional | Time of card authorized |
| `location_id` | `int` | Optional | The ID of the location where the sale takes place. |
| `merchant_id` | `string` | Optional | Merchant ID of the studio |
| `terminal_id` | `string` | Optional | Terminal ID used for payment. Not applicable for CNP/Bank |
| `card_expiration_month` | `string` | Optional | Expiry month of the card |
| `card_expiration_year` | `string` | Optional | Expiry year of the card |
| `cc_last_four` | `string` | Optional | Last 4 digits of CC |
| `card_type` | `string` | Optional | Type of the card |
| `cc_swiped` | `bool` | Optional | Whether card is swiped or not |
| `ach_last_four` | `string` | Optional | Customer’s ACH last 4 digits |

## Example (as JSON)

```json
{
  "TransactionId": 132,
  "SaleId": 62,
  "ClientId": 190,
  "Amount": 57.88,
  "Settled": false
}
```

