
# Waitlist Entry

## Structure

`WaitlistEntry`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `class_date` | `datetime` | Optional | The date of the class or enrollment. |
| `class_id` | `long\|int` | Optional | The ID of the class or enrollment. |
| `class_schedule` | [`ClassSchedule`](../../doc/models/class-schedule.md) | Optional | Represents a single class instance. The class meets at the start time, goes until the end time. |
| `client` | [`Client`](../../doc/models/client.md) | Optional | The Client. |
| `enrollment_date_forward` | `datetime` | Optional | If the waiting list entry was created for an enrollment, this is the date on or after which the client can be added to the enrollment from the waitlist. |
| `id` | `int` | Optional | The ID of the waiting list entry. |
| `request_date_time` | `datetime` | Optional | The date and time that the request to be on the waiting list was made. |
| `visit_ref_no` | `int` | Optional | The ID of the visit that is associated with the waiting list entry. |
| `web` | `bool` | Optional | If `true`, the entry on the waiting list was requested online.<br /><br>If `false`, the entry on the waiting list was requested off-line, for example in person or by phone. |

## Example (as JSON)

```json
{
  "ClassDate": "2016-03-13T12:52:32.123Z",
  "ClassId": 58,
  "ClassSchedule": {
    "Classes": [
      {
        "ClassScheduleId": 195,
        "Visits": [
          {
            "AppointmentId": 128,
            "AppointmentGenderPreference": "Male",
            "AppointmentStatus": "LateCancelled",
            "ClassId": 208,
            "ClientId": "ClientId2"
          }
        ],
        "Clients": [
          {
            "AppointmentGenderPreference": "Male",
            "BirthDate": "2016-03-13T12:52:32.123Z",
            "Country": "Country4",
            "CreationDate": "2016-03-13T12:52:32.123Z",
            "CustomClientFields": [
              {
                "Value": "Value5",
                "Id": 203,
                "DataType": "DataType1",
                "Name": "Name7"
              },
              {
                "Value": "Value6",
                "Id": 204,
                "DataType": "DataType2",
                "Name": "Name8"
              },
              {
                "Value": "Value7",
                "Id": 205,
                "DataType": "DataType3",
                "Name": "Name9"
              }
            ]
          },
          {
            "AppointmentGenderPreference": "None",
            "BirthDate": "2016-03-13T12:52:32.123Z",
            "Country": "Country5",
            "CreationDate": "2016-03-13T12:52:32.123Z",
            "CustomClientFields": [
              {
                "Value": "Value6",
                "Id": 204,
                "DataType": "DataType2",
                "Name": "Name8"
              }
            ]
          },
          {
            "AppointmentGenderPreference": "Female",
            "BirthDate": "2016-03-13T12:52:32.123Z",
            "Country": "Country6",
            "CreationDate": "2016-03-13T12:52:32.123Z",
            "CustomClientFields": [
              {
                "Value": "Value7",
                "Id": 205,
                "DataType": "DataType3",
                "Name": "Name9"
              },
              {
                "Value": "Value8",
                "Id": 206,
                "DataType": "DataType4",
                "Name": "Name0"
              }
            ]
          }
        ],
        "Location": {},
        "Resource": {
          "Id": 87,
          "Name": "Name1"
        }
      },
      {
        "ClassScheduleId": 194,
        "Visits": [
          {
            "AppointmentId": 129,
            "AppointmentGenderPreference": "Female",
            "AppointmentStatus": "None",
            "ClassId": 207,
            "ClientId": "ClientId3"
          },
          {
            "AppointmentId": 130,
            "AppointmentGenderPreference": "None",
            "AppointmentStatus": "Requested",
            "ClassId": 206,
            "ClientId": "ClientId4"
          }
        ],
        "Clients": [
          {
            "AppointmentGenderPreference": "Female",
            "BirthDate": "2016-03-13T12:52:32.123Z",
            "Country": "Country3",
            "CreationDate": "2016-03-13T12:52:32.123Z",
            "CustomClientFields": [
              {
                "Value": "Value4",
                "Id": 202,
                "DataType": "DataType0",
                "Name": "Name6"
              },
              {
                "Value": "Value5",
                "Id": 203,
                "DataType": "DataType1",
                "Name": "Name7"
              }
            ]
          },
          {
            "AppointmentGenderPreference": "Male",
            "BirthDate": "2016-03-13T12:52:32.123Z",
            "Country": "Country4",
            "CreationDate": "2016-03-13T12:52:32.123Z",
            "CustomClientFields": [
              {
                "Value": "Value5",
                "Id": 203,
                "DataType": "DataType1",
                "Name": "Name7"
              },
              {
                "Value": "Value6",
                "Id": 204,
                "DataType": "DataType2",
                "Name": "Name8"
              },
              {
                "Value": "Value7",
                "Id": 205,
                "DataType": "DataType3",
                "Name": "Name9"
              }
            ]
          }
        ],
        "Location": {},
        "Resource": {
          "Id": 88,
          "Name": "Name2"
        }
      },
      {
        "ClassScheduleId": 193,
        "Visits": [
          {
            "AppointmentId": 130,
            "AppointmentGenderPreference": "None",
            "AppointmentStatus": "Requested",
            "ClassId": 206,
            "ClientId": "ClientId4"
          },
          {
            "AppointmentId": 131,
            "AppointmentGenderPreference": "Male",
            "AppointmentStatus": "Booked",
            "ClassId": 205,
            "ClientId": "ClientId5"
          },
          {
            "AppointmentId": 132,
            "AppointmentGenderPreference": "Female",
            "AppointmentStatus": "Completed",
            "ClassId": 204,
            "ClientId": "ClientId6"
          }
        ],
        "Clients": [
          {
            "AppointmentGenderPreference": "None",
            "BirthDate": "2016-03-13T12:52:32.123Z",
            "Country": "Country2",
            "CreationDate": "2016-03-13T12:52:32.123Z",
            "CustomClientFields": [
              {
                "Value": "Value3",
                "Id": 201,
                "DataType": "DataType9",
                "Name": "Name5"
              }
            ]
          }
        ],
        "Location": {},
        "Resource": {
          "Id": 89,
          "Name": "Name3"
        }
      }
    ],
    "Clients": [
      {},
      {}
    ],
    "Course": {
      "Id": 214,
      "Name": "Name4",
      "Description": "Description8",
      "Notes": "Notes6",
      "StartDate": "2016-03-13T12:52:32.123Z"
    },
    "SemesterId": 22,
    "IsAvailable": false
  },
  "Client": {
    "AppointmentGenderPreference": "None",
    "BirthDate": "2016-03-13T12:52:32.123Z",
    "Country": "Country8",
    "CreationDate": "2016-03-13T12:52:32.123Z",
    "CustomClientFields": [
      {
        "Value": "Value9",
        "Id": 141,
        "DataType": "DataType5",
        "Name": "Name1"
      }
    ]
  },
  "EnrollmentDateForward": "2016-03-13T12:52:32.123Z"
}
```

