
# Waitlist Entry

## Structure

`WaitlistEntry`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `class_date` | `datetime` | Optional | The date of the class or enrollment. |
| `class_id` | `long\|int` | Optional | The ID of the class or enrollment. |
| `class_schedule` | [`ClassSchedule`](../../doc/models/class-schedule.md) | Optional | Contains information about the class schedule for this waiting list entry. |
| `client` | [`Client`](../../doc/models/client.md) | Optional | Contains information about the requested client who is on the waiting list. |
| `enrollment_date_forward` | `datetime` | Optional | If the waiting list entry was created for an enrollment, this is the date on or after which the client can be added to the enrollment from the waitlist. |
| `id` | `int` | Optional | The ID of the waiting list entry. |
| `request_date_time` | `datetime` | Optional | The date and time that the request to be on the waiting list was made. |
| `visit_ref_no` | `int` | Optional | The ID of the visit that is associated with the waiting list entry. |
| `web` | `bool` | Optional | If `true`, the entry on the waiting list was requested online.<br /><br>If `false`, the entry on the waiting list was requested off-line, for example in person or by phone. |

## Example (as JSON)

```json
{
  "ClassDate": null,
  "ClassId": null,
  "ClassSchedule": null,
  "Client": null,
  "EnrollmentDateForward": null,
  "Id": null,
  "RequestDateTime": null,
  "VisitRefNo": null,
  "Web": null
}
```

