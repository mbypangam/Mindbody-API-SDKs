
# Get Client Purchases Response

## Structure

`GetClientPurchasesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `purchases` | [`List of MindbodyPublicApiDtoModelsV6ClientPurchaseRecord`](../../doc/models/mindbody-public-api-dto-models-v6-client-purchase-record.md) | Optional | Contains information that describes the item sold and the payment. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Purchases": null
}
```

