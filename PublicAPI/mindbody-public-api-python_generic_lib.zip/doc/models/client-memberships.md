
# Client Memberships

## Structure

`ClientMemberships`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `string` | Optional | ID of the client. |
| `memberships` | [`List of ClientMembership`](../../doc/models/client-membership.md) | Optional | Contains information about the Client Memberships details. |
| `error_message` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "Memberships": [
    {
      "RestrictedLocations": [
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs2",
            "AdditionalImageURLs3"
          ],
          "Address": "Address2",
          "Address2": "Address24",
          "Amenities": [
            {
              "Id": 106,
              "Name": "Name0"
            },
            {
              "Id": 107,
              "Name": "Name9"
            },
            {
              "Id": 108,
              "Name": "Name8"
            }
          ],
          "BusinessDescription": "BusinessDescription8"
        },
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs3",
            "AdditionalImageURLs4",
            "AdditionalImageURLs5"
          ],
          "Address": "Address1",
          "Address2": "Address23",
          "Amenities": [
            {
              "Id": 107,
              "Name": "Name9"
            }
          ],
          "BusinessDescription": "BusinessDescription7"
        },
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs4"
          ],
          "Address": "Address0",
          "Address2": "Address22",
          "Amenities": [
            {
              "Id": 108,
              "Name": "Name8"
            },
            {
              "Id": 109,
              "Name": "Name7"
            }
          ],
          "BusinessDescription": "BusinessDescription6"
        }
      ],
      "IconCode": "IconCode3",
      "MembershipId": 43,
      "ActiveDate": "2016-03-13T12:52:32.123Z",
      "Count": 43
    }
  ],
  "ErrorMessage": "ErrorMessage0"
}
```

