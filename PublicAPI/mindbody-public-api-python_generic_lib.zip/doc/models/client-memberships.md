
# Client Memberships

## Structure

`ClientMemberships`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `string` | Optional | ID of the client. |
| `memberships` | [`List of ClientMembership`](../../doc/models/client-membership.md) | Optional | Contains information about the Client Memberships details. |
| `error_message` | `string` | Optional | Incase if invalid clientID passed, we get ErrorMessage instead of Memberships. |

## Example (as JSON)

```json
{
  "ClientId": null,
  "Memberships": null,
  "ErrorMessage": null
}
```

