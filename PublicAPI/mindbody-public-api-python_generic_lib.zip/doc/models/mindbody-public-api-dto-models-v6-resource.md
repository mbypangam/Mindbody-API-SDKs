
# Mindbody Public Api Dto Models V6 Resource

Contains information about resources, such as rooms.

## Structure

`MindbodyPublicApiDtoModelsV6Resource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The ID of the resource. |
| `name` | `string` | Optional | The name of the resource. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

