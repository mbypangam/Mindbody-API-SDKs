
# Update Product Price Response

Update Product Price Response Model

## Structure

`UpdateProductPriceResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `product` | [`MindbodyPublicApiDtoModelsV6Product`](../../doc/models/mindbody-public-api-dto-models-v6-product.md) | Optional | Contains information about the product. |

## Example (as JSON)

```json
{
  "Product": null
}
```

