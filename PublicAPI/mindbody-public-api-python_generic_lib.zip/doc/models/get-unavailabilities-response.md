
# Get Unavailabilities Response

## Structure

`GetUnavailabilitiesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `unavailabilities` | [`List of MindbodyPublicApiDtoModelsV6UnavailabilityPlain`](../../doc/models/mindbody-public-api-dto-models-v6-unavailability-plain.md) | Optional | Contains information about unavailabilities |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Unavailabilities": null
}
```

