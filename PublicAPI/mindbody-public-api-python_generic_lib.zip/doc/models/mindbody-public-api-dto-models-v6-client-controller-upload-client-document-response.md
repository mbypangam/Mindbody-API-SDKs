
# Mindbody Public Api Dto Models V6 Client Controller Upload Client Document Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `file_size` | `long\|int` | Optional | The size of the uploaded file. |
| `file_name` | `string` | Optional | The name of the uploaded file. |

## Example (as JSON)

```json
{
  "FileSize": null,
  "FileName": null
}
```

