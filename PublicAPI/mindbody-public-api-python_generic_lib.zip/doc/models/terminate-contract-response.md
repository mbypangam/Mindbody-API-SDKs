
# Terminate Contract Response

## Structure

`TerminateContractResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contract` | [`ClientContract`](../../doc/models/client-contract.md) | Optional | A client contract |

## Example (as JSON)

```json
{
  "Contract": null
}
```

