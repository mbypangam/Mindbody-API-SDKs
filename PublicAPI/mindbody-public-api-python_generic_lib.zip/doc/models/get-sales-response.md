
# Get Sales Response

## Structure

`GetSalesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `sales` | [`List of Sale`](../../doc/models/sale.md) | Optional | Contains the Sale objects, each of which describes the sale and payment for a purchase event. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Sales": null
}
```

