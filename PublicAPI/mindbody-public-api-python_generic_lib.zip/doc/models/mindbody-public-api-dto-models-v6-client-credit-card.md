
# Mindbody Public Api Dto Models V6 Client Credit Card

A client credit card.

## Structure

`MindbodyPublicApiDtoModelsV6ClientCreditCard`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `address` | `string` | Optional | The billing address for the credit card. |
| `card_holder` | `string` | Optional | The name of the card holder. |
| `card_number` | `string` | Optional | The credit card number. |
| `card_type` | `string` | Optional | The type of credit card, for example Visa or MasterCard. |
| `city` | `string` | Optional | The city in which the billing address is located. |
| `exp_month` | `string` | Optional | The month in which the credit card expires. |
| `exp_year` | `string` | Optional | The year in which the credit card expires. |
| `last_four` | `string` | Optional | The last four digits of the credit card number. |
| `postal_code` | `string` | Optional | The postal code where the billing address is located. |
| `state` | `string` | Optional | The state that the billing address is located in. |

## Example (as JSON)

```json
{
  "Address": null,
  "CardHolder": null,
  "CardNumber": null,
  "CardType": null,
  "City": null,
  "ExpMonth": null,
  "ExpYear": null,
  "LastFour": null,
  "PostalCode": null,
  "State": null
}
```

