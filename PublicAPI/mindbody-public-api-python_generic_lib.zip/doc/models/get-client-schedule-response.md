
# Get Client Schedule Response

## Structure

`GetClientScheduleResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `visits` | [`List of MindbodyPublicApiDtoModelsV6Visit`](../../doc/models/mindbody-public-api-dto-models-v6-visit.md) | Optional | Contains information about client visits. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Visits": null
}
```

