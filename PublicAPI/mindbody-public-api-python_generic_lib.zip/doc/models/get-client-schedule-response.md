
# Get Client Schedule Response

## Structure

`GetClientScheduleResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `visits` | [`List of Visit`](../../doc/models/visit.md) | Optional | Contains information about client visits. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Visits": null
}
```

