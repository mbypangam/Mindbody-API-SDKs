
# Checkout Payment Info

## Structure

`CheckoutPaymentInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | `string` | Optional | The type of payment. Possible values are:<br><br>* CreditCard - Indicates that this payment item is a credit card.<br>* StoredCard - Indicates that this payment item is a credit card stored on the client’s account.<br>* EncryptedTrackData - Indicates that this payment item is a swiped credit card.<br>* TrackData - Indicates that this payment item is a swiped credit card.<br>* DebitAccount - Indicates that funds should be debited from the client’s account.<br>* Custom - Indicates that this payment item is a custom payment method configured by the business.<br>* Comp - Indicates that this payment item is making all or part of the cart’s total complementary.<br>* Cash - Indicates that this payment item is cash.<br>* Check - Indicates that this payment item is a check.<br>* GiftCard - Indicates that this payment item is a gift card. |
| `metadata` | `dict` | Optional | Contains information about the cart’s payments. See [Payment Item Metadata](https://developers.mindbodyonline.com/PublicDocumentation/V6#payment-item-metadata) for more information. |

## Example (as JSON)

```json
{
  "Type": null,
  "Metadata": null
}
```

