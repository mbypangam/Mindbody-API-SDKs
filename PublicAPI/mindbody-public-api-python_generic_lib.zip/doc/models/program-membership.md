
# Program Membership

## Structure

`ProgramMembership`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | The service category’s ID. |
| `name` | `str` | Optional | The name of this service category. |

## Example (as JSON)

```json
{
  "Id": 146,
  "Name": "Name0"
}
```

