
# Get Clients Response

## Structure

`GetClientsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `clients` | [`List[ClientWithSuspensionInfo]`](../../doc/models/client-with-suspension-info.md) | Optional | The requested clients. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Clients": [
    {
      "SuspensionInfo": {
        "BookingSuspended": true,
        "SuspensionStartDate": "SuspensionStartDate1",
        "SuspensionEndDate": "SuspensionEndDate5"
      },
      "AppointmentGenderPreference": "Male",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country9",
      "CreationDate": "2016-03-13T12:52:32.123Z"
    },
    {
      "SuspensionInfo": {
        "BookingSuspended": false,
        "SuspensionStartDate": "SuspensionStartDate2",
        "SuspensionEndDate": "SuspensionEndDate6"
      },
      "AppointmentGenderPreference": "None",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country0",
      "CreationDate": "2016-03-13T12:52:32.123Z"
    },
    {
      "SuspensionInfo": {
        "BookingSuspended": true,
        "SuspensionStartDate": "SuspensionStartDate3",
        "SuspensionEndDate": "SuspensionEndDate7"
      },
      "AppointmentGenderPreference": "Female",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country1",
      "CreationDate": "2016-03-13T12:52:32.123Z"
    }
  ]
}
```

