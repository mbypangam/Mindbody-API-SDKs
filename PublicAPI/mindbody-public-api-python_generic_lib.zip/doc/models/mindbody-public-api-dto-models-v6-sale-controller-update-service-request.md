
# Mindbody Public Api Dto Models V6 Sale Controller Update Service Request

This class represents the request parameters for the update service API

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `barcode_id` | `string` | Optional | The barcode ID of the pricing option. |
| `price` | `float` | Optional | The cost of the pricing option when sold at a physical location.<br>**Constraints**: `>= 0` |
| `online_price` | `float` | Optional | The cost of the pricing option when sold online.<br>**Constraints**: `>= 0` |

## Example (as JSON)

```json
{
  "BarcodeId": null,
  "Price": null,
  "OnlinePrice": null
}
```

