
# Mindbody Public Api Dto Models V6 Appointment Add On

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentAddOn`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `name` | `string` | Optional | - |
| `num_deducted` | `int` | Optional | - |
| `category_id` | `int` | Optional | - |
| `category` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "NumDeducted": null,
  "CategoryId": null,
  "Category": null
}
```

