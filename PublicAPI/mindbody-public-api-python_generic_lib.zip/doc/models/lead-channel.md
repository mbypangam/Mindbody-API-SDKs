
# Lead Channel

## Structure

`LeadChannel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `name` | `string` | Optional | - |
| `salespipeline_id` | `int` | Optional | - |
| `universal_customer_id` | `uuid\|string` | Optional | - |
| `studio_id` | `int` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "SalespipelineId": null,
  "UniversalCustomerId": "00000000-0000-0000-0000-000000000000",
  "StudioId": null
}
```

