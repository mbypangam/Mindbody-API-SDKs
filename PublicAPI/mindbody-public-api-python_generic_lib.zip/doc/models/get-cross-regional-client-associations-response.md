
# Get Cross Regional Client Associations Response

## Structure

`GetCrossRegionalClientAssociationsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `cross_regional_client_associations` | [`List of MindbodyPublicApiDtoModelsV6CrossRegionalClientAssociation`](../../doc/models/mindbody-public-api-dto-models-v6-cross-regional-client-association.md) | Optional | Contains information about the client’s cross regional associations. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "CrossRegionalClientAssociations": null
}
```

