
# Update Client Rewards Response

## Structure

`UpdateClientRewardsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `transaction` | [`ClientRewardTransaction`](../../doc/models/client-reward-transaction.md) | Optional | The Transaction that was performed against the client rewards |
| `balance` | `long\|int` | Optional | The client's reward Balance, after the transaction |

## Example (as JSON)

```json
{
  "Transaction": null,
  "Balance": null
}
```

