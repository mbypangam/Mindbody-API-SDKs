
# Mindbody Public Api Dto Models V6 Semester

Semesters help you quickly classify enrollments.

## Structure

`MindbodyPublicApiDtoModelsV6Semester`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | This semester's unique ID. |
| `name` | `string` | Optional | Name of the semester. |
| `description` | `string` | Optional | The description of the semester. |
| `start_date` | `datetime` | Optional | Start date of the semester. |
| `end_date` | `datetime` | Optional | End date of the semester. |
| `multi_registration_discount` | `float` | Optional | Discount for multiple registration in the semester. |
| `multi_registration_deadline` | `datetime` | Optional | Registration deadline of the semester. |
| `active` | `bool` | Optional | When `true`, indicates that the semester is active. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null,
  "StartDate": null,
  "EndDate": null,
  "MultiRegistrationDiscount": null,
  "MultiRegistrationDeadline": null,
  "Active": null
}
```

