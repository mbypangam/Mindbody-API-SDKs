
# Mindbody Public Api Dto Models V6 Class Controller Get Enrollments Response

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `enrollments` | [`List of MindbodyPublicApiDtoModelsV6ClassSchedule`](../../doc/models/mindbody-public-api-dto-models-v6-class-schedule.md) | Optional | Contains information about the enrollments. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Enrollments": null
}
```

