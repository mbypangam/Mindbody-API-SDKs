
# Resource 1

## Structure

`Resource1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `name` | `string` | Optional | - |
| `location_id` | `int` | Optional | - |
| `is_active` | `bool` | Optional | - |
| `schedule_types` | [`List of ScheduleType4Enum`](../../doc/models/schedule-type-4-enum.md) | Optional | - |
| `program_ids` | `List of int` | Optional | - |

## Example (as JSON)

```json
{
  "Id": 146,
  "Name": "Name0",
  "LocationId": 50,
  "IsActive": false,
  "ScheduleTypes": [
    "Media",
    "Arrival"
  ]
}
```

