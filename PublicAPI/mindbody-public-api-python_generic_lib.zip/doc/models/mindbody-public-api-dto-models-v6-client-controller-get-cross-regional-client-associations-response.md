
# Mindbody Public Api Dto Models V6 Client Controller Get Cross Regional Client Associations Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. |
| `cross_regional_client_associations` | [`List of MindbodyPublicApiDtoModelsV6CrossRegionalClientAssociation`](../../doc/models/mindbody-public-api-dto-models-v6-cross-regional-client-association.md) | Optional | Contains information about the client's cross regional associations. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "CrossRegionalClientAssociations": null
}
```

