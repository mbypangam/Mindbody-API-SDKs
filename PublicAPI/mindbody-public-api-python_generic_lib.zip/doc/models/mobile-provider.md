
# Mobile Provider

## Structure

`MobileProvider`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `int` | Optional | - |
| `active` | `bool` | Optional | - |
| `provider_name` | `string` | Optional | - |
| `provider_address` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": 146,
  "Active": false,
  "ProviderName": "ProviderName2",
  "ProviderAddress": "ProviderAddress8"
}
```

