
# Response Details

## Structure

`ResponseDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Optional | - |
| `transaction_id` | `string` | Optional | - |
| `message` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Status": null,
  "TransactionId": null,
  "Message": null
}
```

