
# Response Details

Contains information about the response message detail.

## Structure

`ResponseDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string` | Optional | Contains information about the response status. |
| `transaction_id` | `string` | Optional | The unique transaction ID. |
| `message` | `string` | Optional | Contains information about the response message detail. |

## Example (as JSON)

```json
{
  "Status": "Status8",
  "TransactionId": "TransactionId8",
  "Message": "Message6"
}
```

