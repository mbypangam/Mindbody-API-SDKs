
# Get Contact Log Types Response

## Structure

`GetContactLogTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `contact_log_types` | [`List of ContactLogType`](../../doc/models/contact-log-type.md) | Optional | The requested Active ContactLogTypes |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ContactLogTypes": null
}
```

