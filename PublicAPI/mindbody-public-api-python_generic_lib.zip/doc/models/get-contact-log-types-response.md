
# Get Contact Log Types Response

## Structure

`GetContactLogTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `contact_log_types` | [`List of ContactLogType`](../../doc/models/contact-log-type.md) | Optional | The requested Active ContactLogTypes |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "ContactLogTypes": [
    {
      "Id": 90,
      "Name": "Name0",
      "SubTypes": [
        {
          "Id": 28,
          "Name": "Name4"
        },
        {
          "Id": 29,
          "Name": "Name3"
        }
      ]
    },
    {
      "Id": 91,
      "Name": "Name1",
      "SubTypes": [
        {
          "Id": 29,
          "Name": "Name3"
        },
        {
          "Id": 30,
          "Name": "Name2"
        },
        {
          "Id": 31,
          "Name": "Name1"
        }
      ]
    },
    {
      "Id": 92,
      "Name": "Name2",
      "SubTypes": [
        {
          "Id": 30,
          "Name": "Name2"
        }
      ]
    }
  ]
}
```

