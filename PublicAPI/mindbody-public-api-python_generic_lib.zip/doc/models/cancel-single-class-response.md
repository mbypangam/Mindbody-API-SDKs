
# Cancel Single Class Response

## Structure

`CancelSingleClassResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mclass` | [`Class`](../../doc/models/class.md) | Optional | A resulting class. |

## Example (as JSON)

```json
{
  "Class": null
}
```

