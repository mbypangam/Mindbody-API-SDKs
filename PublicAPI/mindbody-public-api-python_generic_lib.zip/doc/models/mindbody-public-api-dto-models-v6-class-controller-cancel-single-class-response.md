
# Mindbody Public Api Dto Models V6 Class Controller Cancel Single Class Response

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mclass` | [`MindbodyPublicApiDtoModelsV6Class`](../../doc/models/mindbody-public-api-dto-models-v6-class.md) | Optional | A resulting class. |

## Example (as JSON)

```json
{
  "Class": null
}
```

