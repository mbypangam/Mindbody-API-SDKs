
# Get Pick a Spot Class Response

Contains information about the get PickASpot class response.

## Structure

`GetPickASpotClassResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `classes` | [`List[PickASpotClass]`](../../doc/models/pick-a-spot-class.md) | Optional | Contains information about the PickASpot classes. |
| `pagination` | [`Pagination`](../../doc/models/pagination.md) | Optional | Contains information about the pagination used. |
| `response_details` | [`ResponseDetails`](../../doc/models/response-details.md) | Optional | Contains information about the response message detail. |

## Example (as JSON)

```json
{
  "classes": [
    {
      "SiteId": 132,
      "LocationId": 18,
      "ClassId": "ClassId6",
      "ClassExternalId": "ClassExternalId4",
      "ClassName": "ClassName0"
    },
    {
      "SiteId": 131,
      "LocationId": 17,
      "ClassId": "ClassId7",
      "ClassExternalId": "ClassExternalId3",
      "ClassName": "ClassName9"
    }
  ],
  "pagination": {
    "PageNumber": 92,
    "PageSize": 26,
    "TotalResultCount": 42,
    "TotalPageCount": 112
  },
  "responseDetails": {
    "Status": "Status8",
    "TransactionId": "TransactionId8",
    "Message": "Message6"
  }
}
```

