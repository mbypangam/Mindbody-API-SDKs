
# Get Client Account Balances Response

## Structure

`GetClientAccountBalancesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `clients` | [`List of Client`](../../doc/models/client.md) | Optional | A list of clients. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Clients": null
}
```

