
# Location 1

## Structure

`Location1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `business_id` | `int` | Optional | - |
| `site_id` | `int` | Optional | - |
| `business_description` | `string` | Optional | - |
| `additional_image_ur_ls` | `List of string` | Optional | - |
| `facility_square_feet` | `int` | Optional | - |
| `pro_spa_finder_site` | `bool` | Optional | - |
| `has_classes` | `bool` | Optional | - |
| `phone_extension` | `string` | Optional | - |
| `action` | [`ActionEnum`](../../doc/models/action-enum.md) | Optional | - |
| `id` | `int` | Optional | - |
| `name` | `string` | Optional | - |
| `address` | `string` | Optional | - |
| `address_2` | `string` | Optional | - |
| `tax_1` | `float` | Optional | - |
| `tax_2` | `float` | Optional | - |
| `tax_3` | `float` | Optional | - |
| `tax_4` | `float` | Optional | - |
| `tax_5` | `float` | Optional | - |
| `phone` | `string` | Optional | - |
| `city` | `string` | Optional | - |
| `state_prov_code` | `string` | Optional | - |
| `postal_code` | `string` | Optional | - |
| `latitude` | `float` | Optional | - |
| `longitude` | `float` | Optional | - |
| `distance_in_miles` | `float` | Optional | - |
| `image_url` | `string` | Optional | - |
| `description` | `string` | Optional | - |
| `has_site` | `bool` | Optional | - |
| `can_book` | `bool` | Optional | - |
| `number_treatment_rooms` | `int` | Optional | - |
| `active` | `bool` | Optional | - |
| `inv_active` | `bool` | Optional | - |
| `ws_show` | `bool` | Optional | - |
| `email` | `string` | Optional | - |
| `contact_name` | `string` | Optional | - |
| `ship_address` | `string` | Optional | - |
| `ship_state` | `string` | Optional | - |
| `ship_postal` | `string` | Optional | - |
| `ship_phone` | `string` | Optional | - |
| `ship_poc` | `string` | Optional | - |
| `tax_grouping` | `bool` | Optional | - |
| `label_tax_1` | `string` | Optional | - |
| `label_tax_2` | `string` | Optional | - |
| `label_tax_3` | `string` | Optional | - |
| `label_tax_4` | `string` | Optional | - |
| `label_tax_5` | `string` | Optional | - |
| `wac` | `bool` | Optional | - |
| `ship_address_2` | `string` | Optional | - |
| `master_loc_id` | `int` | Optional | - |
| `street_address` | `string` | Optional | - |
| `country` | `string` | Optional | - |
| `ext` | `string` | Optional | - |
| `amenities` | [`List of Amenity1`](../../doc/models/amenity-1.md) | Optional | - |
| `total_number_of_deals` | `long\|int` | Optional | - |
| `total_number_of_ratings` | `int` | Optional | - |
| `average_rating` | `float` | Optional | - |

## Example (as JSON)

```json
{
  "BusinessId": 144,
  "SiteId": 164,
  "BusinessDescription": "BusinessDescription4",
  "AdditionalImageURLs": [
    "AdditionalImageURLs6"
  ],
  "FacilitySquareFeet": 2
}
```

