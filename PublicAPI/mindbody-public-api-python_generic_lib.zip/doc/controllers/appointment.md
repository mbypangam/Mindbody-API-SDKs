# Appointment

```python
appointment_controller = client.appointment
```

## Class Name

`AppointmentController`

## Methods

* [Appointment Add Appointment](../../doc/controllers/appointment.md#appointment-add-appointment)
* [Appointment Update Appointment](../../doc/controllers/appointment.md#appointment-update-appointment)
* [Appointment Get Available Dates](../../doc/controllers/appointment.md#appointment-get-available-dates)
* [Appointment Get Bookable Items](../../doc/controllers/appointment.md#appointment-get-bookable-items)
* [Appointment Get Active Session Times](../../doc/controllers/appointment.md#appointment-get-active-session-times)
* [Appointment Get Schedule Items](../../doc/controllers/appointment.md#appointment-get-schedule-items)
* [Appointment Get Appointment Options](../../doc/controllers/appointment.md#appointment-get-appointment-options)
* [Appointment Get Staff Appointments](../../doc/controllers/appointment.md#appointment-get-staff-appointments)
* [Appointment Get Add Ons](../../doc/controllers/appointment.md#appointment-get-add-ons)
* [Appointment Add Appointment Add On](../../doc/controllers/appointment.md#appointment-add-appointment-add-on)
* [Appointment Delete Appointment Add On](../../doc/controllers/appointment.md#appointment-delete-appointment-add-on)
* [Appointment Remove From Waitlist](../../doc/controllers/appointment.md#appointment-remove-from-waitlist)
* [Appointment Update Availability](../../doc/controllers/appointment.md#appointment-update-availability)
* [Appointment Add Availabilities](../../doc/controllers/appointment.md#appointment-add-availabilities)
* [Appointment Delete Availability](../../doc/controllers/appointment.md#appointment-delete-availability)
* [Appointment Get Unavailabilities](../../doc/controllers/appointment.md#appointment-get-unavailabilities)


# Appointment Add Appointment

A user token is required for this endpoint. To book an appointment, you must use a location ID, staff ID, client ID, session type ID, and the StartDateTime of the appointment. You can get most of this information using GET BookableItems.

```python
def appointment_add_appointment(self,
                               version,
                               request,
                               site_id,
                               authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-response.md)

## Example Usage

```python
version = '6'
request = MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentRequest()
request.client_id = 'ClientId0'
request.location_id = 238
request.session_type_id = 82
request.staff_id = 188
request.start_date_time = dateutil.parser.parse('2016-03-13T12:52:32.123Z')
site_id = '-99'

result = appointment_controller.appointment_add_appointment(version, request, site_id)
```


# Appointment Update Appointment

To update the information for a specific appointment, you must have a staff user token with the proper permissions. Note that you can only update the appointment’s `StartDateTime`, `EndDateTime`, `StaffId`, `Notes`, and `SessionTypeId`.

```python
def appointment_update_appointment(self,
                                  version,
                                  request,
                                  site_id,
                                  authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-appointment-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-appointment-response.md)

## Example Usage

```python
version = '6'
request = MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest()
request.appointment_id = 246
site_id = '-99'

result = appointment_controller.appointment_update_appointment(version, request, site_id)
```


# Appointment Get Available Dates

Returns a list of dates to narrow down staff availability when booking. Dates are those which staff are scheduled to work and do not guarantee booking availabilities. After this call is made, use GET BookableItems to retrieve availabilities for specific dates before booking.

```python
def appointment_get_available_dates(self,
                                   version,
                                   request_session_type_id,
                                   site_id,
                                   authorization=None,
                                   request_end_date=None,
                                   request_location_id=None,
                                   request_staff_id=None,
                                   request_start_date=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request_session_type_id` | `int` | Query, Required | required requested session type ID. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_end_date` | `datetime` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `request_location_id` | `int` | Query, Optional | optional requested location ID. |
| `request_staff_id` | `long\|int` | Query, Optional | optional requested staff ID. |
| `request_start_date` | `datetime` | Query, Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today’s date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-available-dates-response.md)

## Example Usage

```python
version = '6'
request_session_type_id = 100
site_id = '-99'

result = appointment_controller.appointment_get_available_dates(version, request_session_type_id, site_id)
```


# Appointment Get Bookable Items

Returns a list of availabilities with the information needed to book appointments. Availabilities include information such as the location and its amenities, staff members, programs, and session types. Recommended to use with ActiveSessionTimes to see which increments each business allows for booking appointments.

```python
def appointment_get_bookable_items(self,
                                  version,
                                  request_session_type_ids,
                                  site_id,
                                  authorization=None,
                                  request_appointment_id=None,
                                  request_end_date=None,
                                  request_ignore_default_session_length=None,
                                  request_limit=None,
                                  request_location_ids=None,
                                  request_offset=None,
                                  request_staff_ids=None,
                                  request_start_date=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request_session_type_ids` | `List of int` | Query, Required | A list of the requested session type IDs. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_appointment_id` | `long\|int` | Query, Optional | If provided, filters out the appointment with this ID. |
| `request_end_date` | `datetime` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `request_ignore_default_session_length` | `bool` | Query, Optional | When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br /><br>When `false`, only availabilities that have the default session length return. |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_ids` | `List of int` | Query, Optional | A list of the requested location IDs. |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_staff_ids` | `List of long\|int` | Query, Optional | A list of the requested staff IDs. Omit parameter to return all staff availabilities. |
| `request_start_date` | `datetime` | Query, Optional | The start date of the requested date range.<br><br />Default: **today’s date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-bookable-items-response.md)

## Example Usage

```python
version = '6'
request_session_type_ids = [228, 229]
site_id = '-99'

result = appointment_controller.appointment_get_bookable_items(version, request_session_type_ids, site_id)
```


# Appointment Get Active Session Times

This is not appointment availability but rather the active business hours for studios and which increments services can be booked at. See BookableItems for appointment availability.

```python
def appointment_get_active_session_times(self,
                                        version,
                                        site_id,
                                        authorization=None,
                                        request_end_time=None,
                                        request_limit=None,
                                        request_offset=None,
                                        request_schedule_type=None,
                                        request_session_type_ids=None,
                                        request_start_time=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_end_time` | `datetime` | Query, Optional | Filters results to times that end on or before this time on the current date. Any date provided is ignored..<br><br />Default: **23:59:59** |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_schedule_type` | [`RequestScheduleTypeEnum`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided. |
| `request_session_type_ids` | `List of int` | Query, Optional | Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided. |
| `request_start_time` | `datetime` | Query, Optional | Filters results to times that start on or after this time on the current date. Any date provided is ignored.<br><br />Default: **00:00:00** |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-active-session-times-response.md)

## Example Usage

```python
version = '6'
site_id = '-99'

result = appointment_controller.appointment_get_active_session_times(version, site_id)
```


# Appointment Get Schedule Items

Returns a list of schedule items, including appointments, availabilities, and unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.

```python
def appointment_get_schedule_items(self,
                                  version,
                                  site_id,
                                  authorization=None,
                                  request_end_date=None,
                                  request_ignore_prep_finish_times=None,
                                  request_limit=None,
                                  request_location_ids=None,
                                  request_offset=None,
                                  request_staff_ids=None,
                                  request_start_date=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_end_date` | `datetime` | Query, Optional | The end date of the requested date range.<br><br />Default: **today’s date** |
| `request_ignore_prep_finish_times` | `bool` | Query, Optional | When `true`, appointment preparation and finish unavailabilities are not returned.<br><br />Default: **false** |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_ids` | `List of int` | Query, Optional | A list of requested location IDs. |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_staff_ids` | `List of long\|int` | Query, Optional | A list of requested staff IDs. |
| `request_start_date` | `datetime` | Query, Optional | The start date of the requested date range.<br><br />Default: **today’s date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-schedule-items-response.md)

## Example Usage

```python
version = '6'
site_id = '-99'

result = appointment_controller.appointment_get_schedule_items(version, site_id)
```


# Appointment Get Appointment Options

This endpoint has no query parameters.

```python
def appointment_get_appointment_options(self,
                                       version,
                                       site_id,
                                       authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-appointment-options-response.md)

## Example Usage

```python
version = '6'
site_id = '-99'

result = appointment_controller.appointment_get_appointment_options(version, site_id)
```


# Appointment Get Staff Appointments

Returns a list of appointments by staff member.

```python
def appointment_get_staff_appointments(self,
                                      version,
                                      site_id,
                                      authorization=None,
                                      request_appointment_ids=None,
                                      request_client_id=None,
                                      request_end_date=None,
                                      request_limit=None,
                                      request_location_ids=None,
                                      request_offset=None,
                                      request_staff_ids=None,
                                      request_start_date=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_appointment_ids` | `List of int` | Query, Optional | A list of the requested appointment IDs. |
| `request_client_id` | `string` | Query, Optional | The client ID to be returned. |
| `request_end_date` | `datetime` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_ids` | `List of int` | Query, Optional | A list of the requested location IDs. |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_staff_ids` | `List of long\|int` | Query, Optional | List of staff IDs to be returned. Use a value of zero to return all staff appointments. |
| `request_start_date` | `datetime` | Query, Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today’s date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-staff-appointments-response.md)

## Example Usage

```python
version = '6'
site_id = '-99'

result = appointment_controller.appointment_get_staff_appointments(version, site_id)
```


# Appointment Get Add Ons

Get active appointment add-ons.

```python
def appointment_get_add_ons(self,
                           version,
                           site_id,
                           authorization=None,
                           request_limit=None,
                           request_offset=None,
                           request_staff_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_staff_id` | `int` | Query, Optional | Filter to add-ons only performed by this staff member. |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-add-ons-response.md)

## Example Usage

```python
version = '6'
site_id = '-99'

result = appointment_controller.appointment_get_add_ons(version, site_id)
```


# Appointment Add Appointment Add On

This endpoint books an add-on on top of an existing, regular appointment. To book an add-on, you must use an existing appointment ID and session type ID. You can get a session type ID using `GET AppointmentAddOns`.

```python
def appointment_add_appointment_add_on(self,
                                      version,
                                      request,
                                      site_id,
                                      authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-add-on-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-add-on-response.md)

## Example Usage

```python
version = '6'
request = MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest()
site_id = '-99'

result = appointment_controller.appointment_add_appointment_add_on(version, request, site_id)
```


# Appointment Delete Appointment Add On

This endpoint can be used to early-cancel a booked appointment add-on.

```python
def appointment_delete_appointment_add_on(self,
                                         version,
                                         id,
                                         site_id,
                                         authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `id` | `long\|int` | Query, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`void`

## Example Usage

```python
version = '6'
id = 112
site_id = '-99'

result = appointment_controller.appointment_delete_appointment_add_on(version, id, site_id)
```


# Appointment Remove From Waitlist

Remove an appointment from waitlist

```python
def appointment_remove_from_waitlist(self,
                                    version,
                                    request_waitlist_entry_ids,
                                    site_id,
                                    authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request_waitlist_entry_ids` | `List of int` | Query, Required | A list of `WaitlistEntryIds` to remove from the waiting list. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`object`

## Example Usage

```python
version = '6'
request_waitlist_entry_ids = [138, 139]
site_id = '-99'

result = appointment_controller.appointment_remove_from_waitlist(version, request_waitlist_entry_ids, site_id)
```


# Appointment Update Availability

To update the information for a specific availability or unavailability of the staff.<br />
Note: You must have a staff user token with the required permissions.

```python
def appointment_update_availability(self,
                                   version,
                                   site_id,
                                   update_availability_request,
                                   authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `update_availability_request` | [`MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-availability-request.md) | Body, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-availability-response.md)

## Example Usage

```python
version = '6'
site_id = '-99'
update_availability_request = MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest()

result = appointment_controller.appointment_update_availability(version, site_id, update_availability_request)
```


# Appointment Add Availabilities

Add availabilities and unavailabilities for a staff member.<br />
Note: You must have a staff user token with the required permissions.

```python
def appointment_add_availabilities(self,
                                  version,
                                  request,
                                  site_id,
                                  authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-availabilities-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-availabilities-response.md)

## Example Usage

```python
version = '6'
request = MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest()
site_id = '-99'

result = appointment_controller.appointment_add_availabilities(version, request, site_id)
```


# Appointment Delete Availability

This endpoint deletes the availability or unavailability.
Note: You must have a staff user token with the required permissions.

```python
def appointment_delete_availability(self,
                                   version,
                                   site_id,
                                   authorization=None,
                                   delete_availability_request_availability_id=None,
                                   delete_availability_request_test=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `delete_availability_request_availability_id` | `int` | Query, Optional | The ID of the availability or unavailability. |
| `delete_availability_request_test` | `bool` | Query, Optional | When `true`, indicates that this is a test request and no data is deleted from the subscriber’s database.<br>When `false`, the record will be deleted.<br>Default: **false** |

## Response Type

`void`

## Example Usage

```python
version = '6'
site_id = '-99'

result = appointment_controller.appointment_delete_availability(version, site_id)
```


# Appointment Get Unavailabilities

Returns a list of unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed..

```python
def appointment_get_unavailabilities(self,
                                    version,
                                    site_id,
                                    authorization=None,
                                    request_end_date=None,
                                    request_limit=None,
                                    request_offset=None,
                                    request_staff_ids=None,
                                    request_start_date=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_end_date` | `datetime` | Query, Optional | The end date of the requested date range.<br><br />Default: **today’s date** |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_staff_ids` | `List of long\|int` | Query, Optional | A list of requested staff IDs. |
| `request_start_date` | `datetime` | Query, Optional | The start date of the requested date range.<br><br />Default: **today’s date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-unavailabilities-response.md)

## Example Usage

```python
version = '6'
site_id = '-99'

result = appointment_controller.appointment_get_unavailabilities(version, site_id)
```

