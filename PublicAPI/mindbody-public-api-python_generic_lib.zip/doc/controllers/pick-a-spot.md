# Pick a Spot

```python
pick_a_spot_controller = client.pick_a_spot
```

## Class Name

`PickASpotController`

## Methods

* [Get Class List](../../doc/controllers/pick-a-spot.md#get-class-list)
* [Get Class](../../doc/controllers/pick-a-spot.md#get-class)
* [Get Reservation](../../doc/controllers/pick-a-spot.md#get-reservation)
* [Update Reservation](../../doc/controllers/pick-a-spot.md#update-reservation)
* [Create Reservation](../../doc/controllers/pick-a-spot.md#create-reservation)
* [Delete Reservation](../../doc/controllers/pick-a-spot.md#delete-reservation)


# Get Class List

A user token is required for this endpoint.

```python
def get_class_list(self,
                  version,
                  page_number,
                  page_size,
                  site_id,
                  authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `page_number` | `int` | Query, Required | Page number. |
| `page_size` | `int` | Query, Required | Page size |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetPickASpotClassResponse`](../../doc/models/get-pick-a-spot-class-response.md)

## Example Usage

```python
version = '6'
page_number = 110
page_size = 118
site_id = '-99'

result = pick_a_spot_controller.get_class_list(version, page_number, page_size, site_id)
```


# Get Class

A user token is required for this endpoint.

```python
def get_class(self,
             version,
             class_id,
             page_number,
             page_size,
             site_id,
             authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `class_id` | `string` | Template, Required | - |
| `page_number` | `int` | Query, Required | Page number. |
| `page_size` | `int` | Query, Required | Page size |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetPickASpotClassResponse`](../../doc/models/get-pick-a-spot-class-response.md)

## Example Usage

```python
version = '6'
class_id = 'classId0'
page_number = 110
page_size = 118
site_id = '-99'

result = pick_a_spot_controller.get_class(version, class_id, page_number, page_size, site_id)
```


# Get Reservation

A user token is required for this endpoint.

```python
def get_reservation(self,
                   version,
                   path_info,
                   site_id,
                   authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `path_info` | `string` | Template, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetReservationResponse`](../../doc/models/get-reservation-response.md)

## Example Usage

```python
version = '6'
path_info = 'pathInfo8'
site_id = '-99'

result = pick_a_spot_controller.get_reservation(version, path_info, site_id)
```


# Update Reservation

A user token is required for this endpoint.

```python
def update_reservation(self,
                      version,
                      path_info,
                      site_id,
                      authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `path_info` | `string` | Template, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateReservationResponse`](../../doc/models/update-reservation-response.md)

## Example Usage

```python
version = '6'
path_info = 'pathInfo8'
site_id = '-99'

result = pick_a_spot_controller.update_reservation(version, path_info, site_id)
```


# Create Reservation

A user token is required for this endpoint.

```python
def create_reservation(self,
                      version,
                      path_info,
                      site_id,
                      authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `path_info` | `string` | Template, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`CreateReservationResponse`](../../doc/models/create-reservation-response.md)

## Example Usage

```python
version = '6'
path_info = 'pathInfo8'
site_id = '-99'

result = pick_a_spot_controller.create_reservation(version, path_info, site_id)
```


# Delete Reservation

A user token is required for this endpoint.

```python
def delete_reservation(self,
                      version,
                      path_info,
                      site_id,
                      authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `path_info` | `string` | Template, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`DeleteReservationResponse`](../../doc/models/delete-reservation-response.md)

## Example Usage

```python
version = '6'
path_info = 'pathInfo8'
site_id = '-99'

result = pick_a_spot_controller.delete_reservation(version, path_info, site_id)
```

