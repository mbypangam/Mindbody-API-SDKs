# Staff

```python
staff_controller = client.staff
```

## Class Name

`StaffController`

## Methods

* [Get Staff Image URL](../../doc/controllers/staff.md#get-staff-image-url)
* [Get Sales Reps](../../doc/controllers/staff.md#get-sales-reps)
* [Get Staff Session Types](../../doc/controllers/staff.md#get-staff-session-types)
* [Get Staff](../../doc/controllers/staff.md#get-staff)
* [Get Staff Permissions](../../doc/controllers/staff.md#get-staff-permissions)
* [Add Staff](../../doc/controllers/staff.md#add-staff)
* [Assign Staff Session Type](../../doc/controllers/staff.md#assign-staff-session-type)
* [Add Staff Availability](../../doc/controllers/staff.md#add-staff-availability)
* [Update Staff](../../doc/controllers/staff.md#update-staff)
* [Update Staff Permissions](../../doc/controllers/staff.md#update-staff-permissions)


# Get Staff Image URL

This endpoint can be utilized to retrieve image urls for requested staff member.

```python
def get_staff_image_url(self,
                       version,
                       site_id,
                       authorization=None,
                       request_staff_id=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_staff_id` | `long\|int` | Query, Optional | The ID of the staff member whose image URL details you want to retrieve. |

## Response Type

[`GetStaffImageURLResponse`](../../doc/models/get-staff-image-url-response.md)

## Example Usage

```python
version = '6'
site_id = '-99'

result = staff_controller.get_staff_image_url(version, site_id)
```


# Get Sales Reps

This endpoint returns the basic details of the staffs that are marked as sales reps.

```python
def get_sales_reps(self,
                  version,
                  site_id,
                  authorization=None,
                  request_active_only=None,
                  request_limit=None,
                  request_offset=None,
                  request_sales_rep_numbers=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_active_only` | `bool` | Query, Optional | When `true`, will return only active reps data.<br>Default : **false** |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_sales_rep_numbers` | `List of int` | Query, Optional | This is the list of the sales rep numbers for which the salesrep data will be fetched. |

## Response Type

[`GetSalesRepsResponse`](../../doc/models/get-sales-reps-response.md)

## Example Usage

```python
version = '6'
site_id = '-99'

result = staff_controller.get_sales_reps(version, site_id)
```


# Get Staff Session Types

Gets a list of active session types for a specific staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```python
def get_staff_session_types(self,
                           version,
                           request_staff_id,
                           site_id,
                           authorization=None,
                           request_limit=None,
                           request_offset=None,
                           request_online_only=None,
                           request_program_ids=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request_staff_id` | `long\|int` | Query, Required | The ID of the staff member whose session types you want to return. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_online_only` | `bool` | Query, Optional | When `true`, indicates that only the session types that can be booked online should be returned.<br>Default: **false** |
| `request_program_ids` | `List of int` | Query, Optional | Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return. |

## Response Type

[`GetStaffSessionTypesResponse`](../../doc/models/get-staff-session-types-response.md)

## Example Usage

```python
version = '6'
request_staff_id = 180
site_id = '-99'

result = staff_controller.get_staff_session_types(version, request_staff_id, site_id)
```


# Get Staff

When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:

* FirstName
* LastName
* Id
* Bio
* DisplayName
* ImageUrl
* EmpID

```python
def get_staff(self,
             version,
             site_id,
             authorization=None,
             request_filters=None,
             request_limit=None,
             request_location_id=None,
             request_offset=None,
             request_session_type_id=None,
             request_staff_ids=None,
             request_start_date_time=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `request_filters` | `List of string` | Query, Optional | Filters to apply to the search. Possible values are:<br><br>* StaffViewable<br>* AppointmentInstructor<br>* ClassInstructor<br>* Male<br>* Female |
| `request_limit` | `int` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_id` | `int` | Query, Optional | Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter. |
| `request_offset` | `int` | Query, Optional | Page offset, defaults to 0. |
| `request_session_type_id` | `int` | Query, Optional | Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter. |
| `request_staff_ids` | `List of long\|int` | Query, Optional | A list of the requested staff IDs. |
| `request_start_date_time` | `datetime` | Query, Optional | Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter. |

## Response Type

[`GetStaffResponse`](../../doc/models/get-staff-response.md)

## Example Usage

```python
version = '6'
site_id = '-99'

result = staff_controller.get_staff(version, site_id)
```


# Get Staff Permissions

Get configured staff permissions for a staff member.

```python
def get_staff_permissions(self,
                         version,
                         request_staff_id,
                         site_id,
                         authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request_staff_id` | `long\|int` | Query, Required | The ID of the staff member whose permissions you want to return. |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetStaffPermissionsResponse`](../../doc/models/get-staff-permissions-response.md)

## Example Usage

```python
version = '6'
request_staff_id = 180
site_id = '-99'

result = staff_controller.get_staff_permissions(version, request_staff_id, site_id)
```


# Add Staff

Creates a new staff member record at the specified business. The `FirstName` and `LastName` parameters are always required for this request.

```python
def add_staff(self,
             version,
             request,
             site_id,
             authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddStaffRequest`](../../doc/models/add-staff-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AddStaffResponse`](../../doc/models/add-staff-response.md)

## Example Usage

```python
version = '6'
request = AddStaffRequest()
request.first_name = 'FirstName8'
request.last_name = 'LastName8'
site_id = '-99'

result = staff_controller.add_staff(version, request, site_id)
```


# Assign Staff Session Type

Assigns a staff member to an appointment session type with staff specific properties such as time length and pay rate. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```python
def assign_staff_session_type(self,
                             version,
                             request,
                             site_id,
                             authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AssignStaffSessionTypeRequest`](../../doc/models/assign-staff-session-type-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AssignStaffSessionTypeResponse`](../../doc/models/assign-staff-session-type-response.md)

## Example Usage

```python
version = '6'
request = AssignStaffSessionTypeRequest()
request.staff_id = 188
request.session_type_id = 82
request.active = False
site_id = '-99'

result = staff_controller.assign_staff_session_type(version, request, site_id)
```


# Add Staff Availability

Enables to add staff availability or unavailability for a given staff member.

```python
def add_staff_availability(self,
                          version,
                          request,
                          site_id,
                          authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddStaffAvailabilityRequest`](../../doc/models/add-staff-availability-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`void`

## Example Usage

```python
version = '6'
request = AddStaffAvailabilityRequest()
request.staff_id = 188
request.is_availability = False
request.days_of_week = ['DaysOfWeek7']
request.start_time = 'StartTime4'
request.end_time = 'EndTime0'
request.start_date = 'StartDate0'
request.end_date = 'EndDate6'
site_id = '-99'

result = staff_controller.add_staff_availability(version, request, site_id)
```


# Update Staff

Updates an existing staff member record at the specified business. The ID is a required parameters for this request.

```python
def update_staff(self,
                version,
                request,
                site_id,
                authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateStaffRequest`](../../doc/models/update-staff-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateStaffResponse`](../../doc/models/update-staff-response.md)

## Example Usage

```python
version = '6'
request = UpdateStaffRequest()
request.id = 142
site_id = '-99'

result = staff_controller.update_staff(version, request, site_id)
```


# Update Staff Permissions

Assigns a permission group to a staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```python
def update_staff_permissions(self,
                            version,
                            request,
                            site_id,
                            authorization=None)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateStaffPermissionsRequest`](../../doc/models/update-staff-permissions-request.md) | Body, Required | - |
| `site_id` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateStaffPermissionsResponse`](../../doc/models/update-staff-permissions-response.md)

## Example Usage

```python
version = '6'
request = UpdateStaffPermissionsRequest()
request.staff_id = 188
request.permission_group_name = 'PermissionGroupName8'
site_id = '-99'

result = staff_controller.update_staff_permissions(version, request, site_id)
```

