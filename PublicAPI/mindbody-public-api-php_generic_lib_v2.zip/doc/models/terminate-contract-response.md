
# Terminate Contract Response

## Structure

`TerminateContractResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `contract` | [`?ClientContract`](../../doc/models/client-contract.md) | Optional | A client contract | getContract(): ?ClientContract | setContract(?ClientContract contract): void |

## Example (as JSON)

```json
{
  "Contract": null
}
```

