
# Terminate Contract Response

## Structure

`TerminateContractResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `contract` | [`?ClientContract`](../../doc/models/client-contract.md) | Optional | Contains confirmation message for the successful contract termination. | getContract(): ?ClientContract | setContract(?ClientContract contract): void |

## Example (as JSON)

```json
{
  "Contract": null
}
```

