
# Written Class Schedules Info

## Structure

`WrittenClassSchedulesInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classId` | `?int` | Optional | The ClassScheduleId. | getClassId(): ?int | setClassId(?int classId): void |
| `classInstanceIds` | `?(int[])` | Optional | The individual ClassIds of the enrollment schedule. | getClassInstanceIds(): ?array | setClassInstanceIds(?array classInstanceIds): void |

## Example (as JSON)

```json
{
  "ClassId": 58,
  "ClassInstanceIds": [
    67,
    68
  ]
}
```

