
# Get Client Rewards Response

## Structure

`GetClientRewardsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `balance` | `?int` | Optional | The total rewards points available to the indicated client after the above transaction. | getBalance(): ?int | setBalance(?int balance): void |
| `transactions` | [`?(MindbodyPublicApiDtoModelsV6ClientRewardTransaction[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-reward-transaction.md) | Optional | Contains information about the reward transaction details. | getTransactions(): ?array | setTransactions(?array transactions): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Balance": null,
  "Transactions": null
}
```

