
# Mindbody Public Api Dto Models V6 Program Membership

## Structure

`MindbodyPublicApiDtoModelsV6ProgramMembership`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The service category’s ID. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of this service category. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

