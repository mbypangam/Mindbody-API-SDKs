
# Mindbody Public Api Dto Models V6 Site Controller Get Locations Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetLocationsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `locations` | [`?(MindbodyPublicApiDtoModelsV6Location[])`](../../doc/models/mindbody-public-api-dto-models-v6-location.md) | Optional | Contains information about the locations. | getLocations(): ?array | setLocations(?array locations): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Locations": null
}
```

