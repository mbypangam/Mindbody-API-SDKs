
# Purchase Account Credit Request

## Structure

`PurchaseAccountCreditRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `test` | `?bool` | Optional | When `true`, allows you to test the request without affecting the database.<br>When `false`, the request is carried out and the database is affected. | getTest(): ?bool | setTest(?bool test): void |
| `locationId` | `?int` | Optional | The ID of the location where the account credit is being sold. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `clientId` | `string` | Required | The ID of the location where the account credit is being sold. | getClientId(): string | setClientId(string clientId): void |
| `sendEmailReceipt` | `?bool` | Optional | When `true`, indicates that a purchase receipt email should be sent to the purchasing client, if all settings are correctly configured.<br /><br>When `false`, no email is sent to the purchaser. | getSendEmailReceipt(): ?bool | setSendEmailReceipt(?bool sendEmailReceipt): void |
| `salesRepId` | `?int` | Optional | The ID of the staff member to be marked as the sales rep for this account credit sale. | getSalesRepId(): ?int | setSalesRepId(?int salesRepId): void |
| `consumerPresent` | `?bool` | Optional | When `true`, indicates that the consumer is present or otherwise able to successfully negotiate an SCA challenge.<br>It is not a good idea to have this always be false as that could very likely lead to a bank declining all transactions for the merchant. Defaults to false.<br>Default: **false** | getConsumerPresent(): ?bool | setConsumerPresent(?bool consumerPresent): void |
| `paymentAuthenticationCallbackUrl` | `?string` | Optional | The URL consumer is redirected to if the bank requests SCA. This field is only needed if ConsumerPresent is true. | getPaymentAuthenticationCallbackUrl(): ?string | setPaymentAuthenticationCallbackUrl(?string paymentAuthenticationCallbackUrl): void |
| `paymentInfo` | [`?MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-checkout-request-payments-checkout-payment-info.md) | Optional | Contains information about the payment. | getPaymentInfo(): ?MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo | setPaymentInfo(?MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo paymentInfo): void |

## Example (as JSON)

```json
{
  "Test": null,
  "LocationId": null,
  "ClientId": "ClientId6",
  "SendEmailReceipt": null,
  "SalesRepId": null,
  "ConsumerPresent": null,
  "PaymentAuthenticationCallbackUrl": null,
  "PaymentInfo": null
}
```

