
# Type 1 Enum

## Enumeration

`Type1Enum`

## Fields

| Name |
|  --- |
| `ALL` |
| `DROPIN` |
| `ENROLLMENT` |
| `APPOINTMENT` |
| `RESOURCE` |
| `MEDIA` |
| `ARRIVAL` |

