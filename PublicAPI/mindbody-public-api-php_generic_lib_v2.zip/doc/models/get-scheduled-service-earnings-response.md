
# Get Scheduled Service Earnings Response

## Structure

`GetScheduledServiceEarningsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `scheduledServiceEarnings` | [`?(ScheduledServiceEarningsEvent[])`](../../doc/models/scheduled-service-earnings-event.md) | Optional | Contains the class payroll events. | getScheduledServiceEarnings(): ?array | setScheduledServiceEarnings(?array scheduledServiceEarnings): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ScheduledServiceEarnings": null
}
```

