
# Get Scheduled Service Earnings Response

## Structure

`GetScheduledServiceEarningsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `scheduledServiceEarnings` | [`?(ScheduledServiceEarningsEvent[])`](../../doc/models/scheduled-service-earnings-event.md) | Optional | Contains the class payroll events. | getScheduledServiceEarnings(): ?array | setScheduledServiceEarnings(?array scheduledServiceEarnings): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "ScheduledServiceEarnings": [
    {
      "StaffId": 166,
      "ScheduledServiceId": 250,
      "ScheduledServiceType": "Enrollment",
      "Earnings": 69.78,
      "DateTime": "2016-03-13T12:52:32.123Z"
    },
    {
      "StaffId": 166,
      "ScheduledServiceId": 250,
      "ScheduledServiceType": "Enrollment",
      "Earnings": 69.78,
      "DateTime": "2016-03-13T12:52:32.123Z"
    },
    {
      "StaffId": 166,
      "ScheduledServiceId": 250,
      "ScheduledServiceType": "Enrollment",
      "Earnings": 69.78,
      "DateTime": "2016-03-13T12:52:32.123Z"
    }
  ]
}
```

