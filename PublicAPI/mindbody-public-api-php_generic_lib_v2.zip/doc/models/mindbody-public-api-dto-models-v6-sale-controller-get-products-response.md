
# Mindbody Public Api Dto Models V6 Sale Controller Get Products Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `products` | [`?(MindbodyPublicApiDtoModelsV6Product[])`](../../doc/models/mindbody-public-api-dto-models-v6-product.md) | Optional | Contains information about the products. | getProducts(): ?array | setProducts(?array products): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Products": null
}
```

