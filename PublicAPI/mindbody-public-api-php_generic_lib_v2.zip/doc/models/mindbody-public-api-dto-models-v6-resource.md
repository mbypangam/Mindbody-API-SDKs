
# Mindbody Public Api Dto Models V6 Resource

Contains information about resources, such as rooms.

## Structure

`MindbodyPublicApiDtoModelsV6Resource`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the resource. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the resource. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

