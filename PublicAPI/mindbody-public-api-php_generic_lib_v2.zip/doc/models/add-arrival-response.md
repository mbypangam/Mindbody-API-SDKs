
# Add Arrival Response

## Structure

`AddArrivalResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `arrivalAdded` | `?bool` | Optional | When `true`, indicates that the arrival was added to the database. | getArrivalAdded(): ?bool | setArrivalAdded(?bool arrivalAdded): void |
| `clientService` | [`?ClientService`](../../doc/models/client-service.md) | Optional | A service that is on a client's account. | getClientService(): ?ClientService | setClientService(?ClientService clientService): void |

## Example (as JSON)

```json
{
  "ArrivalAdded": null,
  "ClientService": null
}
```

