
# Update Client Rewards Response

## Structure

`UpdateClientRewardsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `transaction` | [`?ClientRewardTransaction`](../../doc/models/client-reward-transaction.md) | Optional | The Transaction that was performed against the client rewards | getTransaction(): ?ClientRewardTransaction | setTransaction(?ClientRewardTransaction transaction): void |
| `balance` | `?int` | Optional | The client's reward Balance, after the transaction | getBalance(): ?int | setBalance(?int balance): void |

## Example (as JSON)

```json
{
  "Transaction": null,
  "Balance": null
}
```

