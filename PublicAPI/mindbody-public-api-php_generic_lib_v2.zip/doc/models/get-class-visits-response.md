
# Get Class Visits Response

## Structure

`GetClassVisitsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `class` | [`?MClass`](../../doc/models/m-class.md) | Optional | Contains class and booking information. | getClass(): ?MClass | setClass(?MClass class): void |

## Example (as JSON)

```json
{
  "Class": null
}
```

