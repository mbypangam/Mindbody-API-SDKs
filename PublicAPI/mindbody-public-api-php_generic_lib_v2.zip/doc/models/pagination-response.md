
# Pagination Response

Contains information about the pagination to use.

## Structure

`PaginationResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `requestedLimit` | `?int` | Optional | Limit from pagination request | getRequestedLimit(): ?int | setRequestedLimit(?int requestedLimit): void |
| `requestedOffset` | `?int` | Optional | Offset from pagination request | getRequestedOffset(): ?int | setRequestedOffset(?int requestedOffset): void |
| `pageSize` | `?int` | Optional | Number of results returned in this response | getPageSize(): ?int | setPageSize(?int pageSize): void |
| `totalResults` | `?int` | Optional | Total number of results in dataset | getTotalResults(): ?int | setTotalResults(?int totalResults): void |

## Example (as JSON)

```json
{
  "RequestedLimit": 22,
  "RequestedOffset": 0,
  "PageSize": 172,
  "TotalResults": 112
}
```

