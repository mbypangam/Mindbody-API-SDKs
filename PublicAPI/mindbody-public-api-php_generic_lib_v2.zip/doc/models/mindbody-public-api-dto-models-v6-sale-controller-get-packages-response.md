
# Mindbody Public Api Dto Models V6 Sale Controller Get Packages Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `packages` | [`?(MindbodyPublicApiDtoModelsV6Package[])`](../../doc/models/mindbody-public-api-dto-models-v6-package.md) | Optional | Contains information about the resulting packages. | getPackages(): ?array | setPackages(?array packages): void |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |

## Example (as JSON)

```json
{
  "Packages": null,
  "PaginationResponse": null
}
```

