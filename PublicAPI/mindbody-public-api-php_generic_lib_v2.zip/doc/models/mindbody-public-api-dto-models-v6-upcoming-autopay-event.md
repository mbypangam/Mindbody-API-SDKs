
# Mindbody Public Api Dto Models V6 Upcoming Autopay Event

## Structure

`MindbodyPublicApiDtoModelsV6UpcomingAutopayEvent`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientContractId` | `?int` | Optional | The ID of the contract. | getClientContractId(): ?int | setClientContractId(?int clientContractId): void |
| `chargeAmount` | `?float` | Optional | The amount charged. | getChargeAmount(): ?float | setChargeAmount(?float chargeAmount): void |
| `paymentMethod` | [`?string (PaymentMethodEnum)`](../../doc/models/payment-method-enum.md) | Optional | The payment method. | getPaymentMethod(): ?string | setPaymentMethod(?string paymentMethod): void |
| `scheduleDate` | `?\DateTime` | Optional | The date and time of the next payment. | getScheduleDate(): ?\DateTime | setScheduleDate(?\DateTime scheduleDate): void |

## Example (as JSON)

```json
{
  "ClientContractId": null,
  "ChargeAmount": null,
  "PaymentMethod": null,
  "ScheduleDate": null
}
```

