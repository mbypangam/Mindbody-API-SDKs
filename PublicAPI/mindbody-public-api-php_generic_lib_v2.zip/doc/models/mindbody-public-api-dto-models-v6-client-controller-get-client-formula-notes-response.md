
# Mindbody Public Api Dto Models V6 Client Controller Get Client Formula Notes Response

Enables to retrieve cross regional formula notes for a client, or for a specific appointment. The two parameters are optional, however at least one must be provided. This endpoint supports pagination.

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `formulaNotes` | [`?(MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-formula-note-response.md) | Optional | Contains details about the client’s formula. | getFormulaNotes(): ?array | setFormulaNotes(?array formulaNotes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "FormulaNotes": null
}
```

