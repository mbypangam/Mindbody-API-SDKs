
# Add Site Client Index Request

## Structure

`AddSiteClientIndexRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientIndexName` | `string` | Required | The name of the client index. | getClientIndexName(): string | setClientIndexName(string clientIndexName): void |
| `active` | `?bool` | Optional | Indicates if Client Index is Active | getActive(): ?bool | setActive(?bool active): void |
| `showOnNewClient` | `?bool` | Optional | Indicates if Client Index is shown on a new client profile | getShowOnNewClient(): ?bool | setShowOnNewClient(?bool showOnNewClient): void |
| `showOnEnrollmentRoster` | `?bool` | Optional | Indicates if Client Index is shown on Enrollement Roster | getShowOnEnrollmentRoster(): ?bool | setShowOnEnrollmentRoster(?bool showOnEnrollmentRoster): void |
| `editOnEnrollmentRoster` | `?bool` | Optional | Indicates if Client Index can be edited on Enrollement Roster | getEditOnEnrollmentRoster(): ?bool | setEditOnEnrollmentRoster(?bool editOnEnrollmentRoster): void |
| `sortOrder` | `?int` | Optional | Indicates sort order | getSortOrder(): ?int | setSortOrder(?int sortOrder): void |
| `showInConsumerMode` | `?bool` | Optional | Indicates if Client Index is shown in consumer mode. | getShowInConsumerMode(): ?bool | setShowInConsumerMode(?bool showInConsumerMode): void |
| `requiredConsumerMode` | `?bool` | Optional | Indicates if the index is required when creating profiles in consumer mode. | getRequiredConsumerMode(): ?bool | setRequiredConsumerMode(?bool requiredConsumerMode): void |
| `requiredBizMode` | `?bool` | Optional | Indicates if the index is required when creating profiles in business mode. | getRequiredBizMode(): ?bool | setRequiredBizMode(?bool requiredBizMode): void |

## Example (as JSON)

```json
{
  "ClientIndexName": "ClientIndexName4",
  "Active": false,
  "ShowOnNewClient": false,
  "ShowOnEnrollmentRoster": false,
  "EditOnEnrollmentRoster": false,
  "SortOrder": 18
}
```

