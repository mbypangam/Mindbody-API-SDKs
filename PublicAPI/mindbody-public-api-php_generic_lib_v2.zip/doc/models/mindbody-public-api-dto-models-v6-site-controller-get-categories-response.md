
# Mindbody Public Api Dto Models V6 Site Controller Get Categories Response

Get Categories Response Model

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetCategoriesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `categories` | [`?(MindbodyPublicApiCommonModelsCategory[])`](../../doc/models/mindbody-public-api-common-models-category.md) | Optional | Contains the Category objects, each of which describes the categories for a site. | getCategories(): ?array | setCategories(?array categories): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Categories": null
}
```

