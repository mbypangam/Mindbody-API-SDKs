
# Get Staff Appointments Response

## Structure

`GetStaffAppointmentsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `appointments` | [`?(Appointment[])`](../../doc/models/appointment.md) | Optional | Contains information about appointments and their details. | getAppointments(): ?array | setAppointments(?array appointments): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Appointments": null
}
```

