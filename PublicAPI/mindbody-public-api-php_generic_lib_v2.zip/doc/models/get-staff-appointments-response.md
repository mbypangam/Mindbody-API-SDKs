
# Get Staff Appointments Response

Get Staff Appointments Response Model

## Structure

`GetStaffAppointmentsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `appointments` | [`?(Appointment[])`](../../doc/models/appointment.md) | Optional | Contains information about appointments and their details. | getAppointments(): ?array | setAppointments(?array appointments): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Appointments": [
    {
      "GenderPreference": "Male",
      "Duration": 190,
      "ProviderId": "ProviderId6",
      "Id": 144,
      "Status": "LateCancelled"
    },
    {
      "GenderPreference": "None",
      "Duration": 191,
      "ProviderId": "ProviderId7",
      "Id": 145,
      "Status": "None"
    }
  ]
}
```

