
# Update Staff Response

## Structure

`UpdateStaffResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staff` | [`?Staff`](../../doc/models/staff.md) | Optional | The Staff | getStaff(): ?Staff | setStaff(?Staff staff): void |

## Example (as JSON)

```json
{
  "Staff": null
}
```

