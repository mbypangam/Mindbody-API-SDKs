
# Get Semesters Response

Get Semesters Response Model

## Structure

`GetSemestersResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `semesters` | [`?(Semester[])`](../../doc/models/semester.md) | Optional | Contains the Semester objects, each of which describes the semesters for a site. | getSemesters(): ?array | setSemesters(?array semesters): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Semesters": null
}
```

