
# Mindbody Public Api Dto Models V6 Appointment Controller Get Add Ons Response

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `addOns` | [`?(MindbodyPublicApiDtoModelsV6AppointmentAddOn[])`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-add-on.md) | Optional | A list of available add-ons. | getAddOns(): ?array | setAddOns(?array addOns): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "AddOns": null
}
```

