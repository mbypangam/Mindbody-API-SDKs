
# Mindbody Public Api Dto Models V6 Sale Controller Purchase Gift Card Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `barcodeId` | `?string` | Optional | The barcode ID assigned to the purchased gift card. | getBarcodeId(): ?string | setBarcodeId(?string barcodeId): void |
| `value` | `?float` | Optional | The monetary value of the gift card. | getValue(): ?float | setValue(?float value): void |
| `amountPaid` | `?float` | Optional | The amount paid for the gift card by the purchaser. | getAmountPaid(): ?float | setAmountPaid(?float amountPaid): void |
| `fromName` | `?string` | Optional | The name of the purchaser. | getFromName(): ?string | setFromName(?string fromName): void |
| `layoutId` | `?int` | Optional | The ID of the layout used for this gift card. | getLayoutId(): ?int | setLayoutId(?int layoutId): void |
| `emailReceipt` | `?bool` | Optional | Whether or not an email receipt was sent to the purchaser. If true, a receipt was sent. | getEmailReceipt(): ?bool | setEmailReceipt(?bool emailReceipt): void |
| `purchaserClientId` | `?string` | Optional | The client ID of the purchaser. | getPurchaserClientId(): ?string | setPurchaserClientId(?string purchaserClientId): void |
| `purchaserEmail` | `?string` | Optional | The purchaser’s email address. | getPurchaserEmail(): ?string | setPurchaserEmail(?string purchaserEmail): void |
| `recipientEmail` | `?string` | Optional | The recipient’s email address. | getRecipientEmail(): ?string | setRecipientEmail(?string recipientEmail): void |
| `saleId` | `?int` | Optional | The sale ID of the gift card. | getSaleId(): ?int | setSaleId(?int saleId): void |
| `paymentProcessingFailures` | [`?(MindbodyPublicApiDtoModelsV6SaleControllerPaymentProcessingFailure[])`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-payment-processing-failure.md) | Optional | Any cart processing failures, for example when SCA challenged, the cart is in PaymentAuthenticationRequired state and at least one of the failures listed will provide an authentication Url. | getPaymentProcessingFailures(): ?array | setPaymentProcessingFailures(?array paymentProcessingFailures): void |

## Example (as JSON)

```json
{
  "BarcodeId": null,
  "Value": null,
  "AmountPaid": null,
  "FromName": null,
  "LayoutId": null,
  "EmailReceipt": null,
  "PurchaserClientId": null,
  "PurchaserEmail": null,
  "RecipientEmail": null,
  "SaleId": null,
  "PaymentProcessingFailures": null
}
```

