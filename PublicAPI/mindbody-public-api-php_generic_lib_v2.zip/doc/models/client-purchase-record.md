
# Client Purchase Record

A record of a specific client purchase

## Structure

`ClientPurchaseRecord`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sale` | [`?Sale`](../../doc/models/sale.md) | Optional | Contains the Sale details. | getSale(): ?Sale | setSale(?Sale sale): void |
| `description` | `?string` | Optional | The item name and description. | getDescription(): ?string | setDescription(?string description): void |
| `accountPayment` | `?bool` | Optional | If `true`, the item was a payment credited to an account. | getAccountPayment(): ?bool | setAccountPayment(?bool accountPayment): void |
| `price` | `?float` | Optional | The price paid for the item. | getPrice(): ?float | setPrice(?float price): void |
| `amountPaid` | `?float` | Optional | The amount paid for the item. | getAmountPaid(): ?float | setAmountPaid(?float amountPaid): void |
| `discount` | `?float` | Optional | The discount amount that was applied to the item. | getDiscount(): ?float | setDiscount(?float discount): void |
| `tax` | `?float` | Optional | The amount of tax that was applied to the item. | getTax(): ?float | setTax(?float tax): void |
| `returned` | `?bool` | Optional | The return status of the item. If `true`, this item was returned. | getReturned(): ?bool | setReturned(?bool returned): void |
| `quantity` | `?int` | Optional | The quantity of the item purchased. | getQuantity(): ?int | setQuantity(?int quantity): void |

## Example (as JSON)

```json
{
  "Sale": {
    "Id": 174,
    "SaleDate": "2016-03-13T12:52:32.123Z",
    "SaleTime": "SaleTime0",
    "SaleDateTime": "2016-03-13T12:52:32.123Z",
    "OriginalSaleDateTime": "2016-03-13T12:52:32.123Z"
  },
  "Description": "Description6",
  "AccountPayment": false,
  "Price": 138.2,
  "AmountPaid": 162.76
}
```

