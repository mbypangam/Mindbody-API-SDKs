
# Mindbody Public Api Dto Models V6 Cross Regional Client Association

A client cross region association

## Structure

`MindbodyPublicApiDtoModelsV6CrossRegionalClientAssociation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `siteId` | `?int` | Optional | The ID of the site to which the client belongs. | getSiteId(): ?int | setSiteId(?int siteId): void |
| `clientId` | `?string` | Optional | The client's RSSID. | getClientId(): ?string | setClientId(?string clientId): void |
| `uniqueId` | `?int` | Optional | The client's unique ID. | getUniqueId(): ?int | setUniqueId(?int uniqueId): void |

## Example (as JSON)

```json
{
  "SiteId": null,
  "ClientId": null,
  "UniqueId": null
}
```

