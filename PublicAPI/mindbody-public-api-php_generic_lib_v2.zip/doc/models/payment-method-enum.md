
# Payment Method Enum

The payment method.

## Enumeration

`PaymentMethodEnum`

## Fields

| Name |
|  --- |
| `OTHER` |
| `CREDITCARD` |
| `DEBITACCOUNT` |
| `ACH` |

