
# Get Client Complete Info Response

Contains information about the requested client.

## Structure

`GetClientCompleteInfoResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `client` | [`?ClientWithSuspensionInfo`](../../doc/models/client-with-suspension-info.md) | Optional | Contains information about the requested client. | getClient(): ?ClientWithSuspensionInfo | setClient(?ClientWithSuspensionInfo client): void |
| `clientServices` | [`?(ClientService[])`](../../doc/models/client-service.md) | Optional | Contains information about client pricing options. | getClientServices(): ?array | setClientServices(?array clientServices): void |
| `clientContracts` | [`?(ClientContract[])`](../../doc/models/client-contract.md) | Optional | Contains information about client contract. | getClientContracts(): ?array | setClientContracts(?array clientContracts): void |
| `clientMemberships` | [`?(ClientMembership[])`](../../doc/models/client-membership.md) | Optional | Contains information about client Memberships. | getClientMemberships(): ?array | setClientMemberships(?array clientMemberships): void |
| `clientArrivals` | [`?(ClientArrival[])`](../../doc/models/client-arrival.md) | Optional | Contains information about client arrival services. | getClientArrivals(): ?array | setClientArrivals(?array clientArrivals): void |

## Example (as JSON)

```json
{
  "Client": null,
  "ClientServices": null,
  "ClientContracts": null,
  "ClientMemberships": null,
  "ClientArrivals": null
}
```

