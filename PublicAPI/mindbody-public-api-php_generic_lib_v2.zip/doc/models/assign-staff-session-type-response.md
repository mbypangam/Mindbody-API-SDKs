
# Assign Staff Session Type Response

## Structure

`AssignStaffSessionTypeResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `?int` | Optional | Staff member assigned to the session type | getStaffId(): ?int | setStaffId(?int staffId): void |
| `sessionTypeId` | `?int` | Optional | The session type the staff member is assigned to | getSessionTypeId(): ?int | setSessionTypeId(?int sessionTypeId): void |
| `payRateType` | `?string` | Optional | The pay rate type name<br>Can be: "Flat", "Percent", or "No Pay" | getPayRateType(): ?string | setPayRateType(?string payRateType): void |
| `payRateAmount` | `?float` | Optional | The pay rate amount. It is interpreted based on the value of PayRateTypeId | getPayRateAmount(): ?float | setPayRateAmount(?float payRateAmount): void |
| `timeLength` | `?int` | Optional | The staff specific amount of time that a session of this type typically lasts. | getTimeLength(): ?int | setTimeLength(?int timeLength): void |
| `prepTime` | `?int` | Optional | Prep time in minutes | getPrepTime(): ?int | setPrepTime(?int prepTime): void |
| `finishTime` | `?int` | Optional | Finish time in minutes | getFinishTime(): ?int | setFinishTime(?int finishTime): void |
| `active` | `?bool` | Optional | Whether this association is active | getActive(): ?bool | setActive(?bool active): void |

## Example (as JSON)

```json
{
  "StaffId": 148,
  "SessionTypeId": 42,
  "PayRateType": "PayRateType0",
  "PayRateAmount": 87.3,
  "TimeLength": 182
}
```

