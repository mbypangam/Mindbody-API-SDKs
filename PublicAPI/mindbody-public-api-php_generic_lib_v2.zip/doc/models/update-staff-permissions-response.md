
# Update Staff Permissions Response

## Structure

`UpdateStaffPermissionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `userGroup` | [`?StaffPermissionGroup`](../../doc/models/staff-permission-group.md) | Optional | Contains information about the staff member’s permission group. | getUserGroup(): ?StaffPermissionGroup | setUserGroup(?StaffPermissionGroup userGroup): void |

## Example (as JSON)

```json
{
  "UserGroup": null
}
```

