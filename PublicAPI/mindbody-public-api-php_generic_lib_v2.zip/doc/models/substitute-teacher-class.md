
# Substitute Teacher Class

Represents a single class instance. Used in SubstituteClassTeacher endpoint.

## Structure

`SubstituteTeacherClass`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classScheduleId` | `?int` | Optional | The class schedule ID of the requested class. | getClassScheduleId(): ?int | setClassScheduleId(?int classScheduleId): void |
| `location` | [`?Location`](../../doc/models/location.md) | Optional | - | getLocation(): ?Location | setLocation(?Location location): void |
| `maxCapacity` | `?int` | Optional | The total number of bookings allowed in the class. | getMaxCapacity(): ?int | setMaxCapacity(?int maxCapacity): void |
| `webCapacity` | `?int` | Optional | The total number of online bookings allowed in the class. | getWebCapacity(): ?int | setWebCapacity(?int webCapacity): void |
| `totalBooked` | `?int` | Optional | The total number of clients who are booked into the class prior to this call being made. | getTotalBooked(): ?int | setTotalBooked(?int totalBooked): void |
| `totalBookedWaitlist` | `?int` | Optional | The total number of booked clients who are on the waiting list for the class prior to this call being made. | getTotalBookedWaitlist(): ?int | setTotalBookedWaitlist(?int totalBookedWaitlist): void |
| `webBooked` | `?int` | Optional | The total number of bookings in the class made by online users, prior to this call being made. This property is the current number of bookings counted toward the `WebCapacity` limit. | getWebBooked(): ?int | setWebBooked(?int webBooked): void |
| `semesterId` | `?int` | Optional | Identifies the semester assigned to this class. | getSemesterId(): ?int | setSemesterId(?int semesterId): void |
| `isCanceled` | `?bool` | Optional | When `true`, indicates that the class has been canceled.<br /><br>When `false`, indicates that the class has not been canceled and may still be bookable. | getIsCanceled(): ?bool | setIsCanceled(?bool isCanceled): void |
| `substitute` | `?bool` | Optional | When `true`, indicates that the class is being taught by a substitute teacher. | getSubstitute(): ?bool | setSubstitute(?bool substitute): void |
| `active` | `?bool` | Optional | When `true`, indicates that the class is being shown to clients in consumer mode. | getActive(): ?bool | setActive(?bool active): void |
| `isWaitlistAvailable` | `?bool` | Optional | When `true`, indicates that the class has a waiting list and there is space available on the waiting list for another client.<br /><br>When `false`, indicates either that the class does not have a waiting list or there is no space available on the class waiting list. | getIsWaitlistAvailable(): ?bool | setIsWaitlistAvailable(?bool isWaitlistAvailable): void |
| `hideCancel` | `?bool` | Optional | When `true`, indicates that this class is should not be shown to clients when `IsCancelled` is `true`.<br /><br>When `false`, indicates that this class is should be shown to clients when `IsCancelled` is `true`.<br /><br>This property can be ignored when the `IsCancelled` property is `false`. | getHideCancel(): ?bool | setHideCancel(?bool hideCancel): void |
| `id` | `?int` | Optional | The unique identifier of the class. | getId(): ?int | setId(?int id): void |
| `isAvailable` | `?bool` | Optional | When `true`, indicates that the class can be booked.<br /><br>When `false`, that the class cannot be booked at this time. | getIsAvailable(): ?bool | setIsAvailable(?bool isAvailable): void |
| `startDateTime` | `?DateTime` | Optional | The date and time that this class is scheduled to start. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?DateTime` | Optional | The date and time when this class is scheduled to end. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `lastModifiedDateTime` | `?DateTime` | Optional | The last time the class was modified. | getLastModifiedDateTime(): ?\DateTime | setLastModifiedDateTime(?\DateTime lastModifiedDateTime): void |
| `classDescription` | [`?ClassDescription`](../../doc/models/class-description.md) | Optional | Represents a class definition. The class meets at the start time, goes until the end time. | getClassDescription(): ?ClassDescription | setClassDescription(?ClassDescription classDescription): void |
| `staff` | [`?Staff`](../../doc/models/staff.md) | Optional | The Staff | getStaff(): ?Staff | setStaff(?Staff staff): void |
| `virtualStreamLink` | `?string` | Optional | The URL for the pre-recorded live stream for the class if hosted on the mindbody virtual wellness platform | getVirtualStreamLink(): ?string | setVirtualStreamLink(?string virtualStreamLink): void |

## Example (as JSON)

```json
{
  "ClassScheduleId": 4,
  "Location": {
    "AdditionalImageURLs": [
      "AdditionalImageURLs4"
    ],
    "Address": "Address2",
    "Address2": "Address24",
    "Amenities": [
      {
        "Id": 200,
        "Name": "Name2"
      },
      {
        "Id": 201,
        "Name": "Name3"
      },
      {
        "Id": 202,
        "Name": "Name4"
      }
    ],
    "BusinessDescription": "BusinessDescription8"
  },
  "MaxCapacity": 178,
  "WebCapacity": 224,
  "TotalBooked": 100
}
```

