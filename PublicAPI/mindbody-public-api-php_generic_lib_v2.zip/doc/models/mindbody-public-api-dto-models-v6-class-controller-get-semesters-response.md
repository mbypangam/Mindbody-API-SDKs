
# Mindbody Public Api Dto Models V6 Class Controller Get Semesters Response

Get Semesters Response Model

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetSemestersResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `semesters` | [`?(MindbodyPublicApiDtoModelsV6Semester[])`](../../doc/models/mindbody-public-api-dto-models-v6-semester.md) | Optional | A list of Semesters. | getSemesters(): ?array | setSemesters(?array semesters): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Semesters": null
}
```

