
# Update Appointment Request

## Structure

`UpdateAppointmentRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appointmentId` | `int` | Required | A unique ID for the appointment. | getAppointmentId(): int | setAppointmentId(int appointmentId): void |
| `endDateTime` | `?DateTime` | Optional | The end date and time of the new appointment.<br><br />Default: **StartDateTime**, offset by the staff member’s default appointment duration. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `execute` | `?string` | Optional | The action taken to add this appointment. | getExecute(): ?string | setExecute(?string execute): void |
| `genderPreference` | `?string` | Optional | The client’s service provider gender preference. | getGenderPreference(): ?string | setGenderPreference(?string genderPreference): void |
| `notes` | `?string` | Optional | Any general notes about this appointment. | getNotes(): ?string | setNotes(?string notes): void |
| `partnerExternalId` | `?string` | Optional | Optional external key for api partners. | getPartnerExternalId(): ?string | setPartnerExternalId(?string partnerExternalId): void |
| `providerId` | `?string` | Optional | If a user has Complementary and Alternative Medicine features enabled, this parameter assigns a provider ID to the appointment. | getProviderId(): ?string | setProviderId(?string providerId): void |
| `resourceIds` | `?(int[])` | Optional | A list of resource IDs to associate with the new appointment. | getResourceIds(): ?array | setResourceIds(?array resourceIds): void |
| `sendEmail` | `?bool` | Optional | Whether to send client an email for cancellations. An email is sent only if the client has an email address and automatic emails have been set up.<br><br />Default: **false** | getSendEmail(): ?bool | setSendEmail(?bool sendEmail): void |
| `sessionTypeId` | `?int` | Optional | The session type associated with the new appointment. | getSessionTypeId(): ?int | setSessionTypeId(?int sessionTypeId): void |
| `staffId` | `?int` | Optional | The ID of the staff member who is adding the new appointment. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `startDateTime` | `?DateTime` | Optional | The start date and time of the new appointment. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `test` | `?bool` | Optional | When `true`, indicates that the method is to be validated, but no new appointment data is added.<br><br />Default: **false** | getTest(): ?bool | setTest(?bool test): void |

## Example (as JSON)

```json
{
  "AppointmentId": 22,
  "EndDateTime": "2016-03-13T12:52:32.123Z",
  "Execute": "Execute4",
  "GenderPreference": "GenderPreference0",
  "Notes": "Notes8",
  "PartnerExternalId": "PartnerExternalId6"
}
```

