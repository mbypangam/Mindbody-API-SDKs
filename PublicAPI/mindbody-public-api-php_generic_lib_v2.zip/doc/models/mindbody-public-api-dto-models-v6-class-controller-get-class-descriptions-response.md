
# Mindbody Public Api Dto Models V6 Class Controller Get Class Descriptions Response

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetClassDescriptionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `classDescriptions` | [`?(MindbodyPublicApiDtoModelsV6ClassDescription[])`](../../doc/models/mindbody-public-api-dto-models-v6-class-description.md) | Optional | Contains information about the class descriptions. | getClassDescriptions(): ?array | setClassDescriptions(?array classDescriptions): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClassDescriptions": null
}
```

