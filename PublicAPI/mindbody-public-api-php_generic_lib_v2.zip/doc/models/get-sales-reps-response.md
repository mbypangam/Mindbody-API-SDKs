
# Get Sales Reps Response

This is the response class for the get sales reps API

## Structure

`GetSalesRepsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `salesReps` | [`?(SalesRepResponse[])`](../../doc/models/sales-rep-response.md) | Optional | This the list of sales reps and their details | getSalesReps(): ?array | setSalesReps(?array salesReps): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "SalesReps": null
}
```

