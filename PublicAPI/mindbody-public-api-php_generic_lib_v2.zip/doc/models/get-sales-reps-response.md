
# Get Sales Reps Response

This is the response class for the get sales reps API

## Structure

`GetSalesRepsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `salesReps` | [`?(SalesRepResponse[])`](../../doc/models/sales-rep-response.md) | Optional | This the list of sales reps and their details | getSalesReps(): ?array | setSalesReps(?array salesReps): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "SalesReps": [
    {
      "Id": 39,
      "FirstName": "FirstName1",
      "LastName": "LastName1",
      "SalesRepNumbers": [
        219,
        220,
        221
      ]
    }
  ]
}
```

