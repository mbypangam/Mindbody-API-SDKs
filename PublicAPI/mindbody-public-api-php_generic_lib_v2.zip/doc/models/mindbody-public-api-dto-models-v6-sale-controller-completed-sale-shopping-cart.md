
# Mindbody Public Api Dto Models V6 Sale Controller Completed Sale Shopping Cart

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleShoppingCart`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | The shopping cart ID. | getId(): ?string | setId(?string id): void |
| `cartItems` | [`?(MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleCartItem[])`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-completed-sale-cart-item.md) | Optional | Contains information about the items in the shopping cart. | getCartItems(): ?array | setCartItems(?array cartItems): void |
| `subTotal` | `?float` | Optional | The cart’s total cost before taxes and discounts were applied. | getSubTotal(): ?float | setSubTotal(?float subTotal): void |
| `discountTotal` | `?float` | Optional | The monetary amount removed from the cart’s total cost by applied discounts. | getDiscountTotal(): ?float | setDiscountTotal(?float discountTotal): void |
| `taxTotal` | `?float` | Optional | The monetary amount paid in taxes, included in the cart’s `GrandTotal`. | getTaxTotal(): ?float | setTaxTotal(?float taxTotal): void |
| `grandTotal` | `?float` | Optional | The cart’s total cost, including taxes and discounts. | getGrandTotal(): ?float | setGrandTotal(?float grandTotal): void |
| `transactions` | [`?(TransactionResponse[])`](../../doc/models/transaction-response.md) | Optional | Contains information returned from the first call to CheckoutShoppingCart. | getTransactions(): ?array | setTransactions(?array transactions): void |

## Example (as JSON)

```json
{
  "Id": null,
  "CartItems": null,
  "SubTotal": null,
  "DiscountTotal": null,
  "TaxTotal": null,
  "GrandTotal": null,
  "Transactions": null
}
```

