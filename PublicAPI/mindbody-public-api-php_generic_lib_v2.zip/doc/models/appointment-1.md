
# Appointment 1

An appointment

## Structure

`Appointment1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `genderPreference` | `?string` | Optional | Prefered gender of appointment. | getGenderPreference(): ?string | setGenderPreference(?string genderPreference): void |
| `duration` | `?int` | Optional | Duration of appointment. | getDuration(): ?int | setDuration(?int duration): void |
| `providerId` | `?string` | Optional | If a user has Complementary and Alternative Medicine features enabled,<br>this will allow a Provider ID to be assigned to an appointment. | getProviderId(): ?string | setProviderId(?string providerId): void |
| `id` | `?int` | Optional | The unique ID of the appointment. | getId(): ?int | setId(?int id): void |
| `status` | [`?string(Status1Enum)`](../../doc/models/status-1-enum.md) | Optional | The status of this appointment. | getStatus(): ?string | setStatus(?string status): void |
| `startDateTime` | `?DateTime` | Optional | The date and time the appointment will start. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?DateTime` | Optional | The date and time the appointment will end. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `notes` | `?string` | Optional | The appointment notes. | getNotes(): ?string | setNotes(?string notes): void |
| `partnerExternalId` | `?string` | Optional | Optional external key for api partners. | getPartnerExternalId(): ?string | setPartnerExternalId(?string partnerExternalId): void |
| `staffRequested` | `?bool` | Optional | Whether the staff member was requested specifically by the client. | getStaffRequested(): ?bool | setStaffRequested(?bool staffRequested): void |
| `programId` | `?int` | Optional | The ID of the program this appointment belongs to. | getProgramId(): ?int | setProgramId(?int programId): void |
| `waitlistEntryId` | `?int` | Optional | The ID of the appointment waitlist. | getWaitlistEntryId(): ?int | setWaitlistEntryId(?int waitlistEntryId): void |
| `sessionTypeId` | `?int` | Optional | The ID of the session type of this appointment. | getSessionTypeId(): ?int | setSessionTypeId(?int sessionTypeId): void |
| `locationId` | `?int` | Optional | The ID of the location where this appointment will take place. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `staffId` | `?int` | Optional | The ID of the staff member instructing this appointment. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `clientId` | `?string` | Optional | The RSSID of the client booked for this appointment. | getClientId(): ?string | setClientId(?string clientId): void |
| `firstAppointment` | `?bool` | Optional | Whether this is the client's first appointment at the site. | getFirstAppointment(): ?bool | setFirstAppointment(?bool firstAppointment): void |
| `clientServiceId` | `?int` | Optional | The ID of the pass on the client's account that is paying for this appointment. | getClientServiceId(): ?int | setClientServiceId(?int clientServiceId): void |
| `resources` | [`?(Resource2[])`](../../doc/models/resource.md) | Optional | The resources this appointment is using. | getResources(): ?array | setResources(?array resources): void |
| `addOns` | [`?(AddOnSmall1[])`](../../doc/models/add-on-small-1.md) | Optional | The Add-Ons Associated with this appointment | getAddOns(): ?array | setAddOns(?array addOns): void |
| `isWaitlist` | `?bool` | Optional | Whether to add appointment to waitlist. | getIsWaitlist(): ?bool | setIsWaitlist(?bool isWaitlist): void |
| `onlineDescription` | `?string` | Optional | Online Description associated with the appointment | getOnlineDescription(): ?string | setOnlineDescription(?string onlineDescription): void |

## Example (as JSON)

```json
{
  "GenderPreference": "GenderPreference0",
  "Duration": 192,
  "ProviderId": "ProviderId2",
  "Id": 146,
  "Status": "Confirmed"
}
```

