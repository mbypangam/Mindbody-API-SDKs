
# Remove Client From Class Response

## Structure

`RemoveClientFromClassResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `class` | [`?MClass`](../../doc/models/m-class.md) | Optional | Contains information about the class from which the client was removed. | getClass(): ?MClass | setClass(?MClass class): void |

## Example (as JSON)

```json
{
  "Class": null
}
```

