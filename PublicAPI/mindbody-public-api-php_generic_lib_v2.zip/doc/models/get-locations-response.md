
# Get Locations Response

## Structure

`GetLocationsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `locations` | [`?(Location[])`](../../doc/models/location.md) | Optional | Contains information about the locations. | getLocations(): ?array | setLocations(?array locations): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Locations": [
    {
      "AdditionalImageURLs": [
        "AdditionalImageURLs2"
      ],
      "Address": "Address2",
      "Address2": "Address24",
      "Amenities": [
        {
          "Id": 230,
          "Name": "Name2"
        },
        {
          "Id": 229,
          "Name": "Name3"
        },
        {
          "Id": 228,
          "Name": "Name4"
        }
      ],
      "BusinessDescription": "BusinessDescription8"
    }
  ]
}
```

