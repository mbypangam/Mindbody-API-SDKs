
# Mindbody Public Api Dto Models V6 Availability

A staff availability entry

## Structure

`MindbodyPublicApiDtoModelsV6Availability`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the availability. | getId(): ?int | setId(?int id): void |
| `staff` | [`?MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Contains information about staff members. | getStaff(): ?MindbodyPublicApiDtoModelsV6Staff | setStaff(?MindbodyPublicApiDtoModelsV6Staff staff): void |
| `sessionType` | [`?MindbodyPublicApiDtoModelsV6SessionType`](../../doc/models/mindbody-public-api-dto-models-v6-session-type.md) | Optional | Contains information about the types of sessions. | getSessionType(): ?MindbodyPublicApiDtoModelsV6SessionType | setSessionType(?MindbodyPublicApiDtoModelsV6SessionType sessionType): void |
| `programs` | [`?(MindbodyPublicApiDtoModelsV6Program[])`](../../doc/models/mindbody-public-api-dto-models-v6-program.md) | Optional | Contains information about the programs. | getPrograms(): ?array | setPrograms(?array programs): void |
| `startDateTime` | `?\DateTime` | Optional | The date and time the availability starts. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | The date and time the availability ends. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `bookableEndDateTime` | `?\DateTime` | Optional | The time of day that the last appointment can start. | getBookableEndDateTime(): ?\DateTime | setBookableEndDateTime(?\DateTime bookableEndDateTime): void |
| `location` | [`?MindbodyPublicApiDtoModelsV6Location`](../../doc/models/mindbody-public-api-dto-models-v6-location.md) | Optional | Contains information about the location. | getLocation(): ?MindbodyPublicApiDtoModelsV6Location | setLocation(?MindbodyPublicApiDtoModelsV6Location location): void |
| `prepTime` | `?int` | Optional | Prep time in minutes | getPrepTime(): ?int | setPrepTime(?int prepTime): void |
| `finishTime` | `?int` | Optional | Finish time in minutes | getFinishTime(): ?int | setFinishTime(?int finishTime): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

