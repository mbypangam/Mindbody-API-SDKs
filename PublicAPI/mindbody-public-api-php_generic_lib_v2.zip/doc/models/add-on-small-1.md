
# Add on Small 1

## Structure

`AddOnSmall1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The unique ID of the appointment add on. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The Name of the appointment add on. | getName(): ?string | setName(?string name): void |
| `staffId` | `?int` | Optional | The unique ID of the staff on appointment. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `typeId` | `?int` | Optional | The ID of the session type of this appointment. | getTypeId(): ?int | setTypeId(?int typeId): void |

## Example (as JSON)

```json
{
  "Id": 146,
  "Name": "Name0",
  "StaffId": 156,
  "TypeId": 216
}
```

