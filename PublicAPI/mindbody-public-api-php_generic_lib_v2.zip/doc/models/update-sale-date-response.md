
# Update Sale Date Response

Update Sale Date Response Properties

## Structure

`UpdateSaleDateResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sale` | [`?Sale`](../../doc/models/sale.md) | Optional | Contains the Sale details. | getSale(): ?Sale | setSale(?Sale sale): void |

## Example (as JSON)

```json
{
  "Sale": null
}
```

