
# Get Client Duplicates Response

## Structure

`GetClientDuplicatesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `clientDuplicates` | [`?(ClientDuplicate[])`](../../doc/models/client-duplicate.md) | Optional | The requested clients. | getClientDuplicates(): ?array | setClientDuplicates(?array clientDuplicates): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientDuplicates": null
}
```

