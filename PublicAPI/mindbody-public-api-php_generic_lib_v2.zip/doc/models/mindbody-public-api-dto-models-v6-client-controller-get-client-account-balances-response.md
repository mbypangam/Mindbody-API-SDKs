
# Mindbody Public Api Dto Models V6 Client Controller Get Client Account Balances Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `clients` | [`?(MindbodyPublicApiDtoModelsV6Client[])`](../../doc/models/mindbody-public-api-dto-models-v6-client.md) | Optional | A list of clients. | getClients(): ?array | setClients(?array clients): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Clients": null
}
```

