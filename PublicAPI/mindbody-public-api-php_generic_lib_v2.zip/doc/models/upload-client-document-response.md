
# Upload Client Document Response

## Structure

`UploadClientDocumentResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `fileSize` | `?int` | Optional | The size of the uploaded file. | getFileSize(): ?int | setFileSize(?int fileSize): void |
| `fileName` | `?string` | Optional | The name of the uploaded file. | getFileName(): ?string | setFileName(?string fileName): void |

## Example (as JSON)

```json
{
  "FileSize": 142,
  "FileName": "FileName8"
}
```

