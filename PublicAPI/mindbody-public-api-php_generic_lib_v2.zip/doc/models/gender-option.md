
# Gender Option

A gender option available at a site

## Structure

`GenderOption`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The id of the gender option. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The value that describes this gender option. | getName(): ?string | setName(?string name): void |
| `isActive` | `?bool` | Optional | When `true`, this indicates that the gender option is active and may be assigned to a client. | getIsActive(): ?bool | setIsActive(?bool isActive): void |
| `isDefault` | `?bool` | Optional | When true, this indicates that this is the default gender option at the site. | getIsDefault(): ?bool | setIsDefault(?bool isDefault): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "IsActive": null,
  "IsDefault": null
}
```

