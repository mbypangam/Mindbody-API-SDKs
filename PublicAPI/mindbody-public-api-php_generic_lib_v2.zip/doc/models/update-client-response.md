
# Update Client Response

## Structure

`UpdateClientResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `client` | [`?ClientWithSuspensionInfo`](../../doc/models/client-with-suspension-info.md) | Optional | Contains information about the updated client. | getClient(): ?ClientWithSuspensionInfo | setClient(?ClientWithSuspensionInfo client): void |

## Example (as JSON)

```json
{
  "Client": null
}
```

