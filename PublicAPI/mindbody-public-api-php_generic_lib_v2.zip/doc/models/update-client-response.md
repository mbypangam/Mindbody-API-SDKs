
# Update Client Response

## Structure

`UpdateClientResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `client` | [`?ClientWithSuspensionInfo`](../../doc/models/client-with-suspension-info.md) | Optional | A Client DTO with Suspension Informatoin | getClient(): ?ClientWithSuspensionInfo | setClient(?ClientWithSuspensionInfo client): void |

## Example (as JSON)

```json
{
  "Client": null
}
```

