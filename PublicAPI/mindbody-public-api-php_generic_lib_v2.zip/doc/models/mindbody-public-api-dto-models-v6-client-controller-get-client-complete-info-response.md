
# Mindbody Public Api Dto Models V6 Client Controller Get Client Complete Info Response

Contains information about the requested client.

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `client` | [`?MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo`](../../doc/models/mindbody-public-api-dto-models-v6-client-with-suspension-info.md) | Optional | A Client DTO with Suspension Informatoin | getClient(): ?MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo | setClient(?MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo client): void |
| `clientServices` | [`?(MindbodyPublicApiDtoModelsV6ClientService[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-service.md) | Optional | Contains information about client pricing options. | getClientServices(): ?array | setClientServices(?array clientServices): void |
| `clientContracts` | [`?(MindbodyPublicApiDtoModelsV6ClientContract[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-contract.md) | Optional | Contains information about client contract. | getClientContracts(): ?array | setClientContracts(?array clientContracts): void |
| `clientMemberships` | [`?(MindbodyPublicApiDtoModelsV6ClientMembership[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-membership.md) | Optional | Contains information about client Memberships. | getClientMemberships(): ?array | setClientMemberships(?array clientMemberships): void |
| `clientArrivals` | [`?(MindbodyPublicApiDtoModelsV6ClientArrival[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-arrival.md) | Optional | Contains information about client arrival services. | getClientArrivals(): ?array | setClientArrivals(?array clientArrivals): void |

## Example (as JSON)

```json
{
  "Client": null,
  "ClientServices": null,
  "ClientContracts": null,
  "ClientMemberships": null,
  "ClientArrivals": null
}
```

