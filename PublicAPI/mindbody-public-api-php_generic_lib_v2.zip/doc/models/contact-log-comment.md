
# Contact Log Comment

A contact log comment.

## Structure

`ContactLogComment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The comment’s ID. | getId(): ?int | setId(?int id): void |
| `text` | `?string` | Optional | The comment’s body text. | getText(): ?string | setText(?string text): void |
| `createdDateTime` | `?\DateTime` | Optional | The local time when the comment was created. | getCreatedDateTime(): ?\DateTime | setCreatedDateTime(?\DateTime createdDateTime): void |
| `createdBy` | [`?Staff`](../../doc/models/staff.md) | Optional | Information about the staff member who created the comment. | getCreatedBy(): ?Staff | setCreatedBy(?Staff createdBy): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Text": null,
  "CreatedDateTime": null,
  "CreatedBy": null
}
```

