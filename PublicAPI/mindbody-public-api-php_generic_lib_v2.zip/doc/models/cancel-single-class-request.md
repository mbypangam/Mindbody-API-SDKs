
# Cancel Single Class Request

## Structure

`CancelSingleClassRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classID` | `?int` | Optional | Class ID to lookup. | getClassID(): ?int | setClassID(?int classID): void |
| `hideCancel` | `?bool` | Optional | When `true`, indicates that this class is hidden when cancelled.<br>When `false`, indicates that this class is not hidden when cancelled. | getHideCancel(): ?bool | setHideCancel(?bool hideCancel): void |
| `sendClientEmail` | `?bool` | Optional | When `true`, sends the client an automatic email about the cancellation, if the client has opted to receive email. | getSendClientEmail(): ?bool | setSendClientEmail(?bool sendClientEmail): void |
| `sendStaffEmail` | `?bool` | Optional | When `true`, sends the staff an automatic email about the cancellation, if the staff has opted to receive email. | getSendStaffEmail(): ?bool | setSendStaffEmail(?bool sendStaffEmail): void |

## Example (as JSON)

```json
{
  "ClassID": null,
  "HideCancel": null,
  "SendClientEmail": null,
  "SendStaffEmail": null
}
```

