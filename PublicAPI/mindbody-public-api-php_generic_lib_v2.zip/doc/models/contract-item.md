
# Contract Item

## Structure

`ContractItem`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | The ID of the item. | getId(): ?string | setId(?string id): void |
| `name` | `?string` | Optional | The name of the item. | getName(): ?string | setName(?string name): void |
| `description` | `?string` | Optional | A description of the item. | getDescription(): ?string | setDescription(?string description): void |
| `type` | `?string` | Optional | The type of the item. | getType(): ?string | setType(?string type): void |
| `price` | `?float` | Optional | The price of the item. | getPrice(): ?float | setPrice(?float price): void |
| `quantity` | `?int` | Optional | The quantity of the item. | getQuantity(): ?int | setQuantity(?int quantity): void |
| `oneTimeItem` | `?bool` | Optional | When `true`, indicates that the item is charged only once.<br /><br>When `false`, indicates that the item is charged multiple times. | getOneTimeItem(): ?bool | setOneTimeItem(?bool oneTimeItem): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null,
  "Type": null,
  "Price": null,
  "Quantity": null,
  "OneTimeItem": null
}
```

