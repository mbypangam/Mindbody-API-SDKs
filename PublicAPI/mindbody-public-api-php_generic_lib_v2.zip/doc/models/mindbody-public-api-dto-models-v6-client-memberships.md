
# Mindbody Public Api Dto Models V6 Client Memberships

## Structure

`MindbodyPublicApiDtoModelsV6ClientMemberships`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `?string` | Optional | ID of the client. | getClientId(): ?string | setClientId(?string clientId): void |
| `memberships` | [`?(MindbodyPublicApiDtoModelsV6ClientMembership[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-membership.md) | Optional | Contains information about the Client Memberships details. | getMemberships(): ?array | setMemberships(?array memberships): void |
| `errorMessage` | `?string` | Optional | Incase if invalid clientID passed, we get ErrorMessage instead of Memberships. | getErrorMessage(): ?string | setErrorMessage(?string errorMessage): void |

## Example (as JSON)

```json
{
  "ClientId": null,
  "Memberships": null,
  "ErrorMessage": null
}
```

