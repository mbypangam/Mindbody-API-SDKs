
# Get Memberships Response

## Structure

`GetMembershipsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `memberships` | [`?(Membership[])`](../../doc/models/membership.md) | Optional | Details about the memberships. | getMemberships(): ?array | setMemberships(?array memberships): void |

## Example (as JSON)

```json
{
  "Memberships": [
    {
      "MembershipId": 132,
      "MembershipName": "MembershipName6",
      "Priority": 82,
      "MemberRetailDiscount": 177.18,
      "MemberServiceDiscount": 63.02
    },
    {
      "MembershipId": 132,
      "MembershipName": "MembershipName6",
      "Priority": 82,
      "MemberRetailDiscount": 177.18,
      "MemberServiceDiscount": 63.02
    }
  ]
}
```

