
# Get Memberships Response

## Structure

`GetMembershipsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `memberships` | [`?(MindbodyPublicApiDtoModelsV6Membership[])`](../../doc/models/mindbody-public-api-dto-models-v6-membership.md) | Optional | Details about the memberships. | getMemberships(): ?array | setMemberships(?array memberships): void |

## Example (as JSON)

```json
{
  "Memberships": null
}
```

