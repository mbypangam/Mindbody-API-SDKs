
# Mindbody Public Api Dto Models V6 Client Controller Get Clients Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination properties to use. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `clients` | [`?(MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-with-suspension-info.md) | Optional | The requested clients. | getClients(): ?array | setClients(?array clients): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Clients": null
}
```

