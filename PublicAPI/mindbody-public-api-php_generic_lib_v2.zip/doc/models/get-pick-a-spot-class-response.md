
# Get Pick a Spot Class Response

Pick A Spot class response.

## Structure

`GetPickASpotClassResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classes` | [`?(PickASpotClass[])`](../../doc/models/pick-a-spot-class.md) | Optional | Pick A Spot classes information. | getClasses(): ?array | setClasses(?array classes): void |
| `pagination` | [`?Pagination`](../../doc/models/pagination.md) | Optional | Contains information about the pagination used. | getPagination(): ?Pagination | setPagination(?Pagination pagination): void |
| `responseDetails` | [`?ResponseDetails`](../../doc/models/response-details.md) | Optional | Contains information about the response details. | getResponseDetails(): ?ResponseDetails | setResponseDetails(?ResponseDetails responseDetails): void |

## Example (as JSON)

```json
{
  "classes": null,
  "pagination": null,
  "responseDetails": null
}
```

