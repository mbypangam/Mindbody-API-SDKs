
# Get Client Contracts Response

## Structure

`GetClientContractsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `contracts` | [`?(MindbodyPublicApiDtoModelsV6ClientContract[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-contract.md) | Optional | Contains the details of the client’s contract. | getContracts(): ?array | setContracts(?array contracts): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Contracts": null
}
```

