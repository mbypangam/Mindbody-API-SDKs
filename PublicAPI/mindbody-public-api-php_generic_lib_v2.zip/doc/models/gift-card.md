
# Gift Card

## Structure

`GiftCard`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The gift card's `ProductID`. | getId(): ?int | setId(?int id): void |
| `locationIds` | `?(int[])` | Optional | The IDs of the locations where the gift card is sold. | getLocationIds(): ?array | setLocationIds(?array locationIds): void |
| `description` | `?string` | Optional | A description of the gift card. | getDescription(): ?string | setDescription(?string description): void |
| `editableByConsumer` | `?bool` | Optional | When `true`, indicates that the gift card can be edited by the client. | getEditableByConsumer(): ?bool | setEditableByConsumer(?bool editableByConsumer): void |
| `cardValue` | `?float` | Optional | The value of the gift card. | getCardValue(): ?float | setCardValue(?float cardValue): void |
| `salePrice` | `?float` | Optional | The sale price of the gift card, if applicable. | getSalePrice(): ?float | setSalePrice(?float salePrice): void |
| `soldOnline` | `?bool` | Optional | When `true`, indicates that the gift card is sold online. | getSoldOnline(): ?bool | setSoldOnline(?bool soldOnline): void |
| `membershipRestrictionIds` | `?(int[])` | Optional | A list of IDs for membership restrictions, if this card is restricted to members with certain types of memberships. | getMembershipRestrictionIds(): ?array | setMembershipRestrictionIds(?array membershipRestrictionIds): void |
| `giftCardTerms` | `?string` | Optional | The terms of the gift card. | getGiftCardTerms(): ?string | setGiftCardTerms(?string giftCardTerms): void |
| `contactInfo` | `?string` | Optional | Contact information for the gift card. | getContactInfo(): ?string | setContactInfo(?string contactInfo): void |
| `displayLogo` | `?bool` | Optional | When `true`, indicates that the logo should be displayed on the gift card. | getDisplayLogo(): ?bool | setDisplayLogo(?bool displayLogo): void |
| `layouts` | [`?(GiftCardLayout[])`](../../doc/models/gift-card-layout.md) | Optional | A list of layouts available for the gift card. | getLayouts(): ?array | setLayouts(?array layouts): void |

## Example (as JSON)

```json
{
  "Id": 166,
  "LocationIds": [
    204,
    205
  ],
  "Description": "Description6",
  "EditableByConsumer": false,
  "CardValue": 106.8
}
```

