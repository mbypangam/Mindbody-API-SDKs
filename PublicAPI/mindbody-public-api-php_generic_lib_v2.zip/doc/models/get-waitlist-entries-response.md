
# Get Waitlist Entries Response

## Structure

`GetWaitlistEntriesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `waitlistEntries` | [`?(MindbodyPublicApiDtoModelsV6WaitlistEntry[])`](../../doc/models/mindbody-public-api-dto-models-v6-waitlist-entry.md) | Optional | Contains information about the waiting list entries. | getWaitlistEntries(): ?array | setWaitlistEntries(?array waitlistEntries): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "WaitlistEntries": null
}
```

