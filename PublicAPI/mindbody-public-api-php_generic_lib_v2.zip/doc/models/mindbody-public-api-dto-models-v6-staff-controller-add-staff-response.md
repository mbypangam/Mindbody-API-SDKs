
# Mindbody Public Api Dto Models V6 Staff Controller Add Staff Response

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staff` | [`?MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Contains information about the staff | getStaff(): ?MindbodyPublicApiDtoModelsV6Staff | setStaff(?MindbodyPublicApiDtoModelsV6Staff staff): void |

## Example (as JSON)

```json
{
  "Staff": null
}
```

