
# Mindbody Public Api Dto Models V6 Client Controller Suspend Contract Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `string` | Required | The RSSID of the client for whom the contract is getting suspended. | getClientId(): string | setClientId(string clientId): void |
| `clientContractId` | `int` | Required | The unique ID of the sale of the contract | getClientContractId(): int | setClientContractId(int clientContractId): void |
| `suspensionType` | `?string` | Optional | The suspension type | getSuspensionType(): ?string | setSuspensionType(?string suspensionType): void |
| `suspensionStart` | `?\DateTime` | Optional | The date to start contract suspension | getSuspensionStart(): ?\DateTime | setSuspensionStart(?\DateTime suspensionStart): void |
| `duration` | `?int` | Optional | The number of (DurationUnit) the suspension lasts | getDuration(): ?int | setDuration(?int duration): void |
| `durationUnit` | `?int` | Optional | The unit applied to duration | getDurationUnit(): ?int | setDurationUnit(?int durationUnit): void |
| `openEnded` | `?bool` | Optional | Indicates open ended suspension | getOpenEnded(): ?bool | setOpenEnded(?bool openEnded): void |
| `suspensionNotes` | `?string` | Optional | The suspension notes | getSuspensionNotes(): ?string | setSuspensionNotes(?string suspensionNotes): void |
| `suspensionFee` | `?float` | Optional | charge to suspend a contract for a set period of time | getSuspensionFee(): ?float | setSuspensionFee(?float suspensionFee): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "ClientContractId": 86,
  "SuspensionType": null,
  "SuspensionStart": null,
  "Duration": null,
  "DurationUnit": null,
  "OpenEnded": null,
  "SuspensionNotes": null,
  "SuspensionFee": null
}
```

