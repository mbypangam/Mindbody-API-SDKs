
# Formula Note Response

An individual Client Formula Note.

## Structure

`FormulaNoteResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The formula note ID. | getId(): ?int | setId(?int id): void |
| `clientId` | `?string` | Optional | The unique Id of the client for the formula note. This is the unique ID for the client in the site where the formula note originated. This is different than the ClientId specified in the request, which is the id for the client assigned by the business. | getClientId(): ?string | setClientId(?string clientId): void |
| `appointmentId` | `?int` | Optional | The appointment ID that the formula note is related to. | getAppointmentId(): ?int | setAppointmentId(?int appointmentId): void |
| `entryDate` | `?\DateTime` | Optional | The date formula note was created. | getEntryDate(): ?\DateTime | setEntryDate(?\DateTime entryDate): void |
| `note` | `?string` | Optional | The new formula note text. | getNote(): ?string | setNote(?string note): void |
| `siteId` | `?int` | Optional | The site Id. | getSiteId(): ?int | setSiteId(?int siteId): void |
| `siteName` | `?string` | Optional | The site name. | getSiteName(): ?string | setSiteName(?string siteName): void |
| `staffFirstName` | `?string` | Optional | The first name of the staff for the optional associated appointment. If no appointment ID is provided, this will be null. | getStaffFirstName(): ?string | setStaffFirstName(?string staffFirstName): void |
| `staffLastName` | `?string` | Optional | The last name of the staff for the optional associated appointment. If no appointment ID is provided, this will be null. | getStaffLastName(): ?string | setStaffLastName(?string staffLastName): void |
| `staffDisplayName` | `?string` | Optional | The display name of the staff for the optional associated appointment. If no appointment ID is provided, or no display name is specified for the staff member, this will be null. | getStaffDisplayName(): ?string | setStaffDisplayName(?string staffDisplayName): void |

## Example (as JSON)

```json
{
  "Id": 146,
  "ClientId": "ClientId6",
  "AppointmentId": 22,
  "EntryDate": "2016-03-13T12:52:32.123Z",
  "Note": "Note0"
}
```

