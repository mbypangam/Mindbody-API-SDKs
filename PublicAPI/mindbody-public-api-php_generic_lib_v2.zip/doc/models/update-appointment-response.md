
# Update Appointment Response

## Structure

`UpdateAppointmentResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appointment` | [`?MindbodyPublicApiDtoModelsV6Appointment`](../../doc/models/mindbody-public-api-dto-models-v6-appointment.md) | Optional | Contains information about the appointment. | getAppointment(): ?MindbodyPublicApiDtoModelsV6Appointment | setAppointment(?MindbodyPublicApiDtoModelsV6Appointment appointment): void |

## Example (as JSON)

```json
{
  "Appointment": null
}
```

