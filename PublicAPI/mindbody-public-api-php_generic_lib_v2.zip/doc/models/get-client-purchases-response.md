
# Get Client Purchases Response

## Structure

`GetClientPurchasesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `purchases` | [`?(ClientPurchaseRecord[])`](../../doc/models/client-purchase-record.md) | Optional | Contains information that describes the item sold and the payment. | getPurchases(): ?array | setPurchases(?array purchases): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Purchases": null
}
```

