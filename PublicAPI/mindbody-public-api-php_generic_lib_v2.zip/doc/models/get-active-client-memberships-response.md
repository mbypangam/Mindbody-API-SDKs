
# Get Active Client Memberships Response

## Structure

`GetActiveClientMembershipsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `clientMemberships` | [`?(ClientMembership[])`](../../doc/models/client-membership.md) | Optional | Details about the requested memberships. | getClientMemberships(): ?array | setClientMemberships(?array clientMemberships): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientMemberships": null
}
```

