
# Add Availabilities Response

Add Availabilities Response Model

## Structure

`AddAvailabilitiesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffMembers` | [`?(Staff1[])`](../../doc/models/staff-1.md) | Optional | Contains information about the staff. | getStaffMembers(): ?array | setStaffMembers(?array staffMembers): void |
| `errors` | [`?(ApiError1[])`](../../doc/models/api-error-1.md) | Optional | Contains information about the error. | getErrors(): ?array | setErrors(?array errors): void |

## Example (as JSON)

```json
{
  "StaffMembers": [
    {
      "Id": 202,
      "FirstName": "FirstName8",
      "LastName": "LastName8",
      "DisplayName": "DisplayName0",
      "Email": "Email8"
    },
    {
      "Id": 203,
      "FirstName": "FirstName7",
      "LastName": "LastName7",
      "DisplayName": "DisplayName9",
      "Email": "Email7"
    }
  ],
  "Errors": [
    {
      "Message": "Message8",
      "Code": "Code2"
    }
  ]
}
```

