
# Add Availabilities Response

## Structure

`AddAvailabilitiesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffMembers` | [`?(Staff1[])`](../../doc/models/staff-1.md) | Optional | Contains information about the staff. | getStaffMembers(): ?array | setStaffMembers(?array staffMembers): void |
| `errors` | [`?(ApiError1[])`](../../doc/models/api-error-1.md) | Optional | Contains information about the error. | getErrors(): ?array | setErrors(?array errors): void |

## Example (as JSON)

```json
{
  "StaffMembers": null,
  "Errors": null
}
```

