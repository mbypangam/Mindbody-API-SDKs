
# Mindbody Public Api Dto Models V6 Sale Controller Get Services Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `services` | [`?(MindbodyPublicApiDtoModelsV6Service[])`](../../doc/models/mindbody-public-api-dto-models-v6-service.md) | Optional | Contains information about the services. | getServices(): ?array | setServices(?array services): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Services": null
}
```

