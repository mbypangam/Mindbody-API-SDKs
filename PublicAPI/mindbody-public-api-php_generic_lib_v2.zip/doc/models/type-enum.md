
# Type Enum

Contains the class description session type. Possible values are:

* All
* Class
* Enrollment
* Appointment
* Resource
* Media
* Arrival

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `ALL` |
| `CLASS_` |
| `ENROLLMENT` |
| `APPOINTMENT` |
| `RESOURCE` |
| `MEDIA` |
| `ARRIVAL` |

