
# Mindbody Public Api Dto Models V6 Sale Controller Completed Sale Cart Item

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleCartItem`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `item` | `?array` | Optional | A purchased item; either a pricing option or a retail product. | getItem(): ?array | setItem(?array item): void |
| `discountAmount` | `?float` | Optional | The amount of the discount applied to the item. | getDiscountAmount(): ?float | setDiscountAmount(?float discountAmount): void |
| `visitIds` | `?(int[])` | Optional | The IDs of the booked classes, enrollments, or courses that were reconciled by this cart item. This list is only returned if a valid visit ID was passed in the request?s `VisitIds` list. | getVisitIds(): ?array | setVisitIds(?array visitIds): void |
| `appointmentIds` | `?(int[])` | Optional | Gets or sets the item. | getAppointmentIds(): ?array | setAppointmentIds(?array appointmentIds): void |
| `appointments` | [`?(MindbodyPublicApiDtoModelsV6Appointment[])`](../../doc/models/mindbody-public-api-dto-models-v6-appointment.md) | Optional | The IDs of the appointments that were reconciled by this cart item. This list is only returned if a valid appointment ID was passed in the request?s `AppointmentIds` list. | getAppointments(): ?array | setAppointments(?array appointments): void |
| `id` | `?int` | Optional | The item?s ID in the current cart. | getId(): ?int | setId(?int id): void |
| `quantity` | `?int` | Optional | The quantity of the item being purchased. | getQuantity(): ?int | setQuantity(?int quantity): void |

## Example (as JSON)

```json
{
  "Item": null,
  "DiscountAmount": null,
  "VisitIds": null,
  "AppointmentIds": null,
  "Appointments": null,
  "Id": null,
  "Quantity": null
}
```

