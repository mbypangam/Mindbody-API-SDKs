
# Create Reservation Response

Create reservation response.

## Structure

`CreateReservationResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reservation` | [`?Reservation`](../../doc/models/reservation.md) | Optional | Reservation details. | getReservation(): ?Reservation | setReservation(?Reservation reservation): void |
| `responseDetails` | [`?ResponseDetails`](../../doc/models/response-details.md) | Optional | Response details, e.g. status, transactionId. | getResponseDetails(): ?ResponseDetails | setResponseDetails(?ResponseDetails responseDetails): void |

## Example (as JSON)

```json
{
  "Reservation": null,
  "ResponseDetails": null
}
```

