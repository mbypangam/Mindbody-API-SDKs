
# Create Reservation Response

Contains information about the create reservation response.

## Structure

`CreateReservationResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reservation` | [`?Reservation`](../../doc/models/reservation.md) | Optional | Contains information about the reservation. | getReservation(): ?Reservation | setReservation(?Reservation reservation): void |
| `responseDetails` | [`?ResponseDetails`](../../doc/models/response-details.md) | Optional | Contains information about the response message detail. | getResponseDetails(): ?ResponseDetails | setResponseDetails(?ResponseDetails responseDetails): void |

## Example (as JSON)

```json
{
  "Reservation": {
    "ReservationId": "ReservationId2",
    "ReservationExternalId": "ReservationExternalId4",
    "ClassId": "ClassId4",
    "ClassExternalId": "ClassExternalId6",
    "MemberExternalId": "MemberExternalId4"
  },
  "ResponseDetails": {
    "Status": "Status2",
    "TransactionId": "TransactionId4",
    "Message": "Message0"
  }
}
```

