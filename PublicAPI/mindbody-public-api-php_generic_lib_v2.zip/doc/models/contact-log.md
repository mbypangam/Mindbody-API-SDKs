
# Contact Log

A contact log.

## Structure

`ContactLog`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The contact log’s ID. | getId(): ?int | setId(?int id): void |
| `text` | `?string` | Optional | The contact log’s body text. | getText(): ?string | setText(?string text): void |
| `createdDateTime` | `?\DateTime` | Optional | The local date and time when the contact log was created. | getCreatedDateTime(): ?\DateTime | setCreatedDateTime(?\DateTime createdDateTime): void |
| `followupByDate` | `?\DateTime` | Optional | The date by which the assigned staff member should close or follow up on this contact log. | getFollowupByDate(): ?\DateTime | setFollowupByDate(?\DateTime followupByDate): void |
| `contactMethod` | `?string` | Optional | The method by which the client wants to be contacted. | getContactMethod(): ?string | setContactMethod(?string contactMethod): void |
| `contactName` | `?string` | Optional | The name of the client to contact. | getContactName(): ?string | setContactName(?string contactName): void |
| `client` | [`?Client`](../../doc/models/client.md) | Optional | The Client. | getClient(): ?Client | setClient(?Client client): void |
| `createdBy` | [`?Staff`](../../doc/models/staff.md) | Optional | The Staff | getCreatedBy(): ?Staff | setCreatedBy(?Staff createdBy): void |
| `assignedTo` | [`?Staff`](../../doc/models/staff.md) | Optional | The Staff | getAssignedTo(): ?Staff | setAssignedTo(?Staff assignedTo): void |
| `comments` | [`?(ContactLogComment[])`](../../doc/models/contact-log-comment.md) | Optional | Information about the comment. | getComments(): ?array | setComments(?array comments): void |
| `types` | [`?(ContactLogType[])`](../../doc/models/contact-log-type.md) | Optional | Information about the type of contact log. | getTypes(): ?array | setTypes(?array types): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Text": null,
  "CreatedDateTime": null,
  "FollowupByDate": null,
  "ContactMethod": null,
  "ContactName": null,
  "Client": null,
  "CreatedBy": null,
  "AssignedTo": null,
  "Comments": null,
  "Types": null
}
```

