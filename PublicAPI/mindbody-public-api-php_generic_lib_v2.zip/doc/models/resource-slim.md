
# Resource Slim

Contains information about resources, such as rooms.

## Structure

`ResourceSlim`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the resource being used for this appointment. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the resource being used for this appointment. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": 80,
  "Name": "Name8"
}
```

