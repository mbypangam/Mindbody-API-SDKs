
# Class Schedule

Represents a single class instance. The class meets at the start time, goes until the end time.

## Structure

`ClassSchedule`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classes` | [`?(MClass[])`](../../doc/models/m-class.md) | Optional | Contains information about a class. | getClasses(): ?array | setClasses(?array classes): void |
| `clients` | [`?(Client[])`](../../doc/models/client.md) | Optional | Contains information about clients. | getClients(): ?array | setClients(?array clients): void |
| `course` | [`?Course`](../../doc/models/course.md) | Optional | A course. | getCourse(): ?Course | setCourse(?Course course): void |
| `semesterId` | `?int` | Optional | The semester ID for the enrollment (if any). | getSemesterId(): ?int | setSemesterId(?int semesterId): void |
| `isAvailable` | `?bool` | Optional | When `true`, indicates that the enrollment shows in consumer mode, has not started yet, and there is room in each class of the enrollment.<br /><br>When `false`, indicates that either the enrollment does not show in consumer mode, has already started, or there is no room in some classes of the enrollment. | getIsAvailable(): ?bool | setIsAvailable(?bool isAvailable): void |
| `id` | `?int` | Optional | The unique ID of the class schedule. | getId(): ?int | setId(?int id): void |
| `classDescription` | [`?ClassDescription`](../../doc/models/class-description.md) | Optional | Represents a class definition. The class meets at the start time, goes until the end time. | getClassDescription(): ?ClassDescription | setClassDescription(?ClassDescription classDescription): void |
| `daySunday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Sundays. | getDaySunday(): ?bool | setDaySunday(?bool daySunday): void |
| `dayMonday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Mondays. | getDayMonday(): ?bool | setDayMonday(?bool dayMonday): void |
| `dayTuesday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Tuesdays. | getDayTuesday(): ?bool | setDayTuesday(?bool dayTuesday): void |
| `dayWednesday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Wednesdays. | getDayWednesday(): ?bool | setDayWednesday(?bool dayWednesday): void |
| `dayThursday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Thursdays. | getDayThursday(): ?bool | setDayThursday(?bool dayThursday): void |
| `dayFriday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Fridays. | getDayFriday(): ?bool | setDayFriday(?bool dayFriday): void |
| `daySaturday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Saturdays. | getDaySaturday(): ?bool | setDaySaturday(?bool daySaturday): void |
| `allowOpenEnrollment` | `?bool` | Optional | When `true`, indicates that the enrollment allows booking after the enrollment has started. | getAllowOpenEnrollment(): ?bool | setAllowOpenEnrollment(?bool allowOpenEnrollment): void |
| `allowDateForwardEnrollment` | `?bool` | Optional | When `true`, indicates that this the enrollment shows in consumer mode, the enrollment has not started yet, and there is room in each class of the enrollment. | getAllowDateForwardEnrollment(): ?bool | setAllowDateForwardEnrollment(?bool allowDateForwardEnrollment): void |
| `startTime` | `?DateTime` | Optional | The time this class schedule starts. | getStartTime(): ?\DateTime | setStartTime(?\DateTime startTime): void |
| `endTime` | `?DateTime` | Optional | The time this class schedule ends. | getEndTime(): ?\DateTime | setEndTime(?\DateTime endTime): void |
| `startDate` | `?DateTime` | Optional | The date this class schedule starts. | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?DateTime` | Optional | The date this class schedule ends. | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `staff` | [`?Staff`](../../doc/models/staff.md) | Optional | The Staff | getStaff(): ?Staff | setStaff(?Staff staff): void |
| `location` | [`?Location`](../../doc/models/location.md) | Optional | - | getLocation(): ?Location | setLocation(?Location location): void |

## Example (as JSON)

```json
{
  "Classes": [
    {
      "ClassScheduleId": 27,
      "Visits": [
        {
          "AppointmentId": 122,
          "AppointmentGenderPreference": "Female",
          "AppointmentStatus": "NoShow",
          "ClassId": 214,
          "ClientId": "ClientId6"
        },
        {
          "AppointmentId": 121,
          "AppointmentGenderPreference": "Male",
          "AppointmentStatus": "Arrived",
          "ClassId": 215,
          "ClientId": "ClientId5"
        },
        {
          "AppointmentId": 120,
          "AppointmentGenderPreference": "None",
          "AppointmentStatus": "Confirmed",
          "ClassId": 216,
          "ClientId": "ClientId4"
        }
      ],
      "Clients": [
        {
          "AppointmentGenderPreference": "Female",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country2",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value3",
              "Id": 35,
              "DataType": "DataType9",
              "Name": "Name5"
            },
            {
              "Value": "Value4",
              "Id": 36,
              "DataType": "DataType0",
              "Name": "Name6"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "Male",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country3",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value4",
              "Id": 36,
              "DataType": "DataType0",
              "Name": "Name6"
            },
            {
              "Value": "Value5",
              "Id": 37,
              "DataType": "DataType1",
              "Name": "Name7"
            },
            {
              "Value": "Value6",
              "Id": 38,
              "DataType": "DataType2",
              "Name": "Name8"
            }
          ]
        }
      ],
      "Location": {
        "AdditionalImageURLs": [
          "AdditionalImageURLs9",
          "AdditionalImageURLs0",
          "AdditionalImageURLs1"
        ],
        "Address": "Address5",
        "Address2": "Address27",
        "Amenities": [
          {
            "Id": 223,
            "Name": "Name5"
          },
          {
            "Id": 224,
            "Name": "Name6"
          }
        ],
        "BusinessDescription": "BusinessDescription1"
      },
      "Resource": {
        "Id": 255,
        "Name": "Name3"
      }
    },
    {
      "ClassScheduleId": 28,
      "Visits": [
        {
          "AppointmentId": 121,
          "AppointmentGenderPreference": "Male",
          "AppointmentStatus": "Arrived",
          "ClassId": 215,
          "ClientId": "ClientId5"
        }
      ],
      "Clients": [
        {
          "AppointmentGenderPreference": "Male",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country3",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value4",
              "Id": 36,
              "DataType": "DataType0",
              "Name": "Name6"
            },
            {
              "Value": "Value5",
              "Id": 37,
              "DataType": "DataType1",
              "Name": "Name7"
            },
            {
              "Value": "Value6",
              "Id": 38,
              "DataType": "DataType2",
              "Name": "Name8"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "None",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country4",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value5",
              "Id": 37,
              "DataType": "DataType1",
              "Name": "Name7"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "Female",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country5",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value6",
              "Id": 38,
              "DataType": "DataType2",
              "Name": "Name8"
            },
            {
              "Value": "Value7",
              "Id": 39,
              "DataType": "DataType3",
              "Name": "Name9"
            }
          ]
        }
      ],
      "Location": {
        "AdditionalImageURLs": [
          "AdditionalImageURLs0"
        ],
        "Address": "Address6",
        "Address2": "Address28",
        "Amenities": [
          {
            "Id": 224,
            "Name": "Name6"
          },
          {
            "Id": 225,
            "Name": "Name7"
          },
          {
            "Id": 226,
            "Name": "Name8"
          }
        ],
        "BusinessDescription": "BusinessDescription2"
      },
      "Resource": {
        "Id": 254,
        "Name": "Name2"
      }
    }
  ],
  "Clients": [
    {
      "AppointmentGenderPreference": "Male",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country9",
      "CreationDate": "2016-03-13T12:52:32.123Z",
      "CustomClientFields": [
        {
          "Value": "Value0",
          "Id": 12,
          "DataType": "DataType6",
          "Name": "Name2"
        },
        {
          "Value": "Value1",
          "Id": 13,
          "DataType": "DataType7",
          "Name": "Name3"
        },
        {
          "Value": "Value2",
          "Id": 14,
          "DataType": "DataType8",
          "Name": "Name4"
        }
      ]
    },
    {
      "AppointmentGenderPreference": "None",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country0",
      "CreationDate": "2016-03-13T12:52:32.123Z",
      "CustomClientFields": [
        {
          "Value": "Value1",
          "Id": 13,
          "DataType": "DataType7",
          "Name": "Name3"
        }
      ]
    },
    {
      "AppointmentGenderPreference": "Female",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country1",
      "CreationDate": "2016-03-13T12:52:32.123Z",
      "CustomClientFields": [
        {
          "Value": "Value2",
          "Id": 14,
          "DataType": "DataType8",
          "Name": "Name4"
        },
        {
          "Value": "Value3",
          "Id": 15,
          "DataType": "DataType9",
          "Name": "Name5"
        }
      ]
    }
  ],
  "Course": {
    "Id": 0,
    "Name": "Name6",
    "Description": "Description0",
    "Notes": "Notes2",
    "StartDate": "2016-03-13T12:52:32.123Z"
  },
  "SemesterId": 192,
  "IsAvailable": false
}
```

