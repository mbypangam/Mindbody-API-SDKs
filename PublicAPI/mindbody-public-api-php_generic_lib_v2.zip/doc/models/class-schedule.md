
# Class Schedule

Represents a single class instance. The class meets at the start time, goes until the end time.

## Structure

`ClassSchedule`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `classes` | [`?(MClass[])`](../../doc/models/m-class.md) | Optional | Contains information about a class. | getClasses(): ?array | setClasses(?array classes): void |
| `clients` | [`?(Client[])`](../../doc/models/client.md) | Optional | Contains information about clients. | getClients(): ?array | setClients(?array clients): void |
| `course` | [`?Course`](../../doc/models/course.md) | Optional | Contains information about the course that the enrollment is a part of. | getCourse(): ?Course | setCourse(?Course course): void |
| `semesterId` | `?int` | Optional | The semester ID for the enrollment (if any). | getSemesterId(): ?int | setSemesterId(?int semesterId): void |
| `isAvailable` | `?bool` | Optional | When `true`, indicates that the enrollment shows in consumer mode, has not started yet, and there is room in each class of the enrollment.<br /><br>When `false`, indicates that either the enrollment does not show in consumer mode, has already started, or there is no room in some classes of the enrollment. | getIsAvailable(): ?bool | setIsAvailable(?bool isAvailable): void |
| `id` | `?int` | Optional | The unique ID of the class schedule. | getId(): ?int | setId(?int id): void |
| `classDescription` | [`?ClassDescription`](../../doc/models/class-description.md) | Optional | Contains information about the class. | getClassDescription(): ?ClassDescription | setClassDescription(?ClassDescription classDescription): void |
| `daySunday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Sundays. | getDaySunday(): ?bool | setDaySunday(?bool daySunday): void |
| `dayMonday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Mondays. | getDayMonday(): ?bool | setDayMonday(?bool dayMonday): void |
| `dayTuesday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Tuesdays. | getDayTuesday(): ?bool | setDayTuesday(?bool dayTuesday): void |
| `dayWednesday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Wednesdays. | getDayWednesday(): ?bool | setDayWednesday(?bool dayWednesday): void |
| `dayThursday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Thursdays. | getDayThursday(): ?bool | setDayThursday(?bool dayThursday): void |
| `dayFriday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Fridays. | getDayFriday(): ?bool | setDayFriday(?bool dayFriday): void |
| `daySaturday` | `?bool` | Optional | When `true`, indicates that this schedule occurs on Saturdays. | getDaySaturday(): ?bool | setDaySaturday(?bool daySaturday): void |
| `allowOpenEnrollment` | `?bool` | Optional | When `true`, indicates that the enrollment allows booking after the enrollment has started. | getAllowOpenEnrollment(): ?bool | setAllowOpenEnrollment(?bool allowOpenEnrollment): void |
| `allowDateForwardEnrollment` | `?bool` | Optional | When `true`, indicates that this the enrollment shows in consumer mode, the enrollment has not started yet, and there is room in each class of the enrollment. | getAllowDateForwardEnrollment(): ?bool | setAllowDateForwardEnrollment(?bool allowDateForwardEnrollment): void |
| `startTime` | `?\DateTime` | Optional | The time this class schedule starts. | getStartTime(): ?\DateTime | setStartTime(?\DateTime startTime): void |
| `endTime` | `?\DateTime` | Optional | The time this class schedule ends. | getEndTime(): ?\DateTime | setEndTime(?\DateTime endTime): void |
| `startDate` | `?\DateTime` | Optional | The date this class schedule starts. | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | The date this class schedule ends. | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `staff` | [`?Staff`](../../doc/models/staff.md) | Optional | Contains information about the staff member who is regularly scheduled to teach the class. | getStaff(): ?Staff | setStaff(?Staff staff): void |
| `location` | [`?Location`](../../doc/models/location.md) | Optional | Contains information about the regularly scheduled location of this class. | getLocation(): ?Location | setLocation(?Location location): void |

## Example (as JSON)

```json
{
  "Classes": null,
  "Clients": null,
  "Course": null,
  "SemesterId": null,
  "IsAvailable": null,
  "Id": null,
  "ClassDescription": null,
  "DaySunday": null,
  "DayMonday": null,
  "DayTuesday": null,
  "DayWednesday": null,
  "DayThursday": null,
  "DayFriday": null,
  "DaySaturday": null,
  "AllowOpenEnrollment": null,
  "AllowDateForwardEnrollment": null,
  "StartTime": null,
  "EndTime": null,
  "StartDate": null,
  "EndDate": null,
  "Staff": null,
  "Location": null
}
```

