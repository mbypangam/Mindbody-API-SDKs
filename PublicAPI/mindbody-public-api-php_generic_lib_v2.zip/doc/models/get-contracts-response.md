
# Get Contracts Response

## Structure

`GetContractsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `contracts` | [`?(MindbodyPublicApiDtoModelsV6Contract[])`](../../doc/models/mindbody-public-api-dto-models-v6-contract.md) | Optional | Contains information about each contract. | getContracts(): ?array | setContracts(?array contracts): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Contracts": null
}
```

