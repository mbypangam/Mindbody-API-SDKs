
# Contact Log Type

A contact log type.

## Structure

`ContactLogType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The Id of the contactlog Type. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the contactlog Type. | getName(): ?string | setName(?string name): void |
| `subTypes` | [`?(ContactLogSubType[])`](../../doc/models/contact-log-sub-type.md) | Optional | Contains the SubType objects, each of which describes the subtypes for a contactlog Type. | getSubTypes(): ?array | setSubTypes(?array subTypes): void |

## Example (as JSON)

```json
{
  "Id": 80,
  "Name": "Name6",
  "SubTypes": [
    {
      "Id": 102,
      "Name": "Name6"
    },
    {
      "Id": 102,
      "Name": "Name6"
    },
    {
      "Id": 102,
      "Name": "Name6"
    }
  ]
}
```

