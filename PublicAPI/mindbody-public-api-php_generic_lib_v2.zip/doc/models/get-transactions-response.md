
# Get Transactions Response

Get Transactions Response Properties

## Structure

`GetTransactionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `transactions` | [`?(Transaction[])`](../../doc/models/transaction.md) | Optional | Contains the transaction objects, each of which describes the transaction details for a purchase event. | getTransactions(): ?array | setTransactions(?array transactions): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Transactions": null
}
```

