
# Get Transactions Response

Transactions Response Properties

## Structure

`GetTransactionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `transactions` | [`?(MindbodyPublicApiDtoModelsV6Transaction[])`](../../doc/models/mindbody-public-api-dto-models-v6-transaction.md) | Optional | Contains the transaction objects, each of which describes the transaction details for a purchase event. | getTransactions(): ?array | setTransactions(?array transactions): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Transactions": null
}
```

