
# Get Client Indexes Response

## Structure

`GetClientIndexesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientIndexes` | [`?(ClientIndex[])`](../../doc/models/client-index.md) | Optional | Contains information about the client indexes. | getClientIndexes(): ?array | setClientIndexes(?array clientIndexes): void |

## Example (as JSON)

```json
{
  "ClientIndexes": [
    {
      "Id": 252,
      "Name": "Name0",
      "RequiredBusinessMode": false,
      "RequiredConsumerMode": false,
      "Values": [
        {
          "Active": false,
          "Id": 84,
          "Name": "Name6"
        },
        {
          "Active": true,
          "Id": 85,
          "Name": "Name7"
        },
        {
          "Active": false,
          "Id": 86,
          "Name": "Name8"
        }
      ]
    },
    {
      "Id": 253,
      "Name": "Name1",
      "RequiredBusinessMode": true,
      "RequiredConsumerMode": true,
      "Values": [
        {
          "Active": true,
          "Id": 85,
          "Name": "Name7"
        }
      ]
    },
    {
      "Id": 254,
      "Name": "Name2",
      "RequiredBusinessMode": false,
      "RequiredConsumerMode": false,
      "Values": [
        {
          "Active": false,
          "Id": 86,
          "Name": "Name8"
        },
        {
          "Active": true,
          "Id": 87,
          "Name": "Name9"
        }
      ]
    }
  ]
}
```

