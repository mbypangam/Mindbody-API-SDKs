
# Get Client Indexes Response

## Structure

`GetClientIndexesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientIndexes` | [`?(ClientIndex[])`](../../doc/models/client-index.md) | Optional | Contains information about the client indexes. | getClientIndexes(): ?array | setClientIndexes(?array clientIndexes): void |

## Example (as JSON)

```json
{
  "ClientIndexes": null
}
```

