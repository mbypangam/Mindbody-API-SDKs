
# Get Client Indexes Response

## Structure

`GetClientIndexesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientIndexes` | [`?(MindbodyPublicApiDtoModelsV6ClientIndex[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-index.md) | Optional | Contains information about the client indexes. | getClientIndexes(): ?array | setClientIndexes(?array clientIndexes): void |

## Example (as JSON)

```json
{
  "ClientIndexes": null
}
```

