
# Update Client Contract Autopays Request

## Structure

`UpdateClientContractAutopaysRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientContractId` | `?int` | Optional | Client Contract Id | getClientContractId(): ?int | setClientContractId(?int clientContractId): void |
| `autopayStartDate` | `?\DateTime` | Optional | Autopay start date | getAutopayStartDate(): ?\DateTime | setAutopayStartDate(?\DateTime autopayStartDate): void |
| `autopayEndDate` | `?\DateTime` | Optional | (optional) - Indefinite if not provided | getAutopayEndDate(): ?\DateTime | setAutopayEndDate(?\DateTime autopayEndDate): void |
| `productId` | `?int` | Optional | Product Id to update (optional if contract has only one product) | getProductId(): ?int | setProductId(?int productId): void |
| `replaceWithProductId` | `?int` | Optional | (optional) - Replaces the product with this product | getReplaceWithProductId(): ?int | setReplaceWithProductId(?int replaceWithProductId): void |
| `amount` | `?float` | Optional | Overrides autopay amount or amount that would come from ProductId | getAmount(): ?float | setAmount(?float amount): void |

## Example (as JSON)

```json
{
  "ClientContractId": null,
  "AutopayStartDate": null,
  "AutopayEndDate": null,
  "ProductId": null,
  "ReplaceWithProductId": null,
  "Amount": null
}
```

