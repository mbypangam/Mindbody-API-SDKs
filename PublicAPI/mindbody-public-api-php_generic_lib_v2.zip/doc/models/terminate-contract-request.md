
# Terminate Contract Request

## Structure

`TerminateContractRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `string` | Required | The ID of the client. | getClientId(): string | setClientId(string clientId): void |
| `clientContractId` | `int` | Required | The unique ID of the sale of the contract | getClientContractId(): int | setClientContractId(int clientContractId): void |
| `terminationDate` | `\DateTime` | Required | The contract termination date. | getTerminationDate(): \DateTime | setTerminationDate(\DateTime terminationDate): void |
| `terminationCode` | `?string` | Optional | ex. Illness, Injury, Moving, BreakingContract (Note this can be customized by each studio). | getTerminationCode(): ?string | setTerminationCode(?string terminationCode): void |
| `terminationComments` | `?string` | Optional | The comments for terminating a contract. | getTerminationComments(): ?string | setTerminationComments(?string terminationComments): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "ClientContractId": 86,
  "TerminationDate": "2016-03-13T12:52:32.123Z",
  "TerminationCode": null,
  "TerminationComments": null
}
```

