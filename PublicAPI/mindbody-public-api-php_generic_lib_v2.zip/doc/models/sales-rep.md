
# Sales Rep

## Structure

`SalesRep`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `firstName` | `?string` | Optional | The first name of the sales representative. | getFirstName(): ?string | setFirstName(?string firstName): void |
| `id` | `?int` | Optional | The staff ID of the sales representative. | getId(): ?int | setId(?int id): void |
| `lastName` | `?string` | Optional | The last name of the sales representative. | getLastName(): ?string | setLastName(?string lastName): void |
| `salesRepNumber` | `?int` | Optional | This value is the number that identifies the type of sales representative assigned to this client. One to six types of sales representatives can be assigned to a client at any given time, depending on site settings. | getSalesRepNumber(): ?int | setSalesRepNumber(?int salesRepNumber): void |
| `salesRepNumbers` | `?(int[])` | Optional | A list of the different types of sales representative functions assigned to this staff member. | getSalesRepNumbers(): ?array | setSalesRepNumbers(?array salesRepNumbers): void |

## Example (as JSON)

```json
{
  "FirstName": "FirstName4",
  "Id": 146,
  "LastName": "LastName4",
  "SalesRepNumber": 244,
  "SalesRepNumbers": [
    70,
    71,
    72
  ]
}
```

