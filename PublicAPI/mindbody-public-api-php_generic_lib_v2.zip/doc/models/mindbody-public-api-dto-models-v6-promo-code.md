
# Mindbody Public Api Dto Models V6 Promo Code

## Structure

`MindbodyPublicApiDtoModelsV6PromoCode`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | Name of the promo code | getName(): ?string | setName(?string name): void |
| `code` | `?string` | Optional | Code to be used at purchase for discount | getCode(): ?string | setCode(?string code): void |
| `active` | `?bool` | Optional | Active status | getActive(): ?bool | setActive(?bool active): void |
| `discount` | [`?MindbodyPublicApiDtoModelsV6Discount`](../../doc/models/mindbody-public-api-dto-models-v6-discount.md) | Optional | Discount for a promo code | getDiscount(): ?MindbodyPublicApiDtoModelsV6Discount | setDiscount(?MindbodyPublicApiDtoModelsV6Discount discount): void |
| `activationDate` | `?\DateTime` | Optional | Date activated | getActivationDate(): ?\DateTime | setActivationDate(?\DateTime activationDate): void |
| `expirationDate` | `?\DateTime` | Optional | Date expired | getExpirationDate(): ?\DateTime | setExpirationDate(?\DateTime expirationDate): void |
| `maxUses` | `?int` | Optional | How many times it can be used | getMaxUses(): ?int | setMaxUses(?int maxUses): void |
| `numberOfAutopays` | `?int` | Optional | Number of Autopays | getNumberOfAutopays(): ?int | setNumberOfAutopays(?int numberOfAutopays): void |
| `daysAfterCloseDate` | `?int` | Optional | Days after close date | getDaysAfterCloseDate(): ?int | setDaysAfterCloseDate(?int daysAfterCloseDate): void |
| `allowOnline` | `?bool` | Optional | Whether it can be used online | getAllowOnline(): ?bool | setAllowOnline(?bool allowOnline): void |
| `daysValid` | [`?(string[]) (DaysValidEnum)`](../../doc/models/days-valid-enum.md) | Optional | What days the promo code can be used | getDaysValid(): ?array | setDaysValid(?array daysValid): void |
| `applicableItems` | [`?(MindbodyPublicApiDtoModelsV6ApplicableItem[])`](../../doc/models/mindbody-public-api-dto-models-v6-applicable-item.md) | Optional | Items that the promo code will have the discount for | getApplicableItems(): ?array | setApplicableItems(?array applicableItems): void |

## Example (as JSON)

```json
{
  "Name": null,
  "Code": null,
  "Active": null,
  "Discount": null,
  "ActivationDate": null,
  "ExpirationDate": null,
  "MaxUses": null,
  "NumberOfAutopays": null,
  "DaysAfterCloseDate": null,
  "AllowOnline": null,
  "DaysValid": null,
  "ApplicableItems": null
}
```

