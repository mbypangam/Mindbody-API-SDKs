
# Mindbody Public Api Dto Models V6 Promo Code

## Structure

`MindbodyPublicApiDtoModelsV6PromoCode`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `name` | `?string` | Optional | Name of the promo code | getName(): ?string | setName(?string name): void |
| `code` | `?string` | Optional | The code of the promocode. | getCode(): ?string | setCode(?string code): void |
| `active` | `?bool` | Optional | Indicates that promocode is active. | getActive(): ?bool | setActive(?bool active): void |
| `discount` | [`?MindbodyPublicApiDtoModelsV6Discount`](../../doc/models/mindbody-public-api-dto-models-v6-discount.md) | Optional | Contains information about the discount. | getDiscount(): ?MindbodyPublicApiDtoModelsV6Discount | setDiscount(?MindbodyPublicApiDtoModelsV6Discount discount): void |
| `activationDate` | `?\DateTime` | Optional | The promocode activation date. | getActivationDate(): ?\DateTime | setActivationDate(?\DateTime activationDate): void |
| `expirationDate` | `?\DateTime` | Optional | The promocode expiration date. | getExpirationDate(): ?\DateTime | setExpirationDate(?\DateTime expirationDate): void |
| `maxUses` | `?int` | Optional | The maximun number of uses. | getMaxUses(): ?int | setMaxUses(?int maxUses): void |
| `numberOfAutopays` | `?int` | Optional | Number of Autopays | getNumberOfAutopays(): ?int | setNumberOfAutopays(?int numberOfAutopays): void |
| `daysAfterCloseDate` | `?int` | Optional | The number of days a client has to use a promocode after they are no longer a prospect. | getDaysAfterCloseDate(): ?int | setDaysAfterCloseDate(?int daysAfterCloseDate): void |
| `allowOnline` | `?bool` | Optional | Indicates if promocode to be redeemed online in consumer mode. | getAllowOnline(): ?bool | setAllowOnline(?bool allowOnline): void |
| `daysValid` | [`?(string[]) (DaysValidEnum)`](../../doc/models/days-valid-enum.md) | Optional | Indicates what days of the week promocode can be redeemed. | getDaysValid(): ?array | setDaysValid(?array daysValid): void |
| `applicableItems` | [`?(MindbodyPublicApiDtoModelsV6ApplicableItem[])`](../../doc/models/mindbody-public-api-dto-models-v6-applicable-item.md) | Optional | Contains information about a promocode applicable items. | getApplicableItems(): ?array | setApplicableItems(?array applicableItems): void |

## Example (as JSON)

```json
{
  "Name": null,
  "Code": null,
  "Active": null,
  "Discount": null,
  "ActivationDate": null,
  "ExpirationDate": null,
  "MaxUses": null,
  "NumberOfAutopays": null,
  "DaysAfterCloseDate": null,
  "AllowOnline": null,
  "DaysValid": null,
  "ApplicableItems": null
}
```

