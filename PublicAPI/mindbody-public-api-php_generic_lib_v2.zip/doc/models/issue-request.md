
# Issue Request

POST UserToken/Issue request

## Structure

`IssueRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `username` | `?string` | Optional | The staff member’s username. | getUsername(): ?string | setUsername(?string username): void |
| `password` | `?string` | Optional | The staff member’s password. | getPassword(): ?string | setPassword(?string password): void |

## Example (as JSON)

```json
{
  "Username": "Username2",
  "Password": "Password4"
}
```

