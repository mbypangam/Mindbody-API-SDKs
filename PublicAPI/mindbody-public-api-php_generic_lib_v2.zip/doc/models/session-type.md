
# Session Type

SessionType contains information about the session types in a business.

## Structure

`SessionType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`?string(TypeEnum)`](../../doc/models/type-enum.md) | Optional | Contains the class description session type. Possible values are:<br><br>* All<br>* Class<br>* Enrollment<br>* Appointment<br>* Resource<br>* Media<br>* Arrival | getType(): ?string | setType(?string type): void |
| `defaultTimeLength` | `?int` | Optional | The default amount of time that a session of this type typically lasts. | getDefaultTimeLength(): ?int | setDefaultTimeLength(?int defaultTimeLength): void |
| `staffTimeLength` | `?int` | Optional | The amount of time that a session of this type will last for a specific Staff (when applicable.) | getStaffTimeLength(): ?int | setStaffTimeLength(?int staffTimeLength): void |
| `id` | `?int` | Optional | This session type’s unique ID. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of this session type. | getName(): ?string | setName(?string name): void |
| `onlineDescription` | `?string` | Optional | The online description associated with the appointment. | getOnlineDescription(): ?string | setOnlineDescription(?string onlineDescription): void |
| `numDeducted` | `?int` | Optional | The number of sessions that this session type deducts from the pricing option used to pay for this type of session. | getNumDeducted(): ?int | setNumDeducted(?int numDeducted): void |
| `programId` | `?int` | Optional | This session type’s service category ID. | getProgramId(): ?int | setProgramId(?int programId): void |
| `category` | `?string` | Optional | This session type’s category. | getCategory(): ?string | setCategory(?string category): void |
| `categoryId` | `?int` | Optional | This session type’s category ID. | getCategoryId(): ?int | setCategoryId(?int categoryId): void |
| `subcategory` | `?string` | Optional | This session type’s subcategory. | getSubcategory(): ?string | setSubcategory(?string subcategory): void |
| `subcategoryId` | `?int` | Optional | This session type’s subcategory ID. | getSubcategoryId(): ?int | setSubcategoryId(?int subcategoryId): void |
| `availableForAddOn` | `?bool` | Optional | This session type’s Add On Flag. | getAvailableForAddOn(): ?bool | setAvailableForAddOn(?bool availableForAddOn): void |

## Example (as JSON)

```json
{
  "Type": "Arrival",
  "DefaultTimeLength": 132,
  "StaffTimeLength": 110,
  "Id": 146,
  "Name": "Name0"
}
```

