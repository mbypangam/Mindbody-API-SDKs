
# Mindbody Public Api Dto Models V6 Client Controller Get Required Client Fields Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `requiredClientFields` | `?(string[])` | Optional | A list of strings that maps to the client fields that are required by the site. | getRequiredClientFields(): ?array | setRequiredClientFields(?array requiredClientFields): void |

## Example (as JSON)

```json
{
  "RequiredClientFields": null
}
```

