
# Lead Channel

## Structure

`LeadChannel`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `salespipelineId` | `?int` | Optional | - | getSalespipelineId(): ?int | setSalespipelineId(?int salespipelineId): void |
| `universalCustomerId` | `?string` | Optional | - | getUniversalCustomerId(): ?string | setUniversalCustomerId(?string universalCustomerId): void |
| `studioId` | `?int` | Optional | - | getStudioId(): ?int | setStudioId(?int studioId): void |

## Example (as JSON)

```json
{
  "Id": 122,
  "Name": "Name2",
  "SalespipelineId": 222,
  "UniversalCustomerId": "00000000-0000-0000-0000-000000000000",
  "StudioId": 118
}
```

