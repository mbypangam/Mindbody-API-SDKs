
# Mindbody Public Api Dto Models V6 Client Credit Card

A client credit card.

## Structure

`MindbodyPublicApiDtoModelsV6ClientCreditCard`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `address` | `?string` | Optional | The billing address for the credit card. | getAddress(): ?string | setAddress(?string address): void |
| `cardHolder` | `?string` | Optional | The name of the card holder. | getCardHolder(): ?string | setCardHolder(?string cardHolder): void |
| `cardNumber` | `?string` | Optional | The credit card number. | getCardNumber(): ?string | setCardNumber(?string cardNumber): void |
| `cardType` | `?string` | Optional | The type of credit card, for example Visa or MasterCard. | getCardType(): ?string | setCardType(?string cardType): void |
| `city` | `?string` | Optional | The city in which the billing address is located. | getCity(): ?string | setCity(?string city): void |
| `expMonth` | `?string` | Optional | The month in which the credit card expires. | getExpMonth(): ?string | setExpMonth(?string expMonth): void |
| `expYear` | `?string` | Optional | The year in which the credit card expires. | getExpYear(): ?string | setExpYear(?string expYear): void |
| `lastFour` | `?string` | Optional | The last four digits of the credit card number. | getLastFour(): ?string | setLastFour(?string lastFour): void |
| `postalCode` | `?string` | Optional | The postal code where the billing address is located. | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `state` | `?string` | Optional | The state that the billing address is located in. | getState(): ?string | setState(?string state): void |

## Example (as JSON)

```json
{
  "Address": null,
  "CardHolder": null,
  "CardNumber": null,
  "CardType": null,
  "City": null,
  "ExpMonth": null,
  "ExpYear": null,
  "LastFour": null,
  "PostalCode": null,
  "State": null
}
```

