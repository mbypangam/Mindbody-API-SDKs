
# Update Service Response

A response from the Update Services API method.

## Structure

`UpdateServiceResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `services` | [`?(Service[])`](../../doc/models/service.md) | Optional | List of services as response | getServices(): ?array | setServices(?array services): void |

## Example (as JSON)

```json
{
  "Services": [
    {
      "Price": 77.35,
      "OnlinePrice": 111.87,
      "TaxIncluded": 184.89,
      "ProgramId": 101,
      "TaxRate": 45.39
    }
  ]
}
```

