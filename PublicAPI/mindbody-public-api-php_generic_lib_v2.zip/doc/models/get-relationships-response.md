
# Get Relationships Response

Get Relationships Response Model

## Structure

`GetRelationshipsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `relationships` | [`?(Relationship[])`](../../doc/models/relationship.md) | Optional | A list of relationships. | getRelationships(): ?array | setRelationships(?array relationships): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Relationships": null
}
```

