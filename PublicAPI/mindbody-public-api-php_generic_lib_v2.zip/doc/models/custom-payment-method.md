
# Custom Payment Method

## Structure

`CustomPaymentMethod`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the custom payment method. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the custom payment method. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": 146,
  "Name": "Name0"
}
```

