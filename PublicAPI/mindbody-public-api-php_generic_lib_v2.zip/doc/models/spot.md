
# Spot

## Structure

`Spot`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reservedSpotNumbers` | `?(int[])` | Optional | - | getReservedSpotNumbers(): ?array | setReservedSpotNumbers(?array reservedSpotNumbers): void |
| `availableSpotNumbers` | `?(int[])` | Optional | - | getAvailableSpotNumbers(): ?array | setAvailableSpotNumbers(?array availableSpotNumbers): void |
| `unavailableSpotNumbers` | `?(int[])` | Optional | - | getUnavailableSpotNumbers(): ?array | setUnavailableSpotNumbers(?array unavailableSpotNumbers): void |

## Example (as JSON)

```json
{
  "ReservedSpotNumbers": null,
  "AvailableSpotNumbers": null,
  "UnavailableSpotNumbers": null
}
```

