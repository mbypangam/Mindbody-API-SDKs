
# Spot

Contains information about the spot details.

## Structure

`Spot`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reservedSpotNumbers` | `?(int[])` | Optional | Contains information about the collection of reserved spot numbers. | getReservedSpotNumbers(): ?array | setReservedSpotNumbers(?array reservedSpotNumbers): void |
| `availableSpotNumbers` | `?(int[])` | Optional | Contains information about the collection of available spot numbers. | getAvailableSpotNumbers(): ?array | setAvailableSpotNumbers(?array availableSpotNumbers): void |
| `unavailableSpotNumbers` | `?(int[])` | Optional | Contains information about the collection of Unavailable spot numbers. | getUnavailableSpotNumbers(): ?array | setUnavailableSpotNumbers(?array unavailableSpotNumbers): void |

## Example (as JSON)

```json
{
  "ReservedSpotNumbers": [
    44,
    45,
    46
  ],
  "AvailableSpotNumbers": [
    28
  ],
  "UnavailableSpotNumbers": [
    41,
    42
  ]
}
```

