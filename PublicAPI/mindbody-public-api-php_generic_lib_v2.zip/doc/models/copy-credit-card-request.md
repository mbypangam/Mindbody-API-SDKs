
# Copy Credit Card Request

crosssite/copycreditcard

## Structure

`CopyCreditCardRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sourceSiteId` | `?int` | Optional | The siteId of the source clientId. | getSourceSiteId(): ?int | setSourceSiteId(?int sourceSiteId): void |
| `sourceClientId` | `?string` | Optional | The clientId at the source siteId. | getSourceClientId(): ?string | setSourceClientId(?string sourceClientId): void |
| `targetSiteId` | `?int` | Optional | The siteId of the target clientId. | getTargetSiteId(): ?int | setTargetSiteId(?int targetSiteId): void |
| `targetClientId` | `?string` | Optional | The clientId at the target siteId. | getTargetClientId(): ?string | setTargetClientId(?string targetClientId): void |

## Example (as JSON)

```json
{
  "SourceSiteId": 74,
  "SourceClientId": "SourceClientId2",
  "TargetSiteId": 250,
  "TargetClientId": "TargetClientId8"
}
```

