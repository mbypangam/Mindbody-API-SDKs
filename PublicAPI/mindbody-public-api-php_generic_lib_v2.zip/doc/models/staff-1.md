
# Staff 1

## Structure

`Staff1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID assigned to the staff member. | getId(): ?int | setId(?int id): void |
| `firstName` | `?string` | Optional | The staff member’s first name. | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | The staff member’s last name. | getLastName(): ?string | setLastName(?string lastName): void |
| `displayName` | `?string` | Optional | The display name of the staff member. | getDisplayName(): ?string | setDisplayName(?string displayName): void |
| `email` | `?string` | Optional | The staff member’s email address. | getEmail(): ?string | setEmail(?string email): void |
| `bio` | `?string` | Optional | The staff member’s biography. This string contains HTML. | getBio(): ?string | setBio(?string bio): void |
| `address` | `?string` | Optional | The address of the staff member who is teaching the class. | getAddress(): ?string | setAddress(?string address): void |
| `address2` | `?string` | Optional | The address2 of the staff member who is teaching the class. | getAddress2(): ?string | setAddress2(?string address2): void |
| `city` | `?string` | Optional | The staff member’s city. | getCity(): ?string | setCity(?string city): void |
| `state` | `?string` | Optional | The staff member’s state. | getState(): ?string | setState(?string state): void |
| `postalCode` | `?string` | Optional | The staff member’s postal code. | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `foreignZip` | `?string` | Optional | The staff member’s Foreign Zip code. | getForeignZip(): ?string | setForeignZip(?string foreignZip): void |
| `country` | `?string` | Optional | The staff member’s country. | getCountry(): ?string | setCountry(?string country): void |
| `workPhone` | `?string` | Optional | The staff member’s work phone number. | getWorkPhone(): ?string | setWorkPhone(?string workPhone): void |
| `homePhone` | `?string` | Optional | The staff member’s home phone number. | getHomePhone(): ?string | setHomePhone(?string homePhone): void |
| `cellPhone` | `?string` | Optional | The staff member’s mobile phone number. | getCellPhone(): ?string | setCellPhone(?string cellPhone): void |
| `active` | `?bool` | Optional | When `true`, indicates that the staff member is Active.<br>When `false`, indicates that the staff member is not Active. | getActive(): ?bool | setActive(?bool active): void |
| `isSystem` | `?bool` | Optional | When `true`, indicates that the staff member is a system .<br>When `false`, indicates that the staff member is not system. | getIsSystem(): ?bool | setIsSystem(?bool isSystem): void |
| `smodeId` | `?int` | Optional | The Staff's Smode Id | getSmodeId(): ?int | setSmodeId(?int smodeId): void |
| `appointmentTrn` | `?bool` | Optional | When `true`, indicates that the staff member offers appointments.<br>When `false`, indicates that the staff member does not offer appointments. | getAppointmentTrn(): ?bool | setAppointmentTrn(?bool appointmentTrn): void |
| `alwaysAllowDoubleBooking` | `?bool` | Optional | When `true`, indicates that the staff member can be scheduled for overlapping services.<br>When `false`, indicates that the staff can only be scheduled for one service at a time in any given time-frame. | getAlwaysAllowDoubleBooking(): ?bool | setAlwaysAllowDoubleBooking(?bool alwaysAllowDoubleBooking): void |
| `independentContractor` | `?bool` | Optional | When `true`, indicates that the staff member is an independent contractor.<br>When `false`, indicates that the staff member is not an independent contractor. | getIndependentContractor(): ?bool | setIndependentContractor(?bool independentContractor): void |
| `imageUrl` | `?string` | Optional | The URL of the staff member’s image, if one has been uploaded. | getImageUrl(): ?string | setImageUrl(?string imageUrl): void |
| `isMale` | `?bool` | Optional | When `true`, indicates that the staff member is male.<br>When `false`, indicates that the staff member is female. | getIsMale(): ?bool | setIsMale(?bool isMale): void |
| `reservationTrn` | `?bool` | Optional | When `true`, indicates that the staff member offers Reservation.<br>When `false`, indicates that the staff member does not offer Reservation. | getReservationTrn(): ?bool | setReservationTrn(?bool reservationTrn): void |
| `sortOrder` | `?int` | Optional | If configured by the business owner, this field determines a staff member’s weight when sorting. Use this field to sort staff members on your interface. | getSortOrder(): ?int | setSortOrder(?int sortOrder): void |
| `multiLocationPermission` | `?bool` | Optional | When `true`, indicates that the staff member has Multi Location Permission.<br>When `false`, indicates that the staff member does not has Multi Location Permission. | getMultiLocationPermission(): ?bool | setMultiLocationPermission(?bool multiLocationPermission): void |
| `name` | `?string` | Optional | The staff member’s name. | getName(): ?string | setName(?string name): void |
| `providerIDs` | `?(string[])` | Optional | A list of ProviderIds for the staff. | getProviderIDs(): ?array | setProviderIDs(?array providerIDs): void |
| `staffSettings` | [`?StaffSetting`](../../doc/models/staff-setting.md) | Optional | contains the information about the staff settings. | getStaffSettings(): ?StaffSetting | setStaffSettings(?StaffSetting staffSettings): void |
| `rep` | `?bool` | Optional | When `true`, indicates that the staff is sales Rep 1 else `false`. | getRep(): ?bool | setRep(?bool rep): void |
| `rep2` | `?bool` | Optional | When `true`, indicates that the staff is sales Rep 2 else `false`. | getRep2(): ?bool | setRep2(?bool rep2): void |
| `rep3` | `?bool` | Optional | When `true`, indicates that the staff is sales Rep 3 else `false`. | getRep3(): ?bool | setRep3(?bool rep3): void |
| `rep4` | `?bool` | Optional | When `true`, indicates that the staff is sales Rep 4 else `false`. | getRep4(): ?bool | setRep4(?bool rep4): void |
| `rep5` | `?bool` | Optional | When `true`, indicates that the staff is sales Rep 5 else `false`. | getRep5(): ?bool | setRep5(?bool rep5): void |
| `rep6` | `?bool` | Optional | When `true`, indicates that the staff is sales Rep 6 else `false`. | getRep6(): ?bool | setRep6(?bool rep6): void |
| `assistant` | `?bool` | Optional | When `true`, indicates that the staff is assistant.<br>When `false`, indicates that the staff is not assistant. | getAssistant(): ?bool | setAssistant(?bool assistant): void |
| `assistant2` | `?bool` | Optional | When `true`, indicates that the staff is assistant2.<br>When `false`, indicates that the staff is not assistant2. | getAssistant2(): ?bool | setAssistant2(?bool assistant2): void |
| `employmentStart` | `?\DateTime` | Optional | The start date of employment. | getEmploymentStart(): ?\DateTime | setEmploymentStart(?\DateTime employmentStart): void |
| `employmentEnd` | `?\DateTime` | Optional | The end date of employment. | getEmploymentEnd(): ?\DateTime | setEmploymentEnd(?\DateTime employmentEnd): void |
| `empID` | `?string` | Optional | The custom staff ID assigned to the staff member. | getEmpID(): ?string | setEmpID(?string empID): void |
| `appointments` | [`?(Appointment1[])`](../../doc/models/appointment-1.md) | Optional | A list of appointments for the staff. | getAppointments(): ?array | setAppointments(?array appointments): void |
| `unavailabilities` | [`?(Unavailability1[])`](../../doc/models/unavailability-1.md) | Optional | A list of unavailabilities for the staff. | getUnavailabilities(): ?array | setUnavailabilities(?array unavailabilities): void |
| `availabilities` | [`?(Availability1[])`](../../doc/models/availability-1.md) | Optional | A list of availabilities for the staff. | getAvailabilities(): ?array | setAvailabilities(?array availabilities): void |
| `loginLocations` | [`?(Location1[])`](../../doc/models/location-1.md) | Optional | A list of LoginLocations for the staff | getLoginLocations(): ?array | setLoginLocations(?array loginLocations): void |

## Example (as JSON)

```json
{
  "Id": 146,
  "FirstName": "FirstName4",
  "LastName": "LastName4",
  "DisplayName": "DisplayName6",
  "Email": "Email4"
}
```

