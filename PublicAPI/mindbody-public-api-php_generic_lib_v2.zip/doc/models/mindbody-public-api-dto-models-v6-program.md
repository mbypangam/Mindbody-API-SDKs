
# Mindbody Public Api Dto Models V6 Program

## Structure

`MindbodyPublicApiDtoModelsV6Program`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The service category?s ID. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of this service category. | getName(): ?string | setName(?string name): void |
| `scheduleType` | [`?string (ScheduleTypeEnum)`](../../doc/models/schedule-type-enum.md) | Optional | The service category?s schedule type. Possible values are:<br><br>* All<br>* Class<br>* Enrollment<br>* Appointment<br>* Resource<br>* Arrival | getScheduleType(): ?string | setScheduleType(?string scheduleType): void |
| `cancelOffset` | `?int` | Optional | The offset to use for the service category. | getCancelOffset(): ?int | setCancelOffset(?int cancelOffset): void |
| `contentFormats` | `?(string[])` | Optional | The content delivery platform(s) used by the service category. Possible values are:<br><br>* InPerson<br>* Livestream:Mindbody<br>* Livestream:Other | getContentFormats(): ?array | setContentFormats(?array contentFormats): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "ScheduleType": null,
  "CancelOffset": null,
  "ContentFormats": null
}
```

