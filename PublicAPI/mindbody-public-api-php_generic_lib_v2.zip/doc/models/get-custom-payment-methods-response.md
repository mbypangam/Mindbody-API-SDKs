
# Get Custom Payment Methods Response

## Structure

`GetCustomPaymentMethodsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `paymentMethods` | [`?(CustomPaymentMethod[])`](../../doc/models/custom-payment-method.md) | Optional | Contains information about the custom payment methods. | getPaymentMethods(): ?array | setPaymentMethods(?array paymentMethods): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "PaymentMethods": null
}
```

