
# Gift Card Layout

Gift card layout

## Structure

`GiftCardLayout`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `layoutId` | `?int` | Optional | The ID of the layout. | getLayoutId(): ?int | setLayoutId(?int layoutId): void |
| `layoutName` | `?string` | Optional | The name of the layout. | getLayoutName(): ?string | setLayoutName(?string layoutName): void |
| `layoutUrl` | `?string` | Optional | The URL of the layout. | getLayoutUrl(): ?string | setLayoutUrl(?string layoutUrl): void |

## Example (as JSON)

```json
{
  "LayoutId": null,
  "LayoutName": null,
  "LayoutUrl": null
}
```

