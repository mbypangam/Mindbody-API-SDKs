
# Mindbody Public Api Dto Models V6 Amenity

Definition of a location amenity

## Structure

`MindbodyPublicApiDtoModelsV6Amenity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID number of the amenity. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the amenity, for example, food or lockers. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

