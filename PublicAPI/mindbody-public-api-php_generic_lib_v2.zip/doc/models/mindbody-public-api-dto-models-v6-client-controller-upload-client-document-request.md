
# Mindbody Public Api Dto Models V6 Client Controller Upload Client Document Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `string` | Required | The RSSID of the client for whom the document is to be uploaded. | getClientId(): string | setClientId(string clientId): void |
| `file` | [`MindbodyPublicApiDtoModelsV6ClientDocument`](../../doc/models/mindbody-public-api-dto-models-v6-client-document.md) | Required | - | getFile(): MindbodyPublicApiDtoModelsV6ClientDocument | setFile(MindbodyPublicApiDtoModelsV6ClientDocument file): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "File": {
    "FileName": "FileName6",
    "MediaType": "MediaType6",
    "Buffer": "Buffer8"
  }
}
```

