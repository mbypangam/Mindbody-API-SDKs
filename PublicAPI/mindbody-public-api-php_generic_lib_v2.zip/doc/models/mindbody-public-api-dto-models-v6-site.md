
# Mindbody Public Api Dto Models V6 Site

## Structure

`MindbodyPublicApiDtoModelsV6Site`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `acceptsAmericanExpress` | `?bool` | Optional | When `true`, indicates that this site accepts American Express cards.<br /><br>When `false`, indicates that this site does not accept American Express credit cards. | getAcceptsAmericanExpress(): ?bool | setAcceptsAmericanExpress(?bool acceptsAmericanExpress): void |
| `acceptsDiscover` | `?bool` | Optional | When `true`, indicates that this site accepts Discover cards.<br /><br>When `false`, indicates that this site does not accept Discover credit cards. | getAcceptsDiscover(): ?bool | setAcceptsDiscover(?bool acceptsDiscover): void |
| `acceptsMasterCard` | `?bool` | Optional | When `true`, indicates that this site accepts MasterCard cards.<br /><br>When `false`, indicates that this site does not accept MasterCard credit cards. | getAcceptsMasterCard(): ?bool | setAcceptsMasterCard(?bool acceptsMasterCard): void |
| `acceptsVisa` | `?bool` | Optional | When `true`, indicates that this site accepts Visa cards.<br /><br>When `false`, indicates that this site does not accept Visa credit cards. | getAcceptsVisa(): ?bool | setAcceptsVisa(?bool acceptsVisa): void |
| `allowsDashboardAccess` | `?bool` | Optional | When `true`, indicates that this site allows access to its dashboard.<br /><br>When `false`, indicates that this site does not allow access to its dashboard. | getAllowsDashboardAccess(): ?bool | setAllowsDashboardAccess(?bool allowsDashboardAccess): void |
| `contactEmail` | `?string` | Optional | The site’s email address. | getContactEmail(): ?string | setContactEmail(?string contactEmail): void |
| `description` | `?string` | Optional | A description of the site. | getDescription(): ?string | setDescription(?string description): void |
| `id` | `?int` | Optional | The site ID. | getId(): ?int | setId(?int id): void |
| `logoUrl` | `?string` | Optional | The URL to the site’s logo. | getLogoUrl(): ?string | setLogoUrl(?string logoUrl): void |
| `name` | `?string` | Optional | The name of the site. | getName(): ?string | setName(?string name): void |
| `pageColor1` | `?string` | Optional | A hex code for a color the business owner uses in marketing. This color can be used to set a theme for an integration so that it matches the configured color-scheme for the business. | getPageColor1(): ?string | setPageColor1(?string pageColor1): void |
| `pageColor2` | `?string` | Optional | The hex code for a second color, to be used in the same manner as `pageColor1`. | getPageColor2(): ?string | setPageColor2(?string pageColor2): void |
| `pageColor3` | `?string` | Optional | The hex code for a third color, to be used in the same manner as `pageColor1`. | getPageColor3(): ?string | setPageColor3(?string pageColor3): void |
| `pageColor4` | `?string` | Optional | The hex code for a fourth color, to be used in the same manner as `pageColor1`. | getPageColor4(): ?string | setPageColor4(?string pageColor4): void |
| `pricingLevel` | `?string` | Optional | The MINDBODY pricing level for the business. Possible values are:<br>Accelerate - The business is on MINDBODY’s Accelerate pricing tier.<br>Grow - The business is on MINDBODY’s Essential pricing tier.<br>Legacy - The business is on an older MINDBODY pricing tier that is no longer offered.<br>Listing - The business is on an older MINDBODY pricing tier that is no longer offered.<br>Pro - The business is on an older MINDBODY pricing tier that is no longer offered.<br>Solo - The business is on an older MINDBODY pricing tier that is no longer offered.<br>Ultimate - The business is on MINDBODY’s Ultimate pricing tier. | getPricingLevel(): ?string | setPricingLevel(?string pricingLevel): void |
| `smsPackageEnabled` | `?bool` | Optional | When `true`, indicates that the business uses SMS text messages to communicate with its clients.<br /><br>When `false`, indicates that the business does not use SMS text messages to communicate with its clients. | getSmsPackageEnabled(): ?bool | setSmsPackageEnabled(?bool smsPackageEnabled): void |
| `taxInclusivePrices` | `?bool` | Optional | When `true`, indicates that the total includes tax.<br /><br>When `false`, indicates that the total does not include tax. | getTaxInclusivePrices(): ?bool | setTaxInclusivePrices(?bool taxInclusivePrices): void |
| `currencyIsoCode` | `?string` | Optional | The currency ISO code for the site. | getCurrencyIsoCode(): ?string | setCurrencyIsoCode(?string currencyIsoCode): void |
| `countryCode` | `?string` | Optional | The country code for the site. | getCountryCode(): ?string | setCountryCode(?string countryCode): void |
| `timeZone` | `?string` | Optional | The time zone the site is located in. | getTimeZone(): ?string | setTimeZone(?string timeZone): void |
| `acceptsDirectDebit` | `?bool` | Optional | When `true`, indicates that direct debit can be used by clients at this site.<br /><br>When `false`, indicates that direct debit can not by used by clients at this site. | getAcceptsDirectDebit(): ?bool | setAcceptsDirectDebit(?bool acceptsDirectDebit): void |
| `leadChannels` | [`?(MindbodyPublicApiCommonModelsLeadChannel[])`](../../doc/models/mindbody-public-api-common-models-lead-channel.md) | Optional | The list of lead channels available for a subscriber/studio. | getLeadChannels(): ?array | setLeadChannels(?array leadChannels): void |

## Example (as JSON)

```json
{
  "AcceptsAmericanExpress": null,
  "AcceptsDiscover": null,
  "AcceptsMasterCard": null,
  "AcceptsVisa": null,
  "AllowsDashboardAccess": null,
  "ContactEmail": null,
  "Description": null,
  "Id": null,
  "LogoUrl": null,
  "Name": null,
  "PageColor1": null,
  "PageColor2": null,
  "PageColor3": null,
  "PageColor4": null,
  "PricingLevel": null,
  "SmsPackageEnabled": null,
  "TaxInclusivePrices": null,
  "CurrencyIsoCode": null,
  "CountryCode": null,
  "TimeZone": null,
  "AcceptsDirectDebit": null,
  "LeadChannels": null
}
```

