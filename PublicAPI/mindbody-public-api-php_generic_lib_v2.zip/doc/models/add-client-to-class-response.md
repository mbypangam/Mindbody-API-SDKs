
# Add Client to Class Response

## Structure

`AddClientToClassResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `visit` | [`?AddClientToClassVisit`](../../doc/models/add-client-to-class-visit.md) | Optional | - | getVisit(): ?AddClientToClassVisit | setVisit(?AddClientToClassVisit visit): void |

## Example (as JSON)

```json
{
  "Visit": null
}
```

