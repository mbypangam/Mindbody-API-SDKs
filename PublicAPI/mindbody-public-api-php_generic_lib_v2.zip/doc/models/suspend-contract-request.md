
# Suspend Contract Request

## Structure

`SuspendContractRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `string` | Required | The ID of the client. | getClientId(): string | setClientId(string clientId): void |
| `clientContractId` | `int` | Required | The unique ID of the sale of the contract. | getClientContractId(): int | setClientContractId(int clientContractId): void |
| `suspensionType` | `?string` | Optional | ex. Illness, Injury, Vacation. (Note this can be customized by each studio).<br>If provided, then Duration, DurationUnit, and SuspensionFee (if applicable) are automatically applied. Restrict Days are not supported. | getSuspensionType(): ?string | setSuspensionType(?string suspensionType): void |
| `suspensionStart` | `?DateTime` | Optional | The contract suspension start date.<br>Default: *today’s date* | getSuspensionStart(): ?\DateTime | setSuspensionStart(?\DateTime suspensionStart): void |
| `duration` | `?int` | Optional | The number of (DurationUnit) the suspension lasts. | getDuration(): ?int | setDuration(?int duration): void |
| `durationUnit` | `?int` | Optional | The unit applied to Duration. | getDurationUnit(): ?int | setDurationUnit(?int durationUnit): void |
| `openEnded` | `?bool` | Optional | When `true`, indicates that suspension is open ended. Also, when `true`, then Duration and DurationUnit are ignored.<br>Default: *false* | getOpenEnded(): ?bool | setOpenEnded(?bool openEnded): void |
| `suspensionNotes` | `?string` | Optional | The comments for suspending a contract. | getSuspensionNotes(): ?string | setSuspensionNotes(?string suspensionNotes): void |
| `suspensionFee` | `?float` | Optional | An optional charge that clients who wish to pause a contract for a set period of time can be charged. | getSuspensionFee(): ?float | setSuspensionFee(?float suspensionFee): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "ClientContractId": 122,
  "SuspensionType": "SuspensionType6",
  "SuspensionStart": "2016-03-13T12:52:32.123Z",
  "Duration": 228,
  "DurationUnit": 106,
  "OpenEnded": false
}
```

