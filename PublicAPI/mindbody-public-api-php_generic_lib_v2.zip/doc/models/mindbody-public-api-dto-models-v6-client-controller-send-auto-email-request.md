
# Mindbody Public Api Dto Models V6 Client Controller Send Auto Email Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `string` | Required | The ID of the client email will be sent to. | getClientId(): string | setClientId(string clientId): void |
| `emailType` | `string` | Required | The type of the email that will be sent to a client.<br>Possible values are:<br><br>* BusinessWelcomeEmail<br>* ConsumerWelcomeEmail | getEmailType(): string | setEmailType(string emailType): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "EmailType": "EmailType8"
}
```

