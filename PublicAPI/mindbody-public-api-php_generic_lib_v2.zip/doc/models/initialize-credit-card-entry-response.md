
# Initialize Credit Card Entry Response

## Structure

`InitializeCreditCardEntryResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `callbackUrl` | `?string` | Optional | - | getCallbackUrl(): ?string | setCallbackUrl(?string callbackUrl): void |

## Example (as JSON)

```json
{
  "CallbackUrl": null
}
```

