
# Get Add Ons Response

Get AddOns Response Model

## Structure

`GetAddOnsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `addOns` | [`?(AppointmentAddOn[])`](../../doc/models/appointment-add-on.md) | Optional | A list of available add-ons. | getAddOns(): ?array | setAddOns(?array addOns): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "AddOns": null
}
```

