
# Alternative Payment Method

DTO object for alternative payment methods.

## Structure

`AlternativePaymentMethod`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the alternative payment method. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the alternative payment method. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": 24,
  "Name": "Name4"
}
```

