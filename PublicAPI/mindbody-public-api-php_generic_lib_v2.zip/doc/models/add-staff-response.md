
# Add Staff Response

## Structure

`AddStaffResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staff` | [`?Staff`](../../doc/models/staff.md) | Optional | Contains information about the staff | getStaff(): ?Staff | setStaff(?Staff staff): void |

## Example (as JSON)

```json
{
  "Staff": null
}
```

