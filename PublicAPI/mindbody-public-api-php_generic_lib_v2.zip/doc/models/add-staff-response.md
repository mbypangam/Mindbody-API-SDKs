
# Add Staff Response

## Structure

`AddStaffResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staff` | [`?MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Contains information about the staff | getStaff(): ?MindbodyPublicApiDtoModelsV6Staff | setStaff(?MindbodyPublicApiDtoModelsV6Staff staff): void |

## Example (as JSON)

```json
{
  "Staff": null
}
```

