
# Get Bookable Items Response

## Structure

`GetBookableItemsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `availabilities` | [`?(MindbodyPublicApiDtoModelsV6Availability[])`](../../doc/models/mindbody-public-api-dto-models-v6-availability.md) | Optional | Contains information about the availabilities for appointment booking. | getAvailabilities(): ?array | setAvailabilities(?array availabilities): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Availabilities": null
}
```

