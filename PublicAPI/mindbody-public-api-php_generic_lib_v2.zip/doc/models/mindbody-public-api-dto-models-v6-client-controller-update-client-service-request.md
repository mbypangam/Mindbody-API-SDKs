
# Mindbody Public Api Dto Models V6 Client Controller Update Client Service Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `serviceId` | `int` | Required | The ID of the service to update. | getServiceId(): int | setServiceId(int serviceId): void |
| `activeDate` | `?\DateTime` | Optional | The date that the service became active. | getActiveDate(): ?\DateTime | setActiveDate(?\DateTime activeDate): void |
| `expirationDate` | `?\DateTime` | Optional | The date that the service is to expire. | getExpirationDate(): ?\DateTime | setExpirationDate(?\DateTime expirationDate): void |
| `count` | `?int` | Optional | The number of client service sessions to update. | getCount(): ?int | setCount(?int count): void |
| `test` | `?bool` | Optional | When `true`, indicates that input information is to be validated, but not committed.<br /><br>When `false` or omitted, the database is affected.<br /><br>Default: **false** | getTest(): ?bool | setTest(?bool test): void |

## Example (as JSON)

```json
{
  "ServiceId": 158,
  "ActiveDate": null,
  "ExpirationDate": null,
  "Count": null,
  "Test": null
}
```

