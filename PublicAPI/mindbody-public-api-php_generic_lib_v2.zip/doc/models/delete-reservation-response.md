
# Delete Reservation Response

## Structure

`DeleteReservationResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `deleteSucceeded` | `?bool` | Optional | delete successded status. | getDeleteSucceeded(): ?bool | setDeleteSucceeded(?bool deleteSucceeded): void |
| `responseDetail` | [`?ResponseDetails`](../../doc/models/response-details.md) | Optional | Response details information. | getResponseDetail(): ?ResponseDetails | setResponseDetail(?ResponseDetails responseDetail): void |

## Example (as JSON)

```json
{
  "DeleteSucceeded": null,
  "ResponseDetail": null
}
```

