
# Get Unavailabilities Response

## Structure

`GetUnavailabilitiesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `unavailabilities` | [`?(MindbodyPublicApiDtoModelsV6UnavailabilityPlain[])`](../../doc/models/mindbody-public-api-dto-models-v6-unavailability-plain.md) | Optional | Contains information about unavailabilities | getUnavailabilities(): ?array | setUnavailabilities(?array unavailabilities): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Unavailabilities": null
}
```

