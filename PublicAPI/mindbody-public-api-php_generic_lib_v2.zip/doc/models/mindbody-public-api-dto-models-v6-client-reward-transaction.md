
# Mindbody Public Api Dto Models V6 Client Reward Transaction

Contains information about the transaction details.

## Structure

`MindbodyPublicApiDtoModelsV6ClientRewardTransaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `actionDateTime` | `?\DateTime` | Optional | The date and time when the points were earned or redeemed in the site local time zone. | getActionDateTime(): ?\DateTime | setActionDateTime(?\DateTime actionDateTime): void |
| `action` | [`?string (Action9Enum)`](../../doc/models/action-9-enum.md) | Optional | Indicates if rewards were earned or redeemed. | getAction(): ?string | setAction(?string action): void |
| `source` | `?string` | Optional | The source of the reward transaction. | getSource(): ?string | setSource(?string source): void |
| `sourceID` | `?int` | Optional | The unique identifier in the MINDBODY system for the **Source**. | getSourceID(): ?int | setSourceID(?int sourceID): void |
| `expirationDateTime` | `?\DateTime` | Optional | The date and time when earned points expire. This is calculated based on site and client rewards settings. This date will be in the site local time zone and may be **null**. | getExpirationDateTime(): ?\DateTime | setExpirationDateTime(?\DateTime expirationDateTime): void |
| `points` | `?int` | Optional | The amount of points the client earned or redeemed. | getPoints(): ?int | setPoints(?int points): void |

## Example (as JSON)

```json
{
  "ActionDateTime": null,
  "Action": null,
  "Source": null,
  "SourceID": null,
  "ExpirationDateTime": null,
  "Points": null
}
```

