
# Get Client Schedule Response

## Structure

`GetClientScheduleResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `visits` | [`?(MindbodyPublicApiDtoModelsV6Visit[])`](../../doc/models/mindbody-public-api-dto-models-v6-visit.md) | Optional | Contains information about client visits. | getVisits(): ?array | setVisits(?array visits): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Visits": null
}
```

