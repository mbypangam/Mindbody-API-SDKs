
# Get Client Schedule Response

## Structure

`GetClientScheduleResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `visits` | [`?(Visit[])`](../../doc/models/visit.md) | Optional | Contains information about client visits. | getVisits(): ?array | setVisits(?array visits): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Visits": null
}
```

