
# Mindbody Public Api Dto Models V6 Client

The Client.

## Structure

`MindbodyPublicApiDtoModelsV6Client`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appointmentGenderPreference` | [`?string (AppointmentGenderPreference1Enum)`](../../doc/models/appointment-gender-preference-1-enum.md) | Optional | The gender of staff member with whom the client prefers to book appointments. | getAppointmentGenderPreference(): ?string | setAppointmentGenderPreference(?string appointmentGenderPreference): void |
| `birthDate` | `?\DateTime` | Optional | The client’s date of birth. | getBirthDate(): ?\DateTime | setBirthDate(?\DateTime birthDate): void |
| `country` | `?string` | Optional | The client’s country. | getCountry(): ?string | setCountry(?string country): void |
| `creationDate` | `?\DateTime` | Optional | The date the client’s profile was created and added to the business, either by the client from the online store, or by a staff member. This value always returns in the format `yyyy-mm-ddThh:mm:ss:ms`. | getCreationDate(): ?\DateTime | setCreationDate(?\DateTime creationDate): void |
| `customClientFields` | [`?(MindbodyPublicApiDtoModelsV6CustomClientFieldValue[])`](../../doc/models/mindbody-public-api-dto-models-v6-custom-client-field-value.md) | Optional | Contains information about the custom client fields assigned to the client. | getCustomClientFields(): ?array | setCustomClientFields(?array customClientFields): void |
| `clientCreditCard` | [`?MindbodyPublicApiDtoModelsV6ClientCreditCard`](../../doc/models/mindbody-public-api-dto-models-v6-client-credit-card.md) | Optional | Contains information about the client’s credit card. | getClientCreditCard(): ?MindbodyPublicApiDtoModelsV6ClientCreditCard | setClientCreditCard(?MindbodyPublicApiDtoModelsV6ClientCreditCard clientCreditCard): void |
| `clientIndexes` | [`?(MindbodyPublicApiDtoModelsV6AssignedClientIndex[])`](../../doc/models/mindbody-public-api-dto-models-v6-assigned-client-index.md) | Optional | Contains the IDs of the client’s assigned ClientIndexes and ClientIndexValues.<br><br>If an index is already assigned to the client, it is overwritten with the passed index value. You cannot currently remove client indexes using the Public API. Only the indexes passed in the request are returned in the response. | getClientIndexes(): ?array | setClientIndexes(?array clientIndexes): void |
| `clientRelationships` | [`?(MindbodyPublicApiDtoModelsV6ClientRelationship[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-relationship.md) | Optional | Contains information about the relationship between two clients.<br><br>This parameter does not include all of the relationships assigned to the client, only the ones passed in the request. | getClientRelationships(): ?array | setClientRelationships(?array clientRelationships): void |
| `firstAppointmentDate` | `?\DateTime` | Optional | The date of the client’s first booked appointment at the business. | getFirstAppointmentDate(): ?\DateTime | setFirstAppointmentDate(?\DateTime firstAppointmentDate): void |
| `firstClassDate` | `?\DateTime` | Optional | The date of the clients first booked class at the business. | getFirstClassDate(): ?\DateTime | setFirstClassDate(?\DateTime firstClassDate): void |
| `firstName` | `?string` | Optional | The client’s first name. | getFirstName(): ?string | setFirstName(?string firstName): void |
| `id` | `?string` | Optional | The client’s ID, as configured by the business owner. This is the client’s barcode ID if the business owner assigns barcodes to clients. This ID is used throughout the Public API for client-related Public API calls. When used in a POST `UpdateClient` request, the `Id` is used to identify the client for the update. | getId(): ?string | setId(?string id): void |
| `isCompany` | `?bool` | Optional | When `true`, indicates that the client should be marked as a company at the business.<br /><br>When `false`, indicates the client is an individual and does not represent a company. | getIsCompany(): ?bool | setIsCompany(?bool isCompany): void |
| `isProspect` | `?bool` | Optional | This value is set only if the business owner allows individuals to be prospects.<br /><br>When `true`, indicates that the client should be marked as a prospect for the business.<br /><br>When `false`, indicates that the client should not be marked as a prospect for the business. | getIsProspect(): ?bool | setIsProspect(?bool isProspect): void |
| `lastName` | `?string` | Optional | The client’s last name. | getLastName(): ?string | setLastName(?string lastName): void |
| `liability` | [`?MindbodyPublicApiDtoModelsV6Liability`](../../doc/models/mindbody-public-api-dto-models-v6-liability.md) | Optional | Contains the client’s liability agreement information for the business. | getLiability(): ?MindbodyPublicApiDtoModelsV6Liability | setLiability(?MindbodyPublicApiDtoModelsV6Liability liability): void |
| `liabilityRelease` | `?bool` | Optional | Passing `true` sets the client’s liability information as follows:<br><br>* `IsReleased` is set to `true`.<br>* `AgreementDate` is set to the time zone of the business when the call was processed.<br>* `ReleasedBy` is set to `null` if the call is made by the client, `0` if the call was made by the business owner, or to a specific staff member’s ID if a staff member made the call.<br>  Passing `false` sets the client’s liability information as follows:<br>* `IsReleased` is set to `false`.<br>* `AgreementDate` is set to `null`.<br>* `ReleasedBy` is set to `null`. | getLiabilityRelease(): ?bool | setLiabilityRelease(?bool liabilityRelease): void |
| `membershipIcon` | `?int` | Optional | The ID of the [membership icon](https://support.mindbodyonline.com/s/article/203259703-Membership-Setup-screen?language=en_US) displayed next to the client’s name, if the client has a membership on their account. | getMembershipIcon(): ?int | setMembershipIcon(?int membershipIcon): void |
| `mobileProvider` | `?int` | Optional | The client’s mobile provider. | getMobileProvider(): ?int | setMobileProvider(?int mobileProvider): void |
| `notes` | `?string` | Optional | Any notes entered on the client’s account by staff members. This value should never be shown to clients unless the business owner has a specific reason for showing them. | getNotes(): ?string | setNotes(?string notes): void |
| `state` | `?string` | Optional | The client’s state. | getState(): ?string | setState(?string state): void |
| `uniqueId` | `?int` | Optional | The client’s system-generated ID at the business. This value cannot be changed by business owners and is always unique across all clients at the business. This ID is not widely used in the Public API, but can be used by your application to uniquely identify clients. | getUniqueId(): ?int | setUniqueId(?int uniqueId): void |
| `lastModifiedDateTime` | `?\DateTime` | Optional | The UTC date and time when the client’s information was last modified. | getLastModifiedDateTime(): ?\DateTime | setLastModifiedDateTime(?\DateTime lastModifiedDateTime): void |
| `redAlert` | `?string` | Optional | Contains any red alert information entered by the business owner for the client. | getRedAlert(): ?string | setRedAlert(?string redAlert): void |
| `yellowAlert` | `?string` | Optional | Contains any yellow alert information entered by the business owner for the client. | getYellowAlert(): ?string | setYellowAlert(?string yellowAlert): void |
| `middleName` | `?string` | Optional | The client’s middle name. | getMiddleName(): ?string | setMiddleName(?string middleName): void |
| `prospectStage` | [`?MindbodyPublicApiDtoModelsV6ProspectStage`](../../doc/models/mindbody-public-api-dto-models-v6-prospect-stage.md) | Optional | Contains information about the client [prospect stage](https://support.mindbodyonline.com/s/article/206176457-Prospect-Stages?language=en_US). | getProspectStage(): ?MindbodyPublicApiDtoModelsV6ProspectStage | setProspectStage(?MindbodyPublicApiDtoModelsV6ProspectStage prospectStage): void |
| `email` | `?string` | Optional | The client’s email address. | getEmail(): ?string | setEmail(?string email): void |
| `mobilePhone` | `?string` | Optional | The client’s mobile phone number. | getMobilePhone(): ?string | setMobilePhone(?string mobilePhone): void |
| `homePhone` | `?string` | Optional | The client’s home phone number. | getHomePhone(): ?string | setHomePhone(?string homePhone): void |
| `workPhone` | `?string` | Optional | The client’s work phone number. | getWorkPhone(): ?string | setWorkPhone(?string workPhone): void |
| `accountBalance` | `?float` | Optional | The client’s current [account balance](https://mindbody-online-support.force.com/support/s/article/203262013-Adding-account-payments-video-tutorial?language=en_US). | getAccountBalance(): ?float | setAccountBalance(?float accountBalance): void |
| `addressLine1` | `?string` | Optional | The first line of the client’s street address. | getAddressLine1(): ?string | setAddressLine1(?string addressLine1): void |
| `addressLine2` | `?string` | Optional | The second line of the client’s street address, if needed. | getAddressLine2(): ?string | setAddressLine2(?string addressLine2): void |
| `city` | `?string` | Optional | The client’s city. | getCity(): ?string | setCity(?string city): void |
| `postalCode` | `?string` | Optional | The client’s postal code. | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `workExtension` | `?string` | Optional | The client’s work phone extension number. | getWorkExtension(): ?string | setWorkExtension(?string workExtension): void |
| `referredBy` | `?string` | Optional | Specifies how the client was referred to the business. You can get a list of possible strings using the `GetClientReferralTypes` endpoint. | getReferredBy(): ?string | setReferredBy(?string referredBy): void |
| `photoUrl` | `?string` | Optional | The URL of the client’s photo for the client profile. | getPhotoUrl(): ?string | setPhotoUrl(?string photoUrl): void |
| `emergencyContactInfoName` | `?string` | Optional | The name of the client’s emergency contact. | getEmergencyContactInfoName(): ?string | setEmergencyContactInfoName(?string emergencyContactInfoName): void |
| `emergencyContactInfoEmail` | `?string` | Optional | The email address of the client’s emergency contact. | getEmergencyContactInfoEmail(): ?string | setEmergencyContactInfoEmail(?string emergencyContactInfoEmail): void |
| `emergencyContactInfoPhone` | `?string` | Optional | The phone number of the client’s emergency contact. | getEmergencyContactInfoPhone(): ?string | setEmergencyContactInfoPhone(?string emergencyContactInfoPhone): void |
| `emergencyContactInfoRelationship` | `?string` | Optional | The client’s relationship with the emergency contact. | getEmergencyContactInfoRelationship(): ?string | setEmergencyContactInfoRelationship(?string emergencyContactInfoRelationship): void |
| `gender` | `?string` | Optional | The gender of the client. | getGender(): ?string | setGender(?string gender): void |
| `lastFormulaNotes` | `?string` | Optional | The last [formula note](https://support.mindbodyonline.com/s/article/203259903-Appointments-Formula-notes?language=en_US) entered for the client. | getLastFormulaNotes(): ?string | setLastFormulaNotes(?string lastFormulaNotes): void |
| `active` | `?bool` | Optional | When `true`, indicates that the client’s profile is marked as active on the site.<br /><br>When `false`, the client’s profile is inactive.<br>Defaults to `true` based on the assumption that if a client is currently inactive OR is to be marked inactive, this property will explicitly be mapped/set to `false`. | getActive(): ?bool | setActive(?bool active): void |
| `salesReps` | [`?(MindbodyPublicApiDtoModelsV6SalesRep[])`](../../doc/models/mindbody-public-api-dto-models-v6-sales-rep.md) | Optional | A list of sales representatives. | getSalesReps(): ?array | setSalesReps(?array salesReps): void |
| `status` | `?string` | Optional | The status of the client in the business. Possible values are:<br><br>* Declined<br>* Non-Member<br>* Active<br>* Expired<br>* Suspended<br>* Terminated | getStatus(): ?string | setStatus(?string status): void |
| `action` | [`?string (Action1Enum)`](../../doc/models/action-1-enum.md) | Optional | The action taken. | getAction(): ?string | setAction(?string action): void |
| `sendAccountEmails` | `?bool` | Optional | When `true`, indicates that the client has opted to receive general account notifications by email. This property is editable.<br><br />Default: **false** | getSendAccountEmails(): ?bool | setSendAccountEmails(?bool sendAccountEmails): void |
| `sendAccountTexts` | `?bool` | Optional | When `true`, indicates that the client has opted to receive general account notifications by text message. This parameter cannot be updated by developers. If included in a request, it is ignored. | getSendAccountTexts(): ?bool | setSendAccountTexts(?bool sendAccountTexts): void |
| `sendPromotionalEmails` | `?bool` | Optional | When `true`, indicates that the client has opted to receive promotional notifications by email. This property is editable.<br><br />Default: **false** | getSendPromotionalEmails(): ?bool | setSendPromotionalEmails(?bool sendPromotionalEmails): void |
| `sendPromotionalTexts` | `?bool` | Optional | When `true`, indicates that the client has opted to receive promotional notifications by text message. This parameter cannot be updated by developers. If included in a request, it is ignored. | getSendPromotionalTexts(): ?bool | setSendPromotionalTexts(?bool sendPromotionalTexts): void |
| `sendScheduleEmails` | `?bool` | Optional | When `true`, indicates that the client has opted to receive schedule notifications by email. This property is editable.<br><br />Default: **false** | getSendScheduleEmails(): ?bool | setSendScheduleEmails(?bool sendScheduleEmails): void |
| `sendScheduleTexts` | `?bool` | Optional | When `true`, indicates that the client has opted to receive schedule notifications by text message. This parameter cannot be updated by developers. If included in a request, it is ignored. | getSendScheduleTexts(): ?bool | setSendScheduleTexts(?bool sendScheduleTexts): void |
| `homeLocation` | [`?MindbodyPublicApiDtoModelsV6Location`](../../doc/models/mindbody-public-api-dto-models-v6-location.md) | Optional | Information about the Home Location for this client | getHomeLocation(): ?MindbodyPublicApiDtoModelsV6Location | setHomeLocation(?MindbodyPublicApiDtoModelsV6Location homeLocation): void |
| `lockerNumber` | `?string` | Optional | The clients locker number. | getLockerNumber(): ?string | setLockerNumber(?string lockerNumber): void |

## Example (as JSON)

```json
{
  "AppointmentGenderPreference": null,
  "BirthDate": null,
  "Country": null,
  "CreationDate": null,
  "CustomClientFields": null,
  "ClientCreditCard": null,
  "ClientIndexes": null,
  "ClientRelationships": null,
  "FirstAppointmentDate": null,
  "FirstClassDate": null,
  "FirstName": null,
  "Id": null,
  "IsCompany": null,
  "IsProspect": null,
  "LastName": null,
  "Liability": null,
  "LiabilityRelease": null,
  "MembershipIcon": null,
  "MobileProvider": null,
  "Notes": null,
  "State": null,
  "UniqueId": null,
  "LastModifiedDateTime": null,
  "RedAlert": null,
  "YellowAlert": null,
  "MiddleName": null,
  "ProspectStage": null,
  "Email": null,
  "MobilePhone": null,
  "HomePhone": null,
  "WorkPhone": null,
  "AccountBalance": null,
  "AddressLine1": null,
  "AddressLine2": null,
  "City": null,
  "PostalCode": null,
  "WorkExtension": null,
  "ReferredBy": null,
  "PhotoUrl": null,
  "EmergencyContactInfoName": null,
  "EmergencyContactInfoEmail": null,
  "EmergencyContactInfoPhone": null,
  "EmergencyContactInfoRelationship": null,
  "Gender": null,
  "LastFormulaNotes": null,
  "Active": null,
  "SalesReps": null,
  "Status": null,
  "Action": null,
  "SendAccountEmails": null,
  "SendAccountTexts": null,
  "SendPromotionalEmails": null,
  "SendPromotionalTexts": null,
  "SendScheduleEmails": null,
  "SendScheduleTexts": null,
  "HomeLocation": null,
  "LockerNumber": null
}
```

