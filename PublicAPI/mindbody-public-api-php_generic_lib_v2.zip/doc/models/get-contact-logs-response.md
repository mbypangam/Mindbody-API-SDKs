
# Get Contact Logs Response

## Structure

`GetContactLogsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `contactLogs` | [`?(MindbodyPublicApiDtoModelsV6ContactLog[])`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log.md) | Optional | Contains the information about the contact logs. | getContactLogs(): ?array | setContactLogs(?array contactLogs): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ContactLogs": null
}
```

