
# Session Type 1

## Structure

`SessionType1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | [`?string (Type1Enum)`](../../doc/models/type-1-enum.md) | Optional | - | getType(): ?string | setType(?string type): void |
| `defaultTimeLength` | `?int` | Optional | - | getDefaultTimeLength(): ?int | setDefaultTimeLength(?int defaultTimeLength): void |
| `staffTimeLength` | `?int` | Optional | - | getStaffTimeLength(): ?int | setStaffTimeLength(?int staffTimeLength): void |
| `programId` | `?int` | Optional | - | getProgramId(): ?int | setProgramId(?int programId): void |
| `numDeducted` | `?int` | Optional | - | getNumDeducted(): ?int | setNumDeducted(?int numDeducted): void |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `active` | `?bool` | Optional | - | getActive(): ?bool | setActive(?bool active): void |
| `capacity` | `?int` | Optional | - | getCapacity(): ?int | setCapacity(?int capacity): void |
| `resourceRequired` | `?bool` | Optional | - | getResourceRequired(): ?bool | setResourceRequired(?bool resourceRequired): void |
| `category` | [`?ServiceTag`](../../doc/models/service-tag.md) | Optional | ServiceTag refers to Category and Subcategory fields for classes and appointments | getCategory(): ?ServiceTag | setCategory(?ServiceTag category): void |
| `subcategory` | [`?ServiceTag`](../../doc/models/service-tag.md) | Optional | ServiceTag refers to Category and Subcategory fields for classes and appointments | getSubcategory(): ?ServiceTag | setSubcategory(?ServiceTag subcategory): void |
| `onlineDescription` | `?string` | Optional | - | getOnlineDescription(): ?string | setOnlineDescription(?string onlineDescription): void |

## Example (as JSON)

```json
{
  "Type": "Arrival",
  "DefaultTimeLength": 132,
  "StaffTimeLength": 110,
  "ProgramId": 154,
  "NumDeducted": 226
}
```

