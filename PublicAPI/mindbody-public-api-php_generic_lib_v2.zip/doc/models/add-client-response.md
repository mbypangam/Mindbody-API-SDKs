
# Add Client Response

## Structure

`AddClientResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `client` | [`?Client`](../../doc/models/client.md) | Optional | Contains information about the client. | getClient(): ?Client | setClient(?Client client): void |

## Example (as JSON)

```json
{
  "Client": null
}
```

