
# Update Contact Log Type

## Structure

`UpdateContactLogType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the contact log type to update the subtypes of. | getId(): ?int | setId(?int id): void |
| `subTypes` | `?(int[])` | Optional | The subtype IDs that are to be added to the contact log. | getSubTypes(): ?array | setSubTypes(?array subTypes): void |

## Example (as JSON)

```json
{
  "Id": null,
  "SubTypes": null
}
```

