
# Staff Setting

contains the information about the staff settings.

## Structure

`StaffSetting`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `useStaffNicknames` | `?bool` | Optional | When `true`, `DisplayName` of the staff will be displayed.<br>When `false`, `DisplayName` will be displayed as null. | getUseStaffNicknames(): ?bool | setUseStaffNicknames(?bool useStaffNicknames): void |
| `showStaffLastNamesOnSchedules` | `?bool` | Optional | When `true`, indicates that the Name contains both the `FirstName` and `LastName` of the staff.<br>When `false`, indicates that the Name contains only the `FirstName` of the staff. | getShowStaffLastNamesOnSchedules(): ?bool | setShowStaffLastNamesOnSchedules(?bool showStaffLastNamesOnSchedules): void |

## Example (as JSON)

```json
{
  "UseStaffNicknames": null,
  "ShowStaffLastNamesOnSchedules": null
}
```

