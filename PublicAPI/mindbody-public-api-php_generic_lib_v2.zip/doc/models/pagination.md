
# Pagination

Contains information about the pagination used.

## Structure

`Pagination`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `pageNumber` | `?int` | Optional | Page number of results in dataset. | getPageNumber(): ?int | setPageNumber(?int pageNumber): void |
| `pageSize` | `?int` | Optional | Number of results returned in this response. | getPageSize(): ?int | setPageSize(?int pageSize): void |
| `totalResultCount` | `?int` | Optional | Total number of results in dataset. | getTotalResultCount(): ?int | setTotalResultCount(?int totalResultCount): void |
| `totalPageCount` | `?int` | Optional | Total number of page in dataset. | getTotalPageCount(): ?int | setTotalPageCount(?int totalPageCount): void |

## Example (as JSON)

```json
{
  "PageNumber": 54,
  "PageSize": 136,
  "TotalResultCount": 152,
  "TotalPageCount": 222
}
```

