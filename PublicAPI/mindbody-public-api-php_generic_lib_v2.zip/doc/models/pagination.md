
# Pagination

## Structure

`Pagination`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `pageNumber` | `?int` | Optional | - | getPageNumber(): ?int | setPageNumber(?int pageNumber): void |
| `pageSize` | `?int` | Optional | - | getPageSize(): ?int | setPageSize(?int pageSize): void |
| `totalResultCount` | `?int` | Optional | - | getTotalResultCount(): ?int | setTotalResultCount(?int totalResultCount): void |
| `totalPageCount` | `?int` | Optional | - | getTotalPageCount(): ?int | setTotalPageCount(?int totalPageCount): void |

## Example (as JSON)

```json
{
  "PageNumber": null,
  "PageSize": null,
  "TotalResultCount": null,
  "TotalPageCount": null
}
```

