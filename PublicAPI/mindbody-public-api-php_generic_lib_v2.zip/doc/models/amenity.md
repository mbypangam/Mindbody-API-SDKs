
# Amenity

Definition of a location amenity

## Structure

`Amenity`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID number of the amenity. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the amenity, for example, food or lockers. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": 146,
  "Name": "Name0"
}
```

