
# Get Classes Response

## Structure

`GetClassesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `classes` | [`?(MClass[])`](../../doc/models/m-class.md) | Optional | A list of the requested classes. | getClasses(): ?array | setClasses(?array classes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Classes": null
}
```

