
# Get Categories Response

Get Categories Response Model

## Structure

`GetCategoriesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `categories` | [`?(Category[])`](../../doc/models/category.md) | Optional | Contains the Category objects, each of which describes the categories for a site. | getCategories(): ?array | setCategories(?array categories): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Categories": null
}
```

