
# Get Schedule Items Response

## Structure

`GetScheduleItemsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `staffMembers` | [`?(MindbodyPublicApiDtoModelsV6Staff[])`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Contains information about staff members with schedule items. | getStaffMembers(): ?array | setStaffMembers(?array staffMembers): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "StaffMembers": null
}
```

