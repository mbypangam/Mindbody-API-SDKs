
# Get Schedule Items Response

## Structure

`GetScheduleItemsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `staffMembers` | [`?(Staff[])`](../../doc/models/staff.md) | Optional | Contains information about staff members with schedule items. | getStaffMembers(): ?array | setStaffMembers(?array staffMembers): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "StaffMembers": null
}
```

