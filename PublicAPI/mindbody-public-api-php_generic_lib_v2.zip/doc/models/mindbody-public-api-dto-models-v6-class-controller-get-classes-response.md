
# Mindbody Public Api Dto Models V6 Class Controller Get Classes Response

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetClassesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `classes` | [`?(MindbodyPublicApiDtoModelsV6Class[])`](../../doc/models/mindbody-public-api-dto-models-v6-class.md) | Optional | A list of the requested classes. | getClasses(): ?array | setClasses(?array classes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Classes": null
}
```

