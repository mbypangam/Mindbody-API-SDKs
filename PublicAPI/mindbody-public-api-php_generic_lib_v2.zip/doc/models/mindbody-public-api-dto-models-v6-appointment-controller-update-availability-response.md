
# Mindbody Public Api Dto Models V6 Appointment Controller Update Availability Response

This is the update avaialability response

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffMembers` | [`?(MindbodyPublicApiDtoModelsV6Staff[])`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | This is the success list of the trainer availability | getStaffMembers(): ?array | setStaffMembers(?array staffMembers): void |
| `errors` | [`?(MindbodyPublicApiDtoModelsV6ApiError[])`](../../doc/models/mindbody-public-api-dto-models-v6-api-error.md) | Optional | - | getErrors(): ?array | setErrors(?array errors): void |

## Example (as JSON)

```json
{
  "StaffMembers": null,
  "Errors": null
}
```

