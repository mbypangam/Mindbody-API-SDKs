
# Mindbody Public Api Common Models Api Error

## Structure

`MindbodyPublicApiCommonModelsApiError`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `message` | `?string` | Optional | The text of the message. Each message is specific to the error that caused it.<br>For example, if the the error type is `InvalidFileFormat`,<br>the message could say "The photo you attempted to upload is not a supported file type." | getMessage(): ?string | setMessage(?string message): void |
| `code` | `?string` | Optional | The type of error that occurred, for example, `ClientNotFound` or `InvalidClassId`. | getCode(): ?string | setCode(?string code): void |

## Example (as JSON)

```json
{
  "Message": null,
  "Code": null
}
```

