
# Get Sales Response

## Structure

`GetSalesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `sales` | [`?(Sale[])`](../../doc/models/sale.md) | Optional | Contains the Sale objects, each of which describes the sale and payment for a purchase event. | getSales(): ?array | setSales(?array sales): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Sales": null
}
```

