
# Add Availabilities Request

## Structure

`AddAvailabilitiesRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `test` | `?bool` | Optional | When `true`, the request ensures that its parameters are valid without affecting real data.<br>When `false`, the request performs as intended and may affect live client data.<br>(optional) Defaults to false. | getTest(): ?bool | setTest(?bool test): void |
| `locationID` | `?int` | Optional | Location of availability.<br><br />Not used when IsUnavailable is `true`. | getLocationID(): ?int | setLocationID(?int locationID): void |
| `staffIDs` | `?(int[])` | Optional | A list of requested staff IDs.<br /><br>(optional) Defaults to staff ID of user credentials. Use 0 for all. | getStaffIDs(): ?array | setStaffIDs(?array staffIDs): void |
| `programIDs` | `?(int[])` | Optional | A list of program IDs.<br /><br>(optional) Defaults to all.<br><br />Not used when IsUnavailable is true. | getProgramIDs(): ?array | setProgramIDs(?array programIDs): void |
| `startDateTime` | `?DateTime` | Optional | The start date and time of the new availabilities or unavailabilities. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?DateTime` | Optional | The end date and time of the new availabilities or unavailabilities. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `daysOfWeek` | [`?(string(DaysOfWeekEnum)[])`](../../doc/models/days-of-week-enum.md) | Optional | The days of the week to set.<br /><br>(optional) Defaults to all. | getDaysOfWeek(): ?array | setDaysOfWeek(?array daysOfWeek): void |
| `unavailableDescription` | `?string` | Optional | Description of unavalability.<br><br />Only used when IsUnavailable is true. | getUnavailableDescription(): ?string | setUnavailableDescription(?string unavailableDescription): void |
| `isUnavailable` | `?bool` | Optional | When `true`, indicates that unavailability is getting added. When `false`, indicates that availability is getting added.<br>Default: **false** | getIsUnavailable(): ?bool | setIsUnavailable(?bool isUnavailable): void |
| `publicDisplay` | [`?string(PublicDisplay1Enum)`](../../doc/models/public-display-1-enum.md) | Optional | Sets the public display of the availability.<br /><ul><li>Show</li><li>Mask</li><li>Hide</li></ul><br>(optional) Defaults to Show. | getPublicDisplay(): ?string | setPublicDisplay(?string publicDisplay): void |

## Example (as JSON)

```json
{
  "Test": false,
  "LocationID": 106,
  "StaffIDs": [
    237,
    238,
    239
  ],
  "ProgramIDs": [
    0
  ],
  "StartDateTime": "2016-03-13T12:52:32.123Z"
}
```

