
# Mindbody Public Api Dto Models V6 Class Controller Substitute Class Teacher Response

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `class` | [`?MindbodyPublicApiDtoModelsV6SubstituteTeacherClass`](../../doc/models/mindbody-public-api-dto-models-v6-substitute-teacher-class.md) | Optional | Contains information about the class that is being assigned a substitute teacher. | getClass(): ?MindbodyPublicApiDtoModelsV6SubstituteTeacherClass | setClass(?MindbodyPublicApiDtoModelsV6SubstituteTeacherClass class): void |

## Example (as JSON)

```json
{
  "Class": null
}
```

