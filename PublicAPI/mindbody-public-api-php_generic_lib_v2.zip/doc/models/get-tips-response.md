
# Get Tips Response

## Structure

`GetTipsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `tips` | [`?(Tip[])`](../../doc/models/tip.md) | Optional | Contains information about tips given to staff members within the given date range. Results are ordered by StaffId. | getTips(): ?array | setTips(?array tips): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Tips": null
}
```

