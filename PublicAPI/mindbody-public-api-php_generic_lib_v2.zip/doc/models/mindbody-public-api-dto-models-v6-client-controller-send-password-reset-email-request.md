
# Mindbody Public Api Dto Models V6 Client Controller Send Password Reset Email Request

Request to send a password reset email to a user

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `userEmail` | `string` | Required | The user's email address. The software uses this parameter as the username. | getUserEmail(): string | setUserEmail(string userEmail): void |
| `userFirstName` | `string` | Required | The user's first name. The software uses this parameter to verify the user. | getUserFirstName(): string | setUserFirstName(string userFirstName): void |
| `userLastName` | `string` | Required | The user's last name. The software uses this parameter to verify the user. | getUserLastName(): string | setUserLastName(string userLastName): void |

## Example (as JSON)

```json
{
  "UserEmail": "UserEmail4",
  "UserFirstName": "UserFirstName8",
  "UserLastName": "UserLastName4"
}
```

