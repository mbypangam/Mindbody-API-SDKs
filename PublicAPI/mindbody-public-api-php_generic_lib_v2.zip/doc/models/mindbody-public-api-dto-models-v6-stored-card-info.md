
# Mindbody Public Api Dto Models V6 Stored Card Info

## Structure

`MindbodyPublicApiDtoModelsV6StoredCardInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `lastFour` | `?string` | Optional | - | getLastFour(): ?string | setLastFour(?string lastFour): void |

## Example (as JSON)

```json
{
  "LastFour": null
}
```

