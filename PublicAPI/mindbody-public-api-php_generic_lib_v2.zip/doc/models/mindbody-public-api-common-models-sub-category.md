
# Mindbody Public Api Common Models Sub Category

## Structure

`MindbodyPublicApiCommonModelsSubCategory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The sub category Id used for api calls. | getId(): ?int | setId(?int id): void |
| `subCategoryName` | `?string` | Optional | Sub Category Name | getSubCategoryName(): ?string | setSubCategoryName(?string subCategoryName): void |
| `active` | `?bool` | Optional | Check if Sub Category is active. | getActive(): ?bool | setActive(?bool active): void |

## Example (as JSON)

```json
{
  "Id": null,
  "SubCategoryName": null,
  "Active": null
}
```

