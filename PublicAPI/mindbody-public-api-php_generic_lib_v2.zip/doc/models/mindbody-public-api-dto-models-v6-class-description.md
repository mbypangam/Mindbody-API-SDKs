
# Mindbody Public Api Dto Models V6 Class Description

Represents a class definition. The class meets at the start time, goes until the end time.

## Structure

`MindbodyPublicApiDtoModelsV6ClassDescription`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `active` | `?bool` | Optional | When `true`, indicates that the business can assign this class description to new class schedules.<br /><br>When `false`, indicates that the business cannot assign this class description to new class schedules. | getActive(): ?bool | setActive(?bool active): void |
| `description` | `?string` | Optional | The long version of the class description. | getDescription(): ?string | setDescription(?string description): void |
| `id` | `?int` | Optional | The class description's ID. | getId(): ?int | setId(?int id): void |
| `imageURL` | `?string` | Optional | The class description's image URL, if any. If it does not exist, nothing is returned. | getImageURL(): ?string | setImageURL(?string imageURL): void |
| `lastUpdated` | `?\DateTime` | Optional | The date this class description was last modified. | getLastUpdated(): ?\DateTime | setLastUpdated(?\DateTime lastUpdated): void |
| `level` | [`?MindbodyPublicApiDtoModelsV6Level`](../../doc/models/mindbody-public-api-dto-models-v6-level.md) | Optional | A session level. | getLevel(): ?MindbodyPublicApiDtoModelsV6Level | setLevel(?MindbodyPublicApiDtoModelsV6Level level): void |
| `name` | `?string` | Optional | The name of this class description. | getName(): ?string | setName(?string name): void |
| `notes` | `?string` | Optional | Any notes about the class description. | getNotes(): ?string | setNotes(?string notes): void |
| `prereq` | `?string` | Optional | Any prerequisites for the class. | getPrereq(): ?string | setPrereq(?string prereq): void |
| `program` | [`?MindbodyPublicApiDtoModelsV6Program`](../../doc/models/mindbody-public-api-dto-models-v6-program.md) | Optional | - | getProgram(): ?MindbodyPublicApiDtoModelsV6Program | setProgram(?MindbodyPublicApiDtoModelsV6Program program): void |
| `sessionType` | [`?MindbodyPublicApiDtoModelsV6SessionType`](../../doc/models/mindbody-public-api-dto-models-v6-session-type.md) | Optional | - | getSessionType(): ?MindbodyPublicApiDtoModelsV6SessionType | setSessionType(?MindbodyPublicApiDtoModelsV6SessionType sessionType): void |
| `category` | `?string` | Optional | The category of this class description. | getCategory(): ?string | setCategory(?string category): void |
| `categoryId` | `?int` | Optional | The category ID of this class description. | getCategoryId(): ?int | setCategoryId(?int categoryId): void |
| `subcategory` | `?string` | Optional | The subcategory of this class description. | getSubcategory(): ?string | setSubcategory(?string subcategory): void |
| `subcategoryId` | `?int` | Optional | The subcategory ID of this class description. | getSubcategoryId(): ?int | setSubcategoryId(?int subcategoryId): void |

## Example (as JSON)

```json
{
  "Active": null,
  "Description": null,
  "Id": null,
  "ImageURL": null,
  "LastUpdated": null,
  "Level": null,
  "Name": null,
  "Notes": null,
  "Prereq": null,
  "Program": null,
  "SessionType": null,
  "Category": null,
  "CategoryId": null,
  "Subcategory": null,
  "SubcategoryId": null
}
```

