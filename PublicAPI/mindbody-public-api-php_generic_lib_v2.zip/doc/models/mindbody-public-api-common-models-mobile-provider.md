
# Mindbody Public Api Common Models Mobile Provider

## Structure

`MindbodyPublicApiCommonModelsMobileProvider`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `active` | `?bool` | Optional | - | getActive(): ?bool | setActive(?bool active): void |
| `providerName` | `?string` | Optional | - | getProviderName(): ?string | setProviderName(?string providerName): void |
| `providerAddress` | `?string` | Optional | - | getProviderAddress(): ?string | setProviderAddress(?string providerAddress): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Active": null,
  "ProviderName": null,
  "ProviderAddress": null
}
```

