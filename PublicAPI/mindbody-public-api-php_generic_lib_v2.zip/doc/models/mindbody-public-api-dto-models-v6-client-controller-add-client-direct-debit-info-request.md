
# Mindbody Public Api Dto Models V6 Client Controller Add Client Direct Debit Info Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `test` | `?bool` | Optional | When `true`, indicates that test mode is enabled. The information is to be validated, but no data will be added or updated.<br>Default: **false** | getTest(): ?bool | setTest(?bool test): void |
| `clientId` | `?string` | Optional | The ID of the client being updated | getClientId(): ?string | setClientId(?string clientId): void |
| `nameOnAccount` | `?string` | Optional | The name on the bank account being added | getNameOnAccount(): ?string | setNameOnAccount(?string nameOnAccount): void |
| `routingNumber` | `?string` | Optional | The routing number of the bank account being added | getRoutingNumber(): ?string | setRoutingNumber(?string routingNumber): void |
| `accountNumber` | `?string` | Optional | The bank account number | getAccountNumber(): ?string | setAccountNumber(?string accountNumber): void |
| `accountType` | `?string` | Optional | The account type.<br><br>Possible values:<br><br>* Checking<br>* Savings | getAccountType(): ?string | setAccountType(?string accountType): void |

## Example (as JSON)

```json
{
  "Test": null,
  "ClientId": null,
  "NameOnAccount": null,
  "RoutingNumber": null,
  "AccountNumber": null,
  "AccountType": null
}
```

