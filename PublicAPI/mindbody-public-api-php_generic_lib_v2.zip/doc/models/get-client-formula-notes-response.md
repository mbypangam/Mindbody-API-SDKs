
# Get Client Formula Notes Response

Enables to retrieve cross regional formula notes for a client, or for a specific appointment. The two parameters are optional, however at least one must be provided. This endpoint supports pagination.

## Structure

`GetClientFormulaNotesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `formulaNotes` | [`?(FormulaNoteResponse[])`](../../doc/models/formula-note-response.md) | Optional | Contains details about the client’s formula. | getFormulaNotes(): ?array | setFormulaNotes(?array formulaNotes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "FormulaNotes": null
}
```

