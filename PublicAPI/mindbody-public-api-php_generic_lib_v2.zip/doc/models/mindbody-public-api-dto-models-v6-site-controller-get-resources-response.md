
# Mindbody Public Api Dto Models V6 Site Controller Get Resources Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetResourcesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `resources` | [`?(MindbodyPublicApiDtoModelsV6Resource[])`](../../doc/models/mindbody-public-api-dto-models-v6-resource.md) | Optional | Contains information about resources as the business. | getResources(): ?array | setResources(?array resources): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Resources": null
}
```

