
# Level

A session level.

## Structure

`Level`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | Contains the Id given to this level. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | Contains the name given to this level. | getName(): ?string | setName(?string name): void |
| `description` | `?string` | Optional | Contains a description of this level. | getDescription(): ?string | setDescription(?string description): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null
}
```

