
# Add Formula Note Request

## Structure

`AddFormulaNoteRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `string` | Required | The ID of the client who needs to have a formula note added. | getClientId(): string | setClientId(string clientId): void |
| `appointmentId` | `?int` | Optional | The appointment ID that the formula note is related to. | getAppointmentId(): ?int | setAppointmentId(?int appointmentId): void |
| `note` | `string` | Required | The new formula note text. | getNote(): string | setNote(string note): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId4",
  "AppointmentId": 120,
  "Note": "Note0"
}
```

