
# Add Promo Code Request

## Structure

`AddPromoCodeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `code` | `string` | Required | The code of the promocode. | getCode(): string | setCode(string code): void |
| `name` | `string` | Required | The name of the promocode. | getName(): string | setName(string name): void |
| `active` | `?bool` | Optional | Indicates that promocode is active. Default: **true** | getActive(): ?bool | setActive(?bool active): void |
| `discount` | [`?Discount`](../../doc/models/discount.md) | Optional | Discount for a promo code | getDiscount(): ?Discount | setDiscount(?Discount discount): void |
| `activationDate` | `?\DateTime` | Optional | The date of the promocode activation. Default: **today’s date** | getActivationDate(): ?\DateTime | setActivationDate(?\DateTime activationDate): void |
| `expirationDate` | `?\DateTime` | Optional | The date of the promocode expiration. Default: **a months from today’s date** | getExpirationDate(): ?\DateTime | setExpirationDate(?\DateTime expirationDate): void |
| `maxUses` | `?int` | Optional | The maximun number of uses. A use is considered a single sale. | getMaxUses(): ?int | setMaxUses(?int maxUses): void |
| `daysAfterCloseDate` | `?int` | Optional | The number of days a client has to use a promocode after they are no longer a prospect. | getDaysAfterCloseDate(): ?int | setDaysAfterCloseDate(?int daysAfterCloseDate): void |
| `allowOnline` | `?bool` | Optional | Indicates if promocode can be redeemed online in consumer mode. Default: **false** | getAllowOnline(): ?bool | setAllowOnline(?bool allowOnline): void |
| `daysValid` | `?(string[])` | Optional | Indicates what days of the week promocode is valid. Defaults to 7 days of the week. Possible values are:<br><br>* Monday<br>* Tuesday<br>* Wednesday<br>* Thursday<br>* Friday<br>* Saturday<br>* Sunday | getDaysValid(): ?array | setDaysValid(?array daysValid): void |
| `applicableItems` | [`?(ApplicableItem[])`](../../doc/models/applicable-item.md) | Optional | Contains information about a promocode applicable items.<br>See ApplicableItems for a details of the `ApplicableItems` object. | getApplicableItems(): ?array | setApplicableItems(?array applicableItems): void |

## Example (as JSON)

```json
{
  "Code": "Code0",
  "Name": "Name0",
  "Active": null,
  "Discount": null,
  "ActivationDate": null,
  "ExpirationDate": null,
  "MaxUses": null,
  "DaysAfterCloseDate": null,
  "AllowOnline": null,
  "DaysValid": null,
  "ApplicableItems": null
}
```

