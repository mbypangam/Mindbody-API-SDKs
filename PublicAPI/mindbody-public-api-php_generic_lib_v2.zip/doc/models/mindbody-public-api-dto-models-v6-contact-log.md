
# Mindbody Public Api Dto Models V6 Contact Log

A contact log.

## Structure

`MindbodyPublicApiDtoModelsV6ContactLog`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The contact log’s ID. | getId(): ?int | setId(?int id): void |
| `text` | `?string` | Optional | The contact log’s body text. | getText(): ?string | setText(?string text): void |
| `createdDateTime` | `?\DateTime` | Optional | The local date and time when the contact log was created. | getCreatedDateTime(): ?\DateTime | setCreatedDateTime(?\DateTime createdDateTime): void |
| `followupByDate` | `?\DateTime` | Optional | The date by which the assigned staff member should close or follow up on this contact log. | getFollowupByDate(): ?\DateTime | setFollowupByDate(?\DateTime followupByDate): void |
| `contactMethod` | `?string` | Optional | The method by which the client wants to be contacted. | getContactMethod(): ?string | setContactMethod(?string contactMethod): void |
| `contactName` | `?string` | Optional | The name of the client to contact. | getContactName(): ?string | setContactName(?string contactName): void |
| `client` | [`?MindbodyPublicApiDtoModelsV6Client`](../../doc/models/mindbody-public-api-dto-models-v6-client.md) | Optional | Information about the client to whom the contact log belongs. | getClient(): ?MindbodyPublicApiDtoModelsV6Client | setClient(?MindbodyPublicApiDtoModelsV6Client client): void |
| `createdBy` | [`?MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Information about the staff member who created the contact log. | getCreatedBy(): ?MindbodyPublicApiDtoModelsV6Staff | setCreatedBy(?MindbodyPublicApiDtoModelsV6Staff createdBy): void |
| `assignedTo` | [`?MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Information about the staff member to whom the contact log is assigned for follow up. | getAssignedTo(): ?MindbodyPublicApiDtoModelsV6Staff | setAssignedTo(?MindbodyPublicApiDtoModelsV6Staff assignedTo): void |
| `comments` | [`?(MindbodyPublicApiDtoModelsV6ContactLogComment[])`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log-comment.md) | Optional | Information about the comment. | getComments(): ?array | setComments(?array comments): void |
| `types` | [`?(MindbodyPublicApiDtoModelsV6ContactLogType[])`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log-type.md) | Optional | Information about the type of contact log. | getTypes(): ?array | setTypes(?array types): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Text": null,
  "CreatedDateTime": null,
  "FollowupByDate": null,
  "ContactMethod": null,
  "ContactName": null,
  "Client": null,
  "CreatedBy": null,
  "AssignedTo": null,
  "Comments": null,
  "Types": null
}
```

