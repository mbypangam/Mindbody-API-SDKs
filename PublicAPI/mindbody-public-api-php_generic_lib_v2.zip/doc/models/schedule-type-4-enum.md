
# Schedule Type 4 Enum

## Enumeration

`ScheduleType4Enum`

## Fields

| Name |
|  --- |
| `ALL` |
| `CLASS_` |
| `ENROLLMENT` |
| `APPOINTMENT` |
| `RESOURCE` |
| `MEDIA` |
| `ARRIVAL` |

