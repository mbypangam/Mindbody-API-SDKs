
# Service

## Structure

`Service`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `price` | `?float` | Optional | The cost of the pricing option when sold at a physical location. | getPrice(): ?float | setPrice(?float price): void |
| `onlinePrice` | `?float` | Optional | The cost of the pricing option when sold online. | getOnlinePrice(): ?float | setOnlinePrice(?float onlinePrice): void |
| `taxIncluded` | `?float` | Optional | The amount of tax included in the price, if inclusive pricing is enabled. | getTaxIncluded(): ?float | setTaxIncluded(?float taxIncluded): void |
| `programId` | `?int` | Optional | The ID of the program that this pricing option applies to. | getProgramId(): ?int | setProgramId(?int programId): void |
| `taxRate` | `?float` | Optional | The tax rate applied to the pricing option. This field is populated only when you include a `LocationID` in the request. | getTaxRate(): ?float | setTaxRate(?float taxRate): void |
| `productId` | `?int` | Optional | The unique ID of this pricing option. This is the `PurchasedItems[].Id` returned from GET Sales. | getProductId(): ?int | setProductId(?int productId): void |
| `id` | `?string` | Optional | The barcode ID of the pricing option. This is the `PurchasedItems[].BarcodeId` returned from GET Sales. | getId(): ?string | setId(?string id): void |
| `name` | `?string` | Optional | The name of the pricing option. | getName(): ?string | setName(?string name): void |
| `count` | `?int` | Optional | The initial count of usages available for the pricing option. | getCount(): ?int | setCount(?int count): void |
| `sellOnline` | `?bool` | Optional | When true, filters to the pricing options that can be sold online.<br>Default: *false* | getSellOnline(): ?bool | setSellOnline(?bool sellOnline): void |
| `saleInContractOnly` | `?bool` | Optional | When `true`, indicates that the pricing option is allowed to be purchased in a contract or package.<br>When `false`, indicates that the pricing option is not allowed to be purchased in a contract or package. | getSaleInContractOnly(): ?bool | setSaleInContractOnly(?bool saleInContractOnly): void |
| `type` | `?string` | Optional | The type of the pricing option, either Drop-in, Series, or Unlimited. | getType(): ?string | setType(?string type): void |
| `expirationType` | `?string` | Optional | The date the pricing option begins its activation, either the date of sale or the date the client first used it for a visit. | getExpirationType(): ?string | setExpirationType(?string expirationType): void |
| `expirationUnit` | `?string` | Optional | The unit, either days or months, of `ExpirationLength`, indicating how long the pricing option is active for. | getExpirationUnit(): ?string | setExpirationUnit(?string expirationUnit): void |
| `expirationLength` | `?int` | Optional | The number of days or months that the pricing option is active for. | getExpirationLength(): ?int | setExpirationLength(?int expirationLength): void |
| `revenueCategory` | `?string` | Optional | The revenue category of the pricing option. | getRevenueCategory(): ?string | setRevenueCategory(?string revenueCategory): void |
| `membershipId` | `?int` | Optional | The ID that this pricing option grants membership to. | getMembershipId(): ?int | setMembershipId(?int membershipId): void |
| `sellAtLocationIds` | `?(int[])` | Optional | The location IDs where this pricing option is sold. | getSellAtLocationIds(): ?array | setSellAtLocationIds(?array sellAtLocationIds): void |
| `useAtLocationIds` | `?(int[])` | Optional | The location IDs where this pricing option may be used. | getUseAtLocationIds(): ?array | setUseAtLocationIds(?array useAtLocationIds): void |
| `priority` | `?string` | Optional | The priority of the pricing option, either High, Medium, or Low. | getPriority(): ?string | setPriority(?string priority): void |
| `isIntroOffer` | `?bool` | Optional | Indicates if this pricing option is an introductory offer. | getIsIntroOffer(): ?bool | setIsIntroOffer(?bool isIntroOffer): void |
| `introOfferType` | `?string` | Optional | When `IsIntroOffer` is true, this indicates if this introductory offer may be purchased by new clients or new and existing clients. | getIntroOfferType(): ?string | setIntroOfferType(?string introOfferType): void |
| `isThirdPartyDiscountPricing` | `?bool` | Optional | Indicates whether this pricing option is sold at discounted rates by third-party services, such as ClassPass. | getIsThirdPartyDiscountPricing(): ?bool | setIsThirdPartyDiscountPricing(?bool isThirdPartyDiscountPricing): void |
| `program` | `?string` | Optional | The name of the service category the pricing option belongs to. | getProgram(): ?string | setProgram(?string program): void |
| `discontinued` | `?bool` | Optional | If the pricing option has been marked discontinued. | getDiscontinued(): ?bool | setDiscontinued(?bool discontinued): void |
| `restrictToMembershipIds` | `?(int[])` | Optional | Restricted to members of these membership ids. | getRestrictToMembershipIds(): ?array | setRestrictToMembershipIds(?array restrictToMembershipIds): void |
| `applyMemberDiscountsOfMembershipIds` | `?(int[])` | Optional | Discounts applied of these membership ids. | getApplyMemberDiscountsOfMembershipIds(): ?array | setApplyMemberDiscountsOfMembershipIds(?array applyMemberDiscountsOfMembershipIds): void |

## Example (as JSON)

```json
{
  "Price": 6.2,
  "OnlinePrice": 40.72,
  "TaxIncluded": 142.26,
  "ProgramId": 154,
  "TaxRate": 230.24
}
```

