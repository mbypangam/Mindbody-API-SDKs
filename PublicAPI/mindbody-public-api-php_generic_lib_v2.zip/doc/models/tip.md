
# Tip

## Structure

`Tip`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `?int` | Optional | The ID of the staff member the tip is for. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `saleId` | `?int` | Optional | The sale’s ID associated with the tip. | getSaleId(): ?int | setSaleId(?int saleId): void |
| `saleDateTime` | `?\DateTime` | Optional | The date and time when the tip was given. | getSaleDateTime(): ?\DateTime | setSaleDateTime(?\DateTime saleDateTime): void |
| `earnings` | `?float` | Optional | The amount tipped to the staff member. | getEarnings(): ?float | setEarnings(?float earnings): void |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "SaleId": 62,
  "SaleDateTime": "2016-03-13T12:52:32.123Z",
  "Earnings": 73.68
}
```

