
# Get Staff Response

## Structure

`GetStaffResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | - | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `staffMembers` | [`?(MindbodyPublicApiDtoModelsV6Staff[])`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | A list of staff members. See Staff for a description of the 'Staff' information. | getStaffMembers(): ?array | setStaffMembers(?array staffMembers): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "StaffMembers": null
}
```

