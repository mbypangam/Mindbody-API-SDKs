
# Course

A course.

## Structure

`Course`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The course ID. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The course name. | getName(): ?string | setName(?string name): void |
| `description` | `?string` | Optional | A description of the course. | getDescription(): ?string | setDescription(?string description): void |
| `notes` | `?string` | Optional | Any notes that have been written about the course. | getNotes(): ?string | setNotes(?string notes): void |
| `startDate` | `?\DateTime` | Optional | Date and time that the course starts. | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | Date and time that the course ends. | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `location` | [`?Location`](../../doc/models/location.md) | Optional | - | getLocation(): ?Location | setLocation(?Location location): void |
| `organizer` | [`?Staff`](../../doc/models/staff.md) | Optional | The Staff | getOrganizer(): ?Staff | setOrganizer(?Staff organizer): void |
| `program` | [`?Program`](../../doc/models/program.md) | Optional | - | getProgram(): ?Program | setProgram(?Program program): void |
| `imageUrl` | `?string` | Optional | The URL of the image associated with this course, if one exists. | getImageUrl(): ?string | setImageUrl(?string imageUrl): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null,
  "Notes": null,
  "StartDate": null,
  "EndDate": null,
  "Location": null,
  "Organizer": null,
  "Program": null,
  "ImageUrl": null
}
```

