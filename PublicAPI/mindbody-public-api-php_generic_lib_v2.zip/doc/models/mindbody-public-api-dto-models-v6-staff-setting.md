
# Mindbody Public Api Dto Models V6 Staff Setting

## Structure

`MindbodyPublicApiDtoModelsV6StaffSetting`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `useStaffNicknames` | `?bool` | Optional | - | getUseStaffNicknames(): ?bool | setUseStaffNicknames(?bool useStaffNicknames): void |
| `showStaffLastNamesOnSchedules` | `?bool` | Optional | - | getShowStaffLastNamesOnSchedules(): ?bool | setShowStaffLastNamesOnSchedules(?bool showStaffLastNamesOnSchedules): void |

## Example (as JSON)

```json
{
  "UseStaffNicknames": null,
  "ShowStaffLastNamesOnSchedules": null
}
```

