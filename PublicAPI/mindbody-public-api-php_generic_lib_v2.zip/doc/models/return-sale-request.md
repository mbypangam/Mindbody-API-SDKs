
# Return Sale Request

ReturnSaleRequest

## Structure

`ReturnSaleRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `saleId` | `?int` | Optional | The Sale ID of the sale item to be returned. | getSaleId(): ?int | setSaleId(?int saleId): void |
| `returnReason` | `?string` | Optional | The reason for the return. | getReturnReason(): ?string | setReturnReason(?string returnReason): void |

## Example (as JSON)

```json
{
  "SaleId": null,
  "ReturnReason": null
}
```

