
# Availability

A staff availability entry

## Structure

`Availability`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the availability. | getId(): ?int | setId(?int id): void |
| `staff` | [`?Staff`](../../doc/models/staff.md) | Optional | Contains information about staff members. | getStaff(): ?Staff | setStaff(?Staff staff): void |
| `resources` | [`?(Resource2[])`](../../doc/models/resource.md) | Optional | Available resources | getResources(): ?array | setResources(?array resources): void |
| `sessionType` | [`?SessionType`](../../doc/models/session-type.md) | Optional | Contains information about the types of sessions. | getSessionType(): ?SessionType | setSessionType(?SessionType sessionType): void |
| `programs` | [`?(Program[])`](../../doc/models/program.md) | Optional | Contains information about the programs. | getPrograms(): ?array | setPrograms(?array programs): void |
| `startDateTime` | `?\DateTime` | Optional | The date and time the availability starts. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | The date and time the availability ends. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `bookableEndDateTime` | `?\DateTime` | Optional | The time of day that the last appointment can start. | getBookableEndDateTime(): ?\DateTime | setBookableEndDateTime(?\DateTime bookableEndDateTime): void |
| `location` | [`?Location`](../../doc/models/location.md) | Optional | Contains information about the location. | getLocation(): ?Location | setLocation(?Location location): void |
| `prepTime` | `?int` | Optional | Prep time in minutes | getPrepTime(): ?int | setPrepTime(?int prepTime): void |
| `finishTime` | `?int` | Optional | Finish time in minutes | getFinishTime(): ?int | setFinishTime(?int finishTime): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "Resources": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

