
# Availability

A staff availability entry

## Structure

`Availability`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the availability. | getId(): ?int | setId(?int id): void |
| `staff` | [`?Staff`](../../doc/models/staff.md) | Optional | The Staff | getStaff(): ?Staff | setStaff(?Staff staff): void |
| `sessionType` | [`?SessionType`](../../doc/models/session-type.md) | Optional | SessionType contains information about the session types in a business. | getSessionType(): ?SessionType | setSessionType(?SessionType sessionType): void |
| `programs` | [`?(Program[])`](../../doc/models/program.md) | Optional | Contains information about the programs. | getPrograms(): ?array | setPrograms(?array programs): void |
| `startDateTime` | `?DateTime` | Optional | The date and time the availability starts. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?DateTime` | Optional | The date and time the availability ends. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `bookableEndDateTime` | `?DateTime` | Optional | The time of day that the last appointment can start. | getBookableEndDateTime(): ?\DateTime | setBookableEndDateTime(?\DateTime bookableEndDateTime): void |
| `location` | [`?Location`](../../doc/models/location.md) | Optional | - | getLocation(): ?Location | setLocation(?Location location): void |
| `prepTime` | `?int` | Optional | Prep time in minutes | getPrepTime(): ?int | setPrepTime(?int prepTime): void |
| `finishTime` | `?int` | Optional | Finish time in minutes | getFinishTime(): ?int | setFinishTime(?int finishTime): void |
| `isMasked` | `?bool` | Optional | When `true`, indicates that the staff member's name for availabilty is masked.<br>When `false`, indicates that the staff member's name for availabilty is not masked. | getIsMasked(): ?bool | setIsMasked(?bool isMasked): void |
| `showPublic` | `?bool` | Optional | When `true`, indicates that the schedule is shown to the clients.<br>When `false`, indicates that the schedule is hidden from the clients. | getShowPublic(): ?bool | setShowPublic(?bool showPublic): void |

## Example (as JSON)

```json
{
  "Id": 146,
  "Staff": {
    "Address": "Address8",
    "AppointmentInstructor": false,
    "AlwaysAllowDoubleBooking": false,
    "Bio": "Bio2",
    "City": "City8"
  },
  "SessionType": {
    "Type": "Class",
    "DefaultTimeLength": 30,
    "StaffTimeLength": 52,
    "Id": 52,
    "Name": "Name8"
  },
  "Programs": [
    {
      "Id": 87,
      "Name": "Name7",
      "ScheduleType": "Class",
      "CancelOffset": 77,
      "ContentFormats": [
        "ContentFormats8",
        "ContentFormats9"
      ]
    },
    {
      "Id": 88,
      "Name": "Name8",
      "ScheduleType": "Enrollment",
      "CancelOffset": 78,
      "ContentFormats": [
        "ContentFormats9",
        "ContentFormats0",
        "ContentFormats1"
      ]
    },
    {
      "Id": 89,
      "Name": "Name9",
      "ScheduleType": "Appointment",
      "CancelOffset": 79,
      "ContentFormats": [
        "ContentFormats0"
      ]
    }
  ],
  "StartDateTime": "2016-03-13T12:52:32.123Z"
}
```

