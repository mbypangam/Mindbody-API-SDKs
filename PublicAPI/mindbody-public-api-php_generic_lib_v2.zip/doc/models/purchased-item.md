
# Purchased Item

## Structure

`PurchasedItem`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `saleDetailId` | `?int` | Optional | The ID which gets assigned to the item when item is added to the cart. | getSaleDetailId(): ?int | setSaleDetailId(?int saleDetailId): void |
| `id` | `?int` | Optional | The ID of the purchased item. Use this ID when calling the GET Services or GET Products endpoint. | getId(): ?int | setId(?int id): void |
| `isService` | `?bool` | Optional | When `true`, indicates that the purchased item was a pricing option for a service. | getIsService(): ?bool | setIsService(?bool isService): void |
| `barcodeId` | `?string` | Optional | The barcode number of the purchased item. Use this ID when calling the GET Products endpoint. | getBarcodeId(): ?string | setBarcodeId(?string barcodeId): void |
| `description` | `?string` | Optional | The description of the sale transaction/pricing option. | getDescription(): ?string | setDescription(?string description): void |
| `contractId` | `?int` | Optional | The contract purchased by the client. Use this ID when calling the GET Contract endpoint. | getContractId(): ?int | setContractId(?int contractId): void |
| `categoryId` | `?int` | Optional | The revenue category ID used for sale. Use this ID when calling the GET Categories endpoint. | getCategoryId(): ?int | setCategoryId(?int categoryId): void |
| `subCategoryId` | `?int` | Optional | The ID of revenue subcategory. | getSubCategoryId(): ?int | setSubCategoryId(?int subCategoryId): void |
| `unitPrice` | `?float` | Optional | er Unit Price of the item purchased. | getUnitPrice(): ?float | setUnitPrice(?float unitPrice): void |
| `quantity` | `?int` | Optional | Quantity of the purchased item, applicable for products only. Note: Negative numbers indicate returned items. | getQuantity(): ?int | setQuantity(?int quantity): void |
| `discountPercent` | `?float` | Optional | The percent discount that was applied to the items subtotal. | getDiscountPercent(): ?float | setDiscountPercent(?float discountPercent): void |
| `discountAmount` | `?float` | Optional | The total discount amount that was applied to the items subtotal. | getDiscountAmount(): ?float | setDiscountAmount(?float discountAmount): void |
| `tax1` | `?float` | Optional | A decimal representation of the first tax rate that was applied to the items subtotal. | getTax1(): ?float | setTax1(?float tax1): void |
| `tax2` | `?float` | Optional | A decimal representation of the second tax rate that was applied to the items subtotal. | getTax2(): ?float | setTax2(?float tax2): void |
| `tax3` | `?float` | Optional | A decimal representation of the third tax rate that was applied to the items subtotal. | getTax3(): ?float | setTax3(?float tax3): void |
| `tax4` | `?float` | Optional | A decimal representation of the fourth tax rate that was applied to the items subtotal. | getTax4(): ?float | setTax4(?float tax4): void |
| `tax5` | `?float` | Optional | A decimal representation of the fifth tax rate that was applied to the items subtotal. | getTax5(): ?float | setTax5(?float tax5): void |
| `taxAmount` | `?float` | Optional | Total tax amount that is summation of tax1, tax2, tax3, tax4 and tax5. | getTaxAmount(): ?float | setTaxAmount(?float taxAmount): void |
| `totalAmount` | `?float` | Optional | The items total, once discounts and/or tax was applied. | getTotalAmount(): ?float | setTotalAmount(?float totalAmount): void |
| `notes` | `?string` | Optional | Note made by the customer while purchasing item. | getNotes(): ?string | setNotes(?string notes): void |
| `returned` | `?bool` | Optional | When `true`, indicates that the purchased item is returned, `false` otherwise. | getReturned(): ?bool | setReturned(?bool returned): void |
| `paymentRefId` | `?int` | Optional | The payment reference ID generated during payment of sold item. | getPaymentRefId(): ?int | setPaymentRefId(?int paymentRefId): void |
| `expDate` | `?\DateTime` | Optional | The expiration date of the pricing option purchased. | getExpDate(): ?\DateTime | setExpDate(?\DateTime expDate): void |
| `activeDate` | `?\DateTime` | Optional | The activation date of pricing option purchased. | getActiveDate(): ?\DateTime | setActiveDate(?\DateTime activeDate): void |
| `giftCardBarcodeId` | `?string` | Optional | Gift Card BarcodeId | getGiftCardBarcodeId(): ?string | setGiftCardBarcodeId(?string giftCardBarcodeId): void |

## Example (as JSON)

```json
{
  "SaleDetailId": 116,
  "Id": 146,
  "IsService": false,
  "BarcodeId": "BarcodeId0",
  "Description": "Description6"
}
```

