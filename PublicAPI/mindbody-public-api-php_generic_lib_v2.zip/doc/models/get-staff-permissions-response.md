
# Get Staff Permissions Response

## Structure

`GetStaffPermissionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `userGroup` | [`?StaffPermissionGroup`](../../doc/models/staff-permission-group.md) | Optional | - | getUserGroup(): ?StaffPermissionGroup | setUserGroup(?StaffPermissionGroup userGroup): void |

## Example (as JSON)

```json
{
  "UserGroup": null
}
```

