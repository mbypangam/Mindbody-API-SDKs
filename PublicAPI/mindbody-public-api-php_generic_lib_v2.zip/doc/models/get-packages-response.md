
# Get Packages Response

## Structure

`GetPackagesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `packages` | [`?(Package[])`](../../doc/models/package.md) | Optional | Contains information about the resulting packages. | getPackages(): ?array | setPackages(?array packages): void |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |

## Example (as JSON)

```json
{
  "Packages": null,
  "PaginationResponse": null
}
```

