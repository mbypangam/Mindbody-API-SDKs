
# Get Promo Codes Response

## Structure

`GetPromoCodesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Pagination Response | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `promoCodes` | [`?(MindbodyPublicApiDtoModelsV6PromoCode[])`](../../doc/models/mindbody-public-api-dto-models-v6-promo-code.md) | Optional | Contains information about Promocodes at a site | getPromoCodes(): ?array | setPromoCodes(?array promoCodes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "PromoCodes": null
}
```

