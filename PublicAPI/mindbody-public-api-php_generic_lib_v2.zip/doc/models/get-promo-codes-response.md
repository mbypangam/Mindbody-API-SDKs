
# Get Promo Codes Response

## Structure

`GetPromoCodesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `promoCodes` | [`?(PromoCode[])`](../../doc/models/promo-code.md) | Optional | Contains information about Promocodes at a site | getPromoCodes(): ?array | setPromoCodes(?array promoCodes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "PromoCodes": [
    {
      "PromotionID": 146,
      "Name": "Name8",
      "Code": "Code8",
      "Active": false,
      "Discount": {
        "Type": "Type4",
        "Amount": 176.86
      }
    }
  ]
}
```

