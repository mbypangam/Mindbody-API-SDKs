
# Pick a Spot Class

Contains information about the PickASpot classes.

## Structure

`PickASpotClass`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `siteId` | `?int` | Optional | The unique ID of the Site. | getSiteId(): ?int | setSiteId(?int siteId): void |
| `locationId` | `?int` | Optional | The unique ID of the Location. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `classId` | `?string` | Optional | The unique ID of the Class. | getClassId(): ?string | setClassId(?string classId): void |
| `classExternalId` | `?string` | Optional | The unique Class external ID. | getClassExternalId(): ?string | setClassExternalId(?string classExternalId): void |
| `className` | `?string` | Optional | Contains the class name. | getClassName(): ?string | setClassName(?string className): void |
| `classStartTime` | `?\DateTime` | Optional | Class start time. | getClassStartTime(): ?\DateTime | setClassStartTime(?\DateTime classStartTime): void |
| `classEndTime` | `?\DateTime` | Optional | Class end time. | getClassEndTime(): ?\DateTime | setClassEndTime(?\DateTime classEndTime): void |
| `classMaximumCapacity` | `?int` | Optional | Contains information about the Class maximum capacity. | getClassMaximumCapacity(): ?int | setClassMaximumCapacity(?int classMaximumCapacity): void |
| `roomId` | `?string` | Optional | The unique Room ID. | getRoomId(): ?string | setRoomId(?string roomId): void |
| `spots` | [`?Spot`](../../doc/models/spot.md) | Optional | Contains information about the spot details. | getSpots(): ?Spot | setSpots(?Spot spots): void |
| `reservations` | [`?(Reservation[])`](../../doc/models/reservation.md) | Optional | Contains information about the reservation collection. | getReservations(): ?array | setReservations(?array reservations): void |

## Example (as JSON)

```json
{
  "SiteId": 164,
  "LocationId": 50,
  "ClassId": "ClassId8",
  "ClassExternalId": "ClassExternalId2",
  "ClassName": "ClassName8"
}
```

