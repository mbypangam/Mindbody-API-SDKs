
# Pick a Spot Class

Pick A Spot class detail.

## Structure

`PickASpotClass`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `siteId` | `?int` | Optional | Site ID. | getSiteId(): ?int | setSiteId(?int siteId): void |
| `locationId` | `?int` | Optional | Location ID. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `classId` | `?string` | Optional | Class ID. | getClassId(): ?string | setClassId(?string classId): void |
| `classExternalId` | `?string` | Optional | Class external ID. | getClassExternalId(): ?string | setClassExternalId(?string classExternalId): void |
| `className` | `?string` | Optional | Class Name. | getClassName(): ?string | setClassName(?string className): void |
| `classStartTime` | `?\DateTime` | Optional | Class start time. | getClassStartTime(): ?\DateTime | setClassStartTime(?\DateTime classStartTime): void |
| `classEndTime` | `?\DateTime` | Optional | Class end time. | getClassEndTime(): ?\DateTime | setClassEndTime(?\DateTime classEndTime): void |
| `classMaximumCapacity` | `?int` | Optional | Class maximum capacity | getClassMaximumCapacity(): ?int | setClassMaximumCapacity(?int classMaximumCapacity): void |
| `roomId` | `?string` | Optional | - | getRoomId(): ?string | setRoomId(?string roomId): void |
| `spots` | [`?Spot`](../../doc/models/spot.md) | Optional | - | getSpots(): ?Spot | setSpots(?Spot spots): void |
| `reservations` | [`?(Reservation[])`](../../doc/models/reservation.md) | Optional | - | getReservations(): ?array | setReservations(?array reservations): void |

## Example (as JSON)

```json
{
  "SiteId": null,
  "LocationId": null,
  "ClassId": null,
  "ClassExternalId": null,
  "ClassName": null,
  "ClassStartTime": null,
  "ClassEndTime": null,
  "ClassMaximumCapacity": null,
  "RoomId": null,
  "Spots": null,
  "Reservations": null
}
```

