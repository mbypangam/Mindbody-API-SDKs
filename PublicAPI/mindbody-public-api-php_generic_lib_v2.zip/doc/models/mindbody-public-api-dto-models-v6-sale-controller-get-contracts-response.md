
# Mindbody Public Api Dto Models V6 Sale Controller Get Contracts Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `contracts` | [`?(MindbodyPublicApiDtoModelsV6Contract[])`](../../doc/models/mindbody-public-api-dto-models-v6-contract.md) | Optional | Contains information about each contract. | getContracts(): ?array | setContracts(?array contracts): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Contracts": null
}
```

