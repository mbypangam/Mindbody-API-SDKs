
# Initialize Credit Card Entry Request

## Structure

`InitializeCreditCardEntryRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `merchantAccountId` | `?string` | Optional | - | getMerchantAccountId(): ?string | setMerchantAccountId(?string merchantAccountId): void |
| `locationId` | `?int` | Optional | The ID associated with the location of the sale. | getLocationId(): ?int | setLocationId(?int locationId): void |

## Example (as JSON)

```json
{
  "MerchantAccountId": "MerchantAccountId0",
  "LocationId": 50
}
```

