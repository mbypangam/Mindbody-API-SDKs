
# Resource 1

## Structure

`Resource1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `locationId` | `?int` | Optional | - | getLocationId(): ?int | setLocationId(?int locationId): void |
| `isActive` | `?bool` | Optional | - | getIsActive(): ?bool | setIsActive(?bool isActive): void |
| `scheduleTypes` | [`?(string(ScheduleType4Enum)[])`](../../doc/models/schedule-type-4-enum.md) | Optional | - | getScheduleTypes(): ?array | setScheduleTypes(?array scheduleTypes): void |
| `programIds` | `?(int[])` | Optional | - | getProgramIds(): ?array | setProgramIds(?array programIds): void |

## Example (as JSON)

```json
{
  "Id": 168,
  "Name": "Name8",
  "LocationId": 28,
  "IsActive": false,
  "ScheduleTypes": [
    "Media",
    "Resource",
    "Appointment"
  ]
}
```

