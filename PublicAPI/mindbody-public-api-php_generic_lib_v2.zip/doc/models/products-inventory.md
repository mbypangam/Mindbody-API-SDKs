
# Products Inventory

## Structure

`ProductsInventory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `productId` | `?int` | Optional | A ProductId of the product. | getProductId(): ?int | setProductId(?int productId): void |
| `barcodeId` | `?string` | Optional | The Id is barcode Id of the product. | getBarcodeId(): ?string | setBarcodeId(?string barcodeId): void |
| `locationId` | `?int` | Optional | The LocationId of the product. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `unitsLogged` | `?int` | Optional | UnitsLogged of the product. | getUnitsLogged(): ?int | setUnitsLogged(?int unitsLogged): void |
| `unitsSold` | `?int` | Optional | UnitsSold of the product. | getUnitsSold(): ?int | setUnitsSold(?int unitsSold): void |
| `unitsInStock` | `?int` | Optional | The units in stock of the product | getUnitsInStock(): ?int | setUnitsInStock(?int unitsInStock): void |
| `reorderLevel` | `?int` | Optional | ReorderLevel of the product. | getReorderLevel(): ?int | setReorderLevel(?int reorderLevel): void |
| `maxLevel` | `?int` | Optional | MaxLevel of the product. | getMaxLevel(): ?int | setMaxLevel(?int maxLevel): void |
| `createdDateTimeUTC` | `?\DateTime` | Optional | CreatedDateTimeUTC of the product. | getCreatedDateTimeUTC(): ?\DateTime | setCreatedDateTimeUTC(?\DateTime createdDateTimeUTC): void |
| `modifiedDateTimeUTC` | `?\DateTime` | Optional | ModifiedDateTimeUTC of the product. | getModifiedDateTimeUTC(): ?\DateTime | setModifiedDateTimeUTC(?\DateTime modifiedDateTimeUTC): void |

## Example (as JSON)

```json
{
  "ProductId": null,
  "BarcodeId": null,
  "LocationId": null,
  "UnitsLogged": null,
  "UnitsSold": null,
  "UnitsInStock": null,
  "ReorderLevel": null,
  "MaxLevel": null,
  "CreatedDateTimeUTC": null,
  "ModifiedDateTimeUTC": null
}
```

