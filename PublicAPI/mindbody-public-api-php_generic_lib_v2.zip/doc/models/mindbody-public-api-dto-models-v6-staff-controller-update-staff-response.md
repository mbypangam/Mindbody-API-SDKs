
# Mindbody Public Api Dto Models V6 Staff Controller Update Staff Response

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staff` | [`?MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | The Staff | getStaff(): ?MindbodyPublicApiDtoModelsV6Staff | setStaff(?MindbodyPublicApiDtoModelsV6Staff staff): void |

## Example (as JSON)

```json
{
  "Staff": null
}
```

