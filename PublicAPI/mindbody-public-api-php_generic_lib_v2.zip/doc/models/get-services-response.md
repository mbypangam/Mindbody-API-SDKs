
# Get Services Response

## Structure

`GetServicesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `services` | [`?(Service[])`](../../doc/models/service.md) | Optional | Contains information about the services. | getServices(): ?array | setServices(?array services): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Services": null
}
```

