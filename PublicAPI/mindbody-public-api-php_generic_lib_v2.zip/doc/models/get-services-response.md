
# Get Services Response

## Structure

`GetServicesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `services` | [`?(Service[])`](../../doc/models/service.md) | Optional | Contains information about the services. | getServices(): ?array | setServices(?array services): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Services": [
    {
      "Price": 77.35,
      "OnlinePrice": 111.87,
      "TaxIncluded": 184.89,
      "ProgramId": 101,
      "TaxRate": 45.39
    }
  ]
}
```

