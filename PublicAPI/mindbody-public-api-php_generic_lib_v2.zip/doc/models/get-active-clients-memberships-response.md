
# Get Active Clients Memberships Response

## Structure

`GetActiveClientsMembershipsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `clientMemberships` | [`?(ClientMemberships[])`](../../doc/models/client-memberships.md) | Optional | Details about the requested memberships. | getClientMemberships(): ?array | setClientMemberships(?array clientMemberships): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "ClientMemberships": [
    {
      "ClientId": "ClientId4",
      "Memberships": [
        {
          "RestrictedLocations": [
            {
              "AdditionalImageURLs": [
                "AdditionalImageURLs0",
                "AdditionalImageURLs1"
              ],
              "Address": "Address4",
              "Address2": "Address26",
              "Amenities": [
                {
                  "Id": 200,
                  "Name": "Name8"
                },
                {
                  "Id": 199,
                  "Name": "Name9"
                },
                {
                  "Id": 198,
                  "Name": "Name0"
                }
              ],
              "BusinessDescription": "BusinessDescription0"
            }
          ],
          "IconCode": "IconCode3",
          "MembershipId": 137,
          "ActiveDate": "2016-03-13T12:52:32.123Z",
          "Count": 137
        },
        {
          "RestrictedLocations": [
            {
              "AdditionalImageURLs": [
                "AdditionalImageURLs1",
                "AdditionalImageURLs2",
                "AdditionalImageURLs3"
              ],
              "Address": "Address3",
              "Address2": "Address25",
              "Amenities": [
                {
                  "Id": 199,
                  "Name": "Name9"
                }
              ],
              "BusinessDescription": "BusinessDescription9"
            },
            {
              "AdditionalImageURLs": [
                "AdditionalImageURLs0",
                "AdditionalImageURLs1"
              ],
              "Address": "Address4",
              "Address2": "Address26",
              "Amenities": [
                {
                  "Id": 200,
                  "Name": "Name8"
                },
                {
                  "Id": 199,
                  "Name": "Name9"
                },
                {
                  "Id": 198,
                  "Name": "Name0"
                }
              ],
              "BusinessDescription": "BusinessDescription0"
            },
            {
              "AdditionalImageURLs": [
                "AdditionalImageURLs9"
              ],
              "Address": "Address5",
              "Address2": "Address27",
              "Amenities": [
                {
                  "Id": 201,
                  "Name": "Name7"
                },
                {
                  "Id": 200,
                  "Name": "Name8"
                }
              ],
              "BusinessDescription": "BusinessDescription1"
            }
          ],
          "IconCode": "IconCode4",
          "MembershipId": 138,
          "ActiveDate": "2016-03-13T12:52:32.123Z",
          "Count": 138
        },
        {
          "RestrictedLocations": [
            {
              "AdditionalImageURLs": [
                "AdditionalImageURLs2"
              ],
              "Address": "Address2",
              "Address2": "Address24",
              "Amenities": [
                {
                  "Id": 198,
                  "Name": "Name0"
                },
                {
                  "Id": 197,
                  "Name": "Name1"
                }
              ],
              "BusinessDescription": "BusinessDescription8"
            },
            {
              "AdditionalImageURLs": [
                "AdditionalImageURLs1",
                "AdditionalImageURLs2",
                "AdditionalImageURLs3"
              ],
              "Address": "Address3",
              "Address2": "Address25",
              "Amenities": [
                {
                  "Id": 199,
                  "Name": "Name9"
                }
              ],
              "BusinessDescription": "BusinessDescription9"
            }
          ],
          "IconCode": "IconCode5",
          "MembershipId": 139,
          "ActiveDate": "2016-03-13T12:52:32.123Z",
          "Count": 139
        }
      ],
      "ErrorMessage": "ErrorMessage0"
    },
    {
      "ClientId": "ClientId5",
      "Memberships": [
        {
          "RestrictedLocations": [
            {
              "AdditionalImageURLs": [
                "AdditionalImageURLs9"
              ],
              "Address": "Address5",
              "Address2": "Address27",
              "Amenities": [
                {
                  "Id": 201,
                  "Name": "Name7"
                },
                {
                  "Id": 200,
                  "Name": "Name8"
                }
              ],
              "BusinessDescription": "BusinessDescription1"
            },
            {
              "AdditionalImageURLs": [
                "AdditionalImageURLs8",
                "AdditionalImageURLs9",
                "AdditionalImageURLs0"
              ],
              "Address": "Address6",
              "Address2": "Address28",
              "Amenities": [
                {
                  "Id": 202,
                  "Name": "Name6"
                }
              ],
              "BusinessDescription": "BusinessDescription2"
            }
          ],
          "IconCode": "IconCode2",
          "MembershipId": 136,
          "ActiveDate": "2016-03-13T12:52:32.123Z",
          "Count": 136
        },
        {
          "RestrictedLocations": [
            {
              "AdditionalImageURLs": [
                "AdditionalImageURLs0",
                "AdditionalImageURLs1"
              ],
              "Address": "Address4",
              "Address2": "Address26",
              "Amenities": [
                {
                  "Id": 200,
                  "Name": "Name8"
                },
                {
                  "Id": 199,
                  "Name": "Name9"
                },
                {
                  "Id": 198,
                  "Name": "Name0"
                }
              ],
              "BusinessDescription": "BusinessDescription0"
            }
          ],
          "IconCode": "IconCode3",
          "MembershipId": 137,
          "ActiveDate": "2016-03-13T12:52:32.123Z",
          "Count": 137
        }
      ],
      "ErrorMessage": "ErrorMessage9"
    },
    {
      "ClientId": "ClientId6",
      "Memberships": [
        {
          "RestrictedLocations": [
            {
              "AdditionalImageURLs": [
                "AdditionalImageURLs8",
                "AdditionalImageURLs9",
                "AdditionalImageURLs0"
              ],
              "Address": "Address6",
              "Address2": "Address28",
              "Amenities": [
                {
                  "Id": 202,
                  "Name": "Name6"
                }
              ],
              "BusinessDescription": "BusinessDescription2"
            },
            {
              "AdditionalImageURLs": [
                "AdditionalImageURLs7",
                "AdditionalImageURLs8"
              ],
              "Address": "Address7",
              "Address2": "Address29",
              "Amenities": [
                {
                  "Id": 203,
                  "Name": "Name5"
                },
                {
                  "Id": 202,
                  "Name": "Name6"
                },
                {
                  "Id": 201,
                  "Name": "Name7"
                }
              ],
              "BusinessDescription": "BusinessDescription3"
            },
            {
              "AdditionalImageURLs": [
                "AdditionalImageURLs6"
              ],
              "Address": "Address8",
              "Address2": "Address20",
              "Amenities": [
                {
                  "Id": 204,
                  "Name": "Name4"
                },
                {
                  "Id": 203,
                  "Name": "Name5"
                }
              ],
              "BusinessDescription": "BusinessDescription4"
            }
          ],
          "IconCode": "IconCode1",
          "MembershipId": 135,
          "ActiveDate": "2016-03-13T12:52:32.123Z",
          "Count": 135
        }
      ],
      "ErrorMessage": "ErrorMessage8"
    }
  ]
}
```

