
# Get Active Clients Memberships Response

## Structure

`GetActiveClientsMembershipsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `clientMemberships` | [`?(ClientMemberships[])`](../../doc/models/client-memberships.md) | Optional | Details about the requested memberships. | getClientMemberships(): ?array | setClientMemberships(?array clientMemberships): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientMemberships": null
}
```

