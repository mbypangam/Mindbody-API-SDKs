
# Action 6 Enum

The action performed on this object.

## Enumeration

`Action6Enum`

## Fields

| Name |
|  --- |
| `NONE` |
| `ADDED` |
| `UPDATED` |
| `FAILED` |
| `REMOVED` |

