
# Mindbody Public Api Dto Models V6 Client Controller Get Client Duplicates Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `clientDuplicates` | [`?(MindbodyPublicApiDtoModelsV6ClientDuplicate[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-duplicate.md) | Optional | The requested clients. | getClientDuplicates(): ?array | setClientDuplicates(?array clientDuplicates): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientDuplicates": null
}
```

