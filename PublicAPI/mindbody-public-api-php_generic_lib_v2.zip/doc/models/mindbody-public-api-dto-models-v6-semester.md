
# Mindbody Public Api Dto Models V6 Semester

Semesters help you quickly classify enrollments.

## Structure

`MindbodyPublicApiDtoModelsV6Semester`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | This semester?s unique ID. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | Name of the semester. | getName(): ?string | setName(?string name): void |
| `description` | `?string` | Optional | The description of the semester. | getDescription(): ?string | setDescription(?string description): void |
| `startDate` | `?\DateTime` | Optional | Start date of the semester. | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | End date of the semester. | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `multiRegistrationDiscount` | `?float` | Optional | Discount for multiple registration in the semester. | getMultiRegistrationDiscount(): ?float | setMultiRegistrationDiscount(?float multiRegistrationDiscount): void |
| `multiRegistrationDeadline` | `?\DateTime` | Optional | Registration deadline of the semester. | getMultiRegistrationDeadline(): ?\DateTime | setMultiRegistrationDeadline(?\DateTime multiRegistrationDeadline): void |
| `active` | `?bool` | Optional | When `true`, indicates that the semester is active. | getActive(): ?bool | setActive(?bool active): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null,
  "StartDate": null,
  "EndDate": null,
  "MultiRegistrationDiscount": null,
  "MultiRegistrationDeadline": null,
  "Active": null
}
```

