
# Mindbody Public Api Dto Models V6 Semester

Semesters help you quickly classify enrollments.

## Structure

`MindbodyPublicApiDtoModelsV6Semester`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |
| `startDate` | `?\DateTime` | Optional | - | getStartDate(): ?\DateTime | setStartDate(?\DateTime startDate): void |
| `endDate` | `?\DateTime` | Optional | - | getEndDate(): ?\DateTime | setEndDate(?\DateTime endDate): void |
| `multiRegistrationDiscount` | `?float` | Optional | - | getMultiRegistrationDiscount(): ?float | setMultiRegistrationDiscount(?float multiRegistrationDiscount): void |
| `multiRegistrationDeadline` | `?\DateTime` | Optional | - | getMultiRegistrationDeadline(): ?\DateTime | setMultiRegistrationDeadline(?\DateTime multiRegistrationDeadline): void |
| `active` | `?bool` | Optional | - | getActive(): ?bool | setActive(?bool active): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null,
  "StartDate": null,
  "EndDate": null,
  "MultiRegistrationDiscount": null,
  "MultiRegistrationDeadline": null,
  "Active": null
}
```

