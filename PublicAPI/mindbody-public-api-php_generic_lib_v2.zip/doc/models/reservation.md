
# Reservation

## Structure

`Reservation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reservationId` | `?string` | Optional | - | getReservationId(): ?string | setReservationId(?string reservationId): void |
| `reservationExternalId` | `?string` | Optional | - | getReservationExternalId(): ?string | setReservationExternalId(?string reservationExternalId): void |
| `classId` | `?string` | Optional | - | getClassId(): ?string | setClassId(?string classId): void |
| `classExternalId` | `?string` | Optional | - | getClassExternalId(): ?string | setClassExternalId(?string classExternalId): void |
| `memberExternalId` | `?string` | Optional | - | getMemberExternalId(): ?string | setMemberExternalId(?string memberExternalId): void |
| `reservationType` | `?string` | Optional | - | getReservationType(): ?string | setReservationType(?string reservationType): void |
| `spots` | [`?Spot`](../../doc/models/spot.md) | Optional | - | getSpots(): ?Spot | setSpots(?Spot spots): void |
| `isConfirmed` | `?bool` | Optional | - | getIsConfirmed(): ?bool | setIsConfirmed(?bool isConfirmed): void |
| `confirmationDate` | `?\DateTime` | Optional | - | getConfirmationDate(): ?\DateTime | setConfirmationDate(?\DateTime confirmationDate): void |

## Example (as JSON)

```json
{
  "ReservationId": null,
  "ReservationExternalId": null,
  "ClassId": null,
  "ClassExternalId": null,
  "MemberExternalId": null,
  "ReservationType": null,
  "Spots": null,
  "IsConfirmed": null,
  "ConfirmationDate": null
}
```

