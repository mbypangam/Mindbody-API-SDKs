
# Reservation

Contains information about the reservation.

## Structure

`Reservation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reservationId` | `?string` | Optional | The unique reservation ID. | getReservationId(): ?string | setReservationId(?string reservationId): void |
| `reservationExternalId` | `?string` | Optional | The unique reservation external ID. | getReservationExternalId(): ?string | setReservationExternalId(?string reservationExternalId): void |
| `classId` | `?string` | Optional | The unique class ID. | getClassId(): ?string | setClassId(?string classId): void |
| `classExternalId` | `?string` | Optional | The unique class external ID. | getClassExternalId(): ?string | setClassExternalId(?string classExternalId): void |
| `memberExternalId` | `?string` | Optional | The unique member external ID. | getMemberExternalId(): ?string | setMemberExternalId(?string memberExternalId): void |
| `reservationType` | `?string` | Optional | Contains information about the reservation type. | getReservationType(): ?string | setReservationType(?string reservationType): void |
| `spots` | [`?Spot`](../../doc/models/spot.md) | Optional | Contains information about the spot details. | getSpots(): ?Spot | setSpots(?Spot spots): void |
| `isConfirmed` | `?bool` | Optional | Boolean value whether it is confirmed. | getIsConfirmed(): ?bool | setIsConfirmed(?bool isConfirmed): void |
| `confirmationDate` | `?DateTime` | Optional | Contains information about the confirmation date. | getConfirmationDate(): ?\DateTime | setConfirmationDate(?\DateTime confirmationDate): void |

## Example (as JSON)

```json
{
  "ReservationId": "ReservationId2",
  "ReservationExternalId": "ReservationExternalId4",
  "ClassId": "ClassId4",
  "ClassExternalId": "ClassExternalId6",
  "MemberExternalId": "MemberExternalId4"
}
```

