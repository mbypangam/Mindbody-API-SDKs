
# Get Prospect Stages Response

Get Prospect Stages Response Model

## Structure

`GetProspectStagesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `prospectStages` | [`?(MindbodyPublicApiDtoModelsV6ProspectStage[])`](../../doc/models/mindbody-public-api-dto-models-v6-prospect-stage.md) | Optional | List of Prospect Stages | getProspectStages(): ?array | setProspectStages(?array prospectStages): void |

## Example (as JSON)

```json
{
  "ProspectStages": null
}
```

