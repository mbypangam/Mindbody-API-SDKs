
# Issue Response

POST UserToken/Issue successful response

## Structure

`IssueResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `tokenType` | `?string` | Optional | - | getTokenType(): ?string | setTokenType(?string tokenType): void |
| `accessToken` | `?string` | Optional | The authentication token value. | getAccessToken(): ?string | setAccessToken(?string accessToken): void |
| `expires` | `?DateTime` | Optional | Token expiration in UTC. | getExpires(): ?\DateTime | setExpires(?\DateTime expires): void |
| `user` | [`?User`](../../doc/models/user.md) | Optional | - | getUser(): ?User | setUser(?User user): void |

## Example (as JSON)

```json
{
  "TokenType": "TokenType2",
  "AccessToken": "AccessToken6",
  "Expires": "2016-03-13T12:52:32.123Z",
  "User": {
    "Id": 116,
    "FirstName": "FirstName8",
    "LastName": "LastName2",
    "Type": "Type6"
  }
}
```

