
# Visit

Represents a specific visit to a class

## Structure

`Visit`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appointmentId` | `?int` | Optional | The appointment’s ID. | getAppointmentId(): ?int | setAppointmentId(?int appointmentId): void |
| `appointmentGenderPreference` | [`?string (AppointmentGenderPreferenceEnum)`](../../doc/models/appointment-gender-preference-enum.md) | Optional | The gender of staff member with whom the client prefers to book appointments.<br><br>Possible values are:<br><br>* Female - Indicates that the client prefers to book appointments with female staff members.<br>* Male - Indicates that the client prefers to book appointments with male staff members.<br>* None - Indicates that the client does not have a staff member gender preference. | getAppointmentGenderPreference(): ?string | setAppointmentGenderPreference(?string appointmentGenderPreference): void |
| `appointmentStatus` | [`?string (AppointmentStatusEnum)`](../../doc/models/appointment-status-enum.md) | Optional | The status of the appointment. | getAppointmentStatus(): ?string | setAppointmentStatus(?string appointmentStatus): void |
| `classId` | `?int` | Optional | The class ID that was used to retrieve the visits. | getClassId(): ?int | setClassId(?int classId): void |
| `clientId` | `?string` | Optional | The ID of the client associated with the visit. | getClientId(): ?string | setClientId(?string clientId): void |
| `clientUniqueId` | `?int` | Optional | The unique ID of the client associated with the visit. | getClientUniqueId(): ?int | setClientUniqueId(?int clientUniqueId): void |
| `startDateTime` | `?\DateTime` | Optional | The time this class is scheduled to start. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | The date and time the visit ends. The Public API returns UTC dates and times. For example, a class that occurs on June 25th, 2018 at 2:15PM (EST) appears as “2018-06-25T19:15:00Z” because EST is five hours behind UTC. Date time pairs always return in the format YYYY-MM-DDTHH:mm:ssZ. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `id` | `?int` | Optional | The ID of the visit. | getId(): ?int | setId(?int id): void |
| `lastModifiedDateTime` | `?\DateTime` | Optional | When included in the request, only records modified on or after the specified `LastModifiedDate` are included in the response. The Public API returns UTC dates and times. For example, a class that occurs on June 25th, 2018 at 2:15PM (EST) appears as “2018-06-25T19:15:00Z” because EST is five hours behind UTC. Date time pairs always return in the format YYYY-MM-DDTHH:mm:ssZ. | getLastModifiedDateTime(): ?\DateTime | setLastModifiedDateTime(?\DateTime lastModifiedDateTime): void |
| `lateCancelled` | `?bool` | Optional | When `true`, indicates that the class has been `LateCancelled`.<br /><br>When `false`, indicates that the class has not been `LateCancelled`. | getLateCancelled(): ?bool | setLateCancelled(?bool lateCancelled): void |
| `siteId` | `?int` | Optional | The ID of the business where the visit is booked. | getSiteId(): ?int | setSiteId(?int siteId): void |
| `locationId` | `?int` | Optional | The ID of the location where the visit took place or is to take place. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `makeUp` | `?bool` | Optional | When `true`, the client can make up this session and a session is not deducted from the pricing option that was used to sign the client into the enrollment. When the client has the make-up session, a session is automatically removed from a pricing option that matches the service category of the enrollment and is within the same date range of the missed session.<br /><br>When `false`, the client cannot make up this session. See [Enrollments: Make-ups](https://support.mindbodyonline.com/s/article/203259433-Enrollments-Make-ups?language=en_US) for more information. | getMakeUp(): ?bool | setMakeUp(?bool makeUp): void |
| `name` | `?string` | Optional | The name of the class. | getName(): ?string | setName(?string name): void |
| `serviceId` | `?int` | Optional | The unique ID assigned to this pricing option when it was purchased by the client. | getServiceId(): ?int | setServiceId(?int serviceId): void |
| `serviceName` | `?string` | Optional | The name of the pricing option at the site where it was purchased. | getServiceName(): ?string | setServiceName(?string serviceName): void |
| `productId` | `?int` | Optional | The ID of the pricing option at the site where it was purchased. | getProductId(): ?int | setProductId(?int productId): void |
| `signedIn` | `?bool` | Optional | When `true`, indicates that the client has been signed in.<br /><br>When `false`, indicates that the client has not been signed in. | getSignedIn(): ?bool | setSignedIn(?bool signedIn): void |
| `staffId` | `?int` | Optional | The ID of the staff member who is teaching the class. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `webSignup` | `?bool` | Optional | When `true`, indicates that the client signed up online.<br /><br>When `false`, indicates that the client was signed up by a staff member. | getWebSignup(): ?bool | setWebSignup(?bool webSignup): void |
| `action` | [`?string (Action1Enum)`](../../doc/models/action-1-enum.md) | Optional | The action taken. | getAction(): ?string | setAction(?string action): void |
| `missed` | `?bool` | Optional | When `true`, indicates that the class has been `Missed`.<br /><br>When `false`, indicates that the class has not been `Missed`. | getMissed(): ?bool | setMissed(?bool missed): void |
| `visitType` | `?int` | Optional | Indicates the Id of visit type. | getVisitType(): ?int | setVisitType(?int visitType): void |
| `typeGroup` | `?int` | Optional | Indicates the Id of type group. | getTypeGroup(): ?int | setTypeGroup(?int typeGroup): void |
| `typeTaken` | `?string` | Optional | Indicates the service type taken. | getTypeTaken(): ?string | setTypeTaken(?string typeTaken): void |

## Example (as JSON)

```json
{
  "AppointmentId": null,
  "AppointmentGenderPreference": null,
  "AppointmentStatus": null,
  "ClassId": null,
  "ClientId": null,
  "ClientUniqueId": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Id": null,
  "LastModifiedDateTime": null,
  "LateCancelled": null,
  "SiteId": null,
  "LocationId": null,
  "MakeUp": null,
  "Name": null,
  "ServiceId": null,
  "ServiceName": null,
  "ProductId": null,
  "SignedIn": null,
  "StaffId": null,
  "WebSignup": null,
  "Action": null,
  "Missed": null,
  "VisitType": null,
  "TypeGroup": null,
  "TypeTaken": null
}
```

