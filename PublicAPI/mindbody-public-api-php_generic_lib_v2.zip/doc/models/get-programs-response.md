
# Get Programs Response

## Structure

`GetProgramsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `programs` | [`?(MindbodyPublicApiDtoModelsV6Program[])`](../../doc/models/mindbody-public-api-dto-models-v6-program.md) | Optional | Contains information about the programs. | getPrograms(): ?array | setPrograms(?array programs): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Programs": null
}
```

