
# Mindbody Public Api Dto Models V6 Client Controller Add Client Direct Debit Info Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `?string` | Optional | The ID of the client being updated | getClientId(): ?string | setClientId(?string clientId): void |
| `nameOnAccount` | `?string` | Optional | The name on the bank account being added | getNameOnAccount(): ?string | setNameOnAccount(?string nameOnAccount): void |
| `routingNumber` | `?string` | Optional | The routing number of the bank account being added | getRoutingNumber(): ?string | setRoutingNumber(?string routingNumber): void |
| `accountNumber` | `?string` | Optional | The bank account number | getAccountNumber(): ?string | setAccountNumber(?string accountNumber): void |
| `accountType` | `?string` | Optional | The account type.<br><br>Possible values:<br><br>* Checking<br>* Savings | getAccountType(): ?string | setAccountType(?string accountType): void |

## Example (as JSON)

```json
{
  "ClientId": null,
  "NameOnAccount": null,
  "RoutingNumber": null,
  "AccountNumber": null,
  "AccountType": null
}
```

