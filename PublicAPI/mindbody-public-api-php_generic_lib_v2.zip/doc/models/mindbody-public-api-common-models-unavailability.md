
# Mindbody Public Api Common Models Unavailability

## Structure

`MindbodyPublicApiCommonModelsUnavailability`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | Unavailabiltity ID. | getId(): ?int | setId(?int id): void |
| `startDateTime` | `?\DateTime` | Optional | Start of the unavailability. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | End of the unavailability. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `description` | `?string` | Optional | Description of the unavailability. | getDescription(): ?string | setDescription(?string description): void |

## Example (as JSON)

```json
{
  "Id": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Description": null
}
```

