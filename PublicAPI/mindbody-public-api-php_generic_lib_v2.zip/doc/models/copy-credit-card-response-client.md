
# Copy Credit Card Response Client

## Structure

`CopyCreditCardResponseClient`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `?string` | Optional | ClientId | getClientId(): ?string | setClientId(?string clientId): void |
| `siteId` | `?int` | Optional | SiteId | getSiteId(): ?int | setSiteId(?int siteId): void |
| `firstName` | `?string` | Optional | First name of ClientId | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | Last name of ClientId | getLastName(): ?string | setLastName(?string lastName): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId0",
  "SiteId": 246,
  "FirstName": "FirstName8",
  "LastName": "LastName2"
}
```

