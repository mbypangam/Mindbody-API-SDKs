
# Mindbody Public Api Dto Models V6 Appointment Controller Update Availability Request

This is the update avaialability request coming DTO

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `availabilityIds` | `?(int[])` | Optional | Unique IDs for the availabilities or unavailabilities. | getAvailabilityIds(): ?array | setAvailabilityIds(?array availabilityIds): void |
| `publicDisplay` | [`?string (PublicDisplayEnum)`](../../doc/models/public-display-enum.md) | Optional | Choice that decides whether the availablity should be publicly visible, masked or hidden. | getPublicDisplay(): ?string | setPublicDisplay(?string publicDisplay): void |
| `daysOfWeek` | [`?(string[]) (DaysOfWeekEnum)`](../../doc/models/days-of-week-enum.md) | Optional | The days of week to update the availabilities or unavailabilities.<br /><br>Default: **All** | getDaysOfWeek(): ?array | setDaysOfWeek(?array daysOfWeek): void |
| `programIds` | `?(int[])` | Optional | The program Id to be set for the availabilities.<br>Default: **All** | getProgramIds(): ?array | setProgramIds(?array programIds): void |
| `startDateTime` | `?\DateTime` | Optional | The start date and time for the availabilities or unavailabilities. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | The end date and time for the availabilities or unavailabilities. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `locationId` | `?int` | Optional | The location Id to be updated for the provided availability Ids. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `unavailableDescription` | `?string` | Optional | The description for unavailability. | getUnavailableDescription(): ?string | setUnavailableDescription(?string unavailableDescription): void |
| `test` | `?bool` | Optional | When `true`, the request ensures that its parameters are valid without affecting real data.<br>When ``false`, the request performs as intended and may affect live client data.<br>Default: **false** | getTest(): ?bool | setTest(?bool test): void |

## Example (as JSON)

```json
{
  "AvailabilityIds": null,
  "PublicDisplay": null,
  "DaysOfWeek": null,
  "ProgramIds": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "LocationId": null,
  "UnavailableDescription": null,
  "Test": null
}
```

