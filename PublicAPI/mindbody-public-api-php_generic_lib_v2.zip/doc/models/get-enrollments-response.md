
# Get Enrollments Response

## Structure

`GetEnrollmentsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `enrollments` | [`?(ClassSchedule[])`](../../doc/models/class-schedule.md) | Optional | Contains information about the enrollments. | getEnrollments(): ?array | setEnrollments(?array enrollments): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Enrollments": null
}
```

