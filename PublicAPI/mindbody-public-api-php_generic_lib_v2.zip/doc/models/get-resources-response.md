
# Get Resources Response

## Structure

`GetResourcesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `resources` | [`?(Resource2[])`](../../doc/models/resource.md) | Optional | Contains information about resources as the business. | getResources(): ?array | setResources(?array resources): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Resources": null
}
```

