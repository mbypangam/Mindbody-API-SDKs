
# Add Appointment Add on Response

## Structure

`AddAppointmentAddOnResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appointmentId` | `?int` | Optional | This is the id of the main appointment we added on to | getAppointmentId(): ?int | setAppointmentId(?int appointmentId): void |
| `addOnAppointmentId` | `?int` | Optional | This is the id for the newly created add-on appointment | getAddOnAppointmentId(): ?int | setAddOnAppointmentId(?int addOnAppointmentId): void |

## Example (as JSON)

```json
{
  "AppointmentId": null,
  "AddOnAppointmentId": null
}
```

