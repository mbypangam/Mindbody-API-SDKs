
# Color

A color used by products.

## Structure

`Color`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The unique ID of the product color. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the color of product. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": 40,
  "Name": "Name6"
}
```

