
# Mindbody Public Api Dto Models V6 Contact Log Comment

A contact log comment.

## Structure

`MindbodyPublicApiDtoModelsV6ContactLogComment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The comment's ID. | getId(): ?int | setId(?int id): void |
| `text` | `?string` | Optional | The comment's body text. | getText(): ?string | setText(?string text): void |
| `createdDateTime` | `?\DateTime` | Optional | The local time when the comment was created. | getCreatedDateTime(): ?\DateTime | setCreatedDateTime(?\DateTime createdDateTime): void |
| `createdBy` | [`?MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Information about the staff member who created the comment. | getCreatedBy(): ?MindbodyPublicApiDtoModelsV6Staff | setCreatedBy(?MindbodyPublicApiDtoModelsV6Staff createdBy): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Text": null,
  "CreatedDateTime": null,
  "CreatedBy": null
}
```

