
# Update Client Visit Response

## Structure

`UpdateClientVisitResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `visit` | [`?Visit`](../../doc/models/visit.md) | Optional | The updated visit. | getVisit(): ?Visit | setVisit(?Visit visit): void |

## Example (as JSON)

```json
{
  "Visit": null
}
```

