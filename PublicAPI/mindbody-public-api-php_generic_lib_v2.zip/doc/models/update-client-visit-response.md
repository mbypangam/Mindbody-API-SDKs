
# Update Client Visit Response

## Structure

`UpdateClientVisitResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `visit` | [`?Visit`](../../doc/models/visit.md) | Optional | Represents a specific visit to a class | getVisit(): ?Visit | setVisit(?Visit visit): void |

## Example (as JSON)

```json
{
  "Visit": null
}
```

