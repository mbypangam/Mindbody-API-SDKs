
# Mindbody Public Api Dto Models V6 Staff Controller Update Staff Permissions Response

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `userGroup` | [`?MindbodyPublicApiDtoModelsV6StaffPermissionGroup`](../../doc/models/mindbody-public-api-dto-models-v6-staff-permission-group.md) | Optional | - | getUserGroup(): ?MindbodyPublicApiDtoModelsV6StaffPermissionGroup | setUserGroup(?MindbodyPublicApiDtoModelsV6StaffPermissionGroup userGroup): void |

## Example (as JSON)

```json
{
  "UserGroup": null
}
```

