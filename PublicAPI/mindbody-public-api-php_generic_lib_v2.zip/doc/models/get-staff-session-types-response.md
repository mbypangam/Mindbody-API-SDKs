
# Get Staff Session Types Response

## Structure

`GetStaffSessionTypesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination properties used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `staffSessionTypes` | [`?(StaffSessionType[])`](../../doc/models/staff-session-type.md) | Optional | Contains information about staff member session types. | getStaffSessionTypes(): ?array | setStaffSessionTypes(?array staffSessionTypes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "StaffSessionTypes": null
}
```

