
# Mindbody Public Api Dto Models V6 Staff

The Staff

## Structure

`MindbodyPublicApiDtoModelsV6Staff`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `address` | `?string` | Optional | The address of the staff member who is teaching the class. | getAddress(): ?string | setAddress(?string address): void |
| `appointmentInstructor` | `?bool` | Optional | When `true`, indicates that the staff member offers appointments.<br /><br>When `false`, indicates that the staff member does not offer appointments. | getAppointmentInstructor(): ?bool | setAppointmentInstructor(?bool appointmentInstructor): void |
| `alwaysAllowDoubleBooking` | `?bool` | Optional | When `true`, indicates that the staff member can be scheduled for overlapping services.<br /><br>When `false`, indicates that the staff can only be scheduled for one service at a time in any given time-frame. | getAlwaysAllowDoubleBooking(): ?bool | setAlwaysAllowDoubleBooking(?bool alwaysAllowDoubleBooking): void |
| `bio` | `?string` | Optional | The staff member?s biography. This string contains HTML. | getBio(): ?string | setBio(?string bio): void |
| `city` | `?string` | Optional | The staff member?s city. | getCity(): ?string | setCity(?string city): void |
| `country` | `?string` | Optional | The staff member?s country. | getCountry(): ?string | setCountry(?string country): void |
| `email` | `?string` | Optional | The staff member?s email address. | getEmail(): ?string | setEmail(?string email): void |
| `firstName` | `?string` | Optional | The staff member?s first name. | getFirstName(): ?string | setFirstName(?string firstName): void |
| `displayName` | `?string` | Optional | The staff member?s Nickname. | getDisplayName(): ?string | setDisplayName(?string displayName): void |
| `homePhone` | `?string` | Optional | The staff member?s home phone number. | getHomePhone(): ?string | setHomePhone(?string homePhone): void |
| `id` | `?int` | Optional | The ID assigned to the staff member. | getId(): ?int | setId(?int id): void |
| `independentContractor` | `?bool` | Optional | When `true`, indicates that the staff member is an independent contractor.<br>When `false`, indicates that the staff member is not an independent contractor. | getIndependentContractor(): ?bool | setIndependentContractor(?bool independentContractor): void |
| `isMale` | `?bool` | Optional | When `true`, indicates that the staff member is male.<br>When `false`, indicates that the staff member is female. | getIsMale(): ?bool | setIsMale(?bool isMale): void |
| `lastName` | `?string` | Optional | The staff member?s last name. | getLastName(): ?string | setLastName(?string lastName): void |
| `mobilePhone` | `?string` | Optional | The staff member?s mobile phone number. | getMobilePhone(): ?string | setMobilePhone(?string mobilePhone): void |
| `name` | `?string` | Optional | The staff member?s name. | getName(): ?string | setName(?string name): void |
| `postalCode` | `?string` | Optional | The staff member?s postal code. | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `classTeacher` | `?bool` | Optional | When `true`, indicates that the staff member can teach classes.<br>When `false`, indicates that the staff member cannot teach classes. | getClassTeacher(): ?bool | setClassTeacher(?bool classTeacher): void |
| `sortOrder` | `?int` | Optional | If configured by the business owner, this field determines a staff member?s weight when sorting. Use this field to sort staff members on your interface. | getSortOrder(): ?int | setSortOrder(?int sortOrder): void |
| `state` | `?string` | Optional | The staff member?s state. | getState(): ?string | setState(?string state): void |
| `workPhone` | `?string` | Optional | The staff member?s work phone number. | getWorkPhone(): ?string | setWorkPhone(?string workPhone): void |
| `imageUrl` | `?string` | Optional | The URL of the staff member?s image, if one has been uploaded. | getImageUrl(): ?string | setImageUrl(?string imageUrl): void |
| `classAssistant` | `?bool` | Optional | Is the staff an assistant | getClassAssistant(): ?bool | setClassAssistant(?bool classAssistant): void |
| `classAssistant2` | `?bool` | Optional | Is the staff an assistant2 | getClassAssistant2(): ?bool | setClassAssistant2(?bool classAssistant2): void |
| `employmentStart` | `?\DateTime` | Optional | The start date of employment | getEmploymentStart(): ?\DateTime | setEmploymentStart(?\DateTime employmentStart): void |
| `employmentEnd` | `?\DateTime` | Optional | The end date of employment | getEmploymentEnd(): ?\DateTime | setEmploymentEnd(?\DateTime employmentEnd): void |
| `providerIDs` | `?(string[])` | Optional | A list of ProviderIds for the staff. | getProviderIDs(): ?array | setProviderIDs(?array providerIDs): void |
| `rep` | `?bool` | Optional | return true if staff is sales Rep 1 else false. | getRep(): ?bool | setRep(?bool rep): void |
| `rep2` | `?bool` | Optional | return true if staff is sales Rep 2 else false. | getRep2(): ?bool | setRep2(?bool rep2): void |
| `rep3` | `?bool` | Optional | return true if staff is sales Rep 3 else false. | getRep3(): ?bool | setRep3(?bool rep3): void |
| `rep4` | `?bool` | Optional | return true if staff is sales Rep 4 else false. | getRep4(): ?bool | setRep4(?bool rep4): void |
| `rep5` | `?bool` | Optional | return true if staff is sales Rep 5 else false. | getRep5(): ?bool | setRep5(?bool rep5): void |
| `rep6` | `?bool` | Optional | return true if staff is sales Rep 6 else false. | getRep6(): ?bool | setRep6(?bool rep6): void |
| `staffSettings` | [`?MindbodyPublicApiDtoModelsV6StaffSetting`](../../doc/models/mindbody-public-api-dto-models-v6-staff-setting.md) | Optional | This object contains the staff settings. | getStaffSettings(): ?MindbodyPublicApiDtoModelsV6StaffSetting | setStaffSettings(?MindbodyPublicApiDtoModelsV6StaffSetting staffSettings): void |
| `appointments` | [`?(MindbodyPublicApiDtoModelsV6Appointment[])`](../../doc/models/mindbody-public-api-dto-models-v6-appointment.md) | Optional | A list of appointments for the staff. | getAppointments(): ?array | setAppointments(?array appointments): void |
| `unavailabilities` | [`?(MindbodyPublicApiDtoModelsV6Unavailability[])`](../../doc/models/mindbody-public-api-dto-models-v6-unavailability.md) | Optional | A list of unavailabilities for the staff. | getUnavailabilities(): ?array | setUnavailabilities(?array unavailabilities): void |
| `availabilities` | [`?(MindbodyPublicApiDtoModelsV6Availability[])`](../../doc/models/mindbody-public-api-dto-models-v6-availability.md) | Optional | A list of availabilities for the staff. | getAvailabilities(): ?array | setAvailabilities(?array availabilities): void |
| `empID` | `?string` | Optional | The EmpID assigned to the staff member. | getEmpID(): ?string | setEmpID(?string empID): void |

## Example (as JSON)

```json
{
  "Address": null,
  "AppointmentInstructor": null,
  "AlwaysAllowDoubleBooking": null,
  "Bio": null,
  "City": null,
  "Country": null,
  "Email": null,
  "FirstName": null,
  "DisplayName": null,
  "HomePhone": null,
  "Id": null,
  "IndependentContractor": null,
  "IsMale": null,
  "LastName": null,
  "MobilePhone": null,
  "Name": null,
  "PostalCode": null,
  "ClassTeacher": null,
  "SortOrder": null,
  "State": null,
  "WorkPhone": null,
  "ImageUrl": null,
  "ClassAssistant": null,
  "ClassAssistant2": null,
  "EmploymentStart": null,
  "EmploymentEnd": null,
  "ProviderIDs": null,
  "Rep": null,
  "Rep2": null,
  "Rep3": null,
  "Rep4": null,
  "Rep5": null,
  "Rep6": null,
  "StaffSettings": null,
  "Appointments": null,
  "Unavailabilities": null,
  "Availabilities": null,
  "EmpID": null
}
```

