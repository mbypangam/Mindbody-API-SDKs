
# Get Commissions Response

## Structure

`GetCommissionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `commissions` | [`?(CommissionPayrollPurchaseEvent[])`](../../doc/models/commission-payroll-purchase-event.md) | Optional | Contains information about commissions earned by staff for sales within the given date range. Results are ordered by `SaleId`, then by `StaffId`. | getCommissions(): ?array | setCommissions(?array commissions): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Commissions": null
}
```

