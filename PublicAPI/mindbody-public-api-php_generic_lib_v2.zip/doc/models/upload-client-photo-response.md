
# Upload Client Photo Response

## Structure

`UploadClientPhotoResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `?string` | Optional | The RSSID of the client for whom the photo was uploaded. | getClientId(): ?string | setClientId(?string clientId): void |
| `photoUrl` | `?string` | Optional | The URL of the uploaded photo. | getPhotoUrl(): ?string | setPhotoUrl(?string photoUrl): void |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "PhotoUrl": "PhotoUrl2"
}
```

