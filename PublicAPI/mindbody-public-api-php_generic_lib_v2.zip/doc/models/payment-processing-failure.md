
# Payment Processing Failure

Contains information about any payment processing failure.  Specifically for when an SCA challenge is

## Structure

`PaymentProcessingFailure`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `?string` | Optional | Returned only if SCA challenge is indicated. | getType(): ?string | setType(?string type): void |
| `message` | `?string` | Optional | Returned only if SCA challenge is indicated. | getMessage(): ?string | setMessage(?string message): void |
| `authenticationRedirectUrl` | `?string` | Optional | Returned only if SCA challenge is indicated. | getAuthenticationRedirectUrl(): ?string | setAuthenticationRedirectUrl(?string authenticationRedirectUrl): void |

## Example (as JSON)

```json
{
  "Type": "Type0",
  "Message": "Message6",
  "AuthenticationRedirectUrl": "AuthenticationRedirectUrl6"
}
```

