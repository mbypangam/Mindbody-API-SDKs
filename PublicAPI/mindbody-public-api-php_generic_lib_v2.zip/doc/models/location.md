
# Location

## Structure

`Location`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `additionalImageURLs` | `?(string[])` | Optional | A list of URLs of any images associated with this location. | getAdditionalImageURLs(): ?array | setAdditionalImageURLs(?array additionalImageURLs): void |
| `address` | `?string` | Optional | The first line of the location’s street address. | getAddress(): ?string | setAddress(?string address): void |
| `address2` | `?string` | Optional | A second address line for the location’s street address, if needed. | getAddress2(): ?string | setAddress2(?string address2): void |
| `amenities` | [`?(Amenity[])`](../../doc/models/amenity.md) | Optional | A list of strings representing amenities available at the location. | getAmenities(): ?array | setAmenities(?array amenities): void |
| `businessDescription` | `?string` | Optional | The business description for the location, as configured by the business owner. | getBusinessDescription(): ?string | setBusinessDescription(?string businessDescription): void |
| `city` | `?string` | Optional | The location’s city. | getCity(): ?string | setCity(?string city): void |
| `description` | `?string` | Optional | A description of the location. | getDescription(): ?string | setDescription(?string description): void |
| `hasClasses` | `?bool` | Optional | When `true`, indicates that classes are held at this location.<br /><br>When `false`, Indicates that classes are not held at this location. | getHasClasses(): ?bool | setHasClasses(?bool hasClasses): void |
| `id` | `?int` | Optional | The ID assigned to this location. | getId(): ?int | setId(?int id): void |
| `latitude` | `?float` | Optional | The location’s latitude. | getLatitude(): ?float | setLatitude(?float latitude): void |
| `longitude` | `?float` | Optional | The location’s longitude. | getLongitude(): ?float | setLongitude(?float longitude): void |
| `name` | `?string` | Optional | The name of this location. | getName(): ?string | setName(?string name): void |
| `phone` | `?string` | Optional | The location’s phone number. | getPhone(): ?string | setPhone(?string phone): void |
| `phoneExtension` | `?string` | Optional | The location’s phone extension. | getPhoneExtension(): ?string | setPhoneExtension(?string phoneExtension): void |
| `postalCode` | `?string` | Optional | The location’s postal code. | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `siteID` | `?int` | Optional | The ID number assigned to this location. | getSiteID(): ?int | setSiteID(?int siteID): void |
| `stateProvCode` | `?string` | Optional | The location’s state or province code. | getStateProvCode(): ?string | setStateProvCode(?string stateProvCode): void |
| `tax1` | `?float` | Optional | A decimal representation of the location’s first tax rate. Tax properties are provided to apply all taxes to the purchase price that the purchase is subject to. Use as many tax properties as needed to represent all the taxes that apply in the location. Enter a decimal number that represents the appropriate tax rate. For example, for an 8% sales tax, enter 0.08. | getTax1(): ?float | setTax1(?float tax1): void |
| `tax2` | `?float` | Optional | A decimal representation of the location’s second tax rate. See the example in the description of Tax1. | getTax2(): ?float | setTax2(?float tax2): void |
| `tax3` | `?float` | Optional | A decimal representation of the location’s third tax rate. See the example in the description of Tax1. | getTax3(): ?float | setTax3(?float tax3): void |
| `tax4` | `?float` | Optional | A decimal representation of the location’s fourth tax rate. See the example in the description of Tax1. | getTax4(): ?float | setTax4(?float tax4): void |
| `tax5` | `?float` | Optional | A decimal representation of the location’s fifth tax rate. See the example in the description of Tax1. | getTax5(): ?float | setTax5(?float tax5): void |
| `totalNumberOfRatings` | `?int` | Optional | The number of reviews that clients have left for this location. | getTotalNumberOfRatings(): ?int | setTotalNumberOfRatings(?int totalNumberOfRatings): void |
| `averageRating` | `?float` | Optional | The average rating for the location, out of five stars. | getAverageRating(): ?float | setAverageRating(?float averageRating): void |
| `totalNumberOfDeals` | `?int` | Optional | The number of distinct introductory pricing options available for purchase at this location. | getTotalNumberOfDeals(): ?int | setTotalNumberOfDeals(?int totalNumberOfDeals): void |

## Example (as JSON)

```json
{
  "AdditionalImageURLs": [
    "AdditionalImageURLs4"
  ],
  "Address": "Address2",
  "Address2": "Address24",
  "Amenities": [
    {
      "Id": 214,
      "Name": "Name8"
    },
    {
      "Id": 214,
      "Name": "Name8"
    },
    {
      "Id": 214,
      "Name": "Name8"
    }
  ],
  "BusinessDescription": "BusinessDescription8"
}
```

