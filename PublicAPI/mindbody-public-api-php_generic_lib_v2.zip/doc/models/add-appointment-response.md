
# Add Appointment Response

## Structure

`AddAppointmentResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `appointment` | [`?Appointment`](../../doc/models/appointment.md) | Optional | Contains information about an appointment. | getAppointment(): ?Appointment | setAppointment(?Appointment appointment): void |

## Example (as JSON)

```json
{
  "Appointment": {
    "GenderPreference": "None",
    "Duration": 182,
    "ProviderId": "ProviderId6",
    "Id": 136,
    "Status": "None"
  }
}
```

