
# Mindbody Public Api Dto Models V6 Sale Controller Initialize Credit Card Entry Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientId` | `?string` | Optional | - | getClientId(): ?string | setClientId(?string clientId): void |
| `merchantAccountId` | `?string` | Optional | - | getMerchantAccountId(): ?string | setMerchantAccountId(?string merchantAccountId): void |
| `locationId` | `?int` | Optional | The ID associated with the location of the sale. | getLocationId(): ?int | setLocationId(?int locationId): void |

## Example (as JSON)

```json
{
  "ClientId": null,
  "MerchantAccountId": null,
  "LocationId": null
}
```

