
# Class Description

Represents a class definition. The class meets at the start time, goes until the end time.

## Structure

`ClassDescription`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `active` | `?bool` | Optional | When `true`, indicates that the business can assign this class description to new class schedules.<br /><br>When `false`, indicates that the business cannot assign this class description to new class schedules. | getActive(): ?bool | setActive(?bool active): void |
| `description` | `?string` | Optional | The long version of the class description. | getDescription(): ?string | setDescription(?string description): void |
| `id` | `?int` | Optional | The class description's ID. | getId(): ?int | setId(?int id): void |
| `imageURL` | `?string` | Optional | The class description's image URL, if any. If it does not exist, nothing is returned. | getImageURL(): ?string | setImageURL(?string imageURL): void |
| `lastUpdated` | `?\DateTime` | Optional | The date this class description was last modified. | getLastUpdated(): ?\DateTime | setLastUpdated(?\DateTime lastUpdated): void |
| `level` | [`?Level`](../../doc/models/level.md) | Optional | A session level. | getLevel(): ?Level | setLevel(?Level level): void |
| `name` | `?string` | Optional | The name of this class description. | getName(): ?string | setName(?string name): void |
| `notes` | `?string` | Optional | Any notes about the class description. | getNotes(): ?string | setNotes(?string notes): void |
| `prereq` | `?string` | Optional | Any prerequisites for the class. | getPrereq(): ?string | setPrereq(?string prereq): void |
| `program` | [`?Program`](../../doc/models/program.md) | Optional | - | getProgram(): ?Program | setProgram(?Program program): void |
| `sessionType` | [`?SessionType`](../../doc/models/session-type.md) | Optional | SessionType contains information about the session types in a business. | getSessionType(): ?SessionType | setSessionType(?SessionType sessionType): void |
| `category` | `?string` | Optional | The category of this class description. | getCategory(): ?string | setCategory(?string category): void |
| `categoryId` | `?int` | Optional | The category ID of this class description. | getCategoryId(): ?int | setCategoryId(?int categoryId): void |
| `subcategory` | `?string` | Optional | The subcategory of this class description. | getSubcategory(): ?string | setSubcategory(?string subcategory): void |
| `subcategoryId` | `?int` | Optional | The subcategory ID of this class description. | getSubcategoryId(): ?int | setSubcategoryId(?int subcategoryId): void |

## Example (as JSON)

```json
{
  "Active": false,
  "Description": "Description6",
  "Id": 146,
  "ImageURL": "ImageURL0",
  "LastUpdated": "2016-03-13T12:52:32.123Z"
}
```

