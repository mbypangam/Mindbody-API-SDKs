
# Return Sale Response

ReturnSaleResponse

## Structure

`ReturnSaleResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `returnSaleID` | `?int` | Optional | The returned sale ID | getReturnSaleID(): ?int | setReturnSaleID(?int returnSaleID): void |
| `trainerID` | `?int` | Optional | The trainer ID who returned the sale | getTrainerID(): ?int | setTrainerID(?int trainerID): void |
| `amount` | `?float` | Optional | The returned amount | getAmount(): ?float | setAmount(?float amount): void |

## Example (as JSON)

```json
{
  "ReturnSaleID": null,
  "TrainerID": null,
  "Amount": null
}
```

