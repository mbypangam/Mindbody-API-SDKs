
# Mindbody Public Api Dto Models V6 Commission Detail

## Structure

`MindbodyPublicApiDtoModelsV6CommissionDetail`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `commissionType` | `?string` | Optional | The type of commission earned. Possible values are:<br><br>* ItemStandardPercentageCommission<br>* ItemStandardFlatCommission<br>* ItemPromotionalPercentageCommission<br>* ItemPromotionalFlatCommission<br>* StaffStandardPercentageCommission<br>* StaffStandardFlatCommission<br>* StaffPromotionalPercentageCommission<br>* StaffPromotionalFlatCommission | getCommissionType(): ?string | setCommissionType(?string commissionType): void |
| `commissionEarnings` | `?float` | Optional | The portion of `Earnings` earned by this `CommissionType`. | getCommissionEarnings(): ?float | setCommissionEarnings(?float commissionEarnings): void |

## Example (as JSON)

```json
{
  "CommissionType": null,
  "CommissionEarnings": null
}
```

