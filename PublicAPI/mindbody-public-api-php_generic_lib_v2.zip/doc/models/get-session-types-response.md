
# Get Session Types Response

## Structure

`GetSessionTypesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `sessionTypes` | [`?(SessionType[])`](../../doc/models/session-type.md) | Optional | Contains information about sessions. | getSessionTypes(): ?array | setSessionTypes(?array sessionTypes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "SessionTypes": null
}
```

