
# Promo Code

## Structure

`PromoCode`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `promotionID` | `?int` | Optional | ID of the promo code | getPromotionID(): ?int | setPromotionID(?int promotionID): void |
| `name` | `?string` | Optional | Name of the promo code | getName(): ?string | setName(?string name): void |
| `code` | `?string` | Optional | The code of the promocode. | getCode(): ?string | setCode(?string code): void |
| `active` | `?bool` | Optional | Indicates that promocode is active. | getActive(): ?bool | setActive(?bool active): void |
| `discount` | [`?Discount`](../../doc/models/discount.md) | Optional | Discount for a promo code | getDiscount(): ?Discount | setDiscount(?Discount discount): void |
| `activationDate` | `?\DateTime` | Optional | The promocode activation date. | getActivationDate(): ?\DateTime | setActivationDate(?\DateTime activationDate): void |
| `expirationDate` | `?\DateTime` | Optional | The promocode expiration date. | getExpirationDate(): ?\DateTime | setExpirationDate(?\DateTime expirationDate): void |
| `maxUses` | `?int` | Optional | The maximun number of uses. | getMaxUses(): ?int | setMaxUses(?int maxUses): void |
| `numberOfAutopays` | `?int` | Optional | Number of Autopays | getNumberOfAutopays(): ?int | setNumberOfAutopays(?int numberOfAutopays): void |
| `daysAfterCloseDate` | `?int` | Optional | The number of days a client has to use a promocode after they are no longer a prospect. | getDaysAfterCloseDate(): ?int | setDaysAfterCloseDate(?int daysAfterCloseDate): void |
| `allowOnline` | `?bool` | Optional | Indicates if promocode to be redeemed online in consumer mode. | getAllowOnline(): ?bool | setAllowOnline(?bool allowOnline): void |
| `lastModifiedDateTime` | `?\DateTime` | Optional | Promo code last modified date and time | getLastModifiedDateTime(): ?\DateTime | setLastModifiedDateTime(?\DateTime lastModifiedDateTime): void |
| `daysValid` | [`?(string[]) (DaysValidEnum)`](../../doc/models/days-valid-enum.md) | Optional | What days the promo code can be used | getDaysValid(): ?array | setDaysValid(?array daysValid): void |
| `applicableItems` | [`?(ApplicableItem[])`](../../doc/models/applicable-item.md) | Optional | Contains information about a promocode applicable items. | getApplicableItems(): ?array | setApplicableItems(?array applicableItems): void |

## Example (as JSON)

```json
{
  "PromotionID": null,
  "Name": null,
  "Code": null,
  "Active": null,
  "Discount": null,
  "ActivationDate": null,
  "ExpirationDate": null,
  "MaxUses": null,
  "NumberOfAutopays": null,
  "DaysAfterCloseDate": null,
  "AllowOnline": null,
  "LastModifiedDateTime": null,
  "DaysValid": null,
  "ApplicableItems": null
}
```

