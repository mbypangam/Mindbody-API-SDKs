
# Client Arrival

## Structure

`ClientArrival`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `arrivalProgramID` | `?int` | Optional | Arrival program id | getArrivalProgramID(): ?int | setArrivalProgramID(?int arrivalProgramID): void |
| `arrivalProgramName` | `?string` | Optional | Arrival program name | getArrivalProgramName(): ?string | setArrivalProgramName(?string arrivalProgramName): void |
| `canAccess` | `?bool` | Optional | Property to check client can access arrival service. | getCanAccess(): ?bool | setCanAccess(?bool canAccess): void |
| `locationsIDs` | `?(int[])` | Optional | List of locations where arrival service can availed | getLocationsIDs(): ?array | setLocationsIDs(?array locationsIDs): void |

## Example (as JSON)

```json
{
  "ArrivalProgramID": 208,
  "ArrivalProgramName": "ArrivalProgramName2",
  "CanAccess": false,
  "LocationsIDs": [
    231,
    232,
    233
  ]
}
```

