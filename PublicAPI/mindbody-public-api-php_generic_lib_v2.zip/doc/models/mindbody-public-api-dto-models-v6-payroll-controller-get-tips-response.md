
# Mindbody Public Api Dto Models V6 Payroll Controller Get Tips Response

## Structure

`MindbodyPublicApiDtoModelsV6PayrollControllerGetTipsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. See Pagination for a description of the Pagination information. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `tips` | [`?(MindbodyPublicApiDtoModelsV6Tip[])`](../../doc/models/mindbody-public-api-dto-models-v6-tip.md) | Optional | Contains information about tips given to staff members within the given date range. Results are ordered by StaffId. | getTips(): ?array | setTips(?array tips): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Tips": null
}
```

