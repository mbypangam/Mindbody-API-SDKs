
# Payment Type

## Structure

`PaymentType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The Payment Type Id used for api calls. | getId(): ?int | setId(?int id): void |
| `paymentTypeName` | `?string` | Optional | Payment Type Name | getPaymentTypeName(): ?string | setPaymentTypeName(?string paymentTypeName): void |
| `active` | `?bool` | Optional | Check if Payment type is active. | getActive(): ?bool | setActive(?bool active): void |
| `fee` | `?float` | Optional | Payment type fee. | getFee(): ?float | setFee(?float fee): void |

## Example (as JSON)

```json
{
  "Id": null,
  "PaymentTypeName": null,
  "Active": null,
  "Fee": null
}
```

