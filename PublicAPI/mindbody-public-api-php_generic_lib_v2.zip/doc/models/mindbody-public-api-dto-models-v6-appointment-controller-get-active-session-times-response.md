
# Mindbody Public Api Dto Models V6 Appointment Controller Get Active Session Times Response

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `activeSessionTimes` | `?(string[])` | Optional | List of available start times for active sessions. Note the following:<br><br>* The times returned represent possibilities for scheduling a session, not necessarily currently scheduled sessions.<br>* The response includes either all schedule types or those filtered by supplying `ScheduleType` or `SessionTypeIds`.<br>* Each session has an associated schedule type, but when you supply `SessionTypeIds`, they may map to one or more of the schedule types. | getActiveSessionTimes(): ?array | setActiveSessionTimes(?array activeSessionTimes): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ActiveSessionTimes": null
}
```

