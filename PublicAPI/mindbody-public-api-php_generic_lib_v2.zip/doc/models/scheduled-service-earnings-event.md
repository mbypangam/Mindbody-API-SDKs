
# Scheduled Service Earnings Event

## Structure

`ScheduledServiceEarningsEvent`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `?int` | Optional | The ID of the staff member who taught the class. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `scheduledServiceId` | `?int` | Optional | The class' ID. | getScheduledServiceId(): ?int | setScheduledServiceId(?int scheduledServiceId): void |
| `scheduledServiceType` | [`?string(ScheduledServiceTypeEnum)`](../../doc/models/scheduled-service-type-enum.md) | Optional | The type of the scheduled service; i.e, a class, appointment, or enrollment. | getScheduledServiceType(): ?string | setScheduledServiceType(?string scheduledServiceType): void |
| `earnings` | `?float` | Optional | The total monetary amount the staff is to be paid for this class. | getEarnings(): ?float | setEarnings(?float earnings): void |
| `dateTime` | `?DateTime` | Optional | - | getDateTime(): ?\DateTime | setDateTime(?\DateTime dateTime): void |

## Example (as JSON)

```json
{
  "StaffId": 110,
  "ScheduledServiceId": 194,
  "ScheduledServiceType": "Enrollment",
  "Earnings": 215.14,
  "DateTime": "2016-03-13T12:52:32.123Z"
}
```

