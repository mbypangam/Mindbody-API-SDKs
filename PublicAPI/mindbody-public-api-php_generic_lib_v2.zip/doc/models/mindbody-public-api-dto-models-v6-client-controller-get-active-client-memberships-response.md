
# Mindbody Public Api Dto Models V6 Client Controller Get Active Client Memberships Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `clientMemberships` | [`?(MindbodyPublicApiDtoModelsV6ClientMembership[])`](../../doc/models/mindbody-public-api-dto-models-v6-client-membership.md) | Optional | Details about the requested memberships. | getClientMemberships(): ?array | setClientMemberships(?array clientMemberships): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientMemberships": null
}
```

