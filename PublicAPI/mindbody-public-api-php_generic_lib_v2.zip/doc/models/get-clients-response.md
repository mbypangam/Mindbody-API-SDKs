
# Get Clients Response

## Structure

`GetClientsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `clients` | [`?(ClientWithSuspensionInfo[])`](../../doc/models/client-with-suspension-info.md) | Optional | The requested clients. | getClients(): ?array | setClients(?array clients): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Clients": [
    {
      "SuspensionInfo": {
        "BookingSuspended": false,
        "SuspensionStartDate": "SuspensionStartDate8",
        "SuspensionEndDate": "SuspensionEndDate2"
      },
      "AppointmentGenderPreference": "Female",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country4",
      "CreationDate": "2016-03-13T12:52:32.123Z"
    }
  ]
}
```

