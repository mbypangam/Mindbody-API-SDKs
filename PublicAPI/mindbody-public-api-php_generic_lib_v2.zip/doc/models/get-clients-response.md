
# Get Clients Response

## Structure

`GetClientsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination properties to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `clients` | [`?(ClientWithSuspensionInfo[])`](../../doc/models/client-with-suspension-info.md) | Optional | The requested clients. | getClients(): ?array | setClients(?array clients): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Clients": null
}
```

