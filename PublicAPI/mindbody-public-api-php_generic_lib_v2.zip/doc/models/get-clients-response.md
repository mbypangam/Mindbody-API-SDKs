
# Get Clients Response

## Structure

`GetClientsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `clients` | [`?(ClientWithSuspensionInfo[])`](../../doc/models/client-with-suspension-info.md) | Optional | The requested clients. | getClients(): ?array | setClients(?array clients): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Clients": [
    {
      "SuspensionInfo": {
        "BookingSuspended": true,
        "SuspensionStartDate": "SuspensionStartDate1",
        "SuspensionEndDate": "SuspensionEndDate5"
      },
      "AppointmentGenderPreference": "Male",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country9",
      "CreationDate": "2016-03-13T12:52:32.123Z"
    },
    {
      "SuspensionInfo": {
        "BookingSuspended": false,
        "SuspensionStartDate": "SuspensionStartDate2",
        "SuspensionEndDate": "SuspensionEndDate6"
      },
      "AppointmentGenderPreference": "None",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country0",
      "CreationDate": "2016-03-13T12:52:32.123Z"
    },
    {
      "SuspensionInfo": {
        "BookingSuspended": true,
        "SuspensionStartDate": "SuspensionStartDate3",
        "SuspensionEndDate": "SuspensionEndDate7"
      },
      "AppointmentGenderPreference": "Female",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country1",
      "CreationDate": "2016-03-13T12:52:32.123Z"
    }
  ]
}
```

