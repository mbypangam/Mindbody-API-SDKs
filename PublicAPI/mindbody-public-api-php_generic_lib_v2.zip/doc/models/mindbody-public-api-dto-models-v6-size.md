
# Mindbody Public Api Dto Models V6 Size

## Structure

`MindbodyPublicApiDtoModelsV6Size`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the product size. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the product size. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

