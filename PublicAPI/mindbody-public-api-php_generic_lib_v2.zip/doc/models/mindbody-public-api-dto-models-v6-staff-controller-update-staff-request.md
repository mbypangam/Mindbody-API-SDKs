
# Mindbody Public Api Dto Models V6 Staff Controller Update Staff Request

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `iD` | `int` | Required | The unique ID of the staff member. | getID(): int | setID(int iD): void |
| `firstName` | `?string` | Optional | The staff member first name. You must specify a first name when you add a staff member. | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | The staff member last name. You must specify a last name when you add a staff member. | getLastName(): ?string | setLastName(?string lastName): void |
| `email` | `?string` | Optional | The staff member's email address. | getEmail(): ?string | setEmail(?string email): void |
| `isMale` | `?bool` | Optional | When `true`, indicates that the staff member is male.<br>When `false`, indicates that the staff member is female. | getIsMale(): ?bool | setIsMale(?bool isMale): void |
| `homePhone` | `?string` | Optional | The staff member's home phone number. | getHomePhone(): ?string | setHomePhone(?string homePhone): void |
| `workPhone` | `?string` | Optional | The staff member's work phone number. | getWorkPhone(): ?string | setWorkPhone(?string workPhone): void |
| `mobilePhone` | `?string` | Optional | The staff member's mobile phone number. | getMobilePhone(): ?string | setMobilePhone(?string mobilePhone): void |
| `bio` | `?string` | Optional | The staff member's biography. This string contains HTML. | getBio(): ?string | setBio(?string bio): void |
| `address` | `?string` | Optional | The first line of the staff member street address | getAddress(): ?string | setAddress(?string address): void |
| `address2` | `?string` | Optional | The second line of the staff member street address, if needed. | getAddress2(): ?string | setAddress2(?string address2): void |
| `city` | `?string` | Optional | The staff member's city. | getCity(): ?string | setCity(?string city): void |
| `state` | `?string` | Optional | The staff member's state. | getState(): ?string | setState(?string state): void |
| `country` | `?string` | Optional | The staff member's country. | getCountry(): ?string | setCountry(?string country): void |
| `postalCode` | `?string` | Optional | The staff member's postal code. | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `classAssistant` | `?bool` | Optional | When `true`, indicates that the staff member can be a class assistant. | getClassAssistant(): ?bool | setClassAssistant(?bool classAssistant): void |
| `classAssistant2` | `?bool` | Optional | When `true`, indicates that the staff member can be a class assistant. | getClassAssistant2(): ?bool | setClassAssistant2(?bool classAssistant2): void |
| `independentContractor` | `?bool` | Optional | When `true`, indicates that the staff member is an independent contractor.<br>When `false`, indicates that the staff member is not an independent contractor. | getIndependentContractor(): ?bool | setIndependentContractor(?bool independentContractor): void |
| `appointmentInstructor` | `?bool` | Optional | When `true`, indicates that the staff member offers appointments.<br /><br>When `false`, indicates that the staff member does not offer appointments. | getAppointmentInstructor(): ?bool | setAppointmentInstructor(?bool appointmentInstructor): void |
| `alwaysAllowDoubleBooking` | `?bool` | Optional | When `true`, indicates that the staff member can be scheduled for overlapping services.<br /><br>When `false`, indicates that the staff member does not offer appointments. | getAlwaysAllowDoubleBooking(): ?bool | setAlwaysAllowDoubleBooking(?bool alwaysAllowDoubleBooking): void |
| `classTeacher` | `?bool` | Optional | When `true`, indicates that the staff member can teach classes.<br>When `false`, indicates that the staff member cannot teach classes. | getClassTeacher(): ?bool | setClassTeacher(?bool classTeacher): void |
| `employmentStart` | `?\DateTime` | Optional | The start date of employment | getEmploymentStart(): ?\DateTime | setEmploymentStart(?\DateTime employmentStart): void |
| `employmentEnd` | `?\DateTime` | Optional | The end date of employment | getEmploymentEnd(): ?\DateTime | setEmploymentEnd(?\DateTime employmentEnd): void |
| `sortOrder` | `?int` | Optional | If configured by the business owner, this field determines a staff member's weight when sorting. Use this field to sort staff members on your interface. | getSortOrder(): ?int | setSortOrder(?int sortOrder): void |
| `providerIDs` | `?(string[])` | Optional | A list of providerIDs for the staff.  In the US it is one per staff and is numeric, otherwise it can be a list and is alpha-numeric<br>for more information see <a href=" https://support.mindbodyonline.com/s/article/204075743-Provider-IDs?language=en_US" target="blank">Provider IDs</a> | getProviderIDs(): ?array | setProviderIDs(?array providerIDs): void |
| `active` | `?bool` | Optional | Indicates if the staff member is active. Staff member cannot be deactivated if they have future classes or appointments. | getActive(): ?bool | setActive(?bool active): void |
| `notes` | `?string` | Optional | Staff Member Private Notes | getNotes(): ?string | setNotes(?string notes): void |
| `empID` | `?string` | Optional | The custom staff ID assigned to the staff member. | getEmpID(): ?string | setEmpID(?string empID): void |

## Example (as JSON)

```json
{
  "ID": 110,
  "FirstName": null,
  "LastName": null,
  "Email": null,
  "IsMale": null,
  "HomePhone": null,
  "WorkPhone": null,
  "MobilePhone": null,
  "Bio": null,
  "Address": null,
  "Address2": null,
  "City": null,
  "State": null,
  "Country": null,
  "PostalCode": null,
  "ClassAssistant": null,
  "ClassAssistant2": null,
  "IndependentContractor": null,
  "AppointmentInstructor": null,
  "AlwaysAllowDoubleBooking": null,
  "ClassTeacher": null,
  "EmploymentStart": null,
  "EmploymentEnd": null,
  "SortOrder": null,
  "ProviderIDs": null,
  "Active": null,
  "Notes": null,
  "EmpID": null
}
```

