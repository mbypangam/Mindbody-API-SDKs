
# Transaction

## Structure

`Transaction`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `transactionId` | `?int` | Optional | The transaction ID. | getTransactionId(): ?int | setTransactionId(?int transactionId): void |
| `saleId` | `?int` | Optional | The sale ID. | getSaleId(): ?int | setSaleId(?int saleId): void |
| `clientId` | `?int` | Optional | The ID of the client who made the purchase. | getClientId(): ?int | setClientId(?int clientId): void |
| `amount` | `?float` | Optional | The amount charged on the card | getAmount(): ?float | setAmount(?float amount): void |
| `settled` | `?bool` | Optional | Whether it is settled or not | getSettled(): ?bool | setSettled(?bool settled): void |
| `status` | `?string` | Optional | Status of the transaction | getStatus(): ?string | setStatus(?string status): void |
| `transactionTime` | `?\DateTime` | Optional | Time of card swiped | getTransactionTime(): ?\DateTime | setTransactionTime(?\DateTime transactionTime): void |
| `authTime` | `?\DateTime` | Optional | Time of card authorized | getAuthTime(): ?\DateTime | setAuthTime(?\DateTime authTime): void |
| `locationId` | `?int` | Optional | The ID of the location where the sale takes place. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `merchantId` | `?string` | Optional | Merchant ID of the studio | getMerchantId(): ?string | setMerchantId(?string merchantId): void |
| `terminalId` | `?string` | Optional | Terminal ID used for payment. Not applicable for CNP/Bank | getTerminalId(): ?string | setTerminalId(?string terminalId): void |
| `cardExpirationMonth` | `?string` | Optional | Expiry month of the card | getCardExpirationMonth(): ?string | setCardExpirationMonth(?string cardExpirationMonth): void |
| `cardExpirationYear` | `?string` | Optional | Expiry year of the card | getCardExpirationYear(): ?string | setCardExpirationYear(?string cardExpirationYear): void |
| `cCLastFour` | `?string` | Optional | Last 4 digits of CC | getCCLastFour(): ?string | setCCLastFour(?string cCLastFour): void |
| `cardType` | `?string` | Optional | Type of the card | getCardType(): ?string | setCardType(?string cardType): void |
| `cCSwiped` | `?bool` | Optional | Whether card is swiped or not | getCCSwiped(): ?bool | setCCSwiped(?bool cCSwiped): void |
| `aCHLastFour` | `?string` | Optional | Customer’s ACH last 4 digits | getACHLastFour(): ?string | setACHLastFour(?string aCHLastFour): void |

## Example (as JSON)

```json
{
  "TransactionId": 132,
  "SaleId": 62,
  "ClientId": 190,
  "Amount": 57.88,
  "Settled": false
}
```

