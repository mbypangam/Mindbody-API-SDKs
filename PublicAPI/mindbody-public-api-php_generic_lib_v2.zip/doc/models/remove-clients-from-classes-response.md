
# Remove Clients From Classes Response

Remove Clients From Classes Response

## Structure

`RemoveClientsFromClassesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `classes` | [`?(MClass[])`](../../doc/models/m-class.md) | Optional | Contains information about the classes from which the clients were removed. | getClasses(): ?array | setClasses(?array classes): void |
| `errors` | [`?(ApiError[])`](../../doc/models/api-error.md) | Optional | Contains information about the errors | getErrors(): ?array | setErrors(?array errors): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Classes": [
    {
      "ClassScheduleId": 27,
      "Visits": [
        {
          "AppointmentId": 122,
          "AppointmentGenderPreference": "Female",
          "AppointmentStatus": "NoShow",
          "ClassId": 214,
          "ClientId": "ClientId6"
        },
        {
          "AppointmentId": 121,
          "AppointmentGenderPreference": "Male",
          "AppointmentStatus": "Arrived",
          "ClassId": 215,
          "ClientId": "ClientId5"
        },
        {
          "AppointmentId": 120,
          "AppointmentGenderPreference": "None",
          "AppointmentStatus": "Confirmed",
          "ClassId": 216,
          "ClientId": "ClientId4"
        }
      ],
      "Clients": [
        {
          "AppointmentGenderPreference": "Female",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country2",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value3",
              "Id": 35,
              "DataType": "DataType9",
              "Name": "Name5"
            },
            {
              "Value": "Value4",
              "Id": 36,
              "DataType": "DataType0",
              "Name": "Name6"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "Male",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country3",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value4",
              "Id": 36,
              "DataType": "DataType0",
              "Name": "Name6"
            },
            {
              "Value": "Value5",
              "Id": 37,
              "DataType": "DataType1",
              "Name": "Name7"
            },
            {
              "Value": "Value6",
              "Id": 38,
              "DataType": "DataType2",
              "Name": "Name8"
            }
          ]
        }
      ],
      "Location": {
        "AdditionalImageURLs": [
          "AdditionalImageURLs9",
          "AdditionalImageURLs0",
          "AdditionalImageURLs1"
        ],
        "Address": "Address5",
        "Address2": "Address27",
        "Amenities": [
          {
            "Id": 223,
            "Name": "Name5"
          },
          {
            "Id": 224,
            "Name": "Name6"
          }
        ],
        "BusinessDescription": "BusinessDescription1"
      },
      "Resource": {
        "Id": 255,
        "Name": "Name3"
      }
    },
    {
      "ClassScheduleId": 28,
      "Visits": [
        {
          "AppointmentId": 121,
          "AppointmentGenderPreference": "Male",
          "AppointmentStatus": "Arrived",
          "ClassId": 215,
          "ClientId": "ClientId5"
        }
      ],
      "Clients": [
        {
          "AppointmentGenderPreference": "Male",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country3",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value4",
              "Id": 36,
              "DataType": "DataType0",
              "Name": "Name6"
            },
            {
              "Value": "Value5",
              "Id": 37,
              "DataType": "DataType1",
              "Name": "Name7"
            },
            {
              "Value": "Value6",
              "Id": 38,
              "DataType": "DataType2",
              "Name": "Name8"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "None",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country4",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value5",
              "Id": 37,
              "DataType": "DataType1",
              "Name": "Name7"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "Female",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country5",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value6",
              "Id": 38,
              "DataType": "DataType2",
              "Name": "Name8"
            },
            {
              "Value": "Value7",
              "Id": 39,
              "DataType": "DataType3",
              "Name": "Name9"
            }
          ]
        }
      ],
      "Location": {
        "AdditionalImageURLs": [
          "AdditionalImageURLs0"
        ],
        "Address": "Address6",
        "Address2": "Address28",
        "Amenities": [
          {
            "Id": 224,
            "Name": "Name6"
          },
          {
            "Id": 225,
            "Name": "Name7"
          },
          {
            "Id": 226,
            "Name": "Name8"
          }
        ],
        "BusinessDescription": "BusinessDescription2"
      },
      "Resource": {
        "Id": 254,
        "Name": "Name2"
      }
    }
  ],
  "Errors": [
    {
      "Message": "Message8",
      "Code": "Code2"
    }
  ]
}
```

