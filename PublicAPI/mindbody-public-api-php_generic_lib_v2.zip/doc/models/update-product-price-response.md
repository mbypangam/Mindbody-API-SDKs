
# Update Product Price Response

Update Product Price Response Model

## Structure

`UpdateProductPriceResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `product` | [`?MindbodyPublicApiDtoModelsV6Product`](../../doc/models/mindbody-public-api-dto-models-v6-product.md) | Optional | Contains information about the product. | getProduct(): ?MindbodyPublicApiDtoModelsV6Product | setProduct(?MindbodyPublicApiDtoModelsV6Product product): void |

## Example (as JSON)

```json
{
  "Product": null
}
```

