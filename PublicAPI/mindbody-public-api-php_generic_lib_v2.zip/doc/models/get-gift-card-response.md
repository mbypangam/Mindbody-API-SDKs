
# Get Gift Card Response

## Structure

`GetGiftCardResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `giftCards` | [`?(GiftCard[])`](../../doc/models/gift-card.md) | Optional | Contains information about the gift cards. | getGiftCards(): ?array | setGiftCards(?array giftCards): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "GiftCards": [
    {
      "Id": 90,
      "LocationIds": [
        128,
        129
      ],
      "Description": "Description0",
      "EditableByConsumer": false,
      "CardValue": 153.64
    }
  ]
}
```

