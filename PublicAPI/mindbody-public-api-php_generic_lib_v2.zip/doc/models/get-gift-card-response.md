
# Get Gift Card Response

## Structure

`GetGiftCardResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `giftCards` | [`?(MindbodyPublicApiDtoModelsV6GiftCard[])`](../../doc/models/mindbody-public-api-dto-models-v6-gift-card.md) | Optional | Contains information about the gift cards. | getGiftCards(): ?array | setGiftCards(?array giftCards): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "GiftCards": null
}
```

