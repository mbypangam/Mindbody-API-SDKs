
# Get Gift Card Response

## Structure

`GetGiftCardResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `giftCards` | [`?(GiftCard[])`](../../doc/models/gift-card.md) | Optional | Contains information about the gift cards. | getGiftCards(): ?array | setGiftCards(?array giftCards): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "GiftCards": null
}
```

