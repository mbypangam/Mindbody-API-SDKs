
# Commission Payroll Purchase Event

## Structure

`CommissionPayrollPurchaseEvent`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `staffId` | `?int` | Optional | The ID of the staff member who earned commissions. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `saleDateTime` | `?DateTime` | Optional | The date and time when the sale occurred. | getSaleDateTime(): ?\DateTime | setSaleDateTime(?\DateTime saleDateTime): void |
| `saleId` | `?int` | Optional | The sale’s ID. | getSaleId(): ?int | setSaleId(?int saleId): void |
| `saleType` | `?string` | Optional | The Sales type. When this is "Purchase" indicates that this sale paid commission to a staff. When this is "Return" | getSaleType(): ?string | setSaleType(?string saleType): void |
| `productId` | `?int` | Optional | The product ID of the item for which the staff earned commissions. | getProductId(): ?int | setProductId(?int productId): void |
| `earningsDetails` | [`?(CommissionDetail[])`](../../doc/models/commission-detail.md) | Optional | Contains information about which commissions the staff earned for this item. | getEarningsDetails(): ?array | setEarningsDetails(?array earningsDetails): void |
| `earnings` | `?float` | Optional | The total commissions earned by the staff for this item. | getEarnings(): ?float | setEarnings(?float earnings): void |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "SaleDateTime": "2016-03-13T12:52:32.123Z",
  "SaleId": 62,
  "SaleType": "SaleType2",
  "ProductId": 104
}
```

