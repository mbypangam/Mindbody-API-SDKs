
# Mindbody Public Api Dto Models V6 Sale Payment

## Structure

`MindbodyPublicApiDtoModelsV6SalePayment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | A unique identifier for this payment. | getId(): ?int | setId(?int id): void |
| `amount` | `?float` | Optional | The amount of this payment. | getAmount(): ?float | setAmount(?float amount): void |
| `method` | `?int` | Optional | The method for this payment. | getMethod(): ?int | setMethod(?int method): void |
| `type` | `?string` | Optional | The type of payment. | getType(): ?string | setType(?string type): void |
| `notes` | `?string` | Optional | Notes about this payment. | getNotes(): ?string | setNotes(?string notes): void |
| `transactionId` | `?int` | Optional | The payment transaction ID | getTransactionId(): ?int | setTransactionId(?int transactionId): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Amount": null,
  "Method": null,
  "Type": null,
  "Notes": null,
  "TransactionId": null
}
```

