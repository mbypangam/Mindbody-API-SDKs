
# Cancel Single Class Response

## Structure

`CancelSingleClassResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `class` | [`?MClass`](../../doc/models/m-class.md) | Optional | A resulting class. | getClass(): ?MClass | setClass(?MClass class): void |

## Example (as JSON)

```json
{
  "Class": null
}
```

