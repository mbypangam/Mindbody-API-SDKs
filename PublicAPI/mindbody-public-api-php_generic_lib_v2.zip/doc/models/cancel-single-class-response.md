
# Cancel Single Class Response

## Structure

`CancelSingleClassResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `class` | [`?MindbodyPublicApiDtoModelsV6Class`](../../doc/models/mindbody-public-api-dto-models-v6-class.md) | Optional | A resulting class. | getClass(): ?MindbodyPublicApiDtoModelsV6Class | setClass(?MindbodyPublicApiDtoModelsV6Class class): void |

## Example (as JSON)

```json
{
  "Class": null
}
```

