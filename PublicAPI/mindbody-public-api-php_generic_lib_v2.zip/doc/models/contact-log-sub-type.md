
# Contact Log Sub Type

A contact log subtype.

## Structure

`ContactLogSubType`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The unique ID of the subtype | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of the subcontactlog Type. | getName(): ?string | setName(?string name): void |

## Example (as JSON)

```json
{
  "Id": 152,
  "Name": "Name0"
}
```

