
# Mindbody Public Api Dto Models V6 Client Duplicate

A client record that is considered a duplicate based on matching of the client's first name, last name, AND email fields

## Structure

`MindbodyPublicApiDtoModelsV6ClientDuplicate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?string` | Optional | The client?s ID, as configured by the business owner. This is the client?s barcode ID if the business owner assigns barcodes to clients. This ID is used throughout the Public API for client-related Public API calls. When used in a POST `UpdateClient` request, the `Id` is used to identify the client for the update. | getId(): ?string | setId(?string id): void |
| `uniqueId` | `?int` | Optional | The client?s system-generated ID at the business. This value cannot be changed by business owners and is always unique across all clients at the business. This ID is not widely used in the Public API, but can be used by your application to uniquely identify clients. | getUniqueId(): ?int | setUniqueId(?int uniqueId): void |
| `firstName` | `?string` | Optional | The client?s first name. | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | The client?s last name. | getLastName(): ?string | setLastName(?string lastName): void |
| `email` | `?string` | Optional | The client?s email address. | getEmail(): ?string | setEmail(?string email): void |

## Example (as JSON)

```json
{
  "Id": null,
  "UniqueId": null,
  "FirstName": null,
  "LastName": null,
  "Email": null
}
```

