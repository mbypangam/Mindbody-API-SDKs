
# Mindbody Public Api Dto Models V6 Direct Debit Info

## Structure

`MindbodyPublicApiDtoModelsV6DirectDebitInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `nameOnAccount` | `?string` | Optional | The name on the bank account. | getNameOnAccount(): ?string | setNameOnAccount(?string nameOnAccount): void |
| `routingNumber` | `?string` | Optional | The routing number for the bank. | getRoutingNumber(): ?string | setRoutingNumber(?string routingNumber): void |
| `accountNumber` | `?string` | Optional | The last four of the bank account number. | getAccountNumber(): ?string | setAccountNumber(?string accountNumber): void |
| `accountType` | `?string` | Optional | The account type.<br><br>Possible values:<br><br>* Checking<br>* Savings | getAccountType(): ?string | setAccountType(?string accountType): void |

## Example (as JSON)

```json
{
  "NameOnAccount": null,
  "RoutingNumber": null,
  "AccountNumber": null,
  "AccountType": null
}
```

