
# Mindbody Public Api Dto Models V6 Credit Card Info

INformation about an individual credit card

## Structure

`MindbodyPublicApiDtoModelsV6CreditCardInfo`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `creditCardNumber` | `?string` | Optional | - | getCreditCardNumber(): ?string | setCreditCardNumber(?string creditCardNumber): void |
| `expMonth` | `?string` | Optional | - | getExpMonth(): ?string | setExpMonth(?string expMonth): void |
| `expYear` | `?string` | Optional | - | getExpYear(): ?string | setExpYear(?string expYear): void |
| `billingName` | `?string` | Optional | - | getBillingName(): ?string | setBillingName(?string billingName): void |
| `billingAddress` | `?string` | Optional | - | getBillingAddress(): ?string | setBillingAddress(?string billingAddress): void |
| `billingCity` | `?string` | Optional | - | getBillingCity(): ?string | setBillingCity(?string billingCity): void |
| `billingState` | `?string` | Optional | - | getBillingState(): ?string | setBillingState(?string billingState): void |
| `billingPostalCode` | `?string` | Optional | - | getBillingPostalCode(): ?string | setBillingPostalCode(?string billingPostalCode): void |
| `saveInfo` | `?bool` | Optional | - | getSaveInfo(): ?bool | setSaveInfo(?bool saveInfo): void |
| `cardId` | `?string` | Optional | Card Id of a stored instruments card | getCardId(): ?string | setCardId(?string cardId): void |

## Example (as JSON)

```json
{
  "CreditCardNumber": null,
  "ExpMonth": null,
  "ExpYear": null,
  "BillingName": null,
  "BillingAddress": null,
  "BillingCity": null,
  "BillingState": null,
  "BillingPostalCode": null,
  "SaveInfo": null,
  "CardId": null
}
```

