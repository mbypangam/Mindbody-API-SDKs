
# Location 1

## Structure

`Location1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `businessId` | `?int` | Optional | - | getBusinessId(): ?int | setBusinessId(?int businessId): void |
| `siteId` | `?int` | Optional | - | getSiteId(): ?int | setSiteId(?int siteId): void |
| `businessDescription` | `?string` | Optional | - | getBusinessDescription(): ?string | setBusinessDescription(?string businessDescription): void |
| `additionalImageURLs` | `?(string[])` | Optional | - | getAdditionalImageURLs(): ?array | setAdditionalImageURLs(?array additionalImageURLs): void |
| `facilitySquareFeet` | `?int` | Optional | - | getFacilitySquareFeet(): ?int | setFacilitySquareFeet(?int facilitySquareFeet): void |
| `proSpaFinderSite` | `?bool` | Optional | - | getProSpaFinderSite(): ?bool | setProSpaFinderSite(?bool proSpaFinderSite): void |
| `hasClasses` | `?bool` | Optional | - | getHasClasses(): ?bool | setHasClasses(?bool hasClasses): void |
| `phoneExtension` | `?string` | Optional | - | getPhoneExtension(): ?string | setPhoneExtension(?string phoneExtension): void |
| `action` | [`?string (ActionEnum)`](../../doc/models/action-enum.md) | Optional | - | getAction(): ?string | setAction(?string action): void |
| `id` | `?int` | Optional | - | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | - | getName(): ?string | setName(?string name): void |
| `address` | `?string` | Optional | - | getAddress(): ?string | setAddress(?string address): void |
| `address2` | `?string` | Optional | - | getAddress2(): ?string | setAddress2(?string address2): void |
| `tax1` | `?float` | Optional | - | getTax1(): ?float | setTax1(?float tax1): void |
| `tax2` | `?float` | Optional | - | getTax2(): ?float | setTax2(?float tax2): void |
| `tax3` | `?float` | Optional | - | getTax3(): ?float | setTax3(?float tax3): void |
| `tax4` | `?float` | Optional | - | getTax4(): ?float | setTax4(?float tax4): void |
| `tax5` | `?float` | Optional | - | getTax5(): ?float | setTax5(?float tax5): void |
| `phone` | `?string` | Optional | - | getPhone(): ?string | setPhone(?string phone): void |
| `city` | `?string` | Optional | - | getCity(): ?string | setCity(?string city): void |
| `stateProvCode` | `?string` | Optional | - | getStateProvCode(): ?string | setStateProvCode(?string stateProvCode): void |
| `postalCode` | `?string` | Optional | - | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `latitude` | `?float` | Optional | - | getLatitude(): ?float | setLatitude(?float latitude): void |
| `longitude` | `?float` | Optional | - | getLongitude(): ?float | setLongitude(?float longitude): void |
| `distanceInMiles` | `?float` | Optional | - | getDistanceInMiles(): ?float | setDistanceInMiles(?float distanceInMiles): void |
| `imageURL` | `?string` | Optional | - | getImageURL(): ?string | setImageURL(?string imageURL): void |
| `description` | `?string` | Optional | - | getDescription(): ?string | setDescription(?string description): void |
| `hasSite` | `?bool` | Optional | - | getHasSite(): ?bool | setHasSite(?bool hasSite): void |
| `canBook` | `?bool` | Optional | - | getCanBook(): ?bool | setCanBook(?bool canBook): void |
| `numberTreatmentRooms` | `?int` | Optional | - | getNumberTreatmentRooms(): ?int | setNumberTreatmentRooms(?int numberTreatmentRooms): void |
| `active` | `?bool` | Optional | - | getActive(): ?bool | setActive(?bool active): void |
| `invActive` | `?bool` | Optional | - | getInvActive(): ?bool | setInvActive(?bool invActive): void |
| `wsShow` | `?bool` | Optional | - | getWsShow(): ?bool | setWsShow(?bool wsShow): void |
| `email` | `?string` | Optional | - | getEmail(): ?string | setEmail(?string email): void |
| `contactName` | `?string` | Optional | - | getContactName(): ?string | setContactName(?string contactName): void |
| `shipAddress` | `?string` | Optional | - | getShipAddress(): ?string | setShipAddress(?string shipAddress): void |
| `shipState` | `?string` | Optional | - | getShipState(): ?string | setShipState(?string shipState): void |
| `shipPostal` | `?string` | Optional | - | getShipPostal(): ?string | setShipPostal(?string shipPostal): void |
| `shipPhone` | `?string` | Optional | - | getShipPhone(): ?string | setShipPhone(?string shipPhone): void |
| `shipPOC` | `?string` | Optional | - | getShipPOC(): ?string | setShipPOC(?string shipPOC): void |
| `taxGrouping` | `?bool` | Optional | - | getTaxGrouping(): ?bool | setTaxGrouping(?bool taxGrouping): void |
| `labelTax1` | `?string` | Optional | - | getLabelTax1(): ?string | setLabelTax1(?string labelTax1): void |
| `labelTax2` | `?string` | Optional | - | getLabelTax2(): ?string | setLabelTax2(?string labelTax2): void |
| `labelTax3` | `?string` | Optional | - | getLabelTax3(): ?string | setLabelTax3(?string labelTax3): void |
| `labelTax4` | `?string` | Optional | - | getLabelTax4(): ?string | setLabelTax4(?string labelTax4): void |
| `labelTax5` | `?string` | Optional | - | getLabelTax5(): ?string | setLabelTax5(?string labelTax5): void |
| `wAC` | `?bool` | Optional | - | getWAC(): ?bool | setWAC(?bool wAC): void |
| `shipAddress2` | `?string` | Optional | - | getShipAddress2(): ?string | setShipAddress2(?string shipAddress2): void |
| `masterLocId` | `?int` | Optional | - | getMasterLocId(): ?int | setMasterLocId(?int masterLocId): void |
| `streetAddress` | `?string` | Optional | - | getStreetAddress(): ?string | setStreetAddress(?string streetAddress): void |
| `country` | `?string` | Optional | - | getCountry(): ?string | setCountry(?string country): void |
| `ext` | `?string` | Optional | - | getExt(): ?string | setExt(?string ext): void |
| `amenities` | [`?(Amenity1[])`](../../doc/models/amenity-1.md) | Optional | - | getAmenities(): ?array | setAmenities(?array amenities): void |
| `totalNumberOfDeals` | `?int` | Optional | - | getTotalNumberOfDeals(): ?int | setTotalNumberOfDeals(?int totalNumberOfDeals): void |
| `totalNumberOfRatings` | `?int` | Optional | - | getTotalNumberOfRatings(): ?int | setTotalNumberOfRatings(?int totalNumberOfRatings): void |
| `averageRating` | `?float` | Optional | - | getAverageRating(): ?float | setAverageRating(?float averageRating): void |

## Example (as JSON)

```json
{
  "BusinessId": 144,
  "SiteId": 164,
  "BusinessDescription": "BusinessDescription4",
  "AdditionalImageURLs": [
    "AdditionalImageURLs6"
  ],
  "FacilitySquareFeet": 2
}
```

