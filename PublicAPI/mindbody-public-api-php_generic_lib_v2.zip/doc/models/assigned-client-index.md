
# Assigned Client Index

Represents a client index value assigned to a client

## Structure

`AssignedClientIndex`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The index ID assigned to the client. | getId(): ?int | setId(?int id): void |
| `valueId` | `?int` | Optional | The index’s value ID. | getValueId(): ?int | setValueId(?int valueId): void |

## Example (as JSON)

```json
{
  "Id": 80,
  "ValueId": 104
}
```

