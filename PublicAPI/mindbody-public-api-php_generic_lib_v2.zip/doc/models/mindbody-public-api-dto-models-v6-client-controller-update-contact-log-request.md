
# Mindbody Public Api Dto Models V6 Client Controller Update Contact Log Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of the contact log being updated. | getId(): ?int | setId(?int id): void |
| `test` | `?bool` | Optional | When `true`, indicates that this is a test request and no data is inserted into the subscriber?s database.<br /><br>When `false`, the database is updated. | getTest(): ?bool | setTest(?bool test): void |
| `assignedToStaffId` | `?int` | Optional | The ID of the staff member to whom the contact log is now being assigned. | getAssignedToStaffId(): ?int | setAssignedToStaffId(?int assignedToStaffId): void |
| `text` | `?string` | Optional | The contact log?s new text. | getText(): ?string | setText(?string text): void |
| `contactName` | `?string` | Optional | The name of the new person to be contacted by the assigned staff member. | getContactName(): ?string | setContactName(?string contactName): void |
| `followupByDate` | `?\DateTime` | Optional | The new date by which the assigned staff member should complete this contact log. | getFollowupByDate(): ?\DateTime | setFollowupByDate(?\DateTime followupByDate): void |
| `contactMethod` | `?string` | Optional | The new method by which the client wants to be contacted. | getContactMethod(): ?string | setContactMethod(?string contactMethod): void |
| `isComplete` | `?bool` | Optional | When `true`, indicates that the contact log is complete.<br>When `false`, indicates the contact log isn?t complete. | getIsComplete(): ?bool | setIsComplete(?bool isComplete): void |
| `comments` | [`?(MindbodyPublicApiDtoModelsV6UpdateContactLogComment[])`](../../doc/models/mindbody-public-api-dto-models-v6-update-contact-log-comment.md) | Optional | Contains information about the comments being updated or added to the contact log. Comments that have an ID of `0` are added to the contact log. | getComments(): ?array | setComments(?array comments): void |
| `types` | [`?(MindbodyPublicApiDtoModelsV6UpdateContactLogType[])`](../../doc/models/mindbody-public-api-dto-models-v6-update-contact-log-type.md) | Optional | Contains information about the contact logs types being assigned to the contact log, in addition to the contact log types that are already assigned. | getTypes(): ?array | setTypes(?array types): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Test": null,
  "AssignedToStaffId": null,
  "Text": null,
  "ContactName": null,
  "FollowupByDate": null,
  "ContactMethod": null,
  "IsComplete": null,
  "Comments": null,
  "Types": null
}
```

