
# Autopay Schedule

## Structure

`AutopaySchedule`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `frequencyType` | `?string` | Optional | Defines how often clients are charged. Possible values are:<br><br>* SetNumberOfAutopays<br>* MonthToMonth | getFrequencyType(): ?string | setFrequencyType(?string frequencyType): void |
| `frequencyValue` | `?int` | Optional | The interval of AutoPay frequency, combined with `FrequencyTimeUnit`. This value is null if `FrequencyType` is `MonthToMonth`. | getFrequencyValue(): ?int | setFrequencyValue(?int frequencyValue): void |
| `frequencyTimeUnit` | `?string` | Optional | Defines the time unit that sets how often to run the AutoPay, combined with `FrequencyValue`. This value is null if `FrequencyType` is `MonthToMonth`. Possible values are:<br><br>* Weekly<br>* Monthly<br>* Yearly | getFrequencyTimeUnit(): ?string | setFrequencyTimeUnit(?string frequencyTimeUnit): void |

## Example (as JSON)

```json
{
  "FrequencyType": null,
  "FrequencyValue": null,
  "FrequencyTimeUnit": null
}
```

