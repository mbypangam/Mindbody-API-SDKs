
# Get Appointment Options Response

## Structure

`GetAppointmentOptionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `options` | [`?(MindbodyPublicApiDtoModelsV6AppointmentOption[])`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-option.md) | Optional | Contains information about the appointment options. | getOptions(): ?array | setOptions(?array options): void |

## Example (as JSON)

```json
{
  "Options": null
}
```

