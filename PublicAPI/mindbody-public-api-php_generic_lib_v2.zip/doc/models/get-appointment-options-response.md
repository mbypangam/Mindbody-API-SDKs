
# Get Appointment Options Response

## Structure

`GetAppointmentOptionsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `options` | [`?(AppointmentOption[])`](../../doc/models/appointment-option.md) | Optional | Contains information about the appointment options. | getOptions(): ?array | setOptions(?array options): void |

## Example (as JSON)

```json
{
  "Options": [
    {
      "DisplayName": "DisplayName4",
      "Name": "Name2",
      "Value": "Value0",
      "Type": "Type2"
    },
    {
      "DisplayName": "DisplayName4",
      "Name": "Name2",
      "Value": "Value0",
      "Type": "Type2"
    }
  ]
}
```

