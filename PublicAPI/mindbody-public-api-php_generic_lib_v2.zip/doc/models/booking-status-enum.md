
# Booking Status Enum

Contains the booking?s payment status.

## Enumeration

`BookingStatusEnum`

## Fields

| Name |
|  --- |
| `PAYMENTREQUIRED` |
| `BOOKANDPAYLATER` |
| `FREE` |

