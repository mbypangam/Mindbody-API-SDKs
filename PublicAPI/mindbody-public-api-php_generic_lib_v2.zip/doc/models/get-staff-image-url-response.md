
# Get Staff Image URL Response

A response object returned from the GetStaffImgURL API.

## Structure

`GetStaffImageURLResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `imageURL` | `?string` | Optional | A staff member's image URL. | getImageURL(): ?string | setImageURL(?string imageURL): void |
| `mobileImageURL` | `?string` | Optional | A staff member's mobile image URL. | getMobileImageURL(): ?string | setMobileImageURL(?string mobileImageURL): void |

## Example (as JSON)

```json
{
  "ImageURL": null,
  "MobileImageURL": null
}
```

