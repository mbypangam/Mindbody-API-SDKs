
# Mindbody Public Api Dto Models V6 Service

## Structure

`MindbodyPublicApiDtoModelsV6Service`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `price` | `?float` | Optional | The cost of the pricing option when sold at a physical location. | getPrice(): ?float | setPrice(?float price): void |
| `onlinePrice` | `?float` | Optional | The cost of the pricing option when sold online. | getOnlinePrice(): ?float | setOnlinePrice(?float onlinePrice): void |
| `taxIncluded` | `?float` | Optional | The amount of tax included in the price, if inclusive pricing is enabled. | getTaxIncluded(): ?float | setTaxIncluded(?float taxIncluded): void |
| `programId` | `?int` | Optional | The ID of the program that this pricing option applies to. | getProgramId(): ?int | setProgramId(?int programId): void |
| `taxRate` | `?float` | Optional | The tax rate applied to the pricing option. This field is populated only when you include a `LocationID` in the request. | getTaxRate(): ?float | setTaxRate(?float taxRate): void |
| `productId` | `?int` | Optional | The unique ID of the pricing option. | getProductId(): ?int | setProductId(?int productId): void |
| `id` | `?string` | Optional | The barcode ID of the pricing option. | getId(): ?string | setId(?string id): void |
| `name` | `?string` | Optional | The name of the pricing option. | getName(): ?string | setName(?string name): void |
| `count` | `?int` | Optional | The initial count of usages available for the pricing option. | getCount(): ?int | setCount(?int count): void |
| `sellOnline` | `?bool` | Optional | A flag for whether or not the pricing option is sold online. | getSellOnline(): ?bool | setSellOnline(?bool sellOnline): void |
| `saleInContractOnly` | `?bool` | Optional | A flag for whether or not the pricing option is contractonly. | getSaleInContractOnly(): ?bool | setSaleInContractOnly(?bool saleInContractOnly): void |
| `type` | `?string` | Optional | Indicates if the pricing option is a drop-in, series, or unlimiited. | getType(): ?string | setType(?string type): void |
| `expirationType` | `?string` | Optional | Indicates if the pricing option begins its activation on the date of sale or first usage. | getExpirationType(): ?string | setExpirationType(?string expirationType): void |
| `expirationUnit` | `?string` | Optional | The unit, either days or months, of ExpirationLength. | getExpirationUnit(): ?string | setExpirationUnit(?string expirationUnit): void |
| `expirationLength` | `?int` | Optional | The lifetime of a pricing option. | getExpirationLength(): ?int | setExpirationLength(?int expirationLength): void |
| `revenueCategory` | `?string` | Optional | The revenue category of the pricing option. | getRevenueCategory(): ?string | setRevenueCategory(?string revenueCategory): void |
| `membershipId` | `?int` | Optional | The ID that this pricing option grants membership to. | getMembershipId(): ?int | setMembershipId(?int membershipId): void |
| `sellAtLocationIds` | `?(int[])` | Optional | The location IDs where this pricing option is sold. | getSellAtLocationIds(): ?array | setSellAtLocationIds(?array sellAtLocationIds): void |
| `useAtLocationIds` | `?(int[])` | Optional | The location IDs where this pricing option may be used. | getUseAtLocationIds(): ?array | setUseAtLocationIds(?array useAtLocationIds): void |
| `priority` | `?string` | Optional | The priority of the pricing option. | getPriority(): ?string | setPriority(?string priority): void |
| `isIntroOffer` | `?bool` | Optional | A flag that indicates if this pricing option is an introductory offer. | getIsIntroOffer(): ?bool | setIsIntroOffer(?bool isIntroOffer): void |
| `introOfferType` | `?string` | Optional | Indicates if this pricing option may be purchased to new clients or all clients. | getIntroOfferType(): ?string | setIntroOfferType(?string introOfferType): void |
| `isThirdPartyDiscountPricing` | `?bool` | Optional | A flag that indicates if this pricing option involves a third party discount | getIsThirdPartyDiscountPricing(): ?bool | setIsThirdPartyDiscountPricing(?bool isThirdPartyDiscountPricing): void |
| `program` | `?string` | Optional | The name of the program corresponding to ProgramId. | getProgram(): ?string | setProgram(?string program): void |
| `discontinued` | `?bool` | Optional | Whether this pricing option has been discontinued or not | getDiscontinued(): ?bool | setDiscontinued(?bool discontinued): void |

## Example (as JSON)

```json
{
  "Price": null,
  "OnlinePrice": null,
  "TaxIncluded": null,
  "ProgramId": null,
  "TaxRate": null,
  "ProductId": null,
  "Id": null,
  "Name": null,
  "Count": null,
  "SellOnline": null,
  "SaleInContractOnly": null,
  "Type": null,
  "ExpirationType": null,
  "ExpirationUnit": null,
  "ExpirationLength": null,
  "RevenueCategory": null,
  "MembershipId": null,
  "SellAtLocationIds": null,
  "UseAtLocationIds": null,
  "Priority": null,
  "IsIntroOffer": null,
  "IntroOfferType": null,
  "IsThirdPartyDiscountPricing": null,
  "Program": null,
  "Discontinued": null
}
```

