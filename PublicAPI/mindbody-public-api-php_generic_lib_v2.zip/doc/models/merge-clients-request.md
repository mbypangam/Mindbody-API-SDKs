
# Merge Clients Request

Request for clients/mergeclients

## Structure

`MergeClientsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `sourceClientId` | `?int` | Optional | The client that will be merged into TargetClientId | getSourceClientId(): ?int | setSourceClientId(?int sourceClientId): void |
| `targetClientId` | `?int` | Optional | The client that will remain | getTargetClientId(): ?int | setTargetClientId(?int targetClientId): void |

## Example (as JSON)

```json
{
  "SourceClientId": 88,
  "TargetClientId": 178
}
```

