
# Purchase Account Credit Response

## Structure

`PurchaseAccountCreditResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `amountPaid` | `?float` | Optional | The amount paid for the gift card by the purchaser. | getAmountPaid(): ?float | setAmountPaid(?float amountPaid): void |
| `clientId` | `?string` | Optional | The client ID of the purchaser. | getClientId(): ?string | setClientId(?string clientId): void |
| `saleId` | `?int` | Optional | The sale ID of the gift card. | getSaleId(): ?int | setSaleId(?int saleId): void |
| `emailReceipt` | `?bool` | Optional | Whether or not an email receipt was sent to the purchaser. If true, a receipt was sent. | getEmailReceipt(): ?bool | setEmailReceipt(?bool emailReceipt): void |
| `paymentProcessingFailures` | [`?(MindbodyPublicApiDtoModelsV6SaleControllerPaymentProcessingFailure[])`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-payment-processing-failure.md) | Optional | Any cart processing failures, for example when SCA challenged, the cart is in PaymentAuthenticationRequired state and at least one of the failures listed will provide an authentication Url. | getPaymentProcessingFailures(): ?array | setPaymentProcessingFailures(?array paymentProcessingFailures): void |

## Example (as JSON)

```json
{
  "AmountPaid": null,
  "ClientId": null,
  "SaleId": null,
  "EmailReceipt": null,
  "PaymentProcessingFailures": null
}
```

