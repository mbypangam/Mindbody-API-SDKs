
# Pricing Relationships

## Structure

`PricingRelationships`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paysFor` | `?(int[])` | Optional | - | getPaysFor(): ?array | setPaysFor(?array paysFor): void |
| `paidBy` | `?(int[])` | Optional | - | getPaidBy(): ?array | setPaidBy(?array paidBy): void |

## Example (as JSON)

```json
{
  "PaysFor": [
    92
  ],
  "PaidBy": [
    198,
    199
  ]
}
```

