
# Get Time Cards Response

## Structure

`GetTimeCardsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `timeCards` | [`?(TimeCardEvent[])`](../../doc/models/time-card-event.md) | Optional | Information about time card entries, ordered by staff ID. | getTimeCards(): ?array | setTimeCards(?array timeCards): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "TimeCards": [
    {
      "StaffId": 37,
      "Task": "Task5",
      "TimeIn": "2016-03-13T12:52:32.123Z",
      "TimeOut": "2016-03-13T12:52:32.123Z",
      "Hours": 180.13
    },
    {
      "StaffId": 38,
      "Task": "Task6",
      "TimeIn": "2016-03-13T12:52:32.123Z",
      "TimeOut": "2016-03-13T12:52:32.123Z",
      "Hours": 180.14
    }
  ]
}
```

