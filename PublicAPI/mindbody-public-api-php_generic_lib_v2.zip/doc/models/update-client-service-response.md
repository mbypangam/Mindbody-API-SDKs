
# Update Client Service Response

## Structure

`UpdateClientServiceResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientService` | [`?MindbodyPublicApiDtoModelsV6ClientService`](../../doc/models/mindbody-public-api-dto-models-v6-client-service.md) | Optional | Contains information about the service to be updated. | getClientService(): ?MindbodyPublicApiDtoModelsV6ClientService | setClientService(?MindbodyPublicApiDtoModelsV6ClientService clientService): void |

## Example (as JSON)

```json
{
  "ClientService": null
}
```

