
# Update Client Service Response

## Structure

`UpdateClientServiceResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `clientService` | [`?ClientService`](../../doc/models/client-service.md) | Optional | Contains information about the service to be updated. | getClientService(): ?ClientService | setClientService(?ClientService clientService): void |

## Example (as JSON)

```json
{
  "ClientService": null
}
```

