
# Sale

Contains the Sale details.

## Structure

`Sale`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The sale ID. | getId(): ?int | setId(?int id): void |
| `saleDate` | `?\DateTime` | Optional | The date the item was sold. | getSaleDate(): ?\DateTime | setSaleDate(?\DateTime saleDate): void |
| `saleTime` | `?string` | Optional | The time the item was sold. | getSaleTime(): ?string | setSaleTime(?string saleTime): void |
| `saleDateTime` | `?\DateTime` | Optional | The date and time the item was sold. | getSaleDateTime(): ?\DateTime | setSaleDateTime(?\DateTime saleDateTime): void |
| `originalSaleDateTime` | `?\DateTime` | Optional | The date and time the item was sold originally. | getOriginalSaleDateTime(): ?\DateTime | setOriginalSaleDateTime(?\DateTime originalSaleDateTime): void |
| `salesRepId` | `?int` | Optional | The sales representative ID | getSalesRepId(): ?int | setSalesRepId(?int salesRepId): void |
| `clientId` | `?string` | Optional | The ID of the client who made the purchase. | getClientId(): ?string | setClientId(?string clientId): void |
| `recipientClientId` | `?int` | Optional | Recipient Client Id | getRecipientClientId(): ?int | setRecipientClientId(?int recipientClientId): void |
| `purchasedItems` | [`?(PurchasedItem[])`](../../doc/models/purchased-item.md) | Optional | Contains the `PurchasedItem` objects that describe the purchased items. | getPurchasedItems(): ?array | setPurchasedItems(?array purchasedItems): void |
| `locationId` | `?int` | Optional | The ID of the location where the sale takes place. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `payments` | [`?(SalePayment[])`](../../doc/models/sale-payment.md) | Optional | Contains the `SalePayment` objects that describe the payments that contributed to this sale. | getPayments(): ?array | setPayments(?array payments): void |

## Example (as JSON)

```json
{
  "Id": null,
  "SaleDate": null,
  "SaleTime": null,
  "SaleDateTime": null,
  "OriginalSaleDateTime": null,
  "SalesRepId": null,
  "ClientId": null,
  "RecipientClientId": null,
  "PurchasedItems": null,
  "LocationId": null,
  "Payments": null
}
```

