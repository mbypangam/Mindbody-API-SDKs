
# Add Appointment Add on Request

Creates an add-on for an appointment

## Structure

`AddAppointmentAddOnRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `applyPayment` | `?bool` | Optional | When `true`, indicates that a payment should be applied to the appointment. Currently only ApplyPayment=false is implemented.<br>Default: **true** | getApplyPayment(): ?bool | setApplyPayment(?bool applyPayment): void |
| `appointmentId` | `?int` | Optional | The appointment ID the add-on is getting added to. | getAppointmentId(): ?int | setAppointmentId(?int appointmentId): void |
| `sessionTypeId` | `?int` | Optional | The session type associated with the new appointment add-on. | getSessionTypeId(): ?int | setSessionTypeId(?int sessionTypeId): void |
| `staffId` | `?int` | Optional | The ID of the staff member who is adding the new appointment add-on.<br>Default: staff member performing the appointment. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `test` | `?bool` | Optional | When `true`, indicates that the method is to be validated, but no new appointment add-on data is added.<br>Default: **false** | getTest(): ?bool | setTest(?bool test): void |

## Example (as JSON)

```json
{
  "ApplyPayment": null,
  "AppointmentId": null,
  "SessionTypeId": null,
  "StaffId": null,
  "Test": null
}
```

