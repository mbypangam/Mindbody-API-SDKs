
# Sub Category

## Structure

`SubCategory`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The Id of the subcategory. | getId(): ?int | setId(?int id): void |
| `subCategoryName` | `?string` | Optional | The name of the subcategory. | getSubCategoryName(): ?string | setSubCategoryName(?string subCategoryName): void |
| `active` | `?bool` | Optional | When `true`, indicates that the subcategory is active. | getActive(): ?bool | setActive(?bool active): void |

## Example (as JSON)

```json
{
  "Id": 158,
  "SubCategoryName": "SubCategoryName8",
  "Active": false
}
```

