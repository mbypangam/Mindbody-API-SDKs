
# Update Service Request

This class represents the request parameters for the update service API

## Structure

`UpdateServiceRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `barcodeId` | `?string` | Optional | The barcode ID of the pricing option. | getBarcodeId(): ?string | setBarcodeId(?string barcodeId): void |
| `price` | `?float` | Optional | The cost of the pricing option when sold at a physical location.<br>**Constraints**: `>= 0` | getPrice(): ?float | setPrice(?float price): void |
| `onlinePrice` | `?float` | Optional | The cost of the pricing option when sold online.<br>**Constraints**: `>= 0` | getOnlinePrice(): ?float | setOnlinePrice(?float onlinePrice): void |

## Example (as JSON)

```json
{
  "BarcodeId": "BarcodeId0",
  "Price": 6.2,
  "OnlinePrice": 40.72
}
```

