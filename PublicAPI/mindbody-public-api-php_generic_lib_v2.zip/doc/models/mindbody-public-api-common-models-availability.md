
# Mindbody Public Api Common Models Availability

The availability of a specific staff

## Structure

`MindbodyPublicApiCommonModelsAvailability`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | Id of the availability | getId(): ?int | setId(?int id): void |
| `staff` | [`?MindbodyPublicApiCommonModelsStaff`](../../doc/models/mindbody-public-api-common-models-staff.md) | Optional | Availabilities staff. | getStaff(): ?MindbodyPublicApiCommonModelsStaff | setStaff(?MindbodyPublicApiCommonModelsStaff staff): void |
| `resources` | [`?(MindbodyPublicApiCommonModelsResource[])`](../../doc/models/mindbody-public-api-common-models-resource.md) | Optional | Available resources | getResources(): ?array | setResources(?array resources): void |
| `sessionType` | [`?MindbodyPublicApiCommonModelsSessionType`](../../doc/models/mindbody-public-api-common-models-session-type.md) | Optional | Availabilities session type. | getSessionType(): ?MindbodyPublicApiCommonModelsSessionType | setSessionType(?MindbodyPublicApiCommonModelsSessionType sessionType): void |
| `programs` | [`?(MindbodyPublicApiCommonModelsProgram[])`](../../doc/models/mindbody-public-api-common-models-program.md) | Optional | Availabilities program list. | getPrograms(): ?array | setPrograms(?array programs): void |
| `startDateTime` | `?\DateTime` | Optional | Availabilities start date and time. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | Availabilities end date and time. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `bookableEndDateTime` | `?\DateTime` | Optional | Availabilities bookable end date and time. | getBookableEndDateTime(): ?\DateTime | setBookableEndDateTime(?\DateTime bookableEndDateTime): void |
| `location` | [`?MindbodyPublicApiCommonModelsLocation`](../../doc/models/mindbody-public-api-common-models-location.md) | Optional | Availabilities location. | getLocation(): ?MindbodyPublicApiCommonModelsLocation | setLocation(?MindbodyPublicApiCommonModelsLocation location): void |
| `prepTime` | `?int` | Optional | Appointment prep time | getPrepTime(): ?int | setPrepTime(?int prepTime): void |
| `finishTime` | `?int` | Optional | Appointment finish time | getFinishTime(): ?int | setFinishTime(?int finishTime): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "Resources": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

