
# Mindbody Public Api Dto Models V6 Appointment Add On

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentAddOn`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The ID of this add-on. | getId(): ?int | setId(?int id): void |
| `name` | `?string` | Optional | The name of this add-on. | getName(): ?string | setName(?string name): void |
| `numDeducted` | `?int` | Optional | The number of sessions that this add-on deducts from the pricing option used to pay for this add-on. | getNumDeducted(): ?int | setNumDeducted(?int numDeducted): void |
| `categoryId` | `?int` | Optional | This ID of this add-on's category. | getCategoryId(): ?int | setCategoryId(?int categoryId): void |
| `category` | `?string` | Optional | The name of this add-on's category. | getCategory(): ?string | setCategory(?string category): void |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "NumDeducted": null,
  "CategoryId": null,
  "Category": null
}
```

