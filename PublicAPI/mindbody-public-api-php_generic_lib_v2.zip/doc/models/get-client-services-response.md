
# Get Client Services Response

## Structure

`GetClientServicesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `clientServices` | [`?(ClientService[])`](../../doc/models/client-service.md) | Optional | Contains information about client pricing options. | getClientServices(): ?array | setClientServices(?array clientServices): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientServices": null
}
```

