
# Get Reservation Response

Get reservation response

## Structure

`GetReservationResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `reservations` | [`?(Reservation[])`](../../doc/models/reservation.md) | Optional | - | getReservations(): ?array | setReservations(?array reservations): void |
| `pagination` | [`?Pagination`](../../doc/models/pagination.md) | Optional | - | getPagination(): ?Pagination | setPagination(?Pagination pagination): void |
| `responseDetails` | [`?ResponseDetails`](../../doc/models/response-details.md) | Optional | - | getResponseDetails(): ?ResponseDetails | setResponseDetails(?ResponseDetails responseDetails): void |

## Example (as JSON)

```json
{
  "Reservations": null,
  "Pagination": null,
  "ResponseDetails": null
}
```

