
# Checkout Shopping Cart Response

## Structure

`CheckoutShoppingCartResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `shoppingCart` | [`?ShoppingCart`](../../doc/models/shopping-cart.md) | Optional | - | getShoppingCart(): ?ShoppingCart | setShoppingCart(?ShoppingCart shoppingCart): void |
| `classes` | [`?(MClass[])`](../../doc/models/m-class.md) | Optional | Contains information about the classes. | getClasses(): ?array | setClasses(?array classes): void |
| `appointments` | [`?(Appointment[])`](../../doc/models/appointment.md) | Optional | Contains information about the appointments. | getAppointments(): ?array | setAppointments(?array appointments): void |
| `enrollments` | [`?(ClassSchedule[])`](../../doc/models/class-schedule.md) | Optional | Contains information about enrollment class schedules. | getEnrollments(): ?array | setEnrollments(?array enrollments): void |

## Example (as JSON)

```json
{
  "ShoppingCart": {
    "Id": "Id0",
    "CartItems": [
      {
        "Item": {
          "key1": "val1",
          "key2": "val2"
        },
        "DiscountAmount": 244.77,
        "VisitIds": [
          197,
          198
        ],
        "AppointmentIds": [
          87,
          88,
          89
        ],
        "Appointments": [
          {
            "GenderPreference": "Female",
            "Duration": 249,
            "ProviderId": "ProviderId7",
            "Id": 203,
            "Status": "Requested"
          }
        ]
      },
      {
        "Item": {
          "key1": "val1",
          "key2": "val2"
        },
        "DiscountAmount": 244.78,
        "VisitIds": [
          198,
          199,
          200
        ],
        "AppointmentIds": [
          88
        ],
        "Appointments": [
          {
            "GenderPreference": "Male",
            "Duration": 250,
            "ProviderId": "ProviderId8",
            "Id": 204,
            "Status": "Booked"
          },
          {
            "GenderPreference": "None",
            "Duration": 251,
            "ProviderId": "ProviderId9",
            "Id": 205,
            "Status": "Completed"
          }
        ]
      },
      {
        "Item": {
          "key1": "val1",
          "key2": "val2"
        },
        "DiscountAmount": 244.79,
        "VisitIds": [
          199
        ],
        "AppointmentIds": [
          89,
          90
        ],
        "Appointments": [
          {
            "GenderPreference": "None",
            "Duration": 251,
            "ProviderId": "ProviderId9",
            "Id": 205,
            "Status": "Completed"
          },
          {
            "GenderPreference": "Female",
            "Duration": 252,
            "ProviderId": "ProviderId0",
            "Id": 206,
            "Status": "Confirmed"
          },
          {
            "GenderPreference": "Male",
            "Duration": 253,
            "ProviderId": "ProviderId1",
            "Id": 207,
            "Status": "Arrived"
          }
        ]
      }
    ],
    "SubTotal": 108.54,
    "DiscountTotal": 99.92,
    "TaxTotal": 136.36
  },
  "Classes": [
    {
      "ClassScheduleId": 27,
      "Visits": [
        {
          "AppointmentId": 122,
          "AppointmentGenderPreference": "Female",
          "AppointmentStatus": "NoShow",
          "ClassId": 214,
          "ClientId": "ClientId6"
        },
        {
          "AppointmentId": 121,
          "AppointmentGenderPreference": "Male",
          "AppointmentStatus": "Arrived",
          "ClassId": 215,
          "ClientId": "ClientId5"
        },
        {
          "AppointmentId": 120,
          "AppointmentGenderPreference": "None",
          "AppointmentStatus": "Confirmed",
          "ClassId": 216,
          "ClientId": "ClientId4"
        }
      ],
      "Clients": [
        {
          "AppointmentGenderPreference": "Female",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country2",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value3",
              "Id": 35,
              "DataType": "DataType9",
              "Name": "Name5"
            },
            {
              "Value": "Value4",
              "Id": 36,
              "DataType": "DataType0",
              "Name": "Name6"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "Male",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country3",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value4",
              "Id": 36,
              "DataType": "DataType0",
              "Name": "Name6"
            },
            {
              "Value": "Value5",
              "Id": 37,
              "DataType": "DataType1",
              "Name": "Name7"
            },
            {
              "Value": "Value6",
              "Id": 38,
              "DataType": "DataType2",
              "Name": "Name8"
            }
          ]
        }
      ],
      "Location": {
        "AdditionalImageURLs": [
          "AdditionalImageURLs9",
          "AdditionalImageURLs0",
          "AdditionalImageURLs1"
        ],
        "Address": "Address5",
        "Address2": "Address27",
        "Amenities": [
          {
            "Id": 223,
            "Name": "Name5"
          },
          {
            "Id": 224,
            "Name": "Name6"
          }
        ],
        "BusinessDescription": "BusinessDescription1"
      },
      "Resource": {
        "Id": 255,
        "Name": "Name3"
      }
    },
    {
      "ClassScheduleId": 28,
      "Visits": [
        {
          "AppointmentId": 121,
          "AppointmentGenderPreference": "Male",
          "AppointmentStatus": "Arrived",
          "ClassId": 215,
          "ClientId": "ClientId5"
        }
      ],
      "Clients": [
        {
          "AppointmentGenderPreference": "Male",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country3",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value4",
              "Id": 36,
              "DataType": "DataType0",
              "Name": "Name6"
            },
            {
              "Value": "Value5",
              "Id": 37,
              "DataType": "DataType1",
              "Name": "Name7"
            },
            {
              "Value": "Value6",
              "Id": 38,
              "DataType": "DataType2",
              "Name": "Name8"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "None",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country4",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value5",
              "Id": 37,
              "DataType": "DataType1",
              "Name": "Name7"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "Female",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country5",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value6",
              "Id": 38,
              "DataType": "DataType2",
              "Name": "Name8"
            },
            {
              "Value": "Value7",
              "Id": 39,
              "DataType": "DataType3",
              "Name": "Name9"
            }
          ]
        }
      ],
      "Location": {
        "AdditionalImageURLs": [
          "AdditionalImageURLs0"
        ],
        "Address": "Address6",
        "Address2": "Address28",
        "Amenities": [
          {
            "Id": 224,
            "Name": "Name6"
          },
          {
            "Id": 225,
            "Name": "Name7"
          },
          {
            "Id": 226,
            "Name": "Name8"
          }
        ],
        "BusinessDescription": "BusinessDescription2"
      },
      "Resource": {
        "Id": 254,
        "Name": "Name2"
      }
    }
  ],
  "Appointments": [
    {
      "GenderPreference": "Male",
      "Duration": 190,
      "ProviderId": "ProviderId6",
      "Id": 144,
      "Status": "LateCancelled"
    },
    {
      "GenderPreference": "None",
      "Duration": 191,
      "ProviderId": "ProviderId7",
      "Id": 145,
      "Status": "None"
    }
  ],
  "Enrollments": [
    {
      "Classes": [
        {
          "ClassScheduleId": 38,
          "Visits": [
            {
              "AppointmentId": 189,
              "AppointmentGenderPreference": "Male",
              "AppointmentStatus": "Booked",
              "ClassId": 147,
              "ClientId": "ClientId1"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "Male",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country7",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value8",
                  "Id": 46,
                  "DataType": "DataType4",
                  "Name": "Name0"
                },
                {
                  "Value": "Value9",
                  "Id": 47,
                  "DataType": "DataType5",
                  "Name": "Name1"
                },
                {
                  "Value": "Value0",
                  "Id": 48,
                  "DataType": "DataType6",
                  "Name": "Name2"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "None",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country8",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value9",
                  "Id": 47,
                  "DataType": "DataType5",
                  "Name": "Name1"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "Female",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country9",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value0",
                  "Id": 48,
                  "DataType": "DataType6",
                  "Name": "Name2"
                },
                {
                  "Value": "Value1",
                  "Id": 49,
                  "DataType": "DataType7",
                  "Name": "Name3"
                }
              ]
            }
          ],
          "Location": {
            "AdditionalImageURLs": [
              "AdditionalImageURLs6"
            ],
            "Address": "Address0",
            "Address2": "Address22",
            "Amenities": [
              {
                "Id": 234,
                "Name": "Name0"
              },
              {
                "Id": 235,
                "Name": "Name1"
              },
              {
                "Id": 236,
                "Name": "Name2"
              }
            ],
            "BusinessDescription": "BusinessDescription6"
          },
          "Resource": {
            "Id": 244,
            "Name": "Name8"
          }
        },
        {
          "ClassScheduleId": 39,
          "Visits": [
            {
              "AppointmentId": 190,
              "AppointmentGenderPreference": "Female",
              "AppointmentStatus": "Completed",
              "ClassId": 146,
              "ClientId": "ClientId2"
            },
            {
              "AppointmentId": 191,
              "AppointmentGenderPreference": "None",
              "AppointmentStatus": "Confirmed",
              "ClassId": 145,
              "ClientId": "ClientId3"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "None",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country8",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value9",
                  "Id": 47,
                  "DataType": "DataType5",
                  "Name": "Name1"
                }
              ]
            }
          ],
          "Location": {
            "AdditionalImageURLs": [
              "AdditionalImageURLs5",
              "AdditionalImageURLs4"
            ],
            "Address": "Address1",
            "Address2": "Address23",
            "Amenities": [
              {
                "Id": 235,
                "Name": "Name1"
              }
            ],
            "BusinessDescription": "BusinessDescription7"
          },
          "Resource": {
            "Id": 243,
            "Name": "Name7"
          }
        },
        {
          "ClassScheduleId": 40,
          "Visits": [
            {
              "AppointmentId": 191,
              "AppointmentGenderPreference": "None",
              "AppointmentStatus": "Confirmed",
              "ClassId": 145,
              "ClientId": "ClientId3"
            },
            {
              "AppointmentId": 192,
              "AppointmentGenderPreference": "Male",
              "AppointmentStatus": "Arrived",
              "ClassId": 144,
              "ClientId": "ClientId4"
            },
            {
              "AppointmentId": 193,
              "AppointmentGenderPreference": "Female",
              "AppointmentStatus": "NoShow",
              "ClassId": 143,
              "ClientId": "ClientId5"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "Female",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country9",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value0",
                  "Id": 48,
                  "DataType": "DataType6",
                  "Name": "Name2"
                },
                {
                  "Value": "Value1",
                  "Id": 49,
                  "DataType": "DataType7",
                  "Name": "Name3"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "Male",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country0",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value1",
                  "Id": 49,
                  "DataType": "DataType7",
                  "Name": "Name3"
                },
                {
                  "Value": "Value2",
                  "Id": 50,
                  "DataType": "DataType8",
                  "Name": "Name4"
                },
                {
                  "Value": "Value3",
                  "Id": 51,
                  "DataType": "DataType9",
                  "Name": "Name5"
                }
              ]
            }
          ],
          "Location": {
            "AdditionalImageURLs": [
              "AdditionalImageURLs4",
              "AdditionalImageURLs3",
              "AdditionalImageURLs2"
            ],
            "Address": "Address2",
            "Address2": "Address24",
            "Amenities": [
              {
                "Id": 236,
                "Name": "Name2"
              },
              {
                "Id": 237,
                "Name": "Name3"
              }
            ],
            "BusinessDescription": "BusinessDescription8"
          },
          "Resource": {
            "Id": 242,
            "Name": "Name6"
          }
        }
      ],
      "Clients": [
        {
          "AppointmentGenderPreference": "Female",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country4",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value5",
              "Id": 1,
              "DataType": "DataType1",
              "Name": "Name7"
            },
            {
              "Value": "Value6",
              "Id": 2,
              "DataType": "DataType2",
              "Name": "Name8"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "Male",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country5",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value6",
              "Id": 2,
              "DataType": "DataType2",
              "Name": "Name8"
            },
            {
              "Value": "Value7",
              "Id": 3,
              "DataType": "DataType3",
              "Name": "Name9"
            },
            {
              "Value": "Value8",
              "Id": 4,
              "DataType": "DataType4",
              "Name": "Name0"
            }
          ]
        }
      ],
      "Course": {
        "Id": 245,
        "Name": "Name1",
        "Description": "Description5",
        "Notes": "Notes3",
        "StartDate": "2016-03-13T12:52:32.123Z"
      },
      "SemesterId": 203,
      "IsAvailable": true
    },
    {
      "Classes": [
        {
          "ClassScheduleId": 37,
          "Visits": [
            {
              "AppointmentId": 188,
              "AppointmentGenderPreference": "None",
              "AppointmentStatus": "Requested",
              "ClassId": 148,
              "ClientId": "ClientId0"
            },
            {
              "AppointmentId": 189,
              "AppointmentGenderPreference": "Male",
              "AppointmentStatus": "Booked",
              "ClassId": 147,
              "ClientId": "ClientId1"
            },
            {
              "AppointmentId": 190,
              "AppointmentGenderPreference": "Female",
              "AppointmentStatus": "Completed",
              "ClassId": 146,
              "ClientId": "ClientId2"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "Female",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country6",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value7",
                  "Id": 45,
                  "DataType": "DataType3",
                  "Name": "Name9"
                },
                {
                  "Value": "Value8",
                  "Id": 46,
                  "DataType": "DataType4",
                  "Name": "Name0"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "Male",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country7",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value8",
                  "Id": 46,
                  "DataType": "DataType4",
                  "Name": "Name0"
                },
                {
                  "Value": "Value9",
                  "Id": 47,
                  "DataType": "DataType5",
                  "Name": "Name1"
                },
                {
                  "Value": "Value0",
                  "Id": 48,
                  "DataType": "DataType6",
                  "Name": "Name2"
                }
              ]
            }
          ],
          "Location": {
            "AdditionalImageURLs": [
              "AdditionalImageURLs7",
              "AdditionalImageURLs6",
              "AdditionalImageURLs5"
            ],
            "Address": "Address9",
            "Address2": "Address21",
            "Amenities": [
              {
                "Id": 233,
                "Name": "Name9"
              },
              {
                "Id": 234,
                "Name": "Name0"
              }
            ],
            "BusinessDescription": "BusinessDescription5"
          },
          "Resource": {
            "Id": 245,
            "Name": "Name9"
          }
        },
        {
          "ClassScheduleId": 38,
          "Visits": [
            {
              "AppointmentId": 189,
              "AppointmentGenderPreference": "Male",
              "AppointmentStatus": "Booked",
              "ClassId": 147,
              "ClientId": "ClientId1"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "Male",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country7",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value8",
                  "Id": 46,
                  "DataType": "DataType4",
                  "Name": "Name0"
                },
                {
                  "Value": "Value9",
                  "Id": 47,
                  "DataType": "DataType5",
                  "Name": "Name1"
                },
                {
                  "Value": "Value0",
                  "Id": 48,
                  "DataType": "DataType6",
                  "Name": "Name2"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "None",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country8",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value9",
                  "Id": 47,
                  "DataType": "DataType5",
                  "Name": "Name1"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "Female",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country9",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value0",
                  "Id": 48,
                  "DataType": "DataType6",
                  "Name": "Name2"
                },
                {
                  "Value": "Value1",
                  "Id": 49,
                  "DataType": "DataType7",
                  "Name": "Name3"
                }
              ]
            }
          ],
          "Location": {
            "AdditionalImageURLs": [
              "AdditionalImageURLs6"
            ],
            "Address": "Address0",
            "Address2": "Address22",
            "Amenities": [
              {
                "Id": 234,
                "Name": "Name0"
              },
              {
                "Id": 235,
                "Name": "Name1"
              },
              {
                "Id": 236,
                "Name": "Name2"
              }
            ],
            "BusinessDescription": "BusinessDescription6"
          },
          "Resource": {
            "Id": 244,
            "Name": "Name8"
          }
        }
      ],
      "Clients": [
        {
          "AppointmentGenderPreference": "Male",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country5",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value6",
              "Id": 2,
              "DataType": "DataType2",
              "Name": "Name8"
            },
            {
              "Value": "Value7",
              "Id": 3,
              "DataType": "DataType3",
              "Name": "Name9"
            },
            {
              "Value": "Value8",
              "Id": 4,
              "DataType": "DataType4",
              "Name": "Name0"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "None",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country6",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value7",
              "Id": 3,
              "DataType": "DataType3",
              "Name": "Name9"
            }
          ]
        },
        {
          "AppointmentGenderPreference": "Female",
          "BirthDate": "2016-03-13T12:52:32.123Z",
          "Country": "Country7",
          "CreationDate": "2016-03-13T12:52:32.123Z",
          "CustomClientFields": [
            {
              "Value": "Value8",
              "Id": 4,
              "DataType": "DataType4",
              "Name": "Name0"
            },
            {
              "Value": "Value9",
              "Id": 5,
              "DataType": "DataType5",
              "Name": "Name1"
            }
          ]
        }
      ],
      "Course": {
        "Id": 246,
        "Name": "Name2",
        "Description": "Description4",
        "Notes": "Notes4",
        "StartDate": "2016-03-13T12:52:32.123Z"
      },
      "SemesterId": 202,
      "IsAvailable": false
    }
  ]
}
```

