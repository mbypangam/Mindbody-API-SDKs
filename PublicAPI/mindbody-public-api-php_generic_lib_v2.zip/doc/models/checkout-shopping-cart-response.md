
# Checkout Shopping Cart Response

## Structure

`CheckoutShoppingCartResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `shoppingCart` | [`?ShoppingCart`](../../doc/models/shopping-cart.md) | Optional | - | getShoppingCart(): ?ShoppingCart | setShoppingCart(?ShoppingCart shoppingCart): void |
| `classes` | [`?(MClass[])`](../../doc/models/m-class.md) | Optional | Contains information about the classes. | getClasses(): ?array | setClasses(?array classes): void |
| `appointments` | [`?(Appointment[])`](../../doc/models/appointment.md) | Optional | Contains information about the appointments. | getAppointments(): ?array | setAppointments(?array appointments): void |
| `enrollments` | [`?(ClassSchedule[])`](../../doc/models/class-schedule.md) | Optional | Contains information about enrollment class schedules. | getEnrollments(): ?array | setEnrollments(?array enrollments): void |

## Example (as JSON)

```json
{
  "ShoppingCart": null,
  "Classes": null,
  "Appointments": null,
  "Enrollments": null
}
```

