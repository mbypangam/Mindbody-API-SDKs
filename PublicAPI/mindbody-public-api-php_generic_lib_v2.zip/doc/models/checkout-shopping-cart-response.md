
# Checkout Shopping Cart Response

## Structure

`CheckoutShoppingCartResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `shoppingCart` | [`?MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleShoppingCart`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-completed-sale-shopping-cart.md) | Optional | Contains information about the shopping cart. | getShoppingCart(): ?MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleShoppingCart | setShoppingCart(?MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleShoppingCart shoppingCart): void |
| `classes` | [`?(MindbodyPublicApiDtoModelsV6Class[])`](../../doc/models/mindbody-public-api-dto-models-v6-class.md) | Optional | Contains information about the classes. | getClasses(): ?array | setClasses(?array classes): void |
| `appointments` | [`?(MindbodyPublicApiDtoModelsV6Appointment[])`](../../doc/models/mindbody-public-api-dto-models-v6-appointment.md) | Optional | Contains information about the appointments. | getAppointments(): ?array | setAppointments(?array appointments): void |
| `enrollments` | [`?(MindbodyPublicApiDtoModelsV6ClassSchedule[])`](../../doc/models/mindbody-public-api-dto-models-v6-class-schedule.md) | Optional | Contains information about enrollment class schedules. | getEnrollments(): ?array | setEnrollments(?array enrollments): void |

## Example (as JSON)

```json
{
  "ShoppingCart": null,
  "Classes": null,
  "Appointments": null,
  "Enrollments": null
}
```

