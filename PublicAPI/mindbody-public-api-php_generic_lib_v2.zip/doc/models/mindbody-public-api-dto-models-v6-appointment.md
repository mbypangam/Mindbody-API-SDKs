
# Mindbody Public Api Dto Models V6 Appointment

Contains information about an appointment.

## Structure

`MindbodyPublicApiDtoModelsV6Appointment`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `genderPreference` | [`?string (GenderPreferenceEnum)`](../../doc/models/gender-preference-enum.md) | Optional | The prefered gender of the appointment provider.<br>Possible values are:<br><br>* None<br>* Female<br>* Male | getGenderPreference(): ?string | setGenderPreference(?string genderPreference): void |
| `duration` | `?int` | Optional | The duration of the appointment. | getDuration(): ?int | setDuration(?int duration): void |
| `providerId` | `?string` | Optional | If a user has Complementary and Alternative Medicine features enabled, this property indicates the provider assigned to the appointment. | getProviderId(): ?string | setProviderId(?string providerId): void |
| `id` | `?int` | Optional | The unique ID of the appointment. | getId(): ?int | setId(?int id): void |
| `status` | [`?string (StatusEnum)`](../../doc/models/status-enum.md) | Optional | The status of this appointment.<br>Possible values are:<br><br>* None<br>* Requested<br>* Booked<br>* Completed<br>* Confirmed<br>* Arrived<br>* NoShow<br>* Cancelled<br>* LateCancelled | getStatus(): ?string | setStatus(?string status): void |
| `startDateTime` | `?\DateTime` | Optional | The date and time the appointment is to start. | getStartDateTime(): ?\DateTime | setStartDateTime(?\DateTime startDateTime): void |
| `endDateTime` | `?\DateTime` | Optional | The date and time the appointment is to end. | getEndDateTime(): ?\DateTime | setEndDateTime(?\DateTime endDateTime): void |
| `notes` | `?string` | Optional | Any notes associated with the appointment. | getNotes(): ?string | setNotes(?string notes): void |
| `partnerExternalId` | `?string` | Optional | Optional external key for api partners. | getPartnerExternalId(): ?string | setPartnerExternalId(?string partnerExternalId): void |
| `staffRequested` | `?bool` | Optional | When `true`, indicates that the staff member was requested specifically by the client. | getStaffRequested(): ?bool | setStaffRequested(?bool staffRequested): void |
| `programId` | `?int` | Optional | The ID of the program to which this appointment belongs. | getProgramId(): ?int | setProgramId(?int programId): void |
| `sessionTypeId` | `?int` | Optional | The ID of the session type of this appointment. | getSessionTypeId(): ?int | setSessionTypeId(?int sessionTypeId): void |
| `locationId` | `?int` | Optional | The ID of the location where this appointment is to take place. | getLocationId(): ?int | setLocationId(?int locationId): void |
| `staffId` | `?int` | Optional | The ID of the staff member providing the service for this appointment. | getStaffId(): ?int | setStaffId(?int staffId): void |
| `clientId` | `?string` | Optional | The RSSID of the client who is booked for this appointment. | getClientId(): ?string | setClientId(?string clientId): void |
| `firstAppointment` | `?bool` | Optional | When `true`, indicates that this is the client's first appointment at this site. | getFirstAppointment(): ?bool | setFirstAppointment(?bool firstAppointment): void |
| `isWaitlist` | `?bool` | Optional | When `true`, indicates that the client should be added to a specific appointment waiting list.<br>When `false`, the client should not be added to the waiting list.<br>Default: *false* | getIsWaitlist(): ?bool | setIsWaitlist(?bool isWaitlist): void |
| `waitlistEntryId` | `?int` | Optional | The unique ID of the appointment waitlist. | getWaitlistEntryId(): ?int | setWaitlistEntryId(?int waitlistEntryId): void |
| `clientServiceId` | `?int` | Optional | The ID of the pass on the client's account that is to pay for this appointment. | getClientServiceId(): ?int | setClientServiceId(?int clientServiceId): void |
| `resources` | [`?(MindbodyPublicApiDtoModelsV6Resource[])`](../../doc/models/mindbody-public-api-dto-models-v6-resource.md) | Optional | The resources this appointment is to use. | getResources(): ?array | setResources(?array resources): void |
| `addOns` | [`?(MindbodyPublicApiDtoModelsV6AddOnSmall[])`](../../doc/models/mindbody-public-api-dto-models-v6-add-on-small.md) | Optional | Any AddOns associated with the appointment | getAddOns(): ?array | setAddOns(?array addOns): void |
| `onlineDescription` | `?string` | Optional | Online Description associated with the appointment | getOnlineDescription(): ?string | setOnlineDescription(?string onlineDescription): void |

## Example (as JSON)

```json
{
  "GenderPreference": null,
  "Duration": null,
  "ProviderId": null,
  "Id": null,
  "Status": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Notes": null,
  "PartnerExternalId": null,
  "StaffRequested": null,
  "ProgramId": null,
  "SessionTypeId": null,
  "LocationId": null,
  "StaffId": null,
  "ClientId": null,
  "FirstAppointment": null,
  "IsWaitlist": null,
  "WaitlistEntryId": null,
  "ClientServiceId": null,
  "Resources": null,
  "AddOns": null,
  "OnlineDescription": null
}
```

