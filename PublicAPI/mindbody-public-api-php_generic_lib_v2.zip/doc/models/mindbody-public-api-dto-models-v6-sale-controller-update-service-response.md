
# Mindbody Public Api Dto Models V6 Sale Controller Update Service Response

A response from the Update Services API method.

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `services` | [`?(MindbodyPublicApiDtoModelsV6Service[])`](../../doc/models/mindbody-public-api-dto-models-v6-service.md) | Optional | List of services as response | getServices(): ?array | setServices(?array services): void |

## Example (as JSON)

```json
{
  "Services": null
}
```

