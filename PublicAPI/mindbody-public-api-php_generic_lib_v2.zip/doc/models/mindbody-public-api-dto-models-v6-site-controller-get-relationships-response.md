
# Mindbody Public Api Dto Models V6 Site Controller Get Relationships Response

Get Relationships Response Model

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetRelationshipsResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. | getPaginationResponse(): ?MindbodyPublicApiDtoModelsV6PaginationResponse | setPaginationResponse(?MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse): void |
| `relationships` | [`?(MindbodyPublicApiDtoModelsV6Relationship[])`](../../doc/models/mindbody-public-api-dto-models-v6-relationship.md) | Optional | A list of relationships. | getRelationships(): ?array | setRelationships(?array relationships): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Relationships": null
}
```

