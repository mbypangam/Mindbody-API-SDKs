
# Sales Rep Response

This is the sales rep DTO

## Structure

`SalesRepResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `id` | `?int` | Optional | The unique Id of the sales rep | getId(): ?int | setId(?int id): void |
| `firstName` | `?string` | Optional | The firstname of the sales rep | getFirstName(): ?string | setFirstName(?string firstName): void |
| `lastName` | `?string` | Optional | The lastname of the sales rep | getLastName(): ?string | setLastName(?string lastName): void |
| `salesRepNumbers` | `?(int[])` | Optional | The sales rep Ids that are assigned to the rep | getSalesRepNumbers(): ?array | setSalesRepNumbers(?array salesRepNumbers): void |

## Example (as JSON)

```json
{
  "Id": 146,
  "FirstName": "FirstName4",
  "LastName": "LastName4",
  "SalesRepNumbers": [
    70,
    71,
    72
  ]
}
```

