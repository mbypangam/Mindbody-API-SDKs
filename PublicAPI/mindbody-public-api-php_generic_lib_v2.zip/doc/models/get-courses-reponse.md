
# Get Courses Reponse

This is the response class for the get courses API

## Structure

`GetCoursesReponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `courses` | [`?(Course[])`](../../doc/models/course.md) | Optional | This is the list course data | getCourses(): ?array | setCourses(?array courses): void |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Courses": null
}
```

