
# Get Courses Reponse

This is the response class for the get courses API

## Structure

`GetCoursesReponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `paginationResponse` | [`?PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. | getPaginationResponse(): ?PaginationResponse | setPaginationResponse(?PaginationResponse paginationResponse): void |
| `courses` | [`?(Course[])`](../../doc/models/course.md) | Optional | This is the list course data | getCourses(): ?array | setCourses(?array courses): void |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Courses": [
    {
      "Id": 90,
      "Name": "Name2",
      "Description": "Description4",
      "Notes": "Notes6",
      "StartDate": "2016-03-13T12:52:32.123Z"
    },
    {
      "Id": 91,
      "Name": "Name3",
      "Description": "Description3",
      "Notes": "Notes5",
      "StartDate": "2016-03-13T12:52:32.123Z"
    },
    {
      "Id": 92,
      "Name": "Name4",
      "Description": "Description2",
      "Notes": "Notes4",
      "StartDate": "2016-03-13T12:52:32.123Z"
    }
  ]
}
```

