
# Add Client Request

## Structure

`AddClientRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `accountBalance` | `?float` | Optional | The client’s current [account balance](https://mindbody-online-support.force.com/support/s/article/203262013-Adding-account-payments-video-tutorial?language=en_US). | getAccountBalance(): ?float | setAccountBalance(?float accountBalance): void |
| `action` | [`?string (Action1Enum)`](../../doc/models/action-1-enum.md) | Optional | The action taken. | getAction(): ?string | setAction(?string action): void |
| `active` | `?bool` | Optional | When `true`, indicates that the client is active at the site.<br /><br>When `false`, indicates that the client is not active at the site. | getActive(): ?bool | setActive(?bool active): void |
| `addressLine1` | `?string` | Optional | The first line of the client’s street address. | getAddressLine1(): ?string | setAddressLine1(?string addressLine1): void |
| `addressLine2` | `?string` | Optional | The second line of the client’s street address, if needed. | getAddressLine2(): ?string | setAddressLine2(?string addressLine2): void |
| `apptGenderPrefMale` | `?bool` | Optional | When `true`, indicates that the client prefers services to be provided by a male service provider.<br /><br>When `false`, indicates that the client prefers services to be provided by a female service provider.<br /><br>When `null`, indicates that the client has no preference.<br>Default: **null** | getApptGenderPrefMale(): ?bool | setApptGenderPrefMale(?bool apptGenderPrefMale): void |
| `birthDate` | `?\DateTime` | Optional | The client’s date of birth. | getBirthDate(): ?\DateTime | setBirthDate(?\DateTime birthDate): void |
| `city` | `?string` | Optional | The client’s city. | getCity(): ?string | setCity(?string city): void |
| `clientCreditCard` | [`?ClientCreditCard`](../../doc/models/client-credit-card.md) | Optional | Contains information about the client’s credit card. | getClientCreditCard(): ?ClientCreditCard | setClientCreditCard(?ClientCreditCard clientCreditCard): void |
| `clientIndexes` | [`?(AssignedClientIndex[])`](../../doc/models/assigned-client-index.md) | Optional | Contains a list of the indexes and client index values to be assigned to the client.<br><br>If an index is already assigned to the client, it is overwritten with the passed index value. You cannot currently remove client indexes using the Public API. Only the indexes passed in the request are returned in the response. | getClientIndexes(): ?array | setClientIndexes(?array clientIndexes): void |
| `clientRelationships` | [`?(ClientRelationship[])`](../../doc/models/client-relationship.md) | Optional | Contains information about client relationships that were added or updated for the client. This parameter does not include all of the relationships assigned to the client, only the ones passed in the request. | getClientRelationships(): ?array | setClientRelationships(?array clientRelationships): void |
| `country` | `?string` | Optional | The country in which the client is located. | getCountry(): ?string | setCountry(?string country): void |
| `creationDate` | `?\DateTime` | Optional | The date when the client was added to the business, either by the client from the online store or by a staff member at the subscriber’s business. This value always returns in the format yyyy-mm-ddThh:mm:ss:ms. | getCreationDate(): ?\DateTime | setCreationDate(?\DateTime creationDate): void |
| `customClientFields` | [`?(CustomClientFieldValue[])`](../../doc/models/custom-client-field-value.md) | Optional | Contains information about the custom fields used for clients in the business. | getCustomClientFields(): ?array | setCustomClientFields(?array customClientFields): void |
| `email` | `?string` | Optional | The client’s email address. | getEmail(): ?string | setEmail(?string email): void |
| `emergencyContactInfoEmail` | `?string` | Optional | The email address of the client’s emergency contact.<br /><br>For more information, see [Children’s program features(emergency contact information)](https://support.mindbodyonline.com/s/article/203259283-Children-s-program-features-emergency-contact-information?language=en_US). | getEmergencyContactInfoEmail(): ?string | setEmergencyContactInfoEmail(?string emergencyContactInfoEmail): void |
| `emergencyContactInfoName` | `?string` | Optional | The name of the client’s emergency contact. | getEmergencyContactInfoName(): ?string | setEmergencyContactInfoName(?string emergencyContactInfoName): void |
| `emergencyContactInfoPhone` | `?string` | Optional | The phone number of the client’s emergency contact. | getEmergencyContactInfoPhone(): ?string | setEmergencyContactInfoPhone(?string emergencyContactInfoPhone): void |
| `emergencyContactInfoRelationship` | `?string` | Optional | The client’s relationship with the emergency contact, for example, mother or spouse. | getEmergencyContactInfoRelationship(): ?string | setEmergencyContactInfoRelationship(?string emergencyContactInfoRelationship): void |
| `firstAppointmentDate` | `?\DateTime` | Optional | The date of the client’s first booked appointment at the business. | getFirstAppointmentDate(): ?\DateTime | setFirstAppointmentDate(?\DateTime firstAppointmentDate): void |
| `firstName` | `string` | Required | The client’s first name. You must specify a first name when you add a client. | getFirstName(): string | setFirstName(string firstName): void |
| `gender` | `?string` | Optional | The client’s gender. | getGender(): ?string | setGender(?string gender): void |
| `homeLocation` | [`?Location`](../../doc/models/location.md) | Optional | Sets the client’s home location to the passed location, based on its ID. | getHomeLocation(): ?Location | setHomeLocation(?Location homeLocation): void |
| `homePhone` | `?string` | Optional | The client’s home phone number. | getHomePhone(): ?string | setHomePhone(?string homePhone): void |
| `isCompany` | `?bool` | Optional | When `true`, indicates that the client should be marked as a company at the business.<br /><br>When `false`, indicates the client is an individual and does not represent a company. | getIsCompany(): ?bool | setIsCompany(?bool isCompany): void |
| `isProspect` | `?bool` | Optional | This value is set only if the business owner allows individuals to be prospects.<br /><br>If the business owner has enabled the setting to default new client as a Prospect, the isProspect value will always be true. Otherwise,<br /><br>When `true`, indicates that the client should be marked as a prospect for the business.<br /><br>When `false`, indicates that the client should not be marked as a prospect for the business. | getIsProspect(): ?bool | setIsProspect(?bool isProspect): void |
| `lastFormulaNotes` | `?string` | Optional | The last [formula note](https://support.mindbodyonline.com/s/article/203259903-Appointments-Formula-notes?language=en_US) entered for the client. | getLastFormulaNotes(): ?string | setLastFormulaNotes(?string lastFormulaNotes): void |
| `lastModifiedDateTime` | `?\DateTime` | Optional | The UTC date and time when the client’s information was last modified. | getLastModifiedDateTime(): ?\DateTime | setLastModifiedDateTime(?\DateTime lastModifiedDateTime): void |
| `lastName` | `string` | Required | The client’s last name. You must specify a last name when you add a client. | getLastName(): string | setLastName(string lastName): void |
| `liability` | [`?Liability`](../../doc/models/liability.md) | Optional | Contains the client’s liability agreement information for the business. | getLiability(): ?Liability | setLiability(?Liability liability): void |
| `liabilityRelease` | `?bool` | Optional | When `true`, sets the client’s liability information as follows:<br><br>* `IsReleased` is set to true.<br>* `AgreementDate` is set to the time zone of the business when the call was processed.<br>* `ReleasedBy` is set to `null` if the call is made by the client, `0` if the call was made by the business owner, or to a specific staff member’s ID if a staff member made the call.<br>  When `false`, sets the client’s liability information as follows:<br>* `IsReleased` is set to `false`.<br>* `AgreementDate` is set to `null`.<br>* `ReleasedBy` is set to `null`. | getLiabilityRelease(): ?bool | setLiabilityRelease(?bool liabilityRelease): void |
| `membershipIcon` | `?int` | Optional | The ID of the membership icon displayed next to the client’s name, if the client has a membership on their account. | getMembershipIcon(): ?int | setMembershipIcon(?int membershipIcon): void |
| `middleName` | `?string` | Optional | The client’s middle name. | getMiddleName(): ?string | setMiddleName(?string middleName): void |
| `mobilePhone` | `?string` | Optional | The client’s mobile phone number. | getMobilePhone(): ?string | setMobilePhone(?string mobilePhone): void |
| `mobileProvider` | `?int` | Optional | The client's mobile provider. | getMobileProvider(): ?int | setMobileProvider(?int mobileProvider): void |
| `newId` | `?string` | Optional | The new RSSID to be used for the client. Use `NewId` to assign a specific alphanumeric value to be a client’s ID. This RSSID must be unique within the subscriber’s site. If this is a cross-regional update, the RSSID must be unique across the region. If the requested value is already in use, the call returns an error. | getNewId(): ?string | setNewId(?string newId): void |
| `notes` | `?string` | Optional | Any notes entered on the client’s account by staff members. This value should never be shown to clients unless the business owner has a specific reason for showing them. | getNotes(): ?string | setNotes(?string notes): void |
| `photoUrl` | `?string` | Optional | The URL for the client’s photo, if one has been uploaded. | getPhotoUrl(): ?string | setPhotoUrl(?string photoUrl): void |
| `postalCode` | `?string` | Optional | The client’s postal code. | getPostalCode(): ?string | setPostalCode(?string postalCode): void |
| `prospectStage` | [`?ProspectStage`](../../doc/models/prospect-stage.md) | Optional | Contains information about the client [prospect stage](https://support.mindbodyonline.com/s/article/206176457-Prospect-Stages?language=en_US). | getProspectStage(): ?ProspectStage | setProspectStage(?ProspectStage prospectStage): void |
| `redAlert` | `?string` | Optional | Contains any red alert information entered by the business owner for the client. | getRedAlert(): ?string | setRedAlert(?string redAlert): void |
| `referredBy` | `?string` | Optional | Specifies how the client was referred to the business. You can get a list of possible strings using the `GET ClientReferralTypes` endpoint.<br /><br>For more information, see [Referral types and referral subtypes](https://support.mindbodyonline.com/s/article/203259393-Referral-types-and-referral-subtypes?language=en_US). | getReferredBy(): ?string | setReferredBy(?string referredBy): void |
| `salesReps` | [`?(SalesRep[])`](../../doc/models/sales-rep.md) | Optional | Contains information about the sales representatives to be assigned to the new client. | getSalesReps(): ?array | setSalesReps(?array salesReps): void |
| `siteId` | `?int` | Optional | The ID of the site. | getSiteId(): ?int | setSiteId(?int siteId): void |
| `state` | `?string` | Optional | The client’s state. | getState(): ?string | setState(?string state): void |
| `status` | `?string` | Optional | The client’s status. | getStatus(): ?string | setStatus(?string status): void |
| `test` | `?bool` | Optional | When `true`, indicates that test mode is enabled. The method is validated, but no client data is added or updated.<br /><br>Default: **false** | getTest(): ?bool | setTest(?bool test): void |
| `uniqueId` | `?int` | Optional | The client’s system-generated ID at the business. This value cannot be changed by business owners and is always unique across all clients at the business. This ID is not widely used in the Public API, but can be used by your application to uniquely identify clients. | getUniqueId(): ?int | setUniqueId(?int uniqueId): void |
| `workExtension` | `?string` | Optional | The client’s work phone extension number. | getWorkExtension(): ?string | setWorkExtension(?string workExtension): void |
| `workPhone` | `?string` | Optional | The client’s work phone number. | getWorkPhone(): ?string | setWorkPhone(?string workPhone): void |
| `yellowAlert` | `?string` | Optional | Contains any yellow alert information entered by the business owner for the client. | getYellowAlert(): ?string | setYellowAlert(?string yellowAlert): void |
| `sendScheduleEmails` | `?bool` | Optional | When `true`, indicates that the client opts to receive schedule emails.<br>Default : **false** | getSendScheduleEmails(): ?bool | setSendScheduleEmails(?bool sendScheduleEmails): void |
| `sendAccountEmails` | `?bool` | Optional | When `true`, indicates that the client opts to receive account emails.<br>Default : **false** | getSendAccountEmails(): ?bool | setSendAccountEmails(?bool sendAccountEmails): void |
| `sendPromotionalEmails` | `?bool` | Optional | When `true`, indicates that the client opts to receive promotional emails.<br>Default : **false** | getSendPromotionalEmails(): ?bool | setSendPromotionalEmails(?bool sendPromotionalEmails): void |
| `sendScheduleTexts` | `?bool` | Optional | When `true`, indicates that the client opts to receive schedule texts. | getSendScheduleTexts(): ?bool | setSendScheduleTexts(?bool sendScheduleTexts): void |
| `sendAccountTexts` | `?bool` | Optional | When `true`, indicates that the client opts to receive account texts. | getSendAccountTexts(): ?bool | setSendAccountTexts(?bool sendAccountTexts): void |
| `sendPromotionalTexts` | `?bool` | Optional | When `true`, indicates that the client opts to receive promotional texts. | getSendPromotionalTexts(): ?bool | setSendPromotionalTexts(?bool sendPromotionalTexts): void |
| `lockerNumber` | `?string` | Optional | The clients locker number. | getLockerNumber(): ?string | setLockerNumber(?string lockerNumber): void |
| `reactivateInactiveClient` | `?bool` | Optional | When `true`, indicates that the client opts to reactive existing Inactive client. | getReactivateInactiveClient(): ?bool | setReactivateInactiveClient(?bool reactivateInactiveClient): void |

## Example (as JSON)

```json
{
  "AccountBalance": null,
  "Action": null,
  "Active": null,
  "AddressLine1": null,
  "AddressLine2": null,
  "ApptGenderPrefMale": null,
  "BirthDate": null,
  "City": null,
  "ClientCreditCard": null,
  "ClientIndexes": null,
  "ClientRelationships": null,
  "Country": null,
  "CreationDate": null,
  "CustomClientFields": null,
  "Email": null,
  "EmergencyContactInfoEmail": null,
  "EmergencyContactInfoName": null,
  "EmergencyContactInfoPhone": null,
  "EmergencyContactInfoRelationship": null,
  "FirstAppointmentDate": null,
  "FirstName": "FirstName4",
  "Gender": null,
  "HomeLocation": null,
  "HomePhone": null,
  "IsCompany": null,
  "IsProspect": null,
  "LastFormulaNotes": null,
  "LastModifiedDateTime": null,
  "LastName": "LastName4",
  "Liability": null,
  "LiabilityRelease": null,
  "MembershipIcon": null,
  "MiddleName": null,
  "MobilePhone": null,
  "MobileProvider": null,
  "NewId": null,
  "Notes": null,
  "PhotoUrl": null,
  "PostalCode": null,
  "ProspectStage": null,
  "RedAlert": null,
  "ReferredBy": null,
  "SalesReps": null,
  "SiteId": null,
  "State": null,
  "Status": null,
  "Test": null,
  "UniqueId": null,
  "WorkExtension": null,
  "WorkPhone": null,
  "YellowAlert": null,
  "SendScheduleEmails": null,
  "SendAccountEmails": null,
  "SendPromotionalEmails": null,
  "SendScheduleTexts": null,
  "SendAccountTexts": null,
  "SendPromotionalTexts": null,
  "LockerNumber": null,
  "ReactivateInactiveClient": null
}
```

