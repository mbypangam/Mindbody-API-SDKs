# Pick a Spot

```php
$pickASpotController = $client->getPickASpotController();
```

## Class Name

`PickASpotController`

## Methods

* [Get Class List](../../doc/controllers/pick-a-spot.md#get-class-list)
* [Get Class](../../doc/controllers/pick-a-spot.md#get-class)
* [Get Reservation](../../doc/controllers/pick-a-spot.md#get-reservation)
* [Update Reservation](../../doc/controllers/pick-a-spot.md#update-reservation)
* [Create Reservation](../../doc/controllers/pick-a-spot.md#create-reservation)
* [Delete Reservation](../../doc/controllers/pick-a-spot.md#delete-reservation)


# Get Class List

A user token is required for this endpoint.

```php
function getClassList(
    string $version,
    int $pageNumber,
    int $pageSize,
    string $siteId,
    ?string $authorization = null
): GetPickASpotClassResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pageNumber` | `int` | Query, Required | Page number. |
| `pageSize` | `int` | Query, Required | Page size |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetPickASpotClassResponse`](../../doc/models/get-pick-a-spot-class-response.md)

## Example Usage

```php
$version = '6';
$pageNumber = 110;
$pageSize = 118;
$siteId = '-99';

$result = $pickASpotController->getClassList($version, $pageNumber, $pageSize, $siteId);
```


# Get Class

A user token is required for this endpoint.

```php
function getClass(
    string $version,
    string $classId,
    int $pageNumber,
    int $pageSize,
    string $siteId,
    ?string $authorization = null
): GetPickASpotClassResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `classId` | `string` | Template, Required | - |
| `pageNumber` | `int` | Query, Required | Page number. |
| `pageSize` | `int` | Query, Required | Page size |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetPickASpotClassResponse`](../../doc/models/get-pick-a-spot-class-response.md)

## Example Usage

```php
$version = '6';
$classId = 'classId0';
$pageNumber = 110;
$pageSize = 118;
$siteId = '-99';

$result = $pickASpotController->getClass($version, $classId, $pageNumber, $pageSize, $siteId);
```


# Get Reservation

A user token is required for this endpoint.

```php
function getReservation(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): GetReservationResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetReservationResponse`](../../doc/models/get-reservation-response.md)

## Example Usage

```php
$version = '6';
$pathInfo = 'pathInfo8';
$siteId = '-99';

$result = $pickASpotController->getReservation($version, $pathInfo, $siteId);
```


# Update Reservation

A user token is required for this endpoint.

```php
function updateReservation(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): UpdateReservationResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateReservationResponse`](../../doc/models/update-reservation-response.md)

## Example Usage

```php
$version = '6';
$pathInfo = 'pathInfo8';
$siteId = '-99';

$result = $pickASpotController->updateReservation($version, $pathInfo, $siteId);
```


# Create Reservation

A user token is required for this endpoint.

```php
function createReservation(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): CreateReservationResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`CreateReservationResponse`](../../doc/models/create-reservation-response.md)

## Example Usage

```php
$version = '6';
$pathInfo = 'pathInfo8';
$siteId = '-99';

$result = $pickASpotController->createReservation($version, $pathInfo, $siteId);
```


# Delete Reservation

A user token is required for this endpoint.

```php
function deleteReservation(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): DeleteReservationResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`DeleteReservationResponse`](../../doc/models/delete-reservation-response.md)

## Example Usage

```php
$version = '6';
$pathInfo = 'pathInfo8';
$siteId = '-99';

$result = $pickASpotController->deleteReservation($version, $pathInfo, $siteId);
```

