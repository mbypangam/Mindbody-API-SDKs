# Pick a Spot

```php
$pickASpotController = $client->getPickASpotController();
```

## Class Name

`PickASpotController`

## Methods

* [Pick a Spot Class List](../../doc/controllers/pick-a-spot.md#pick-a-spot-class-list)
* [Pick a Spot Class](../../doc/controllers/pick-a-spot.md#pick-a-spot-class)
* [Pick a Spot Reservation Get](../../doc/controllers/pick-a-spot.md#pick-a-spot-reservation-get)
* [To Update a Class](../../doc/controllers/pick-a-spot.md#to-update-a-class)
* [Pick a Spot Reservation Post](../../doc/controllers/pick-a-spot.md#pick-a-spot-reservation-post)
* [Pick a Spot Reservation Delete](../../doc/controllers/pick-a-spot.md#pick-a-spot-reservation-delete)


# Pick a Spot Class List

A user token is required for this endpoint.

```php
function pickASpotClassList(string $version, string $siteId, ?string $authorization = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $pickASpotController->pickASpotClassList($version, $siteId);
```


# Pick a Spot Class

A user token is required for this endpoint.

```php
function pickASpotClass(string $version, string $classId, string $siteId, ?string $authorization = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `classId` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$classId = 'classId0';
$siteId = '-99';

$result = $pickASpotController->pickASpotClass($version, $classId, $siteId);
```


# Pick a Spot Reservation Get

A user token is required for this endpoint.

```php
function pickASpotReservationGet(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$pathInfo = 'pathInfo8';
$siteId = '-99';

$result = $pickASpotController->pickASpotReservationGet($version, $pathInfo, $siteId);
```


# To Update a Class

A user token is required for this endpoint.

```php
function toUpdateAClass(string $version, string $pathInfo, string $siteId, ?string $authorization = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$pathInfo = 'pathInfo8';
$siteId = '-99';

$result = $pickASpotController->toUpdateAClass($version, $pathInfo, $siteId);
```


# Pick a Spot Reservation Post

A user token is required for this endpoint.

```php
function pickASpotReservationPost(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$pathInfo = 'pathInfo8';
$siteId = '-99';

$result = $pickASpotController->pickASpotReservationPost($version, $pathInfo, $siteId);
```


# Pick a Spot Reservation Delete

A user token is required for this endpoint.

```php
function pickASpotReservationDelete(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$pathInfo = 'pathInfo8';
$siteId = '-99';

$result = $pickASpotController->pickASpotReservationDelete($version, $pathInfo, $siteId);
```

