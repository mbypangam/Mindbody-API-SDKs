# Cross Site

```php
$crossSiteController = $client->getCrossSiteController();
```

## Class Name

`CrossSiteController`


# Copy Credit Card

Copies the credit card information from one client to another, regardless of site.
The source and target clients must have the same email address.

:information_source: **Note** This endpoint does not require authentication.

```php
function copyCreditCard(
    string $version,
    CopyCreditCardRequest $request,
    string $siteId,
    ?string $authorization = null
): CopyCreditCardResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`CopyCreditCardRequest`](../../doc/models/copy-credit-card-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`CopyCreditCardResponse`](../../doc/models/copy-credit-card-response.md)

## Example Usage

```php
$version = '6';

$request = CopyCreditCardRequestBuilder::init()
    ->sourceSiteId(42)
    ->sourceClientId('SourceClientId8')
    ->targetSiteId(26)
    ->targetClientId('TargetClientId8')
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $crossSiteController->copyCreditCard(
    $version,
    $request,
    $siteId,
    $authorization
);
```

