# Site

```php
$siteController = $client->getSiteController();
```

## Class Name

`SiteController`

## Methods

* [Get Activation Code](../../doc/controllers/site.md#get-activation-code)
* [Get Categories](../../doc/controllers/site.md#get-categories)
* [Get Genders](../../doc/controllers/site.md#get-genders)
* [Get Locations](../../doc/controllers/site.md#get-locations)
* [Get Memberships](../../doc/controllers/site.md#get-memberships)
* [Get Mobile Providers](../../doc/controllers/site.md#get-mobile-providers)
* [Get Payment Types](../../doc/controllers/site.md#get-payment-types)
* [Get Programs](../../doc/controllers/site.md#get-programs)
* [Get Promo Codes](../../doc/controllers/site.md#get-promo-codes)
* [Get Prospect Stages](../../doc/controllers/site.md#get-prospect-stages)
* [Get Relationships](../../doc/controllers/site.md#get-relationships)
* [Get Resources](../../doc/controllers/site.md#get-resources)
* [Get Session Types](../../doc/controllers/site.md#get-session-types)
* [Get Sites](../../doc/controllers/site.md#get-sites)
* [Add Promo Code](../../doc/controllers/site.md#add-promo-code)


# Get Activation Code

Before you can use this endpoint, MINDBODY must approve your developer account for live access. If you have finished testing in the sandbox and are ready to begin working with MINDBODY customers, log into your account and request to go live.

See [Accessing Business Data From MINDBODY](https://developers.mindbodyonline.com/PublicDocumentation/V6#accessing-business-data) for more information about the activation code and how to use it.

Once you are approved, this endpoint returns an activation code.This endpoint supports only one site per call.

```php
function getActivationCode(string $version, ?string $authorization = null): GetActivationCodeResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetActivationCodeResponse`](../../doc/models/get-activation-code-response.md)

## Example Usage

```php
$version = '6';

$result = $siteController->getActivationCode($version);
```


# Get Categories

Gets the categories.

```php
function getCategories(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActive = null,
    ?array $requestCategoryIds = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestService = null,
    ?array $requestSubCategoryIds = null
): GetCategoriesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains categories which are activated.<br>When `false`, only deactivated categories are returned.<br>Default: **All Categories** |
| `requestCategoryIds` | `?(int[])` | Query, Optional | When included, the response only contains details about the specified category Ids. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestService` | `?bool` | Query, Optional | When `true`, the response only contains details about Revenue Categories.<br>When `false`, only Product Revenue Categories are returned.<br>Default: **All Categories** |
| `requestSubCategoryIds` | `?(int[])` | Query, Optional | When included, the response only contains details about the specified subcategory Ids. |

## Response Type

[`GetCategoriesResponse`](../../doc/models/get-categories-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $siteController->getCategories($version, $siteId);
```


# Get Genders

The endpoint returns a list of configured client gender options for a site. Custom gender options are assignable to client genders only. Currently, custom values returned from this endpoint cannot be used as input for other endpoints to specify the genders of staff or client preferences.

```php
function getGenders(string $version, string $siteId, ?string $authorization = null): GetGendersResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetGendersResponse`](../../doc/models/get-genders-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $siteController->getGenders($version, $siteId);
```


# Get Locations

Get locations for a site.

```php
function getLocations(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): GetLocationsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`GetLocationsResponse`](../../doc/models/get-locations-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $siteController->getLocations($version, $siteId);
```


# Get Memberships

Get the memberships at a site.

```php
function getMemberships(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestMembershipIds = null
): GetMembershipsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestMembershipIds` | `?(int[])` | Query, Optional | The requested membership IDs.<br /><br>Default: **all** IDs that the authenticated user’s access level allows. |

## Response Type

[`GetMembershipsResponse`](../../doc/models/get-memberships-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $siteController->getMemberships($version, $siteId);
```


# Get Mobile Providers

Get the list of mobile providers that are supported by the business.

```php
function getMobileProviders(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActive = null
): GetMobileProvidersResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains mobile providers which are activated.<br>When `false`, only deactivated mobile providers are returned.<br>Default: **All Mobile Providers** |

## Response Type

[`GetMobileProvidersResponse`](../../doc/models/get-mobile-providers-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $siteController->getMobileProviders($version, $siteId);
```


# Get Payment Types

Get payment types for a site.

```php
function getPaymentTypes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActive = null
): GetPaymentTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains payment types which are activated.<br>When `false`, only deactivated payment types are returned.<br>Default: **All Payment Types** |

## Response Type

[`GetPaymentTypesResponse`](../../doc/models/get-payment-types-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $siteController->getPaymentTypes($version, $siteId);
```


# Get Programs

Get service categories offered at a site.

```php
function getPrograms(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestOnlineOnly = null,
    ?array $requestProgramIds = null,
    ?string $requestScheduleType = null
): GetProgramsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `?bool` | Query, Optional | If `true`, filters results to show only those programs that are shown online.<br /><br>If `false`, all programs are returned.<br /><br>Default: **false** |
| `requestProgramIds` | `?(int[])` | Query, Optional | Program Ids to filter for |
| `requestScheduleType` | [`?string (RequestScheduleTypeEnum)`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | A schedule type used to filter the returned results. Possible values are:<br><br>* All<br>* Class<br>* Enrollment<br>* Appointment<br>* Resource<br>* Media<br>* Arrival |

## Response Type

[`GetProgramsResponse`](../../doc/models/get-programs-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $siteController->getPrograms($version, $siteId);
```


# Get Promo Codes

Gets a list of promocodes at the specified business. This endpoint requires staff user credentials.
This staff member should have enabled the Set up promotions / **Semester discounts** staff permission.

```php
function getPromoCodes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActiveOnly = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestOnlineOnly = null,
    ?\DateTime $requestStartDate = null
): GetPromoCodesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActiveOnly` | `?bool` | Query, Optional | If true, filters results to show only promocodes that are active. If **false**, all promocodes are returned.<br>Default: **true** |
| `requestEndDate` | `?\DateTime` | Query, Optional | Filters results to promocodes that were activated before this date. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `?bool` | Query, Optional | If `true`, filters results to show only promocodes that can be used for online sale.<br>If `false`, all promocodes are returned.<br>Default: **false** |
| `requestStartDate` | `?\DateTime` | Query, Optional | Filters results to promocodes that were activated after this date. |

## Response Type

[`GetPromoCodesResponse`](../../doc/models/get-promo-codes-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $siteController->getPromoCodes($version, $siteId);
```


# Get Prospect Stages

Get the list of prospect stages that represent the prospect stage options for prospective clients.

```php
function getProspectStages(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActive = null
): GetProspectStagesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains prospect stages which are activated.<br>When `false`, only deactivated prospect stages are returned.<br>Default: **All Prospect Stages** |

## Response Type

[`GetProspectStagesResponse`](../../doc/models/get-prospect-stages-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $siteController->getProspectStages($version, $siteId);
```


# Get Relationships

This endpoint retrieves the business site relationships.

```php
function getRelationships(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActive = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): GetRelationshipsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `?bool` | Query, Optional | When `true`, the response only contains relationships which are activated.<br>When `false`, only deactivated relationships are returned.<br>Default: **All Relationships** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`GetRelationshipsResponse`](../../doc/models/get-relationships-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $siteController->getRelationships($version, $siteId);
```


# Get Resources

Get resources used at a site.

```php
function getResources(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDateTime = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?array $requestSessionTypeIds = null,
    ?\DateTime $requestStartDateTime = null
): GetResourcesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDateTime` | `?\DateTime` | Query, Optional | The time the resource ends. This parameter is ignored if `EndDateTime` or `LocationID` is not set. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | The location of the resource. This parameter is ignored if `EndDateTime` or `LocationID` is not set.<br /><br>Default: **all** |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSessionTypeIds` | `?(int[])` | Query, Optional | List of session type IDs.<br /><br>Default: **all** |
| `requestStartDateTime` | `?\DateTime` | Query, Optional | The time the resource starts. This parameter is ignored if `EndDateTime` or `LocationID` is not set. |

## Response Type

[`GetResourcesResponse`](../../doc/models/get-resources-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $siteController->getResources($version, $siteId);
```


# Get Session Types

Get the session types used at a site.

```php
function getSessionTypes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestOnlineOnly = null,
    ?array $requestProgramIDs = null
): GetSessionTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `?bool` | Query, Optional | When `true`, indicates that only the session types that can be booked online should be returned.<br /><br>Default: **false** |
| `requestProgramIDs` | `?(int[])` | Query, Optional | Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return. |

## Response Type

[`GetSessionTypesResponse`](../../doc/models/get-session-types-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $siteController->getSessionTypes($version, $siteId);
```


# Get Sites

Gets a list of sites that the developer has permission to view.

* Passing in no `SiteIds` returns all sites that the developer has access to.
* Passing in one `SiteIds` returns more detailed information about the specified site.

```php
function getSites(
    string $version,
    ?string $authorization = null,
    ?bool $requestIncludeLeadChannels = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?array $requestSiteIds = null
): GetSitesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestIncludeLeadChannels` | `?bool` | Query, Optional | This is an optional parameter to get lead channels for a Site. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSiteIds` | `?(int[])` | Query, Optional | List of the requested site IDs. When omitted, returns all sites that the source has access to. |

## Response Type

[`GetSitesResponse`](../../doc/models/get-sites-response.md)

## Example Usage

```php
$version = '6';

$result = $siteController->getSites($version);
```


# Add Promo Code

Creates a new promocode record at the specified business.
This endpoint requires staff user credentials. This staff memeber should have enabled the **Set up promotions / Semester discounts** staff permission.

```php
function addPromoCode(
    string $version,
    AddPromoCodeRequest $request,
    string $siteId,
    ?string $authorization = null
): AddPromoCodeResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddPromoCodeRequest`](../../doc/models/add-promo-code-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AddPromoCodeResponse`](../../doc/models/add-promo-code-response.md)

## Example Usage

```php
$version = '6';
$request_code = 'Code6';
$request_name = 'Name6';
$request = new Models\AddPromoCodeRequest(
    $request_code,
    $request_name
);
$siteId = '-99';

$result = $siteController->addPromoCode($version, $request, $siteId);
```

