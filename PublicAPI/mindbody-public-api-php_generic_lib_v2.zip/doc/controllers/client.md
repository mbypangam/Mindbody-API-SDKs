# Client

```php
$clientController = $client->getClientController();
```

## Class Name

`ClientController`

## Methods

* [Client Get Clients](../../doc/controllers/client.md#client-get-clients)
* [Client Get Client Duplicates](../../doc/controllers/client.md#client-get-client-duplicates)
* [Client Get Client Formula Notes](../../doc/controllers/client.md#client-get-client-formula-notes)
* [Client Delete Client Formula Note](../../doc/controllers/client.md#client-delete-client-formula-note)
* [Client Add Formula Note](../../doc/controllers/client.md#client-add-formula-note)
* [Client Upload Client Document](../../doc/controllers/client.md#client-upload-client-document)
* [Client Upload Client Photo](../../doc/controllers/client.md#client-upload-client-photo)
* [Client Get Client Contracts](../../doc/controllers/client.md#client-get-client-contracts)
* [Client Get Client Services](../../doc/controllers/client.md#client-get-client-services)
* [Client Get Client Visits](../../doc/controllers/client.md#client-get-client-visits)
* [Client Get Client Schedule](../../doc/controllers/client.md#client-get-client-schedule)
* [Client Get Active Client Memberships](../../doc/controllers/client.md#client-get-active-client-memberships)
* [Client Get Required Client Fields](../../doc/controllers/client.md#client-get-required-client-fields)
* [Client Get Client Referral Types](../../doc/controllers/client.md#client-get-client-referral-types)
* [Client Get Client Account Balances](../../doc/controllers/client.md#client-get-client-account-balances)
* [Client Get Client Purchases](../../doc/controllers/client.md#client-get-client-purchases)
* [Client Get Client Indexes](../../doc/controllers/client.md#client-get-client-indexes)
* [Client Get Custom Client Fields](../../doc/controllers/client.md#client-get-custom-client-fields)
* [Client Add Contact Log](../../doc/controllers/client.md#client-add-contact-log)
* [Client Update Contact Log](../../doc/controllers/client.md#client-update-contact-log)
* [Client Get Cross Regional Client Associations](../../doc/controllers/client.md#client-get-cross-regional-client-associations)
* [Client Add Client](../../doc/controllers/client.md#client-add-client)
* [Client Update Client](../../doc/controllers/client.md#client-update-client)
* [Client Update Client Visit](../../doc/controllers/client.md#client-update-client-visit)
* [Client Add Arrival](../../doc/controllers/client.md#client-add-arrival)
* [Client Send Password Reset Email](../../doc/controllers/client.md#client-send-password-reset-email)
* [Client Get Contact Logs](../../doc/controllers/client.md#client-get-contact-logs)
* [Client Update Client Service](../../doc/controllers/client.md#client-update-client-service)
* [Client Get Direct Debit Info](../../doc/controllers/client.md#client-get-direct-debit-info)
* [Client Delete Direct Debit Info](../../doc/controllers/client.md#client-delete-direct-debit-info)
* [Client Add Client Direct Debit Info](../../doc/controllers/client.md#client-add-client-direct-debit-info)
* [Client Get Client Rewards](../../doc/controllers/client.md#client-get-client-rewards)
* [Client Update Client Rewards](../../doc/controllers/client.md#client-update-client-rewards)
* [Client Get Client Complete Info](../../doc/controllers/client.md#client-get-client-complete-info)
* [Client Get Contact Log Types](../../doc/controllers/client.md#client-get-contact-log-types)
* [Client Delete Contact Log](../../doc/controllers/client.md#client-delete-contact-log)
* [Client Send Auto Email](../../doc/controllers/client.md#client-send-auto-email)
* [Client Get Active Clients Memberships](../../doc/controllers/client.md#client-get-active-clients-memberships)
* [Client Terminate Contract](../../doc/controllers/client.md#client-terminate-contract)
* [Client Update Client Contract Autopays](../../doc/controllers/client.md#client-update-client-contract-autopays)
* [Client Suspend Contract](../../doc/controllers/client.md#client-suspend-contract)
* [Client Merge Client](../../doc/controllers/client.md#client-merge-client)


# Client Get Clients

This endpoint requires staff user credentials. This endpoint supports pagination. See Pagination for a description of the Pagination information.

```php
function clientGetClients(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestClientIDs = null,
    ?bool $requestIncludeInactive = null,
    ?bool $requestIsProspect = null,
    ?\DateTime $requestLastModifiedDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?string $requestSearchText = null,
    ?array $requestUniqueIds = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientIDs` | `?(string[])` | Query, Optional | The requested client IDs.<br>Default: **all IDs** that the authenticated user’s access level allows.<br /><br>Note: You can fetch information for maximum 20 clients at once. |
| `requestIncludeInactive` | `?bool` | Query, Optional | When `true`, indicates the results to include active and inactive clients.<br /><br>When `false`, indicates that only those clients who are marked as active should be returned.<br>Default: **false** |
| `requestIsProspect` | `?bool` | Query, Optional | When `true`, filters the results to include only those clients marked as prospects for the business.<br /><br>When `false`, indicates that only those clients who are not marked prospects should be returned. |
| `requestLastModifiedDate` | `?\DateTime` | Query, Optional | Filters the results to include only the clients that have been modified on or after this date. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSearchText` | `?string` | Query, Optional | Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided. |
| `requestUniqueIds` | `?(int[])` | Query, Optional | Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.<br>Default: **all UniqueIDs** that the authenticated user’s access level allows. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-clients-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $clientController->clientGetClients($version, $siteId);
```


# Client Get Client Duplicates

This endpoint gets client records that would be considered duplicates based on case-insensitive matching of the client’s first name, last name, and email. For there to be results, all three parameters must match a client record. This endpoint requires staff user credentials.

An empty `ClientDuplicates` object in the response from this endpoint indicates that there were no client records found that match the first name, last name, and email fields passed in.

If one client record is returned, it is not a duplicate itself, but no other client record can be created or updated that would match this client’s first name, last name, and email combination.

If more than one client record is returned, these clients are duplicates of each other.We recommend discussing with the business how they would like to resolve duplicate records in the event the response contains more than one client record.Businesses can use the Merge Duplicate Clients tool in the Core Business Mode software to resolve the duplicate client records.

```php
function clientGetClientDuplicates(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?string $requestEmail = null,
    ?string $requestFirstName = null,
    ?string $requestLastName = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEmail` | `?string` | Query, Optional | The client email to match on when searching for duplicates. |
| `requestFirstName` | `?string` | Query, Optional | The client first name to match on when searching for duplicates. |
| `requestLastName` | `?string` | Query, Optional | The client last name to match on when searching for duplicates. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-duplicates-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $clientController->clientGetClientDuplicates($version, $siteId);
```


# Client Get Client Formula Notes

***QueryParams***: Enables to retrieve cross regional formula notes for a client, or for a specific appointment. The two parameters are optional, however at least one must be provided. This endpoint supports pagination.

```php
function clientGetClientFormulaNotes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestAppointmentId = null,
    ?string $requestClientId = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentId` | `?int` | Query, Optional | The appointment ID of an appointment in the studio specified in the header of the request. |
| `requestClientId` | `?string` | Query, Optional | The client ID of the client whose formula notes are being requested. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-formula-notes-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $clientController->clientGetClientFormulaNotes($version, $siteId);
```


# Client Delete Client Formula Note

This endpoint deletes an existing formula note. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.

```php
function clientDeleteClientFormulaNote(
    string $version,
    string $requestClientId,
    int $requestFormulaNoteId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The client ID of the client whose formula note needs to be deleted. |
| `requestFormulaNoteId` | `int` | Query, Required | The formula note ID for the note to be deleted. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

`void`

## Example Usage

```php
$version = '6';
$requestClientId = 'request.clientId2';
$requestFormulaNoteId = 72;
$siteId = '-99';

$clientController->clientDeleteClientFormulaNote($version, $requestClientId, $requestFormulaNoteId, $siteId);
```


# Client Add Formula Note

This endpoint adds a formula note for a specified client or specified client appointment. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.

```php
function clientAddFormulaNote(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-formula-note-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-formula-note-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_note = 'Note6';
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerAddFormulaNoteRequest(
    $request_clientId,
    $request_note
);
$siteId = '-99';

$result = $clientController->clientAddFormulaNote($version, $request, $siteId);
```


# Client Upload Client Document

Uploads a document file for a specific client. Returns a string representation of the image byte array. The maximum size file that can be uploaded is **4MB**.

```php
function clientUploadClientDocument(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-document-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-document-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_file_fileName = 'FileName2';
$request_file_mediaType = 'MediaType2';
$request_file_buffer = 'Buffer4';
$request_file = new Models\MindbodyPublicApiDtoModelsV6ClientDocument(
    $request_file_fileName,
    $request_file_mediaType,
    $request_file_buffer
);
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentRequest(
    $request_clientId,
    $request_file
);
$siteId = '-99';

$result = $clientController->clientUploadClientDocument($version, $request, $siteId);
```


# Client Upload Client Photo

Uploads a client’s profile photo. The maximum file size is 4 MB and acceptable file types are:

* bmp
* jpeg
* gif
* tiff
* png

```php
function clientUploadClientPhoto(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-photo-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-upload-client-photo-response.md)

## Example Usage

```php
$version = '6';
$request_bytes = 'Bytes6';
$request_clientId = 'ClientId0';
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest(
    $request_bytes,
    $request_clientId
);
$siteId = '-99';

$result = $clientController->clientUploadClientPhoto($version, $request, $siteId);
```


# Client Get Client Contracts

Get contracts that a client has purchased.

```php
function clientGetClientContracts(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?bool $requestCrossRegionalLookup = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | Determines how many sites are skipped over when retrieving a client’s cross regional contracts. Used when a client ID is linked to more than ten sites in an organization. Only a maximum of ten site databases are queried when this call is made and `CrossRegionalLookup` is set to `true`. To change which sites are queried, change this offset value.<br>Default: **0** |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | When `true`, indicates that the requesting client’s cross regional contracts are returned, if any.<br /><br>When `false`, indicates that cross regional contracts are not returned. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientContractsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-contracts-response.md)

## Example Usage

```php
$version = '6';
$requestClientId = 'request.clientId2';
$siteId = '-99';

$result = $clientController->clientGetClientContracts($version, $requestClientId, $siteId);
```


# Client Get Client Services

Get pricing options that a client has purchased.

```php
function clientGetClientServices(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClassId = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?bool $requestCrossRegionalLookup = null,
    ?\DateTime $requestEndDate = null,
    ?bool $requestIgnoreCrossRegionalSiteLimit = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?int $requestSessionTypeId = null,
    ?bool $requestShowActiveOnly = null,
    ?\DateTime $requestStartDate = null,
    ?int $requestVisitCount = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientServicesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client to query. The results are a list of pricing options that the client has purchased. Note that “service” and “pricing option” are synonymous in this section of the documentation. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassId` | `?int` | Query, Optional | Filters results to only those pricing options that can be used to pay for this class. |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestEndDate` | `?\DateTime` | Query, Optional | Filters results to pricing options that are valid on or before this date.<br>Default: **today’s date** |
| `requestIgnoreCrossRegionalSiteLimit` | `?bool` | Query, Optional | Used to specify if the number of cross regional sites used to search for client’s pricing options should be ignored.<br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | Filters results to pricing options that can be used at the listed location IDs. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | Filters results to pricing options that belong to one of the given program IDs. |
| `requestSessionTypeId` | `?int` | Query, Optional | Filters results to pricing options that will pay for the given session type ID. Use this to find pricing options that will pay for a specific appointment type. |
| `requestShowActiveOnly` | `?bool` | Query, Optional | When `true`, includes active services only.<br>Default: **false** |
| `requestStartDate` | `?\DateTime` | Query, Optional | Filters results to pricing options that are valid on or after this date.<br>Default: **today’s date** |
| `requestVisitCount` | `?int` | Query, Optional | A filter on the minimum number of visits a service can pay for. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientServicesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-services-response.md)

## Example Usage

```php
$version = '6';
$requestClientId = 'request.clientId2';
$siteId = '-99';

$result = $clientController->clientGetClientServices($version, $requestClientId, $siteId);
```


# Client Get Client Visits

Gets the Client Visits for a specific client.

```php
function clientGetClientVisits(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?bool $requestCrossRegionalLookup = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?\DateTime $requestStartDate = null,
    ?bool $requestUnpaidsOnly = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientVisitsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the requested client. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br /><br>When `false`, indicates that only visits at the current site are returned. |
| `requestEndDate` | `?\DateTime` | Query, Optional | The date past which class visits are not returned.<br>Default: **today’s date** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The date before which class visits are not returned.<br>Default: **the end date** |
| `requestUnpaidsOnly` | `?bool` | Query, Optional | When `true`, indicates that only visits that have not been paid for are returned.<br /><br>When `false`, indicates that all visits are returned, regardless of whether they have been paid for.<br /><br>Default: **false** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientVisitsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-visits-response.md)

## Example Usage

```php
$version = '6';
$requestClientId = 'request.clientId2';
$siteId = '-99';

$result = $clientController->clientGetClientVisits($version, $requestClientId, $siteId);
```


# Client Get Client Schedule

This endpoint can be utilized to retrieve scheduled visits which is associated with the requested client.

```php
function clientGetClientSchedule(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?bool $requestCrossRegionalLookup = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?\DateTime $requestStartDate = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the requested client. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br>When `false`, indicates that only visits at the current site are returned. |
| `requestEndDate` | `?\DateTime` | Query, Optional | The date past which class visits are not returned.<br>Default is today’s date |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The date before which class visits are not returned.<br>Default is the end date |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientScheduleResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-schedule-response.md)

## Example Usage

```php
$version = '6';
$requestClientId = 'request.clientId2';
$siteId = '-99';

$result = $clientController->clientGetClientSchedule($version, $requestClientId, $siteId);
```


# Client Get Active Client Memberships

Please note that client memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.

```php
function clientGetActiveClientMemberships(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?bool $requestCrossRegionalLookup = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client for whom memberships are returned. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientMembershipsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-active-client-memberships-response.md)

## Example Usage

```php
$version = '6';
$requestClientId = 'request.clientId2';
$siteId = '-99';

$result = $clientController->clientGetActiveClientMemberships($version, $requestClientId, $siteId);
```


# Client Get Required Client Fields

Gets the list of fields that a new client has to fill out in business mode, specifically for the sign-up process. `AddClient` and `UpdateClient` validate against these fields.

This endpoint has no query parameters.

```php
function clientGetRequiredClientFields(
    string $version,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-required-client-fields-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $clientController->clientGetRequiredClientFields($version, $siteId);
```


# Client Get Client Referral Types

Gets a list of referral types. Referral types are options that new clients can choose to identify how they learned about the business. Referral types are typically used for the sign-up process.

```php
function clientGetClientReferralTypes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestIncludeInactive = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestIncludeInactive` | `?bool` | Query, Optional | When `true`, filters the results to include subtypes and inactive referral types.<br /><br>When `false`, includes no subtypes and only active types.<br>Default:**false** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-referral-types-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $clientController->clientGetClientReferralTypes($version, $siteId);
```


# Client Get Client Account Balances

Get account balance information for one or more client(s).

```php
function clientGetClientAccountBalances(
    string $version,
    array $requestClientIds,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestBalanceDate = null,
    ?int $requestClassId = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientIds` | `string[]` | Query, Required | The list of clients IDs for which you want account balances. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestBalanceDate` | `?\DateTime` | Query, Optional | The date you want a balance relative to.<br>Default: **the current date** |
| `requestClassId` | `?int` | Query, Optional | The class ID of the event for which you want a balance. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientAccountBalancesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-account-balances-response.md)

## Example Usage

```php
$version = '6';
$requestClientIds = ['request.clientIds9', 'request.clientIds0', 'request.clientIds1'];
$siteId = '-99';

$result = $clientController->clientGetClientAccountBalances($version, $requestClientIds, $siteId);
```


# Client Get Client Purchases

Gets a list of purchases made by a specific client.

```php
function clientGetClientPurchases(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?int $requestSaleId = null,
    ?\DateTime $requestStartDate = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client you are querying for purchases. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `?\DateTime` | Query, Optional | Filters results to purchases made before this timestamp.<br /><br>Default: **end of today** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSaleId` | `?int` | Query, Optional | Filters results to the single record associated with this ID. |
| `requestStartDate` | `?\DateTime` | Query, Optional | Filters results to purchases made on or after this timestamp.<br /><br>Default: **now** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientPurchasesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-purchases-response.md)

## Example Usage

```php
$version = '6';
$requestClientId = 'request.clientId2';
$siteId = '-99';

$result = $clientController->clientGetClientPurchases($version, $requestClientId, $siteId);
```


# Client Get Client Indexes

Client indexes are used to analyze client demographics. A business owner can set up different categories with sets of values which they can assign to each client. Client indexes are used in client searches, for tagging clients so that the owner can send mass emails to similar groups, and for many reports.

For more information, see Client Indexes and [Client Index Values (video tutorial)](https://support.mindbodyonline.com/s/article/203261653-Client-indexes-and-client-index-values-video-tutorial?language=en_USclient).

```php
function clientGetClientIndexes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestRequiredOnly = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestRequiredOnly` | `?bool` | Query, Optional | When `true`, filters the results to only indexes that are required on creation.<br /><br>When `false` or omitted, returns all of the client indexes. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-indexes-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $clientController->clientGetClientIndexes($version, $siteId);
```


# Client Get Custom Client Fields

Get a site's configured custom client fields.

```php
function clientGetCustomClientFields(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-custom-client-fields-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $clientController->clientGetCustomClientFields($version, $siteId);
```


# Client Add Contact Log

Add a contact log to a client's account.

```php
function clientAddContactLog(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ContactLog
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-contact-log-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ContactLog`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_contactMethod = 'ContactMethod0';
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest(
    $request_clientId,
    $request_contactMethod
);
$siteId = '-99';

$result = $clientController->clientAddContactLog($version, $request, $siteId);
```


# Client Update Contact Log

Update a contact log on a client's account.

```php
function clientUpdateContactLog(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ContactLog
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-contact-log-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ContactLog`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log.md)

## Example Usage

```php
$version = '6';
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest();
$siteId = '-99';

$result = $clientController->clientUpdateContactLog($version, $request, $siteId);
```


# Client Get Cross Regional Client Associations

Returns a list of sites that a particular client ID (also referred to as an RSSID) or a client email address is associated with in a cross-regional organization. Either the `ClientID` or `Email` parameter is required. If both are provided, the `ClientID` is used.

Use this endpoint to retrieve information for other Public API endpoints, about the same client at multiple sites within an organization. To use this endpoint, your developer account must have been granted permission to the site’s entire organization.

Note that this endpoint does not work on the Developer Sandbox site, as it is not set up for cross-regional use cases.

```php
function clientGetCrossRegionalClientAssociations(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?string $requestClientId = null,
    ?string $requestEmail = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientId` | `?string` | Query, Optional | Looks up the cross regional associations by the client’s ID. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. |
| `requestEmail` | `?string` | Query, Optional | Looks up the cross regional associations by the client’s email address. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetCrossRegionalClientAssociationsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-cross-regional-client-associations-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $clientController->clientGetCrossRegionalClientAssociations($version, $siteId);
```


# Client Add Client

Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />
Creates a new client record at the specified business.Passing a User Token as Authorization will create a client and respect Business Mode required fields.Omitting the token will create a client and respect Consumer Mode required fi elds. To make sure you are collecting all required pieces of information, first run GetRequired ClientFields.<br />
If you have purchased an Ultimate tier then this endpoint will automatically start showing new opportunity on Sales Pipeline.

```php
function clientAddClient(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerAddClientRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClientControllerAddClientResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddClientRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-request.md) | Body, Required | The `FirstName` and `LastName` parameters are always required in this request.<br>All other parameters are optional, but note that any of the optional parameters could be required by a particular business,<br>depending on how the business has configured the site settings. If `GetRequiredClientFields` returns `EmergContact` in the list of required fields,<br>then all emergency contact parameters are required, which includes `EmergencyContactInfoEmail`, `EmergencyContactInfoName`, `EmergencyContactInfoPhone`, and `EmergencyContactInfoRelationship`. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerAddClientResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-response.md)

## Example Usage

```php
$version = '6';
$request_firstName = 'FirstName8';
$request_lastName = 'LastName8';
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerAddClientRequest(
    $request_firstName,
    $request_lastName
);
$siteId = '-99';

$result = $clientController->clientAddClient($version, $request, $siteId);
```


# Client Update Client

Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />
Updates an existing client for a specific subscriber.Passing a User Token as Authorization respects Business Mode required fields.Omitting the token respects Consumer Mode required fields.To make sure you are collecting all required pieces of information, first run GetRequiredClientFields..Use this endpoint as follows:

* If you need to update the `ReferredBy` parameter, use this endpoint after calling `GET ClientReferralTypes`.
* When updating a client’s home location, use after calling `GET Locations`.
* If you are updating a client’s stored credit card, use after calling `GET AcceptedCardTypes` so that you can make sure the card is a type that is accepted at the subscriber.<br />

If this endpoint is used on a cross-regional site, passing in a client’s RSSID and email address creates a cross-regional link. This means that the client is created in cross-regional sites where the client does not exist and `GET CrossRegionalClientAssociations` returns all appropriate cross-regional sites. When `CrossRegionalUpdate` is omitted or set to `true`, the client’s updated information is propagated to all of the region’s sites. If `CrossRegionalUpdate` is set to `false`, only the local client is updated.

Note that the following items cannot be updated for a cross-regional client:

* `ClientIndexes`
* `ClientRelationships`
* `CustomClientFields`
* `SalesReps`
* `SendAccountEmails`
* `SendAccountTexts`
* `SendPromotionalEmails`
* `SendPromotionalTexts`
* `SendScheduleEmails`
* `SendScheduleTexts`
* `Gender` (for site custom values)

Custom client Gender options can only be created with non-cross-regional requests.

If you have purchased an Ultimate tier then this endpoint will automatically start showing a new opportunity on Sales Pipeline.It will create a new opportunity if the current request modify the contact as follows::

* You need to update the `IsProspect` parameter, to `true`.<br />
* You need to update the `ProspectStage`.`Description parameter`, to `New Lead`.<br />

Updates made to any inactive clients will automatically reactivate the client unless the `Acive` property is explicitly set to `false` in the request body.

```php
function clientUpdateClient(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-response.md)

## Example Usage

```php
$version = '6';
$request_client = new Models\MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo();
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest(
    $request_client
);
$siteId = '-99';

$result = $clientController->clientUpdateClient($version, $request, $siteId);
```


# Client Update Client Visit

Updates the status of the specified visit.

```php
function clientUpdateClientVisit(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-visit-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-visit-response.md)

## Example Usage

```php
$version = '6';
$request_visitId = 92;
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest(
    $request_visitId
);
$siteId = '-99';

$result = $clientController->clientUpdateClientVisit($version, $request, $siteId);
```


# Client Add Arrival

Marks a client as arrived for a specified location. A staff user token must be included with staff assigned the LaunchSignInScreen permission.

When used on a site that is part of a region, the following additional logic will apply:

* When a client exists within the region but not at the studio where the arrival is being logged, a local client record will be automatically created.
* If the local client does not have an applicable local membership or pricing option, a membership or pricing option will be automatically used if it exists elsewhere within the region.

```php
function clientAddArrival(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-arrival-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-arrival-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_locationId = 238;
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalRequest(
    $request_clientId,
    $request_locationId
);
$siteId = '-99';

$result = $clientController->clientAddArrival($version, $request, $siteId);
```


# Client Send Password Reset Email

Send a password reset email to a client.

```php
function clientSendPasswordResetEmail(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest $request,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-send-password-reset-email-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$request_userEmail = 'UserEmail2';
$request_userFirstName = 'UserFirstName2';
$request_userLastName = 'UserLastName8';
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest(
    $request_userEmail,
    $request_userFirstName,
    $request_userLastName
);
$siteId = '-99';

$result = $clientController->clientSendPasswordResetEmail($version, $request, $siteId);
```


# Client Get Contact Logs

This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.

```php
function clientGetContactLogs(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestShowSystemGenerated = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDate = null,
    ?array $requestSubtypeIds = null,
    ?array $requestTypeIds = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client whose contact logs are being requested. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `?\DateTime` | Query, Optional | Filters the results to contact logs created before this date.<br /><br>Default: **the start date** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestShowSystemGenerated` | `?bool` | Query, Optional | When `true`, system-generated contact logs are returned in the results.<br /><br>Default: **false** |
| `requestStaffIds` | `?(int[])` | Query, Optional | Filters the results to return contact logs assigned to one or more staff IDs. |
| `requestStartDate` | `?\DateTime` | Query, Optional | Filters the results to contact logs created on or after this date.<br /><br>Default: **the current date** |
| `requestSubtypeIds` | `?(int[])` | Query, Optional | Filters the results to contact logs assigned one or more of these subtype IDs. |
| `requestTypeIds` | `?(int[])` | Query, Optional | Filters the results to contact logs assigned one or more of these type IDs. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-contact-logs-response.md)

## Example Usage

```php
$version = '6';
$requestClientId = 'request.clientId2';
$siteId = '-99';

$result = $clientController->clientGetContactLogs($version, $requestClientId, $siteId);
```


# Client Update Client Service

Updates the active date and/or expiration date of a client pricing option. This request requires staff user credentials. If the active date is modified, the expiration date is also modified accordingly. If the expiration date is modified, the active date is unchanged.

```php
function clientUpdateClientService(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-service-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-service-response.md)

## Example Usage

```php
$version = '6';
$request_serviceId = 130;
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest(
    $request_serviceId
);
$siteId = '-99';

$result = $clientController->clientUpdateClientService($version, $request, $siteId);
```


# Client Get Direct Debit Info

This endpoint returns direct debit info stored on a client's account. This endpoint requires staff user credentials.

A null response from this endpoint indicates that the client has no usable direct debit information on their account.Use the POST AddClientDirectDebitInfo endpoint to add direct debit information to a client’s account.

```php
function clientGetDirectDebitInfo(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?string $clientId = null
): MindbodyPublicApiDtoModelsV6DirectDebitInfo
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `clientId` | `?string` | Query, Optional | The ID of the client. |

## Response Type

[`MindbodyPublicApiDtoModelsV6DirectDebitInfo`](../../doc/models/mindbody-public-api-dto-models-v6-direct-debit-info.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $clientController->clientGetDirectDebitInfo($version, $siteId);
```


# Client Delete Direct Debit Info

This endpoint deletes direct debit info from a client’s account. This endpoint requires staff user credentials.

```php
function clientDeleteDirectDebitInfo(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?string $clientId = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `clientId` | `?string` | Query, Optional | The ID of the client. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $clientController->clientDeleteDirectDebitInfo($version, $siteId);
```


# Client Add Client Direct Debit Info

This endpoint adds direct debit info to a client’s account. This endpoint requires staff user credentials.

```php
function clientAddClientDirectDebitInfo(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-direct-debit-info-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-add-client-direct-debit-info-response.md)

## Example Usage

```php
$version = '6';
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerAddClientDirectDebitInfoRequest();
$siteId = '-99';

$result = $clientController->clientAddClientDirectDebitInfo($version, $request, $siteId);
```


# Client Get Client Rewards

Gets the client rewards.

```php
function clientGetClientRewards(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?\DateTime $requestStartDate = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `?\DateTime` | Query, Optional | The end date of transaction.<br>Default: **StartDate** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The start date of transaction.<br>Default: **today** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-rewards-response.md)

## Example Usage

```php
$version = '6';
$requestClientId = 'request.clientId2';
$siteId = '-99';

$result = $clientController->clientGetClientRewards($version, $requestClientId, $siteId);
```


# Client Update Client Rewards

Earns or redeems rewards points for a given client, based on site settings. Cross regional rewards are not supported at this time.

```php
function clientUpdateClientRewards(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-update-client-rewards-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-rewards-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_points = 10;
$request_action = 'Action6';
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest(
    $request_clientId,
    $request_points,
    $request_action
);
$siteId = '-99';

$result = $clientController->clientUpdateClientRewards($version, $request, $siteId);
```


# Client Get Client Complete Info

This endpoint returns complete client information along with list of purchased services, contract details, membership details and arrival programs for a specific client.

```php
function clientGetClientCompleteInfo(
    string $version,
    string $requestClientId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?bool $requestCrossRegionalLookup = null,
    ?\DateTime $requestEndDate = null,
    ?array $requestRequiredClientData = null,
    ?\DateTime $requestStartDate = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | Filters results to client with these ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | Used to retrieve a clients pricing options from multiple sites within an organization.When included and set to `true`,<br>it searches a maximum of ten sites with which this client is associated.When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated.<br>You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with.<br>Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestEndDate` | `?\DateTime` | Query, Optional | Filters results to pricing options that are valid on or before this date. |
| `requestRequiredClientData` | `?(string[])` | Query, Optional | Used to retrieve list of purchased services, contract details, membership details and arrival programs for a specific client.<br>Default `ClientServices`, `ClientContracts`, `ClientMemberships` and `ClientArrivals` will be returned when `RequiredClientDatais` not set.<br>When `RequiredClientData` is set to `Contracts` then only `ClientContracts` will be returned in the response.<br>When `RequiredClientData` is set to Services then only `ClientServices` will be returned in the response.<br>When `RequiredClientData` is set to `Memberships` then only `ClientMemberships` will be returned in the response.<br>When `RequiredClientData` is set to `ArrivalPrograms` then only `ClientArrivals` will be returned in the response. |
| `requestStartDate` | `?\DateTime` | Query, Optional | Filters results to pricing options that are valid on or after this date. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-client-complete-info-response.md)

## Example Usage

```php
$version = '6';
$requestClientId = 'request.clientId2';
$siteId = '-99';

$result = $clientController->clientGetClientCompleteInfo($version, $requestClientId, $siteId);
```


# Client Get Contact Log Types

This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.

```php
function clientGetContactLogTypes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestContactLogTypeId = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestContactLogTypeId` | `?int` | Query, Optional | The requested ContactLogType ID.<br>Default: **all** IDs that the authenticated user’s access level allows. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-contact-log-types-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $clientController->clientGetContactLogTypes($version, $siteId);
```


# Client Delete Contact Log

This endpoint deletes contactlog of client. This endpoint requires staff user credentials.

```php
function clientDeleteContactLog(
    string $version,
    string $requestClientId,
    int $requestContactLogId,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestTest = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The client ID of the client whose Contact Log is being deleted. |
| `requestContactLogId` | `int` | Query, Required | The Contact Log ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestTest` | `?bool` | Query, Optional | When `true`, indicates that this is a test request and no data is inserted into the subscriber’s database.<br>When `false`, the database is updated. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$requestClientId = 'request.clientId2';
$requestContactLogId = 90;
$siteId = '-99';

$result = $clientController->clientDeleteContactLog($version, $requestClientId, $requestContactLogId, $siteId);
```


# Client Send Auto Email

This endpoint requires staff user credentials.

```php
function clientSendAutoEmail(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest $request,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-send-auto-email-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_emailType = 'EmailType4';
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest(
    $request_clientId,
    $request_emailType
);
$siteId = '-99';

$result = $clientController->clientSendAutoEmail($version, $request, $siteId);
```


# Client Get Active Clients Memberships

The endpoint returns a list of memberships for multiple clients we pass in query parameter. Please note that clients memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.

```php
function clientGetActiveClientsMemberships(
    string $version,
    array $requestClientIds,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientAssociatedSitesOffset = null,
    ?bool $requestCrossRegionalLookup = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null
): MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientIds` | `string[]` | Query, Required | The ID of the client for whom memberships are returned. Maximum allowed : 200. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `?int` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `?bool` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerGetActiveClientsMembershipsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-get-active-clients-memberships-response.md)

## Example Usage

```php
$version = '6';
$requestClientIds = ['request.clientIds9', 'request.clientIds0', 'request.clientIds1'];
$siteId = '-99';

$result = $clientController->clientGetActiveClientsMemberships($version, $requestClientIds, $siteId);
```


# Client Terminate Contract

This endpoint terminates a client contract. This endpoint requires staff user credentials with TerminateClientContract permission.

```php
function clientTerminateContract(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-terminate-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-terminate-contract-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_clientContractId = 118;
$request_terminationDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest(
    $request_clientId,
    $request_clientContractId,
    $request_terminationDate
);
$siteId = '-99';

$result = $clientController->clientTerminateContract($version, $request, $siteId);
```


# Client Update Client Contract Autopays

```php
function clientUpdateClientContractAutopays(
    string $version,
    MindbodyPublicApiDtoModelsV6SaleControllerUpdateClientContractAutopaysRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6Contract
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6SaleControllerUpdateClientContractAutopaysRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-client-contract-autopays-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6Contract`](../../doc/models/mindbody-public-api-dto-models-v6-contract.md)

## Example Usage

```php
$version = '6';
$request = new Models\MindbodyPublicApiDtoModelsV6SaleControllerUpdateClientContractAutopaysRequest();
$siteId = '-99';

$result = $clientController->clientUpdateClientContractAutopays($version, $request, $siteId);
```


# Client Suspend Contract

Suspend client contract

```php
function clientSuspendContract(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-suspend-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-suspend-contract-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_clientContractId = 118;
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest(
    $request_clientId,
    $request_clientContractId
);
$siteId = '-99';

$result = $clientController->clientSuspendContract($version, $request, $siteId);
```


# Client Merge Client

```php
function clientMergeClient(
    string $version,
    MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest $request,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest`](../../doc/models/mindbody-public-api-dto-models-v6-client-controller-merge-clients-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$request = new Models\MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest();
$siteId = '-99';

$result = $clientController->clientMergeClient($version, $request, $siteId);
```

