# Enrollment

```php
$enrollmentController = $client->getEnrollmentController();
```

## Class Name

`EnrollmentController`

## Methods

* [Get Enrollments](../../doc/controllers/enrollment.md#get-enrollments)
* [Add Client to Enrollment](../../doc/controllers/enrollment.md#add-client-to-enrollment)
* [Add Enrollment Schedule](../../doc/controllers/enrollment.md#add-enrollment-schedule)
* [Update Enrollment Schedule](../../doc/controllers/enrollment.md#update-enrollment-schedule)


# Get Enrollments

Returns a list of enrollments. An enrollment is a service, such as a workshop or an event, that a staff member offers to multiple students, who commit to coming to all or most of the scheduled sessions. Enrollments typically run for a limited time only.

When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:

* FirstName
* LastName
* Id
* Bio
* DisplayName
* ImageUrl

```php
function getEnrollments(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestClassScheduleIds = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?array $requestSessionTypeIds = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDate = null
): GetEnrollmentsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassScheduleIds` | `?(int[])` | Query, Optional | A list of the requested class schedule IDs. If omitted, all class schedule IDs return. |
| `requestEndDate` | `?DateTime` | Query, Optional | The end of the date range. The response returns any active enrollments that occur on or before this day.<br /><br>Default: **StartDate** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | List of the IDs for the requested locations. If omitted, all location IDs return. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | List of the IDs for the requested programs. If omitted, all program IDs return. |
| `requestSessionTypeIds` | `?(int[])` | Query, Optional | List of the IDs for the requested session types. If omitted, all session types IDs return. |
| `requestStaffIds` | `?(int[])` | Query, Optional | List of the IDs for the requested staff IDs. If omitted, all staff IDs return. |
| `requestStartDate` | `?DateTime` | Query, Optional | The start of the date range. The response returns any active enrollments that occur on or after this day.<br /><br>Default: **today’s date** |

## Response Type

[`GetEnrollmentsResponse`](../../doc/models/get-enrollments-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestClassScheduleIds = [
    149,
    150,
    151
];

$requestEndDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestLimit = 62;

$requestLocationIds = [
    192
];

$requestOffset = 100;

$requestProgramIds = [
    91,
    92,
    93
];

$requestSessionTypeIds = [
    228,
    229
];

$requestStaffIds = [
    23,
    24,
    25
];

$requestStartDate = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$result = $enrollmentController->getEnrollments(
    $version,
    $siteId,
    $authorization,
    $requestClassScheduleIds,
    $requestEndDate,
    $requestLimit,
    $requestLocationIds,
    $requestOffset,
    $requestProgramIds,
    $requestSessionTypeIds,
    $requestStaffIds,
    $requestStartDate
);
```


# Add Client to Enrollment

Book a client into an enrollment.

```php
function addClientToEnrollment(
    string $version,
    AddClientToEnrollmentRequest $request,
    string $siteId,
    ?string $authorization = null
): ClassSchedule
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddClientToEnrollmentRequest`](../../doc/models/add-client-to-enrollment-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`ClassSchedule`](../../doc/models/class-schedule.md)

## Example Usage

```php
$version = '6';

$request = AddClientToEnrollmentRequestBuilder::init(
    'ClientId0',
    36
)
    ->enrollDateForward(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->enrollOpen(
        [
            DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z')
        ]
    )
    ->test(false)
    ->sendEmail(false)
    ->waitlist(false)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $enrollmentController->addClientToEnrollment(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Add Enrollment Schedule

This endpoint adds a enrollment schedule. You can require clients to sign up for the entire enrollment schedule or allow them to pick specific sessions using the AllowOpenEnrollment parameter.

```php
function addEnrollmentSchedule(
    string $version,
    AddClassEnrollmentScheduleRequest $request,
    string $siteId,
    ?string $authorization = null
): WrittenClassSchedulesInfo
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddClassEnrollmentScheduleRequest`](../../doc/models/add-class-enrollment-schedule-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`WrittenClassSchedulesInfo`](../../doc/models/written-class-schedules-info.md)

## Example Usage

```php
$version = '6';

$request = AddClassEnrollmentScheduleRequestBuilder::init()
    ->classDescriptionId(66)
    ->locationId(238)
    ->startDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->endDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->startTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $enrollmentController->addEnrollmentSchedule(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Update Enrollment Schedule

This endpoint update a enrollment schedule.

```php
function updateEnrollmentSchedule(
    string $version,
    UpdateClassEnrollmentScheduleRequest $request,
    string $siteId,
    ?string $authorization = null
): WrittenClassSchedulesInfo
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateClassEnrollmentScheduleRequest`](../../doc/models/update-class-enrollment-schedule-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`WrittenClassSchedulesInfo`](../../doc/models/written-class-schedules-info.md)

## Example Usage

```php
$version = '6';

$request = UpdateClassEnrollmentScheduleRequestBuilder::init()
    ->classId(90)
    ->classDescriptionId(66)
    ->locationId(238)
    ->startDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->endDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $enrollmentController->updateEnrollmentSchedule(
    $version,
    $request,
    $siteId,
    $authorization
);
```

