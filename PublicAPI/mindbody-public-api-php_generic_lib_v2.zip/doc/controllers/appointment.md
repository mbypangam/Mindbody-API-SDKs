# Appointment

```php
$appointmentController = $client->getAppointmentController();
```

## Class Name

`AppointmentController`

## Methods

* [Get Active Session Times](../../doc/controllers/appointment.md#get-active-session-times)
* [Get Add Ons](../../doc/controllers/appointment.md#get-add-ons)
* [Get Appointment Options](../../doc/controllers/appointment.md#get-appointment-options)
* [Get Available Dates](../../doc/controllers/appointment.md#get-available-dates)
* [Get Bookable Items](../../doc/controllers/appointment.md#get-bookable-items)
* [Get Schedule Items](../../doc/controllers/appointment.md#get-schedule-items)
* [Get Staff Appointments](../../doc/controllers/appointment.md#get-staff-appointments)
* [Get Unavailabilities](../../doc/controllers/appointment.md#get-unavailabilities)
* [Add Appointment](../../doc/controllers/appointment.md#add-appointment)
* [Add Appointment Add On](../../doc/controllers/appointment.md#add-appointment-add-on)
* [Update Availability](../../doc/controllers/appointment.md#update-availability)
* [Add Availabilities](../../doc/controllers/appointment.md#add-availabilities)
* [Update Appointment](../../doc/controllers/appointment.md#update-appointment)
* [Remove From Waitlist](../../doc/controllers/appointment.md#remove-from-waitlist)
* [Delete Availability](../../doc/controllers/appointment.md#delete-availability)
* [Delete Appointment Add On](../../doc/controllers/appointment.md#delete-appointment-add-on)


# Get Active Session Times

This is not appointment availability but rather the active business hours for studios and which increments services can be booked at. See BookableItems for appointment availability.

```php
function getActiveSessionTimes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndTime = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?string $requestScheduleType = null,
    ?array $requestSessionTypeIds = null,
    ?\DateTime $requestStartTime = null
): GetActiveSessionTimesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndTime` | `?\DateTime` | Query, Optional | Filters results to times that end on or before this time on the current date. Any date provided is ignored..<br><br />Default: **23:59:59** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestScheduleType` | [`?string (RequestScheduleTypeEnum)`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided. |
| `requestSessionTypeIds` | `?(int[])` | Query, Optional | Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided. |
| `requestStartTime` | `?\DateTime` | Query, Optional | Filters results to times that start on or after this time on the current date. Any date provided is ignored.<br><br />Default: **00:00:00** |

## Response Type

[`GetActiveSessionTimesResponse`](../../doc/models/get-active-session-times-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $appointmentController->getActiveSessionTimes($version, $siteId);
```


# Get Add Ons

Get active appointment add-ons.

```php
function getAddOns(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?int $requestStaffId = null
): GetAddOnsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffId` | `?int` | Query, Optional | Filter to add-ons only performed by this staff member. |

## Response Type

[`GetAddOnsResponse`](../../doc/models/get-add-ons-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $appointmentController->getAddOns($version, $siteId);
```


# Get Appointment Options

This endpoint has no query parameters.

```php
function getAppointmentOptions(
    string $version,
    string $siteId,
    ?string $authorization = null
): GetAppointmentOptionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetAppointmentOptionsResponse`](../../doc/models/get-appointment-options-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $appointmentController->getAppointmentOptions($version, $siteId);
```


# Get Available Dates

Returns a list of dates to narrow down staff availability when booking. Dates are those which staff are scheduled to work and do not guarantee booking availabilities. After this call is made, use GET BookableItems to retrieve availabilities for specific dates before booking.

```php
function getAvailableDates(
    string $version,
    int $requestSessionTypeId,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLocationId = null,
    ?int $requestStaffId = null,
    ?\DateTime $requestStartDate = null
): GetAvailableDatesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestSessionTypeId` | `int` | Query, Required | required requested session type ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `?\DateTime` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestLocationId` | `?int` | Query, Optional | optional requested location ID. |
| `requestStaffId` | `?int` | Query, Optional | optional requested staff ID. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today’s date** |

## Response Type

[`GetAvailableDatesResponse`](../../doc/models/get-available-dates-response.md)

## Example Usage

```php
$version = '6';
$requestSessionTypeId = 100;
$siteId = '-99';

$result = $appointmentController->getAvailableDates($version, $requestSessionTypeId, $siteId);
```


# Get Bookable Items

Returns a list of availabilities with the information needed to book appointments. Availabilities include information such as the location and its amenities, staff members, programs, and session types. Recommended to use with ActiveSessionTimes to see which increments each business allows for booking appointments.

```php
function getBookableItems(
    string $version,
    array $requestSessionTypeIds,
    string $siteId,
    ?string $authorization = null,
    ?int $requestAppointmentId = null,
    ?\DateTime $requestEndDate = null,
    ?bool $requestIgnoreDefaultSessionLength = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDate = null
): GetBookableItemsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestSessionTypeIds` | `int[]` | Query, Required | A list of the requested session type IDs. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentId` | `?int` | Query, Optional | If provided, filters out the appointment with this ID. |
| `requestEndDate` | `?\DateTime` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestIgnoreDefaultSessionLength` | `?bool` | Query, Optional | When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br /><br>When `false`, only availabilities that have the default session length return. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | A list of the requested location IDs. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `?(int[])` | Query, Optional | A list of the requested staff IDs. Omit parameter to return all staff availabilities. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The start date of the requested date range.<br><br />Default: **today’s date** |

## Response Type

[`GetBookableItemsResponse`](../../doc/models/get-bookable-items-response.md)

## Example Usage

```php
$version = '6';
$requestSessionTypeIds = [228, 229];
$siteId = '-99';

$result = $appointmentController->getBookableItems($version, $requestSessionTypeIds, $siteId);
```


# Get Schedule Items

Returns a list of schedule items, including appointments, availabilities, and unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.

```php
function getScheduleItems(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDate = null,
    ?bool $requestIgnorePrepFinishTimes = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDate = null
): GetScheduleItemsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `?\DateTime` | Query, Optional | The end date of the requested date range.<br><br />Default: **today’s date** |
| `requestIgnorePrepFinishTimes` | `?bool` | Query, Optional | When `true`, appointment preparation and finish unavailabilities are not returned.<br><br />Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | A list of requested location IDs. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `?(int[])` | Query, Optional | A list of requested staff IDs. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The start date of the requested date range.<br><br />Default: **today’s date** |

## Response Type

[`GetScheduleItemsResponse`](../../doc/models/get-schedule-items-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $appointmentController->getScheduleItems($version, $siteId);
```


# Get Staff Appointments

Returns a list of appointments by staff member.

```php
function getStaffAppointments(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestAppointmentIds = null,
    ?string $requestClientId = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDate = null
): GetStaffAppointmentsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentIds` | `?(int[])` | Query, Optional | A list of the requested appointment IDs. |
| `requestClientId` | `?string` | Query, Optional | The client ID to be returned. |
| `requestEndDate` | `?\DateTime` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | A list of the requested location IDs. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `?(int[])` | Query, Optional | List of staff IDs to be returned. Use a value of zero to return all staff appointments. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today’s date** |

## Response Type

[`GetStaffAppointmentsResponse`](../../doc/models/get-staff-appointments-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $appointmentController->getStaffAppointments($version, $siteId);
```


# Get Unavailabilities

Returns a list of unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.

```php
function getUnavailabilities(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDate = null
): GetUnavailabilitiesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `?\DateTime` | Query, Optional | The end date of the requested date range.<br><br />Default: **today’s date** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `?(int[])` | Query, Optional | A list of requested staff IDs. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The start date of the requested date range.<br><br />Default: **today’s date** |

## Response Type

[`GetUnavailabilitiesResponse`](../../doc/models/get-unavailabilities-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $appointmentController->getUnavailabilities($version, $siteId);
```


# Add Appointment

A user token is required for this endpoint. To book an appointment, you must use a location ID, staff ID, client ID, session type ID, and the StartDateTime of the appointment. You can get most of this information using GET BookableItems.

```php
function addAppointment(
    string $version,
    AddAppointmentRequest $request,
    string $siteId,
    ?string $authorization = null
): AddAppointmentResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddAppointmentRequest`](../../doc/models/add-appointment-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AddAppointmentResponse`](../../doc/models/add-appointment-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_locationId = 238;
$request_sessionTypeId = 82;
$request_staffId = 188;
$request_startDateTime = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');
$request = new Models\AddAppointmentRequest(
    $request_clientId,
    $request_locationId,
    $request_sessionTypeId,
    $request_staffId,
    $request_startDateTime
);
$siteId = '-99';

$result = $appointmentController->addAppointment($version, $request, $siteId);
```


# Add Appointment Add On

This endpoint books an add-on on top of an existing, regular appointment. To book an add-on, you must use an existing appointment ID and session type ID. You can get a session type ID using `GET AppointmentAddOns`.

```php
function addAppointmentAddOn(
    string $version,
    AddAppointmentAddOnRequest $request,
    string $siteId,
    ?string $authorization = null
): AddAppointmentAddOnResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddAppointmentAddOnRequest`](../../doc/models/add-appointment-add-on-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AddAppointmentAddOnResponse`](../../doc/models/add-appointment-add-on-response.md)

## Example Usage

```php
$version = '6';
$request = new Models\AddAppointmentAddOnRequest();
$siteId = '-99';

$result = $appointmentController->addAppointmentAddOn($version, $request, $siteId);
```


# Update Availability

To update the information for a specific availability or unavailability of the staff.<br />
Note: You must have a staff user token with the required permissions.

```php
function updateAvailability(
    string $version,
    string $siteId,
    UpdateAvailabilityRequest $updateAvailabilityRequest,
    ?string $authorization = null
): UpdateAvailabilityResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateAvailabilityRequest` | [`UpdateAvailabilityRequest`](../../doc/models/update-availability-request.md) | Body, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateAvailabilityResponse`](../../doc/models/update-availability-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';
$updateAvailabilityRequest = new Models\UpdateAvailabilityRequest();

$result = $appointmentController->updateAvailability($version, $siteId, $updateAvailabilityRequest);
```


# Add Availabilities

Add availabilities and unavailabilities for a staff member.<br />
Note: You must have a staff user token with the required permissions.

```php
function addAvailabilities(
    string $version,
    AddAvailabilitiesRequest $request,
    string $siteId,
    ?string $authorization = null
): AddAvailabilitiesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddAvailabilitiesRequest`](../../doc/models/add-availabilities-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AddAvailabilitiesResponse`](../../doc/models/add-availabilities-response.md)

## Example Usage

```php
$version = '6';
$request = new Models\AddAvailabilitiesRequest();
$siteId = '-99';

$result = $appointmentController->addAvailabilities($version, $request, $siteId);
```


# Update Appointment

To update the information for a specific appointment, you must have a staff user token with the proper permissions. Note that you can only update the appointment’s `StartDateTime`, `EndDateTime`, `StaffId`, `Notes`, and `SessionTypeId`.

```php
function updateAppointment(
    string $version,
    UpdateAppointmentRequest $request,
    string $siteId,
    ?string $authorization = null
): UpdateAppointmentResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateAppointmentRequest`](../../doc/models/update-appointment-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateAppointmentResponse`](../../doc/models/update-appointment-response.md)

## Example Usage

```php
$version = '6';
$request_appointmentId = 246;
$request = new Models\UpdateAppointmentRequest(
    $request_appointmentId
);
$siteId = '-99';

$result = $appointmentController->updateAppointment($version, $request, $siteId);
```


# Remove From Waitlist

Remove an appointment from waitlist

```php
function removeFromWaitlist(
    string $version,
    array $requestWaitlistEntryIds,
    string $siteId,
    ?string $authorization = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestWaitlistEntryIds` | `int[]` | Query, Required | A list of `WaitlistEntryIds` to remove from the waiting list. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`void`

## Example Usage

```php
$version = '6';
$requestWaitlistEntryIds = [138, 139];
$siteId = '-99';

$appointmentController->removeFromWaitlist($version, $requestWaitlistEntryIds, $siteId);
```


# Delete Availability

This endpoint deletes the availability or unavailability.
Note: You must have a staff user token with the required permissions.

```php
function deleteAvailability(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $deleteAvailabilityRequestAvailabilityId = null,
    ?bool $deleteAvailabilityRequestTest = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `deleteAvailabilityRequestAvailabilityId` | `?int` | Query, Optional | The ID of the availability or unavailability. |
| `deleteAvailabilityRequestTest` | `?bool` | Query, Optional | When `true`, indicates that this is a test request and no data is deleted from the subscriber’s database.<br>When `false`, the record will be deleted.<br>Default: **false** |

## Response Type

`void`

## Example Usage

```php
$version = '6';
$siteId = '-99';

$appointmentController->deleteAvailability($version, $siteId);
```


# Delete Appointment Add On

This endpoint can be used to early-cancel a booked appointment add-on.

```php
function deleteAppointmentAddOn(string $version, int $id, string $siteId, ?string $authorization = null): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `id` | `int` | Query, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`void`

## Example Usage

```php
$version = '6';
$id = 112;
$siteId = '-99';

$appointmentController->deleteAppointmentAddOn($version, $id, $siteId);
```

