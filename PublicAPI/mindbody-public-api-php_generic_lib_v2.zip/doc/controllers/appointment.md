# Appointment

```php
$appointmentController = $client->getAppointmentController();
```

## Class Name

`AppointmentController`

## Methods

* [Appointment Get Active Session Times](../../doc/controllers/appointment.md#appointment-get-active-session-times)
* [Appointment Get Add Ons](../../doc/controllers/appointment.md#appointment-get-add-ons)
* [Appointment Get Appointment Options](../../doc/controllers/appointment.md#appointment-get-appointment-options)
* [Appointment Get Available Dates](../../doc/controllers/appointment.md#appointment-get-available-dates)
* [Appointment Get Bookable Items](../../doc/controllers/appointment.md#appointment-get-bookable-items)
* [Appointment Get Schedule Items](../../doc/controllers/appointment.md#appointment-get-schedule-items)
* [Appointment Get Staff Appointments](../../doc/controllers/appointment.md#appointment-get-staff-appointments)
* [Appointment Get Unavailabilities](../../doc/controllers/appointment.md#appointment-get-unavailabilities)
* [Appointment Add Appointment](../../doc/controllers/appointment.md#appointment-add-appointment)
* [Appointment Add Appointment Add On](../../doc/controllers/appointment.md#appointment-add-appointment-add-on)
* [Appointment Update Availability](../../doc/controllers/appointment.md#appointment-update-availability)
* [Appointment Add Availabilities](../../doc/controllers/appointment.md#appointment-add-availabilities)
* [Appointment Update Appointment](../../doc/controllers/appointment.md#appointment-update-appointment)
* [Appointment Remove From Waitlist](../../doc/controllers/appointment.md#appointment-remove-from-waitlist)
* [Appointment Delete Availability](../../doc/controllers/appointment.md#appointment-delete-availability)
* [Appointment Delete Appointment Add On](../../doc/controllers/appointment.md#appointment-delete-appointment-add-on)


# Appointment Get Active Session Times

This is not appointment availability but rather the active business hours for studios and which increments services can be booked at. See BookableItems for appointment availability.

```php
function appointmentGetActiveSessionTimes(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndTime = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?string $requestScheduleType = null,
    ?array $requestSessionTypeIds = null,
    ?\DateTime $requestStartTime = null
): MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndTime` | `?\DateTime` | Query, Optional | Filters results to times that end on or before this time on the current date. Any date provided is ignored..<br><br />Default: **23:59:59** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestScheduleType` | [`?string (RequestScheduleTypeEnum)`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided. |
| `requestSessionTypeIds` | `?(int[])` | Query, Optional | Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided. |
| `requestStartTime` | `?\DateTime` | Query, Optional | Filters results to times that start on or after this time on the current date. Any date provided is ignored.<br><br />Default: **00:00:00** |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-active-session-times-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $appointmentController->appointmentGetActiveSessionTimes($version, $siteId);
```


# Appointment Get Add Ons

Get active appointment add-ons.

```php
function appointmentGetAddOns(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?int $requestStaffId = null
): MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffId` | `?int` | Query, Optional | Filter to add-ons only performed by this staff member. |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-add-ons-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $appointmentController->appointmentGetAddOns($version, $siteId);
```


# Appointment Get Appointment Options

This endpoint has no query parameters.

```php
function appointmentGetAppointmentOptions(
    string $version,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-appointment-options-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $appointmentController->appointmentGetAppointmentOptions($version, $siteId);
```


# Appointment Get Available Dates

Returns a list of dates to narrow down staff availability when booking. Dates are those which staff are scheduled to work and do not guarantee booking availabilities. After this call is made, use GET BookableItems to retrieve availabilities for specific dates before booking.

```php
function appointmentGetAvailableDates(
    string $version,
    int $requestSessionTypeId,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLocationId = null,
    ?int $requestStaffId = null,
    ?\DateTime $requestStartDate = null
): MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestSessionTypeId` | `int` | Query, Required | required requested session type ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `?\DateTime` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestLocationId` | `?int` | Query, Optional | optional requested location ID. |
| `requestStaffId` | `?int` | Query, Optional | optional requested staff ID. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today's date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-available-dates-response.md)

## Example Usage

```php
$version = '6';
$requestSessionTypeId = 100;
$siteId = '-99';

$result = $appointmentController->appointmentGetAvailableDates($version, $requestSessionTypeId, $siteId);
```


# Appointment Get Bookable Items

Returns a list of availabilities with the information needed to book appointments. Availabilities include information such as the location and its amenities, staff members, programs, and session types. Recommended to use with ActiveSessionTimes to see which increments each business allows for booking appointments.

```php
function appointmentGetBookableItems(
    string $version,
    array $requestSessionTypeIds,
    string $siteId,
    ?string $authorization = null,
    ?int $requestAppointmentId = null,
    ?\DateTime $requestEndDate = null,
    ?bool $requestIgnoreDefaultSessionLength = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDate = null
): MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestSessionTypeIds` | `int[]` | Query, Required | A list of the requested session type IDs. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentId` | `?int` | Query, Optional | If provided, filters out the appointment with this ID. |
| `requestEndDate` | `?\DateTime` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestIgnoreDefaultSessionLength` | `?bool` | Query, Optional | When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br /><br>When `false`, only availabilities that have the default session length return. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | A list of the requested location IDs. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `?(int[])` | Query, Optional | A list of the requested staff IDs. Omit parameter to return all staff availabilities. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The start date of the requested date range.<br><br />Default: **today's date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-bookable-items-response.md)

## Example Usage

```php
$version = '6';
$requestSessionTypeIds = [228, 229];
$siteId = '-99';

$result = $appointmentController->appointmentGetBookableItems($version, $requestSessionTypeIds, $siteId);
```


# Appointment Get Schedule Items

Returns a list of schedule items, including appointments, availabilities, and unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.

```php
function appointmentGetScheduleItems(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDate = null,
    ?bool $requestIgnorePrepFinishTimes = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDate = null
): MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `?\DateTime` | Query, Optional | The end date of the requested date range.<br><br />Default: **today's date** |
| `requestIgnorePrepFinishTimes` | `?bool` | Query, Optional | When `true`, appointment preparation and finish unavailabilities are not returned.<br><br />Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | A list of requested location IDs. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `?(int[])` | Query, Optional | A list of requested staff IDs. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The start date of the requested date range.<br><br />Default: **today's date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-schedule-items-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $appointmentController->appointmentGetScheduleItems($version, $siteId);
```


# Appointment Get Staff Appointments

Returns a list of appointments by staff member.

```php
function appointmentGetStaffAppointments(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestAppointmentIds = null,
    ?string $requestClientId = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDate = null
): MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentIds` | `?(int[])` | Query, Optional | A list of the requested appointment IDs. |
| `requestClientId` | `?string` | Query, Optional | The client ID to be returned. |
| `requestEndDate` | `?\DateTime` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | A list of the requested location IDs. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `?(int[])` | Query, Optional | List of staff IDs to be returned. Use a value of zero to return all staff appointments. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today's date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-staff-appointments-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $appointmentController->appointmentGetStaffAppointments($version, $siteId);
```


# Appointment Get Unavailabilities

Returns a list of unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed..

```php
function appointmentGetUnavailabilities(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDate = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDate = null
): MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `?\DateTime` | Query, Optional | The end date of the requested date range.<br><br />Default: **today's date** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `?(int[])` | Query, Optional | A list of requested staff IDs. |
| `requestStartDate` | `?\DateTime` | Query, Optional | The start date of the requested date range.<br><br />Default: **today's date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-unavailabilities-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $appointmentController->appointmentGetUnavailabilities($version, $siteId);
```


# Appointment Add Appointment

A user token is required for this endpoint. To book an appointment, you must use a location ID, staff ID, client ID, session type ID, and the StartDateTime of the appointment. You can get most of this information using GET BookableItems.

```php
function appointmentAddAppointment(
    string $version,
    AddAppointmentRequest $request,
    string $siteId,
    ?string $authorization = null
): AddAppointmentResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddAppointmentRequest`](../../doc/models/add-appointment-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AddAppointmentResponse`](../../doc/models/add-appointment-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_locationId = 238;
$request_sessionTypeId = 82;
$request_staffId = 188;
$request_startDateTime = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');
$request = new Models\AddAppointmentRequest(
    $request_clientId,
    $request_locationId,
    $request_sessionTypeId,
    $request_staffId,
    $request_startDateTime
);
$siteId = '-99';

$result = $appointmentController->appointmentAddAppointment($version, $request, $siteId);
```


# Appointment Add Appointment Add On

This endpoint books an add-on on top of an existing, regular appointment. To book an add-on, you must use an existing appointment ID and session type ID. You can get a session type ID using `GET AppointmentAddOns`.

```php
function appointmentAddAppointmentAddOn(
    string $version,
    MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-add-on-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-add-on-response.md)

## Example Usage

```php
$version = '6';
$request = new Models\MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest();
$siteId = '-99';

$result = $appointmentController->appointmentAddAppointmentAddOn($version, $request, $siteId);
```


# Appointment Update Availability

To update the information for a specific availability or unavailability of the staff.<br />
Note: You must have a staff user token with the required permissions.

```php
function appointmentUpdateAvailability(
    string $version,
    string $siteId,
    MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest $updateAvailabilityRequest,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateAvailabilityRequest` | [`MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-availability-request.md) | Body, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-availability-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';
$updateAvailabilityRequest = new Models\MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest();

$result = $appointmentController->appointmentUpdateAvailability($version, $siteId, $updateAvailabilityRequest);
```


# Appointment Add Availabilities

Add availabilities and unavailabilities for a staff member.<br />
Note: You must have a staff user token with the required permissions.

```php
function appointmentAddAvailabilities(
    string $version,
    MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-availabilities-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-availabilities-response.md)

## Example Usage

```php
$version = '6';
$request = new Models\MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest();
$siteId = '-99';

$result = $appointmentController->appointmentAddAvailabilities($version, $request, $siteId);
```


# Appointment Update Appointment

To update the information for a specific appointment, you must have a staff user token with the proper permissions. Note that you can only update the appointment's `StartDateTime`, `EndDateTime`, `StaffId`, `Notes`, and `SessionTypeId`.

```php
function appointmentUpdateAppointment(
    string $version,
    MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-appointment-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-appointment-response.md)

## Example Usage

```php
$version = '6';
$request_appointmentId = 246;
$request = new Models\MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest(
    $request_appointmentId
);
$siteId = '-99';

$result = $appointmentController->appointmentUpdateAppointment($version, $request, $siteId);
```


# Appointment Remove From Waitlist

Remove an appointment from waitlist

```php
function appointmentRemoveFromWaitlist(
    string $version,
    array $requestWaitlistEntryIds,
    string $siteId,
    ?string $authorization = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestWaitlistEntryIds` | `int[]` | Query, Required | A list of `WaitlistEntryIds` to remove from the waiting list. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`void`

## Example Usage

```php
$version = '6';
$requestWaitlistEntryIds = [138, 139];
$siteId = '-99';

$appointmentController->appointmentRemoveFromWaitlist($version, $requestWaitlistEntryIds, $siteId);
```


# Appointment Delete Availability

This endpoint deletes the availability or unavailability.
Note: You must have a staff user token with the required permissions.

```php
function appointmentDeleteAvailability(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $deleteAvailabilityRequestAvailabilityId = null,
    ?bool $deleteAvailabilityRequestTest = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `deleteAvailabilityRequestAvailabilityId` | `?int` | Query, Optional | The ID of the availability or unavailability. |
| `deleteAvailabilityRequestTest` | `?bool` | Query, Optional | When `true`, indicates that this is a test request and no data is deleted from the subscriber's database.<br>When `false`, the record will be deleted.<br>Default: **false** |

## Response Type

`void`

## Example Usage

```php
$version = '6';
$siteId = '-99';

$appointmentController->appointmentDeleteAvailability($version, $siteId);
```


# Appointment Delete Appointment Add On

This endpoint can be used to early-cancel a booked appointment add-on.

```php
function appointmentDeleteAppointmentAddOn(
    string $version,
    int $id,
    string $siteId,
    ?string $authorization = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `id` | `int` | Query, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`void`

## Example Usage

```php
$version = '6';
$id = 112;
$siteId = '-99';

$appointmentController->appointmentDeleteAppointmentAddOn($version, $id, $siteId);
```

