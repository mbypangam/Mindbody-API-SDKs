# Payroll

```php
$payrollController = $client->getPayrollController();
```

## Class Name

`PayrollController`

## Methods

* [Payroll Get Commissions](../../doc/controllers/payroll.md#payroll-get-commissions)
* [Payroll Get Scheduled Service Earnings](../../doc/controllers/payroll.md#payroll-get-scheduled-service-earnings)
* [Payroll Get Time Cards](../../doc/controllers/payroll.md#payroll-get-time-cards)
* [Payroll Get Tips](../../doc/controllers/payroll.md#payroll-get-tips)


# Payroll Get Commissions

A staff authorization token is not required for this endpoint, but if one is passed, its permissions are honored. Depending on the access permissions configured for the staff member whose token is passed,
the endpoint returns either only the payroll information for that staff member or it returns the payroll information for all staff members.

```php
function payrollGetCommissions(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDateTime = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?int $requestStaffId = null,
    ?\DateTime $requestStartDateTime = null
): MindbodyPublicApiDtoModelsV6PayrollControllerGetCommissionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDateTime` | `?\DateTime` | Query, Optional | The end of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br /><br>Default: **Today's date**<br><br>* If you do not supply an `EndDateTime`, the data returns for the period from the `StartDateTime` that you supply to today's date.<br>* If you do not supply an `EndDateTime` or a `StartDateTime`, data returns for the seven days prior to today's date. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | A LocationId that you want to retrieve payroll information for. If you do not supply a `LocationId`, data from all locations is returned. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffId` | `?int` | Query, Optional | A list of staff IDs that you want to retrieve payroll information for. If you do not supply a `StaffId`, all active staff members return, ordered by staff ID. |
| `requestStartDateTime` | `?\DateTime` | Query, Optional | The beginning of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br><br>* If you do not supply a `StartDateTime`, data returns for the seven days prior to the `EndDateTime` that you supply.<br>* If you do not supply either a `StartDateTime` or an `EndDateTime`, the data returns for seven days prior to today's date. |

## Response Type

[`MindbodyPublicApiDtoModelsV6PayrollControllerGetCommissionsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-payroll-controller-get-commissions-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $payrollController->payrollGetCommissions($version, $siteId);
```


# Payroll Get Scheduled Service Earnings

A staff authorization token is not required for this endpoint, but if one is passed, its permissions are honored. Depending on the access permissions configured for the staff member whose token is passed, the endpoint returns either only the payroll information for that staff member or it returns the payroll information for all staff members.

Note that if a staff member is not paid for a class, earnings of zero are returned by this endpoint.

Note that this endpoint calculates both bonus and no-reg rates for assistants.These rates are not supported by the Payroll report in the web interface.

Note that this endpoint returns both the teacher's adjusted rate and the assistant's pay rate when the assistant is paid by the teacher.The Payroll report in the web interface only returns the teacher's adjusted rate.

```php
function payrollGetScheduledServiceEarnings(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDateTime = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?int $requestScheduledServiceId = null,
    ?string $requestScheduledServiceType = null,
    ?int $requestStaffId = null,
    ?\DateTime $requestStartDateTime = null
): MindbodyPublicApiDtoModelsV6PayrollControllerGetScheduledServiceEarningsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDateTime` | `?\DateTime` | Query, Optional | The end of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br /><br>Default: **Today's date**<br><br>* If you do not supply an `EndDateTime`, the data returns for the period from the `StartDateTime` that you supply to today's date.<br>* If you do not supply an `EndDateTime` or a `StartDateTime`, data returns for the seven days prior to today's date. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | A LocationId that you want to retrieve payroll information for. If you do not supply a `LocationId`, data from all locations is returned. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestScheduledServiceId` | `?int` | Query, Optional | Filters the results to a single scheduled service. This parameter must be used with a single ScheduledServiceType. |
| `requestScheduledServiceType` | `?string` | Query, Optional | Filters the results to schedule service earnings for specific types of services. Possible values:<br><br>* Class<br>* Appointment |
| `requestStaffId` | `?int` | Query, Optional | A list of staff IDs that you want to retrieve payroll information for. If you do not supply a `StaffId`, all active staff members return, ordered by staff ID. |
| `requestStartDateTime` | `?\DateTime` | Query, Optional | The beginning of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br><br>* If you do not supply a `StartDateTime`, data returns for the seven days prior to the `EndDateTime` that you supply.<br>* If you do not supply either a `StartDateTime` or an `EndDateTime`, the data returns for seven days prior to today's date. |

## Response Type

[`MindbodyPublicApiDtoModelsV6PayrollControllerGetScheduledServiceEarningsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-payroll-controller-get-scheduled-service-earnings-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $payrollController->payrollGetScheduledServiceEarnings($version, $siteId);
```


# Payroll Get Time Cards

This endpoint returns information for all locations. The **View reports for all locations permission **is not supported for staff auth tokens.

```php
function payrollGetTimeCards(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDateTime = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?int $requestStaffId = null,
    ?\DateTime $requestStartDateTime = null
): MindbodyPublicApiDtoModelsV6PayrollControllerGetTimeCardsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDateTime` | `?\DateTime` | Query, Optional | The end of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br /><br>Default: **Today's date**<br><br>* If you do not supply an `EndDateTime`, the data returns for the period from the `StartDateTime` that you supply to today's date.<br>* If you do not supply an `EndDateTime` or a `StartDateTime`, data returns for the seven days prior to today's date. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | A LocationId that you want to retrieve payroll information for. If you do not supply a `LocationId`, data from all locations is returned. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffId` | `?int` | Query, Optional | A list of staff IDs that you want to retrieve payroll information for. If you do not supply a `StaffId`, all active staff members return, ordered by staff ID. |
| `requestStartDateTime` | `?\DateTime` | Query, Optional | The beginning of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br><br>* If you do not supply a `StartDateTime`, data returns for the seven days prior to the `EndDateTime` that you supply.<br>* If you do not supply either a `StartDateTime` or an `EndDateTime`, the data returns for seven days prior to today's date. |

## Response Type

[`MindbodyPublicApiDtoModelsV6PayrollControllerGetTimeCardsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-payroll-controller-get-time-cards-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $payrollController->payrollGetTimeCards($version, $siteId);
```


# Payroll Get Tips

A staff authorization token is not required for this endpoint, but if one is passed, its permissions are honored. Depending on the access permissions configured for the staff member whose token is passed,
the endpoint returns either only the payroll information for that staff member or it returns the payroll information for all staff members.
This endpoint returns information for all locations.The** View reports for all locations **permission is not supported for staff auth tokens.

```php
function payrollGetTips(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndDateTime = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?int $requestStaffId = null,
    ?\DateTime $requestStartDateTime = null
): MindbodyPublicApiDtoModelsV6PayrollControllerGetTipsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndDateTime` | `?\DateTime` | Query, Optional | The end of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br /><br>Default: **Today's date**<br><br>* If you do not supply an `EndDateTime`, the data returns for the period from the `StartDateTime` that you supply to today's date.<br>* If you do not supply an `EndDateTime` or a `StartDateTime`, data returns for the seven days prior to today's date. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | A LocationId that you want to retrieve payroll information for. If you do not supply a `LocationId`, data from all locations is returned. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffId` | `?int` | Query, Optional | A list of staff IDs that you want to retrieve payroll information for. If you do not supply a `StaffId`, all active staff members return, ordered by staff ID. |
| `requestStartDateTime` | `?\DateTime` | Query, Optional | The beginning of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br><br>* If you do not supply a `StartDateTime`, data returns for the seven days prior to the `EndDateTime` that you supply.<br>* If you do not supply either a `StartDateTime` or an `EndDateTime`, the data returns for seven days prior to today's date. |

## Response Type

[`MindbodyPublicApiDtoModelsV6PayrollControllerGetTipsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-payroll-controller-get-tips-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $payrollController->payrollGetTips($version, $siteId);
```

