# Pick a Spotv

```php
$pickASpotvController = $client->getPickASpotvController();
```

## Class Name

`PickASpotvController`

## Methods

* [Pick a Spotv Class List](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-class-list)
* [Pick a Spotv Class](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-class)
* [Pick a Spotv Reservation Get](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-get)
* [Pick a Spotv Reservation Put](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-put)
* [Pick a Spotv Reservation Post](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-post)
* [Pick a Spotv Reservation Delete](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-delete)


# Pick a Spotv Class List

```php
function pickASpotvClassList(string $version, string $siteId, ?string $authorization = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $pickASpotvController->pickASpotvClassList($version, $siteId);
```


# Pick a Spotv Class

```php
function pickASpotvClass(string $version, string $classId, string $siteId, ?string $authorization = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `classId` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$classId = 'classId0';
$siteId = '-99';

$result = $pickASpotvController->pickASpotvClass($version, $classId, $siteId);
```


# Pick a Spotv Reservation Get

```php
function pickASpotvReservationGet(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$pathInfo = 'pathInfo8';
$siteId = '-99';

$result = $pickASpotvController->pickASpotvReservationGet($version, $pathInfo, $siteId);
```


# Pick a Spotv Reservation Put

```php
function pickASpotvReservationPut(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$pathInfo = 'pathInfo8';
$siteId = '-99';

$result = $pickASpotvController->pickASpotvReservationPut($version, $pathInfo, $siteId);
```


# Pick a Spotv Reservation Post

```php
function pickASpotvReservationPost(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$pathInfo = 'pathInfo8';
$siteId = '-99';

$result = $pickASpotvController->pickASpotvReservationPost($version, $pathInfo, $siteId);
```


# Pick a Spotv Reservation Delete

```php
function pickASpotvReservationDelete(
    string $version,
    string $pathInfo,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$pathInfo = 'pathInfo8';
$siteId = '-99';

$result = $pickASpotvController->pickASpotvReservationDelete($version, $pathInfo, $siteId);
```

