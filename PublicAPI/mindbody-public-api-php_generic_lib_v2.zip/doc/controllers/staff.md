# Staff

```php
$staffController = $client->getStaffController();
```

## Class Name

`StaffController`

## Methods

* [Get Staff Image URL](../../doc/controllers/staff.md#get-staff-image-url)
* [Get Sales Reps](../../doc/controllers/staff.md#get-sales-reps)
* [Get Staff Session Types](../../doc/controllers/staff.md#get-staff-session-types)
* [Get Staff](../../doc/controllers/staff.md#get-staff)
* [Get Staff Permissions](../../doc/controllers/staff.md#get-staff-permissions)
* [Add Staff](../../doc/controllers/staff.md#add-staff)
* [Assign Staff Session Type](../../doc/controllers/staff.md#assign-staff-session-type)
* [Add Staff Availability](../../doc/controllers/staff.md#add-staff-availability)
* [Update Staff](../../doc/controllers/staff.md#update-staff)
* [Update Staff Permissions](../../doc/controllers/staff.md#update-staff-permissions)


# Get Staff Image URL

This endpoint can be utilized to retrieve image urls for requested staff member.

```php
function getStaffImageURL(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestStaffId = null
): GetStaffImageURLResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestStaffId` | `?int` | Query, Optional | The ID of the staff member whose image URL details you want to retrieve. |

## Response Type

[`GetStaffImageURLResponse`](../../doc/models/get-staff-image-url-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestStaffId = 180;

$result = $staffController->getStaffImageURL(
    $version,
    $siteId,
    $authorization,
    $requestStaffId
);
```


# Get Sales Reps

This endpoint returns the basic details of the staffs that are marked as sales reps.

```php
function getSalesReps(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?bool $requestActiveOnly = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?array $requestSalesRepNumbers = null
): GetSalesRepsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestActiveOnly` | `?bool` | Query, Optional | When `true`, will return only active reps data.<br>Default : **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSalesRepNumbers` | `?(int[])` | Query, Optional | This is the list of the sales rep numbers for which the salesrep data will be fetched. |

## Response Type

[`GetSalesRepsResponse`](../../doc/models/get-sales-reps-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestActiveOnly = false;

$requestLimit = 62;

$requestOffset = 100;

$requestSalesRepNumbers = [
    123,
    124,
    125
];

$result = $staffController->getSalesReps(
    $version,
    $siteId,
    $authorization,
    $requestActiveOnly,
    $requestLimit,
    $requestOffset,
    $requestSalesRepNumbers
);
```


# Get Staff Session Types

Gets a list of active session types for a specific staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```php
function getStaffSessionTypes(
    string $version,
    int $requestStaffId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?bool $requestOnlineOnly = null,
    ?array $requestProgramIds = null
): GetStaffSessionTypesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestStaffId` | `int` | Query, Required | The ID of the staff member whose session types you want to return. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `?bool` | Query, Optional | When `true`, indicates that only the session types that can be booked online should be returned.<br>Default: **false** |
| `requestProgramIds` | `?(int[])` | Query, Optional | Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return. |

## Response Type

[`GetStaffSessionTypesResponse`](../../doc/models/get-staff-session-types-response.md)

## Example Usage

```php
$version = '6';

$requestStaffId = 180;

$siteId = '-99';

$authorization = 'authorization6';

$requestLimit = 62;

$requestOffset = 100;

$requestOnlineOnly = false;

$requestProgramIds = [
    91,
    92,
    93
];

$result = $staffController->getStaffSessionTypes(
    $version,
    $requestStaffId,
    $siteId,
    $authorization,
    $requestLimit,
    $requestOffset,
    $requestOnlineOnly,
    $requestProgramIds
);
```


# Get Staff

When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:

* FirstName
* LastName
* Id
* Bio
* DisplayName
* ImageUrl
* EmpID

```php
function getStaff(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestFilters = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?int $requestSessionTypeId = null,
    ?array $requestStaffIds = null,
    ?\DateTime $requestStartDateTime = null
): GetStaffResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestFilters` | `?(string[])` | Query, Optional | Filters to apply to the search. Possible values are:<br><br>* StaffViewable<br>* AppointmentInstructor<br>* ClassInstructor<br>* Male<br>* Female |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSessionTypeId` | `?int` | Query, Optional | Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter. |
| `requestStaffIds` | `?(int[])` | Query, Optional | A list of the requested staff IDs. |
| `requestStartDateTime` | `?\DateTime` | Query, Optional | Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter. |

## Response Type

[`GetStaffResponse`](../../doc/models/get-staff-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestFilters = [
    'request.filters0',
    'request.filters1',
    'request.filters2'
];

$requestLimit = 62;

$requestLocationId = 90;

$requestOffset = 100;

$requestSessionTypeId = 100;

$requestStaffIds = [
    23,
    24,
    25
];

$requestStartDateTime = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$result = $staffController->getStaff(
    $version,
    $siteId,
    $authorization,
    $requestFilters,
    $requestLimit,
    $requestLocationId,
    $requestOffset,
    $requestSessionTypeId,
    $requestStaffIds,
    $requestStartDateTime
);
```


# Get Staff Permissions

Get configured staff permissions for a staff member.

```php
function getStaffPermissions(
    string $version,
    int $requestStaffId,
    string $siteId,
    ?string $authorization = null
): GetStaffPermissionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestStaffId` | `int` | Query, Required | The ID of the staff member whose permissions you want to return. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetStaffPermissionsResponse`](../../doc/models/get-staff-permissions-response.md)

## Example Usage

```php
$version = '6';

$requestStaffId = 180;

$siteId = '-99';

$authorization = 'authorization6';

$result = $staffController->getStaffPermissions(
    $version,
    $requestStaffId,
    $siteId,
    $authorization
);
```


# Add Staff

Creates a new staff member record at the specified business. The `FirstName` and `LastName` parameters are always required for this request.

```php
function addStaff(
    string $version,
    AddStaffRequest $request,
    string $siteId,
    ?string $authorization = null
): AddStaffResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddStaffRequest`](../../doc/models/add-staff-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AddStaffResponse`](../../doc/models/add-staff-response.md)

## Example Usage

```php
$version = '6';

$request = AddStaffRequestBuilder::init(
    'FirstName8',
    'LastName8'
)
    ->email('Email8')
    ->isMale(false)
    ->homePhone('HomePhone8')
    ->workPhone('WorkPhone2')
    ->mobilePhone('MobilePhone6')
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $staffController->addStaff(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Assign Staff Session Type

Assigns a staff member to an appointment session type with staff specific properties such as time length and pay rate. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```php
function assignStaffSessionType(
    string $version,
    AssignStaffSessionTypeRequest $request,
    string $siteId,
    ?string $authorization = null
): AssignStaffSessionTypeResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AssignStaffSessionTypeRequest`](../../doc/models/assign-staff-session-type-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`AssignStaffSessionTypeResponse`](../../doc/models/assign-staff-session-type-response.md)

## Example Usage

```php
$version = '6';

$request = AssignStaffSessionTypeRequestBuilder::init(
    188,
    82,
    false
)
    ->timeLength(222)
    ->prepTime(166)
    ->finishTime(246)
    ->payRateType('PayRateType2')
    ->payRateAmount(169.62)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $staffController->assignStaffSessionType(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Add Staff Availability

Enables to add staff availability or unavailability for a given staff member.

```php
function addStaffAvailability(
    string $version,
    AddStaffAvailabilityRequest $request,
    string $siteId,
    ?string $authorization = null
): void
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddStaffAvailabilityRequest`](../../doc/models/add-staff-availability-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`void`

## Example Usage

```php
$version = '6';

$request = AddStaffAvailabilityRequestBuilder::init(
    188,
    false,
    [
        'DaysOfWeek7'
    ],
    'StartTime4',
    'EndTime0',
    'StartDate0',
    'EndDate6'
)
    ->description('Description0')
    ->programIds(
        [
            238
        ]
    )
    ->locationId(238)
    ->status('Status4')
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$staffController->addStaffAvailability(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Update Staff

Updates an existing staff member record at the specified business. The ID is a required parameters for this request.

```php
function updateStaff(
    string $version,
    UpdateStaffRequest $request,
    string $siteId,
    ?string $authorization = null
): UpdateStaffResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateStaffRequest`](../../doc/models/update-staff-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateStaffResponse`](../../doc/models/update-staff-response.md)

## Example Usage

```php
$version = '6';

$request = UpdateStaffRequestBuilder::init(
    142
)
    ->firstName('FirstName8')
    ->lastName('LastName8')
    ->email('Email8')
    ->isMale(false)
    ->homePhone('HomePhone8')
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $staffController->updateStaff(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Update Staff Permissions

Assigns a permission group to a staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```php
function updateStaffPermissions(
    string $version,
    UpdateStaffPermissionsRequest $request,
    string $siteId,
    ?string $authorization = null
): UpdateStaffPermissionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateStaffPermissionsRequest`](../../doc/models/update-staff-permissions-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateStaffPermissionsResponse`](../../doc/models/update-staff-permissions-response.md)

## Example Usage

```php
$version = '6';

$request = UpdateStaffPermissionsRequestBuilder::init(
    188,
    'PermissionGroupName8'
)->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $staffController->updateStaffPermissions(
    $version,
    $request,
    $siteId,
    $authorization
);
```

