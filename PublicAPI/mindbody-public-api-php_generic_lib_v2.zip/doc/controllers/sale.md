# Sale

```php
$saleController = $client->getSaleController();
```

## Class Name

`SaleController`

## Methods

* [Get Accepted Card Types](../../doc/controllers/sale.md#get-accepted-card-types)
* [Get Contracts](../../doc/controllers/sale.md#get-contracts)
* [Get Custom Payment Methods](../../doc/controllers/sale.md#get-custom-payment-methods)
* [Get Gift Card Balance](../../doc/controllers/sale.md#get-gift-card-balance)
* [Get Gift Cards](../../doc/controllers/sale.md#get-gift-cards)
* [Get Packages](../../doc/controllers/sale.md#get-packages)
* [Get Sales](../../doc/controllers/sale.md#get-sales)
* [Get Services](../../doc/controllers/sale.md#get-services)
* [Update Services](../../doc/controllers/sale.md#update-services)
* [Get Transactions](../../doc/controllers/sale.md#get-transactions)
* [Checkout Shopping Cart](../../doc/controllers/sale.md#checkout-shopping-cart)
* [Initialize Credit Card Entry](../../doc/controllers/sale.md#initialize-credit-card-entry)
* [Purchase Account Credit](../../doc/controllers/sale.md#purchase-account-credit)
* [Purchase Contract](../../doc/controllers/sale.md#purchase-contract)
* [Purchase Gift Card](../../doc/controllers/sale.md#purchase-gift-card)
* [Return Sale](../../doc/controllers/sale.md#return-sale)
* [Update Sale Date](../../doc/controllers/sale.md#update-sale-date)


# Get Accepted Card Types

Gets a list of card types that the site accepts. You can also use `GET Sites` to return the Site object, which contains individual accepted card types for requested sites.

This endpoint has no query parameters.The response returns a list of strings. Possible values are:

* Visa
* MasterCard
* Discover
* AMEX

```php
function getAcceptedCardTypes(string $version, string $siteId, ?string $authorization = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`string[]`

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->getAcceptedCardTypes($version, $siteId);
```


# Get Contracts

Returns the contracts and autopay options that are available on a location-by-location basis. Depending on the configurations established by the site, this endpoint returns options that can be used to sign up clients for recurring payments for services offered by the business.

```php
function getContracts(
    string $version,
    int $requestLocationId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestConsumerId = null,
    ?array $requestContractIds = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?string $requestPromoCode = null,
    ?bool $requestSoldOnline = null
): GetContractsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestLocationId` | `int` | Query, Required | The ID of the location that has the requested contracts and AutoPay options. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestConsumerId` | `?int` | Query, Optional | The ID of the client. |
| `requestContractIds` | `?(int[])` | Query, Optional | When included, the response only contains details about the specified contract IDs. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestPromoCode` | `?string` | Query, Optional | PromoCode to apply |
| `requestSoldOnline` | `?bool` | Query, Optional | When `true`, the response only contains details about contracts and AutoPay options that can be sold online.<br>When `false`, all contracts are returned.<br>Default: **false** |

## Response Type

[`GetContractsResponse`](../../doc/models/get-contracts-response.md)

## Example Usage

```php
$version = '6';
$requestLocationId = 90;
$siteId = '-99';

$result = $saleController->getContracts($version, $requestLocationId, $siteId);
```


# Get Custom Payment Methods

Get payment methods that can be used to pay for sales at a site.

```php
function getCustomPaymentMethods(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): GetCustomPaymentMethodsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`GetCustomPaymentMethodsResponse`](../../doc/models/get-custom-payment-methods-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->getCustomPaymentMethods($version, $siteId);
```


# Get Gift Card Balance

Returns a gift card’s remaining balance.

```php
function getGiftCardBalance(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?string $barcodeId = null
): GetGiftCardBalanceResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `barcodeId` | `?string` | Query, Optional | The barcode ID of the gift card for which you want the balance. |

## Response Type

[`GetGiftCardBalanceResponse`](../../doc/models/get-gift-card-balance-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->getGiftCardBalance($version, $siteId);
```


# Get Gift Cards

Returns information about gift cards that can be purchased.

```php
function getGiftCards(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestIds = null,
    ?bool $requestIncludeCustomLayouts = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?bool $requestSoldOnline = null
): GetGiftCardResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestIds` | `?(int[])` | Query, Optional | Filters the results to the requested gift card IDs.<br /><br>Default: **all** gift cards. |
| `requestIncludeCustomLayouts` | `?bool` | Query, Optional | When `true`, includes custom gift card layouts.<br /><br>When `false`, includes only system layouts.<br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | When included, returns gift cards that are sold at the provided location ID. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSoldOnline` | `?bool` | Query, Optional | When `true`, only returns gift cards that are sold online.<br /><br>Default: **false** |

## Response Type

[`GetGiftCardResponse`](../../doc/models/get-gift-card-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->getGiftCards($version, $siteId);
```


# Get Packages

A package is typically used to combine multiple services and/or products into a single offering. Staff members can check out multiple appointments while selling the package, and can discount the items included. For example, a spa might bundle a massage, a pedicure, a manicure, a facial, and a few selected beauty products into a package.

```php
function getPackages(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?array $requestPackageIds = null,
    ?bool $requestSellOnline = null
): GetPackagesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | The location ID to use to determine the tax for the products that this request returns.<br /><br>Default: **online store** |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestPackageIds` | `?(int[])` | Query, Optional | A list of the packages IDs to filter by. |
| `requestSellOnline` | `?bool` | Query, Optional | When `true`, only returns products that can be sold online.<br /><br>When `false`, all products are returned.<br /><br>Default: **false** |

## Response Type

[`GetPackagesResponse`](../../doc/models/get-packages-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->getPackages($version, $siteId);
```


# Get Sales

Get sales completed at a site.

```php
function getSales(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndSaleDateTime = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?int $requestPaymentMethodId = null,
    ?int $requestSaleId = null,
    ?\DateTime $requestStartSaleDateTime = null
): GetSalesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndSaleDateTime` | `?\DateTime` | Query, Optional | Filters results to sales that happened before this date and time. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestPaymentMethodId` | `?int` | Query, Optional | Filters results to sales paid for by the given payment method ID which indicates payment method(s) (i.e. cash, VISA, AMEX, Check, etc.). |
| `requestSaleId` | `?int` | Query, Optional | The sale ID associated with the particular item. It Filters results to the requested sale ID. |
| `requestStartSaleDateTime` | `?\DateTime` | Query, Optional | Filters results to sales that happened after this date and time. |

## Response Type

[`GetSalesResponse`](../../doc/models/get-sales-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->getSales($version, $siteId);
```


# Get Services

Get pricing options available for purchase at a site

```php
function getServices(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClassId = null,
    ?int $requestClassScheduleId = null,
    ?bool $requestHideRelatedPrograms = null,
    ?bool $requestIncludeDiscontinued = null,
    ?bool $requestIncludeSaleInContractOnly = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?bool $requestSellOnline = null,
    ?array $requestServiceIds = null,
    ?array $requestSessionTypeIds = null,
    ?int $requestStaffId = null
): GetServicesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassId` | `?int` | Query, Optional | Filters to the pricing options for the specified class ID. |
| `requestClassScheduleId` | `?int` | Query, Optional | Filters to the pricing options for the specified class schedule ID. |
| `requestHideRelatedPrograms` | `?bool` | Query, Optional | When `true`, indicates that pricing options of related programs are omitted from the response.<br /><br>Default: **false** |
| `requestIncludeDiscontinued` | `?bool` | Query, Optional | When `true`, indicates that the filtered pricing option list includes discontinued pricing options.<br /><br>Default: **false** |
| `requestIncludeSaleInContractOnly` | `?bool` | Query, Optional | When `true`, indicates that the filtered pricing option list includes sale in contract only pricing options.<br /><br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | When specified, for each returned pricing option, `TaxRate` and `TaxIncluded` are calculated according to the specified location. Note that this does not filter results to only services provided at the given location, and for locations where Value-Added Tax (VAT) rules apply, the `TaxRate` is set to zero. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | Filters to pricing options with the specified program IDs. |
| `requestSellOnline` | `?bool` | Query, Optional | When `true`, filters to the pricing options that can be sold online.<br /><br>Default: **false** |
| `requestServiceIds` | `?(string[])` | Query, Optional | Filters to the pricing options with the specified IDs. In this context, service and pricing option are used interchangeably. These are the `PurchasedItems[].Id` returned from GET Sales. |
| `requestSessionTypeIds` | `?(int[])` | Query, Optional | Filters to the pricing options with the specified session types IDs. |
| `requestStaffId` | `?int` | Query, Optional | Sets `Price` and `OnlinePrice` to the particular pricing of a specific staff member, if allowed by the business. |

## Response Type

[`GetServicesResponse`](../../doc/models/get-services-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->getServices($version, $siteId);
```


# Update Services

Update unit price and online price of provided services.

```php
function updateServices(
    string $version,
    string $siteId,
    array $updateServicesRequest,
    ?string $authorization = null
): UpdateServiceResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateServicesRequest` | [`UpdateServiceRequest[]`](../../doc/models/update-service-request.md) | Body, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateServiceResponse`](../../doc/models/update-service-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';
$updateServicesRequest = [];

$updateServicesRequest[0] = new Models\UpdateServiceRequest();


$result = $saleController->updateServices($version, $siteId, $updateServicesRequest);
```


# Get Transactions

This endpoint returns a list of transaction details of processed sales.

```php
function getTransactions(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientId = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?int $requestSaleId = null,
    ?string $requestStatus = null,
    ?\DateTime $requestTransactionEndDateTime = null,
    ?int $requestTransactionId = null,
    ?\DateTime $requestTransactionStartDateTime = null
): GetTransactionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientId` | `?int` | Query, Optional | Filters results to the requested client ID. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | Filters the transaction results with the ID number associated with the location of the sale. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSaleId` | `?int` | Query, Optional | Filters the transaction results with the ID number associated with the sale. |
| `requestStatus` | `?string` | Query, Optional | Filters the transaction results by the estimated transaction status. |
| `requestTransactionEndDateTime` | `?\DateTime` | Query, Optional | Filters the transaction results that happpened before this date and time.<br>Default: **today’s date** |
| `requestTransactionId` | `?int` | Query, Optional | Filters the transaction results with the ID number generated when the sale is processed. |
| `requestTransactionStartDateTime` | `?\DateTime` | Query, Optional | Filters the transaction results that happpened after this date and time.<br>Default: **today’s date** |

## Response Type

[`GetTransactionsResponse`](../../doc/models/get-transactions-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->getTransactions($version, $siteId);
```


# Checkout Shopping Cart

This endpoint provides a wide range of functionality. For example, you can use it when a client purchases new pricing options, retail products, packages, and tips. You can also combine purchasing a new pricing option and many other functions, such as booking a client into a class, booking a new appointment for a client, enrolling a client into an enrollment or course, or reconciling an unpaid, already booked appointment or class. Use this call when a client purchases:

* a pricing option, after calling `GET Services` and choosing a specific pricing option’s ID
* a retail product, after calling `GET Products` and choosing a specific retail product’s ID
* a package, after calling `GET Packages` and choosing a specific package’s ID
* a tip to give to a staff member, after calling `GET Staff` and choosing a specific staff member ID, and the amount that the client wants to tip
  The documentation provides explanations of the request body and response, as well as the cart item metadata, payment item metadata, and purchased cart items.
  This endpoint had been updated to support Strong Customer Authentication (SCA).
  **Note :**
  Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

```php
function checkoutShoppingCart(
    string $version,
    CheckoutShoppingCartRequest $request,
    string $siteId,
    ?string $authorization = null
): CheckoutShoppingCartResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`CheckoutShoppingCartRequest`](../../doc/models/checkout-shopping-cart-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`CheckoutShoppingCartResponse`](../../doc/models/checkout-shopping-cart-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_items = [];

$request_items[0] = new Models\CheckoutItemWrapper();

$request_items[1] = new Models\CheckoutItemWrapper();

$request_items[2] = new Models\CheckoutItemWrapper();

$request_payments = [];

$request_payments[0] = new Models\CheckoutPaymentInfo();

$request_payments[1] = new Models\CheckoutPaymentInfo();

$request_payments[2] = new Models\CheckoutPaymentInfo();

$request = new Models\CheckoutShoppingCartRequest(
    $request_clientId,
    $request_items,
    $request_payments
);
$siteId = '-99';

$result = $saleController->checkoutShoppingCart($version, $request, $siteId);
```


# Initialize Credit Card Entry

**Note**:  
Referer is a DomainURL which will be automatically reflected if the Card UI is loaded via your application.
If you are using this endpoint via postman then you need to specify your domain URL under Referer.

```php
function initializeCreditCardEntry(
    string $version,
    InitializeCreditCardEntryRequest $request,
    string $siteId,
    ?string $authorization = null
): InitializeCreditCardEntryResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`InitializeCreditCardEntryRequest`](../../doc/models/initialize-credit-card-entry-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`InitializeCreditCardEntryResponse`](../../doc/models/initialize-credit-card-entry-response.md)

## Example Usage

```php
$version = '6';
$request = new Models\InitializeCreditCardEntryRequest();
$siteId = '-99';

$result = $saleController->initializeCreditCardEntry($version, $request, $siteId);
```


# Purchase Account Credit

Allows a client to purchase account credit from a business.

```php
function purchaseAccountCredit(
    string $version,
    PurchaseAccountCreditRequest $request,
    string $siteId,
    ?string $authorization = null
): PurchaseAccountCreditResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`PurchaseAccountCreditRequest`](../../doc/models/purchase-account-credit-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`PurchaseAccountCreditResponse`](../../doc/models/purchase-account-credit-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request = new Models\PurchaseAccountCreditRequest(
    $request_clientId
);
$siteId = '-99';

$result = $saleController->purchaseAccountCredit($version, $request, $siteId);
```


# Purchase Contract

Allows a client to sign up for a contract or autopay using the information returned from the `GET Contracts` endpoint. The client can pay with a new credit card or with a stored credit card. The client must exist at the site specified before this call is made.

This endpoint allows a developer to specify whether a client pays now or pays on the `StartDate`.If you are building a client-facing experience, you should talk with the business owner to understand the owner’s policies before you give clients a choice of the two payment types.
This endpoint had been updated to support Strong Customer Authentication (SCA).

**Note**
Protect yourself from processor fees and credit card fraud. Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

```php
function purchaseContract(
    string $version,
    PurchaseContractRequest $request,
    string $siteId,
    ?string $authorization = null
): PurchaseContractResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`PurchaseContractRequest`](../../doc/models/purchase-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`PurchaseContractResponse`](../../doc/models/purchase-contract-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_contractId = 168;
$request = new Models\PurchaseContractRequest(
    $request_clientId,
    $request_contractId
);
$siteId = '-99';

$result = $saleController->purchaseContract($version, $request, $siteId);
```


# Purchase Gift Card

Allows a client to purchase a gift card from a business in a variety of designs. The card can be emailed to the recipient on a specific day, and a card title and a personal message can be added.
**Note**
Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

```php
function purchaseGiftCard(
    string $version,
    PurchaseGiftCardRequest $request,
    string $siteId,
    ?string $authorization = null
): PurchaseGiftCardResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`PurchaseGiftCardRequest`](../../doc/models/purchase-gift-card-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`PurchaseGiftCardResponse`](../../doc/models/purchase-gift-card-response.md)

## Example Usage

```php
$version = '6';
$request_locationId = 238;
$request_purchaserClientId = 'PurchaserClientId6';
$request_giftCardId = 222;
$request = new Models\PurchaseGiftCardRequest(
    $request_locationId,
    $request_purchaserClientId,
    $request_giftCardId
);
$siteId = '-99';

$result = $saleController->purchaseGiftCard($version, $request, $siteId);
```


# Return Sale

Return a comped sale for a specified sale ID in business mode. The sale is returnable only if it is a sale of a service, product or gift card and it has not been used. Currently, only the comp payment method is supported.

```php
function returnSale(
    string $version,
    ReturnSaleRequest $returnSaleRequest,
    string $siteId,
    ?string $authorization = null
): ReturnSaleResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `returnSaleRequest` | [`ReturnSaleRequest`](../../doc/models/return-sale-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`ReturnSaleResponse`](../../doc/models/return-sale-response.md)

## Example Usage

```php
$version = '6';
$returnSaleRequest = new Models\ReturnSaleRequest();
$siteId = '-99';

$result = $saleController->returnSale($version, $returnSaleRequest, $siteId);
```


# Update Sale Date

This endpoint updates the SaleDate and returns the details of the sale.

```php
function updateSaleDate(
    string $version,
    UpdateSaleDateRequest $request,
    string $siteId,
    ?string $authorization = null
): UpdateSaleDateResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateSaleDateRequest`](../../doc/models/update-sale-date-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateSaleDateResponse`](../../doc/models/update-sale-date-response.md)

## Example Usage

```php
$version = '6';
$request = new Models\UpdateSaleDateRequest();
$siteId = '-99';

$result = $saleController->updateSaleDate($version, $request, $siteId);
```

