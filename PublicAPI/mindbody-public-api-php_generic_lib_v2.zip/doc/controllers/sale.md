# Sale

```php
$saleController = $client->getSaleController();
```

## Class Name

`SaleController`

## Methods

* [Get Accepted Card Types](../../doc/controllers/sale.md#get-accepted-card-types)
* [Get Contracts](../../doc/controllers/sale.md#get-contracts)
* [Get Custom Payment Methods](../../doc/controllers/sale.md#get-custom-payment-methods)
* [Get Gift Card Balance](../../doc/controllers/sale.md#get-gift-card-balance)
* [Get Gift Cards](../../doc/controllers/sale.md#get-gift-cards)
* [Get Packages](../../doc/controllers/sale.md#get-packages)
* [Get Products](../../doc/controllers/sale.md#get-products)
* [Update Products](../../doc/controllers/sale.md#update-products)
* [Get Products Inventory](../../doc/controllers/sale.md#get-products-inventory)
* [Get Sales](../../doc/controllers/sale.md#get-sales)
* [Get Services](../../doc/controllers/sale.md#get-services)
* [Update Services](../../doc/controllers/sale.md#update-services)
* [Get Transactions](../../doc/controllers/sale.md#get-transactions)
* [Checkout Shopping Cart](../../doc/controllers/sale.md#checkout-shopping-cart)
* [Initialize Credit Card Entry](../../doc/controllers/sale.md#initialize-credit-card-entry)
* [Purchase Account Credit](../../doc/controllers/sale.md#purchase-account-credit)
* [Purchase Contract](../../doc/controllers/sale.md#purchase-contract)
* [Purchase Gift Card](../../doc/controllers/sale.md#purchase-gift-card)
* [Return Sale](../../doc/controllers/sale.md#return-sale)
* [Update Product Price](../../doc/controllers/sale.md#update-product-price)
* [Update Sale Date](../../doc/controllers/sale.md#update-sale-date)


# Get Accepted Card Types

Gets a list of card types that the site accepts. You can also use `GET Sites` to return the Site object, which contains individual accepted card types for requested sites.

This endpoint has no query parameters.The response returns a list of strings. Possible values are:

* Visa
* MasterCard
* Discover
* AMEX

:information_source: **Note** This endpoint does not require authentication.

```php
function getAcceptedCardTypes(string $version, string $siteId, ?string $authorization = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`string[]`

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$result = $saleController->getAcceptedCardTypes(
    $version,
    $siteId,
    $authorization
);
```


# Get Contracts

Returns the contracts and autopay options that are available on a location-by-location basis. Depending on the configurations established by the site, this endpoint returns options that can be used to sign up clients for recurring payments for services offered by the business.

:information_source: **Note** This endpoint does not require authentication.

```php
function getContracts(
    string $version,
    int $requestLocationId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestConsumerId = null,
    ?array $requestContractIds = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?string $requestPromoCode = null,
    ?bool $requestSoldOnline = null
): GetContractsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestLocationId` | `int` | Query, Required | The ID of the location that has the requested contracts and AutoPay options. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestConsumerId` | `?int` | Query, Optional | The ID of the client. |
| `requestContractIds` | `?(int[])` | Query, Optional | When included, the response only contains details about the specified contract IDs. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestPromoCode` | `?string` | Query, Optional | PromoCode to apply |
| `requestSoldOnline` | `?bool` | Query, Optional | When `true`, the response only contains details about contracts and AutoPay options that can be sold online.<br>When `false`, all contracts are returned.<br>Default: **false** |

## Response Type

[`GetContractsResponse`](../../doc/models/get-contracts-response.md)

## Example Usage

```php
$version = '6';

$requestLocationId = 90;

$siteId = '-99';

$authorization = 'authorization6';

$requestConsumerId = 120;

$requestContractIds = [
    39,
    40
];

$requestLimit = 62;

$requestOffset = 100;

$requestPromoCode = 'request.promoCode0';

$requestSoldOnline = false;

$result = $saleController->getContracts(
    $version,
    $requestLocationId,
    $siteId,
    $authorization,
    $requestConsumerId,
    $requestContractIds,
    $requestLimit,
    $requestOffset,
    $requestPromoCode,
    $requestSoldOnline
);
```


# Get Custom Payment Methods

Get payment methods that can be used to pay for sales at a site.

:information_source: **Note** This endpoint does not require authentication.

```php
function getCustomPaymentMethods(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): GetCustomPaymentMethodsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`GetCustomPaymentMethodsResponse`](../../doc/models/get-custom-payment-methods-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestLimit = 62;

$requestOffset = 100;

$result = $saleController->getCustomPaymentMethods(
    $version,
    $siteId,
    $authorization,
    $requestLimit,
    $requestOffset
);
```


# Get Gift Card Balance

Returns a gift card’s remaining balance.

:information_source: **Note** This endpoint does not require authentication.

```php
function getGiftCardBalance(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?string $barcodeId = null
): GetGiftCardBalanceResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `barcodeId` | `?string` | Query, Optional | The barcode ID of the gift card for which you want the balance. |

## Response Type

[`GetGiftCardBalanceResponse`](../../doc/models/get-gift-card-balance-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$barcodeId = 'barcodeId6';

$result = $saleController->getGiftCardBalance(
    $version,
    $siteId,
    $authorization,
    $barcodeId
);
```


# Get Gift Cards

Returns information about gift cards that can be purchased.

:information_source: **Note** This endpoint does not require authentication.

```php
function getGiftCards(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestIds = null,
    ?bool $requestIncludeCustomLayouts = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?bool $requestSoldOnline = null
): GetGiftCardResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestIds` | `?(int[])` | Query, Optional | Filters the results to the requested gift card IDs.<br /><br>Default: **all** gift cards. |
| `requestIncludeCustomLayouts` | `?bool` | Query, Optional | When `true`, includes custom gift card layouts.<br /><br>When `false`, includes only system layouts.<br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | When included, returns gift cards that are sold at the provided location ID. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSoldOnline` | `?bool` | Query, Optional | When `true`, only returns gift cards that are sold online.<br /><br>Default: **false** |

## Response Type

[`GetGiftCardResponse`](../../doc/models/get-gift-card-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestIds = [
    1,
    2
];

$requestIncludeCustomLayouts = false;

$requestLimit = 62;

$requestLocationId = 90;

$requestOffset = 100;

$requestSoldOnline = false;

$result = $saleController->getGiftCards(
    $version,
    $siteId,
    $authorization,
    $requestIds,
    $requestIncludeCustomLayouts,
    $requestLimit,
    $requestLocationId,
    $requestOffset,
    $requestSoldOnline
);
```


# Get Packages

A package is typically used to combine multiple services and/or products into a single offering. Staff members can check out multiple appointments while selling the package, and can discount the items included. For example, a spa might bundle a massage, a pedicure, a manicure, a facial, and a few selected beauty products into a package.

:information_source: **Note** This endpoint does not require authentication.

```php
function getPackages(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?array $requestPackageIds = null,
    ?bool $requestSellOnline = null
): GetPackagesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | The location ID to use to determine the tax for the products that this request returns.<br /><br>Default: **online store** |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestPackageIds` | `?(int[])` | Query, Optional | A list of the packages IDs to filter by. |
| `requestSellOnline` | `?bool` | Query, Optional | When `true`, only returns products that can be sold online.<br /><br>When `false`, all products are returned.<br /><br>Default: **false** |

## Response Type

[`GetPackagesResponse`](../../doc/models/get-packages-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestLimit = 62;

$requestLocationId = 90;

$requestOffset = 100;

$requestPackageIds = [
    158,
    159
];

$requestSellOnline = false;

$result = $saleController->getPackages(
    $version,
    $siteId,
    $authorization,
    $requestLimit,
    $requestLocationId,
    $requestOffset,
    $requestPackageIds,
    $requestSellOnline
);
```


# Get Products

Get retail products available for purchase at a site.

:information_source: **Note** This endpoint does not require authentication.

```php
function getProducts(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestCategoryIds = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?array $requestProductIds = null,
    ?string $requestSearchText = null,
    ?bool $requestSellOnline = null,
    ?array $requestSubCategoryIds = null
): GetProductsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestCategoryIds` | `?(int[])` | Query, Optional | A list of revenue category IDs to filter by. Use this ID when calling the GET Categories endpoint.<br><br>**Note:** The values for these are not currently retrievable through the API. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | The location ID to use to determine the tax for the products that this request returns.<br /><br>Default: **online store** |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProductIds` | `?(string[])` | Query, Optional | The barcode number of the product to be filter by. |
| `requestSearchText` | `?string` | Query, Optional | A search filter, used for searching by term. |
| `requestSellOnline` | `?bool` | Query, Optional | When `true`, only products that can be sold online are returned.<br /><br>When `false`, all products are returned.<br /><br>Default: **false** |
| `requestSubCategoryIds` | `?(int[])` | Query, Optional | A list of subcategory IDs to filter by. Use this ID when calling the GET Categories endpoint.<br><br>**Note:** The values for these are not currently retrievable through the API. |

## Response Type

[`GetProductsResponse`](../../doc/models/get-products-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestCategoryIds = [
    140,
    141
];

$requestLimit = 62;

$requestLocationId = 90;

$requestOffset = 100;

$requestProductIds = [
    'request.productIds3',
    'request.productIds4'
];

$requestSearchText = 'request.searchText0';

$requestSellOnline = false;

$requestSubCategoryIds = [
    173,
    174,
    175
];

$result = $saleController->getProducts(
    $version,
    $siteId,
    $authorization,
    $requestCategoryIds,
    $requestLimit,
    $requestLocationId,
    $requestOffset,
    $requestProductIds,
    $requestSearchText,
    $requestSellOnline,
    $requestSubCategoryIds
);
```


# Update Products

Update retail products available for purchase at a site.

:information_source: **Note** This endpoint does not require authentication.

```php
function updateProducts(
    string $version,
    string $siteId,
    array $updateProductsRequests,
    ?string $authorization = null
): GetProductsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateProductsRequests` | [`UpdateProductRequest[]`](../../doc/models/update-product-request.md) | Body, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`GetProductsResponse`](../../doc/models/get-products-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$updateProductsRequests = [
    UpdateProductRequestBuilder::init()
        ->barcodeId('BarcodeId2')
        ->price(47.22)
        ->onlinePrice(81.74)
        ->build(),
    UpdateProductRequestBuilder::init()
        ->barcodeId('BarcodeId2')
        ->price(47.22)
        ->onlinePrice(81.74)
        ->build()
];

$authorization = 'authorization6';

$result = $saleController->updateProducts(
    $version,
    $siteId,
    $updateProductsRequests,
    $authorization
);
```


# Get Products Inventory

Get retail products inventory data available at a site.

:information_source: **Note** This endpoint does not require authentication.

```php
function getProductsInventory(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestBarcodeIds = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestProductIds = null
): GetProductsInventoryResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestBarcodeIds` | `?(string[])` | Query, Optional | When included, the response only contains details about the specified Barcode Ids. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | When included, the response only contains details about the specified location Ids. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProductIds` | `?(string[])` | Query, Optional | When included, the response only contains details about the specified product Ids. |

## Response Type

[`GetProductsInventoryResponse`](../../doc/models/get-products-inventory-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestBarcodeIds = [
    'request.barcodeIds6'
];

$requestLimit = 62;

$requestLocationIds = [
    192
];

$requestOffset = 100;

$requestProductIds = [
    'request.productIds3',
    'request.productIds4'
];

$result = $saleController->getProductsInventory(
    $version,
    $siteId,
    $authorization,
    $requestBarcodeIds,
    $requestLimit,
    $requestLocationIds,
    $requestOffset,
    $requestProductIds
);
```


# Get Sales

Get sales completed at a site.

:information_source: **Note** This endpoint does not require authentication.

```php
function getSales(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndSaleDateTime = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?int $requestPaymentMethodId = null,
    ?int $requestSaleId = null,
    ?\DateTime $requestStartSaleDateTime = null
): GetSalesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndSaleDateTime` | `?DateTime` | Query, Optional | Filters results to sales that happened before this date and time. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestPaymentMethodId` | `?int` | Query, Optional | Filters results to sales paid for by the given payment method ID which indicates payment method(s) (i.e. cash, VISA, AMEX, Check, etc.). |
| `requestSaleId` | `?int` | Query, Optional | The sale ID associated with the particular item. It Filters results to the requested sale ID. |
| `requestStartSaleDateTime` | `?DateTime` | Query, Optional | Filters results to sales that happened after this date and time. |

## Response Type

[`GetSalesResponse`](../../doc/models/get-sales-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestEndSaleDateTime = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestLimit = 62;

$requestOffset = 100;

$requestPaymentMethodId = 140;

$requestSaleId = 32;

$requestStartSaleDateTime = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$result = $saleController->getSales(
    $version,
    $siteId,
    $authorization,
    $requestEndSaleDateTime,
    $requestLimit,
    $requestOffset,
    $requestPaymentMethodId,
    $requestSaleId,
    $requestStartSaleDateTime
);
```


# Get Services

Get pricing options available for purchase at a site

:information_source: **Note** This endpoint does not require authentication.

```php
function getServices(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClassId = null,
    ?int $requestClassScheduleId = null,
    ?bool $requestHideRelatedPrograms = null,
    ?bool $requestIncludeDiscontinued = null,
    ?bool $requestIncludeSaleInContractOnly = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?bool $requestSellOnline = null,
    ?array $requestServiceIds = null,
    ?array $requestSessionTypeIds = null,
    ?int $requestStaffId = null
): GetServicesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassId` | `?int` | Query, Optional | Filters to the pricing options for the specified class ID. |
| `requestClassScheduleId` | `?int` | Query, Optional | Filters to the pricing options for the specified class schedule ID. |
| `requestHideRelatedPrograms` | `?bool` | Query, Optional | When `true`, indicates that pricing options of related programs are omitted from the response.<br /><br>Default: **false** |
| `requestIncludeDiscontinued` | `?bool` | Query, Optional | When `true`, indicates that the filtered pricing option list includes discontinued pricing options.<br /><br>Default: **false** |
| `requestIncludeSaleInContractOnly` | `?bool` | Query, Optional | When `true`, indicates that the filtered pricing option list includes sale in contract only pricing options.<br /><br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | When specified, for each returned pricing option, `TaxRate` and `TaxIncluded` are calculated according to the specified location. Note that this does not filter results to only services provided at the given location, and for locations where Value-Added Tax (VAT) rules apply, the `TaxRate` is set to zero. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | Filters to pricing options with the specified program IDs. |
| `requestSellOnline` | `?bool` | Query, Optional | When `true`, filters to the pricing options that can be sold online.<br /><br>Default: **false** |
| `requestServiceIds` | `?(string[])` | Query, Optional | Filters to the pricing options with the specified IDs. In this context, service and pricing option are used interchangeably. These are the `PurchasedItems[].Id` returned from GET Sales. |
| `requestSessionTypeIds` | `?(int[])` | Query, Optional | Filters to the pricing options with the specified session types IDs. |
| `requestStaffId` | `?int` | Query, Optional | Sets `Price` and `OnlinePrice` to the particular pricing of a specific staff member, if allowed by the business. |

## Response Type

[`GetServicesResponse`](../../doc/models/get-services-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestClassId = 206;

$requestClassScheduleId = 226;

$requestHideRelatedPrograms = false;

$requestIncludeDiscontinued = false;

$requestIncludeSaleInContractOnly = false;

$requestLimit = 62;

$requestLocationId = 90;

$requestOffset = 100;

$requestProgramIds = [
    91,
    92,
    93
];

$requestSellOnline = false;

$requestServiceIds = [
    'request.serviceIds6',
    'request.serviceIds7',
    'request.serviceIds8'
];

$requestSessionTypeIds = [
    228,
    229
];

$requestStaffId = 180;

$result = $saleController->getServices(
    $version,
    $siteId,
    $authorization,
    $requestClassId,
    $requestClassScheduleId,
    $requestHideRelatedPrograms,
    $requestIncludeDiscontinued,
    $requestIncludeSaleInContractOnly,
    $requestLimit,
    $requestLocationId,
    $requestOffset,
    $requestProgramIds,
    $requestSellOnline,
    $requestServiceIds,
    $requestSessionTypeIds,
    $requestStaffId
);
```


# Update Services

Update unit price and online price of provided services.

:information_source: **Note** This endpoint does not require authentication.

```php
function updateServices(
    string $version,
    string $siteId,
    array $updateServicesRequest,
    ?string $authorization = null
): UpdateServiceResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateServicesRequest` | [`UpdateServiceRequest[]`](../../doc/models/update-service-request.md) | Body, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateServiceResponse`](../../doc/models/update-service-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$updateServicesRequest = [
    UpdateServiceRequestBuilder::init()
        ->barcodeId('BarcodeId8')
        ->price(176.98)
        ->onlinePrice(211.5)
        ->build()
];

$authorization = 'authorization6';

$result = $saleController->updateServices(
    $version,
    $siteId,
    $updateServicesRequest,
    $authorization
);
```


# Get Transactions

This endpoint returns a list of transaction details of processed sales.

:information_source: **Note** This endpoint does not require authentication.

```php
function getTransactions(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientId = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?int $requestSaleId = null,
    ?string $requestStatus = null,
    ?\DateTime $requestTransactionEndDateTime = null,
    ?int $requestTransactionId = null,
    ?\DateTime $requestTransactionStartDateTime = null
): GetTransactionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientId` | `?int` | Query, Optional | Filters results to the requested client ID. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | Filters the transaction results with the ID number associated with the location of the sale. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSaleId` | `?int` | Query, Optional | Filters the transaction results with the ID number associated with the sale. |
| `requestStatus` | `?string` | Query, Optional | Filters the transaction results by the estimated transaction status. |
| `requestTransactionEndDateTime` | `?DateTime` | Query, Optional | Filters the transaction results that happpened before this date and time.<br>Default: **today’s date** |
| `requestTransactionId` | `?int` | Query, Optional | Filters the transaction results with the ID number generated when the sale is processed. |
| `requestTransactionStartDateTime` | `?DateTime` | Query, Optional | Filters the transaction results that happpened after this date and time.<br>Default: **today’s date** |

## Response Type

[`GetTransactionsResponse`](../../doc/models/get-transactions-response.md)

## Example Usage

```php
$version = '6';

$siteId = '-99';

$authorization = 'authorization6';

$requestClientId = 222;

$requestLimit = 62;

$requestLocationId = 90;

$requestOffset = 100;

$requestSaleId = 32;

$requestStatus = 'request.status2';

$requestTransactionEndDateTime = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$requestTransactionId = 200;

$requestTransactionStartDateTime = DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z');

$result = $saleController->getTransactions(
    $version,
    $siteId,
    $authorization,
    $requestClientId,
    $requestLimit,
    $requestLocationId,
    $requestOffset,
    $requestSaleId,
    $requestStatus,
    $requestTransactionEndDateTime,
    $requestTransactionId,
    $requestTransactionStartDateTime
);
```


# Checkout Shopping Cart

This endpoint provides a wide range of functionality. For example, you can use it when a client purchases new pricing options, retail products, packages, and tips. You can also combine purchasing a new pricing option and many other functions, such as booking a client into a class, booking a new appointment for a client, enrolling a client into an enrollment or course, or reconciling an unpaid, already booked appointment or class. Use this call when a client purchases:

* a pricing option, after calling `GET Services` and choosing a specific pricing option’s ID
* a retail product, after calling `GET Products` and choosing a specific retail product’s ID
* a package, after calling `GET Packages` and choosing a specific package’s ID
* a tip to give to a staff member, after calling `GET Staff` and choosing a specific staff member ID, and the amount that the client wants to tip
  The documentation provides explanations of the request body and response, as well as the cart item metadata, payment item metadata, and purchased cart items.
  This endpoint had been updated to support Strong Customer Authentication (SCA).
  **Note :**
  Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

:information_source: **Note** This endpoint does not require authentication.

```php
function checkoutShoppingCart(
    string $version,
    CheckoutShoppingCartRequest $request,
    string $siteId,
    ?string $authorization = null
): CheckoutShoppingCartResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`CheckoutShoppingCartRequest`](../../doc/models/checkout-shopping-cart-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`CheckoutShoppingCartResponse`](../../doc/models/checkout-shopping-cart-response.md)

## Example Usage

```php
$version = '6';

$request = CheckoutShoppingCartRequestBuilder::init(
    'ClientId0',
    [
        CheckoutItemWrapperBuilder::init()
            ->item(
                CheckoutItemBuilder::init()
                    ->type('Type2')
                    ->metadata(
                        [
                            'key0' => ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                        ]
                    )
                    ->build()
            )
            ->discountAmount(41.36)
            ->appointmentBookingRequests(
                [
                    CheckoutAppointmentBookingRequestBuilder::init()
                        ->staffId(16)
                        ->locationId(66)
                        ->sessionTypeId(166)
                        ->resources(
                            [
                                ResourceSlimBuilder::init()
                                    ->id(216)
                                    ->name('Name6')
                                    ->build(),
                                ResourceSlimBuilder::init()
                                    ->id(216)
                                    ->name('Name6')
                                    ->build(),
                                ResourceSlimBuilder::init()
                                    ->id(216)
                                    ->name('Name6')
                                    ->build()
                            ]
                        )
                        ->startDateTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
                        ->build()
                ]
            )
            ->enrollmentIds(
                [
                    249,
                    250
                ]
            )
            ->classIds(
                [
                    153,
                    154,
                    155
                ]
            )
            ->build(),
        CheckoutItemWrapperBuilder::init()
            ->item(
                CheckoutItemBuilder::init()
                    ->type('Type2')
                    ->metadata(
                        [
                            'key0' => ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                        ]
                    )
                    ->build()
            )
            ->discountAmount(41.36)
            ->appointmentBookingRequests(
                [
                    CheckoutAppointmentBookingRequestBuilder::init()
                        ->staffId(16)
                        ->locationId(66)
                        ->sessionTypeId(166)
                        ->resources(
                            [
                                ResourceSlimBuilder::init()
                                    ->id(216)
                                    ->name('Name6')
                                    ->build(),
                                ResourceSlimBuilder::init()
                                    ->id(216)
                                    ->name('Name6')
                                    ->build(),
                                ResourceSlimBuilder::init()
                                    ->id(216)
                                    ->name('Name6')
                                    ->build()
                            ]
                        )
                        ->startDateTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
                        ->build()
                ]
            )
            ->enrollmentIds(
                [
                    249,
                    250
                ]
            )
            ->classIds(
                [
                    153,
                    154,
                    155
                ]
            )
            ->build(),
        CheckoutItemWrapperBuilder::init()
            ->item(
                CheckoutItemBuilder::init()
                    ->type('Type2')
                    ->metadata(
                        [
                            'key0' => ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                        ]
                    )
                    ->build()
            )
            ->discountAmount(41.36)
            ->appointmentBookingRequests(
                [
                    CheckoutAppointmentBookingRequestBuilder::init()
                        ->staffId(16)
                        ->locationId(66)
                        ->sessionTypeId(166)
                        ->resources(
                            [
                                ResourceSlimBuilder::init()
                                    ->id(216)
                                    ->name('Name6')
                                    ->build(),
                                ResourceSlimBuilder::init()
                                    ->id(216)
                                    ->name('Name6')
                                    ->build(),
                                ResourceSlimBuilder::init()
                                    ->id(216)
                                    ->name('Name6')
                                    ->build()
                            ]
                        )
                        ->startDateTime(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
                        ->build()
                ]
            )
            ->enrollmentIds(
                [
                    249,
                    250
                ]
            )
            ->classIds(
                [
                    153,
                    154,
                    155
                ]
            )
            ->build()
    ],
    [
        CheckoutPaymentInfoBuilder::init()
            ->type('Type8')
            ->metadata(
                [
                    'key0' => ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    'key1' => ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                ]
            )
            ->build(),
        CheckoutPaymentInfoBuilder::init()
            ->type('Type8')
            ->metadata(
                [
                    'key0' => ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    'key1' => ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                ]
            )
            ->build(),
        CheckoutPaymentInfoBuilder::init()
            ->type('Type8')
            ->metadata(
                [
                    'key0' => ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
                    'key1' => ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
                ]
            )
            ->build()
    ]
)
    ->cartId('CartId0')
    ->test(false)
    ->inStore(false)
    ->calculateTax(false)
    ->promotionCode('PromotionCode2')
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $saleController->checkoutShoppingCart(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Initialize Credit Card Entry

**Note**:  
Referer is a DomainURL which will be automatically reflected if the Card UI is loaded via your application.
If you are using this endpoint via postman then you need to specify your domain URL under Referer.

:information_source: **Note** This endpoint does not require authentication.

```php
function initializeCreditCardEntry(
    string $version,
    InitializeCreditCardEntryRequest $request,
    string $siteId,
    ?string $authorization = null
): InitializeCreditCardEntryResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`InitializeCreditCardEntryRequest`](../../doc/models/initialize-credit-card-entry-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`InitializeCreditCardEntryResponse`](../../doc/models/initialize-credit-card-entry-response.md)

## Example Usage

```php
$version = '6';

$request = InitializeCreditCardEntryRequestBuilder::init()
    ->merchantAccountId('MerchantAccountId4')
    ->locationId(238)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $saleController->initializeCreditCardEntry(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Purchase Account Credit

Allows a client to purchase account credit from a business.

:information_source: **Note** This endpoint does not require authentication.

```php
function purchaseAccountCredit(
    string $version,
    PurchaseAccountCreditRequest $request,
    string $siteId,
    ?string $authorization = null
): PurchaseAccountCreditResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`PurchaseAccountCreditRequest`](../../doc/models/purchase-account-credit-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`PurchaseAccountCreditResponse`](../../doc/models/purchase-account-credit-response.md)

## Example Usage

```php
$version = '6';

$request = PurchaseAccountCreditRequestBuilder::init(
    'ClientId0'
)
    ->test(false)
    ->locationId(238)
    ->sendEmailReceipt(false)
    ->salesRepId(232)
    ->consumerPresent(false)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $saleController->purchaseAccountCredit(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Purchase Contract

Allows a client to sign up for a contract or autopay using the information returned from the `GET Contracts` endpoint. The client can pay with a new credit card or with a stored credit card. The client must exist at the site specified before this call is made.

This endpoint allows a developer to specify whether a client pays now or pays on the `StartDate`.If you are building a client-facing experience, you should talk with the business owner to understand the owner’s policies before you give clients a choice of the two payment types.
This endpoint had been updated to support Strong Customer Authentication (SCA).

**Note**
Protect yourself from processor fees and credit card fraud. Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

:information_source: **Note** This endpoint does not require authentication.

```php
function purchaseContract(
    string $version,
    PurchaseContractRequest $request,
    string $siteId,
    ?string $authorization = null
): PurchaseContractResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`PurchaseContractRequest`](../../doc/models/purchase-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`PurchaseContractResponse`](../../doc/models/purchase-contract-response.md)

## Example Usage

```php
$version = '6';

$request = PurchaseContractRequestBuilder::init(
    'ClientId0',
    168
)
    ->test(false)
    ->locationId(238)
    ->startDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->firstPaymentOccurs('FirstPaymentOccurs0')
    ->clientSignature('ClientSignature4')
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $saleController->purchaseContract(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Purchase Gift Card

Allows a client to purchase a gift card from a business in a variety of designs. The card can be emailed to the recipient on a specific day, and a card title and a personal message can be added.
**Note**
Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

:information_source: **Note** This endpoint does not require authentication.

```php
function purchaseGiftCard(
    string $version,
    PurchaseGiftCardRequest $request,
    string $siteId,
    ?string $authorization = null
): PurchaseGiftCardResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`PurchaseGiftCardRequest`](../../doc/models/purchase-gift-card-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`PurchaseGiftCardResponse`](../../doc/models/purchase-gift-card-response.md)

## Example Usage

```php
$version = '6';

$request = PurchaseGiftCardRequestBuilder::init(
    238,
    'PurchaserClientId6',
    222
)
    ->test(false)
    ->layoutId(220)
    ->sendEmailReceipt(false)
    ->recipientEmail('RecipientEmail2')
    ->recipientName('RecipientName2')
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $saleController->purchaseGiftCard(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Return Sale

Return a comped sale for a specified sale ID in business mode. The sale is returnable only if it is a sale of a service, product or gift card and it has not been used. Currently, only the comp payment method is supported.

:information_source: **Note** This endpoint does not require authentication.

```php
function returnSale(
    string $version,
    ReturnSaleRequest $returnSaleRequest,
    string $siteId,
    ?string $authorization = null
): ReturnSaleResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `returnSaleRequest` | [`ReturnSaleRequest`](../../doc/models/return-sale-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`ReturnSaleResponse`](../../doc/models/return-sale-response.md)

## Example Usage

```php
$version = '6';

$returnSaleRequest = ReturnSaleRequestBuilder::init()
    ->saleId(6)
    ->returnReason('ReturnReason8')
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $saleController->returnSale(
    $version,
    $returnSaleRequest,
    $siteId,
    $authorization
);
```


# Update Product Price

This endpoint updates the retail price and an online price for a product. Passing at least one of them is mandatory.

:information_source: **Note** This endpoint does not require authentication.

```php
function updateProductPrice(
    string $version,
    UpdateProductPriceRequest $request,
    string $siteId,
    ?string $authorization = null
): UpdateProductPriceResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateProductPriceRequest`](../../doc/models/update-product-price-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateProductPriceResponse`](../../doc/models/update-product-price-response.md)

## Example Usage

```php
$version = '6';

$request = UpdateProductPriceRequestBuilder::init()
    ->barcodeId('BarcodeId6')
    ->price(195.96)
    ->onlinePrice(230.48)
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $saleController->updateProductPrice(
    $version,
    $request,
    $siteId,
    $authorization
);
```


# Update Sale Date

This endpoint updates the SaleDate and returns the details of the sale.

:information_source: **Note** This endpoint does not require authentication.

```php
function updateSaleDate(
    string $version,
    UpdateSaleDateRequest $request,
    string $siteId,
    ?string $authorization = null
): UpdateSaleDateResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateSaleDateRequest`](../../doc/models/update-sale-date-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`UpdateSaleDateResponse`](../../doc/models/update-sale-date-response.md)

## Example Usage

```php
$version = '6';

$request = UpdateSaleDateRequestBuilder::init()
    ->saleID(232)
    ->saleDate(DateTimeHelper::fromRfc3339DateTime('2016-03-13T12:52:32.123Z'))
    ->build();

$siteId = '-99';

$authorization = 'authorization6';

$result = $saleController->updateSaleDate(
    $version,
    $request,
    $siteId,
    $authorization
);
```

