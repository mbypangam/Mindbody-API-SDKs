# Sale

```php
$saleController = $client->getSaleController();
```

## Class Name

`SaleController`

## Methods

* [Sale Get Products](../../doc/controllers/sale.md#sale-get-products)
* [Sale Get Sales](../../doc/controllers/sale.md#sale-get-sales)
* [Sale Return Sale](../../doc/controllers/sale.md#sale-return-sale)
* [Sale Purchase Contract](../../doc/controllers/sale.md#sale-purchase-contract)
* [Sale Checkout Shopping Cart](../../doc/controllers/sale.md#sale-checkout-shopping-cart)
* [Sale Get Gift Cards](../../doc/controllers/sale.md#sale-get-gift-cards)
* [Sale Get Services](../../doc/controllers/sale.md#sale-get-services)
* [Sale Update Services](../../doc/controllers/sale.md#sale-update-services)
* [Sale Get Products Inventory](../../doc/controllers/sale.md#sale-get-products-inventory)
* [Sale Get Accepted Card Types](../../doc/controllers/sale.md#sale-get-accepted-card-types)
* [Sale Get Contracts](../../doc/controllers/sale.md#sale-get-contracts)
* [Sale Get Custom Payment Methods](../../doc/controllers/sale.md#sale-get-custom-payment-methods)
* [Sale Purchase Account Credit](../../doc/controllers/sale.md#sale-purchase-account-credit)
* [Sale Purchase Gift Card](../../doc/controllers/sale.md#sale-purchase-gift-card)
* [Sale Get Packages](../../doc/controllers/sale.md#sale-get-packages)
* [Sale Get Gift Card Balance](../../doc/controllers/sale.md#sale-get-gift-card-balance)
* [Sale Get Transactions](../../doc/controllers/sale.md#sale-get-transactions)
* [Sale Update Product Price](../../doc/controllers/sale.md#sale-update-product-price)
* [Sale Update Sale Date](../../doc/controllers/sale.md#sale-update-sale-date)
* [Sale Initialize Credit Card Entry](../../doc/controllers/sale.md#sale-initialize-credit-card-entry)


# Sale Get Products

Get retail products available for purchase at a site.

```php
function saleGetProducts(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestCategoryIds = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?array $requestProductIds = null,
    ?string $requestSearchText = null,
    ?bool $requestSellOnline = null,
    ?array $requestSubCategoryIds = null
): MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestCategoryIds` | `?(int[])` | Query, Optional | A list of revenue category IDs to filter by. Use this ID when calling the GET Categories endpoint.<br><br>**Note:** The values for these are not currently retrievable through the API. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | The location ID to use to determine the tax for the products that this request returns.<br /><br>Default: **online store** |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProductIds` | `?(string[])` | Query, Optional | The barcode number of the product to be filter by. |
| `requestSearchText` | `?string` | Query, Optional | A search filter, used for searching by term. |
| `requestSellOnline` | `?bool` | Query, Optional | When `true`, only products that can be sold online are returned.<br /><br>When `false`, all products are returned.<br /><br>Default: **false** |
| `requestSubCategoryIds` | `?(int[])` | Query, Optional | A list of subcategory IDs to filter by. Use this ID when calling the GET Categories endpoint.<br><br>**Note:** The values for these are not currently retrievable through the API. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-products-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->saleGetProducts($version, $siteId);
```


# Sale Get Sales

Get sales completed at a site.

```php
function saleGetSales(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?\DateTime $requestEndSaleDateTime = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?int $requestPaymentMethodId = null,
    ?int $requestSaleId = null,
    ?\DateTime $requestStartSaleDateTime = null
): MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestEndSaleDateTime` | `?\DateTime` | Query, Optional | Filters results to sales that happened before this date and time. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestPaymentMethodId` | `?int` | Query, Optional | Filters results to sales paid for by the given payment method ID which indicates payment method(s) (i.e. cash, VISA, AMEX, Check, etc.). |
| `requestSaleId` | `?int` | Query, Optional | The sale ID associated with the particular item. It Filters results to the requested sale ID. |
| `requestStartSaleDateTime` | `?\DateTime` | Query, Optional | Filters results to sales that happened after this date and time. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerGetSalesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-sales-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->saleGetSales($version, $siteId);
```


# Sale Return Sale

Return a comped sale for a specified sale ID in business mode. The sale is returnable only if it is a sale of a service, product or gift card and it has not been used. Currently, only the comp payment method is supported.

```php
function saleReturnSale(
    string $version,
    MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleRequest $returnSaleRequest,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `returnSaleRequest` | [`MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-return-sale-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-return-sale-response.md)

## Example Usage

```php
$version = '6';
$returnSaleRequest = new Models\MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleRequest();
$siteId = '-99';

$result = $saleController->saleReturnSale($version, $returnSaleRequest, $siteId);
```


# Sale Purchase Contract

Allows a client to sign up for a contract or autopay using the information returned from the `GET Contracts` endpoint. The client can pay with a new credit card or with a stored credit card. The client must exist at the site specified before this call is made.

This endpoint allows a developer to specify whether a client pays now or pays on the `StartDate`.If you are building a client-facing experience, you should talk with the business owner to understand the owner’s policies before you give clients a choice of the two payment types.
This endpoint had been updated to support Strong Customer Authentication (SCA).

**Note**
Protect yourself from processor fees and credit card fraud. Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

```php
function salePurchaseContract(
    string $version,
    MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-contract-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_contractId = 168;
$request = new Models\MindbodyPublicApiDtoModelsV6SaleControllerPurchaseContractRequest(
    $request_clientId,
    $request_contractId
);
$siteId = '-99';

$result = $saleController->salePurchaseContract($version, $request, $siteId);
```


# Sale Checkout Shopping Cart

This endpoint provides a wide range of functionality. For example, you can use it when a client purchases new pricing options, retail products, packages, and tips. You can also combine purchasing a new pricing option and many other functions, such as booking a client into a class, booking a new appointment for a client, enrolling a client into an enrollment or course, or reconciling an unpaid, already booked appointment or class. Use this call when a client purchases:

* a pricing option, after calling `GET Services` and choosing a specific pricing option’s ID
* a retail product, after calling `GET Products` and choosing a specific retail product’s ID
* a package, after calling `GET Packages` and choosing a specific package’s ID
* a tip to give to a staff member, after calling `GET Staff` and choosing a specific staff member ID, and the amount that the client wants to tip
  The documentation provides explanations of the request body and response, as well as the cart item metadata, payment item metadata, and purchased cart items.
  This endpoint had been updated to support Strong Customer Authentication (SCA).
  **Note :**
  Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

```php
function saleCheckoutShoppingCart(
    string $version,
    MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutShoppingCartRequest $request,
    string $siteId,
    ?string $authorization = null
): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutShoppingCartRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-checkout-request-checkout-shopping-cart-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`array`

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request_items = [];

$request_items[0] = new Models\MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutItemWrapper();

$request_items[1] = new Models\MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutItemWrapper();

$request_items[2] = new Models\MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutItemWrapper();

$request_payments = [];

$request_payments[0] = new Models\MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo();

$request_payments[1] = new Models\MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo();

$request_payments[2] = new Models\MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestPaymentsCheckoutPaymentInfo();

$request = new Models\MindbodyPublicApiDtoModelsV6SaleControllerCheckoutRequestCheckoutShoppingCartRequest(
    $request_clientId,
    $request_items,
    $request_payments
);
$siteId = '-99';

$result = $saleController->saleCheckoutShoppingCart($version, $request, $siteId);
```


# Sale Get Gift Cards

Returns information about gift cards that can be purchased.

```php
function saleGetGiftCards(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestIds = null,
    ?bool $requestIncludeCustomLayouts = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?bool $requestSoldOnline = null
): MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestIds` | `?(int[])` | Query, Optional | Filters the results to the requested gift card IDs.<br /><br>Default: **all** gift cards. |
| `requestIncludeCustomLayouts` | `?bool` | Query, Optional | When `true`, includes custom gift card layouts.<br /><br>When `false`, includes only system layouts.<br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | When included, returns gift cards that are sold at the provided location ID. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSoldOnline` | `?bool` | Query, Optional | When `true`, only returns gift cards that are sold online.<br /><br>Default: **false** |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-gift-card-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->saleGetGiftCards($version, $siteId);
```


# Sale Get Services

Get pricing options available for purchase at a site

```php
function saleGetServices(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClassId = null,
    ?int $requestClassScheduleId = null,
    ?bool $requestHideRelatedPrograms = null,
    ?bool $requestIncludeDiscontinued = null,
    ?bool $requestIncludeSaleInContractOnly = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?array $requestProgramIds = null,
    ?bool $requestSellOnline = null,
    ?array $requestServiceIds = null,
    ?array $requestSessionTypeIds = null,
    ?int $requestStaffId = null
): MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClassId` | `?int` | Query, Optional | Filters to the pricing options for the specified class ID. |
| `requestClassScheduleId` | `?int` | Query, Optional | Filters to the pricing options for the specified class schedule ID. |
| `requestHideRelatedPrograms` | `?bool` | Query, Optional | When `true`, indicates that pricing options of related programs are omitted from the response.<br /><br>Default: **false** |
| `requestIncludeDiscontinued` | `?bool` | Query, Optional | When `true`, indicates that the filtered pricing option list includes discontinued pricing options.<br /><br>Default: **false** |
| `requestIncludeSaleInContractOnly` | `?bool` | Query, Optional | When `true`, indicates that the filtered pricing option list includes sale in contract only pricing options.<br /><br>Default: **false** |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | When specified, for each returned pricing option, `TaxRate` and `TaxIncluded` are calculated according to the specified location. Note that this does not filter results to only services provided at the given location, and for locations where Value-Added Tax (VAT) rules apply, the `TaxRate` is set to zero. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `?(int[])` | Query, Optional | Filters to pricing options with the specified program IDs. |
| `requestSellOnline` | `?bool` | Query, Optional | When `true`, filters to the pricing options that can be sold online.<br /><br>Default: **false** |
| `requestServiceIds` | `?(string[])` | Query, Optional | Filters to the pricing options with the specified IDs. In this context, service and pricing option are used interchangeably. These are the `PurchasedItems[].Id` returned from GET Sales. |
| `requestSessionTypeIds` | `?(int[])` | Query, Optional | Filters to the pricing options with the specified session types IDs. |
| `requestStaffId` | `?int` | Query, Optional | Sets `Price` and `OnlinePrice` to the particular pricing of a specific staff member, if allowed by the business. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-services-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->saleGetServices($version, $siteId);
```


# Sale Update Services

Update unit price and online price of provided services.

```php
function saleUpdateServices(
    string $version,
    string $siteId,
    array $updateServicesRequest,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateServicesRequest` | [`MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceRequest[]`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-service-request.md) | Body, Required | - |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-service-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';
$updateServicesRequest = [];

$updateServicesRequest[0] = new Models\MindbodyPublicApiDtoModelsV6SaleControllerUpdateServiceRequest();


$result = $saleController->saleUpdateServices($version, $siteId, $updateServicesRequest);
```


# Sale Get Products Inventory

Get retail products inventory data available at a site.

```php
function saleGetProductsInventory(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?array $requestBarcodeIds = null,
    ?int $requestLimit = null,
    ?array $requestLocationIds = null,
    ?int $requestOffset = null,
    ?array $requestProductIds = null
): MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestBarcodeIds` | `?(string[])` | Query, Optional | When included, the response only contains details about the specified Barcode Ids. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `?(int[])` | Query, Optional | When included, the response only contains details about the specified location Ids. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestProductIds` | `?(string[])` | Query, Optional | When included, the response only contains details about the specified product Ids. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerGetProductsInventoryResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-products-inventory-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->saleGetProductsInventory($version, $siteId);
```


# Sale Get Accepted Card Types

Gets a list of card types that the site accepts. You can also use `GET Sites` to return the Site object, which contains individual accepted card types for requested sites.

This endpoint has no query parameters.The response returns a list of strings. Possible values are:

* Visa
* MasterCard
* Discover
* AMEX

```php
function saleGetAcceptedCardTypes(string $version, string $siteId, ?string $authorization = null): array
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

`string[]`

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->saleGetAcceptedCardTypes($version, $siteId);
```


# Sale Get Contracts

Returns the contracts and autopay options that are available on a location-by-location basis. Depending on the configurations established by the site, this endpoint returns options that can be used to sign up clients for recurring payments for services offered by the business.

```php
function saleGetContracts(
    string $version,
    int $requestLocationId,
    string $siteId,
    ?string $authorization = null,
    ?int $requestConsumerId = null,
    ?array $requestContractIds = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null,
    ?string $requestPromoCode = null,
    ?bool $requestSoldOnline = null
): MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestLocationId` | `int` | Query, Required | The ID of the location that has the requested contracts and AutoPay options. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestConsumerId` | `?int` | Query, Optional | The ID of the client. |
| `requestContractIds` | `?(int[])` | Query, Optional | When included, the response only contains details about the specified contract IDs. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestPromoCode` | `?string` | Query, Optional | PromoCode to apply |
| `requestSoldOnline` | `?bool` | Query, Optional | When `true`, the response only contains details about contracts and AutoPay options that can be sold online.<br>When `false`, all contracts are returned.<br>Default: **false** |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerGetContractsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-contracts-response.md)

## Example Usage

```php
$version = '6';
$requestLocationId = 90;
$siteId = '-99';

$result = $saleController->saleGetContracts($version, $requestLocationId, $siteId);
```


# Sale Get Custom Payment Methods

Get payment methods that can be used to pay for sales at a site.

```php
function saleGetCustomPaymentMethods(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestOffset = null
): MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerGetCustomPaymentMethodsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-custom-payment-methods-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->saleGetCustomPaymentMethods($version, $siteId);
```


# Sale Purchase Account Credit

Allows a client to purchase account credit from a business.

```php
function salePurchaseAccountCredit(
    string $version,
    MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-account-credit-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-account-credit-response.md)

## Example Usage

```php
$version = '6';
$request_clientId = 'ClientId0';
$request = new Models\MindbodyPublicApiDtoModelsV6SaleControllerPurchaseAccountCreditRequest(
    $request_clientId
);
$siteId = '-99';

$result = $saleController->salePurchaseAccountCredit($version, $request, $siteId);
```


# Sale Purchase Gift Card

Allows a client to purchase a gift card from a business in a variety of designs. The card can be emailed to the recipient on a specific day, and a card title and a personal message can be added.

**Note**
Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

```php
function salePurchaseGiftCard(
    string $version,
    MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-gift-card-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-purchase-gift-card-response.md)

## Example Usage

```php
$version = '6';
$request_locationId = 238;
$request_purchaserClientId = 'PurchaserClientId6';
$request_giftCardId = 222;
$request = new Models\MindbodyPublicApiDtoModelsV6SaleControllerPurchaseGiftCardRequest(
    $request_locationId,
    $request_purchaserClientId,
    $request_giftCardId
);
$siteId = '-99';

$result = $saleController->salePurchaseGiftCard($version, $request, $siteId);
```


# Sale Get Packages

A package is typically used to combine multiple services and/or products into a single offering. Staff members can check out multiple appointments while selling the package, and can discount the items included. For example, a spa might bundle a massage, a pedicure, a manicure, a facial, and a few selected beauty products into a package.

```php
function saleGetPackages(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?array $requestPackageIds = null,
    ?bool $requestSellOnline = null
): MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | The location ID to use to determine the tax for the products that this request returns.<br /><br>Default: **online store** |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestPackageIds` | `?(int[])` | Query, Optional | A list of the packages IDs to filter by. |
| `requestSellOnline` | `?bool` | Query, Optional | When `true`, only returns products that can be sold online.<br /><br>When `false`, all products are returned.<br /><br>Default: **false** |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-packages-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->saleGetPackages($version, $siteId);
```


# Sale Get Gift Card Balance

Returns a gift card’s remaining balance.

```php
function saleGetGiftCardBalance(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?string $barcodeId = null
): MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `barcodeId` | `?string` | Query, Optional | The barcode ID of the gift card for which you want the balance. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerGetGiftCardBalanceResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-gift-card-balance-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->saleGetGiftCardBalance($version, $siteId);
```


# Sale Get Transactions

This endpoint returns a list of transaction details of processed sales.

```php
function saleGetTransactions(
    string $version,
    string $siteId,
    ?string $authorization = null,
    ?int $requestClientId = null,
    ?int $requestLimit = null,
    ?int $requestLocationId = null,
    ?int $requestOffset = null,
    ?int $requestSaleId = null,
    ?string $requestStatus = null,
    ?\DateTime $requestTransactionEndDateTime = null,
    ?int $requestTransactionId = null,
    ?\DateTime $requestTransactionStartDateTime = null
): MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |
| `requestClientId` | `?int` | Query, Optional | Filters results to the requested client ID. |
| `requestLimit` | `?int` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `?int` | Query, Optional | Filters the transaction results with the ID number associated with the location of the sale. |
| `requestOffset` | `?int` | Query, Optional | Page offset, defaults to 0. |
| `requestSaleId` | `?int` | Query, Optional | Filters the transaction results with the ID number associated with the sale. |
| `requestStatus` | `?string` | Query, Optional | Filters the transaction results by the estimated transaction status. |
| `requestTransactionEndDateTime` | `?\DateTime` | Query, Optional | Filters the transaction results that happpened before this date and time.<br>Default: **today’s date** |
| `requestTransactionId` | `?int` | Query, Optional | Filters the transaction results with the ID number generated when the sale is processed. |
| `requestTransactionStartDateTime` | `?\DateTime` | Query, Optional | Filters the transaction results that happpened after this date and time.<br>Default: **today’s date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerGetTransactionsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-get-transactions-response.md)

## Example Usage

```php
$version = '6';
$siteId = '-99';

$result = $saleController->saleGetTransactions($version, $siteId);
```


# Sale Update Product Price

This endpoint updates the retail price and an online price for a product. Passing at least one of them is mandatory.

```php
function saleUpdateProductPrice(
    string $version,
    MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-product-price-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-product-price-response.md)

## Example Usage

```php
$version = '6';
$request = new Models\MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest();
$siteId = '-99';

$result = $saleController->saleUpdateProductPrice($version, $request, $siteId);
```


# Sale Update Sale Date

This endpoint updates the SaleDate and returns the details of the sale.

```php
function saleUpdateSaleDate(
    string $version,
    MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-sale-date-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-update-sale-date-response.md)

## Example Usage

```php
$version = '6';
$request = new Models\MindbodyPublicApiDtoModelsV6SaleControllerUpdateSaleDateRequest();
$siteId = '-99';

$result = $saleController->saleUpdateSaleDate($version, $request, $siteId);
```


# Sale Initialize Credit Card Entry

This endpoint returns a Callback URL which is used to load Card Element UI with the help of which user will be able to enter the card details and initiate a transaction .
The documentation provides explanations of the request body and response.

**Note**:
Note
Referer is a DomainURL which will be automatically reflected if the Card UI is loaded via your application.
If you are using this endpoint via postman then you need to specify your domain URL under Referer.

```php
function saleInitializeCreditCardEntry(
    string $version,
    MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest $request,
    string $siteId,
    ?string $authorization = null
): MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-initialize-credit-card-entry-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `?string` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-initialize-credit-card-entry-response.md)

## Example Usage

```php
$version = '6';
$request = new Models\MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest();
$siteId = '-99';

$result = $saleController->saleInitializeCreditCardEntry($version, $request, $siteId);
```

