# Enrollment

```csharp
EnrollmentController enrollmentController = client.EnrollmentController;
```

## Class Name

`EnrollmentController`

## Methods

* [Enrollment Get Enrollments](../../doc/controllers/enrollment.md#enrollment-get-enrollments)
* [Enrollment Add Client to Enrollment](../../doc/controllers/enrollment.md#enrollment-add-client-to-enrollment)
* [Enrollment Add Enrollment Schedule](../../doc/controllers/enrollment.md#enrollment-add-enrollment-schedule)
* [Enrollment Update Enrollment Schedule](../../doc/controllers/enrollment.md#enrollment-update-enrollment-schedule)


# Enrollment Get Enrollments

Returns a list of enrollments. An enrollment is a service, such as a workshop or an event, that a staff member offers to multiple students, who commit to coming to all or most of the scheduled sessions. Enrollments typically run for a limited time only.

When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:

* FirstName
* LastName
* Id
* Bio
* DisplayName
* ImageUrl

```csharp
EnrollmentGetEnrollmentsAsync(
    string version,
    string siteId,
    string authorization = null,
    List<int> requestClassScheduleIds = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<int> requestProgramIds = null,
    List<int> requestSessionTypeIds = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClassScheduleIds` | `List<int>` | Query, Optional | A list of the requested class schedule IDs. If omitted, all class schedule IDs return. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end of the date range. The response returns any active enrollments that occur on or before this day.<br /><br>Default: **StartDate** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | List of the IDs for the requested locations. If omitted, all location IDs return. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `List<int>` | Query, Optional | List of the IDs for the requested programs. If omitted, all program IDs return. |
| `requestSessionTypeIds` | `List<int>` | Query, Optional | List of the IDs for the requested session types. If omitted, all session types IDs return. |
| `requestStaffIds` | `List<long>` | Query, Optional | List of the IDs for the requested staff IDs. If omitted, all staff IDs return. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start of the date range. The response returns any active enrollments that occur on or after this day.<br /><br>Default: **today's date** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-get-enrollments-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse result = await enrollmentController.EnrollmentGetEnrollmentsAsync(version, siteId, null, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Enrollment Add Client to Enrollment

Book a client into an enrollment.

```csharp
EnrollmentAddClientToEnrollmentAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-add-client-to-enrollment-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ClassSchedule>`](../../doc/models/mindbody-public-api-dto-models-v6-class-schedule.md)

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest();
request.ClientId = "ClientId0";
request.ClassScheduleId = 36;
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6ClassSchedule result = await enrollmentController.EnrollmentAddClientToEnrollmentAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Enrollment Add Enrollment Schedule

This endpoint adds a enrollment schedule. You can require clients to sign up for the entire enrollment schedule or allow them to pick specific sessions using the AllowOpenEnrollment parameter.

```csharp
EnrollmentAddEnrollmentScheduleAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest`](../../doc/models/mindbody-public-api-dto-models-v6-add-class-enrollment-schedule-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDataModelsWrittenClassSchedulesInfo>`](../../doc/models/mindbody-public-api-data-models-written-class-schedules-info.md)

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest();
string siteId = "-99";

try
{
    MindbodyPublicApiDataModelsWrittenClassSchedulesInfo result = await enrollmentController.EnrollmentAddEnrollmentScheduleAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Enrollment Update Enrollment Schedule

```csharp
EnrollmentUpdateEnrollmentScheduleAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6UpdateClassEnrollmentScheduleRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6UpdateClassEnrollmentScheduleRequest`](../../doc/models/mindbody-public-api-dto-models-v6-update-class-enrollment-schedule-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6UpdateClassEnrollmentScheduleRequest();
string siteId = "-99";

try
{
    object result = await enrollmentController.EnrollmentUpdateEnrollmentScheduleAsync(version, request, siteId, null);
}
catch (ApiException e){};
```

