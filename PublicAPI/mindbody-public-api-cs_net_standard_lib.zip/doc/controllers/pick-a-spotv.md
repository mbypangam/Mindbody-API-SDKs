# Pick a Spotv

```csharp
PickASpotvController pickASpotvController = client.PickASpotvController;
```

## Class Name

`PickASpotvController`

## Methods

* [Pick a Spotv Class List](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-class-list)
* [Pick a Spotv Class](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-class)
* [Pick a Spotv Reservation Get](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-get)
* [Pick a Spotv Reservation Put](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-put)
* [Pick a Spotv Reservation Post](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-post)
* [Pick a Spotv Reservation Delete](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-delete)


# Pick a Spotv Class List

```csharp
PickASpotvClassListAsync(
    string version,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    object result = await pickASpotvController.PickASpotvClassListAsync(version, siteId, null);
}
catch (ApiException e){};
```


# Pick a Spotv Class

```csharp
PickASpotvClassAsync(
    string version,
    string classId,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `classId` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string classId = "classId0";
string siteId = "-99";

try
{
    object result = await pickASpotvController.PickASpotvClassAsync(version, classId, siteId, null);
}
catch (ApiException e){};
```


# Pick a Spotv Reservation Get

```csharp
PickASpotvReservationGetAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";

try
{
    object result = await pickASpotvController.PickASpotvReservationGetAsync(version, pathInfo, siteId, null);
}
catch (ApiException e){};
```


# Pick a Spotv Reservation Put

```csharp
PickASpotvReservationPutAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";

try
{
    object result = await pickASpotvController.PickASpotvReservationPutAsync(version, pathInfo, siteId, null);
}
catch (ApiException e){};
```


# Pick a Spotv Reservation Post

```csharp
PickASpotvReservationPostAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";

try
{
    object result = await pickASpotvController.PickASpotvReservationPostAsync(version, pathInfo, siteId, null);
}
catch (ApiException e){};
```


# Pick a Spotv Reservation Delete

```csharp
PickASpotvReservationDeleteAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";

try
{
    object result = await pickASpotvController.PickASpotvReservationDeleteAsync(version, pathInfo, siteId, null);
}
catch (ApiException e){};
```

