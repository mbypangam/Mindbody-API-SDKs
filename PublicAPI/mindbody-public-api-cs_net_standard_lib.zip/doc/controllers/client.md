# Client

```csharp
ClientController clientController = client.ClientController;
```

## Class Name

`ClientController`

## Methods

* [Client Get Clients](../../doc/controllers/client.md#client-get-clients)
* [Client Get Client Duplicates](../../doc/controllers/client.md#client-get-client-duplicates)
* [Client Get Client Formula Notes](../../doc/controllers/client.md#client-get-client-formula-notes)
* [Client Delete Client Formula Note](../../doc/controllers/client.md#client-delete-client-formula-note)
* [Client Add Formula Note](../../doc/controllers/client.md#client-add-formula-note)
* [Client Upload Client Document](../../doc/controllers/client.md#client-upload-client-document)
* [Client Upload Client Photo](../../doc/controllers/client.md#client-upload-client-photo)
* [Client Get Client Contracts](../../doc/controllers/client.md#client-get-client-contracts)
* [Client Get Client Services](../../doc/controllers/client.md#client-get-client-services)
* [Client Get Client Visits](../../doc/controllers/client.md#client-get-client-visits)
* [Client Get Client Schedule](../../doc/controllers/client.md#client-get-client-schedule)
* [Client Get Active Client Memberships](../../doc/controllers/client.md#client-get-active-client-memberships)
* [Client Get Required Client Fields](../../doc/controllers/client.md#client-get-required-client-fields)
* [Client Get Client Referral Types](../../doc/controllers/client.md#client-get-client-referral-types)
* [Client Get Client Account Balances](../../doc/controllers/client.md#client-get-client-account-balances)
* [Client Get Client Purchases](../../doc/controllers/client.md#client-get-client-purchases)
* [Client Get Client Indexes](../../doc/controllers/client.md#client-get-client-indexes)
* [Client Get Custom Client Fields](../../doc/controllers/client.md#client-get-custom-client-fields)
* [Client Add Contact Log](../../doc/controllers/client.md#client-add-contact-log)
* [Client Update Contact Log](../../doc/controllers/client.md#client-update-contact-log)
* [Client Get Cross Regional Client Associations](../../doc/controllers/client.md#client-get-cross-regional-client-associations)
* [Client Add Client](../../doc/controllers/client.md#client-add-client)
* [Client Update Client](../../doc/controllers/client.md#client-update-client)
* [Client Update Client Visit](../../doc/controllers/client.md#client-update-client-visit)
* [Client Add Arrival](../../doc/controllers/client.md#client-add-arrival)
* [Client Send Password Reset Email](../../doc/controllers/client.md#client-send-password-reset-email)
* [Client Get Contact Logs](../../doc/controllers/client.md#client-get-contact-logs)
* [Client Update Client Service](../../doc/controllers/client.md#client-update-client-service)
* [Client Get Direct Debit Info](../../doc/controllers/client.md#client-get-direct-debit-info)
* [Client Delete Direct Debit Info](../../doc/controllers/client.md#client-delete-direct-debit-info)
* [Client Add Client Direct Debit Info](../../doc/controllers/client.md#client-add-client-direct-debit-info)
* [Client Get Client Rewards](../../doc/controllers/client.md#client-get-client-rewards)
* [Client Update Client Rewards](../../doc/controllers/client.md#client-update-client-rewards)
* [Client Get Client Complete Info](../../doc/controllers/client.md#client-get-client-complete-info)
* [Client Get Contact Log Types](../../doc/controllers/client.md#client-get-contact-log-types)
* [Client Delete Contact Log](../../doc/controllers/client.md#client-delete-contact-log)
* [Client Send Auto Email](../../doc/controllers/client.md#client-send-auto-email)
* [Client Get Active Clients Memberships](../../doc/controllers/client.md#client-get-active-clients-memberships)
* [Client Terminate Contract](../../doc/controllers/client.md#client-terminate-contract)
* [Client Update Client Contract Autopays](../../doc/controllers/client.md#client-update-client-contract-autopays)
* [Client Suspend Contract](../../doc/controllers/client.md#client-suspend-contract)
* [Client Merge Client](../../doc/controllers/client.md#client-merge-client)


# Client Get Clients

This endpoint requires staff user credentials. This endpoint supports pagination. See Pagination for a description of the Pagination information.

```csharp
ClientGetClientsAsync(
    string version,
    string siteId,
    string authorization = null,
    List<string> requestClientIDs = null,
    bool? requestIncludeInactive = null,
    bool? requestIsProspect = null,
    DateTime? requestLastModifiedDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    string requestSearchText = null,
    List<long> requestUniqueIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientIDs` | `List<string>` | Query, Optional | The requested client IDs.<br>Default: **all IDs** that the authenticated user’s access level allows.<br /><br>Note: You can fetch information for maximum 20 clients at once. |
| `requestIncludeInactive` | `bool?` | Query, Optional | When `true`, indicates the results to include active and inactive clients.<br /><br>When `false`, indicates that only those clients who are marked as active should be returned.<br>Default: **false** |
| `requestIsProspect` | `bool?` | Query, Optional | When `true`, filters the results to include only those clients marked as prospects for the business.<br /><br>When `false`, indicates that only those clients who are not marked prospects should be returned. |
| `requestLastModifiedDate` | `DateTime?` | Query, Optional | Filters the results to include only the clients that have been modified on or after this date. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSearchText` | `string` | Query, Optional | Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided. |
| `requestUniqueIds` | `List<long>` | Query, Optional | Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.<br>Default: **all UniqueIDs** that the authenticated user’s access level allows. |

## Response Type

[`Task<Models.GetClientsResponse>`](../../doc/models/get-clients-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    GetClientsResponse result = await clientController.ClientGetClientsAsync(version, siteId, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Duplicates

This endpoint gets client records that would be considered duplicates based on case-insensitive matching of the client’s first name, last name, and email. For there to be results, all three parameters must match a client record. This endpoint requires staff user credentials.

An empty `ClientDuplicates` object in the response from this endpoint indicates that there were no client records found that match the first name, last name, and email fields passed in.

If one client record is returned, it is not a duplicate itself, but no other client record can be created or updated that would match this client’s first name, last name, and email combination.

If more than one client record is returned, these clients are duplicates of each other.We recommend discussing with the business how they would like to resolve duplicate records in the event the response contains more than one client record.Businesses can use the Merge Duplicate Clients tool in the Core Business Mode software to resolve the duplicate client records.

```csharp
ClientGetClientDuplicatesAsync(
    string version,
    string siteId,
    string authorization = null,
    string requestEmail = null,
    string requestFirstName = null,
    string requestLastName = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEmail` | `string` | Query, Optional | The client email to match on when searching for duplicates. |
| `requestFirstName` | `string` | Query, Optional | The client first name to match on when searching for duplicates. |
| `requestLastName` | `string` | Query, Optional | The client last name to match on when searching for duplicates. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetClientDuplicatesResponse>`](../../doc/models/get-client-duplicates-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    GetClientDuplicatesResponse result = await clientController.ClientGetClientDuplicatesAsync(version, siteId, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Formula Notes

***QueryParams***: Enables to retrieve cross regional formula notes for a client, or for a specific appointment. The two parameters are optional, however at least one must be provided. This endpoint supports pagination.

```csharp
ClientGetClientFormulaNotesAsync(
    string version,
    string siteId,
    string authorization = null,
    long? requestAppointmentId = null,
    string requestClientId = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentId` | `long?` | Query, Optional | The appointment ID of an appointment in the studio specified in the header of the request. |
| `requestClientId` | `string` | Query, Optional | The client ID of the client whose formula notes are being requested. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetClientFormulaNotesResponse>`](../../doc/models/get-client-formula-notes-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    GetClientFormulaNotesResponse result = await clientController.ClientGetClientFormulaNotesAsync(version, siteId, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Delete Client Formula Note

This endpoint deletes an existing formula note. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.

```csharp
ClientDeleteClientFormulaNoteAsync(
    string version,
    string requestClientId,
    long requestFormulaNoteId,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The client ID of the client whose formula note needs to be deleted. |
| `requestFormulaNoteId` | `long` | Query, Required | The formula note ID for the note to be deleted. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

`Task`

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
long requestFormulaNoteId = 72L;
string siteId = "-99";

try
{
    await clientController.ClientDeleteClientFormulaNoteAsync(version, requestClientId, requestFormulaNoteId, siteId, null, null, null);
}
catch (ApiException e){};
```


# Client Add Formula Note

This endpoint adds a formula note for a specified client or specified client appointment. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.

```csharp
ClientAddFormulaNoteAsync(
    string version,
    Models.AddFormulaNoteRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.AddFormulaNoteRequest`](../../doc/models/add-formula-note-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.FormulaNoteResponse>`](../../doc/models/formula-note-response.md)

## Example Usage

```csharp
string version = "6";
var request = new AddFormulaNoteRequest();
request.ClientId = "ClientId0";
request.Note = "Note6";
string siteId = "-99";

try
{
    FormulaNoteResponse result = await clientController.ClientAddFormulaNoteAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Upload Client Document

Uploads a document file for a specific client. Returns a string representation of the image byte array. The maximum size file that can be uploaded is **4MB**.

```csharp
ClientUploadClientDocumentAsync(
    string version,
    Models.UploadClientDocumentRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.UploadClientDocumentRequest`](../../doc/models/upload-client-document-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UploadClientDocumentResponse>`](../../doc/models/upload-client-document-response.md)

## Example Usage

```csharp
string version = "6";
var request = new UploadClientDocumentRequest();
request.ClientId = "ClientId0";
request.File = new MindbodyPublicApiDtoModelsV6ClientDocument();
request.File.FileName = "FileName2";
request.File.MediaType = "MediaType2";
request.File.Buffer = "Buffer4";
string siteId = "-99";

try
{
    UploadClientDocumentResponse result = await clientController.ClientUploadClientDocumentAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Upload Client Photo

Uploads a client’s profile photo. The maximum file size is 4 MB and acceptable file types are:

* bmp
* jpeg
* gif
* tiff
* png

```csharp
ClientUploadClientPhotoAsync(
    string version,
    Models.UploadClientPhotoRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.UploadClientPhotoRequest`](../../doc/models/upload-client-photo-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UploadClientPhotoResponse>`](../../doc/models/upload-client-photo-response.md)

## Example Usage

```csharp
string version = "6";
var request = new UploadClientPhotoRequest();
request.Bytes = "Bytes6";
request.ClientId = "ClientId0";
string siteId = "-99";

try
{
    UploadClientPhotoResponse result = await clientController.ClientUploadClientPhotoAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Get Client Contracts

Get contracts that a client has purchased.

```csharp
ClientGetClientContractsAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Determines how many sites are skipped over when retrieving a client’s cross regional contracts. Used when a client ID is linked to more than ten sites in an organization. Only a maximum of ten site databases are queried when this call is made and `CrossRegionalLookup` is set to `true`. To change which sites are queried, change this offset value.<br>Default: **0** |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | When `true`, indicates that the requesting client’s cross regional contracts are returned, if any.<br /><br>When `false`, indicates that cross regional contracts are not returned. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetClientContractsResponse>`](../../doc/models/get-client-contracts-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";

try
{
    GetClientContractsResponse result = await clientController.ClientGetClientContractsAsync(version, requestClientId, siteId, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Services

Get pricing options that a client has purchased.

```csharp
ClientGetClientServicesAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    int? requestClassId = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    DateTime? requestEndDate = null,
    bool? requestIgnoreCrossRegionalSiteLimit = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<int> requestProgramIds = null,
    int? requestSessionTypeId = null,
    bool? requestShowActiveOnly = null,
    DateTime? requestStartDate = null,
    int? requestVisitCount = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client to query. The results are a list of pricing options that the client has purchased. Note that “service” and “pricing option” are synonymous in this section of the documentation. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClassId` | `int?` | Query, Optional | Filters results to only those pricing options that can be used to pay for this class. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters results to pricing options that are valid on or before this date.<br>Default: **today’s date** |
| `requestIgnoreCrossRegionalSiteLimit` | `bool?` | Query, Optional | Used to specify if the number of cross regional sites used to search for client’s pricing options should be ignored.<br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | Filters results to pricing options that can be used at the listed location IDs. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `List<int>` | Query, Optional | Filters results to pricing options that belong to one of the given program IDs. |
| `requestSessionTypeId` | `int?` | Query, Optional | Filters results to pricing options that will pay for the given session type ID. Use this to find pricing options that will pay for a specific appointment type. |
| `requestShowActiveOnly` | `bool?` | Query, Optional | When `true`, includes active services only.<br>Default: **false** |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters results to pricing options that are valid on or after this date.<br>Default: **today’s date** |
| `requestVisitCount` | `int?` | Query, Optional | A filter on the minimum number of visits a service can pay for. |

## Response Type

[`Task<Models.GetClientServicesResponse>`](../../doc/models/get-client-services-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";

try
{
    GetClientServicesResponse result = await clientController.ClientGetClientServicesAsync(version, requestClientId, siteId, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Visits

Gets the Client Visits for a specific client.

```csharp
ClientGetClientVisitsAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    DateTime? requestStartDate = null,
    bool? requestUnpaidsOnly = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the requested client. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br /><br>When `false`, indicates that only visits at the current site are returned. |
| `requestEndDate` | `DateTime?` | Query, Optional | The date past which class visits are not returned.<br>Default: **today’s date** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `DateTime?` | Query, Optional | The date before which class visits are not returned.<br>Default: **the end date** |
| `requestUnpaidsOnly` | `bool?` | Query, Optional | When `true`, indicates that only visits that have not been paid for are returned.<br /><br>When `false`, indicates that all visits are returned, regardless of whether they have been paid for.<br /><br>Default: **false** |

## Response Type

[`Task<Models.GetClientVisitsResponse>`](../../doc/models/get-client-visits-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";

try
{
    GetClientVisitsResponse result = await clientController.ClientGetClientVisitsAsync(version, requestClientId, siteId, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Schedule

This endpoint can be utilized to retrieve scheduled visits which is associated with the requested client.

```csharp
ClientGetClientScheduleAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the requested client. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | The number of sites to skip when returning the site associated with a client. |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br>When `false`, indicates that only visits at the current site are returned. |
| `requestEndDate` | `DateTime?` | Query, Optional | The date past which class visits are not returned.<br>Default is today’s date |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `DateTime?` | Query, Optional | The date before which class visits are not returned.<br>Default is the end date |

## Response Type

[`Task<Models.GetClientScheduleResponse>`](../../doc/models/get-client-schedule-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";

try
{
    GetClientScheduleResponse result = await clientController.ClientGetClientScheduleAsync(version, requestClientId, siteId, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Active Client Memberships

Please note that client memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.

```csharp
ClientGetActiveClientMembershipsAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client for whom memberships are returned. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetActiveClientMembershipsResponse>`](../../doc/models/get-active-client-memberships-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";

try
{
    GetActiveClientMembershipsResponse result = await clientController.ClientGetActiveClientMembershipsAsync(version, requestClientId, siteId, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Required Client Fields

Gets the list of fields that a new client has to fill out in business mode, specifically for the sign-up process. `AddClient` and `UpdateClient` validate against these fields.

This endpoint has no query parameters.

```csharp
ClientGetRequiredClientFieldsAsync(
    string version,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetRequiredClientFieldsResponse>`](../../doc/models/get-required-client-fields-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    GetRequiredClientFieldsResponse result = await clientController.ClientGetRequiredClientFieldsAsync(version, siteId, null);
}
catch (ApiException e){};
```


# Client Get Client Referral Types

Gets a list of referral types. Referral types are options that new clients can choose to identify how they learned about the business. Referral types are typically used for the sign-up process.

```csharp
ClientGetClientReferralTypesAsync(
    string version,
    string siteId,
    string authorization = null,
    bool? requestIncludeInactive = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestIncludeInactive` | `bool?` | Query, Optional | When `true`, filters the results to include subtypes and inactive referral types.<br /><br>When `false`, includes no subtypes and only active types.<br>Default:**false** |

## Response Type

[`Task<Models.GetClientReferralTypesResponse>`](../../doc/models/get-client-referral-types-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    GetClientReferralTypesResponse result = await clientController.ClientGetClientReferralTypesAsync(version, siteId, null, null);
}
catch (ApiException e){};
```


# Client Get Client Account Balances

Get account balance information for one or more client(s).

```csharp
ClientGetClientAccountBalancesAsync(
    string version,
    List<string> requestClientIds,
    string siteId,
    string authorization = null,
    DateTime? requestBalanceDate = null,
    int? requestClassId = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientIds` | `List<string>` | Query, Required | The list of clients IDs for which you want account balances. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestBalanceDate` | `DateTime?` | Query, Optional | The date you want a balance relative to.<br>Default: **the current date** |
| `requestClassId` | `int?` | Query, Optional | The class ID of the event for which you want a balance. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetClientAccountBalancesResponse>`](../../doc/models/get-client-account-balances-response.md)

## Example Usage

```csharp
string version = "6";
var requestClientIds = new List<string>();
requestClientIds.Add("request.clientIds9");
requestClientIds.Add("request.clientIds0");
requestClientIds.Add("request.clientIds1");
string siteId = "-99";

try
{
    GetClientAccountBalancesResponse result = await clientController.ClientGetClientAccountBalancesAsync(version, requestClientIds, siteId, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Purchases

Gets a list of purchases made by a specific client.

```csharp
ClientGetClientPurchasesAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    int? requestSaleId = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client you are querying for purchases. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters results to purchases made before this timestamp.<br /><br>Default: **end of today** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSaleId` | `int?` | Query, Optional | Filters results to the single record associated with this ID. |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters results to purchases made on or after this timestamp.<br /><br>Default: **now** |

## Response Type

[`Task<Models.GetClientPurchasesResponse>`](../../doc/models/get-client-purchases-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";

try
{
    GetClientPurchasesResponse result = await clientController.ClientGetClientPurchasesAsync(version, requestClientId, siteId, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Client Indexes

Client indexes are used to analyze client demographics. A business owner can set up different categories with sets of values which they can assign to each client. Client indexes are used in client searches, for tagging clients so that the owner can send mass emails to similar groups, and for many reports.

For more information, see Client Indexes and [Client Index Values (video tutorial)](https://support.mindbodyonline.com/s/article/203261653-Client-indexes-and-client-index-values-video-tutorial?language=en_USclient).

```csharp
ClientGetClientIndexesAsync(
    string version,
    string siteId,
    string authorization = null,
    bool? requestRequiredOnly = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestRequiredOnly` | `bool?` | Query, Optional | When `true`, filters the results to only indexes that are required on creation.<br /><br>When `false` or omitted, returns all of the client indexes. |

## Response Type

[`Task<Models.GetClientIndexesResponse>`](../../doc/models/get-client-indexes-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    GetClientIndexesResponse result = await clientController.ClientGetClientIndexesAsync(version, siteId, null, null);
}
catch (ApiException e){};
```


# Client Get Custom Client Fields

Get a site's configured custom client fields.

```csharp
ClientGetCustomClientFieldsAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetCustomClientFieldsResponse>`](../../doc/models/get-custom-client-fields-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    GetCustomClientFieldsResponse result = await clientController.ClientGetCustomClientFieldsAsync(version, siteId, null, null, null);
}
catch (ApiException e){};
```


# Client Add Contact Log

Add a contact log to a client's account.

```csharp
ClientAddContactLogAsync(
    string version,
    Models.AddContactLogRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.AddContactLogRequest`](../../doc/models/add-contact-log-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ContactLog>`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log.md)

## Example Usage

```csharp
string version = "6";
var request = new AddContactLogRequest();
request.ClientId = "ClientId0";
request.ContactMethod = "ContactMethod0";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6ContactLog result = await clientController.ClientAddContactLogAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Update Contact Log

Update a contact log on a client's account.

```csharp
ClientUpdateContactLogAsync(
    string version,
    Models.UpdateContactLogRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.UpdateContactLogRequest`](../../doc/models/update-contact-log-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6ContactLog>`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log.md)

## Example Usage

```csharp
string version = "6";
var request = new UpdateContactLogRequest();
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6ContactLog result = await clientController.ClientUpdateContactLogAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Get Cross Regional Client Associations

Returns a list of sites that a particular client ID (also referred to as an RSSID) or a client email address is associated with in a cross-regional organization. Either the `ClientID` or `Email` parameter is required. If both are provided, the `ClientID` is used.

Use this endpoint to retrieve information for other Public API endpoints, about the same client at multiple sites within an organization. To use this endpoint, your developer account must have been granted permission to the site’s entire organization.

Note that this endpoint does not work on the Developer Sandbox site, as it is not set up for cross-regional use cases.

```csharp
ClientGetCrossRegionalClientAssociationsAsync(
    string version,
    string siteId,
    string authorization = null,
    string requestClientId = null,
    string requestEmail = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientId` | `string` | Query, Optional | Looks up the cross regional associations by the client’s ID. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. |
| `requestEmail` | `string` | Query, Optional | Looks up the cross regional associations by the client’s email address. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetCrossRegionalClientAssociationsResponse>`](../../doc/models/get-cross-regional-client-associations-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    GetCrossRegionalClientAssociationsResponse result = await clientController.ClientGetCrossRegionalClientAssociationsAsync(version, siteId, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Add Client

Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />
Creates a new client record at the specified business.Passing a User Token as Authorization will create a client and respect Business Mode required fields.Omitting the token will create a client and respect Consumer Mode required fi elds. To make sure you are collecting all required pieces of information, first run GetRequired ClientFields.<br />
If you have purchased an Ultimate tier then this endpoint will automatically start showing new opportunity on Sales Pipeline.

```csharp
ClientAddClientAsync(
    string version,
    Models.AddClientRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.AddClientRequest`](../../doc/models/add-client-request.md) | Body, Required | The `FirstName` and `LastName` parameters are always required in this request.<br>All other parameters are optional, but note that any of the optional parameters could be required by a particular business,<br>depending on how the business has configured the site settings. If `GetRequiredClientFields` returns `EmergContact` in the list of required fields,<br>then all emergency contact parameters are required, which includes `EmergencyContactInfoEmail`, `EmergencyContactInfoName`, `EmergencyContactInfoPhone`, and `EmergencyContactInfoRelationship`. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddClientResponse>`](../../doc/models/add-client-response.md)

## Example Usage

```csharp
string version = "6";
var request = new AddClientRequest();
request.FirstName = "FirstName8";
request.LastName = "LastName8";
string siteId = "-99";

try
{
    AddClientResponse result = await clientController.ClientAddClientAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Update Client

Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />
Updates an existing client for a specific subscriber.Passing a User Token as Authorization respects Business Mode required fields.Omitting the token respects Consumer Mode required fields.To make sure you are collecting all required pieces of information, first run GetRequiredClientFields..Use this endpoint as follows:

* If you need to update the `ReferredBy` parameter, use this endpoint after calling `GET ClientReferralTypes`.
* When updating a client’s home location, use after calling `GET Locations`.
* If you are updating a client’s stored credit card, use after calling `GET AcceptedCardTypes` so that you can make sure the card is a type that is accepted at the subscriber.<br />

If this endpoint is used on a cross-regional site, passing in a client’s RSSID and email address creates a cross-regional link. This means that the client is created in cross-regional sites where the client does not exist and `GET CrossRegionalClientAssociations` returns all appropriate cross-regional sites. When `CrossRegionalUpdate` is omitted or set to `true`, the client’s updated information is propagated to all of the region’s sites. If `CrossRegionalUpdate` is set to `false`, only the local client is updated.

Note that the following items cannot be updated for a cross-regional client:

* `ClientIndexes`
* `ClientRelationships`
* `CustomClientFields`
* `SalesReps`
* `SendAccountEmails`
* `SendAccountTexts`
* `SendPromotionalEmails`
* `SendPromotionalTexts`
* `SendScheduleEmails`
* `SendScheduleTexts`
* `Gender` (for site custom values)

Custom client Gender options can only be created with non-cross-regional requests.

If you have purchased an Ultimate tier then this endpoint will automatically start showing a new opportunity on Sales Pipeline.It will create a new opportunity if the current request modify the contact as follows::

* You need to update the `IsProspect` parameter, to `true`.<br />
* You need to update the `ProspectStage`.`Description parameter`, to `New Lead`.<br />

Updates made to any inactive clients will automatically reactivate the client unless the `Acive` property is explicitly set to `false` in the request body.

```csharp
ClientUpdateClientAsync(
    string version,
    Models.UpdateClientRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.UpdateClientRequest`](../../doc/models/update-client-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateClientResponse>`](../../doc/models/update-client-response.md)

## Example Usage

```csharp
string version = "6";
var request = new UpdateClientRequest();
request.Client = new MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo();
string siteId = "-99";

try
{
    UpdateClientResponse result = await clientController.ClientUpdateClientAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Update Client Visit

Updates the status of the specified visit.

```csharp
ClientUpdateClientVisitAsync(
    string version,
    Models.UpdateClientVisitRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.UpdateClientVisitRequest`](../../doc/models/update-client-visit-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateClientVisitResponse>`](../../doc/models/update-client-visit-response.md)

## Example Usage

```csharp
string version = "6";
var request = new UpdateClientVisitRequest();
request.VisitId = 92;
string siteId = "-99";

try
{
    UpdateClientVisitResponse result = await clientController.ClientUpdateClientVisitAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Add Arrival

Marks a client as arrived for a specified location. A staff user token must be included with staff assigned the LaunchSignInScreen permission.

When used on a site that is part of a region, the following additional logic will apply:

* When a client exists within the region but not at the studio where the arrival is being logged, a local client record will be automatically created.
* If the local client does not have an applicable local membership or pricing option, a membership or pricing option will be automatically used if it exists elsewhere within the region.

```csharp
ClientAddArrivalAsync(
    string version,
    Models.AddArrivalRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.AddArrivalRequest`](../../doc/models/add-arrival-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddArrivalResponse>`](../../doc/models/add-arrival-response.md)

## Example Usage

```csharp
string version = "6";
var request = new AddArrivalRequest();
request.ClientId = "ClientId0";
request.LocationId = 238;
string siteId = "-99";

try
{
    AddArrivalResponse result = await clientController.ClientAddArrivalAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Send Password Reset Email

Send a password reset email to a client.

```csharp
ClientSendPasswordResetEmailAsync(
    string version,
    Models.SendPasswordResetEmailRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.SendPasswordResetEmailRequest`](../../doc/models/send-password-reset-email-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
var request = new SendPasswordResetEmailRequest();
request.UserEmail = "UserEmail2";
request.UserFirstName = "UserFirstName2";
request.UserLastName = "UserLastName8";
string siteId = "-99";

try
{
    object result = await clientController.ClientSendPasswordResetEmailAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Get Contact Logs

This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.

```csharp
ClientGetContactLogsAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    bool? requestShowSystemGenerated = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null,
    List<int> requestSubtypeIds = null,
    List<int> requestTypeIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client whose contact logs are being requested. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters the results to contact logs created before this date.<br /><br>Default: **the start date** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestShowSystemGenerated` | `bool?` | Query, Optional | When `true`, system-generated contact logs are returned in the results.<br /><br>Default: **false** |
| `requestStaffIds` | `List<long>` | Query, Optional | Filters the results to return contact logs assigned to one or more staff IDs. |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters the results to contact logs created on or after this date.<br /><br>Default: **the current date** |
| `requestSubtypeIds` | `List<int>` | Query, Optional | Filters the results to contact logs assigned one or more of these subtype IDs. |
| `requestTypeIds` | `List<int>` | Query, Optional | Filters the results to contact logs assigned one or more of these type IDs. |

## Response Type

[`Task<Models.GetContactLogsResponse>`](../../doc/models/get-contact-logs-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";

try
{
    GetContactLogsResponse result = await clientController.ClientGetContactLogsAsync(version, requestClientId, siteId, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Update Client Service

Updates the active date and/or expiration date of a client pricing option. This request requires staff user credentials. If the active date is modified, the expiration date is also modified accordingly. If the expiration date is modified, the active date is unchanged.

```csharp
ClientUpdateClientServiceAsync(
    string version,
    Models.UpdateClientServiceRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.UpdateClientServiceRequest`](../../doc/models/update-client-service-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateClientServiceResponse>`](../../doc/models/update-client-service-response.md)

## Example Usage

```csharp
string version = "6";
var request = new UpdateClientServiceRequest();
request.ServiceId = 130;
string siteId = "-99";

try
{
    UpdateClientServiceResponse result = await clientController.ClientUpdateClientServiceAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Get Direct Debit Info

This endpoint returns direct debit info stored on a client's account. This endpoint requires staff user credentials.

A null response from this endpoint indicates that the client has no usable direct debit information on their account.Use the POST AddClientDirectDebitInfo endpoint to add direct debit information to a client’s account.

```csharp
ClientGetDirectDebitInfoAsync(
    string version,
    string siteId,
    string authorization = null,
    string clientId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `clientId` | `string` | Query, Optional | The ID of the client. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6DirectDebitInfo>`](../../doc/models/mindbody-public-api-dto-models-v6-direct-debit-info.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6DirectDebitInfo result = await clientController.ClientGetDirectDebitInfoAsync(version, siteId, null, null);
}
catch (ApiException e){};
```


# Client Delete Direct Debit Info

This endpoint deletes direct debit info from a client’s account. This endpoint requires staff user credentials.

```csharp
ClientDeleteDirectDebitInfoAsync(
    string version,
    string siteId,
    string authorization = null,
    string clientId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `clientId` | `string` | Query, Optional | The ID of the client. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    object result = await clientController.ClientDeleteDirectDebitInfoAsync(version, siteId, null, null);
}
catch (ApiException e){};
```


# Client Add Client Direct Debit Info

This endpoint adds direct debit info to a client’s account. This endpoint requires staff user credentials.

```csharp
ClientAddClientDirectDebitInfoAsync(
    string version,
    Models.AddClientDirectDebitInfoRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.AddClientDirectDebitInfoRequest`](../../doc/models/add-client-direct-debit-info-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddClientDirectDebitInfoResponse>`](../../doc/models/add-client-direct-debit-info-response.md)

## Example Usage

```csharp
string version = "6";
var request = new AddClientDirectDebitInfoRequest();
string siteId = "-99";

try
{
    AddClientDirectDebitInfoResponse result = await clientController.ClientAddClientDirectDebitInfoAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Get Client Rewards

Gets the client rewards.

```csharp
ClientGetClientRewardsAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The ID of the client. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of transaction.<br>Default: **StartDate** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of transaction.<br>Default: **today** |

## Response Type

[`Task<Models.GetClientRewardsResponse>`](../../doc/models/get-client-rewards-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";

try
{
    GetClientRewardsResponse result = await clientController.ClientGetClientRewardsAsync(version, requestClientId, siteId, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Update Client Rewards

Earns or redeems rewards points for a given client, based on site settings. Cross regional rewards are not supported at this time.

```csharp
ClientUpdateClientRewardsAsync(
    string version,
    Models.UpdateClientRewardsRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.UpdateClientRewardsRequest`](../../doc/models/update-client-rewards-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetClientRewardsResponse>`](../../doc/models/get-client-rewards-response.md)

## Example Usage

```csharp
string version = "6";
var request = new UpdateClientRewardsRequest();
request.ClientId = "ClientId0";
request.Points = 10L;
request.Action = "Action6";
string siteId = "-99";

try
{
    GetClientRewardsResponse result = await clientController.ClientUpdateClientRewardsAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Get Client Complete Info

This endpoint returns complete client information along with list of purchased services, contract details, membership details and arrival programs for a specific client.

```csharp
ClientGetClientCompleteInfoAsync(
    string version,
    string requestClientId,
    string siteId,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    DateTime? requestEndDate = null,
    List<string> requestRequiredClientData = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | Filters results to client with these ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:<br><br>* Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25 |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | Used to retrieve a clients pricing options from multiple sites within an organization.When included and set to `true`,<br>it searches a maximum of ten sites with which this client is associated.When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated.<br>You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with.<br>Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters results to pricing options that are valid on or before this date. |
| `requestRequiredClientData` | `List<string>` | Query, Optional | Used to retrieve list of purchased services, contract details, membership details and arrival programs for a specific client.<br>Default `ClientServices`, `ClientContracts`, `ClientMemberships` and `ClientArrivals` will be returned when `RequiredClientDatais` not set.<br>When `RequiredClientData` is set to `Contracts` then only `ClientContracts` will be returned in the response.<br>When `RequiredClientData` is set to Services then only `ClientServices` will be returned in the response.<br>When `RequiredClientData` is set to `Memberships` then only `ClientMemberships` will be returned in the response.<br>When `RequiredClientData` is set to `ArrivalPrograms` then only `ClientArrivals` will be returned in the response. |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters results to pricing options that are valid on or after this date. |

## Response Type

[`Task<Models.GetClientCompleteInfoResponse>`](../../doc/models/get-client-complete-info-response.md)

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
string siteId = "-99";

try
{
    GetClientCompleteInfoResponse result = await clientController.ClientGetClientCompleteInfoAsync(version, requestClientId, siteId, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Get Contact Log Types

This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.

```csharp
ClientGetContactLogTypesAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestContactLogTypeId = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestContactLogTypeId` | `int?` | Query, Optional | The requested ContactLogType ID.<br>Default: **all** IDs that the authenticated user’s access level allows. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetContactLogTypesResponse>`](../../doc/models/get-contact-log-types-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    GetContactLogTypesResponse result = await clientController.ClientGetContactLogTypesAsync(version, siteId, null, null, null, null);
}
catch (ApiException e){};
```


# Client Delete Contact Log

This endpoint deletes contactlog of client. This endpoint requires staff user credentials.

```csharp
ClientDeleteContactLogAsync(
    string version,
    string requestClientId,
    long requestContactLogId,
    string siteId,
    string authorization = null,
    bool? requestTest = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientId` | `string` | Query, Required | The client ID of the client whose Contact Log is being deleted. |
| `requestContactLogId` | `long` | Query, Required | The Contact Log ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestTest` | `bool?` | Query, Optional | When `true`, indicates that this is a test request and no data is inserted into the subscriber’s database.<br>When `false`, the database is updated. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string requestClientId = "request.clientId2";
long requestContactLogId = 90L;
string siteId = "-99";

try
{
    object result = await clientController.ClientDeleteContactLogAsync(version, requestClientId, requestContactLogId, siteId, null, null);
}
catch (ApiException e){};
```


# Client Send Auto Email

This endpoint requires staff user credentials.

```csharp
ClientSendAutoEmailAsync(
    string version,
    Models.SendAutoEmailRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.SendAutoEmailRequest`](../../doc/models/send-auto-email-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
var request = new SendAutoEmailRequest();
request.ClientId = "ClientId0";
request.EmailType = "EmailType4";
string siteId = "-99";

try
{
    object result = await clientController.ClientSendAutoEmailAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Get Active Clients Memberships

The endpoint returns a list of memberships for multiple clients we pass in query parameter. Please note that clients memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.

```csharp
ClientGetActiveClientsMembershipsAsync(
    string version,
    List<string> requestClientIds,
    string siteId,
    string authorization = null,
    int? requestClientAssociatedSitesOffset = null,
    bool? requestCrossRegionalLookup = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestClientIds` | `List<string>` | Query, Required | The ID of the client for whom memberships are returned. Maximum allowed : 200. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientAssociatedSitesOffset` | `int?` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br /><br>Default: **0**<br><br>For example, if a client is associated with 25 sites, you need to call GET `ActiveClientMemberships` three times, as follows:<br><br>* Use GET `CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.<br>* Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s memberships from sites 1-10<br>* Set `ClientAssociatedSitesOffset` to 10 to return the client’s memberships from sites 11-20<br>* Set `ClientAssociatedSitesOffset` to 20 to return the client’s memberships from sites 21-25 |
| `requestCrossRegionalLookup` | `bool?` | Query, Optional | Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.<br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetActiveClientsMembershipsResponse>`](../../doc/models/get-active-clients-memberships-response.md)

## Example Usage

```csharp
string version = "6";
var requestClientIds = new List<string>();
requestClientIds.Add("request.clientIds9");
requestClientIds.Add("request.clientIds0");
requestClientIds.Add("request.clientIds1");
string siteId = "-99";

try
{
    GetActiveClientsMembershipsResponse result = await clientController.ClientGetActiveClientsMembershipsAsync(version, requestClientIds, siteId, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Client Terminate Contract

This endpoint terminates a client contract. This endpoint requires staff user credentials with TerminateClientContract permission.

```csharp
ClientTerminateContractAsync(
    string version,
    Models.TerminateContractRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.TerminateContractRequest`](../../doc/models/terminate-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.TerminateContractResponse>`](../../doc/models/terminate-contract-response.md)

## Example Usage

```csharp
string version = "6";
var request = new TerminateContractRequest();
request.ClientId = "ClientId0";
request.ClientContractId = 118;
request.TerminationDate = DateTime.Parse("2016-03-13T12:52:32.123Z");
string siteId = "-99";

try
{
    TerminateContractResponse result = await clientController.ClientTerminateContractAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Update Client Contract Autopays

```csharp
ClientUpdateClientContractAutopaysAsync(
    string version,
    Models.UpdateClientContractAutopaysRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.UpdateClientContractAutopaysRequest`](../../doc/models/update-client-contract-autopays-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6Contract>`](../../doc/models/mindbody-public-api-dto-models-v6-contract.md)

## Example Usage

```csharp
string version = "6";
var request = new UpdateClientContractAutopaysRequest();
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6Contract result = await clientController.ClientUpdateClientContractAutopaysAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Suspend Contract

Suspend client contract

```csharp
ClientSuspendContractAsync(
    string version,
    Models.SuspendContractRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.SuspendContractRequest`](../../doc/models/suspend-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.SuspendContractResponse>`](../../doc/models/suspend-contract-response.md)

## Example Usage

```csharp
string version = "6";
var request = new SuspendContractRequest();
request.ClientId = "ClientId0";
request.ClientContractId = 118;
string siteId = "-99";

try
{
    SuspendContractResponse result = await clientController.ClientSuspendContractAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Client Merge Client

```csharp
ClientMergeClientAsync(
    string version,
    Models.MergeClientsRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MergeClientsRequest`](../../doc/models/merge-clients-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
var request = new MergeClientsRequest();
string siteId = "-99";

try
{
    object result = await clientController.ClientMergeClientAsync(version, request, siteId, null);
}
catch (ApiException e){};
```

