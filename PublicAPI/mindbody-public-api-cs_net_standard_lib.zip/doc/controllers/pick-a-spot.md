# Pick a Spot

```csharp
PickASpotController pickASpotController = client.PickASpotController;
```

## Class Name

`PickASpotController`

## Methods

* [Get Class List](../../doc/controllers/pick-a-spot.md#get-class-list)
* [Get Class](../../doc/controllers/pick-a-spot.md#get-class)
* [Get Reservation](../../doc/controllers/pick-a-spot.md#get-reservation)
* [Update Reservation](../../doc/controllers/pick-a-spot.md#update-reservation)
* [Create Reservation](../../doc/controllers/pick-a-spot.md#create-reservation)
* [Delete Reservation](../../doc/controllers/pick-a-spot.md#delete-reservation)


# Get Class List

A user token is required for this endpoint.

```csharp
GetClassListAsync(
    string version,
    int pageNumber,
    int pageSize,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pageNumber` | `int` | Query, Required | Page number. |
| `pageSize` | `int` | Query, Required | Page size |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetPickASpotClassResponse>`](../../doc/models/get-pick-a-spot-class-response.md)

## Example Usage

```csharp
string version = "6";
int pageNumber = 110;
int pageSize = 118;
string siteId = "-99";

try
{
    GetPickASpotClassResponse result = await pickASpotController.GetClassListAsync(version, pageNumber, pageSize, siteId, null);
}
catch (ApiException e){};
```


# Get Class

A user token is required for this endpoint.

```csharp
GetClassAsync(
    string version,
    string classId,
    int pageNumber,
    int pageSize,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `classId` | `string` | Template, Required | - |
| `pageNumber` | `int` | Query, Required | Page number. |
| `pageSize` | `int` | Query, Required | Page size |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetPickASpotClassResponse>`](../../doc/models/get-pick-a-spot-class-response.md)

## Example Usage

```csharp
string version = "6";
string classId = "classId0";
int pageNumber = 110;
int pageSize = 118;
string siteId = "-99";

try
{
    GetPickASpotClassResponse result = await pickASpotController.GetClassAsync(version, classId, pageNumber, pageSize, siteId, null);
}
catch (ApiException e){};
```


# Get Reservation

A user token is required for this endpoint.

```csharp
GetReservationAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetReservationResponse>`](../../doc/models/get-reservation-response.md)

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";

try
{
    GetReservationResponse result = await pickASpotController.GetReservationAsync(version, pathInfo, siteId, null);
}
catch (ApiException e){};
```


# Update Reservation

A user token is required for this endpoint.

```csharp
UpdateReservationAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateReservationResponse>`](../../doc/models/update-reservation-response.md)

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";

try
{
    UpdateReservationResponse result = await pickASpotController.UpdateReservationAsync(version, pathInfo, siteId, null);
}
catch (ApiException e){};
```


# Create Reservation

A user token is required for this endpoint.

```csharp
CreateReservationAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.CreateReservationResponse>`](../../doc/models/create-reservation-response.md)

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";

try
{
    CreateReservationResponse result = await pickASpotController.CreateReservationAsync(version, pathInfo, siteId, null);
}
catch (ApiException e){};
```


# Delete Reservation

A user token is required for this endpoint.

```csharp
DeleteReservationAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.DeleteReservationResponse>`](../../doc/models/delete-reservation-response.md)

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";

try
{
    DeleteReservationResponse result = await pickASpotController.DeleteReservationAsync(version, pathInfo, siteId, null);
}
catch (ApiException e){};
```

