# Pick a Spot

```csharp
PickASpotController pickASpotController = client.PickASpotController;
```

## Class Name

`PickASpotController`

## Methods

* [Pick a Spot Class List](../../doc/controllers/pick-a-spot.md#pick-a-spot-class-list)
* [Pick a Spot Class](../../doc/controllers/pick-a-spot.md#pick-a-spot-class)
* [Pick a Spot Reservation Get](../../doc/controllers/pick-a-spot.md#pick-a-spot-reservation-get)
* [To Update a Class](../../doc/controllers/pick-a-spot.md#to-update-a-class)
* [Pick a Spot Reservation Post](../../doc/controllers/pick-a-spot.md#pick-a-spot-reservation-post)
* [Pick a Spot Reservation Delete](../../doc/controllers/pick-a-spot.md#pick-a-spot-reservation-delete)


# Pick a Spot Class List

A user token is required for this endpoint.

```csharp
PickASpotClassListAsync(
    string version,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    object result = await pickASpotController.PickASpotClassListAsync(version, siteId, null);
}
catch (ApiException e){};
```


# Pick a Spot Class

A user token is required for this endpoint.

```csharp
PickASpotClassAsync(
    string version,
    string classId,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `classId` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string classId = "classId0";
string siteId = "-99";

try
{
    object result = await pickASpotController.PickASpotClassAsync(version, classId, siteId, null);
}
catch (ApiException e){};
```


# Pick a Spot Reservation Get

A user token is required for this endpoint.

```csharp
PickASpotReservationGetAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";

try
{
    object result = await pickASpotController.PickASpotReservationGetAsync(version, pathInfo, siteId, null);
}
catch (ApiException e){};
```


# To Update a Class

A user token is required for this endpoint.

```csharp
ToUpdateAClassAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";

try
{
    object result = await pickASpotController.ToUpdateAClassAsync(version, pathInfo, siteId, null);
}
catch (ApiException e){};
```


# Pick a Spot Reservation Post

A user token is required for this endpoint.

```csharp
PickASpotReservationPostAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";

try
{
    object result = await pickASpotController.PickASpotReservationPostAsync(version, pathInfo, siteId, null);
}
catch (ApiException e){};
```


# Pick a Spot Reservation Delete

A user token is required for this endpoint.

```csharp
PickASpotReservationDeleteAsync(
    string version,
    string pathInfo,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `pathInfo` | `string` | Template, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string pathInfo = "pathInfo8";
string siteId = "-99";

try
{
    object result = await pickASpotController.PickASpotReservationDeleteAsync(version, pathInfo, siteId, null);
}
catch (ApiException e){};
```

