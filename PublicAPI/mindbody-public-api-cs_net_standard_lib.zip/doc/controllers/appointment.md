# Appointment

```csharp
AppointmentController appointmentController = client.AppointmentController;
```

## Class Name

`AppointmentController`

## Methods

* [Appointment Get Active Session Times](../../doc/controllers/appointment.md#appointment-get-active-session-times)
* [Appointment Get Add Ons](../../doc/controllers/appointment.md#appointment-get-add-ons)
* [Appointment Get Appointment Options](../../doc/controllers/appointment.md#appointment-get-appointment-options)
* [Appointment Get Available Dates](../../doc/controllers/appointment.md#appointment-get-available-dates)
* [Appointment Get Bookable Items](../../doc/controllers/appointment.md#appointment-get-bookable-items)
* [Appointment Get Schedule Items](../../doc/controllers/appointment.md#appointment-get-schedule-items)
* [Appointment Get Staff Appointments](../../doc/controllers/appointment.md#appointment-get-staff-appointments)
* [Appointment Get Unavailabilities](../../doc/controllers/appointment.md#appointment-get-unavailabilities)
* [Appointment Add Appointment](../../doc/controllers/appointment.md#appointment-add-appointment)
* [Appointment Add Appointment Add On](../../doc/controllers/appointment.md#appointment-add-appointment-add-on)
* [Appointment Update Availability](../../doc/controllers/appointment.md#appointment-update-availability)
* [Appointment Add Availabilities](../../doc/controllers/appointment.md#appointment-add-availabilities)
* [Appointment Update Appointment](../../doc/controllers/appointment.md#appointment-update-appointment)
* [Appointment Remove From Waitlist](../../doc/controllers/appointment.md#appointment-remove-from-waitlist)
* [Appointment Delete Availability](../../doc/controllers/appointment.md#appointment-delete-availability)
* [Appointment Delete Appointment Add On](../../doc/controllers/appointment.md#appointment-delete-appointment-add-on)


# Appointment Get Active Session Times

This is not appointment availability but rather the active business hours for studios and which increments services can be booked at. See BookableItems for appointment availability.

```csharp
AppointmentGetActiveSessionTimesAsync(
    string version,
    string siteId,
    string authorization = null,
    DateTime? requestEndTime = null,
    int? requestLimit = null,
    int? requestOffset = null,
    Models.RequestScheduleTypeEnum? requestScheduleType = null,
    List<int> requestSessionTypeIds = null,
    DateTime? requestStartTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndTime` | `DateTime?` | Query, Optional | Filters results to times that end on or before this time on the current date. Any date provided is ignored..<br><br />Default: **23:59:59** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestScheduleType` | [`Models.RequestScheduleTypeEnum?`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided. |
| `requestSessionTypeIds` | `List<int>` | Query, Optional | Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided. |
| `requestStartTime` | `DateTime?` | Query, Optional | Filters results to times that start on or after this time on the current date. Any date provided is ignored.<br><br />Default: **00:00:00** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-active-session-times-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetActiveSessionTimesResponse result = await appointmentController.AppointmentGetActiveSessionTimesAsync(version, siteId, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Appointment Get Add Ons

Get active appointment add-ons.

```csharp
AppointmentGetAddOnsAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null,
    int? requestStaffId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffId` | `int?` | Query, Optional | Filter to add-ons only performed by this staff member. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-add-ons-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse result = await appointmentController.AppointmentGetAddOnsAsync(version, siteId, null, null, null, null);
}
catch (ApiException e){};
```


# Appointment Get Appointment Options

This endpoint has no query parameters.

```csharp
AppointmentGetAppointmentOptionsAsync(
    string version,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-appointment-options-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetAppointmentOptionsResponse result = await appointmentController.AppointmentGetAppointmentOptionsAsync(version, siteId, null);
}
catch (ApiException e){};
```


# Appointment Get Available Dates

Returns a list of dates to narrow down staff availability when booking. Dates are those which staff are scheduled to work and do not guarantee booking availabilities. After this call is made, use GET BookableItems to retrieve availabilities for specific dates before booking.

```csharp
AppointmentGetAvailableDatesAsync(
    string version,
    int requestSessionTypeId,
    string siteId,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLocationId = null,
    long? requestStaffId = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestSessionTypeId` | `int` | Query, Required | required requested session type ID. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestLocationId` | `int?` | Query, Optional | optional requested location ID. |
| `requestStaffId` | `long?` | Query, Optional | optional requested staff ID. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today's date** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-available-dates-response.md)

## Example Usage

```csharp
string version = "6";
int requestSessionTypeId = 100;
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetAvailableDatesResponse result = await appointmentController.AppointmentGetAvailableDatesAsync(version, requestSessionTypeId, siteId, null, null, null, null, null);
}
catch (ApiException e){};
```


# Appointment Get Bookable Items

Returns a list of availabilities with the information needed to book appointments. Availabilities include information such as the location and its amenities, staff members, programs, and session types. Recommended to use with ActiveSessionTimes to see which increments each business allows for booking appointments.

```csharp
AppointmentGetBookableItemsAsync(
    string version,
    List<int> requestSessionTypeIds,
    string siteId,
    string authorization = null,
    long? requestAppointmentId = null,
    DateTime? requestEndDate = null,
    bool? requestIgnoreDefaultSessionLength = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestSessionTypeIds` | `List<int>` | Query, Required | A list of the requested session type IDs. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentId` | `long?` | Query, Optional | If provided, filters out the appointment with this ID. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestIgnoreDefaultSessionLength` | `bool?` | Query, Optional | When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br /><br>When `false`, only availabilities that have the default session length return. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | A list of the requested location IDs. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `List<long>` | Query, Optional | A list of the requested staff IDs. Omit parameter to return all staff availabilities. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range.<br><br />Default: **today's date** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-bookable-items-response.md)

## Example Usage

```csharp
string version = "6";
var requestSessionTypeIds = new List<int>();
requestSessionTypeIds.Add(228);
requestSessionTypeIds.Add(229);
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetBookableItemsResponse result = await appointmentController.AppointmentGetBookableItemsAsync(version, requestSessionTypeIds, siteId, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Appointment Get Schedule Items

Returns a list of schedule items, including appointments, availabilities, and unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.

```csharp
AppointmentGetScheduleItemsAsync(
    string version,
    string siteId,
    string authorization = null,
    DateTime? requestEndDate = null,
    bool? requestIgnorePrepFinishTimes = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **today's date** |
| `requestIgnorePrepFinishTimes` | `bool?` | Query, Optional | When `true`, appointment preparation and finish unavailabilities are not returned.<br><br />Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | A list of requested location IDs. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `List<long>` | Query, Optional | A list of requested staff IDs. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range.<br><br />Default: **today's date** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-schedule-items-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetScheduleItemsResponse result = await appointmentController.AppointmentGetScheduleItemsAsync(version, siteId, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Appointment Get Staff Appointments

Returns a list of appointments by staff member.

```csharp
AppointmentGetStaffAppointmentsAsync(
    string version,
    string siteId,
    string authorization = null,
    List<int> requestAppointmentIds = null,
    string requestClientId = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestAppointmentIds` | `List<int>` | Query, Optional | A list of the requested appointment IDs. |
| `requestClientId` | `string` | Query, Optional | The client ID to be returned. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **StartDate** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | A list of the requested location IDs. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `List<long>` | Query, Optional | List of staff IDs to be returned. Use a value of zero to return all staff appointments. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range. If omitted, the default is used.<br><br />Default: **today's date** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-staff-appointments-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetStaffAppointmentsResponse result = await appointmentController.AppointmentGetStaffAppointmentsAsync(version, siteId, null, null, null, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Appointment Get Unavailabilities

Returns a list of unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed..

```csharp
AppointmentGetUnavailabilitiesAsync(
    string version,
    string siteId,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | The end date of the requested date range.<br><br />Default: **today's date** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestStaffIds` | `List<long>` | Query, Optional | A list of requested staff IDs. |
| `requestStartDate` | `DateTime?` | Query, Optional | The start date of the requested date range.<br><br />Default: **today's date** |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-get-unavailabilities-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesResponse result = await appointmentController.AppointmentGetUnavailabilitiesAsync(version, siteId, null, null, null, null, null, null);
}
catch (ApiException e){};
```


# Appointment Add Appointment

A user token is required for this endpoint. To book an appointment, you must use a location ID, staff ID, client ID, session type ID, and the StartDateTime of the appointment. You can get most of this information using GET BookableItems.

```csharp
AppointmentAddAppointmentAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-response.md)

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentRequest();
request.ClientId = "ClientId0";
request.LocationId = 238;
request.SessionTypeId = 82;
request.StaffId = 188L;
request.StartDateTime = DateTime.Parse("2016-03-13T12:52:32.123Z");
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse result = await appointmentController.AppointmentAddAppointmentAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Appointment Add Appointment Add On

This endpoint books an add-on on top of an existing, regular appointment. To book an add-on, you must use an existing appointment ID and session type ID. You can get a session type ID using `GET AppointmentAddOns`.

```csharp
AppointmentAddAppointmentAddOnAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-add-on-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-appointment-add-on-response.md)

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest();
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnResponse result = await appointmentController.AppointmentAddAppointmentAddOnAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Appointment Update Availability

To update the information for a specific availability or unavailability of the staff.<br />
Note: You must have a staff user token with the required permissions.

```csharp
AppointmentUpdateAvailabilityAsync(
    string version,
    string siteId,
    Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest updateAvailabilityRequest,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateAvailabilityRequest` | [`Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-availability-request.md) | Body, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-availability-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
var updateAvailabilityRequest = new MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityRequest();

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse result = await appointmentController.AppointmentUpdateAvailabilityAsync(version, siteId, updateAvailabilityRequest, null);
}
catch (ApiException e){};
```


# Appointment Add Availabilities

Add availabilities and unavailabilities for a staff member.<br />
Note: You must have a staff user token with the required permissions.

```csharp
AppointmentAddAvailabilitiesAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-availabilities-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-add-availabilities-response.md)

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest();
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse result = await appointmentController.AppointmentAddAvailabilitiesAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Appointment Update Appointment

To update the information for a specific appointment, you must have a staff user token with the proper permissions. Note that you can only update the appointment's `StartDateTime`, `EndDateTime`, `StaffId`, `Notes`, and `SessionTypeId`.

```csharp
AppointmentUpdateAppointmentAsync(
    string version,
    Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-appointment-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-controller-update-appointment-response.md)

## Example Usage

```csharp
string version = "6";
var request = new MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest();
request.AppointmentId = 246L;
string siteId = "-99";

try
{
    MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentResponse result = await appointmentController.AppointmentUpdateAppointmentAsync(version, request, siteId, null);
}
catch (ApiException e){};
```


# Appointment Remove From Waitlist

Remove an appointment from waitlist

```csharp
AppointmentRemoveFromWaitlistAsync(
    string version,
    List<int> requestWaitlistEntryIds,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestWaitlistEntryIds` | `List<int>` | Query, Required | A list of `WaitlistEntryIds` to remove from the waiting list. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task`

## Example Usage

```csharp
string version = "6";
var requestWaitlistEntryIds = new List<int>();
requestWaitlistEntryIds.Add(138);
requestWaitlistEntryIds.Add(139);
string siteId = "-99";

try
{
    await appointmentController.AppointmentRemoveFromWaitlistAsync(version, requestWaitlistEntryIds, siteId, null);
}
catch (ApiException e){};
```


# Appointment Delete Availability

This endpoint deletes the availability or unavailability.
Note: You must have a staff user token with the required permissions.

```csharp
AppointmentDeleteAvailabilityAsync(
    string version,
    string siteId,
    string authorization = null,
    int? deleteAvailabilityRequestAvailabilityId = null,
    bool? deleteAvailabilityRequestTest = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `deleteAvailabilityRequestAvailabilityId` | `int?` | Query, Optional | The ID of the availability or unavailability. |
| `deleteAvailabilityRequestTest` | `bool?` | Query, Optional | When `true`, indicates that this is a test request and no data is deleted from the subscriber's database.<br>When `false`, the record will be deleted.<br>Default: **false** |

## Response Type

`Task`

## Example Usage

```csharp
string version = "6";
string siteId = "-99";

try
{
    await appointmentController.AppointmentDeleteAvailabilityAsync(version, siteId, null, null, null);
}
catch (ApiException e){};
```


# Appointment Delete Appointment Add On

This endpoint can be used to early-cancel a booked appointment add-on.

```csharp
AppointmentDeleteAppointmentAddOnAsync(
    string version,
    long id,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `id` | `long` | Query, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task`

## Example Usage

```csharp
string version = "6";
long id = 112L;
string siteId = "-99";

try
{
    await appointmentController.AppointmentDeleteAppointmentAddOnAsync(version, id, siteId, null);
}
catch (ApiException e){};
```

