# Sale

```csharp
SaleController saleController = client.SaleController;
```

## Class Name

`SaleController`

## Methods

* [Get Accepted Card Types](../../doc/controllers/sale.md#get-accepted-card-types)
* [Get Contracts](../../doc/controllers/sale.md#get-contracts)
* [Get Custom Payment Methods](../../doc/controllers/sale.md#get-custom-payment-methods)
* [Get Gift Card Balance](../../doc/controllers/sale.md#get-gift-card-balance)
* [Get Gift Cards](../../doc/controllers/sale.md#get-gift-cards)
* [Get Packages](../../doc/controllers/sale.md#get-packages)
* [Get Products](../../doc/controllers/sale.md#get-products)
* [Update Products](../../doc/controllers/sale.md#update-products)
* [Get Products Inventory](../../doc/controllers/sale.md#get-products-inventory)
* [Get Sales](../../doc/controllers/sale.md#get-sales)
* [Get Services](../../doc/controllers/sale.md#get-services)
* [Update Services](../../doc/controllers/sale.md#update-services)
* [Get Transactions](../../doc/controllers/sale.md#get-transactions)
* [Checkout Shopping Cart](../../doc/controllers/sale.md#checkout-shopping-cart)
* [Initialize Credit Card Entry](../../doc/controllers/sale.md#initialize-credit-card-entry)
* [Purchase Account Credit](../../doc/controllers/sale.md#purchase-account-credit)
* [Purchase Contract](../../doc/controllers/sale.md#purchase-contract)
* [Purchase Gift Card](../../doc/controllers/sale.md#purchase-gift-card)
* [Return Sale](../../doc/controllers/sale.md#return-sale)
* [Update Product Price](../../doc/controllers/sale.md#update-product-price)
* [Update Sale Date](../../doc/controllers/sale.md#update-sale-date)


# Get Accepted Card Types

Gets a list of card types that the site accepts. You can also use `GET Sites` to return the Site object, which contains individual accepted card types for requested sites.

This endpoint has no query parameters.The response returns a list of strings. Possible values are:

* Visa
* MasterCard
* Discover
* AMEX

```csharp
GetAcceptedCardTypesAsync(
    string version,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<List<string>>`

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
try
{
    List<string> result = await saleController.GetAcceptedCardTypesAsync(
        version,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Contracts

Returns the contracts and autopay options that are available on a location-by-location basis. Depending on the configurations established by the site, this endpoint returns options that can be used to sign up clients for recurring payments for services offered by the business.

```csharp
GetContractsAsync(
    string version,
    int requestLocationId,
    string siteId,
    string authorization = null,
    long? requestConsumerId = null,
    List<int> requestContractIds = null,
    int? requestLimit = null,
    int? requestOffset = null,
    string requestPromoCode = null,
    bool? requestSoldOnline = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestLocationId` | `int` | Query, Required | The ID of the location that has the requested contracts and AutoPay options. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestConsumerId` | `long?` | Query, Optional | The ID of the client. |
| `requestContractIds` | `List<int>` | Query, Optional | When included, the response only contains details about the specified contract IDs. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestPromoCode` | `string` | Query, Optional | PromoCode to apply |
| `requestSoldOnline` | `bool?` | Query, Optional | When `true`, the response only contains details about contracts and AutoPay options that can be sold online.<br>When `false`, all contracts are returned.<br>Default: **false** |

## Response Type

[`Task<Models.GetContractsResponse>`](../../doc/models/get-contracts-response.md)

## Example Usage

```csharp
string version = "6";
int requestLocationId = 90;
string siteId = "-99";
string authorization = "authorization6";
long? requestConsumerId = 120L;
List<int> requestContractIds = new List<int>
{
    39,
    40,
};

int? requestLimit = 62;
int? requestOffset = 100;
string requestPromoCode = "request.promoCode0";
bool? requestSoldOnline = false;
try
{
    GetContractsResponse result = await saleController.GetContractsAsync(
        version,
        requestLocationId,
        siteId,
        authorization,
        requestConsumerId,
        requestContractIds,
        requestLimit,
        requestOffset,
        requestPromoCode,
        requestSoldOnline
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Custom Payment Methods

Get payment methods that can be used to pay for sales at a site.

```csharp
GetCustomPaymentMethodsAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetCustomPaymentMethodsResponse>`](../../doc/models/get-custom-payment-methods-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? requestLimit = 62;
int? requestOffset = 100;
try
{
    GetCustomPaymentMethodsResponse result = await saleController.GetCustomPaymentMethodsAsync(
        version,
        siteId,
        authorization,
        requestLimit,
        requestOffset
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Gift Card Balance

Returns a gift card’s remaining balance.

```csharp
GetGiftCardBalanceAsync(
    string version,
    string siteId,
    string authorization = null,
    string barcodeId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `barcodeId` | `string` | Query, Optional | The barcode ID of the gift card for which you want the balance. |

## Response Type

[`Task<Models.GetGiftCardBalanceResponse>`](../../doc/models/get-gift-card-balance-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
string barcodeId = "barcodeId6";
try
{
    GetGiftCardBalanceResponse result = await saleController.GetGiftCardBalanceAsync(
        version,
        siteId,
        authorization,
        barcodeId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Gift Cards

Returns information about gift cards that can be purchased.

```csharp
GetGiftCardsAsync(
    string version,
    string siteId,
    string authorization = null,
    List<int> requestIds = null,
    bool? requestIncludeCustomLayouts = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    bool? requestSoldOnline = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestIds` | `List<int>` | Query, Optional | Filters the results to the requested gift card IDs.<br /><br>Default: **all** gift cards. |
| `requestIncludeCustomLayouts` | `bool?` | Query, Optional | When `true`, includes custom gift card layouts.<br /><br>When `false`, includes only system layouts.<br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | When included, returns gift cards that are sold at the provided location ID. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSoldOnline` | `bool?` | Query, Optional | When `true`, only returns gift cards that are sold online.<br /><br>Default: **false** |

## Response Type

[`Task<Models.GetGiftCardResponse>`](../../doc/models/get-gift-card-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
List<int> requestIds = new List<int>
{
    1,
    2,
};

bool? requestIncludeCustomLayouts = false;
int? requestLimit = 62;
int? requestLocationId = 90;
int? requestOffset = 100;
bool? requestSoldOnline = false;
try
{
    GetGiftCardResponse result = await saleController.GetGiftCardsAsync(
        version,
        siteId,
        authorization,
        requestIds,
        requestIncludeCustomLayouts,
        requestLimit,
        requestLocationId,
        requestOffset,
        requestSoldOnline
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Packages

A package is typically used to combine multiple services and/or products into a single offering. Staff members can check out multiple appointments while selling the package, and can discount the items included. For example, a spa might bundle a massage, a pedicure, a manicure, a facial, and a few selected beauty products into a package.

```csharp
GetPackagesAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    List<int> requestPackageIds = null,
    bool? requestSellOnline = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | The location ID to use to determine the tax for the products that this request returns.<br /><br>Default: **online store** |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestPackageIds` | `List<int>` | Query, Optional | A list of the packages IDs to filter by. |
| `requestSellOnline` | `bool?` | Query, Optional | When `true`, only returns products that can be sold online.<br /><br>When `false`, all products are returned.<br /><br>Default: **false** |

## Response Type

[`Task<Models.GetPackagesResponse>`](../../doc/models/get-packages-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? requestLimit = 62;
int? requestLocationId = 90;
int? requestOffset = 100;
List<int> requestPackageIds = new List<int>
{
    158,
    159,
};

bool? requestSellOnline = false;
try
{
    GetPackagesResponse result = await saleController.GetPackagesAsync(
        version,
        siteId,
        authorization,
        requestLimit,
        requestLocationId,
        requestOffset,
        requestPackageIds,
        requestSellOnline
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Products

Get retail products available for purchase at a site.

```csharp
GetProductsAsync(
    string version,
    string siteId,
    string authorization = null,
    List<int> requestCategoryIds = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    List<string> requestProductIds = null,
    string requestSearchText = null,
    bool? requestSellOnline = null,
    List<int> requestSubCategoryIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestCategoryIds` | `List<int>` | Query, Optional | A list of revenue category IDs to filter by. Use this ID when calling the GET Categories endpoint.<br><br>**Note:** The values for these are not currently retrievable through the API. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | The location ID to use to determine the tax for the products that this request returns.<br /><br>Default: **online store** |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProductIds` | `List<string>` | Query, Optional | The barcode number of the product to be filter by. |
| `requestSearchText` | `string` | Query, Optional | A search filter, used for searching by term. |
| `requestSellOnline` | `bool?` | Query, Optional | When `true`, only products that can be sold online are returned.<br /><br>When `false`, all products are returned.<br /><br>Default: **false** |
| `requestSubCategoryIds` | `List<int>` | Query, Optional | A list of subcategory IDs to filter by. Use this ID when calling the GET Categories endpoint.<br><br>**Note:** The values for these are not currently retrievable through the API. |

## Response Type

[`Task<Models.GetProductsResponse>`](../../doc/models/get-products-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
List<int> requestCategoryIds = new List<int>
{
    140,
    141,
};

int? requestLimit = 62;
int? requestLocationId = 90;
int? requestOffset = 100;
List<string> requestProductIds = new List<string>
{
    "request.productIds3",
    "request.productIds4",
};

string requestSearchText = "request.searchText0";
bool? requestSellOnline = false;
List<int> requestSubCategoryIds = new List<int>
{
    173,
    174,
    175,
};

try
{
    GetProductsResponse result = await saleController.GetProductsAsync(
        version,
        siteId,
        authorization,
        requestCategoryIds,
        requestLimit,
        requestLocationId,
        requestOffset,
        requestProductIds,
        requestSearchText,
        requestSellOnline,
        requestSubCategoryIds
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Products

Update retail products available for purchase at a site.

```csharp
UpdateProductsAsync(
    string version,
    string siteId,
    List<Models.UpdateProductRequest> updateProductsRequests,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateProductsRequests` | [`List<UpdateProductRequest>`](../../doc/models/update-product-request.md) | Body, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetProductsResponse>`](../../doc/models/get-products-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
List<Models.UpdateProductRequest> updateProductsRequests = new List<Models.UpdateProductRequest>
{
    new UpdateProductRequest
    {
        BarcodeId = "BarcodeId1",
        Price = 26.71,
        OnlinePrice = 61.23,
    },
    new UpdateProductRequest
    {
        BarcodeId = "BarcodeId2",
        Price = 26.72,
        OnlinePrice = 61.24,
    },
};

string authorization = "authorization6";
try
{
    GetProductsResponse result = await saleController.UpdateProductsAsync(
        version,
        siteId,
        updateProductsRequests,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Products Inventory

Get retail products inventory data available at a site.

```csharp
GetProductsInventoryAsync(
    string version,
    string siteId,
    string authorization = null,
    List<string> requestBarcodeIds = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<string> requestProductIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestBarcodeIds` | `List<string>` | Query, Optional | When included, the response only contains details about the specified Barcode Ids. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | When included, the response only contains details about the specified location Ids. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProductIds` | `List<string>` | Query, Optional | When included, the response only contains details about the specified product Ids. |

## Response Type

[`Task<Models.GetProductsInventoryResponse>`](../../doc/models/get-products-inventory-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
List<string> requestBarcodeIds = new List<string>
{
    "request.barcodeIds6",
};

int? requestLimit = 62;
List<int> requestLocationIds = new List<int>
{
    192,
};

int? requestOffset = 100;
List<string> requestProductIds = new List<string>
{
    "request.productIds3",
    "request.productIds4",
};

try
{
    GetProductsInventoryResponse result = await saleController.GetProductsInventoryAsync(
        version,
        siteId,
        authorization,
        requestBarcodeIds,
        requestLimit,
        requestLocationIds,
        requestOffset,
        requestProductIds
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Sales

Get sales completed at a site.

```csharp
GetSalesAsync(
    string version,
    string siteId,
    string authorization = null,
    DateTime? requestEndSaleDateTime = null,
    int? requestLimit = null,
    int? requestOffset = null,
    int? requestPaymentMethodId = null,
    long? requestSaleId = null,
    DateTime? requestStartSaleDateTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndSaleDateTime` | `DateTime?` | Query, Optional | Filters results to sales that happened before this date and time. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestPaymentMethodId` | `int?` | Query, Optional | Filters results to sales paid for by the given payment method ID which indicates payment method(s) (i.e. cash, VISA, AMEX, Check, etc.). |
| `requestSaleId` | `long?` | Query, Optional | The sale ID associated with the particular item. It Filters results to the requested sale ID. |
| `requestStartSaleDateTime` | `DateTime?` | Query, Optional | Filters results to sales that happened after this date and time. |

## Response Type

[`Task<Models.GetSalesResponse>`](../../doc/models/get-sales-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
DateTime? requestEndSaleDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
int? requestOffset = 100;
int? requestPaymentMethodId = 140;
long? requestSaleId = 32L;
DateTime? requestStartSaleDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetSalesResponse result = await saleController.GetSalesAsync(
        version,
        siteId,
        authorization,
        requestEndSaleDateTime,
        requestLimit,
        requestOffset,
        requestPaymentMethodId,
        requestSaleId,
        requestStartSaleDateTime
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Services

Get pricing options available for purchase at a site

```csharp
GetServicesAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestClassId = null,
    int? requestClassScheduleId = null,
    bool? requestHideRelatedPrograms = null,
    bool? requestIncludeDiscontinued = null,
    bool? requestIncludeSaleInContractOnly = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    List<int> requestProgramIds = null,
    bool? requestSellOnline = null,
    List<string> requestServiceIds = null,
    List<int> requestSessionTypeIds = null,
    long? requestStaffId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClassId` | `int?` | Query, Optional | Filters to the pricing options for the specified class ID. |
| `requestClassScheduleId` | `int?` | Query, Optional | Filters to the pricing options for the specified class schedule ID. |
| `requestHideRelatedPrograms` | `bool?` | Query, Optional | When `true`, indicates that pricing options of related programs are omitted from the response.<br /><br>Default: **false** |
| `requestIncludeDiscontinued` | `bool?` | Query, Optional | When `true`, indicates that the filtered pricing option list includes discontinued pricing options.<br /><br>Default: **false** |
| `requestIncludeSaleInContractOnly` | `bool?` | Query, Optional | When `true`, indicates that the filtered pricing option list includes sale in contract only pricing options.<br /><br>Default: **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | When specified, for each returned pricing option, `TaxRate` and `TaxIncluded` are calculated according to the specified location. Note that this does not filter results to only services provided at the given location, and for locations where Value-Added Tax (VAT) rules apply, the `TaxRate` is set to zero. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `List<int>` | Query, Optional | Filters to pricing options with the specified program IDs. |
| `requestSellOnline` | `bool?` | Query, Optional | When `true`, filters to the pricing options that can be sold online.<br /><br>Default: **false** |
| `requestServiceIds` | `List<string>` | Query, Optional | Filters to the pricing options with the specified IDs. In this context, service and pricing option are used interchangeably. These are the `PurchasedItems[].Id` returned from GET Sales. |
| `requestSessionTypeIds` | `List<int>` | Query, Optional | Filters to the pricing options with the specified session types IDs. |
| `requestStaffId` | `long?` | Query, Optional | Sets `Price` and `OnlinePrice` to the particular pricing of a specific staff member, if allowed by the business. |

## Response Type

[`Task<Models.GetServicesResponse>`](../../doc/models/get-services-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? requestClassId = 206;
int? requestClassScheduleId = 226;
bool? requestHideRelatedPrograms = false;
bool? requestIncludeDiscontinued = false;
bool? requestIncludeSaleInContractOnly = false;
int? requestLimit = 62;
int? requestLocationId = 90;
int? requestOffset = 100;
List<int> requestProgramIds = new List<int>
{
    91,
    92,
    93,
};

bool? requestSellOnline = false;
List<string> requestServiceIds = new List<string>
{
    "request.serviceIds6",
    "request.serviceIds7",
    "request.serviceIds8",
};

List<int> requestSessionTypeIds = new List<int>
{
    228,
    229,
};

long? requestStaffId = 180L;
try
{
    GetServicesResponse result = await saleController.GetServicesAsync(
        version,
        siteId,
        authorization,
        requestClassId,
        requestClassScheduleId,
        requestHideRelatedPrograms,
        requestIncludeDiscontinued,
        requestIncludeSaleInContractOnly,
        requestLimit,
        requestLocationId,
        requestOffset,
        requestProgramIds,
        requestSellOnline,
        requestServiceIds,
        requestSessionTypeIds,
        requestStaffId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Services

Update unit price and online price of provided services.

```csharp
UpdateServicesAsync(
    string version,
    string siteId,
    List<Models.UpdateServiceRequest> updateServicesRequest,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `updateServicesRequest` | [`List<UpdateServiceRequest>`](../../doc/models/update-service-request.md) | Body, Required | - |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateServiceResponse>`](../../doc/models/update-service-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
List<Models.UpdateServiceRequest> updateServicesRequest = new List<Models.UpdateServiceRequest>
{
    new UpdateServiceRequest
    {
        BarcodeId = "BarcodeId7",
        Price = 134.37,
        OnlinePrice = 168.89,
    },
};

string authorization = "authorization6";
try
{
    UpdateServiceResponse result = await saleController.UpdateServicesAsync(
        version,
        siteId,
        updateServicesRequest,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Transactions

This endpoint returns a list of transaction details of processed sales.

```csharp
GetTransactionsAsync(
    string version,
    string siteId,
    string authorization = null,
    long? requestClientId = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    long? requestSaleId = null,
    string requestStatus = null,
    DateTime? requestTransactionEndDateTime = null,
    int? requestTransactionId = null,
    DateTime? requestTransactionStartDateTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestClientId` | `long?` | Query, Optional | Filters results to the requested client ID. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | Filters the transaction results with the ID number associated with the location of the sale. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSaleId` | `long?` | Query, Optional | Filters the transaction results with the ID number associated with the sale. |
| `requestStatus` | `string` | Query, Optional | Filters the transaction results by the estimated transaction status. |
| `requestTransactionEndDateTime` | `DateTime?` | Query, Optional | Filters the transaction results that happpened before this date and time.<br>Default: **today’s date** |
| `requestTransactionId` | `int?` | Query, Optional | Filters the transaction results with the ID number generated when the sale is processed. |
| `requestTransactionStartDateTime` | `DateTime?` | Query, Optional | Filters the transaction results that happpened after this date and time.<br>Default: **today’s date** |

## Response Type

[`Task<Models.GetTransactionsResponse>`](../../doc/models/get-transactions-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
long? requestClientId = 222L;
int? requestLimit = 62;
int? requestLocationId = 90;
int? requestOffset = 100;
long? requestSaleId = 32L;
string requestStatus = "request.status2";
DateTime? requestTransactionEndDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestTransactionId = 200;
DateTime? requestTransactionStartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetTransactionsResponse result = await saleController.GetTransactionsAsync(
        version,
        siteId,
        authorization,
        requestClientId,
        requestLimit,
        requestLocationId,
        requestOffset,
        requestSaleId,
        requestStatus,
        requestTransactionEndDateTime,
        requestTransactionId,
        requestTransactionStartDateTime
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Checkout Shopping Cart

This endpoint provides a wide range of functionality. For example, you can use it when a client purchases new pricing options, retail products, packages, and tips. You can also combine purchasing a new pricing option and many other functions, such as booking a client into a class, booking a new appointment for a client, enrolling a client into an enrollment or course, or reconciling an unpaid, already booked appointment or class. Use this call when a client purchases:

* a pricing option, after calling `GET Services` and choosing a specific pricing option’s ID
* a retail product, after calling `GET Products` and choosing a specific retail product’s ID
* a package, after calling `GET Packages` and choosing a specific package’s ID
* a tip to give to a staff member, after calling `GET Staff` and choosing a specific staff member ID, and the amount that the client wants to tip
  The documentation provides explanations of the request body and response, as well as the cart item metadata, payment item metadata, and purchased cart items.
  This endpoint had been updated to support Strong Customer Authentication (SCA).
  **Note :**
  Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

```csharp
CheckoutShoppingCartAsync(
    string version,
    Models.CheckoutShoppingCartRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`CheckoutShoppingCartRequest`](../../doc/models/checkout-shopping-cart-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.CheckoutShoppingCartResponse>`](../../doc/models/checkout-shopping-cart-response.md)

## Example Usage

```csharp
string version = "6";
CheckoutShoppingCartRequest request = new CheckoutShoppingCartRequest
{
    ClientId = "ClientId0",
    Items = new List<Models.CheckoutItemWrapper>
    {
        new CheckoutItemWrapper
        {
            Item = new CheckoutItem
            {
                Type = "Type3",
                Metadata = new Dictionary<string, object>
                {
                    ["key0"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                    ["key1"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                    ["key2"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                },
            },
            DiscountAmount = 213.37,
            AppointmentBookingRequests = new List<Models.CheckoutAppointmentBookingRequest>
            {
                new CheckoutAppointmentBookingRequest
                {
                    StaffId = 83L,
                    LocationId = 123,
                    SessionTypeId = 233,
                    Resources = new List<Models.ResourceSlim>
                    {
                        new ResourceSlim
                        {
                            Id = 38,
                            Name = "Name6",
                        },
                    },
                    StartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
                        provider: CultureInfo.InvariantCulture,
                        DateTimeStyles.RoundtripKind),
                },
                new CheckoutAppointmentBookingRequest
                {
                    StaffId = 82L,
                    LocationId = 124,
                    SessionTypeId = 232,
                    Resources = new List<Models.ResourceSlim>
                    {
                        new ResourceSlim
                        {
                            Id = 37,
                            Name = "Name7",
                        },
                        new ResourceSlim
                        {
                            Id = 36,
                            Name = "Name8",
                        },
                    },
                    StartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
                        provider: CultureInfo.InvariantCulture,
                        DateTimeStyles.RoundtripKind),
                },
                new CheckoutAppointmentBookingRequest
                {
                    StaffId = 81L,
                    LocationId = 125,
                    SessionTypeId = 231,
                    Resources = new List<Models.ResourceSlim>
                    {
                        new ResourceSlim
                        {
                            Id = 36,
                            Name = "Name8",
                        },
                        new ResourceSlim
                        {
                            Id = 35,
                            Name = "Name9",
                        },
                        new ResourceSlim
                        {
                            Id = 34,
                            Name = "Name0",
                        },
                    },
                    StartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
                        provider: CultureInfo.InvariantCulture,
                        DateTimeStyles.RoundtripKind),
                },
            },
            EnrollmentIds = new List<int>
            {
                42,
            },
            ClassIds = new List<int>
            {
                202,
                203,
            },
        },
        new CheckoutItemWrapper
        {
            Item = new CheckoutItem
            {
                Type = "Type4",
                Metadata = new Dictionary<string, object>
                {
                    ["key0"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                },
            },
            DiscountAmount = 213.38,
            AppointmentBookingRequests = new List<Models.CheckoutAppointmentBookingRequest>
            {
                new CheckoutAppointmentBookingRequest
                {
                    StaffId = 82L,
                    LocationId = 124,
                    SessionTypeId = 232,
                    Resources = new List<Models.ResourceSlim>
                    {
                        new ResourceSlim
                        {
                            Id = 37,
                            Name = "Name7",
                        },
                        new ResourceSlim
                        {
                            Id = 36,
                            Name = "Name8",
                        },
                    },
                    StartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
                        provider: CultureInfo.InvariantCulture,
                        DateTimeStyles.RoundtripKind),
                },
            },
            EnrollmentIds = new List<int>
            {
                43,
                44,
            },
            ClassIds = new List<int>
            {
                203,
                204,
                205,
            },
        },
        new CheckoutItemWrapper
        {
            Item = new CheckoutItem
            {
                Type = "Type5",
                Metadata = new Dictionary<string, object>
                {
                    ["key0"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                    ["key1"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                },
            },
            DiscountAmount = 213.39,
            AppointmentBookingRequests = new List<Models.CheckoutAppointmentBookingRequest>
            {
                new CheckoutAppointmentBookingRequest
                {
                    StaffId = 81L,
                    LocationId = 125,
                    SessionTypeId = 231,
                    Resources = new List<Models.ResourceSlim>
                    {
                        new ResourceSlim
                        {
                            Id = 36,
                            Name = "Name8",
                        },
                        new ResourceSlim
                        {
                            Id = 35,
                            Name = "Name9",
                        },
                        new ResourceSlim
                        {
                            Id = 34,
                            Name = "Name0",
                        },
                    },
                    StartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
                        provider: CultureInfo.InvariantCulture,
                        DateTimeStyles.RoundtripKind),
                },
                new CheckoutAppointmentBookingRequest
                {
                    StaffId = 80L,
                    LocationId = 126,
                    SessionTypeId = 230,
                    Resources = new List<Models.ResourceSlim>
                    {
                        new ResourceSlim
                        {
                            Id = 35,
                            Name = "Name9",
                        },
                    },
                    StartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
                        provider: CultureInfo.InvariantCulture,
                        DateTimeStyles.RoundtripKind),
                },
            },
            EnrollmentIds = new List<int>
            {
                44,
                45,
                46,
            },
            ClassIds = new List<int>
            {
                204,
            },
        },
    },
    Payments = new List<Models.CheckoutPaymentInfo>
    {
        new CheckoutPaymentInfo
        {
            Type = "Type4",
            Metadata = new Dictionary<string, object>
            {
                ["key0"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            },
        },
        new CheckoutPaymentInfo
        {
            Type = "Type5",
            Metadata = new Dictionary<string, object>
            {
                ["key0"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ["key1"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            },
        },
        new CheckoutPaymentInfo
        {
            Type = "Type6",
            Metadata = new Dictionary<string, object>
            {
                ["key0"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ["key1"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
                ["key2"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
            },
        },
    },
    CartId = "CartId0",
    Test = false,
    InStore = false,
    CalculateTax = false,
    PromotionCode = "PromotionCode2",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    CheckoutShoppingCartResponse result = await saleController.CheckoutShoppingCartAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Initialize Credit Card Entry

**Note**:  
Referer is a DomainURL which will be automatically reflected if the Card UI is loaded via your application.
If you are using this endpoint via postman then you need to specify your domain URL under Referer.

```csharp
InitializeCreditCardEntryAsync(
    string version,
    Models.InitializeCreditCardEntryRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`InitializeCreditCardEntryRequest`](../../doc/models/initialize-credit-card-entry-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.InitializeCreditCardEntryResponse>`](../../doc/models/initialize-credit-card-entry-response.md)

## Example Usage

```csharp
string version = "6";
InitializeCreditCardEntryRequest request = new InitializeCreditCardEntryRequest
{
    MerchantAccountId = "MerchantAccountId4",
    LocationId = 238,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    InitializeCreditCardEntryResponse result = await saleController.InitializeCreditCardEntryAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Purchase Account Credit

Allows a client to purchase account credit from a business.

```csharp
PurchaseAccountCreditAsync(
    string version,
    Models.PurchaseAccountCreditRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`PurchaseAccountCreditRequest`](../../doc/models/purchase-account-credit-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.PurchaseAccountCreditResponse>`](../../doc/models/purchase-account-credit-response.md)

## Example Usage

```csharp
string version = "6";
PurchaseAccountCreditRequest request = new PurchaseAccountCreditRequest
{
    ClientId = "ClientId0",
    Test = false,
    LocationId = 238,
    SendEmailReceipt = false,
    SalesRepId = 232L,
    ConsumerPresent = false,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    PurchaseAccountCreditResponse result = await saleController.PurchaseAccountCreditAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Purchase Contract

Allows a client to sign up for a contract or autopay using the information returned from the `GET Contracts` endpoint. The client can pay with a new credit card or with a stored credit card. The client must exist at the site specified before this call is made.

This endpoint allows a developer to specify whether a client pays now or pays on the `StartDate`.If you are building a client-facing experience, you should talk with the business owner to understand the owner’s policies before you give clients a choice of the two payment types.
This endpoint had been updated to support Strong Customer Authentication (SCA).

**Note**
Protect yourself from processor fees and credit card fraud. Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

```csharp
PurchaseContractAsync(
    string version,
    Models.PurchaseContractRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`PurchaseContractRequest`](../../doc/models/purchase-contract-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.PurchaseContractResponse>`](../../doc/models/purchase-contract-response.md)

## Example Usage

```csharp
string version = "6";
PurchaseContractRequest request = new PurchaseContractRequest
{
    ClientId = "ClientId0",
    ContractId = 168,
    Test = false,
    LocationId = 238,
    StartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    FirstPaymentOccurs = "FirstPaymentOccurs0",
    ClientSignature = "ClientSignature4",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    PurchaseContractResponse result = await saleController.PurchaseContractAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Purchase Gift Card

Allows a client to purchase a gift card from a business in a variety of designs. The card can be emailed to the recipient on a specific day, and a card title and a personal message can be added.
**Note**
Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!

```csharp
PurchaseGiftCardAsync(
    string version,
    Models.PurchaseGiftCardRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`PurchaseGiftCardRequest`](../../doc/models/purchase-gift-card-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.PurchaseGiftCardResponse>`](../../doc/models/purchase-gift-card-response.md)

## Example Usage

```csharp
string version = "6";
PurchaseGiftCardRequest request = new PurchaseGiftCardRequest
{
    LocationId = 238,
    PurchaserClientId = "PurchaserClientId6",
    GiftCardId = 222,
    Test = false,
    LayoutId = 220,
    SendEmailReceipt = false,
    RecipientEmail = "RecipientEmail2",
    RecipientName = "RecipientName2",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    PurchaseGiftCardResponse result = await saleController.PurchaseGiftCardAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Return Sale

Return a comped sale for a specified sale ID in business mode. The sale is returnable only if it is a sale of a service, product or gift card and it has not been used. Currently, only the comp payment method is supported.

```csharp
ReturnSaleAsync(
    string version,
    Models.ReturnSaleRequest returnSaleRequest,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `returnSaleRequest` | [`ReturnSaleRequest`](../../doc/models/return-sale-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.ReturnSaleResponse>`](../../doc/models/return-sale-response.md)

## Example Usage

```csharp
string version = "6";
ReturnSaleRequest returnSaleRequest = new ReturnSaleRequest
{
    SaleId = 6L,
    ReturnReason = "ReturnReason8",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    ReturnSaleResponse result = await saleController.ReturnSaleAsync(
        version,
        returnSaleRequest,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Product Price

This endpoint updates the retail price and an online price for a product. Passing at least one of them is mandatory.

```csharp
UpdateProductPriceAsync(
    string version,
    Models.UpdateProductPriceRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateProductPriceRequest`](../../doc/models/update-product-price-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateProductPriceResponse>`](../../doc/models/update-product-price-response.md)

## Example Usage

```csharp
string version = "6";
UpdateProductPriceRequest request = new UpdateProductPriceRequest
{
    BarcodeId = "BarcodeId6",
    Price = 195.96,
    OnlinePrice = 230.48,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    UpdateProductPriceResponse result = await saleController.UpdateProductPriceAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Sale Date

This endpoint updates the SaleDate and returns the details of the sale.

```csharp
UpdateSaleDateAsync(
    string version,
    Models.UpdateSaleDateRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateSaleDateRequest`](../../doc/models/update-sale-date-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateSaleDateResponse>`](../../doc/models/update-sale-date-response.md)

## Example Usage

```csharp
string version = "6";
UpdateSaleDateRequest request = new UpdateSaleDateRequest
{
    SaleID = 232L,
    SaleDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    UpdateSaleDateResponse result = await saleController.UpdateSaleDateAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

