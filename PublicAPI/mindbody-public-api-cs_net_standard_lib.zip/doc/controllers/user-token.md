# User Token

```csharp
UserTokenController userTokenController = client.UserTokenController;
```

## Class Name

`UserTokenController`

## Methods

* [Issue Token](../../doc/controllers/user-token.md#issue-token)
* [Renew Token](../../doc/controllers/user-token.md#renew-token)
* [Revoke Token](../../doc/controllers/user-token.md#revoke-token)


# Issue Token

When users interact with your Public API integration as staff members, they need to get a staff user token for authentication.
You can use the issue endpoint to get a staff user token, then pass the token in the headers for all of your requests.

:information_source: **Note** This endpoint does not require authentication.

```csharp
IssueTokenAsync(
    string version,
    Models.IssueRequest request,
    string siteId)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`IssueRequest`](../../doc/models/issue-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |

## Response Type

[`Task<Models.IssueResponse>`](../../doc/models/issue-response.md)

## Example Usage

```csharp
string version = "6";
IssueRequest request = new IssueRequest
{
    Username = "Username4",
    Password = "Password6",
};

string siteId = "-99";
try
{
    IssueResponse result = await userTokenController.IssueTokenAsync(
        version,
        request,
        siteId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Renew Token

Renews a token. Can be used to extend the lifetime of a token.
Current lifetime expansion: 24hrs from current expiration, up to 7 renewals.

:information_source: **Note** This endpoint does not require authentication.

```csharp
RenewTokenAsync(
    string version,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
try
{
    object result = await userTokenController.RenewTokenAsync(
        version,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Revoke Token

Revokes the user token in the Authorization header.

:information_source: **Note** This endpoint does not require authentication.

```csharp
RevokeTokenAsync(
    string version,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
try
{
    object result = await userTokenController.RevokeTokenAsync(
        version,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

