# Site

```csharp
SiteController siteController = client.SiteController;
```

## Class Name

`SiteController`

## Methods

* [Get Activation Code](../../doc/controllers/site.md#get-activation-code)
* [Get Categories](../../doc/controllers/site.md#get-categories)
* [Get Genders](../../doc/controllers/site.md#get-genders)
* [Get Liability Waiver](../../doc/controllers/site.md#get-liability-waiver)
* [Get Locations](../../doc/controllers/site.md#get-locations)
* [Get Memberships](../../doc/controllers/site.md#get-memberships)
* [Get Mobile Providers](../../doc/controllers/site.md#get-mobile-providers)
* [Get Payment Types](../../doc/controllers/site.md#get-payment-types)
* [Get Programs](../../doc/controllers/site.md#get-programs)
* [Get Promo Codes](../../doc/controllers/site.md#get-promo-codes)
* [Get Prospect Stages](../../doc/controllers/site.md#get-prospect-stages)
* [Get Relationships](../../doc/controllers/site.md#get-relationships)
* [Get Resource Availabilities](../../doc/controllers/site.md#get-resource-availabilities)
* [Get Resources](../../doc/controllers/site.md#get-resources)
* [Get Session Types](../../doc/controllers/site.md#get-session-types)
* [Get Sites](../../doc/controllers/site.md#get-sites)
* [Add Client Index](../../doc/controllers/site.md#add-client-index)
* [Add Promo Code](../../doc/controllers/site.md#add-promo-code)
* [Deactivate Promo Code](../../doc/controllers/site.md#deactivate-promo-code)
* [Update Client Index](../../doc/controllers/site.md#update-client-index)


# Get Activation Code

Before you can use this endpoint, MINDBODY must approve your developer account for live access. If you have finished testing in the sandbox and are ready to begin working with MINDBODY customers, log into your account and request to go live.

See [Accessing Business Data From MINDBODY](https://developers.mindbodyonline.com/PublicDocumentation/V6#accessing-business-data) for more information about the activation code and how to use it.

Once you are approved, this endpoint returns an activation code.This endpoint supports only one site per call.

```csharp
GetActivationCodeAsync(
    string version,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetActivationCodeResponse>`](../../doc/models/get-activation-code-response.md)

## Example Usage

```csharp
string version = "6";
string authorization = "authorization6";
try
{
    GetActivationCodeResponse result = await siteController.GetActivationCodeAsync(
        version,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Categories

Gets the categories.

```csharp
GetCategoriesAsync(
    string version,
    string siteId,
    string authorization = null,
    bool? requestActive = null,
    List<int> requestCategoryIds = null,
    int? requestLimit = null,
    int? requestOffset = null,
    bool? requestService = null,
    List<int> requestSubCategoryIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `bool?` | Query, Optional | When `true`, the response only contains categories which are activated.<br>When `false`, only deactivated categories are returned.<br>Default: **All Categories** |
| `requestCategoryIds` | `List<int>` | Query, Optional | When included, the response only contains details about the specified category Ids. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestService` | `bool?` | Query, Optional | When `true`, the response only contains details about Revenue Categories.<br>When `false`, only Product Revenue Categories are returned.<br>Default: **All Categories** |
| `requestSubCategoryIds` | `List<int>` | Query, Optional | When included, the response only contains details about the specified subcategory Ids. |

## Response Type

[`Task<Models.GetCategoriesResponse>`](../../doc/models/get-categories-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
bool? requestActive = false;
List<int> requestCategoryIds = new List<int>
{
    140,
    141,
};

int? requestLimit = 62;
int? requestOffset = 100;
bool? requestService = false;
List<int> requestSubCategoryIds = new List<int>
{
    173,
    174,
    175,
};

try
{
    GetCategoriesResponse result = await siteController.GetCategoriesAsync(
        version,
        siteId,
        authorization,
        requestActive,
        requestCategoryIds,
        requestLimit,
        requestOffset,
        requestService,
        requestSubCategoryIds
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Genders

The endpoint returns a list of configured client gender options for a site. Custom gender options are assignable to client genders only. Currently, custom values returned from this endpoint cannot be used as input for other endpoints to specify the genders of staff or client preferences.

```csharp
GetGendersAsync(
    string version,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetGendersResponse>`](../../doc/models/get-genders-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
try
{
    GetGendersResponse result = await siteController.GetGendersAsync(
        version,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Liability Waiver

Gets Liability Waiver content at the specified business.
This endpoint requires staff user credentials.

```csharp
GetLiabilityWaiverAsync(
    string version,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetLiabilityWaiverResponse>`](../../doc/models/get-liability-waiver-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
try
{
    GetLiabilityWaiverResponse result = await siteController.GetLiabilityWaiverAsync(
        version,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Locations

Get locations for a site.

```csharp
GetLocationsAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetLocationsResponse>`](../../doc/models/get-locations-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? requestLimit = 62;
int? requestOffset = 100;
try
{
    GetLocationsResponse result = await siteController.GetLocationsAsync(
        version,
        siteId,
        authorization,
        requestLimit,
        requestOffset
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Memberships

Get the memberships at a site.

```csharp
GetMembershipsAsync(
    string version,
    string siteId,
    string authorization = null,
    List<int> requestMembershipIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestMembershipIds` | `List<int>` | Query, Optional | The requested membership IDs.<br /><br>Default: **all** IDs that the authenticated user’s access level allows. |

## Response Type

[`Task<Models.GetMembershipsResponse>`](../../doc/models/get-memberships-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
List<int> requestMembershipIds = new List<int>
{
    213,
    214,
};

try
{
    GetMembershipsResponse result = await siteController.GetMembershipsAsync(
        version,
        siteId,
        authorization,
        requestMembershipIds
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Mobile Providers

Get the list of mobile providers that are supported by the business.

```csharp
GetMobileProvidersAsync(
    string version,
    string siteId,
    string authorization = null,
    bool? requestActive = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `bool?` | Query, Optional | When `true`, the response only contains mobile providers which are activated.<br>When `false`, only deactivated mobile providers are returned.<br>Default: **All Mobile Providers** |

## Response Type

[`Task<Models.GetMobileProvidersResponse>`](../../doc/models/get-mobile-providers-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
bool? requestActive = false;
try
{
    GetMobileProvidersResponse result = await siteController.GetMobileProvidersAsync(
        version,
        siteId,
        authorization,
        requestActive
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Payment Types

Get payment types for a site.

```csharp
GetPaymentTypesAsync(
    string version,
    string siteId,
    string authorization = null,
    bool? requestActive = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `bool?` | Query, Optional | When `true`, the response only contains payment types which are activated.<br>When `false`, only deactivated payment types are returned.<br>Default: **All Payment Types** |

## Response Type

[`Task<Models.GetPaymentTypesResponse>`](../../doc/models/get-payment-types-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
bool? requestActive = false;
try
{
    GetPaymentTypesResponse result = await siteController.GetPaymentTypesAsync(
        version,
        siteId,
        authorization,
        requestActive
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Programs

Get service categories offered at a site.

```csharp
GetProgramsAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null,
    bool? requestOnlineOnly = null,
    List<int> requestProgramIds = null,
    Models.RequestScheduleTypeEnum? requestScheduleType = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `bool?` | Query, Optional | If `true`, filters results to show only those programs that are shown online.<br /><br>If `false`, all programs are returned.<br /><br>Default: **false** |
| `requestProgramIds` | `List<int>` | Query, Optional | Program Ids to filter for |
| `requestScheduleType` | [`RequestScheduleTypeEnum?`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | A schedule type used to filter the returned results. Possible values are:<br><br>* All<br>* Class<br>* Enrollment<br>* Appointment<br>* Resource<br>* Media<br>* Arrival |

## Response Type

[`Task<Models.GetProgramsResponse>`](../../doc/models/get-programs-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? requestLimit = 62;
int? requestOffset = 100;
bool? requestOnlineOnly = false;
List<int> requestProgramIds = new List<int>
{
    91,
    92,
    93,
};

RequestScheduleTypeEnum? requestScheduleType = RequestScheduleTypeEnum.Resource;
try
{
    GetProgramsResponse result = await siteController.GetProgramsAsync(
        version,
        siteId,
        authorization,
        requestLimit,
        requestOffset,
        requestOnlineOnly,
        requestProgramIds,
        requestScheduleType
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Promo Codes

Gets a list of promocodes at the specified business. This endpoint requires staff user credentials.
This staff member should have enabled the Set up promotions / **Semester discounts** staff permission.

```csharp
GetPromoCodesAsync(
    string version,
    string siteId,
    string authorization = null,
    bool? requestActiveOnly = null,
    DateTime? requestEndDate = null,
    DateTime? requestLastModifiedDate = null,
    int? requestLimit = null,
    int? requestOffset = null,
    bool? requestOnlineOnly = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestActiveOnly` | `bool?` | Query, Optional | If true, filters results to show only promocodes that are active. If **false**, all promocodes are returned.<br>Default: **true** |
| `requestEndDate` | `DateTime?` | Query, Optional | Filters results to promocodes that were activated before this date. |
| `requestLastModifiedDate` | `DateTime?` | Query, Optional | Filters results to promocodes that were modified on or after this date. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `bool?` | Query, Optional | If `true`, filters results to show only promocodes that can be used for online sale.<br>If `false`, all promocodes are returned.<br>Default: **false** |
| `requestStartDate` | `DateTime?` | Query, Optional | Filters results to promocodes that were activated after this date. |

## Response Type

[`Task<Models.GetPromoCodesResponse>`](../../doc/models/get-promo-codes-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
bool? requestActiveOnly = false;
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
DateTime? requestLastModifiedDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
int? requestOffset = 100;
bool? requestOnlineOnly = false;
DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetPromoCodesResponse result = await siteController.GetPromoCodesAsync(
        version,
        siteId,
        authorization,
        requestActiveOnly,
        requestEndDate,
        requestLastModifiedDate,
        requestLimit,
        requestOffset,
        requestOnlineOnly,
        requestStartDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Prospect Stages

Get the list of prospect stages that represent the prospect stage options for prospective clients.

```csharp
GetProspectStagesAsync(
    string version,
    string siteId,
    string authorization = null,
    bool? requestActive = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `bool?` | Query, Optional | When `true`, the response only contains prospect stages which are activated.<br>When `false`, only deactivated prospect stages are returned.<br>Default: **All Prospect Stages** |

## Response Type

[`Task<Models.GetProspectStagesResponse>`](../../doc/models/get-prospect-stages-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
bool? requestActive = false;
try
{
    GetProspectStagesResponse result = await siteController.GetProspectStagesAsync(
        version,
        siteId,
        authorization,
        requestActive
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Relationships

This endpoint retrieves the business site relationships.

```csharp
GetRelationshipsAsync(
    string version,
    string siteId,
    string authorization = null,
    bool? requestActive = null,
    int? requestLimit = null,
    int? requestOffset = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestActive` | `bool?` | Query, Optional | When `true`, the response only contains relationships which are activated.<br>When `false`, only deactivated relationships are returned.<br>Default: **All Relationships** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |

## Response Type

[`Task<Models.GetRelationshipsResponse>`](../../doc/models/get-relationships-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
bool? requestActive = false;
int? requestLimit = 62;
int? requestOffset = 100;
try
{
    GetRelationshipsResponse result = await siteController.GetRelationshipsAsync(
        version,
        siteId,
        authorization,
        requestActive,
        requestLimit,
        requestOffset
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Resource Availabilities

Get resource availabilities used at a site.

```csharp
GetResourceAvailabilitiesAsync(
    string version,
    string siteId,
    string authorization = null,
    DateTime? requestEndDate = null,
    int? requestLimit = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<int> requestProgramIds = null,
    List<int> requestResourceIds = null,
    List<Models.RequestScheduleTypeEnum> requestScheduleTypes = null,
    DateTime? requestStartDate = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDate` | `DateTime?` | Query, Optional | End date. If default, StartDate is used. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationIds` | `List<int>` | Query, Optional | Filter by location ids (optional) |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `List<int>` | Query, Optional | Filter by program ids (optional) |
| `requestResourceIds` | `List<int>` | Query, Optional | Filter on resourceIds |
| `requestScheduleTypes` | [`List<RequestScheduleTypeEnum>`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | Filter by schedule types (optional) |
| `requestStartDate` | `DateTime?` | Query, Optional | Start time |

## Response Type

[`Task<Models.GetResourcesResponse>`](../../doc/models/get-resources-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
DateTime? requestEndDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
int? requestLimit = 62;
List<int> requestLocationIds = new List<int>
{
    192,
};

int? requestOffset = 100;
List<int> requestProgramIds = new List<int>
{
    91,
    92,
    93,
};

List<int> requestResourceIds = new List<int>
{
    62,
};

List<RequestScheduleTypeEnum> requestScheduleTypes = new List<RequestScheduleTypeEnum>
{
    RequestScheduleTypeEnum.Appointment,
    RequestScheduleTypeEnum.Resource,
    RequestScheduleTypeEnum.Media,
};

DateTime? requestStartDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetResourcesResponse result = await siteController.GetResourceAvailabilitiesAsync(
        version,
        siteId,
        authorization,
        requestEndDate,
        requestLimit,
        requestLocationIds,
        requestOffset,
        requestProgramIds,
        requestResourceIds,
        requestScheduleTypes,
        requestStartDate
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Resources

Get resources used at a site.

```csharp
GetResourcesAsync(
    string version,
    string siteId,
    string authorization = null,
    DateTime? requestEndDateTime = null,
    bool? requestIncludeInactive = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    List<int> requestLocationIds = null,
    int? requestOffset = null,
    List<int> requestProgramIds = null,
    List<int> requestResourceIds = null,
    List<Models.RequestScheduleTypeEnum> requestScheduleTypes = null,
    List<int> requestSessionTypeIds = null,
    DateTime? requestStartDateTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestEndDateTime` | `DateTime?` | Query, Optional | The time the resource ends. This parameter is ignored if `EndDateTime` or `LocationID` is not set. |
| `requestIncludeInactive` | `bool?` | Query, Optional | Enable to include inactive |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | The location of the resource. This parameter is ignored if `EndDateTime` or `LocationID` is not set.<br /><br>Default: **all** |
| `requestLocationIds` | `List<int>` | Query, Optional | Filter by location ids (optional) |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestProgramIds` | `List<int>` | Query, Optional | Filter by program ids (optional) |
| `requestResourceIds` | `List<int>` | Query, Optional | Filter on resourceIds |
| `requestScheduleTypes` | [`List<RequestScheduleTypeEnum>`](../../doc/models/request-schedule-type-enum.md) | Query, Optional | Filter by schedule types (optional) |
| `requestSessionTypeIds` | `List<int>` | Query, Optional | List of session type IDs.<br /><br>Default: **all** |
| `requestStartDateTime` | `DateTime?` | Query, Optional | The time the resource starts. This parameter is ignored if `EndDateTime` or `LocationID` is not set. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
DateTime? requestEndDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
bool? requestIncludeInactive = false;
int? requestLimit = 62;
int? requestLocationId = 90;
List<int> requestLocationIds = new List<int>
{
    192,
};

int? requestOffset = 100;
List<int> requestProgramIds = new List<int>
{
    91,
    92,
    93,
};

List<int> requestResourceIds = new List<int>
{
    62,
};

List<RequestScheduleTypeEnum> requestScheduleTypes = new List<RequestScheduleTypeEnum>
{
    RequestScheduleTypeEnum.Appointment,
    RequestScheduleTypeEnum.Resource,
    RequestScheduleTypeEnum.Media,
};

List<int> requestSessionTypeIds = new List<int>
{
    228,
    229,
};

DateTime? requestStartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    object result = await siteController.GetResourcesAsync(
        version,
        siteId,
        authorization,
        requestEndDateTime,
        requestIncludeInactive,
        requestLimit,
        requestLocationId,
        requestLocationIds,
        requestOffset,
        requestProgramIds,
        requestResourceIds,
        requestScheduleTypes,
        requestSessionTypeIds,
        requestStartDateTime
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Session Types

Get the session types used at a site.

```csharp
GetSessionTypesAsync(
    string version,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null,
    bool? requestOnlineOnly = null,
    List<int> requestProgramIDs = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `bool?` | Query, Optional | When `true`, indicates that only the session types that can be booked online should be returned.<br /><br>Default: **false** |
| `requestProgramIDs` | `List<int>` | Query, Optional | Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return. |

## Response Type

[`Task<Models.GetSessionTypesResponse>`](../../doc/models/get-session-types-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
int? requestLimit = 62;
int? requestOffset = 100;
bool? requestOnlineOnly = false;
List<int> requestProgramIDs = new List<int>
{
    52,
    53,
    54,
};

try
{
    GetSessionTypesResponse result = await siteController.GetSessionTypesAsync(
        version,
        siteId,
        authorization,
        requestLimit,
        requestOffset,
        requestOnlineOnly,
        requestProgramIDs
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Sites

Gets a list of sites that the developer has permission to view.

* Passing in no `SiteIds` returns all sites that the developer has access to.
* Passing in one `SiteIds` returns more detailed information about the specified site.

```csharp
GetSitesAsync(
    string version,
    string authorization = null,
    bool? requestIncludeLeadChannels = null,
    bool? requestIncludePerStaffPricing = null,
    int? requestLimit = null,
    int? requestOffset = null,
    List<int> requestSiteIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestIncludeLeadChannels` | `bool?` | Query, Optional | This is an optional parameter to get lead channels for a Site. |
| `requestIncludePerStaffPricing` | `bool?` | Query, Optional | Include whether or not studios have per staff pricing enabled. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSiteIds` | `List<int>` | Query, Optional | List of the requested site IDs. When omitted, returns all sites that the source has access to. |

## Response Type

[`Task<Models.GetSitesResponse>`](../../doc/models/get-sites-response.md)

## Example Usage

```csharp
string version = "6";
string authorization = "authorization6";
bool? requestIncludeLeadChannels = false;
bool? requestIncludePerStaffPricing = false;
int? requestLimit = 62;
int? requestOffset = 100;
List<int> requestSiteIds = new List<int>
{
    135,
    136,
};

try
{
    GetSitesResponse result = await siteController.GetSitesAsync(
        version,
        authorization,
        requestIncludeLeadChannels,
        requestIncludePerStaffPricing,
        requestLimit,
        requestOffset,
        requestSiteIds
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Client Index

Creates a new client index record at the specified business.
This endpoint requires staff user credentials.

```csharp
AddClientIndexAsync(
    string version,
    Models.AddSiteClientIndexRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddSiteClientIndexRequest`](../../doc/models/add-site-client-index-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddSiteClientIndexResponse>`](../../doc/models/add-site-client-index-response.md)

## Example Usage

```csharp
string version = "6";
AddSiteClientIndexRequest request = new AddSiteClientIndexRequest
{
    ClientIndexName = "ClientIndexName2",
    Active = false,
    ShowOnNewClient = false,
    ShowOnEnrollmentRoster = false,
    EditOnEnrollmentRoster = false,
    SortOrder = 50,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    AddSiteClientIndexResponse result = await siteController.AddClientIndexAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Promo Code

Creates a new promocode record at the specified business.
This endpoint requires staff user credentials. This staff memeber should have enabled the **Set up promotions / Semester discounts** staff permission.

```csharp
AddPromoCodeAsync(
    string version,
    Models.AddPromoCodeRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddPromoCodeRequest`](../../doc/models/add-promo-code-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddPromoCodeResponse>`](../../doc/models/add-promo-code-response.md)

## Example Usage

```csharp
string version = "6";
AddPromoCodeRequest request = new AddPromoCodeRequest
{
    Code = "Code6",
    Name = "Name6",
    Active = false,
    Discount = new Discount
    {
        Type = "Type6",
        Amount = 80.68,
    },
    ActivationDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    ExpirationDate = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind),
    MaxUses = 192,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    AddPromoCodeResponse result = await siteController.AddPromoCodeAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Deactivate Promo Code

Deactivates an existing promocode record at the specified business.
This endpoint requires staff user credentials. This staff memeber should have enabled the **Set up promotions / Semester discounts** staff permission.

```csharp
DeactivatePromoCodeAsync(
    string version,
    Models.DeactivatePromoCodeRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`DeactivatePromoCodeRequest`](../../doc/models/deactivate-promo-code-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task<object>`

## Example Usage

```csharp
string version = "6";
DeactivatePromoCodeRequest request = new DeactivatePromoCodeRequest
{
    PromotionId = 42,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    object result = await siteController.DeactivatePromoCodeAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Client Index

Updates an exisitng client index record at the specified business.
This endpoint requires staff user credentials.

```csharp
UpdateClientIndexAsync(
    string version,
    Models.UpdateSiteClientIndexRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateSiteClientIndexRequest`](../../doc/models/update-site-client-index-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateSiteClientIndexResponse>`](../../doc/models/update-site-client-index-response.md)

## Example Usage

```csharp
string version = "6";
UpdateSiteClientIndexRequest request = new UpdateSiteClientIndexRequest
{
    ClientIndexID = 194,
    ClientIndexName = "ClientIndexName2",
    Active = false,
    ShowOnNewClient = false,
    ShowOnEnrollmentRoster = false,
    EditOnEnrollmentRoster = false,
    SortOrder = 50,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    UpdateSiteClientIndexResponse result = await siteController.UpdateClientIndexAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

