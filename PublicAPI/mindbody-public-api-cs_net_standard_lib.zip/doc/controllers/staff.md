# Staff

```csharp
StaffController staffController = client.StaffController;
```

## Class Name

`StaffController`

## Methods

* [Get Staff Image URL](../../doc/controllers/staff.md#get-staff-image-url)
* [Get Sales Reps](../../doc/controllers/staff.md#get-sales-reps)
* [Get Staff Session Types](../../doc/controllers/staff.md#get-staff-session-types)
* [Get Staff](../../doc/controllers/staff.md#get-staff)
* [Get Staff Permissions](../../doc/controllers/staff.md#get-staff-permissions)
* [Add Staff](../../doc/controllers/staff.md#add-staff)
* [Assign Staff Session Type](../../doc/controllers/staff.md#assign-staff-session-type)
* [Add Staff Availability](../../doc/controllers/staff.md#add-staff-availability)
* [Update Staff](../../doc/controllers/staff.md#update-staff)
* [Update Staff Permissions](../../doc/controllers/staff.md#update-staff-permissions)


# Get Staff Image URL

This endpoint can be utilized to retrieve image urls for requested staff member.

```csharp
GetStaffImageURLAsync(
    string version,
    string siteId,
    string authorization = null,
    long? requestStaffId = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestStaffId` | `long?` | Query, Optional | The ID of the staff member whose image URL details you want to retrieve. |

## Response Type

[`Task<Models.GetStaffImageURLResponse>`](../../doc/models/get-staff-image-url-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
long? requestStaffId = 180L;
try
{
    GetStaffImageURLResponse result = await staffController.GetStaffImageURLAsync(
        version,
        siteId,
        authorization,
        requestStaffId
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Sales Reps

This endpoint returns the basic details of the staffs that are marked as sales reps.

```csharp
GetSalesRepsAsync(
    string version,
    string siteId,
    string authorization = null,
    bool? requestActiveOnly = null,
    int? requestLimit = null,
    int? requestOffset = null,
    List<int> requestSalesRepNumbers = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestActiveOnly` | `bool?` | Query, Optional | When `true`, will return only active reps data.<br>Default : **false** |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSalesRepNumbers` | `List<int>` | Query, Optional | This is the list of the sales rep numbers for which the salesrep data will be fetched. |

## Response Type

[`Task<Models.GetSalesRepsResponse>`](../../doc/models/get-sales-reps-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
bool? requestActiveOnly = false;
int? requestLimit = 62;
int? requestOffset = 100;
List<int> requestSalesRepNumbers = new List<int>
{
    123,
    124,
    125,
};

try
{
    GetSalesRepsResponse result = await staffController.GetSalesRepsAsync(
        version,
        siteId,
        authorization,
        requestActiveOnly,
        requestLimit,
        requestOffset,
        requestSalesRepNumbers
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Staff Session Types

Gets a list of active session types for a specific staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```csharp
GetStaffSessionTypesAsync(
    string version,
    long requestStaffId,
    string siteId,
    string authorization = null,
    int? requestLimit = null,
    int? requestOffset = null,
    bool? requestOnlineOnly = null,
    List<int> requestProgramIds = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestStaffId` | `long` | Query, Required | The ID of the staff member whose session types you want to return. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestOnlineOnly` | `bool?` | Query, Optional | When `true`, indicates that only the session types that can be booked online should be returned.<br>Default: **false** |
| `requestProgramIds` | `List<int>` | Query, Optional | Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return. |

## Response Type

[`Task<Models.GetStaffSessionTypesResponse>`](../../doc/models/get-staff-session-types-response.md)

## Example Usage

```csharp
string version = "6";
long requestStaffId = 180L;
string siteId = "-99";
string authorization = "authorization6";
int? requestLimit = 62;
int? requestOffset = 100;
bool? requestOnlineOnly = false;
List<int> requestProgramIds = new List<int>
{
    91,
    92,
    93,
};

try
{
    GetStaffSessionTypesResponse result = await staffController.GetStaffSessionTypesAsync(
        version,
        requestStaffId,
        siteId,
        authorization,
        requestLimit,
        requestOffset,
        requestOnlineOnly,
        requestProgramIds
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Staff

When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:

* FirstName
* LastName
* Id
* Bio
* DisplayName
* ImageUrl
* EmpID

```csharp
GetStaffAsync(
    string version,
    string siteId,
    string authorization = null,
    List<string> requestFilters = null,
    int? requestLimit = null,
    int? requestLocationId = null,
    int? requestOffset = null,
    int? requestSessionTypeId = null,
    List<long> requestStaffIds = null,
    DateTime? requestStartDateTime = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |
| `requestFilters` | `List<string>` | Query, Optional | Filters to apply to the search. Possible values are:<br><br>* StaffViewable<br>* AppointmentInstructor<br>* ClassInstructor<br>* Male<br>* Female |
| `requestLimit` | `int?` | Query, Optional | Number of results to include, defaults to 100 |
| `requestLocationId` | `int?` | Query, Optional | Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter. |
| `requestOffset` | `int?` | Query, Optional | Page offset, defaults to 0. |
| `requestSessionTypeId` | `int?` | Query, Optional | Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter. |
| `requestStaffIds` | `List<long>` | Query, Optional | A list of the requested staff IDs. |
| `requestStartDateTime` | `DateTime?` | Query, Optional | Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter. |

## Response Type

[`Task<Models.GetStaffResponse>`](../../doc/models/get-staff-response.md)

## Example Usage

```csharp
string version = "6";
string siteId = "-99";
string authorization = "authorization6";
List<string> requestFilters = new List<string>
{
    "request.filters0",
    "request.filters1",
    "request.filters2",
};

int? requestLimit = 62;
int? requestLocationId = 90;
int? requestOffset = 100;
int? requestSessionTypeId = 100;
List<long> requestStaffIds = new List<long>
{
    23L,
    24L,
    25L,
};

DateTime? requestStartDateTime = DateTime.ParseExact("2016-03-13T12:52:32.123Z", "yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK",
        provider: CultureInfo.InvariantCulture,
        DateTimeStyles.RoundtripKind);
try
{
    GetStaffResponse result = await staffController.GetStaffAsync(
        version,
        siteId,
        authorization,
        requestFilters,
        requestLimit,
        requestLocationId,
        requestOffset,
        requestSessionTypeId,
        requestStaffIds,
        requestStartDateTime
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Get Staff Permissions

Get configured staff permissions for a staff member.

```csharp
GetStaffPermissionsAsync(
    string version,
    long requestStaffId,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `requestStaffId` | `long` | Query, Required | The ID of the staff member whose permissions you want to return. |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.GetStaffPermissionsResponse>`](../../doc/models/get-staff-permissions-response.md)

## Example Usage

```csharp
string version = "6";
long requestStaffId = 180L;
string siteId = "-99";
string authorization = "authorization6";
try
{
    GetStaffPermissionsResponse result = await staffController.GetStaffPermissionsAsync(
        version,
        requestStaffId,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Staff

Creates a new staff member record at the specified business. The `FirstName` and `LastName` parameters are always required for this request.

```csharp
AddStaffAsync(
    string version,
    Models.AddStaffRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddStaffRequest`](../../doc/models/add-staff-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AddStaffResponse>`](../../doc/models/add-staff-response.md)

## Example Usage

```csharp
string version = "6";
AddStaffRequest request = new AddStaffRequest
{
    FirstName = "FirstName8",
    LastName = "LastName8",
    Email = "Email8",
    IsMale = false,
    HomePhone = "HomePhone8",
    WorkPhone = "WorkPhone2",
    MobilePhone = "MobilePhone6",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    AddStaffResponse result = await staffController.AddStaffAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Assign Staff Session Type

Assigns a staff member to an appointment session type with staff specific properties such as time length and pay rate. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```csharp
AssignStaffSessionTypeAsync(
    string version,
    Models.AssignStaffSessionTypeRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AssignStaffSessionTypeRequest`](../../doc/models/assign-staff-session-type-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.AssignStaffSessionTypeResponse>`](../../doc/models/assign-staff-session-type-response.md)

## Example Usage

```csharp
string version = "6";
AssignStaffSessionTypeRequest request = new AssignStaffSessionTypeRequest
{
    StaffId = 188L,
    SessionTypeId = 82,
    Active = false,
    TimeLength = 222,
    PrepTime = 166,
    FinishTime = 246,
    PayRateType = "PayRateType2",
    PayRateAmount = 169.62,
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    AssignStaffSessionTypeResponse result = await staffController.AssignStaffSessionTypeAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Add Staff Availability

Enables to add staff availability or unavailability for a given staff member.

```csharp
AddStaffAvailabilityAsync(
    string version,
    Models.AddStaffAvailabilityRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`AddStaffAvailabilityRequest`](../../doc/models/add-staff-availability-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

`Task`

## Example Usage

```csharp
string version = "6";
AddStaffAvailabilityRequest request = new AddStaffAvailabilityRequest
{
    StaffId = 188L,
    IsAvailability = false,
    DaysOfWeek = new List<string>
    {
        "DaysOfWeek7",
    },
    StartTime = "StartTime4",
    EndTime = "EndTime0",
    StartDate = "StartDate0",
    EndDate = "EndDate6",
    Description = "Description0",
    ProgramIds = new List<int>
    {
        238,
    },
    LocationId = 238,
    Status = "Status4",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    await staffController.AddStaffAvailabilityAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Staff

Updates an existing staff member record at the specified business. The ID is a required parameters for this request.

```csharp
UpdateStaffAsync(
    string version,
    Models.UpdateStaffRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateStaffRequest`](../../doc/models/update-staff-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateStaffResponse>`](../../doc/models/update-staff-response.md)

## Example Usage

```csharp
string version = "6";
UpdateStaffRequest request = new UpdateStaffRequest
{
    ID = 142L,
    FirstName = "FirstName8",
    LastName = "LastName8",
    Email = "Email8",
    IsMale = false,
    HomePhone = "HomePhone8",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    UpdateStaffResponse result = await staffController.UpdateStaffAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```


# Update Staff Permissions

Assigns a permission group to a staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```csharp
UpdateStaffPermissionsAsync(
    string version,
    Models.UpdateStaffPermissionsRequest request,
    string siteId,
    string authorization = null)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `string` | Template, Required | version of the api. |
| `request` | [`UpdateStaffPermissionsRequest`](../../doc/models/update-staff-permissions-request.md) | Body, Required | - |
| `siteId` | `string` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `string` | Header, Optional | A staff user authorization token. |

## Response Type

[`Task<Models.UpdateStaffPermissionsResponse>`](../../doc/models/update-staff-permissions-response.md)

## Example Usage

```csharp
string version = "6";
UpdateStaffPermissionsRequest request = new UpdateStaffPermissionsRequest
{
    StaffId = 188L,
    PermissionGroupName = "PermissionGroupName8",
};

string siteId = "-99";
string authorization = "authorization6";
try
{
    UpdateStaffPermissionsResponse result = await staffController.UpdateStaffPermissionsAsync(
        version,
        request,
        siteId,
        authorization
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

