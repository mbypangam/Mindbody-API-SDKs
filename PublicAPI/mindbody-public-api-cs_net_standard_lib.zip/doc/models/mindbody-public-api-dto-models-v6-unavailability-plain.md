
# Mindbody Public Api Dto Models V6 Unavailability Plain

## Structure

`MindbodyPublicApiDtoModelsV6UnavailabilityPlain`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID of the unavailability. |
| `StaffId` | `long?` | Optional | Id of the staff |
| `StartDateTime` | `DateTime?` | Optional | The date and time the unavailability starts. |
| `EndDateTime` | `DateTime?` | Optional | The date and time the unavailability ends. |
| `Description` | `string` | Optional | A description of the unavailability. |

## Example (as JSON)

```json
{
  "Id": null,
  "StaffId": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Description": null
}
```

