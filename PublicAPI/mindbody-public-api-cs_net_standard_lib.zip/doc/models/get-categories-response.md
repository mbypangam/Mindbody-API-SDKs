
# Get Categories Response

Get Categories Response Model

## Structure

`GetCategoriesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `Categories` | [`List<Models.Category>`](../../doc/models/category.md) | Optional | Contains the Category objects, each of which describes the categories for a site. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Categories": null
}
```

