
# Get Categories Response

Get Categories Response Model

## Structure

`GetCategoriesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `Categories` | [`List<Models.Category>`](../../doc/models/category.md) | Optional | Contains the Category objects, each of which describes the categories for a site. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Categories": [
    {
      "Id": 159,
      "CategoryName": "CategoryName3",
      "Description": "Description5",
      "Service": true,
      "Active": true
    },
    {
      "Id": 160,
      "CategoryName": "CategoryName4",
      "Description": "Description4",
      "Service": false,
      "Active": false
    },
    {
      "Id": 161,
      "CategoryName": "CategoryName5",
      "Description": "Description3",
      "Service": true,
      "Active": true
    }
  ]
}
```

