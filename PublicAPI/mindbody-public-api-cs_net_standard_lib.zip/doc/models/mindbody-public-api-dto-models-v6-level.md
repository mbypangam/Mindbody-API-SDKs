
# Mindbody Public Api Dto Models V6 Level

A session level.

## Structure

`MindbodyPublicApiDtoModelsV6Level`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The level's ID. |
| `Name` | `string` | Optional | The level's name. |
| `Description` | `string` | Optional | The level's description. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null
}
```

