
# Suspend Contract Response

## Structure

`SuspendContractResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Contract` | [`Models.ClientContract`](../../doc/models/client-contract.md) | Optional | Contains information about client contract. |

## Example (as JSON)

```json
{
  "Contract": null
}
```

