
# Suspend Contract Response

## Structure

`SuspendContractResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Contract` | [`Models.MindbodyPublicApiDtoModelsV6ClientContract`](../../doc/models/mindbody-public-api-dto-models-v6-client-contract.md) | Optional | Contains information about client contract. |

## Example (as JSON)

```json
{
  "Contract": null
}
```

