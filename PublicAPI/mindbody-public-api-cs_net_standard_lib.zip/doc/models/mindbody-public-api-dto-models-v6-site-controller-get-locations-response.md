
# Mindbody Public Api Dto Models V6 Site Controller Get Locations Response

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetLocationsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. |
| `Locations` | [`List<Models.MindbodyPublicApiDtoModelsV6Location>`](../../doc/models/mindbody-public-api-dto-models-v6-location.md) | Optional | Contains information about the locations. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Locations": null
}
```

