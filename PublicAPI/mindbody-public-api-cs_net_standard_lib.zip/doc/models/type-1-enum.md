
# Type 1 Enum

## Enumeration

`Type1Enum`

## Fields

| Name |
|  --- |
| `All` |
| `DropIn` |
| `Enrollment` |
| `Appointment` |
| `Resource` |
| `Media` |
| `Arrival` |

