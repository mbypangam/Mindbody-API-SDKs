
# Create Reservation Response

Create reservation response.

## Structure

`CreateReservationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Reservation` | [`Models.Reservation`](../../doc/models/reservation.md) | Optional | Reservation details. |
| `ResponseDetails` | [`Models.ResponseDetails`](../../doc/models/response-details.md) | Optional | Response details, e.g. status, transactionId. |

## Example (as JSON)

```json
{
  "Reservation": null,
  "ResponseDetails": null
}
```

