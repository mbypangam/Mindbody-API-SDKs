
# Availability 1

The availability of a specific staff

## Structure

`Availability1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | Id of the availability |
| `Staff` | [`Models.Staff1`](../../doc/models/staff-1.md) | Optional | - |
| `SessionType` | [`Models.SessionType1`](../../doc/models/session-type-1.md) | Optional | - |
| `Programs` | [`List<Models.Program1>`](../../doc/models/program-1.md) | Optional | Availabilities program list. |
| `StartDateTime` | `DateTime?` | Optional | Availabilities start date and time. |
| `EndDateTime` | `DateTime?` | Optional | Availabilities end date and time. |
| `BookableEndDateTime` | `DateTime?` | Optional | Availabilities bookable end date and time. |
| `Location` | [`Models.Location1`](../../doc/models/location-1.md) | Optional | - |
| `PrepTime` | `int?` | Optional | Appointment prep time |
| `FinishTime` | `int?` | Optional | Appointment finish time |

## Example (as JSON)

```json
{
  "Id": 146,
  "Staff": {
    "Id": 176,
    "FirstName": "FirstName6",
    "LastName": "LastName6",
    "DisplayName": "DisplayName4",
    "Email": "Email6"
  },
  "SessionType": {
    "Type": "DropIn",
    "DefaultTimeLength": 30,
    "StaffTimeLength": 52,
    "ProgramId": 60,
    "NumDeducted": 64
  },
  "Programs": [
    {
      "CancelOffset": 77,
      "Id": 87,
      "Name": "Name7",
      "ScheduleType": "DropIn",
      "ContentFormat": "Other"
    },
    {
      "CancelOffset": 78,
      "Id": 88,
      "Name": "Name8",
      "ScheduleType": "Enrollment",
      "ContentFormat": "InPerson"
    },
    {
      "CancelOffset": 79,
      "Id": 89,
      "Name": "Name9",
      "ScheduleType": "Appointment",
      "ContentFormat": "Mindbody"
    }
  ],
  "StartDateTime": "2016-03-13T12:52:32.123Z"
}
```

