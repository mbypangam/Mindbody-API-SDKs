
# Availability 1

The availability of a specific staff

## Structure

`Availability1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | Id of the availability |
| `Staff` | [`Models.Staff1`](../../doc/models/staff-1.md) | Optional | Availabilities staff. |
| `Resources` | [`List<Models.Resource1>`](../../doc/models/resource-1.md) | Optional | Available resources |
| `SessionType` | [`Models.SessionType1`](../../doc/models/session-type-1.md) | Optional | Availabilities session type. |
| `Programs` | [`List<Models.Program1>`](../../doc/models/program-1.md) | Optional | Availabilities program list. |
| `StartDateTime` | `DateTime?` | Optional | Availabilities start date and time. |
| `EndDateTime` | `DateTime?` | Optional | Availabilities end date and time. |
| `BookableEndDateTime` | `DateTime?` | Optional | Availabilities bookable end date and time. |
| `Location` | [`Models.Location1`](../../doc/models/location-1.md) | Optional | Availabilities location. |
| `PrepTime` | `int?` | Optional | Appointment prep time |
| `FinishTime` | `int?` | Optional | Appointment finish time |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "Resources": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

