
# Get Client Complete Info Response

Contains information about the requested client.

## Structure

`GetClientCompleteInfoResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Client` | [`ClientWithSuspensionInfo`](../../doc/models/client-with-suspension-info.md) | Optional | A Client DTO with Suspension Informatoin |
| `ClientServices` | [`List<ClientService>`](../../doc/models/client-service.md) | Optional | Contains information about client pricing options. |
| `ClientContracts` | [`List<ClientContract>`](../../doc/models/client-contract.md) | Optional | Contains information about client contract. |
| `ClientMemberships` | [`List<ClientMembership>`](../../doc/models/client-membership.md) | Optional | Contains information about client Memberships. |
| `ClientArrivals` | [`List<ClientArrival>`](../../doc/models/client-arrival.md) | Optional | Contains information about client arrival services. |

## Example (as JSON)

```json
{
  "Client": {
    "SuspensionInfo": {
      "BookingSuspended": false,
      "SuspensionStartDate": "SuspensionStartDate0",
      "SuspensionEndDate": "SuspensionEndDate4"
    },
    "AppointmentGenderPreference": "None",
    "BirthDate": "2016-03-13T12:52:32.123Z",
    "Country": "Country8",
    "CreationDate": "2016-03-13T12:52:32.123Z"
  },
  "ClientServices": [
    {
      "ActiveDate": "2016-03-13T12:52:32.123Z",
      "Count": 208,
      "Current": false,
      "ExpirationDate": "2016-03-13T12:52:32.123Z",
      "Id": 144
    },
    {
      "ActiveDate": "2016-03-13T12:52:32.123Z",
      "Count": 209,
      "Current": true,
      "ExpirationDate": "2016-03-13T12:52:32.123Z",
      "Id": 145
    }
  ],
  "ClientContracts": [
    {
      "AgreementDate": "2016-03-13T12:52:32.123Z",
      "AutopayStatus": "Suspended",
      "ContractName": "ContractName8",
      "EndDate": "2016-03-13T12:52:32.123Z",
      "Id": 162
    },
    {
      "AgreementDate": "2016-03-13T12:52:32.123Z",
      "AutopayStatus": "Inactive",
      "ContractName": "ContractName9",
      "EndDate": "2016-03-13T12:52:32.123Z",
      "Id": 163
    }
  ],
  "ClientMemberships": [
    {
      "RestrictedLocations": [
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs3"
          ],
          "Address": "Address1",
          "Address2": "Address23",
          "Amenities": [
            {
              "Id": 71,
              "Name": "Name9"
            },
            {
              "Id": 72,
              "Name": "Name8"
            }
          ],
          "BusinessDescription": "BusinessDescription7"
        },
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs2",
            "AdditionalImageURLs3",
            "AdditionalImageURLs4"
          ],
          "Address": "Address2",
          "Address2": "Address24",
          "Amenities": [
            {
              "Id": 70,
              "Name": "Name0"
            }
          ],
          "BusinessDescription": "BusinessDescription8"
        }
      ],
      "IconCode": "IconCode6",
      "MembershipId": 116,
      "ActiveDate": "2016-03-13T12:52:32.123Z",
      "Count": 116
    },
    {
      "RestrictedLocations": [
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs4",
            "AdditionalImageURLs5"
          ],
          "Address": "Address0",
          "Address2": "Address22",
          "Amenities": [
            {
              "Id": 72,
              "Name": "Name8"
            },
            {
              "Id": 73,
              "Name": "Name7"
            },
            {
              "Id": 74,
              "Name": "Name6"
            }
          ],
          "BusinessDescription": "BusinessDescription6"
        }
      ],
      "IconCode": "IconCode7",
      "MembershipId": 117,
      "ActiveDate": "2016-03-13T12:52:32.123Z",
      "Count": 117
    },
    {
      "RestrictedLocations": [
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs5",
            "AdditionalImageURLs6",
            "AdditionalImageURLs7"
          ],
          "Address": "Address9",
          "Address2": "Address21",
          "Amenities": [
            {
              "Id": 73,
              "Name": "Name7"
            }
          ],
          "BusinessDescription": "BusinessDescription5"
        },
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs4",
            "AdditionalImageURLs5"
          ],
          "Address": "Address0",
          "Address2": "Address22",
          "Amenities": [
            {
              "Id": 72,
              "Name": "Name8"
            },
            {
              "Id": 73,
              "Name": "Name7"
            },
            {
              "Id": 74,
              "Name": "Name6"
            }
          ],
          "BusinessDescription": "BusinessDescription6"
        },
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs3"
          ],
          "Address": "Address1",
          "Address2": "Address23",
          "Amenities": [
            {
              "Id": 71,
              "Name": "Name9"
            },
            {
              "Id": 72,
              "Name": "Name8"
            }
          ],
          "BusinessDescription": "BusinessDescription7"
        }
      ],
      "IconCode": "IconCode8",
      "MembershipId": 118,
      "ActiveDate": "2016-03-13T12:52:32.123Z",
      "Count": 118
    }
  ],
  "ClientArrivals": [
    {
      "ArrivalProgramID": 1,
      "ArrivalProgramName": "ArrivalProgramName9",
      "CanAccess": true,
      "LocationsIDs": [
        24,
        25,
        26
      ]
    },
    {
      "ArrivalProgramID": 2,
      "ArrivalProgramName": "ArrivalProgramName8",
      "CanAccess": false,
      "LocationsIDs": [
        25
      ]
    },
    {
      "ArrivalProgramID": 3,
      "ArrivalProgramName": "ArrivalProgramName7",
      "CanAccess": true,
      "LocationsIDs": [
        26,
        27
      ]
    }
  ]
}
```

