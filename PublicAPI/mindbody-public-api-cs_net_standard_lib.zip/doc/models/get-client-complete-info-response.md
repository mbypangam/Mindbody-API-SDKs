
# Get Client Complete Info Response

Contains information about the requested client.

## Structure

`GetClientCompleteInfoResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Client` | [`Models.ClientWithSuspensionInfo`](../../doc/models/client-with-suspension-info.md) | Optional | A Client DTO with Suspension Informatoin |
| `ClientServices` | [`List<Models.ClientService>`](../../doc/models/client-service.md) | Optional | Contains information about client pricing options. |
| `ClientContracts` | [`List<Models.ClientContract>`](../../doc/models/client-contract.md) | Optional | Contains information about client contract. |
| `ClientMemberships` | [`List<Models.ClientMembership>`](../../doc/models/client-membership.md) | Optional | Contains information about client Memberships. |
| `ClientArrivals` | [`List<Models.ClientArrival>`](../../doc/models/client-arrival.md) | Optional | Contains information about client arrival services. |

## Example (as JSON)

```json
{
  "Client": null,
  "ClientServices": null,
  "ClientContracts": null,
  "ClientMemberships": null,
  "ClientArrivals": null
}
```

