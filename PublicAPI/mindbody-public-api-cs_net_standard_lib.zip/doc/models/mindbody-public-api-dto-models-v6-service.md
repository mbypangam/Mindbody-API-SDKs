
# Mindbody Public Api Dto Models V6 Service

## Structure

`MindbodyPublicApiDtoModelsV6Service`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Price` | `double?` | Optional | The cost of the pricing option when sold at a physical location. |
| `OnlinePrice` | `double?` | Optional | The cost of the pricing option when sold online. |
| `TaxIncluded` | `double?` | Optional | The amount of tax included in the price, if inclusive pricing is enabled. |
| `ProgramId` | `int?` | Optional | The ID of the program that this pricing option applies to. |
| `TaxRate` | `double?` | Optional | The tax rate applied to the pricing option. This field is populated only when you include a `LocationID` in the request. |
| `ProductId` | `int?` | Optional | The unique ID of the pricing option. |
| `Id` | `string` | Optional | The barcode ID of the pricing option. |
| `Name` | `string` | Optional | The name of the pricing option. |
| `Count` | `int?` | Optional | The initial count of usages available for the pricing option. |
| `SellOnline` | `bool?` | Optional | A flag for whether or not the pricing option is sold online. |
| `SaleInContractOnly` | `bool?` | Optional | A flag for whether or not the pricing option is contractonly. |
| `Type` | `string` | Optional | Indicates if the pricing option is a drop-in, series, or unlimiited. |
| `ExpirationType` | `string` | Optional | Indicates if the pricing option begins its activation on the date of sale or first usage. |
| `ExpirationUnit` | `string` | Optional | The unit, either days or months, of ExpirationLength. |
| `ExpirationLength` | `int?` | Optional | The lifetime of a pricing option. |
| `RevenueCategory` | `string` | Optional | The revenue category of the pricing option. |
| `MembershipId` | `int?` | Optional | The ID that this pricing option grants membership to. |
| `SellAtLocationIds` | `List<int>` | Optional | The location IDs where this pricing option is sold. |
| `UseAtLocationIds` | `List<int>` | Optional | The location IDs where this pricing option may be used. |
| `Priority` | `string` | Optional | The priority of the pricing option. |
| `IsIntroOffer` | `bool?` | Optional | A flag that indicates if this pricing option is an introductory offer. |
| `IntroOfferType` | `string` | Optional | Indicates if this pricing option may be purchased to new clients or all clients. |
| `IsThirdPartyDiscountPricing` | `bool?` | Optional | A flag that indicates if this pricing option involves a third party discount |
| `Program` | `string` | Optional | The name of the program corresponding to ProgramId. |
| `Discontinued` | `bool?` | Optional | Whether this pricing option has been discontinued or not |

## Example (as JSON)

```json
{
  "Price": null,
  "OnlinePrice": null,
  "TaxIncluded": null,
  "ProgramId": null,
  "TaxRate": null,
  "ProductId": null,
  "Id": null,
  "Name": null,
  "Count": null,
  "SellOnline": null,
  "SaleInContractOnly": null,
  "Type": null,
  "ExpirationType": null,
  "ExpirationUnit": null,
  "ExpirationLength": null,
  "RevenueCategory": null,
  "MembershipId": null,
  "SellAtLocationIds": null,
  "UseAtLocationIds": null,
  "Priority": null,
  "IsIntroOffer": null,
  "IntroOfferType": null,
  "IsThirdPartyDiscountPricing": null,
  "Program": null,
  "Discontinued": null
}
```

