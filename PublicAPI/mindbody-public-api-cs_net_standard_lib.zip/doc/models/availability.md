
# Availability

A staff availability entry

## Structure

`Availability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID of the availability. |
| `Staff` | [`Models.Staff`](../../doc/models/staff.md) | Optional | The Staff |
| `SessionType` | [`Models.SessionType`](../../doc/models/session-type.md) | Optional | SessionType contains information about the session types in a business. |
| `Programs` | [`List<Models.Program>`](../../doc/models/program.md) | Optional | Contains information about the programs. |
| `StartDateTime` | `DateTime?` | Optional | The date and time the availability starts. |
| `EndDateTime` | `DateTime?` | Optional | The date and time the availability ends. |
| `BookableEndDateTime` | `DateTime?` | Optional | The time of day that the last appointment can start. |
| `Location` | [`Models.Location`](../../doc/models/location.md) | Optional | - |
| `PrepTime` | `int?` | Optional | Prep time in minutes |
| `FinishTime` | `int?` | Optional | Finish time in minutes |
| `IsMasked` | `bool?` | Optional | When `true`, indicates that the staff member's name for availabilty is masked.<br>When `false`, indicates that the staff member's name for availabilty is not masked. |
| `ShowPublic` | `bool?` | Optional | When `true`, indicates that the schedule is shown to the clients.<br>When `false`, indicates that the schedule is hidden from the clients. |

## Example (as JSON)

```json
{
  "Id": 146,
  "Staff": {
    "Address": "Address8",
    "AppointmentInstructor": false,
    "AlwaysAllowDoubleBooking": false,
    "Bio": "Bio2",
    "City": "City8"
  },
  "SessionType": {
    "Type": "Class",
    "DefaultTimeLength": 30,
    "StaffTimeLength": 52,
    "Id": 52,
    "Name": "Name8"
  },
  "Programs": [
    {
      "Id": 87,
      "Name": "Name7",
      "ScheduleType": "Class",
      "CancelOffset": 77,
      "ContentFormats": [
        "ContentFormats8",
        "ContentFormats9"
      ]
    },
    {
      "Id": 88,
      "Name": "Name8",
      "ScheduleType": "Enrollment",
      "CancelOffset": 78,
      "ContentFormats": [
        "ContentFormats9",
        "ContentFormats0",
        "ContentFormats1"
      ]
    },
    {
      "Id": 89,
      "Name": "Name9",
      "ScheduleType": "Appointment",
      "CancelOffset": 79,
      "ContentFormats": [
        "ContentFormats0"
      ]
    }
  ],
  "StartDateTime": "2016-03-13T12:52:32.123Z"
}
```

