
# Availability

A staff availability entry

## Structure

`Availability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID of the availability. |
| `Staff` | [`Models.Staff`](../../doc/models/staff.md) | Optional | The Staff |
| `SessionType` | [`Models.SessionType`](../../doc/models/session-type.md) | Optional | SessionType contains information about the session types in a business. |
| `Programs` | [`List<Models.Program>`](../../doc/models/program.md) | Optional | Contains information about the programs. |
| `StartDateTime` | `DateTime?` | Optional | The date and time the availability starts. |
| `EndDateTime` | `DateTime?` | Optional | The date and time the availability ends. |
| `BookableEndDateTime` | `DateTime?` | Optional | The time of day that the last appointment can start. |
| `Location` | [`Models.Location`](../../doc/models/location.md) | Optional | - |
| `PrepTime` | `int?` | Optional | Prep time in minutes |
| `FinishTime` | `int?` | Optional | Finish time in minutes |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

