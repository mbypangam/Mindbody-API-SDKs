
# Get Transactions Response

Get Transactions Response Properties

## Structure

`GetTransactionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Transactions` | [`List<Models.Transaction>`](../../doc/models/transaction.md) | Optional | Contains the transaction objects, each of which describes the transaction details for a purchase event. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Transactions": null
}
```

