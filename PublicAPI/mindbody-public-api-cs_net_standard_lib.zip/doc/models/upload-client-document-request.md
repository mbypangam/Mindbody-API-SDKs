
# Upload Client Document Request

## Structure

`UploadClientDocumentRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | The RSSID of the client for whom the document is to be uploaded. |
| `File` | [`Models.MindbodyPublicApiDtoModelsV6ClientDocument`](../../doc/models/mindbody-public-api-dto-models-v6-client-document.md) | Required | Contains information about the file to be uploaded. |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "File": {
    "FileName": "FileName6",
    "MediaType": "MediaType6",
    "Buffer": "Buffer8"
  }
}
```

