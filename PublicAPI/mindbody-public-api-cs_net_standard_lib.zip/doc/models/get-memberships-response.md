
# Get Memberships Response

## Structure

`GetMembershipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Memberships` | [`List<Models.Membership>`](../../doc/models/membership.md) | Optional | Details about the memberships. |

## Example (as JSON)

```json
{
  "Memberships": null
}
```

