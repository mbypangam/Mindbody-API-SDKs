
# Get Memberships Response

## Structure

`GetMembershipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Memberships` | [`List<Membership>`](../../doc/models/membership.md) | Optional | Details about the memberships. |

## Example (as JSON)

```json
{
  "Memberships": [
    {
      "MembershipId": 43,
      "MembershipName": "MembershipName1",
      "Priority": 249,
      "MemberRetailDiscount": 147.35,
      "MemberServiceDiscount": 163.15
    }
  ]
}
```

