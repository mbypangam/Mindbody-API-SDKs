
# Mindbody Public Api Dto Models V6 Prospect Stage

## Structure

`MindbodyPublicApiDtoModelsV6ProspectStage`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Active` | `bool?` | Optional | When `true`, indicates that the client is a prospect at the business and has not yet purchased any of the business pricing options.<br>When `false`, indicates that the client has already purchased at least one pricing option from the business. |
| `Description` | `string` | Optional | A description of the prospect stage. |
| `Id` | `int?` | Optional | The ID of the prospect stage assigned to the client. |

## Example (as JSON)

```json
{
  "Active": null,
  "Description": null,
  "Id": null
}
```

