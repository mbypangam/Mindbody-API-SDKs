
# Mindbody Public Api Dto Models V6 Sale Controller Update Product Price Request

Update Product Price Request Model

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerUpdateProductPriceRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BarcodeId` | `string` | Optional | The barcode number of the product. This is the `Products[].Id` returned from GET Products. |
| `Price` | `double?` | Optional | The price you sell the product for. |
| `OnlinePrice` | `double?` | Optional | The online price of the product. |

## Example (as JSON)

```json
{
  "BarcodeId": null,
  "Price": null,
  "OnlinePrice": null
}
```

