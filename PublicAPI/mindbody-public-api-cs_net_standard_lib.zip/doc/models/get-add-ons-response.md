
# Get Add Ons Response

Get AddOns Response Model

## Structure

`GetAddOnsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `AddOns` | [`List<AppointmentAddOn>`](../../doc/models/appointment-add-on.md) | Optional | A list of available add-ons. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "AddOns": [
    {
      "Id": 14,
      "Name": "Name6",
      "NumDeducted": 102,
      "CategoryId": 184,
      "Category": "Category8"
    },
    {
      "Id": 15,
      "Name": "Name7",
      "NumDeducted": 101,
      "CategoryId": 185,
      "Category": "Category9"
    }
  ]
}
```

