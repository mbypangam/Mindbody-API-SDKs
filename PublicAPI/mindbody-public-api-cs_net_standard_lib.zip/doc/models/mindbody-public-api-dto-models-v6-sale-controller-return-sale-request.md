
# Mindbody Public Api Dto Models V6 Sale Controller Return Sale Request

ReturnSaleRequest

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerReturnSaleRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SaleId` | `long?` | Optional | The Sale ID of the sale item to be returned. |
| `ReturnReason` | `string` | Optional | The reason for the return. |

## Example (as JSON)

```json
{
  "SaleId": null,
  "ReturnReason": null
}
```

