
# Get Enrollments Response

## Structure

`GetEnrollmentsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Enrollments` | [`List<Models.MindbodyPublicApiDtoModelsV6ClassSchedule>`](../../doc/models/mindbody-public-api-dto-models-v6-class-schedule.md) | Optional | Contains information about the enrollments. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Enrollments": null
}
```

