
# Update Availability Response

This is the update avaialability response

## Structure

`UpdateAvailabilityResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StaffMembers` | [`List<Models.MindbodyPublicApiDtoModelsV6Staff>`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | This is the success list of the trainer availability |
| `Errors` | [`List<Models.MindbodyPublicApiDtoModelsV6ApiError>`](../../doc/models/mindbody-public-api-dto-models-v6-api-error.md) | Optional | - |

## Example (as JSON)

```json
{
  "StaffMembers": null,
  "Errors": null
}
```

