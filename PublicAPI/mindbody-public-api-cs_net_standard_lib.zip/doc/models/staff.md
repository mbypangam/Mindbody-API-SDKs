
# Staff

The Staff

## Structure

`Staff`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Address` | `string` | Optional | The address of the staff member who is teaching the class. |
| `AppointmentInstructor` | `bool?` | Optional | When `true`, indicates that the staff member offers appointments.<br /><br>When `false`, indicates that the staff member does not offer appointments. |
| `AlwaysAllowDoubleBooking` | `bool?` | Optional | When `true`, indicates that the staff member can be scheduled for overlapping services.<br /><br>When `false`, indicates that the staff can only be scheduled for one service at a time in any given time-frame. |
| `Bio` | `string` | Optional | The staff member’s biography. This string contains HTML. |
| `City` | `string` | Optional | The staff member’s city. |
| `Country` | `string` | Optional | The staff member’s country. |
| `Email` | `string` | Optional | The staff member’s email address. |
| `FirstName` | `string` | Optional | The staff member’s first name. |
| `DisplayName` | `string` | Optional | The staff member’s Nickname. |
| `HomePhone` | `string` | Optional | The staff member’s home phone number. |
| `Id` | `long?` | Optional | The ID assigned to the staff member. |
| `IndependentContractor` | `bool?` | Optional | When `true`, indicates that the staff member is an independent contractor.<br>When `false`, indicates that the staff member is not an independent contractor. |
| `IsMale` | `bool?` | Optional | When `true`, indicates that the staff member is male.<br>When `false`, indicates that the staff member is female. |
| `LastName` | `string` | Optional | The staff member’s last name. |
| `MobilePhone` | `string` | Optional | The staff member’s mobile phone number. |
| `Name` | `string` | Optional | The staff member’s name. |
| `PostalCode` | `string` | Optional | The staff member’s postal code. |
| `ClassTeacher` | `bool?` | Optional | When `true`, indicates that the staff member can teach classes.<br>When `false`, indicates that the staff member cannot teach classes. |
| `SortOrder` | `int?` | Optional | If configured by the business owner, this field determines a staff member’s weight when sorting. Use this field to sort staff members on your interface. |
| `State` | `string` | Optional | The staff member’s state. |
| `WorkPhone` | `string` | Optional | The staff member’s work phone number. |
| `ImageUrl` | `string` | Optional | The URL of the staff member’s image, if one has been uploaded. |
| `ClassAssistant` | `bool?` | Optional | Is the staff an assistant |
| `ClassAssistant2` | `bool?` | Optional | Is the staff an assistant2 |
| `EmploymentStart` | `DateTime?` | Optional | The start date of employment |
| `EmploymentEnd` | `DateTime?` | Optional | The end date of employment |
| `ProviderIDs` | `List<string>` | Optional | A list of ProviderIds for the staff. |
| `Rep` | `bool?` | Optional | return true if staff is sales Rep 1 else false. |
| `Rep2` | `bool?` | Optional | return true if staff is sales Rep 2 else false. |
| `Rep3` | `bool?` | Optional | return true if staff is sales Rep 3 else false. |
| `Rep4` | `bool?` | Optional | return true if staff is sales Rep 4 else false. |
| `Rep5` | `bool?` | Optional | return true if staff is sales Rep 5 else false. |
| `Rep6` | `bool?` | Optional | return true if staff is sales Rep 6 else false. |
| `StaffSettings` | [`StaffSetting`](../../doc/models/staff-setting.md) | Optional | contains the information about the staff settings. |
| `Appointments` | [`List<Appointment>`](../../doc/models/appointment.md) | Optional | A list of appointments for the staff. |
| `Unavailabilities` | [`List<Unavailability>`](../../doc/models/unavailability.md) | Optional | A list of unavailabilities for the staff. |
| `Availabilities` | [`List<Availability>`](../../doc/models/availability.md) | Optional | A list of availabilities for the staff. |
| `EmpID` | `string` | Optional | The EmpID assigned to the staff member. |

## Example (as JSON)

```json
{
  "Address": "Address8",
  "AppointmentInstructor": false,
  "AlwaysAllowDoubleBooking": false,
  "Bio": "Bio2",
  "City": "City2"
}
```

