
# Add Availabilities Response

Add Availabilities Response Model

## Structure

`AddAvailabilitiesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StaffMembers` | [`List<Models.Staff1>`](../../doc/models/staff-1.md) | Optional | Contains information about the staff. |
| `Errors` | [`List<Models.ApiError1>`](../../doc/models/api-error-1.md) | Optional | Contains information about the error. |

## Example (as JSON)

```json
{
  "StaffMembers": [
    {
      "Id": 202,
      "FirstName": "FirstName8",
      "LastName": "LastName8",
      "DisplayName": "DisplayName0",
      "Email": "Email8"
    },
    {
      "Id": 203,
      "FirstName": "FirstName7",
      "LastName": "LastName7",
      "DisplayName": "DisplayName9",
      "Email": "Email7"
    }
  ],
  "Errors": [
    {
      "Message": "Message8",
      "Code": "Code2"
    }
  ]
}
```

