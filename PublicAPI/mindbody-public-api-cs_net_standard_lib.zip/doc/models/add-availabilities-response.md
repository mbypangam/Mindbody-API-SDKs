
# Add Availabilities Response

## Structure

`AddAvailabilitiesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StaffMembers` | [`List<Models.MindbodyPublicApiCommonModelsStaff>`](../../doc/models/mindbody-public-api-common-models-staff.md) | Optional | Contains information about the staff. |
| `Errors` | [`List<Models.MindbodyPublicApiCommonModelsApiError>`](../../doc/models/mindbody-public-api-common-models-api-error.md) | Optional | Contains information about the error. |

## Example (as JSON)

```json
{
  "StaffMembers": null,
  "Errors": null
}
```

