
# Lead Channel

## Structure

`LeadChannel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |
| `SalespipelineId` | `int?` | Optional | - |
| `UniversalCustomerId` | `Guid?` | Optional | - |
| `StudioId` | `int?` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "SalespipelineId": null,
  "UniversalCustomerId": null,
  "StudioId": null
}
```

