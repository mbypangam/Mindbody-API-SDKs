
# Lead Channel

## Structure

`LeadChannel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |
| `SalespipelineId` | `int?` | Optional | - |
| `UniversalCustomerId` | `Guid?` | Optional | - |
| `StudioId` | `int?` | Optional | - |

## Example (as JSON)

```json
{
  "Id": 122,
  "Name": "Name2",
  "SalespipelineId": 222,
  "UniversalCustomerId": "00000000-0000-0000-0000-000000000000",
  "StudioId": 118
}
```

