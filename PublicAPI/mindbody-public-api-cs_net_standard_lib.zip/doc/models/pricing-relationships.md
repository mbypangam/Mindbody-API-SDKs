
# Pricing Relationships

## Structure

`PricingRelationships`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaysFor` | `List<int>` | Optional | - |
| `PaidBy` | `List<int>` | Optional | - |

## Example (as JSON)

```json
{
  "PaysFor": [
    92
  ],
  "PaidBy": [
    198,
    199
  ]
}
```

