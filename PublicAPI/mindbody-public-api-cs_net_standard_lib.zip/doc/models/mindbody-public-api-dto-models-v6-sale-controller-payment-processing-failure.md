
# Mindbody Public Api Dto Models V6 Sale Controller Payment Processing Failure

Contains information about any payment processing failure.  Specifically for when an SCA challenge is

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerPaymentProcessingFailure`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `string` | Optional | Returned only if SCA challenge is indicated. |
| `Message` | `string` | Optional | Returned only if SCA challenge is indicated. |
| `AuthenticationRedirectUrl` | `string` | Optional | Returned only if SCA challenge is indicated. |

## Example (as JSON)

```json
{
  "Type": null,
  "Message": null,
  "AuthenticationRedirectUrl": null
}
```

