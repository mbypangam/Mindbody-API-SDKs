
# Checkout Item Wrapper

## Structure

`CheckoutItemWrapper`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Item` | [`CheckoutItem`](../../doc/models/checkout-item.md) | Optional | - |
| `DiscountAmount` | `double?` | Optional | The amount the item is discounted. This parameter is ignored for packages. |
| `AppointmentBookingRequests` | [`List<CheckoutAppointmentBookingRequest>`](../../doc/models/checkout-appointment-booking-request.md) | Optional | A list of appointments to be booked then paid for by this item. This parameter applies only to pricing option items. |
| `EnrollmentIds` | `List<int>` | Optional | A list of enrollment IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `ClassIds` | `List<int>` | Optional | A list of class IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `CourseIds` | `List<long>` | Optional | A list of course IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `VisitIds` | `List<long>` | Optional | A list of visit IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `AppointmentIds` | `List<long>` | Optional | A list of appointment IDs that this item is to reconcile. |
| `Id` | `int?` | Optional | The item’s unique ID within the cart. |
| `Quantity` | `int?` | Optional | The number of this item to be purchased. |

## Example (as JSON)

```json
{
  "Item": {
    "Type": "Type2",
    "Metadata": {
      "key0": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  },
  "DiscountAmount": 68.14,
  "AppointmentBookingRequests": [
    {
      "StaffId": 214,
      "LocationId": 248,
      "SessionTypeId": 108,
      "Resources": [
        {
          "Id": 169,
          "Name": "Name7"
        },
        {
          "Id": 168,
          "Name": "Name8"
        }
      ],
      "StartDateTime": "2016-03-13T12:52:32.123Z"
    }
  ],
  "EnrollmentIds": [
    51,
    52
  ],
  "ClassIds": [
    211,
    212,
    213
  ]
}
```

