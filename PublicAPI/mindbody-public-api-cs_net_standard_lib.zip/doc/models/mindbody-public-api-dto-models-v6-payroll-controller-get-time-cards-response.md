
# Mindbody Public Api Dto Models V6 Payroll Controller Get Time Cards Response

## Structure

`MindbodyPublicApiDtoModelsV6PayrollControllerGetTimeCardsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `TimeCards` | [`List<Models.MindbodyPublicApiDtoModelsV6TimeCardEvent>`](../../doc/models/mindbody-public-api-dto-models-v6-time-card-event.md) | Optional | Information about time card entries, ordered by staff ID. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "TimeCards": null
}
```

