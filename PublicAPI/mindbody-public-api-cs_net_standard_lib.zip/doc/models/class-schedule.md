
# Class Schedule

Represents a single class instance. The class meets at the start time, goes until the end time.

## Structure

`ClassSchedule`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Classes` | [`List<Models.Class>`](../../doc/models/class.md) | Optional | Contains information about a class. |
| `Clients` | [`List<Models.Client>`](../../doc/models/client.md) | Optional | Contains information about clients. |
| `Course` | [`Models.Course`](../../doc/models/course.md) | Optional | A course. |
| `SemesterId` | `int?` | Optional | The semester ID for the enrollment (if any). |
| `IsAvailable` | `bool?` | Optional | When `true`, indicates that the enrollment shows in consumer mode, has not started yet, and there is room in each class of the enrollment.<br /><br>When `false`, indicates that either the enrollment does not show in consumer mode, has already started, or there is no room in some classes of the enrollment. |
| `Id` | `int?` | Optional | The unique ID of the class schedule. |
| `ClassDescription` | [`Models.ClassDescription`](../../doc/models/class-description.md) | Optional | Represents a class definition. The class meets at the start time, goes until the end time. |
| `DaySunday` | `bool?` | Optional | When `true`, indicates that this schedule occurs on Sundays. |
| `DayMonday` | `bool?` | Optional | When `true`, indicates that this schedule occurs on Mondays. |
| `DayTuesday` | `bool?` | Optional | When `true`, indicates that this schedule occurs on Tuesdays. |
| `DayWednesday` | `bool?` | Optional | When `true`, indicates that this schedule occurs on Wednesdays. |
| `DayThursday` | `bool?` | Optional | When `true`, indicates that this schedule occurs on Thursdays. |
| `DayFriday` | `bool?` | Optional | When `true`, indicates that this schedule occurs on Fridays. |
| `DaySaturday` | `bool?` | Optional | When `true`, indicates that this schedule occurs on Saturdays. |
| `AllowOpenEnrollment` | `bool?` | Optional | When `true`, indicates that the enrollment allows booking after the enrollment has started. |
| `AllowDateForwardEnrollment` | `bool?` | Optional | When `true`, indicates that this the enrollment shows in consumer mode, the enrollment has not started yet, and there is room in each class of the enrollment. |
| `StartTime` | `DateTime?` | Optional | The time this class schedule starts. |
| `EndTime` | `DateTime?` | Optional | The time this class schedule ends. |
| `StartDate` | `DateTime?` | Optional | The date this class schedule starts. |
| `EndDate` | `DateTime?` | Optional | The date this class schedule ends. |
| `Staff` | [`Models.Staff`](../../doc/models/staff.md) | Optional | The Staff |
| `Location` | [`Models.Location`](../../doc/models/location.md) | Optional | - |

## Example (as JSON)

```json
{
  "Classes": null,
  "Clients": null,
  "Course": null,
  "SemesterId": null,
  "IsAvailable": null,
  "Id": null,
  "ClassDescription": null,
  "DaySunday": null,
  "DayMonday": null,
  "DayTuesday": null,
  "DayWednesday": null,
  "DayThursday": null,
  "DayFriday": null,
  "DaySaturday": null,
  "AllowOpenEnrollment": null,
  "AllowDateForwardEnrollment": null,
  "StartTime": null,
  "EndTime": null,
  "StartDate": null,
  "EndDate": null,
  "Staff": null,
  "Location": null
}
```

