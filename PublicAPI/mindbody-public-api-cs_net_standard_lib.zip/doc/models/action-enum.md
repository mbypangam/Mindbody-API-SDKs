
# Action Enum

## Enumeration

`ActionEnum`

## Fields

| Name |
|  --- |
| `None` |
| `Added` |
| `Updated` |
| `Failed` |
| `Removed` |

