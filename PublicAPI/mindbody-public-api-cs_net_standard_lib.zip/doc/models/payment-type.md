
# Payment Type

## Structure

`PaymentType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The Payment Type Id used for api calls. |
| `PaymentTypeName` | `string` | Optional | Payment Type Name |
| `Active` | `bool?` | Optional | Check if Payment type is active. |
| `Fee` | `double?` | Optional | Payment type fee. |

## Example (as JSON)

```json
{
  "Id": 170,
  "PaymentTypeName": "PaymentTypeName0",
  "Active": false,
  "Fee": 17.74
}
```

