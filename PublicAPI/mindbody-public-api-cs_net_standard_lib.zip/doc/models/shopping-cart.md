
# Shopping Cart

Represents a shopping cart.

## Structure

`ShoppingCart`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | The shopping cart ID. |
| `CartItems` | [`List<CartItem>`](../../doc/models/cart-item.md) | Optional | Contains information about the items in the shopping cart. |
| `SubTotal` | `double?` | Optional | The cart’s total cost before taxes and discounts were applied. |
| `DiscountTotal` | `double?` | Optional | The monetary amount removed from the cart’s total cost by applied discounts. |
| `TaxTotal` | `double?` | Optional | The monetary amount paid in taxes, included in the cart’s `GrandTotal`. |
| `GrandTotal` | `double?` | Optional | The cart’s total cost, including taxes and discounts. |
| `Transactions` | [`List<TransactionResponse>`](../../doc/models/transaction-response.md) | Optional | Contains information returned from the first call to CheckoutShoppingCart. |
| `SaleId` | `long?` | Optional | The ID of the sale associated with the shopping cart. |

## Example (as JSON)

```json
{
  "Id": "Id0",
  "CartItems": [
    {
      "Item": {
        "key1": "val1",
        "key2": "val2"
      },
      "SalesNotes": "SalesNotes8",
      "DiscountAmount": 4.36,
      "VisitIds": [
        232,
        233
      ],
      "AppointmentIds": [
        98
      ]
    },
    {
      "Item": {
        "key1": "val1",
        "key2": "val2"
      },
      "SalesNotes": "SalesNotes8",
      "DiscountAmount": 4.36,
      "VisitIds": [
        232,
        233
      ],
      "AppointmentIds": [
        98
      ]
    },
    {
      "Item": {
        "key1": "val1",
        "key2": "val2"
      },
      "SalesNotes": "SalesNotes8",
      "DiscountAmount": 4.36,
      "VisitIds": [
        232,
        233
      ],
      "AppointmentIds": [
        98
      ]
    }
  ],
  "SubTotal": 108.54,
  "DiscountTotal": 99.92,
  "TaxTotal": 136.36
}
```

