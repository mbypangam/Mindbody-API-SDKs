
# Issue Request

POST UserToken/Issue request

## Structure

`IssueRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Username` | `string` | Optional | The staff member’s username. |
| `Password` | `string` | Optional | The staff member’s password. |

## Example (as JSON)

```json
{
  "Username": "Username2",
  "Password": "Password4"
}
```

