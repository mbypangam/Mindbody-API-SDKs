
# Get Client Contracts Response

## Structure

`GetClientContractsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `Contracts` | [`List<Models.ClientContract>`](../../doc/models/client-contract.md) | Optional | Contains the details of the client’s contract. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Contracts": null
}
```

