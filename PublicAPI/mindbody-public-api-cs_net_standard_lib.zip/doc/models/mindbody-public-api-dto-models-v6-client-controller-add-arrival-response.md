
# Mindbody Public Api Dto Models V6 Client Controller Add Arrival Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ArrivalAdded` | `bool?` | Optional | When `true`, indicates that the arrival was added to the database. |
| `ClientService` | [`Models.MindbodyPublicApiDtoModelsV6ClientService`](../../doc/models/mindbody-public-api-dto-models-v6-client-service.md) | Optional | Contains information about the pricing option being used to pay for the client?s current service session. |

## Example (as JSON)

```json
{
  "ArrivalAdded": null,
  "ClientService": null
}
```

