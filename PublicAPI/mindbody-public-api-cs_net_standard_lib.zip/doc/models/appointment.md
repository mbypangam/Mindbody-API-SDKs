
# Appointment

Contains information about an appointment.

## Structure

`Appointment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `GenderPreference` | [`Models.GenderPreferenceEnum?`](../../doc/models/gender-preference-enum.md) | Optional | The prefered gender of the appointment provider.<br>Possible values are:<br><br>* None<br>* Female<br>* Male |
| `Duration` | `int?` | Optional | The duration of the appointment. |
| `ProviderId` | `string` | Optional | If a user has Complementary and Alternative Medicine features enabled, this property indicates the provider assigned to the appointment. |
| `Id` | `long?` | Optional | The unique ID of the appointment. |
| `Status` | [`Models.StatusEnum?`](../../doc/models/status-enum.md) | Optional | The status of this appointment.<br>Possible values are:<br><br>* None<br>* Requested<br>* Booked<br>* Completed<br>* Confirmed<br>* Arrived<br>* NoShow<br>* Cancelled<br>* LateCancelled |
| `StartDateTime` | `DateTime?` | Optional | The date and time the appointment is to start. |
| `EndDateTime` | `DateTime?` | Optional | The date and time the appointment is to end. |
| `Notes` | `string` | Optional | Any notes associated with the appointment. |
| `PartnerExternalId` | `string` | Optional | Optional external key for api partners. |
| `StaffRequested` | `bool?` | Optional | When `true`, indicates that the staff member was requested specifically by the client. |
| `ProgramId` | `int?` | Optional | The ID of the program to which this appointment belongs. |
| `SessionTypeId` | `int?` | Optional | The ID of the session type of this appointment. |
| `LocationId` | `int?` | Optional | The ID of the location where this appointment is to take place. |
| `StaffId` | `long?` | Optional | The ID of the staff member providing the service for this appointment. |
| `ClientId` | `string` | Optional | The RSSID of the client who is booked for this appointment. |
| `FirstAppointment` | `bool?` | Optional | When `true`, indicates that this is the client’s first appointment at this site. |
| `IsWaitlist` | `bool?` | Optional | When `true`, indicates that the client should be added to a specific appointment waiting list.<br>When `false`, the client should not be added to the waiting list.<br>Default: *false* |
| `WaitlistEntryId` | `long?` | Optional | The unique ID of the appointment waitlist. |
| `ClientServiceId` | `long?` | Optional | The ID of the pass on the client’s account that is to pay for this appointment. |
| `Resources` | [`List<Models.Resource>`](../../doc/models/resource.md) | Optional | The resources this appointment is to use. |
| `AddOns` | [`List<Models.AddOnSmall>`](../../doc/models/add-on-small.md) | Optional | Any AddOns associated with the appointment |
| `OnlineDescription` | `string` | Optional | Online Description associated with the appointment |

## Example (as JSON)

```json
{
  "GenderPreference": null,
  "Duration": null,
  "ProviderId": null,
  "Id": null,
  "Status": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Notes": null,
  "PartnerExternalId": null,
  "StaffRequested": null,
  "ProgramId": null,
  "SessionTypeId": null,
  "LocationId": null,
  "StaffId": null,
  "ClientId": null,
  "FirstAppointment": null,
  "IsWaitlist": null,
  "WaitlistEntryId": null,
  "ClientServiceId": null,
  "Resources": null,
  "AddOns": null,
  "OnlineDescription": null
}
```

