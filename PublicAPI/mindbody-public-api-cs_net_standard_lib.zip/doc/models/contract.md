
# Contract

## Structure

`Contract`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The contract’s ID at the subscriber’s business. |
| `Name` | `string` | Optional | The name of the contract. |
| `Description` | `string` | Optional | A description of the contract. |
| `AssignsMembershipId` | `int?` | Optional | The ID of the membership that was assigned to the client when the client signed up for a contract. |
| `AssignsMembershipName` | `string` | Optional | The name of the membership that was assigned to the client when the client signed up for this contract. |
| `SoldOnline` | `bool?` | Optional | When `true`, indicates that this membership is intended to be shown to clients in client experiences.<br /><br>When `false`, this contract should only be shown to staff members. |
| `ContractItems` | [`List<Models.ContractItem>`](../../doc/models/contract-item.md) | Optional | Contains information about the items in the contract. |
| `IntroOffer` | `string` | Optional | Defines whether this contract is treated as an introductory offer. If this is an introductory offer, then clients are always charged a set number of times rather than month to month, using their AutoPays. Possible values are:<br><br>* None<br>* NewConsumer<br>* NewAndReturningConsumer |
| `AutopaySchedule` | [`Models.AutopaySchedule`](../../doc/models/autopay-schedule.md) | Optional | - |
| `NumberOfAutopays` | `int?` | Optional | The number of times that the AutoPay is to be run. This value is null if `FrequencyType` is `MonthToMonth`. |
| `AutopayTriggerType` | `string` | Optional | Defines whether the AutoPay, if applicable to this contract, runs on a set schedule or when the pricing option runs out or expires. Possible values are:<br><br>* OnSetSchedule<br>* PricingOptionRunsOutOrExpires |
| `ActionUponCompletionOfAutopays` | `string` | Optional | The renewal action to be taken when this AutoPay is completed. Possible values are:<br><br>* ContractExpires<br>* ContractAutomaticallyRenews |
| `ClientsChargedOn` | `string` | Optional | The value that indicates when clients are charged. Possible values are:<br><br>* OnSaleDate<br>* FirstOfTheMonth<br>* FifteenthOfTheMonth<br>* LastDayOfTheMonth<br>* FirstOrFifteenthOfTheMonth<br>* FirstOrSixteenthOfTheMonth<br>* FifteenthOrEndOfTheMonth<br>* SpecificDate |
| `ClientsChargedOnSpecificDate` | `DateTime?` | Optional | If `ClientsChargedOn` is defined as a specific date, this property holds the value of that date. Otherwise, this property is null. |
| `DiscountAmount` | `double?` | Optional | The calculated discount applied to the items in this contract. |
| `DepositAmount` | `double?` | Optional | The amount of the deposit required for this contract. |
| `FirstAutopayFree` | `bool?` | Optional | When `true`, indicates that the first payment for the AutoPay is free. |
| `LastAutopayFree` | `bool?` | Optional | When `true`, indicates that the last payment for the AutoPay is free. |
| `ClientTerminateOnline` | `bool?` | Optional | When `true`, indicates that the client can terminate this contract on the Internet. |
| `MembershipTypeRestrictions` | [`List<Models.MembershipTypeRestriction>`](../../doc/models/membership-type-restriction.md) | Optional | Contains information about the memberships that can purchase this contract. If null, then no membership restrictions exist, and anyone can purchase the contract. |
| `LocationPurchaseRestrictionIds` | `List<int>` | Optional | The IDs of the locations where this contract may be sold. If there are no restrictions, this value is null. |
| `LocationPurchaseRestrictionNames` | `List<string>` | Optional | Location names where the contract may be purchased. If this value is null, there are no restrictions. |
| `AgreementTerms` | `string` | Optional | Business-defined terms and conditions for the contract. |
| `RequiresElectronicConfirmation` | `bool?` | Optional | When `true`, clients who purchase the contract are prompted to agree to the terms of the contract the next time that they log in. |
| `AutopayEnabled` | `bool?` | Optional | When `true`, this contract establishes an AutoPay on the client’s account. |
| `FirstPaymentAmountSubtotal` | `double?` | Optional | The subtotal of the amount that the client is to be charged when signing up for the contract. |
| `FirstPaymentAmountTax` | `double?` | Optional | The amount of tax that the client is to be charged when signing up for the contract. |
| `FirstPaymentAmountTotal` | `double?` | Optional | The total amount that the client is to be charged when signing up for the contract. |
| `RecurringPaymentAmountSubtotal` | `double?` | Optional | The subtotal amount that the client is to be charged on an ongoing basis. |
| `RecurringPaymentAmountTax` | `double?` | Optional | The amount of tax the client is to be charged on an ongoing basis. |
| `RecurringPaymentAmountTotal` | `double?` | Optional | The total amount that the client is to be charged on an ongoing basis. |
| `TotalContractAmountSubtotal` | `double?` | Optional | The subtotal amount that the client is to be charged over the lifespan of the contract. |
| `TotalContractAmountTax` | `double?` | Optional | The total amount of tax the client is to be charged over the lifespan of the contract. |
| `TotalContractAmountTotal` | `double?` | Optional | The total amount the client is to be charged over the lifespan of the contract. |
| `PromoPaymentAmountSubtotal` | `double?` | Optional | Subtotal promotional period |
| `PromoPaymentAmountTax` | `double?` | Optional | Taxes of promotional period |
| `PromoPaymentAmountTotal` | `double?` | Optional | Total of promotional period |
| `NumberOfPromoAutopays` | `int?` | Optional | Number of times that the AutoPay runs under the promotional period |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null,
  "AssignsMembershipId": null,
  "AssignsMembershipName": null,
  "SoldOnline": null,
  "ContractItems": null,
  "IntroOffer": null,
  "AutopaySchedule": null,
  "NumberOfAutopays": null,
  "AutopayTriggerType": null,
  "ActionUponCompletionOfAutopays": null,
  "ClientsChargedOn": null,
  "ClientsChargedOnSpecificDate": null,
  "DiscountAmount": null,
  "DepositAmount": null,
  "FirstAutopayFree": null,
  "LastAutopayFree": null,
  "ClientTerminateOnline": null,
  "MembershipTypeRestrictions": null,
  "LocationPurchaseRestrictionIds": null,
  "LocationPurchaseRestrictionNames": null,
  "AgreementTerms": null,
  "RequiresElectronicConfirmation": null,
  "AutopayEnabled": null,
  "FirstPaymentAmountSubtotal": null,
  "FirstPaymentAmountTax": null,
  "FirstPaymentAmountTotal": null,
  "RecurringPaymentAmountSubtotal": null,
  "RecurringPaymentAmountTax": null,
  "RecurringPaymentAmountTotal": null,
  "TotalContractAmountSubtotal": null,
  "TotalContractAmountTax": null,
  "TotalContractAmountTotal": null,
  "PromoPaymentAmountSubtotal": null,
  "PromoPaymentAmountTax": null,
  "PromoPaymentAmountTotal": null,
  "NumberOfPromoAutopays": null
}
```

