
# Purchase Gift Card Response

## Structure

`PurchaseGiftCardResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `BarcodeId` | `string` | Optional | The barcode ID assigned to the purchased gift card. |
| `MValue` | `double?` | Optional | The monetary value of the gift card. |
| `AmountPaid` | `double?` | Optional | The amount paid for the gift card by the purchaser. |
| `FromName` | `string` | Optional | The name of the purchaser. |
| `LayoutId` | `int?` | Optional | The ID of the layout used for this gift card. |
| `EmailReceipt` | `bool?` | Optional | Whether or not an email receipt was sent to the purchaser. If true, a receipt was sent. |
| `PurchaserClientId` | `string` | Optional | The client ID of the purchaser. |
| `PurchaserEmail` | `string` | Optional | The purchaser’s email address. |
| `RecipientEmail` | `string` | Optional | The recipient’s email address. |
| `SaleId` | `long?` | Optional | The sale ID of the gift card. |
| `PaymentProcessingFailures` | [`List<Models.PaymentProcessingFailure>`](../../doc/models/payment-processing-failure.md) | Optional | Any cart processing failures, for example when SCA challenged, the cart is in PaymentAuthenticationRequired state and at least one of the failures listed will provide an authentication Url. |

## Example (as JSON)

```json
{
  "BarcodeId": null,
  "Value": null,
  "AmountPaid": null,
  "FromName": null,
  "LayoutId": null,
  "EmailReceipt": null,
  "PurchaserClientId": null,
  "PurchaserEmail": null,
  "RecipientEmail": null,
  "SaleId": null,
  "PaymentProcessingFailures": null
}
```

