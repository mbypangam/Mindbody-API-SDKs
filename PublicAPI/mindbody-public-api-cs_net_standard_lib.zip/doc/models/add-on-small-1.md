
# Add on Small 1

## Structure

`AddOnSmall1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The unique ID of the appointment add on. |
| `Name` | `string` | Optional | The Name of the appointment add on. |
| `StaffId` | `long?` | Optional | The unique ID of the staff on appointment. |
| `TypeId` | `int?` | Optional | The ID of the session type of this appointment. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "StaffId": null,
  "TypeId": null
}
```

