
# Applicable Item

Item that will be applied to a promo code

## Structure

`ApplicableItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `string` | Optional | Type of a promo code<br>The promotional item type.<br>Possible values are:<br><br>* ServiceCategory<br>* RevenueCategory<br>* Supplier<br>* Item |
| `Id` | `int?` | Optional | The promotional item ID. |
| `Name` | `string` | Optional | The promotional item name. |

## Example (as JSON)

```json
{
  "Type": null,
  "Id": null,
  "Name": null
}
```

