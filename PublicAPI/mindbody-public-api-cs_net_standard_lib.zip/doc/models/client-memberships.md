
# Client Memberships

## Structure

`ClientMemberships`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Optional | ID of the client. |
| `Memberships` | [`List<Models.ClientMembership>`](../../doc/models/client-membership.md) | Optional | Contains information about the Client Memberships details. |
| `ErrorMessage` | `string` | Optional | Incase if invalid clientID passed, we get ErrorMessage instead of Memberships. |

## Example (as JSON)

```json
{
  "ClientId": null,
  "Memberships": null,
  "ErrorMessage": null
}
```

