
# Get Appointment Options Response

## Structure

`GetAppointmentOptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Options` | [`List<Models.AppointmentOption>`](../../doc/models/appointment-option.md) | Optional | Contains information about the appointment options. |

## Example (as JSON)

```json
{
  "Options": null
}
```

