
# Get Appointment Options Response

## Structure

`GetAppointmentOptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Options` | [`List<Models.MindbodyPublicApiDtoModelsV6AppointmentOption>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-option.md) | Optional | Contains information about the appointment options. |

## Example (as JSON)

```json
{
  "Options": null
}
```

