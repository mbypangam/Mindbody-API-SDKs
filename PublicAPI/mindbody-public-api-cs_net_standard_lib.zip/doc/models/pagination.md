
# Pagination

Contains information about the pagination used.

## Structure

`Pagination`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PageNumber` | `int?` | Optional | Page number of results in dataset. |
| `PageSize` | `int?` | Optional | Number of results returned in this response. |
| `TotalResultCount` | `int?` | Optional | Total number of results in dataset. |
| `TotalPageCount` | `int?` | Optional | Total number of page in dataset. |

## Example (as JSON)

```json
{
  "PageNumber": 160,
  "PageSize": 30,
  "TotalResultCount": 46,
  "TotalPageCount": 116
}
```

