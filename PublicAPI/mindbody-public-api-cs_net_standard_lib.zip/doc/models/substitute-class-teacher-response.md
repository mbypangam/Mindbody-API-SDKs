
# Substitute Class Teacher Response

## Structure

`SubstituteClassTeacherResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Class` | [`Models.SubstituteTeacherClass`](../../doc/models/substitute-teacher-class.md) | Optional | Contains information about the class that is being assigned a substitute teacher. |

## Example (as JSON)

```json
{
  "Class": null
}
```

