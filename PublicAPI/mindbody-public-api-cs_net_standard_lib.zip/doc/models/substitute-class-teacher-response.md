
# Substitute Class Teacher Response

## Structure

`SubstituteClassTeacherResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Class` | [`Models.MindbodyPublicApiDtoModelsV6SubstituteTeacherClass`](../../doc/models/mindbody-public-api-dto-models-v6-substitute-teacher-class.md) | Optional | Contains information about the class that is being assigned a substitute teacher. |

## Example (as JSON)

```json
{
  "Class": null
}
```

