
# Mindbody Public Api Common Models Api Error

## Structure

`MindbodyPublicApiCommonModelsApiError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Optional | - |
| `Code` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Message": null,
  "Code": null
}
```

