
# Purchased Item

## Structure

`PurchasedItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SaleDetailId` | `int?` | Optional | The ID which gets assigned to the item when item is added to the cart. |
| `Id` | `long?` | Optional | The ID of the purchased item. Use this ID when calling the GET Services or GET Products endpoint. |
| `IsService` | `bool?` | Optional | When `true`, indicates that the purchased item was a pricing option for a service. |
| `BarcodeId` | `string` | Optional | The barcode number of the purchased item. Use this ID when calling the GET Products endpoint. |
| `Description` | `string` | Optional | The description of the sale transaction/pricing option. |
| `ContractId` | `int?` | Optional | The contract purchased by the client. Use this ID when calling the GET Contract endpoint. |
| `CategoryId` | `int?` | Optional | The revenue category ID used for sale. Use this ID when calling the GET Categories endpoint. |
| `SubCategoryId` | `int?` | Optional | The ID of revenue subcategory. |
| `UnitPrice` | `double?` | Optional | er Unit Price of the item purchased. |
| `Quantity` | `int?` | Optional | Quantity of the purchased item, applicable for products only. Note: Negative numbers indicate returned items. |
| `DiscountPercent` | `double?` | Optional | The percent discount that was applied to the items subtotal. |
| `DiscountAmount` | `double?` | Optional | The total discount amount that was applied to the items subtotal. |
| `Tax1` | `double?` | Optional | A decimal representation of the first tax rate that was applied to the items subtotal. |
| `Tax2` | `double?` | Optional | A decimal representation of the second tax rate that was applied to the items subtotal. |
| `Tax3` | `double?` | Optional | A decimal representation of the third tax rate that was applied to the items subtotal. |
| `Tax4` | `double?` | Optional | A decimal representation of the fourth tax rate that was applied to the items subtotal. |
| `Tax5` | `double?` | Optional | A decimal representation of the fifth tax rate that was applied to the items subtotal. |
| `TaxAmount` | `double?` | Optional | Total tax amount that is summation of tax1, tax2, tax3, tax4 and tax5. |
| `TotalAmount` | `double?` | Optional | The items total, once discounts and/or tax was applied. |
| `Notes` | `string` | Optional | Note made by the customer while purchasing item. |
| `Returned` | `bool?` | Optional | When `true`, indicates that the purchased item is returned, `false` otherwise. |
| `PaymentRefId` | `int?` | Optional | The payment reference ID generated during payment of sold item. |
| `ExpDate` | `DateTime?` | Optional | The expiration date of the pricing option purchased. |
| `ActiveDate` | `DateTime?` | Optional | The activation date of pricing option purchased. |

## Example (as JSON)

```json
{
  "SaleDetailId": null,
  "Id": null,
  "IsService": null,
  "BarcodeId": null,
  "Description": null,
  "ContractId": null,
  "CategoryId": null,
  "SubCategoryId": null,
  "UnitPrice": null,
  "Quantity": null,
  "DiscountPercent": null,
  "DiscountAmount": null,
  "Tax1": null,
  "Tax2": null,
  "Tax3": null,
  "Tax4": null,
  "Tax5": null,
  "TaxAmount": null,
  "TotalAmount": null,
  "Notes": null,
  "Returned": null,
  "PaymentRefId": null,
  "ExpDate": null,
  "ActiveDate": null
}
```

