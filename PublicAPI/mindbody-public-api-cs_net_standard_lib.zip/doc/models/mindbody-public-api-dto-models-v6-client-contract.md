
# Mindbody Public Api Dto Models V6 Client Contract

A client contract

## Structure

`MindbodyPublicApiDtoModelsV6ClientContract`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AgreementDate` | `DateTime?` | Optional | The date on which the contract was signed. |
| `AutopayStatus` | [`Models.AutopayStatusEnum?`](../../doc/models/autopay-status-enum.md) | Optional | The status of the client?s autopay. |
| `ContractName` | `string` | Optional | The name of the contract. |
| `EndDate` | `DateTime?` | Optional | The date that the contract expires. |
| `Id` | `int?` | Optional | The unique ID of the sale of the contract. Each time a contract is sold, this ID increases sequentially. |
| `OriginationLocationId` | `int?` | Optional | The ID of the location where the contract was issued. |
| `StartDate` | `DateTime?` | Optional | The date that the contract became active. |
| `SiteId` | `int?` | Optional | The ID of the site where the contract was issued. |
| `UpcomingAutopayEvents` | [`List<Models.MindbodyPublicApiDtoModelsV6UpcomingAutopayEvent>`](../../doc/models/mindbody-public-api-dto-models-v6-upcoming-autopay-event.md) | Optional | Contains details of the autopay events. |
| `ContractID` | `int?` | Optional | The ID of the contract |
| `TerminationDate` | `DateTime?` | Optional | The date that the contract was terminated. |

## Example (as JSON)

```json
{
  "AgreementDate": null,
  "AutopayStatus": null,
  "ContractName": null,
  "EndDate": null,
  "Id": null,
  "OriginationLocationId": null,
  "StartDate": null,
  "SiteId": null,
  "UpcomingAutopayEvents": null,
  "ContractID": null,
  "TerminationDate": null
}
```

