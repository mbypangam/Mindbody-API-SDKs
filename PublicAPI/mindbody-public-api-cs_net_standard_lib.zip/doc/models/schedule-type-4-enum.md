
# Schedule Type 4 Enum

## Enumeration

`ScheduleType4Enum`

## Fields

| Name |
|  --- |
| `All` |
| `Class` |
| `Enrollment` |
| `Appointment` |
| `Resource` |
| `Media` |
| `Arrival` |

