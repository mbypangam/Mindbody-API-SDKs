
# Mindbody Public Api Dto Models V6 Sale Controller Initialize Credit Card Entry Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CallbackUrl` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "CallbackUrl": null
}
```

