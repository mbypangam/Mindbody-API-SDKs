
# Mindbody Public Api Dto Models V6 Client Controller Upload Client Photo Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Optional | The RSSID of the client for whom the photo was uploaded. |
| `PhotoUrl` | `string` | Optional | The URL of the uploaded photo. |

## Example (as JSON)

```json
{
  "ClientId": null,
  "PhotoUrl": null
}
```

