
# Mindbody Public Api Dto Models V6 Client Controller Get Client Duplicates Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientDuplicatesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. |
| `ClientDuplicates` | [`List<Models.MindbodyPublicApiDtoModelsV6ClientDuplicate>`](../../doc/models/mindbody-public-api-dto-models-v6-client-duplicate.md) | Optional | The requested clients. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientDuplicates": null
}
```

