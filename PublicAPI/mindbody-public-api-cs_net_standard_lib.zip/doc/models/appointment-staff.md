
# Appointment Staff

## Structure

`AppointmentStaff`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | - |
| `FirstName` | `string` | Optional | - |
| `LastName` | `string` | Optional | - |
| `DisplayName` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": 130,
  "FirstName": "FirstName2",
  "LastName": "LastName2",
  "DisplayName": "DisplayName4"
}
```

