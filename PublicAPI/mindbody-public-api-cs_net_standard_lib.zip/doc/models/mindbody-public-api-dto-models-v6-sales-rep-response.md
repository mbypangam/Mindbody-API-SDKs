
# Mindbody Public Api Dto Models V6 Sales Rep Response

This is the sales rep DTO

## Structure

`MindbodyPublicApiDtoModelsV6SalesRepResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The unique Id of the sales rep |
| `FirstName` | `string` | Optional | The firstname of the sales rep |
| `LastName` | `string` | Optional | The lastname of the sales rep |
| `SalesRepNumbers` | `List<int>` | Optional | The sales rep Ids that are assigned to the rep |

## Example (as JSON)

```json
{
  "Id": null,
  "FirstName": null,
  "LastName": null,
  "SalesRepNumbers": null
}
```

