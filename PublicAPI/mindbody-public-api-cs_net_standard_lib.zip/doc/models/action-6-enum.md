
# Action 6 Enum

The action performed on this object.

## Enumeration

`Action6Enum`

## Fields

| Name |
|  --- |
| `None` |
| `Added` |
| `Updated` |
| `Failed` |
| `Removed` |

