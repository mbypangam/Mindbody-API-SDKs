
# Api Error

## Structure

`ApiError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Message` | `string` | Optional | - |
| `Code` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Message": null,
  "Code": null
}
```

