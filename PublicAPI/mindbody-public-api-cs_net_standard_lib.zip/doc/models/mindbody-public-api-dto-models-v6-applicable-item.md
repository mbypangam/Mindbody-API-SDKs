
# Mindbody Public Api Dto Models V6 Applicable Item

Item that will be applied to a promo code

## Structure

`MindbodyPublicApiDtoModelsV6ApplicableItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `string` | Optional | The promotional item type.<br>Possible values are:<br><br>* ServiceCategory<br>* RevenueCategory<br>* Supplier<br>* Item |
| `Id` | `int?` | Optional | The promotional item ID. |
| `Name` | `string` | Optional | The promotional item name. |

## Example (as JSON)

```json
{
  "Type": null,
  "Id": null,
  "Name": null
}
```

