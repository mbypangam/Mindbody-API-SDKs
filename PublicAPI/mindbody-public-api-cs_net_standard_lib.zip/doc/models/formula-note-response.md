
# Formula Note Response

An individual Client Formula Note.

## Structure

`FormulaNoteResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The formula note ID. |
| `ClientId` | `string` | Optional | The unique Id of the client for the formula note. This is the unique ID for the client in the site where the formula note originated. This is different than the ClientId specified in the request, which is the id for the client assigned by the business. |
| `AppointmentId` | `long?` | Optional | The appointment ID that the formula note is related to. |
| `EntryDate` | `DateTime?` | Optional | The date formula note was created. |
| `Note` | `string` | Optional | The new formula note text. |
| `SiteId` | `int?` | Optional | The site Id. |
| `SiteName` | `string` | Optional | The site name. |
| `StaffFirstName` | `string` | Optional | The first name of the staff for the optional associated appointment. If no appointment ID is provided, this will be null. |
| `StaffLastName` | `string` | Optional | The last name of the staff for the optional associated appointment. If no appointment ID is provided, this will be null. |
| `StaffDisplayName` | `string` | Optional | The display name of the staff for the optional associated appointment. If no appointment ID is provided, or no display name is specified for the staff member, this will be null. |

## Example (as JSON)

```json
{
  "Id": 146,
  "ClientId": "ClientId6",
  "AppointmentId": 22,
  "EntryDate": "2016-03-13T12:52:32.123Z",
  "Note": "Note0"
}
```

