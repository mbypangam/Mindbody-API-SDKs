
# Mindbody Public Api Dto Models V6 Sale Controller Completed Sale Shopping Cart

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleShoppingCart`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | The shopping cart ID. |
| `CartItems` | [`List<Models.MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleCartItem>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-completed-sale-cart-item.md) | Optional | Contains information about the items in the shopping cart. |
| `SubTotal` | `double?` | Optional | The cart’s total cost before taxes and discounts were applied. |
| `DiscountTotal` | `double?` | Optional | The monetary amount removed from the cart’s total cost by applied discounts. |
| `TaxTotal` | `double?` | Optional | The monetary amount paid in taxes, included in the cart’s `GrandTotal`. |
| `GrandTotal` | `double?` | Optional | The cart’s total cost, including taxes and discounts. |
| `Transactions` | [`List<Models.TransactionResponse>`](../../doc/models/transaction-response.md) | Optional | Contains information returned from the first call to CheckoutShoppingCart. |

## Example (as JSON)

```json
{
  "Id": null,
  "CartItems": null,
  "SubTotal": null,
  "DiscountTotal": null,
  "TaxTotal": null,
  "GrandTotal": null,
  "Transactions": null
}
```

