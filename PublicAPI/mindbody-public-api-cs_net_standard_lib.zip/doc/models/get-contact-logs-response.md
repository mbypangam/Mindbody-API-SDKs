
# Get Contact Logs Response

## Structure

`GetContactLogsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `ContactLogs` | [`List<Models.ContactLog>`](../../doc/models/contact-log.md) | Optional | Contains the information about the contact logs. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ContactLogs": null
}
```

