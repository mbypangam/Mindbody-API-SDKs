
# Get Packages Response

## Structure

`GetPackagesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Packages` | [`List<Package>`](../../doc/models/package.md) | Optional | Contains information about the resulting packages. |
| `PaginationResponse` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |

## Example (as JSON)

```json
{
  "Packages": [
    {
      "Id": 107,
      "Name": "Name7",
      "DiscountPercentage": 247.35,
      "SellOnline": true,
      "Services": [
        {
          "Price": 82.08,
          "OnlinePrice": 116.6,
          "TaxIncluded": 189.62,
          "ProgramId": 62,
          "TaxRate": 50.12
        },
        {
          "Price": 82.09,
          "OnlinePrice": 116.61,
          "TaxIncluded": 189.63,
          "ProgramId": 63,
          "TaxRate": 50.13
        },
        {
          "Price": 82.1,
          "OnlinePrice": 116.62,
          "TaxIncluded": 189.64,
          "ProgramId": 64,
          "TaxRate": 50.14
        }
      ]
    },
    {
      "Id": 108,
      "Name": "Name6",
      "DiscountPercentage": 247.36,
      "SellOnline": false,
      "Services": [
        {
          "Price": 82.09,
          "OnlinePrice": 116.61,
          "TaxIncluded": 189.63,
          "ProgramId": 63,
          "TaxRate": 50.13
        }
      ]
    }
  ],
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  }
}
```

