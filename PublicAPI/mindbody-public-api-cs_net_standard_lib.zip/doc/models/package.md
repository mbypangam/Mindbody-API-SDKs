
# Package

## Structure

`Package`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID of the package. |
| `Name` | `string` | Optional | The name of the package. |
| `DiscountPercentage` | `double?` | Optional | The discount percentage applied to the package. |
| `SellOnline` | `bool?` | Optional | When `true`, only products that can be sold online are returned.<br /><br>When `false`, all products are returned. |
| `Services` | [`List<Models.Service>`](../../doc/models/service.md) | Optional | Information about the services in the packages. |
| `Products` | [`List<Models.Product>`](../../doc/models/product.md) | Optional | Information about the products in the packages. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "DiscountPercentage": null,
  "SellOnline": null,
  "Services": null,
  "Products": null
}
```

