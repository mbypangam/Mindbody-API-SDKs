
# Package

## Structure

`Package`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID of the package. |
| `Name` | `string` | Optional | The name of the package. |
| `DiscountPercentage` | `double?` | Optional | The discount percentage applied to the package. |
| `SellOnline` | `bool?` | Optional | When `true`, only products that can be sold online are returned.<br /><br>When `false`, all products are returned. |
| `Services` | [`List<Models.Service>`](../../doc/models/service.md) | Optional | Information about the services in the packages. |
| `Products` | [`List<Models.Product>`](../../doc/models/product.md) | Optional | Information about the products in the packages. |

## Example (as JSON)

```json
{
  "Id": 146,
  "Name": "Name0",
  "DiscountPercentage": 242.62,
  "SellOnline": false,
  "Services": [
    {
      "Price": 77.35,
      "OnlinePrice": 111.87,
      "TaxIncluded": 184.89,
      "ProgramId": 101,
      "TaxRate": 45.39
    }
  ]
}
```

