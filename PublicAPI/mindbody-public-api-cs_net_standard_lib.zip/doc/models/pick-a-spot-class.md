
# Pick a Spot Class

Pick A Spot class detail.

## Structure

`PickASpotClass`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SiteId` | `int?` | Optional | Site ID. |
| `LocationId` | `int?` | Optional | Location ID. |
| `ClassId` | `string` | Optional | Class ID. |
| `ClassExternalId` | `string` | Optional | Class external ID. |
| `ClassName` | `string` | Optional | Class Name. |
| `ClassStartTime` | `DateTime?` | Optional | Class start time. |
| `ClassEndTime` | `DateTime?` | Optional | Class end time. |
| `ClassMaximumCapacity` | `int?` | Optional | Class maximum capacity |
| `RoomId` | `string` | Optional | - |
| `Spots` | [`Models.Spot`](../../doc/models/spot.md) | Optional | - |
| `Reservations` | [`List<Models.Reservation>`](../../doc/models/reservation.md) | Optional | - |

## Example (as JSON)

```json
{
  "SiteId": null,
  "LocationId": null,
  "ClassId": null,
  "ClassExternalId": null,
  "ClassName": null,
  "ClassStartTime": null,
  "ClassEndTime": null,
  "ClassMaximumCapacity": null,
  "RoomId": null,
  "Spots": null,
  "Reservations": null
}
```

