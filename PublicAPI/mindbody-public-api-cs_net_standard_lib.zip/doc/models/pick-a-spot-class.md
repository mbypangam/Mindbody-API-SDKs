
# Pick a Spot Class

Contains information about the PickASpot classes.

## Structure

`PickASpotClass`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SiteId` | `int?` | Optional | The unique ID of the Site. |
| `LocationId` | `int?` | Optional | The unique ID of the Location. |
| `ClassId` | `string` | Optional | The unique ID of the Class. |
| `ClassExternalId` | `string` | Optional | The unique Class external ID. |
| `ClassName` | `string` | Optional | Contains the class name. |
| `ClassStartTime` | `DateTime?` | Optional | Class start time. |
| `ClassEndTime` | `DateTime?` | Optional | Class end time. |
| `ClassMaximumCapacity` | `int?` | Optional | Contains information about the Class maximum capacity. |
| `RoomId` | `string` | Optional | The unique Room ID. |
| `Spots` | [`Models.Spot`](../../doc/models/spot.md) | Optional | Contains information about the spot details. |
| `Reservations` | [`List<Models.Reservation>`](../../doc/models/reservation.md) | Optional | Contains information about the reservation collection. |

## Example (as JSON)

```json
{
  "SiteId": 164,
  "LocationId": 50,
  "ClassId": "ClassId8",
  "ClassExternalId": "ClassExternalId2",
  "ClassName": "ClassName8"
}
```

