
# Get Custom Client Fields Response

## Structure

`GetCustomClientFieldsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `CustomClientFields` | [`List<Models.MindbodyPublicApiDtoModelsV6CustomClientField>`](../../doc/models/mindbody-public-api-dto-models-v6-custom-client-field.md) | Optional | Contains information about the available custom client fields. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "CustomClientFields": null
}
```

