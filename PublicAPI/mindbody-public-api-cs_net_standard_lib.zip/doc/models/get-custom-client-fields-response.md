
# Get Custom Client Fields Response

## Structure

`GetCustomClientFieldsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `CustomClientFields` | [`List<CustomClientField>`](../../doc/models/custom-client-field.md) | Optional | Contains information about the available custom client fields. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "CustomClientFields": [
    {
      "Id": 223,
      "DataType": "DataType1",
      "Name": "Name7"
    },
    {
      "Id": 224,
      "DataType": "DataType2",
      "Name": "Name8"
    },
    {
      "Id": 225,
      "DataType": "DataType3",
      "Name": "Name9"
    }
  ]
}
```

