
# Add on Small

## Structure

`AddOnSmall`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The unique ID of the appointment add-on booking. |
| `Name` | `string` | Optional | The name of the appointment add-on. |
| `StaffId` | `long?` | Optional | The ID of the staff member providing the service for this add-on. |
| `TypeId` | `int?` | Optional | The ID of the session type of this appointment. |

## Example (as JSON)

```json
{
  "Id": 84,
  "Name": "Name6",
  "StaffId": 94,
  "TypeId": 234
}
```

