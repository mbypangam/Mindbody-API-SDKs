
# Response Details

## Structure

`ResponseDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | `string` | Optional | - |
| `TransactionId` | `string` | Optional | - |
| `Message` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Status": null,
  "TransactionId": null,
  "Message": null
}
```

