
# Get Staff Appointments Response

## Structure

`GetStaffAppointmentsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Appointments` | [`List<Models.Appointment>`](../../doc/models/appointment.md) | Optional | Contains information about appointments and their details. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Appointments": null
}
```

