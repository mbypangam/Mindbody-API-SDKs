
# Get Client Rewards Response

## Structure

`GetClientRewardsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Balance` | `long?` | Optional | The total rewards points available to the indicated client after the above transaction. |
| `Transactions` | [`List<Models.MindbodyPublicApiDtoModelsV6ClientRewardTransaction>`](../../doc/models/mindbody-public-api-dto-models-v6-client-reward-transaction.md) | Optional | Contains information about the reward transaction details. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Balance": null,
  "Transactions": null
}
```

