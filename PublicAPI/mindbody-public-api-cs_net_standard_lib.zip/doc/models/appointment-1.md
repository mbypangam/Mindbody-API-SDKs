
# Appointment 1

An appointment

## Structure

`Appointment1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `GenderPreference` | `string` | Optional | Prefered gender of appointment. |
| `Duration` | `int?` | Optional | Duration of appointment. |
| `ProviderId` | `string` | Optional | If a user has Complementary and Alternative Medicine features enabled,<br>this will allow a Provider ID to be assigned to an appointment. |
| `Id` | `long?` | Optional | The unique ID of the appointment. |
| `Status` | [`Models.Status1Enum?`](../../doc/models/status-1-enum.md) | Optional | The status of this appointment. |
| `StartDateTime` | `DateTime?` | Optional | The date and time the appointment will start. |
| `EndDateTime` | `DateTime?` | Optional | The date and time the appointment will end. |
| `Notes` | `string` | Optional | The appointment notes. |
| `PartnerExternalId` | `string` | Optional | Optional external key for api partners. |
| `StaffRequested` | `bool?` | Optional | Whether the staff member was requested specifically by the client. |
| `ProgramId` | `int?` | Optional | The ID of the program this appointment belongs to. |
| `WaitlistEntryId` | `long?` | Optional | The ID of the appointment waitlist. |
| `SessionTypeId` | `int?` | Optional | The ID of the session type of this appointment. |
| `LocationId` | `int?` | Optional | The ID of the location where this appointment will take place. |
| `StaffId` | `long?` | Optional | The ID of the staff member instructing this appointment. |
| `ClientId` | `string` | Optional | The RSSID of the client booked for this appointment. |
| `FirstAppointment` | `bool?` | Optional | Whether this is the client's first appointment at the site. |
| `ClientServiceId` | `long?` | Optional | The ID of the pass on the client's account that is paying for this appointment. |
| `Resources` | [`List<Models.Resource1>`](../../doc/models/resource-1.md) | Optional | The resources this appointment is using. |
| `AddOns` | [`List<Models.AddOnSmall1>`](../../doc/models/add-on-small-1.md) | Optional | The Add-Ons Associated with this appointment |
| `IsWaitlist` | `bool?` | Optional | Whether to add appointment to waitlist. |
| `OnlineDescription` | `string` | Optional | Online Description associated with the appointment |

## Example (as JSON)

```json
{
  "GenderPreference": null,
  "Duration": null,
  "ProviderId": null,
  "Id": null,
  "Status": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Notes": null,
  "PartnerExternalId": null,
  "StaffRequested": null,
  "ProgramId": null,
  "WaitlistEntryId": null,
  "SessionTypeId": null,
  "LocationId": null,
  "StaffId": null,
  "ClientId": null,
  "FirstAppointment": null,
  "ClientServiceId": null,
  "Resources": null,
  "AddOns": null,
  "IsWaitlist": null,
  "OnlineDescription": null
}
```

