
# Contract Item

## Structure

`ContractItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | The ID of the item. |
| `Name` | `string` | Optional | The name of the item. |
| `Description` | `string` | Optional | A description of the item. |
| `Type` | `string` | Optional | The type of the item. |
| `Price` | `double?` | Optional | The price of the item. |
| `Quantity` | `int?` | Optional | The quantity of the item. |
| `OneTimeItem` | `bool?` | Optional | When `true`, indicates that the item is charged only once.<br /><br>When `false`, indicates that the item is charged multiple times. |

## Example (as JSON)

```json
{
  "Id": "Id6",
  "Name": "Name0",
  "Description": "Description6",
  "Type": "Type0",
  "Price": 6.2
}
```

