
# Request Schedule Type Enum

## Enumeration

`RequestScheduleTypeEnum`

## Fields

| Name |
|  --- |
| `All` |
| `Class` |
| `Enrollment` |
| `Appointment` |
| `Resource` |
| `Media` |
| `Arrival` |

