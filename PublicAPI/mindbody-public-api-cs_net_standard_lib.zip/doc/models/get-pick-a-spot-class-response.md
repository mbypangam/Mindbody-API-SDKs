
# Get Pick a Spot Class Response

Pick A Spot class response.

## Structure

`GetPickASpotClassResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Classes` | [`List<Models.PickASpotClass>`](../../doc/models/pick-a-spot-class.md) | Optional | Pick A Spot classes information. |
| `Pagination` | [`Models.Pagination`](../../doc/models/pagination.md) | Optional | Contains information about the pagination used. |
| `ResponseDetails` | [`Models.ResponseDetails`](../../doc/models/response-details.md) | Optional | Contains information about the response details. |

## Example (as JSON)

```json
{
  "classes": null,
  "pagination": null,
  "responseDetails": null
}
```

