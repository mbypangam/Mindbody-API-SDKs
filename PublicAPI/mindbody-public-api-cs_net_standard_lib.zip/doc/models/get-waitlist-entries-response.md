
# Get Waitlist Entries Response

## Structure

`GetWaitlistEntriesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `WaitlistEntries` | [`List<Models.WaitlistEntry>`](../../doc/models/waitlist-entry.md) | Optional | Contains information about the waiting list entries. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "WaitlistEntries": null
}
```

