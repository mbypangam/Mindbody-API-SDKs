
# Spot

## Structure

`Spot`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReservedSpotNumbers` | `List<int>` | Optional | - |
| `AvailableSpotNumbers` | `List<int>` | Optional | - |
| `UnavailableSpotNumbers` | `List<int>` | Optional | - |

## Example (as JSON)

```json
{
  "ReservedSpotNumbers": null,
  "AvailableSpotNumbers": null,
  "UnavailableSpotNumbers": null
}
```

