
# Spot

Contains information about the spot details.

## Structure

`Spot`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReservedSpotNumbers` | `List<int>` | Optional | Contains information about the collection of reserved spot numbers. |
| `AvailableSpotNumbers` | `List<int>` | Optional | Contains information about the collection of available spot numbers. |
| `UnavailableSpotNumbers` | `List<int>` | Optional | Contains information about the collection of Unavailable spot numbers. |

## Example (as JSON)

```json
{
  "ReservedSpotNumbers": [
    164,
    165
  ],
  "AvailableSpotNumbers": [
    68
  ],
  "UnavailableSpotNumbers": [
    83,
    82,
    81
  ]
}
```

