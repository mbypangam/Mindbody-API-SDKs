
# Purchase Account Credit Response

## Structure

`PurchaseAccountCreditResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AmountPaid` | `double?` | Optional | The amount paid for the gift card by the purchaser. |
| `ClientId` | `string` | Optional | The client ID of the purchaser. |
| `SaleId` | `long?` | Optional | The sale ID of the gift card. |
| `EmailReceipt` | `bool?` | Optional | Whether or not an email receipt was sent to the purchaser. If true, a receipt was sent. |
| `PaymentProcessingFailures` | [`List<Models.PaymentProcessingFailure>`](../../doc/models/payment-processing-failure.md) | Optional | Any cart processing failures, for example when SCA challenged, the cart is in PaymentAuthenticationRequired state and at least one of the failures listed will provide an authentication Url. |

## Example (as JSON)

```json
{
  "AmountPaid": 30.76,
  "ClientId": "ClientId6",
  "SaleId": 62,
  "EmailReceipt": false,
  "PaymentProcessingFailures": [
    {
      "Type": "Type4",
      "Message": "Message0",
      "AuthenticationRedirectUrl": "AuthenticationRedirectUrl0"
    }
  ]
}
```

