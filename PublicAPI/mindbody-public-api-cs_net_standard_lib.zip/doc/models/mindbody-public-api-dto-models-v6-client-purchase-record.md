
# Mindbody Public Api Dto Models V6 Client Purchase Record

A record of a specific client purchase

## Structure

`MindbodyPublicApiDtoModelsV6ClientPurchaseRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Sale` | [`Models.MindbodyPublicApiDtoModelsV6Sale`](../../doc/models/mindbody-public-api-dto-models-v6-sale.md) | Optional | Contains details about the sale and payment for a purchase event. |
| `Description` | `string` | Optional | The item name and description. |
| `AccountPayment` | `bool?` | Optional | If `true`, the item was a payment credited to an account. |
| `Price` | `double?` | Optional | The price paid for the item. |
| `AmountPaid` | `double?` | Optional | The amount paid for the item. |
| `Discount` | `double?` | Optional | The discount amount that was applied to the item. |
| `Tax` | `double?` | Optional | The amount of tax that was applied to the item. |
| `Returned` | `bool?` | Optional | The return status of the item. If `true`, this item was returned. |
| `Quantity` | `int?` | Optional | The quantity of the item purchased. |

## Example (as JSON)

```json
{
  "Sale": null,
  "Description": null,
  "AccountPayment": null,
  "Price": null,
  "AmountPaid": null,
  "Discount": null,
  "Tax": null,
  "Returned": null,
  "Quantity": null
}
```

