
# Mindbody Public Api Dto Models V6 Appointment Controller Get Unavailabilities Response

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetUnavailabilitiesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. |
| `Unavailabilities` | [`List<Models.MindbodyPublicApiDtoModelsV6UnavailabilityPlain>`](../../doc/models/mindbody-public-api-dto-models-v6-unavailability-plain.md) | Optional | Contains information about unavailabilities |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Unavailabilities": null
}
```

