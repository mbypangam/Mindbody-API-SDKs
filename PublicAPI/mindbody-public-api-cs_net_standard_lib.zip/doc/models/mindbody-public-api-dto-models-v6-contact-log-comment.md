
# Mindbody Public Api Dto Models V6 Contact Log Comment

A contact log comment.

## Structure

`MindbodyPublicApiDtoModelsV6ContactLogComment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The comment's ID. |
| `Text` | `string` | Optional | The comment's body text. |
| `CreatedDateTime` | `DateTime?` | Optional | The local time when the comment was created. |
| `CreatedBy` | [`Models.MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Information about the staff member who created the comment. |

## Example (as JSON)

```json
{
  "Id": null,
  "Text": null,
  "CreatedDateTime": null,
  "CreatedBy": null
}
```

