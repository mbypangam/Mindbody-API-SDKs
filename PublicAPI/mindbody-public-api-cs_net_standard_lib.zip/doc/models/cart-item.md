
# Cart Item

## Structure

`CartItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Item` | `object` | Optional | - |
| `SalesNotes` | `string` | Optional | Sales Notes for the Product Purcahsed |
| `DiscountAmount` | `double?` | Optional | The amount of the discount applied to the item. |
| `VisitIds` | `List<long>` | Optional | The IDs of the booked classes, enrollments, or courses that were reconciled by this cart item. This list is only returned if a valid visit ID was passed in the request’s `VisitIds` list. |
| `AppointmentIds` | `List<long>` | Optional | Gets or sets the item. |
| `Appointments` | [`List<Appointment>`](../../doc/models/appointment.md) | Optional | The IDs of the appointments that were reconciled by this cart item. This list is only returned if a valid appointment ID was passed in the request’s `AppointmentIds` list. |
| `Id` | `int?` | Optional | The item’s ID in the current cart. |
| `Quantity` | `int?` | Optional | The quantity of the item being purchased. |

## Example (as JSON)

```json
{
  "Item": {
    "key1": "val1",
    "key2": "val2"
  },
  "SalesNotes": "SalesNotes0",
  "DiscountAmount": 228.72,
  "VisitIds": [
    128
  ],
  "AppointmentIds": [
    170,
    169,
    168
  ]
}
```

