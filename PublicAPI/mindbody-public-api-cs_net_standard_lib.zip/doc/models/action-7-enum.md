
# Action 7 Enum

The action performed on this object.

## Enumeration

`Action7Enum`

## Fields

| Name |
|  --- |
| `None` |
| `Added` |
| `Updated` |
| `Failed` |
| `Removed` |

