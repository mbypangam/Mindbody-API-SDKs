
# Add Client Request

## Structure

`AddClientRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountBalance` | `double?` | Optional | The client’s current [account balance](https://mindbody-online-support.force.com/support/s/article/203262013-Adding-account-payments-video-tutorial?language=en_US). |
| `Action` | [`Models.Action1Enum?`](../../doc/models/action-1-enum.md) | Optional | The action taken. |
| `Active` | `bool?` | Optional | When `true`, indicates that the client is active at the site.<br /><br>When `false`, indicates that the client is not active at the site. |
| `AddressLine1` | `string` | Optional | The first line of the client’s street address. |
| `AddressLine2` | `string` | Optional | The second line of the client’s street address, if needed. |
| `ApptGenderPrefMale` | `bool?` | Optional | When `true`, indicates that the client prefers services to be provided by a male service provider.<br /><br>When `false`, indicates that the client prefers services to be provided by a female service provider.<br /><br>When `null`, indicates that the client has no preference.<br>Default: **null** |
| `BirthDate` | `DateTime?` | Optional | The client’s date of birth. |
| `City` | `string` | Optional | The client’s city. |
| `ClientCreditCard` | [`Models.ClientCreditCard`](../../doc/models/client-credit-card.md) | Optional | Contains information about the client’s credit card. |
| `ClientIndexes` | [`List<Models.AssignedClientIndex>`](../../doc/models/assigned-client-index.md) | Optional | Contains a list of the indexes and client index values to be assigned to the client.<br><br>If an index is already assigned to the client, it is overwritten with the passed index value. You cannot currently remove client indexes using the Public API. Only the indexes passed in the request are returned in the response. |
| `ClientRelationships` | [`List<Models.ClientRelationship>`](../../doc/models/client-relationship.md) | Optional | Contains information about client relationships that were added or updated for the client. This parameter does not include all of the relationships assigned to the client, only the ones passed in the request. |
| `Country` | `string` | Optional | The country in which the client is located. |
| `CreationDate` | `DateTime?` | Optional | The date when the client was added to the business, either by the client from the online store or by a staff member at the subscriber’s business. This value always returns in the format yyyy-mm-ddThh:mm:ss:ms. |
| `CustomClientFields` | [`List<Models.CustomClientFieldValue>`](../../doc/models/custom-client-field-value.md) | Optional | Contains information about the custom fields used for clients in the business. |
| `Email` | `string` | Optional | The client’s email address. |
| `EmergencyContactInfoEmail` | `string` | Optional | The email address of the client’s emergency contact.<br /><br>For more information, see [Children’s program features(emergency contact information)](https://support.mindbodyonline.com/s/article/203259283-Children-s-program-features-emergency-contact-information?language=en_US). |
| `EmergencyContactInfoName` | `string` | Optional | The name of the client’s emergency contact. |
| `EmergencyContactInfoPhone` | `string` | Optional | The phone number of the client’s emergency contact. |
| `EmergencyContactInfoRelationship` | `string` | Optional | The client’s relationship with the emergency contact, for example, mother or spouse. |
| `FirstAppointmentDate` | `DateTime?` | Optional | The date of the client’s first booked appointment at the business. |
| `FirstName` | `string` | Required | The client’s first name. You must specify a first name when you add a client. |
| `Gender` | `string` | Optional | The client’s gender. |
| `HomeLocation` | [`Models.Location`](../../doc/models/location.md) | Optional | Sets the client’s home location to the passed location, based on its ID. |
| `HomePhone` | `string` | Optional | The client’s home phone number. |
| `IsCompany` | `bool?` | Optional | When `true`, indicates that the client should be marked as a company at the business.<br /><br>When `false`, indicates the client is an individual and does not represent a company. |
| `IsProspect` | `bool?` | Optional | This value is set only if the business owner allows individuals to be prospects.<br /><br>If the business owner has enabled the setting to default new client as a Prospect, the isProspect value will always be true. Otherwise,<br /><br>When `true`, indicates that the client should be marked as a prospect for the business.<br /><br>When `false`, indicates that the client should not be marked as a prospect for the business. |
| `LastFormulaNotes` | `string` | Optional | The last [formula note](https://support.mindbodyonline.com/s/article/203259903-Appointments-Formula-notes?language=en_US) entered for the client. |
| `LastModifiedDateTime` | `DateTime?` | Optional | The UTC date and time when the client’s information was last modified. |
| `LastName` | `string` | Required | The client’s last name. You must specify a last name when you add a client. |
| `Liability` | [`Models.Liability`](../../doc/models/liability.md) | Optional | Contains the client’s liability agreement information for the business. |
| `LiabilityRelease` | `bool?` | Optional | When `true`, sets the client’s liability information as follows:<br><br>* `IsReleased` is set to true.<br>* `AgreementDate` is set to the time zone of the business when the call was processed.<br>* `ReleasedBy` is set to `null` if the call is made by the client, `0` if the call was made by the business owner, or to a specific staff member’s ID if a staff member made the call.<br>  When `false`, sets the client’s liability information as follows:<br>* `IsReleased` is set to `false`.<br>* `AgreementDate` is set to `null`.<br>* `ReleasedBy` is set to `null`. |
| `MembershipIcon` | `int?` | Optional | The ID of the membership icon displayed next to the client’s name, if the client has a membership on their account. |
| `MiddleName` | `string` | Optional | The client’s middle name. |
| `MobilePhone` | `string` | Optional | The client’s mobile phone number. |
| `MobileProvider` | `int?` | Optional | The client's mobile provider. |
| `NewId` | `string` | Optional | The new RSSID to be used for the client. Use `NewId` to assign a specific alphanumeric value to be a client’s ID. This RSSID must be unique within the subscriber’s site. If this is a cross-regional update, the RSSID must be unique across the region. If the requested value is already in use, the call returns an error. |
| `Notes` | `string` | Optional | Any notes entered on the client’s account by staff members. This value should never be shown to clients unless the business owner has a specific reason for showing them. |
| `PhotoUrl` | `string` | Optional | The URL for the client’s photo, if one has been uploaded. |
| `PostalCode` | `string` | Optional | The client’s postal code. |
| `ProspectStage` | [`Models.ProspectStage`](../../doc/models/prospect-stage.md) | Optional | Contains information about the client [prospect stage](https://support.mindbodyonline.com/s/article/206176457-Prospect-Stages?language=en_US). |
| `RedAlert` | `string` | Optional | Contains any red alert information entered by the business owner for the client. |
| `ReferredBy` | `string` | Optional | Specifies how the client was referred to the business. You can get a list of possible strings using the `GET ClientReferralTypes` endpoint.<br /><br>For more information, see [Referral types and referral subtypes](https://support.mindbodyonline.com/s/article/203259393-Referral-types-and-referral-subtypes?language=en_US). |
| `SalesReps` | [`List<Models.SalesRep>`](../../doc/models/sales-rep.md) | Optional | Contains information about the sales representatives to be assigned to the new client. |
| `SiteId` | `int?` | Optional | The ID of the site. |
| `State` | `string` | Optional | The client’s state. |
| `Status` | `string` | Optional | The client’s status. |
| `Test` | `bool?` | Optional | When `true`, indicates that test mode is enabled. The method is validated, but no client data is added or updated.<br /><br>Default: **false** |
| `UniqueId` | `long?` | Optional | The client’s system-generated ID at the business. This value cannot be changed by business owners and is always unique across all clients at the business. This ID is not widely used in the Public API, but can be used by your application to uniquely identify clients. |
| `WorkExtension` | `string` | Optional | The client’s work phone extension number. |
| `WorkPhone` | `string` | Optional | The client’s work phone number. |
| `YellowAlert` | `string` | Optional | Contains any yellow alert information entered by the business owner for the client. |
| `SendScheduleEmails` | `bool?` | Optional | When `true`, indicates that the client opts to receive schedule emails.<br>Default : **false** |
| `SendAccountEmails` | `bool?` | Optional | When `true`, indicates that the client opts to receive account emails.<br>Default : **false** |
| `SendPromotionalEmails` | `bool?` | Optional | When `true`, indicates that the client opts to receive promotional emails.<br>Default : **false** |
| `SendScheduleTexts` | `bool?` | Optional | When `true`, indicates that the client opts to receive schedule texts. |
| `SendAccountTexts` | `bool?` | Optional | When `true`, indicates that the client opts to receive account texts. |
| `SendPromotionalTexts` | `bool?` | Optional | When `true`, indicates that the client opts to receive promotional texts. |
| `LockerNumber` | `string` | Optional | The clients locker number. |
| `ReactivateInactiveClient` | `bool?` | Optional | When `true`, indicates that the client opts to reactive existing Inactive client. |

## Example (as JSON)

```json
{
  "AccountBalance": null,
  "Action": null,
  "Active": null,
  "AddressLine1": null,
  "AddressLine2": null,
  "ApptGenderPrefMale": null,
  "BirthDate": null,
  "City": null,
  "ClientCreditCard": null,
  "ClientIndexes": null,
  "ClientRelationships": null,
  "Country": null,
  "CreationDate": null,
  "CustomClientFields": null,
  "Email": null,
  "EmergencyContactInfoEmail": null,
  "EmergencyContactInfoName": null,
  "EmergencyContactInfoPhone": null,
  "EmergencyContactInfoRelationship": null,
  "FirstAppointmentDate": null,
  "FirstName": "FirstName4",
  "Gender": null,
  "HomeLocation": null,
  "HomePhone": null,
  "IsCompany": null,
  "IsProspect": null,
  "LastFormulaNotes": null,
  "LastModifiedDateTime": null,
  "LastName": "LastName4",
  "Liability": null,
  "LiabilityRelease": null,
  "MembershipIcon": null,
  "MiddleName": null,
  "MobilePhone": null,
  "MobileProvider": null,
  "NewId": null,
  "Notes": null,
  "PhotoUrl": null,
  "PostalCode": null,
  "ProspectStage": null,
  "RedAlert": null,
  "ReferredBy": null,
  "SalesReps": null,
  "SiteId": null,
  "State": null,
  "Status": null,
  "Test": null,
  "UniqueId": null,
  "WorkExtension": null,
  "WorkPhone": null,
  "YellowAlert": null,
  "SendScheduleEmails": null,
  "SendAccountEmails": null,
  "SendPromotionalEmails": null,
  "SendScheduleTexts": null,
  "SendAccountTexts": null,
  "SendPromotionalTexts": null,
  "LockerNumber": null,
  "ReactivateInactiveClient": null
}
```

