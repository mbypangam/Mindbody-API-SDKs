
# Add Appointment Response

## Structure

`AddAppointmentResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Appointment` | [`Models.Appointment`](../../doc/models/appointment.md) | Optional | Contains information about an appointment. |

## Example (as JSON)

```json
{
  "Appointment": null
}
```

