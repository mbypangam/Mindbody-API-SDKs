
# Update Client Contract Autopays Request

## Structure

`UpdateClientContractAutopaysRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientContractId` | `int?` | Optional | Client Contract Id |
| `AutopayStartDate` | `DateTime?` | Optional | Autopay start date |
| `AutopayEndDate` | `DateTime?` | Optional | (optional) - Indefinite if not provided |
| `ProductId` | `int?` | Optional | Product Id to update (optional if contract has only one product) |
| `ReplaceWithProductId` | `int?` | Optional | (optional) - Replaces the product with this product |
| `Amount` | `double?` | Optional | Overrides autopay amount or amount that would come from ProductId |

## Example (as JSON)

```json
{
  "ClientContractId": 86,
  "AutopayStartDate": "2016-03-13T12:52:32.123Z",
  "AutopayEndDate": "2016-03-13T12:52:32.123Z",
  "ProductId": 104,
  "ReplaceWithProductId": 24
}
```

