
# Add Client to Class Response

## Structure

`AddClientToClassResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Visit` | [`Models.AddClientToClassVisit`](../../doc/models/add-client-to-class-visit.md) | Optional | Contains information about the created visit. |

## Example (as JSON)

```json
{
  "Visit": null
}
```

