
# Update Client Response

## Structure

`UpdateClientResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Client` | [`Models.ClientWithSuspensionInfo`](../../doc/models/client-with-suspension-info.md) | Optional | A Client DTO with Suspension Informatoin |

## Example (as JSON)

```json
{
  "Client": null
}
```

