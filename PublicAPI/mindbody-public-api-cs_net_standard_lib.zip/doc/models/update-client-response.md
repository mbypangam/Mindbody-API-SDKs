
# Update Client Response

## Structure

`UpdateClientResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Client` | [`Models.MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo`](../../doc/models/mindbody-public-api-dto-models-v6-client-with-suspension-info.md) | Optional | Contains information about the updated client. |

## Example (as JSON)

```json
{
  "Client": null
}
```

