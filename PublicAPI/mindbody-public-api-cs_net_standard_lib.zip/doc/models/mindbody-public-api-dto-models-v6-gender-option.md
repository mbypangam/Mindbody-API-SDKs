
# Mindbody Public Api Dto Models V6 Gender Option

A gender option available at a site

## Structure

`MindbodyPublicApiDtoModelsV6GenderOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The id of the gender option |
| `Name` | `string` | Optional | The name of the gender option |
| `IsActive` | `bool?` | Optional | Whether the gender option is active and can be assigned to a consumer profile |
| `IsDefault` | `bool?` | Optional | Whether the gender option is the default value applied to a consumer profile |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "IsActive": null,
  "IsDefault": null
}
```

