
# Mindbody Public Api Dto Models V6 Gender Option

A gender option available at a site

## Structure

`MindbodyPublicApiDtoModelsV6GenderOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The id of the gender option. |
| `Name` | `string` | Optional | The value that describes this gender option. |
| `IsActive` | `bool?` | Optional | When `true`, this indicates that the gender option is active and may be assigned to a client. |
| `IsDefault` | `bool?` | Optional | When true, this indicates that this is the default gender option at the site. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "IsActive": null,
  "IsDefault": null
}
```

