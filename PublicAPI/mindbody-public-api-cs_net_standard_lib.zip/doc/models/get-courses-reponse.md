
# Get Courses Reponse

This is the response class for the get courses API

## Structure

`GetCoursesReponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | This is the pgaination response |
| `Courses` | [`List<Models.Course>`](../../doc/models/course.md) | Optional | This is the list course data |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Courses": null
}
```

