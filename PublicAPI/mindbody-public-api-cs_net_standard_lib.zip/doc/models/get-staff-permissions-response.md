
# Get Staff Permissions Response

## Structure

`GetStaffPermissionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UserGroup` | [`StaffPermissionGroup`](../../doc/models/staff-permission-group.md) | Optional | - |

## Example (as JSON)

```json
{
  "UserGroup": {
    "PermissionGroupName": "PermissionGroupName8",
    "IpRestricted": false,
    "AllowedPermissions": [
      "ViewAppointmentSchedule",
      "ManageClassNotes"
    ],
    "DeniedPermissions": [
      "CashDrawerReportAnyDate",
      "DailyCloseoutReport"
    ]
  }
}
```

