
# Get Staff Permissions Response

## Structure

`GetStaffPermissionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UserGroup` | [`Models.StaffPermissionGroup`](../../doc/models/staff-permission-group.md) | Optional | Contains information about the requested staff member’s permission group. |

## Example (as JSON)

```json
{
  "UserGroup": null
}
```

