
# Get Session Types Response

## Structure

`GetSessionTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `SessionTypes` | [`List<Models.SessionType>`](../../doc/models/session-type.md) | Optional | Contains information about sessions. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "SessionTypes": null
}
```

