
# Mindbody Public Api Dto Models V6 Staff Controller Get Staff Permissions Response

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UserGroup` | [`Models.MindbodyPublicApiDtoModelsV6StaffPermissionGroup`](../../doc/models/mindbody-public-api-dto-models-v6-staff-permission-group.md) | Optional | - |

## Example (as JSON)

```json
{
  "UserGroup": null
}
```

