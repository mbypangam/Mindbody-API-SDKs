
# Client Index Value

A client index value.

## Structure

`ClientIndexValue`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Active` | `bool?` | Optional | For this call, this value is always `false` and can be ignored.<br>When `false`, indicates that the index value has been deactivated and cannot be assigned to its parent index. |
| `Id` | `int?` | Optional | The index value’s ID. |
| `Name` | `string` | Optional | The name of the client index value. |

## Example (as JSON)

```json
{
  "Active": null,
  "Id": null,
  "Name": null
}
```

