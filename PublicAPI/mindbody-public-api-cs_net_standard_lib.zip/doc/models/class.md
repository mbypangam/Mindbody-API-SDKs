
# Class

Represents a single class instance. The class meets at the start time, goes until the end time.

## Structure

`Class`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClassScheduleId` | `int?` | Optional | The ID used to retrieve the class schedule for the desired class. |
| `Visits` | [`List<Models.Visit>`](../../doc/models/visit.md) | Optional | Contains information about visits. |
| `Clients` | [`List<Models.Client>`](../../doc/models/client.md) | Optional | Contains information about clients. |
| `Location` | [`Models.Location`](../../doc/models/location.md) | Optional | - |
| `Resource` | [`Models.ResourceSlim`](../../doc/models/resource-slim.md) | Optional | Contains information about resources, such as rooms. |
| `MaxCapacity` | `int?` | Optional | The maximum number of clients allowed in the class. |
| `WebCapacity` | `int?` | Optional | The maximum number of clients allowed to sign up online for the class. |
| `TotalBooked` | `int?` | Optional | The total number of clients booked in the class. |
| `TotalSignedIn` | `int?` | Optional | The total number of clients signed into the class. |
| `TotalBookedWaitlist` | `int?` | Optional | The total number of booked clients on the waiting list for the class. |
| `WebBooked` | `int?` | Optional | The total number of clients who signed up online for the class. |
| `SemesterId` | `int?` | Optional | The ID of the semester that the class is a part of, if any. |
| `IsCanceled` | `bool?` | Optional | When `true`, indicates that the class has been cancelled.<br /><br>When `false`, indicates that the class has not been cancelled. |
| `Substitute` | `bool?` | Optional | When `true`, indicates that the class is being taught by a substitute teacher.<br /><br>When `false`, indicates that the class is being taught by its regular teacher. |
| `Active` | `bool?` | Optional | When `true`, indicates that the class is shown to clients when in consumer mode.<br /><br>When `false`, indicates that the class is not shown to clients when in consumer mode. |
| `IsWaitlistAvailable` | `bool?` | Optional | When `true`, indicates that the clients can be placed on a waiting list for the class.<br /><br>When `false`, indicates that the clients cannot be placed on a waiting list for the class. |
| `IsEnrolled` | `bool?` | Optional | When `true`, indicates that the client with the given `ClientId` is enrolled in this class.<br /><br>When `false`, indicates that the client with the given `ClientId` is not enrolled in this class. |
| `HideCancel` | `bool?` | Optional | When `true`, indicates that this class is hidden when cancelled.<br /><br>When `false`, indicates that this class is not hidden when cancelled. |
| `Id` | `int?` | Optional | The unique identifier for the class. |
| `IsAvailable` | `bool?` | Optional | When `true`, indicates that the client with the given client ID can book this class.<br /><br>When `false`, indicates that the client with the given client ID cannot book this class. |
| `StartDateTime` | `DateTime?` | Optional | The time this class is scheduled to start. |
| `EndDateTime` | `DateTime?` | Optional | The time this class is scheduled to end. |
| `LastModifiedDateTime` | `DateTime?` | Optional | The last time this class was modified. |
| `ClassDescription` | [`Models.ClassDescription`](../../doc/models/class-description.md) | Optional | Represents a class definition. The class meets at the start time, goes until the end time. |
| `Staff` | [`Models.Staff`](../../doc/models/staff.md) | Optional | The Staff |
| `BookingWindow` | [`Models.BookingWindow`](../../doc/models/booking-window.md) | Optional | The booking window for registration |
| `BookingStatus` | [`Models.BookingStatusEnum?`](../../doc/models/booking-status-enum.md) | Optional | Contains the booking’s payment status. |
| `VirtualStreamLink` | `string` | Optional | The link to the Mindbody-hosted live stream for the class. This is `null` when no live stream is configured for the class. |

## Example (as JSON)

```json
{
  "ClassScheduleId": null,
  "Visits": null,
  "Clients": null,
  "Location": null,
  "Resource": null,
  "MaxCapacity": null,
  "WebCapacity": null,
  "TotalBooked": null,
  "TotalSignedIn": null,
  "TotalBookedWaitlist": null,
  "WebBooked": null,
  "SemesterId": null,
  "IsCanceled": null,
  "Substitute": null,
  "Active": null,
  "IsWaitlistAvailable": null,
  "IsEnrolled": null,
  "HideCancel": null,
  "Id": null,
  "IsAvailable": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "LastModifiedDateTime": null,
  "ClassDescription": null,
  "Staff": null,
  "BookingWindow": null,
  "BookingStatus": null,
  "VirtualStreamLink": null
}
```

