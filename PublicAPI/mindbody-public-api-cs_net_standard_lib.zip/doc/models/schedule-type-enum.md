
# Schedule Type Enum

## Enumeration

`ScheduleTypeEnum`

## Fields

| Name |
|  --- |
| `All` |
| `Class` |
| `Enrollment` |
| `Appointment` |
| `Resource` |
| `Media` |
| `Arrival` |

