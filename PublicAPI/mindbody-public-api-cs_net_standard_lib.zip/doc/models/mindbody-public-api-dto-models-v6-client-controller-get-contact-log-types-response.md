
# Mindbody Public Api Dto Models V6 Client Controller Get Contact Log Types Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. |
| `ContactLogTypes` | [`List<Models.MindbodyPublicApiDtoModelsV6ContactLogType>`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log-type.md) | Optional | The requested Active ContactLogTypes |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ContactLogTypes": null
}
```

