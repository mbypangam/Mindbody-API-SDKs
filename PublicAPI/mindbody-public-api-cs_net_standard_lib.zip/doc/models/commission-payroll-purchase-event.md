
# Commission Payroll Purchase Event

## Structure

`CommissionPayrollPurchaseEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StaffId` | `long?` | Optional | The ID of the staff member who earned commissions. |
| `SaleDateTime` | `DateTime?` | Optional | The date and time when the sale occurred. |
| `SaleId` | `long?` | Optional | The sale’s ID. |
| `SaleType` | `string` | Optional | The Sales type. When this is "Purchase" indicates that this sale paid commission to a staff. When this is "Return" |
| `ProductId` | `long?` | Optional | The product ID of the item for which the staff earned commissions. |
| `EarningsDetails` | [`List<Models.CommissionDetail>`](../../doc/models/commission-detail.md) | Optional | Contains information about which commissions the staff earned for this item. |
| `Earnings` | `double?` | Optional | The total commissions earned by the staff for this item. |

## Example (as JSON)

```json
{
  "StaffId": null,
  "SaleDateTime": null,
  "SaleId": null,
  "SaleType": null,
  "ProductId": null,
  "EarningsDetails": null,
  "Earnings": null
}
```

