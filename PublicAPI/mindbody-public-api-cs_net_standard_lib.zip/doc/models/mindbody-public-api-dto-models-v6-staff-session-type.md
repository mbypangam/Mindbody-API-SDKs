
# Mindbody Public Api Dto Models V6 Staff Session Type

## Structure

`MindbodyPublicApiDtoModelsV6StaffSessionType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StaffId` | `long?` | Optional | The staff member Id |
| `Type` | [`Models.Type2Enum?`](../../doc/models/type-2-enum.md) | Optional | Contains the class description session type. |
| `Id` | `int?` | Optional | This session type’s unique Id. |
| `Name` | `string` | Optional | The name of this session type. |
| `NumDeducted` | `int?` | Optional | The number of sessions that this session type deducts from the pricing option used to pay for this type of session. |
| `ProgramId` | `int?` | Optional | This session type’s service category Id. |
| `Category` | `string` | Optional | This session type’s category. |
| `CategoryId` | `int?` | Optional | This session type’s category Id. |
| `Subcategory` | `string` | Optional | This session type’s subcategory. |
| `SubcategoryId` | `int?` | Optional | This session type’s subcategory Id. |
| `TimeLength` | `int?` | Optional | - |
| `PrepTime` | `int?` | Optional | Prep time in minutes |
| `FinishTime` | `int?` | Optional | Finish time in minutes |
| `PayRateType` | `string` | Optional | The pay rate type |
| `PayRateAmount` | `double?` | Optional | The pay rate amount |

## Example (as JSON)

```json
{
  "StaffId": null,
  "Type": null,
  "Id": null,
  "Name": null,
  "NumDeducted": null,
  "ProgramId": null,
  "Category": null,
  "CategoryId": null,
  "Subcategory": null,
  "SubcategoryId": null,
  "TimeLength": null,
  "PrepTime": null,
  "FinishTime": null,
  "PayRateType": null,
  "PayRateAmount": null
}
```

