
# Add Formula Note Request

## Structure

`AddFormulaNoteRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | The ID of the client who needs to have a formula note added. |
| `AppointmentId` | `long?` | Optional | The appointment ID that the formula note is related to. |
| `Note` | `string` | Required | The new formula note text. |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "AppointmentId": 22,
  "Note": "Note0"
}
```

