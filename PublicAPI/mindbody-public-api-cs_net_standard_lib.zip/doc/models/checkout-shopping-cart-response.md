
# Checkout Shopping Cart Response

## Structure

`CheckoutShoppingCartResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ShoppingCart` | [`Models.ShoppingCart`](../../doc/models/shopping-cart.md) | Optional | Contains information about the shopping cart. |
| `Classes` | [`List<Models.Class>`](../../doc/models/class.md) | Optional | Contains information about the classes. |
| `Appointments` | [`List<Models.Appointment>`](../../doc/models/appointment.md) | Optional | Contains information about the appointments. |
| `Enrollments` | [`List<Models.ClassSchedule>`](../../doc/models/class-schedule.md) | Optional | Contains information about enrollment class schedules. |

## Example (as JSON)

```json
{
  "ShoppingCart": null,
  "Classes": null,
  "Appointments": null,
  "Enrollments": null
}
```

