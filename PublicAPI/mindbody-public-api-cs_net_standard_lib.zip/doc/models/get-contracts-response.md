
# Get Contracts Response

## Structure

`GetContractsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Contracts` | [`List<Models.MindbodyPublicApiDtoModelsV6Contract>`](../../doc/models/mindbody-public-api-dto-models-v6-contract.md) | Optional | Contains information about each contract. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Contracts": null
}
```

