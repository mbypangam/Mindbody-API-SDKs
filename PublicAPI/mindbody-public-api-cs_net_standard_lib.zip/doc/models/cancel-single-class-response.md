
# Cancel Single Class Response

## Structure

`CancelSingleClassResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Class` | [`Models.Class`](../../doc/models/class.md) | Optional | A resulting class. |

## Example (as JSON)

```json
{
  "Class": null
}
```

