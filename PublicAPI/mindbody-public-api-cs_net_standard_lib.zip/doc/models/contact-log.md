
# Contact Log

A contact log.

## Structure

`ContactLog`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The contact log’s ID. |
| `Text` | `string` | Optional | The contact log’s body text. |
| `CreatedDateTime` | `DateTime?` | Optional | The local date and time when the contact log was created. |
| `FollowupByDate` | `DateTime?` | Optional | The date by which the assigned staff member should close or follow up on this contact log. |
| `ContactMethod` | `string` | Optional | The method by which the client wants to be contacted. |
| `ContactName` | `string` | Optional | The name of the client to contact. |
| `Client` | [`Models.Client`](../../doc/models/client.md) | Optional | The Client. |
| `CreatedBy` | [`Models.Staff`](../../doc/models/staff.md) | Optional | The Staff |
| `AssignedTo` | [`Models.Staff`](../../doc/models/staff.md) | Optional | The Staff |
| `Comments` | [`List<Models.ContactLogComment>`](../../doc/models/contact-log-comment.md) | Optional | Information about the comment. |
| `Types` | [`List<Models.ContactLogType>`](../../doc/models/contact-log-type.md) | Optional | Information about the type of contact log. |

## Example (as JSON)

```json
{
  "Id": 146,
  "Text": "Text8",
  "CreatedDateTime": "2016-03-13T12:52:32.123Z",
  "FollowupByDate": "2016-03-13T12:52:32.123Z",
  "ContactMethod": "ContactMethod6"
}
```

