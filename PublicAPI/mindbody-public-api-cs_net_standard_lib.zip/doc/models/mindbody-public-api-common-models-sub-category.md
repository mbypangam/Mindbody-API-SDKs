
# Mindbody Public Api Common Models Sub Category

## Structure

`MindbodyPublicApiCommonModelsSubCategory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The sub category Id used for api calls. |
| `SubCategoryName` | `string` | Optional | Sub Category Name |
| `Active` | `bool?` | Optional | Check if Sub Category is active. |

## Example (as JSON)

```json
{
  "Id": null,
  "SubCategoryName": null,
  "Active": null
}
```

