
# Get Active Clients Memberships Response

## Structure

`GetActiveClientsMembershipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `ClientMemberships` | [`List<Models.ClientMemberships>`](../../doc/models/client-memberships.md) | Optional | Details about the requested memberships. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientMemberships": null
}
```

