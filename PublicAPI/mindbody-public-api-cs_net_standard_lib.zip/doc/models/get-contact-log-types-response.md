
# Get Contact Log Types Response

## Structure

`GetContactLogTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `ContactLogTypes` | [`List<Models.ContactLogType>`](../../doc/models/contact-log-type.md) | Optional | The requested Active ContactLogTypes |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ContactLogTypes": null
}
```

