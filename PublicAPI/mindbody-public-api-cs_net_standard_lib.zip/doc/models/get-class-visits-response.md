
# Get Class Visits Response

## Structure

`GetClassVisitsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Class` | [`Models.Class`](../../doc/models/class.md) | Optional | Contains class and booking information. |

## Example (as JSON)

```json
{
  "Class": null
}
```

