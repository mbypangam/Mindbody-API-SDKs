
# Get Class Visits Response

## Structure

`GetClassVisitsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Class` | [`Models.MindbodyPublicApiDtoModelsV6Class`](../../doc/models/mindbody-public-api-dto-models-v6-class.md) | Optional | Contains class and booking information. |

## Example (as JSON)

```json
{
  "Class": null
}
```

