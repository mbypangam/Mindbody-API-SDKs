
# Scheduled Service Earnings Event

## Structure

`ScheduledServiceEarningsEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StaffId` | `long?` | Optional | The ID of the staff member who taught the class. |
| `ScheduledServiceId` | `long?` | Optional | The class' ID. |
| `ScheduledServiceType` | [`ScheduledServiceTypeEnum?`](../../doc/models/scheduled-service-type-enum.md) | Optional | The type of the scheduled service; i.e, a class, appointment, or enrollment. |
| `Earnings` | `double?` | Optional | The total monetary amount the staff is to be paid for this class. |
| `DateTime` | `DateTime?` | Optional | - |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "ScheduledServiceId": 240,
  "ScheduledServiceType": "Class",
  "Earnings": 73.68,
  "DateTime": "2016-03-13T12:52:32.123Z"
}
```

