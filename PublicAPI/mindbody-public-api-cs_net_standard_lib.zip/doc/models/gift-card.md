
# Gift Card

## Structure

`GiftCard`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The gift card's `ProductID`. |
| `LocationIds` | `List<int>` | Optional | The IDs of the locations where the gift card is sold. |
| `Description` | `string` | Optional | A description of the gift card. |
| `EditableByConsumer` | `bool?` | Optional | When `true`, indicates that the gift card can be edited by the client. |
| `CardValue` | `double?` | Optional | The value of the gift card. |
| `SalePrice` | `double?` | Optional | The sale price of the gift card, if applicable. |
| `SoldOnline` | `bool?` | Optional | When `true`, indicates that the gift card is sold online. |
| `MembershipRestrictionIds` | `List<int>` | Optional | A list of IDs for membership restrictions, if this card is restricted to members with certain types of memberships. |
| `GiftCardTerms` | `string` | Optional | The terms of the gift card. |
| `ContactInfo` | `string` | Optional | Contact information for the gift card. |
| `DisplayLogo` | `bool?` | Optional | When `true`, indicates that the logo should be displayed on the gift card. |
| `Layouts` | [`List<GiftCardLayout>`](../../doc/models/gift-card-layout.md) | Optional | A list of layouts available for the gift card. |

## Example (as JSON)

```json
{
  "Id": 146,
  "LocationIds": [
    24,
    25
  ],
  "Description": "Description6",
  "EditableByConsumer": false,
  "CardValue": 81.4
}
```

