
# Add Staff Availability Request

Add Staff Availability/Unavailability Schedule

## Structure

`AddStaffAvailabilityRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StaffId` | `long` | Required | The ID of the staff member that availability or unavailability will be added. |
| `IsAvailability` | `bool` | Required | When `true`, indicates that availability will be added, <br /><br>When `false`, indicates that unavailability will be added. |
| `Description` | `string` | Optional | The description of the unavailability, ex. Lunch, Vacation. Required if IsAvailability passed as `false`.<br>Omit if IsAvailability passed as `true`. |
| `ProgramIds` | `List<int>` | Optional | A list of program IDs. Must be a valid active schedulable Program ID. Required if IsAvailability passed as `true`.<br>Omit if IsAvailability passed as `false`. |
| `LocationId` | `int?` | Optional | The ID of the location where the availability is added. Required if IsAvailability passed as `true`.<br>Omit if IsAvailability passed as `false`. |
| `DaysOfWeek` | `List<string>` | Required | The days of the week. Must contain at least one of the following Sunday, Monday, Tuesday etc. |
| `StartTime` | `string` | Required | The start time of the schedule. Must be in HH:MM:SS format.<br>**Constraints**: *Pattern*: `^(?:(?:([01]?\d\|2[0-3]):)?([0-5]?\d):)?([0-5]?\d)$` |
| `EndTime` | `string` | Required | The end time of the schedule. Must be in HH:MM:SS format.<br>**Constraints**: *Pattern*: `^(?:(?:([01]?\d\|2[0-3]):)?([0-5]?\d):)?([0-5]?\d)$` |
| `StartDate` | `string` | Required | The start date of the schedule. Must be in YYYY-MM-DD format.<br>**Constraints**: *Pattern*: `^\d{4}-((0\d)\|(1[012]))-(([012]\d)\|3[01])$` |
| `EndDate` | `string` | Required | The end date of the schedule. Must be in YYYY-MM-DD format.<br>**Constraints**: *Pattern*: `^\d{4}-((0\d)\|(1[012]))-(([012]\d)\|3[01])$` |
| `Status` | `string` | Optional | The status of availability or unavailability. Possible values are:<br><br>* Masked<br>* Hidden<br>* Public<br><br>Default: Public |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "IsAvailability": false,
  "Description": null,
  "ProgramIds": null,
  "LocationId": null,
  "DaysOfWeek": [
    "DaysOfWeek3",
    "DaysOfWeek4",
    "DaysOfWeek5"
  ],
  "StartTime": "StartTime8",
  "EndTime": "EndTime4",
  "StartDate": "StartDate4",
  "EndDate": "EndDate0",
  "Status": null
}
```

