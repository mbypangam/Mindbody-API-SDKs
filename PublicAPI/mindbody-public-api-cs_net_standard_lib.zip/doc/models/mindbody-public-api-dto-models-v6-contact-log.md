
# Mindbody Public Api Dto Models V6 Contact Log

A contact log.

## Structure

`MindbodyPublicApiDtoModelsV6ContactLog`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The contact log?s ID. |
| `Text` | `string` | Optional | The contact log?s body text. |
| `CreatedDateTime` | `DateTime?` | Optional | The local date and time when the contact log was created. |
| `FollowupByDate` | `DateTime?` | Optional | The date by which the assigned staff member should close or follow up on this contact log. |
| `ContactMethod` | `string` | Optional | The method by which the client wants to be contacted. |
| `ContactName` | `string` | Optional | The name of the client to contact. |
| `Client` | [`Models.MindbodyPublicApiDtoModelsV6Client`](../../doc/models/mindbody-public-api-dto-models-v6-client.md) | Optional | Information about the client to whom the contact log belongs. |
| `CreatedBy` | [`Models.MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Information about the staff member who created the contact log. |
| `AssignedTo` | [`Models.MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Information about the staff member to whom the contact log is assigned for follow up. |
| `Comments` | [`List<Models.MindbodyPublicApiDtoModelsV6ContactLogComment>`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log-comment.md) | Optional | Information about the comment. |
| `Types` | [`List<Models.MindbodyPublicApiDtoModelsV6ContactLogType>`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log-type.md) | Optional | Information about the type of contact log. |

## Example (as JSON)

```json
{
  "Id": null,
  "Text": null,
  "CreatedDateTime": null,
  "FollowupByDate": null,
  "ContactMethod": null,
  "ContactName": null,
  "Client": null,
  "CreatedBy": null,
  "AssignedTo": null,
  "Comments": null,
  "Types": null
}
```

