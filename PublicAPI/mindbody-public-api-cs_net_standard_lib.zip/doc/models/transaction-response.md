
# Transaction Response

## Structure

`TransactionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TransactionId` | `int?` | Optional | The Transaction ID. |
| `AuthenticationUrl` | `string` | Optional | The optional valid URL provided by the bank. |

## Example (as JSON)

```json
{
  "TransactionId": null,
  "AuthenticationUrl": null
}
```

