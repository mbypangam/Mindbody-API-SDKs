
# Delete Reservation Response

## Structure

`DeleteReservationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DeleteSucceeded` | `bool?` | Optional | delete successded status. |
| `ResponseDetail` | [`Models.ResponseDetails`](../../doc/models/response-details.md) | Optional | Response details information. |

## Example (as JSON)

```json
{
  "DeleteSucceeded": null,
  "ResponseDetail": null
}
```

