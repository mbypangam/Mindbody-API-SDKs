
# Get Active Client Memberships Response

## Structure

`GetActiveClientMembershipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `ClientMemberships` | [`List<Models.MindbodyPublicApiDtoModelsV6ClientMembership>`](../../doc/models/mindbody-public-api-dto-models-v6-client-membership.md) | Optional | Details about the requested memberships. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientMemberships": null
}
```

