
# Client Credit Card

A client credit card.

## Structure

`ClientCreditCard`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Address` | `string` | Optional | The billing address for the credit card. |
| `CardHolder` | `string` | Optional | The name of the card holder. |
| `CardNumber` | `string` | Optional | The credit card number. |
| `CardType` | `string` | Optional | The type of credit card, for example Visa or MasterCard. |
| `City` | `string` | Optional | The city in which the billing address is located. |
| `ExpMonth` | `string` | Optional | The month in which the credit card expires. |
| `ExpYear` | `string` | Optional | The year in which the credit card expires. |
| `LastFour` | `string` | Optional | The last four digits of the credit card number. |
| `PostalCode` | `string` | Optional | The postal code where the billing address is located. |
| `State` | `string` | Optional | The state that the billing address is located in. |

## Example (as JSON)

```json
{
  "Address": "Address6",
  "CardHolder": "CardHolder6",
  "CardNumber": "CardNumber0",
  "CardType": "CardType6",
  "City": "City6"
}
```

