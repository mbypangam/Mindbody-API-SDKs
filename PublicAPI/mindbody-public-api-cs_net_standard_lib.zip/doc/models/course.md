
# Course

A course.

## Structure

`Course`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The course ID. |
| `Name` | `string` | Optional | The course name. |
| `Description` | `string` | Optional | A description of the course. |
| `Notes` | `string` | Optional | Any notes that have been written about the course. |
| `StartDate` | `DateTime?` | Optional | Date and time that the course starts. |
| `EndDate` | `DateTime?` | Optional | Date and time that the course ends. |
| `Location` | [`Models.Location`](../../doc/models/location.md) | Optional | - |
| `Organizer` | [`Models.Staff`](../../doc/models/staff.md) | Optional | The Staff |
| `Program` | [`Models.Program`](../../doc/models/program.md) | Optional | - |
| `ImageUrl` | `string` | Optional | The URL of the image associated with this course, if one exists. |

## Example (as JSON)

```json
{
  "Id": 146,
  "Name": "Name0",
  "Description": "Description6",
  "Notes": "Notes8",
  "StartDate": "2016-03-13T12:52:32.123Z"
}
```

