
# Reservation

## Structure

`Reservation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReservationId` | `string` | Optional | - |
| `ReservationExternalId` | `string` | Optional | - |
| `ClassId` | `string` | Optional | - |
| `ClassExternalId` | `string` | Optional | - |
| `MemberExternalId` | `string` | Optional | - |
| `ReservationType` | `string` | Optional | - |
| `Spots` | [`Models.Spot`](../../doc/models/spot.md) | Optional | - |
| `IsConfirmed` | `bool?` | Optional | - |
| `ConfirmationDate` | `DateTime?` | Optional | - |

## Example (as JSON)

```json
{
  "ReservationId": null,
  "ReservationExternalId": null,
  "ClassId": null,
  "ClassExternalId": null,
  "MemberExternalId": null,
  "ReservationType": null,
  "Spots": null,
  "IsConfirmed": null,
  "ConfirmationDate": null
}
```

