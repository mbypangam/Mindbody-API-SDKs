
# Reservation

Contains information about the reservation.

## Structure

`Reservation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ReservationId` | `string` | Optional | The unique reservation ID. |
| `ReservationExternalId` | `string` | Optional | The unique reservation external ID. |
| `ClassId` | `string` | Optional | The unique class ID. |
| `ClassExternalId` | `string` | Optional | The unique class external ID. |
| `MemberExternalId` | `string` | Optional | The unique member external ID. |
| `ReservationType` | `string` | Optional | Contains information about the reservation type. |
| `Spots` | [`Models.Spot`](../../doc/models/spot.md) | Optional | Contains information about the spot details. |
| `IsConfirmed` | `bool?` | Optional | Boolean value whether it is confirmed. |
| `ConfirmationDate` | `DateTime?` | Optional | Contains information about the confirmation date. |

## Example (as JSON)

```json
{
  "ReservationId": "ReservationId8",
  "ReservationExternalId": "ReservationExternalId2",
  "ClassId": "ClassId8",
  "ClassExternalId": "ClassExternalId2",
  "MemberExternalId": "MemberExternalId2"
}
```

