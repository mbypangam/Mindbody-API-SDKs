
# Mindbody Public Api Dto Models V6 Client

The Client.

## Structure

`MindbodyPublicApiDtoModelsV6Client`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AppointmentGenderPreference` | [`Models.AppointmentGenderPreference1Enum?`](../../doc/models/appointment-gender-preference-1-enum.md) | Optional | The gender of staff member with whom the client prefers to book appointments. |
| `BirthDate` | `DateTime?` | Optional | The client’s date of birth. |
| `Country` | `string` | Optional | The client’s country. |
| `CreationDate` | `DateTime?` | Optional | The date the client’s profile was created and added to the business, either by the client from the online store, or by a staff member. This value always returns in the format `yyyy-mm-ddThh:mm:ss:ms`. |
| `CustomClientFields` | [`List<Models.MindbodyPublicApiDtoModelsV6CustomClientFieldValue>`](../../doc/models/mindbody-public-api-dto-models-v6-custom-client-field-value.md) | Optional | Contains information about the custom client fields assigned to the client. |
| `ClientCreditCard` | [`Models.MindbodyPublicApiDtoModelsV6ClientCreditCard`](../../doc/models/mindbody-public-api-dto-models-v6-client-credit-card.md) | Optional | A client credit card. |
| `ClientIndexes` | [`List<Models.MindbodyPublicApiDtoModelsV6AssignedClientIndex>`](../../doc/models/mindbody-public-api-dto-models-v6-assigned-client-index.md) | Optional | Contains a list of the indexes and client index values to be assigned to the client.<br><br>If an index is already assigned to the client, it is overwritten with the passed index value. You cannot currently remove client indexes using the Public API. Only the indexes passed in the request are returned in the response. |
| `ClientRelationships` | [`List<Models.MindbodyPublicApiDtoModelsV6ClientRelationship>`](../../doc/models/mindbody-public-api-dto-models-v6-client-relationship.md) | Optional | Contains information about client relationships that were added or updated for the client. This parameter does not include all of the relationships assigned to the client, only the ones passed in the request. |
| `FirstAppointmentDate` | `DateTime?` | Optional | The date of the client’s first booked appointment at the business. |
| `FirstClassDate` | `DateTime?` | Optional | The date of the clients first booked class at the business. |
| `FirstName` | `string` | Optional | The client’s first name. |
| `Id` | `string` | Optional | The client’s ID, as configured by the business owner. This is the client’s barcode ID if the business owner assigns barcodes to clients. This ID is used throughout the Public API for client-related Public API calls. When used in a POST `UpdateClient` request, the `Id` is used to identify the client for the update. |
| `IsCompany` | `bool?` | Optional | When `true`, indicates that the client should be marked as a company at the business.<br /><br>When `false`, indicates the client is an individual and does not represent a company. |
| `IsProspect` | `bool?` | Optional | This value is set only if the business owner allows individuals to be prospects.<br /><br>When `true`, indicates that the client should be marked as a prospect for the business.<br /><br>When `false`, indicates that the client should not be marked as a prospect for the business. |
| `LastName` | `string` | Optional | The client’s last name. |
| `Liability` | [`Models.MindbodyPublicApiDtoModelsV6Liability`](../../doc/models/mindbody-public-api-dto-models-v6-liability.md) | Optional | - |
| `LiabilityRelease` | `bool?` | Optional | Passing `true` sets the client’s liability information as follows:<br><br>* `IsReleased` is set to `true`.<br>* `AgreementDate` is set to the time zone of the business when the call was processed.<br>* `ReleasedBy` is set to `null` if the call is made by the client, `0` if the call was made by the business owner, or to a specific staff member’s ID if a staff member made the call.<br>  Passing `false` sets the client’s liability information as follows:<br>* `IsReleased` is set to `false`.<br>* `AgreementDate` is set to `null`.<br>* `ReleasedBy` is set to `null`. |
| `MembershipIcon` | `int?` | Optional | The ID of the [membership icon](https://support.mindbodyonline.com/s/article/203259703-Membership-Setup-screen?language=en_US) displayed next to the client’s name, if the client has a membership on their account. |
| `MobileProvider` | `int?` | Optional | The client’s mobile provider. |
| `Notes` | `string` | Optional | Any notes entered on the client’s account by staff members. This value should never be shown to clients unless the business owner has a specific reason for showing them. |
| `State` | `string` | Optional | The client’s state. |
| `UniqueId` | `long?` | Optional | The client’s system-generated ID at the business. This value cannot be changed by business owners and is always unique across all clients at the business. This ID is not widely used in the Public API, but can be used by your application to uniquely identify clients. |
| `LastModifiedDateTime` | `DateTime?` | Optional | The UTC date and time when the client’s information was last modified. |
| `RedAlert` | `string` | Optional | Contains any red alert information entered by the business owner for the client. |
| `YellowAlert` | `string` | Optional | Contains any yellow alert information entered by the business owner for the client. |
| `MiddleName` | `string` | Optional | The client’s middle name. |
| `ProspectStage` | [`Models.MindbodyPublicApiDtoModelsV6ProspectStage`](../../doc/models/mindbody-public-api-dto-models-v6-prospect-stage.md) | Optional | - |
| `Email` | `string` | Optional | The client’s email address. |
| `MobilePhone` | `string` | Optional | The client’s mobile phone number. |
| `HomePhone` | `string` | Optional | The client’s home phone number. |
| `WorkPhone` | `string` | Optional | The client’s work phone number. |
| `AccountBalance` | `double?` | Optional | The client’s current [account balance](https://mindbody-online-support.force.com/support/s/article/203262013-Adding-account-payments-video-tutorial?language=en_US). |
| `AddressLine1` | `string` | Optional | The first line of the client’s street address. |
| `AddressLine2` | `string` | Optional | The second line of the client’s street address, if needed. |
| `City` | `string` | Optional | The client’s city. |
| `PostalCode` | `string` | Optional | The client’s postal code. |
| `WorkExtension` | `string` | Optional | The client’s work phone extension number. |
| `ReferredBy` | `string` | Optional | Specifies how the client was referred to the business. You can get a list of possible strings using the `GetClientReferralTypes` endpoint. |
| `PhotoUrl` | `string` | Optional | The URL of the client’s photo for the client profile. |
| `EmergencyContactInfoName` | `string` | Optional | The name of the client’s emergency contact. |
| `EmergencyContactInfoEmail` | `string` | Optional | The email address of the client’s emergency contact. |
| `EmergencyContactInfoPhone` | `string` | Optional | The phone number of the client’s emergency contact. |
| `EmergencyContactInfoRelationship` | `string` | Optional | The client’s relationship with the emergency contact. |
| `Gender` | `string` | Optional | The gender of the client. |
| `LastFormulaNotes` | `string` | Optional | The last [formula note](https://support.mindbodyonline.com/s/article/203259903-Appointments-Formula-notes?language=en_US) entered for the client. |
| `Active` | `bool?` | Optional | When `true`, indicates that the client’s profile is marked as active on the site.<br /><br>When `false`, the client’s profile is inactive.<br>Defaults to `true` based on the assumption that if a client is currently inactive OR is to be marked inactive, this property will explicitly be mapped/set to `false`. |
| `SalesReps` | [`List<Models.MindbodyPublicApiDtoModelsV6SalesRep>`](../../doc/models/mindbody-public-api-dto-models-v6-sales-rep.md) | Optional | A list of sales representatives. |
| `Status` | `string` | Optional | The status of the client in the business. Possible values are:<br><br>* Declined<br>* Non-Member<br>* Active<br>* Expired<br>* Suspended<br>* Terminated |
| `Action` | [`Models.Action1Enum?`](../../doc/models/action-1-enum.md) | Optional | The action taken. |
| `SendAccountEmails` | `bool?` | Optional | When `true`, indicates that the client has opted to receive general account notifications by email. This property is editable.<br><br />Default: **false** |
| `SendAccountTexts` | `bool?` | Optional | When `true`, indicates that the client has opted to receive general account notifications by text message. This parameter cannot be updated by developers. If included in a request, it is ignored. |
| `SendPromotionalEmails` | `bool?` | Optional | When `true`, indicates that the client has opted to receive promotional notifications by email. This property is editable.<br><br />Default: **false** |
| `SendPromotionalTexts` | `bool?` | Optional | When `true`, indicates that the client has opted to receive promotional notifications by text message. This parameter cannot be updated by developers. If included in a request, it is ignored. |
| `SendScheduleEmails` | `bool?` | Optional | When `true`, indicates that the client has opted to receive schedule notifications by email. This property is editable.<br><br />Default: **false** |
| `SendScheduleTexts` | `bool?` | Optional | When `true`, indicates that the client has opted to receive schedule notifications by text message. This parameter cannot be updated by developers. If included in a request, it is ignored. |
| `HomeLocation` | [`Models.MindbodyPublicApiDtoModelsV6Location`](../../doc/models/mindbody-public-api-dto-models-v6-location.md) | Optional | - |
| `LockerNumber` | `string` | Optional | The clients locker number. |

## Example (as JSON)

```json
{
  "AppointmentGenderPreference": null,
  "BirthDate": null,
  "Country": null,
  "CreationDate": null,
  "CustomClientFields": null,
  "ClientCreditCard": null,
  "ClientIndexes": null,
  "ClientRelationships": null,
  "FirstAppointmentDate": null,
  "FirstClassDate": null,
  "FirstName": null,
  "Id": null,
  "IsCompany": null,
  "IsProspect": null,
  "LastName": null,
  "Liability": null,
  "LiabilityRelease": null,
  "MembershipIcon": null,
  "MobileProvider": null,
  "Notes": null,
  "State": null,
  "UniqueId": null,
  "LastModifiedDateTime": null,
  "RedAlert": null,
  "YellowAlert": null,
  "MiddleName": null,
  "ProspectStage": null,
  "Email": null,
  "MobilePhone": null,
  "HomePhone": null,
  "WorkPhone": null,
  "AccountBalance": null,
  "AddressLine1": null,
  "AddressLine2": null,
  "City": null,
  "PostalCode": null,
  "WorkExtension": null,
  "ReferredBy": null,
  "PhotoUrl": null,
  "EmergencyContactInfoName": null,
  "EmergencyContactInfoEmail": null,
  "EmergencyContactInfoPhone": null,
  "EmergencyContactInfoRelationship": null,
  "Gender": null,
  "LastFormulaNotes": null,
  "Active": null,
  "SalesReps": null,
  "Status": null,
  "Action": null,
  "SendAccountEmails": null,
  "SendAccountTexts": null,
  "SendPromotionalEmails": null,
  "SendPromotionalTexts": null,
  "SendScheduleEmails": null,
  "SendScheduleTexts": null,
  "HomeLocation": null,
  "LockerNumber": null
}
```

