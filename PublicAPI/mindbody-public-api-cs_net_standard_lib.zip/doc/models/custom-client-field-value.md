
# Custom Client Field Value

The value of a custom client field

## Structure

`CustomClientFieldValue`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `MValue` | `string` | Optional | The value of a specific custom field for a client. |
| `Id` | `int?` | Optional | The ID of the custom client field. |
| `DataType` | `string` | Optional | The data type of the field. |
| `Name` | `string` | Optional | The name of the field. |

## Example (as JSON)

```json
{
  "Value": "Value2",
  "Id": 146,
  "DataType": "DataType4",
  "Name": "Name0"
}
```

