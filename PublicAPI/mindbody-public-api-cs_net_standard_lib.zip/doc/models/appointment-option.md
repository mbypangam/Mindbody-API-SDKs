
# Appointment Option

An appointment option name/value pair

## Structure

`AppointmentOption`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `DisplayName` | `string` | Optional | The name displayed for this appointment option. |
| `Name` | `string` | Optional | The name given to this option. |
| `MValue` | `string` | Optional | The value of the option. |
| `Type` | `string` | Optional | The data type of the option value. |

## Example (as JSON)

```json
{
  "DisplayName": "DisplayName6",
  "Name": "Name0",
  "Value": "Value2",
  "Type": "Type0"
}
```

