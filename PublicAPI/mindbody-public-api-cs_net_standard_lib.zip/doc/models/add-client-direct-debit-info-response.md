
# Add Client Direct Debit Info Response

## Structure

`AddClientDirectDebitInfoResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Optional | The ID of the client being updated |
| `NameOnAccount` | `string` | Optional | The name on the bank account being added |
| `RoutingNumber` | `string` | Optional | The routing number of the bank account being added |
| `AccountNumber` | `string` | Optional | The bank account number |
| `AccountType` | `string` | Optional | The account type.<br><br>Possible values:<br><br>* Checking<br>* Savings |

## Example (as JSON)

```json
{
  "ClientId": null,
  "NameOnAccount": null,
  "RoutingNumber": null,
  "AccountNumber": null,
  "AccountType": null
}
```

