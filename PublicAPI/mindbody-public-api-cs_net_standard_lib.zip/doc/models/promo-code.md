
# Promo Code

## Structure

`PromoCode`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Name` | `string` | Optional | Name of the promo code |
| `Code` | `string` | Optional | The code of the promocode. |
| `Active` | `bool?` | Optional | Indicates that promocode is active. |
| `Discount` | [`Models.Discount`](../../doc/models/discount.md) | Optional | Contains information about the discount. |
| `ActivationDate` | `DateTime?` | Optional | The promocode activation date. |
| `ExpirationDate` | `DateTime?` | Optional | The promocode expiration date. |
| `MaxUses` | `int?` | Optional | The maximun number of uses. |
| `NumberOfAutopays` | `int?` | Optional | Number of Autopays |
| `DaysAfterCloseDate` | `int?` | Optional | The number of days a client has to use a promocode after they are no longer a prospect. |
| `AllowOnline` | `bool?` | Optional | Indicates if promocode to be redeemed online in consumer mode. |
| `DaysValid` | [`List<Models.DaysValidEnum>`](../../doc/models/days-valid-enum.md) | Optional | Indicates what days of the week promocode can be redeemed. |
| `ApplicableItems` | [`List<Models.ApplicableItem>`](../../doc/models/applicable-item.md) | Optional | Contains information about a promocode applicable items. |

## Example (as JSON)

```json
{
  "Name": null,
  "Code": null,
  "Active": null,
  "Discount": null,
  "ActivationDate": null,
  "ExpirationDate": null,
  "MaxUses": null,
  "NumberOfAutopays": null,
  "DaysAfterCloseDate": null,
  "AllowOnline": null,
  "DaysValid": null,
  "ApplicableItems": null
}
```

