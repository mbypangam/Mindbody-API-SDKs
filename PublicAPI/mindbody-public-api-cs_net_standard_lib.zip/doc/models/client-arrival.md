
# Client Arrival

## Structure

`ClientArrival`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ArrivalProgramID` | `int?` | Optional | Arrival program id |
| `ArrivalProgramName` | `string` | Optional | Arrival program name |
| `CanAccess` | `bool?` | Optional | Property to check client can access arrival service. |
| `LocationsIDs` | `List<int>` | Optional | List of locations where arrival service can availed |

## Example (as JSON)

```json
{
  "ArrivalProgramID": 210,
  "ArrivalProgramName": "ArrivalProgramName4",
  "CanAccess": false,
  "LocationsIDs": [
    233,
    234
  ]
}
```

