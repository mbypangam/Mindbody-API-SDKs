
# Level

A session level.

## Structure

`Level`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | Contains the Id given to this level. |
| `Name` | `string` | Optional | Contains the name given to this level. |
| `Description` | `string` | Optional | Contains a description of this level. |

## Example (as JSON)

```json
{
  "Id": 82,
  "Name": "Name4",
  "Description": "Description2"
}
```

