
# Update Client Service Response

## Structure

`UpdateClientServiceResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientService` | [`Models.ClientService`](../../doc/models/client-service.md) | Optional | A service that is on a client's account. |

## Example (as JSON)

```json
{
  "ClientService": null
}
```

