
# Update Client Service Response

## Structure

`UpdateClientServiceResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientService` | [`Models.ClientService`](../../doc/models/client-service.md) | Optional | Contains information about the service to be updated. |

## Example (as JSON)

```json
{
  "ClientService": null
}
```

