
# Get Bookable Items Response

## Structure

`GetBookableItemsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Availabilities` | [`List<Models.MindbodyPublicApiDtoModelsV6Availability>`](../../doc/models/mindbody-public-api-dto-models-v6-availability.md) | Optional | Contains information about the availabilities for appointment booking. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Availabilities": null
}
```

