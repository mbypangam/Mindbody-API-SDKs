
# Credit Card Info

INformation about an individual credit card

## Structure

`CreditCardInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CreditCardNumber` | `string` | Optional | - |
| `ExpMonth` | `string` | Optional | - |
| `ExpYear` | `string` | Optional | - |
| `BillingName` | `string` | Optional | - |
| `BillingAddress` | `string` | Optional | - |
| `BillingCity` | `string` | Optional | - |
| `BillingState` | `string` | Optional | - |
| `BillingPostalCode` | `string` | Optional | - |
| `SaveInfo` | `bool?` | Optional | - |
| `CardId` | `string` | Optional | Card Id of a stored instruments card |
| `CVV` | `string` | Optional | CVV of the card |

## Example (as JSON)

```json
{
  "CreditCardNumber": "CreditCardNumber4",
  "ExpMonth": "ExpMonth6",
  "ExpYear": "ExpYear4",
  "BillingName": "BillingName0",
  "BillingAddress": "BillingAddress2"
}
```

