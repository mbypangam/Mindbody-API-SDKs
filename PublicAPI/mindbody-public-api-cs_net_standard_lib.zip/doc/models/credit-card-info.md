
# Credit Card Info

INformation about an individual credit card

## Structure

`CreditCardInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CreditCardNumber` | `string` | Optional | - |
| `ExpMonth` | `string` | Optional | - |
| `ExpYear` | `string` | Optional | - |
| `BillingName` | `string` | Optional | - |
| `BillingAddress` | `string` | Optional | - |
| `BillingCity` | `string` | Optional | - |
| `BillingState` | `string` | Optional | - |
| `BillingPostalCode` | `string` | Optional | - |
| `SaveInfo` | `bool?` | Optional | - |
| `CardId` | `string` | Optional | Card Id of a stored instruments card |

## Example (as JSON)

```json
{
  "CreditCardNumber": "CreditCardNumber0",
  "ExpMonth": "ExpMonth2",
  "ExpYear": "ExpYear0",
  "BillingName": "BillingName4",
  "BillingAddress": "BillingAddress6"
}
```

