
# Tip

## Structure

`Tip`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StaffId` | `long?` | Optional | The ID of the staff member the tip is for. |
| `SaleId` | `long?` | Optional | The sale’s ID associated with the tip. |
| `SaleDateTime` | `DateTime?` | Optional | The date and time when the tip was given. |
| `Earnings` | `double?` | Optional | The amount tipped to the staff member. |

## Example (as JSON)

```json
{
  "StaffId": null,
  "SaleId": null,
  "SaleDateTime": null,
  "Earnings": null
}
```

