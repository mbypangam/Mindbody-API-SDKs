
# Get Client Purchases Response

## Structure

`GetClientPurchasesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `Purchases` | [`List<Models.ClientPurchaseRecord>`](../../doc/models/client-purchase-record.md) | Optional | Contains information that describes the item sold and the payment. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Purchases": null
}
```

