
# Get Client Purchases Response

## Structure

`GetClientPurchasesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `Purchases` | [`List<ClientPurchaseRecord>`](../../doc/models/client-purchase-record.md) | Optional | Contains information that describes the item sold and the payment. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Purchases": [
    {
      "Sale": {
        "Id": 98,
        "SaleDate": "2016-03-13T12:52:32.123Z",
        "SaleTime": "SaleTime0",
        "SaleDateTime": "2016-03-13T12:52:32.123Z",
        "OriginalSaleDateTime": "2016-03-13T12:52:32.123Z"
      },
      "Description": "Description6",
      "AccountPayment": false,
      "Price": 196.4,
      "AmountPaid": 220.96
    }
  ]
}
```

