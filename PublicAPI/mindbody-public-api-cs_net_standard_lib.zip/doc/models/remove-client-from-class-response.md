
# Remove Client From Class Response

## Structure

`RemoveClientFromClassResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Class` | [`Models.MindbodyPublicApiDtoModelsV6Class`](../../doc/models/mindbody-public-api-dto-models-v6-class.md) | Optional | Contains information about the class from which the client was removed. |

## Example (as JSON)

```json
{
  "Class": null
}
```

