
# Copy Credit Card Response Client

## Structure

`CopyCreditCardResponseClient`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Optional | ClientId |
| `SiteId` | `int?` | Optional | SiteId |
| `FirstName` | `string` | Optional | First name of ClientId |
| `LastName` | `string` | Optional | Last name of ClientId |

## Example (as JSON)

```json
{
  "ClientId": "ClientId0",
  "SiteId": 246,
  "FirstName": "FirstName8",
  "LastName": "LastName2"
}
```

