
# Get Client Formula Notes Response

Enables to retrieve cross regional formula notes for a client, or for a specific appointment. The two parameters are optional, however at least one must be provided. This endpoint supports pagination.

## Structure

`GetClientFormulaNotesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `FormulaNotes` | [`List<Models.FormulaNoteResponse>`](../../doc/models/formula-note-response.md) | Optional | Contains details about the client’s formula. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "FormulaNotes": [
    {
      "Id": 67,
      "ClientId": "ClientId9",
      "AppointmentId": 101,
      "EntryDate": "2016-03-13T12:52:32.123Z",
      "Note": "Note7"
    }
  ]
}
```

