
# Transaction

## Structure

`Transaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TransactionId` | `int?` | Optional | The transaction ID. |
| `SaleId` | `long?` | Optional | The sale ID. |
| `ClientId` | `long?` | Optional | The ID of the client who made the purchase. |
| `Amount` | `double?` | Optional | The amount charged on the card |
| `Settled` | `bool?` | Optional | Whether it is settled or not |
| `Status` | `string` | Optional | Status of the transaction |
| `TransactionTime` | `DateTime?` | Optional | Time of card swiped |
| `AuthTime` | `DateTime?` | Optional | Time of card authorized |
| `LocationId` | `int?` | Optional | The ID of the location where the sale takes place. |
| `MerchantId` | `string` | Optional | Merchant ID of the studio |
| `TerminalId` | `string` | Optional | Terminal ID used for payment. Not applicable for CNP/Bank |
| `CardExpirationMonth` | `string` | Optional | Expiry month of the card |
| `CardExpirationYear` | `string` | Optional | Expiry year of the card |
| `CCLastFour` | `string` | Optional | Last 4 digits of CC |
| `CardType` | `string` | Optional | Type of the card |
| `CCSwiped` | `bool?` | Optional | Whether card is swiped or not |
| `ACHLastFour` | `string` | Optional | Customer’s ACH last 4 digits |

## Example (as JSON)

```json
{
  "TransactionId": 132,
  "SaleId": 62,
  "ClientId": 190,
  "Amount": 57.88,
  "Settled": false
}
```

