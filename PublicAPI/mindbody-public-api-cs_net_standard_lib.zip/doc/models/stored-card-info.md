
# Stored Card Info

## Structure

`StoredCardInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `LastFour` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "LastFour": "LastFour2"
}
```

