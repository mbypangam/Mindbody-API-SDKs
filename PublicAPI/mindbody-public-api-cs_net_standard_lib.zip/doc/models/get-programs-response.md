
# Get Programs Response

## Structure

`GetProgramsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `Programs` | [`List<Models.Program>`](../../doc/models/program.md) | Optional | Contains information about the programs. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Programs": null
}
```

