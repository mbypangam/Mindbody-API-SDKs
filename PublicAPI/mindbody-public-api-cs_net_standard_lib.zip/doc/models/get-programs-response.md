
# Get Programs Response

## Structure

`GetProgramsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Programs` | [`List<Models.MindbodyPublicApiDtoModelsV6Program>`](../../doc/models/mindbody-public-api-dto-models-v6-program.md) | Optional | Contains information about the programs. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Programs": null
}
```

