
# Custom Payment Method

## Structure

`CustomPaymentMethod`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID of the custom payment method. |
| `Name` | `string` | Optional | The name of the custom payment method. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

