
# Get Sales Reps Response

This is the response class for the get sales reps API

## Structure

`GetSalesRepsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `SalesReps` | [`List<Models.SalesRepResponse>`](../../doc/models/sales-rep-response.md) | Optional | This the list of sales reps and their details |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "SalesReps": null
}
```

