
# Mindbody Public Api Dto Models V6 Sale Controller Completed Sale Transaction Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleTransactionResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `TransactionId` | `int?` | Optional | The Transaction ID. |
| `AuthenticationUrl` | `string` | Optional | The optional valid URL provided by the bank. |

## Example (as JSON)

```json
{
  "TransactionId": null,
  "AuthenticationUrl": null
}
```

