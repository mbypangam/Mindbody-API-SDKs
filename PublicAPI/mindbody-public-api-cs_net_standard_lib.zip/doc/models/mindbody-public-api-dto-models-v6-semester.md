
# Mindbody Public Api Dto Models V6 Semester

Semesters help you quickly classify enrollments.

## Structure

`MindbodyPublicApiDtoModelsV6Semester`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |
| `Description` | `string` | Optional | - |
| `StartDate` | `DateTime?` | Optional | - |
| `EndDate` | `DateTime?` | Optional | - |
| `MultiRegistrationDiscount` | `double?` | Optional | - |
| `MultiRegistrationDeadline` | `DateTime?` | Optional | - |
| `Active` | `bool?` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null,
  "StartDate": null,
  "EndDate": null,
  "MultiRegistrationDiscount": null,
  "MultiRegistrationDeadline": null,
  "Active": null
}
```

