
# Add Client Response

## Structure

`AddClientResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Client` | [`Models.Client`](../../doc/models/client.md) | Optional | The Client. |

## Example (as JSON)

```json
{
  "Client": null
}
```

