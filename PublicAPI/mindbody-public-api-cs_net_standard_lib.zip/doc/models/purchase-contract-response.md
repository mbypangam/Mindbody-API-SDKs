
# Purchase Contract Response

## Structure

`PurchaseContractResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Optional | The ID of the client who is purchasing the contract. |
| `LocationId` | `int?` | Optional | The ID of the location where the contract is being purchased. |
| `ContractId` | `int?` | Optional | The ID of the general contract being purchased. |
| `ClientContractId` | `int?` | Optional | The ID of the specific contract being purchased by this specific client, not to be confused with the `ContractId`, which refers to a general contract that the business offers. |
| `PaymentProcessingFailures` | [`List<PaymentProcessingFailure>`](../../doc/models/payment-processing-failure.md) | Optional | Contains information only if SCA challenge is indicated. |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "LocationId": 50,
  "ContractId": 136,
  "ClientContractId": 86,
  "PaymentProcessingFailures": [
    {
      "Type": "Type4",
      "Message": "Message0",
      "AuthenticationRedirectUrl": "AuthenticationRedirectUrl0"
    }
  ]
}
```

