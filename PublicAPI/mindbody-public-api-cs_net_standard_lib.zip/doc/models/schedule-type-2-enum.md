
# Schedule Type 2 Enum

## Enumeration

`ScheduleType2Enum`

## Fields

| Name |
|  --- |
| `All` |
| `DropIn` |
| `Enrollment` |
| `Appointment` |
| `Resource` |
| `Media` |
| `Arrival` |

