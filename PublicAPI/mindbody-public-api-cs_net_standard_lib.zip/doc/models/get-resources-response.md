
# Get Resources Response

## Structure

`GetResourcesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Resources` | [`List<Models.MindbodyPublicApiDtoModelsV6Resource>`](../../doc/models/mindbody-public-api-dto-models-v6-resource.md) | Optional | Contains information about resources as the business. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Resources": null
}
```

