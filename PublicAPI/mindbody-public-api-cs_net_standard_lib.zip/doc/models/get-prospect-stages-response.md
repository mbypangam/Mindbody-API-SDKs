
# Get Prospect Stages Response

Get Prospect Stages Response Model

## Structure

`GetProspectStagesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProspectStages` | [`List<Models.MindbodyPublicApiDtoModelsV6ProspectStage>`](../../doc/models/mindbody-public-api-dto-models-v6-prospect-stage.md) | Optional | List of Prospect Stages |

## Example (as JSON)

```json
{
  "ProspectStages": null
}
```

