
# Get Prospect Stages Response

Get Prospect Stages Response Model

## Structure

`GetProspectStagesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProspectStages` | [`List<ProspectStage>`](../../doc/models/prospect-stage.md) | Optional | List of Prospect Stages |

## Example (as JSON)

```json
{
  "ProspectStages": [
    {
      "Active": true,
      "Description": "Description3",
      "Id": 97
    }
  ]
}
```

