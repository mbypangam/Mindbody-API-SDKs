
# Semester

Semesters help you quickly classify enrollments.

## Structure

`Semester`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | This semester’s unique ID. |
| `Name` | `string` | Optional | Name of the semester. |
| `Description` | `string` | Optional | The description of the semester. |
| `StartDate` | `DateTime?` | Optional | Start date of the semester. |
| `EndDate` | `DateTime?` | Optional | End date of the semester. |
| `MultiRegistrationDiscount` | `double?` | Optional | Discount for multiple registration in the semester. |
| `MultiRegistrationDeadline` | `DateTime?` | Optional | Registration deadline of the semester. |
| `Active` | `bool?` | Optional | When `true`, indicates that the semester is active. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null,
  "StartDate": null,
  "EndDate": null,
  "MultiRegistrationDiscount": null,
  "MultiRegistrationDeadline": null,
  "Active": null
}
```

