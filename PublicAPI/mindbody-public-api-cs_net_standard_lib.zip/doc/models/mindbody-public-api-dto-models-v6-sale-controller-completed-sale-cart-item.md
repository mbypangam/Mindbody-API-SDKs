
# Mindbody Public Api Dto Models V6 Sale Controller Completed Sale Cart Item

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleCartItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Item` | `object` | Optional | A purchased item; either a pricing option or a retail product. |
| `DiscountAmount` | `double?` | Optional | The amount of the discount applied to the item. |
| `VisitIds` | `List<long>` | Optional | The IDs of the booked classes, enrollments, or courses that were reconciled by this cart item. This list is only returned if a valid visit ID was passed in the request’s `VisitIds` list. |
| `AppointmentIds` | `List<long>` | Optional | Gets or sets the item. |
| `Appointments` | [`List<Models.MindbodyPublicApiDtoModelsV6Appointment>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment.md) | Optional | The IDs of the appointments that were reconciled by this cart item. This list is only returned if a valid appointment ID was passed in the request’s `AppointmentIds` list. |
| `Id` | `int?` | Optional | The item’s ID in the current cart. |
| `Quantity` | `int?` | Optional | The quantity of the item being purchased. |

## Example (as JSON)

```json
{
  "Item": null,
  "DiscountAmount": null,
  "VisitIds": null,
  "AppointmentIds": null,
  "Appointments": null,
  "Id": null,
  "Quantity": null
}
```

