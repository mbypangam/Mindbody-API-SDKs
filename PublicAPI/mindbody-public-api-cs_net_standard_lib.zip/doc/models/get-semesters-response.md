
# Get Semesters Response

Get Semesters Response Model

## Structure

`GetSemestersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `Semesters` | [`List<Models.Semester>`](../../doc/models/semester.md) | Optional | Contains the Semester objects, each of which describes the semesters for a site. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Semesters": null
}
```

