
# Custom Client Field

A custom client field

## Structure

`CustomClientField`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID of the custom client field. |
| `DataType` | `string` | Optional | The data type of the field. |
| `Name` | `string` | Optional | The name of the field. |

## Example (as JSON)

```json
{
  "Id": 12,
  "DataType": "DataType2",
  "Name": "Name2"
}
```

