
# Program Membership

## Structure

`ProgramMembership`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The service category’s ID. |
| `Name` | `string` | Optional | The name of this service category. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

