
# Get Products Inventory Response

## Structure

`GetProductsInventoryResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `ProductsInventory` | [`List<Models.ProductsInventory>`](../../doc/models/products-inventory.md) | Optional | Contains information about the products inventory. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "ProductsInventory": [
    {
      "ProductId": 109,
      "BarcodeId": "BarcodeId5",
      "LocationId": 211,
      "UnitsLogged": 15,
      "UnitsSold": 19
    },
    {
      "ProductId": 110,
      "BarcodeId": "BarcodeId6",
      "LocationId": 212,
      "UnitsLogged": 14,
      "UnitsSold": 20
    }
  ]
}
```

