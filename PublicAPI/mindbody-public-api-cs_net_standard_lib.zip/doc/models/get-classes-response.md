
# Get Classes Response

## Structure

`GetClassesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Classes` | [`List<Models.Class>`](../../doc/models/class.md) | Optional | A list of the requested classes. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Classes": null
}
```

