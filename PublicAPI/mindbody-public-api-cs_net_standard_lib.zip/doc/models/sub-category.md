
# Sub Category

## Structure

`SubCategory`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The Id of the subcategory. |
| `SubCategoryName` | `string` | Optional | The name of the subcategory. |
| `Active` | `bool?` | Optional | When `true`, indicates that the subcategory is active. |

## Example (as JSON)

```json
{
  "Id": 146,
  "SubCategoryName": "SubCategoryName0",
  "Active": false
}
```

