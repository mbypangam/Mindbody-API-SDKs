
# Add Staff Response

## Structure

`AddStaffResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Staff` | [`Models.Staff`](../../doc/models/staff.md) | Optional | Contains information about the staff |

## Example (as JSON)

```json
{
  "Staff": null
}
```

