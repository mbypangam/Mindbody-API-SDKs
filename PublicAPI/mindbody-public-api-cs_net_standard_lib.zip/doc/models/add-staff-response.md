
# Add Staff Response

## Structure

`AddStaffResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Staff` | [`Models.Staff`](../../doc/models/staff.md) | Optional | The Staff |

## Example (as JSON)

```json
{
  "Staff": null
}
```

