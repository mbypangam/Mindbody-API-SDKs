
# Mindbody Public Api Common Models Resource

## Structure

`MindbodyPublicApiCommonModelsResource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

