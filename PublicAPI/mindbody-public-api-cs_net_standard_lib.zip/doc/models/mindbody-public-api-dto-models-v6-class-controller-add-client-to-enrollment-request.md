
# Mindbody Public Api Dto Models V6 Class Controller Add Client to Enrollment Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | The client IDs of the clients to add to the specified enrollments. |
| `ClassScheduleId` | `int` | Required | The class schedule IDs of the enrollments to add the clients to. The ClassScheduleId can be found in GetEnrollments as the EnrollmentId. |
| `EnrollDateForward` | `DateTime?` | Optional | Enroll the clients from this date forward. EnrollDateForward takes priority over open enrollment.<br>Default: **null** |
| `EnrollOpen` | `List<DateTime>` | Optional | Enroll for selected dates. |
| `Test` | `bool?` | Optional | When `true`, input information is validated, but not committed.<br /><br>Default: **false** |
| `SendEmail` | `bool?` | Optional | When `true`, indicates that the client should be sent an email. An email is only sent if the client has an email address and automatic emails have been set up. <br /><br>Default: **false** |
| `Waitlist` | `bool?` | Optional | When `true`, the client is added to a specific enrollments waiting list.. |
| `WaitlistEntryId` | `int?` | Optional | The waiting list entry to add. Used to add a client to an enrollment from a waiting list entry. |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "ClassScheduleId": 4,
  "EnrollDateForward": null,
  "EnrollOpen": null,
  "Test": null,
  "SendEmail": null,
  "Waitlist": null,
  "WaitlistEntryId": null
}
```

