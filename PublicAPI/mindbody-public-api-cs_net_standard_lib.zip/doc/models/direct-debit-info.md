
# Direct Debit Info

## Structure

`DirectDebitInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `NameOnAccount` | `string` | Optional | The name on the bank account. |
| `RoutingNumber` | `string` | Optional | The routing number for the bank. |
| `AccountNumber` | `string` | Optional | The last four of the bank account number. |
| `AccountType` | `string` | Optional | The account type.<br><br>Possible values:<br><br>* Checking<br>* Savings |

## Example (as JSON)

```json
{
  "NameOnAccount": "NameOnAccount6",
  "RoutingNumber": "RoutingNumber0",
  "AccountNumber": "AccountNumber4",
  "AccountType": "AccountType0"
}
```

