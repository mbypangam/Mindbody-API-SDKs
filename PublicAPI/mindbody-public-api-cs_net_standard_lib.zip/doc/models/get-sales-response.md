
# Get Sales Response

## Structure

`GetSalesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Sales` | [`List<Models.MindbodyPublicApiDtoModelsV6Sale>`](../../doc/models/mindbody-public-api-dto-models-v6-sale.md) | Optional | Contains the Sale objects, each of which describes the sale and payment for a purchase event. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Sales": null
}
```

