
# Get Sales Response

## Structure

`GetSalesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `Sales` | [`List<Models.Sale>`](../../doc/models/sale.md) | Optional | Contains the Sale objects, each of which describes the sale and payment for a purchase event. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Sales": null
}
```

