
# Mindbody Public Api Dto Models V6 Purchased Item

## Structure

`MindbodyPublicApiDtoModelsV6PurchasedItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SaleDetailId` | `int?` | Optional | The ID of the sale detail |
| `Id` | `long?` | Optional | The ProductID of the item. |
| `IsService` | `bool?` | Optional | When `true`, indicates that the purchased item was a pricing option for a service. |
| `BarcodeId` | `string` | Optional | The BarcodeId of the item.<br>For services, BarcodeId may be null<br>If no barcode id is explicitly set by the business it is the internal id in a string format. |
| `Description` | `string` | Optional | Description of the sale transaction/pricing option description |
| `ContractId` | `int?` | Optional | Contract ID purchased by the client |
| `CategoryId` | `int?` | Optional | Revenue Category ID |
| `SubCategoryId` | `int?` | Optional | Revenue Subcategory ID |
| `UnitPrice` | `double?` | Optional | Per unit price of the item sold |
| `Quantity` | `int?` | Optional | Quantity of the products |
| `DiscountPercent` | `double?` | Optional | Discount % applied during sale |
| `DiscountAmount` | `double?` | Optional | Discount Amount |
| `Tax1` | `double?` | Optional | Tax1 applicable for the product |
| `Tax2` | `double?` | Optional | Tax2 applicable for the product |
| `Tax3` | `double?` | Optional | Tax3 applicable for the product |
| `Tax4` | `double?` | Optional | Tax4 applicable for the product |
| `Tax5` | `double?` | Optional | Tax5 applicable for the product |
| `TaxAmount` | `double?` | Optional | Tax rate applicable for the product |
| `TotalAmount` | `double?` | Optional | Charged to the customer for paying |
| `Notes` | `string` | Optional | Notes |
| `Returned` | `bool?` | Optional | Returned or not |
| `PaymentRefId` | `int?` | Optional | Payment Reference ID |
| `ExpDate` | `DateTime?` | Optional | Expiration date of the pricing option purchased |
| `ActiveDate` | `DateTime?` | Optional | Activation date of pricing option purchased |

## Example (as JSON)

```json
{
  "SaleDetailId": null,
  "Id": null,
  "IsService": null,
  "BarcodeId": null,
  "Description": null,
  "ContractId": null,
  "CategoryId": null,
  "SubCategoryId": null,
  "UnitPrice": null,
  "Quantity": null,
  "DiscountPercent": null,
  "DiscountAmount": null,
  "Tax1": null,
  "Tax2": null,
  "Tax3": null,
  "Tax4": null,
  "Tax5": null,
  "TaxAmount": null,
  "TotalAmount": null,
  "Notes": null,
  "Returned": null,
  "PaymentRefId": null,
  "ExpDate": null,
  "ActiveDate": null
}
```

