
# Sales Rep Response

This is the sales rep DTO

## Structure

`SalesRepResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The unique Id of the sales rep |
| `FirstName` | `string` | Optional | The firstname of the sales rep |
| `LastName` | `string` | Optional | The lastname of the sales rep |
| `SalesRepNumbers` | `List<int>` | Optional | The sales rep Ids that are assigned to the rep |

## Example (as JSON)

```json
{
  "Id": 160,
  "FirstName": "FirstName8",
  "LastName": "LastName8",
  "SalesRepNumbers": [
    84,
    85
  ]
}
```

