
# Get Staff Response

## Structure

`GetStaffResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | - |
| `StaffMembers` | [`List<Models.Staff>`](../../doc/models/staff.md) | Optional | A list of staff members. See Staff for a description of the 'Staff' information. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "StaffMembers": null
}
```

