
# Mindbody Public Api Dto Models V6 Client Controller Get Client Rewards Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientRewardsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. |
| `Balance` | `long?` | Optional | The total rewards points available to the indicated client after the above transaction. |
| `Transactions` | [`List<Models.MindbodyPublicApiDtoModelsV6ClientRewardTransaction>`](../../doc/models/mindbody-public-api-dto-models-v6-client-reward-transaction.md) | Optional | Contains information about the reward transaction details. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Balance": null,
  "Transactions": null
}
```

