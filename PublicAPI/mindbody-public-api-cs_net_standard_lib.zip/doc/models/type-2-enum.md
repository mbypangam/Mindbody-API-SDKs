
# Type 2 Enum

Contains the class description session type.

## Enumeration

`Type2Enum`

## Fields

| Name |
|  --- |
| `All` |
| `Class` |
| `Enrollment` |
| `Appointment` |
| `Resource` |
| `Media` |
| `Arrival` |

