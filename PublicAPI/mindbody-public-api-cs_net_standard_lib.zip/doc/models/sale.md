
# Sale

Contains the Sale details.

## Structure

`Sale`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The sale ID. |
| `SaleDate` | `DateTime?` | Optional | The date the item was sold. |
| `SaleTime` | `string` | Optional | The time the item was sold. |
| `SaleDateTime` | `DateTime?` | Optional | The date and time the item was sold. |
| `OriginalSaleDateTime` | `DateTime?` | Optional | The date and time the item was sold originally. |
| `SalesRepId` | `long?` | Optional | The sales representative ID |
| `ClientId` | `string` | Optional | The ID of the client who made the purchase. |
| `RecipientClientId` | `long?` | Optional | Recipient Client Id |
| `PurchasedItems` | [`List<PurchasedItem>`](../../doc/models/purchased-item.md) | Optional | Contains the `PurchasedItem` objects that describe the purchased items. |
| `LocationId` | `int?` | Optional | The ID of the location where the sale takes place. |
| `Payments` | [`List<SalePayment>`](../../doc/models/sale-payment.md) | Optional | Contains the `SalePayment` objects that describe the payments that contributed to this sale. |

## Example (as JSON)

```json
{
  "Id": 146,
  "SaleDate": "2016-03-13T12:52:32.123Z",
  "SaleTime": "SaleTime8",
  "SaleDateTime": "2016-03-13T12:52:32.123Z",
  "OriginalSaleDateTime": "2016-03-13T12:52:32.123Z"
}
```

