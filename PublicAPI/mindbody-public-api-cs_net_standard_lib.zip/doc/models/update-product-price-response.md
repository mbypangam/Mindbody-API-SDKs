
# Update Product Price Response

Update Product Price Response Model

## Structure

`UpdateProductPriceResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Product` | [`Models.Product`](../../doc/models/product.md) | Optional | Contains information about the product. |

## Example (as JSON)

```json
{
  "Product": null
}
```

