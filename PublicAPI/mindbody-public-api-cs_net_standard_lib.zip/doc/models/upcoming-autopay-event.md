
# Upcoming Autopay Event

## Structure

`UpcomingAutopayEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientContractId` | `int?` | Optional | The ID of the contract. |
| `ChargeAmount` | `double?` | Optional | The amount charged. |
| `PaymentMethod` | [`Models.PaymentMethodEnum?`](../../doc/models/payment-method-enum.md) | Optional | The payment method. |
| `ScheduleDate` | `DateTime?` | Optional | The date and time of the next payment. |

## Example (as JSON)

```json
{
  "ClientContractId": 86,
  "ChargeAmount": 63.12,
  "PaymentMethod": "Other",
  "ScheduleDate": "2016-03-13T12:52:32.123Z"
}
```

