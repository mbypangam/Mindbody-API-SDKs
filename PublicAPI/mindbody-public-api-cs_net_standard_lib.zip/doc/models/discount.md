
# Discount

Discount for a promo code

## Structure

`Discount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Type` | `string` | Optional | Type of discount percentage/amount |
| `Amount` | `double?` | Optional | Amount of discount |

## Example (as JSON)

```json
{
  "Type": null,
  "Amount": null
}
```

