
# Contact Log Comment

A contact log comment.

## Structure

`ContactLogComment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The comment’s ID. |
| `Text` | `string` | Optional | The comment’s body text. |
| `CreatedDateTime` | `DateTime?` | Optional | The local time when the comment was created. |
| `CreatedBy` | [`Models.Staff`](../../doc/models/staff.md) | Optional | The Staff |

## Example (as JSON)

```json
{
  "Id": null,
  "Text": null,
  "CreatedDateTime": null,
  "CreatedBy": null
}
```

