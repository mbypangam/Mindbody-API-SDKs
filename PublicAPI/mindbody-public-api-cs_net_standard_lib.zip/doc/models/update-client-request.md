
# Update Client Request

## Structure

`UpdateClientRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Client` | [`Models.ClientWithSuspensionInfo`](../../doc/models/client-with-suspension-info.md) | Required | A Client DTO with Suspension Informatoin |
| `Test` | `bool?` | Optional | When `true`, indicates that test mode is enabled. The method is validated, but no client data is added or updated.<br /><br>Default: **false** |
| `CrossRegionalUpdate` | `bool?` | Optional | When `true`, the updated information is propagated to all of the region’s sites where the client has a profile.<br /><br>When `false`, only the local client is updated.<br /><br>Default: **true** |
| `NewId` | `string` | Optional | The new RSSID to be used for the client. Use `NewId` to assign a specific number to be a client’s ID. If that number is not available, the call returns an error. This RSSID must be unique within the subscriber’s site. If this is a cross-regional update, the RSSID must be unique across the region. If the requested number is already in use, an error is returned. |

## Example (as JSON)

```json
{
  "Client": {
    "SuspensionInfo": {
      "BookingSuspended": false,
      "SuspensionStartDate": "SuspensionStartDate0",
      "SuspensionEndDate": "SuspensionEndDate4"
    },
    "AppointmentGenderPreference": "None",
    "BirthDate": "2016-03-13T12:52:32.123Z",
    "Country": "Country8",
    "CreationDate": "2016-03-13T12:52:32.123Z"
  },
  "Test": false,
  "CrossRegionalUpdate": false,
  "NewId": "NewId4"
}
```

