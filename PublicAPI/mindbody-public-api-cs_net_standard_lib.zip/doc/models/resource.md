
# Resource

## Structure

`Resource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "Id": 146,
  "Name": "Name0"
}
```

