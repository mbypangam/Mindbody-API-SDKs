
# Add Appointment Add on Response

## Structure

`AddAppointmentAddOnResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AppointmentId` | `long?` | Optional | This is the id of the main appointment we added on to |
| `AddOnAppointmentId` | `long?` | Optional | This is the id for the newly created add-on appointment |

## Example (as JSON)

```json
{
  "AppointmentId": 22,
  "AddOnAppointmentId": 108
}
```

