
# Update Class Enrollment Schedule Request

## Structure

`UpdateClassEnrollmentScheduleRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClassId` | `int?` | Optional | The class id, a block of schedules |
| `ClassDescriptionId` | `int?` | Optional | Used only internally, overridden if sent |
| `LocationId` | `int?` | Optional | The location where the class is taking place |
| `StartDate` | `DateTime?` | Optional | Class start time (use null for TBD) |
| `EndDate` | `DateTime?` | Optional | Class end time (ignored if StartTime is null) |
| `StartTime` | `DateTime?` | Optional | Class start time (use null for TBD) |
| `EndTime` | `DateTime?` | Optional | Class end time (ignored if StartTime is null) |
| `DaySunday` | `bool?` | Optional | (optional) - If the class occurs on Sunday (ignored if EndDate is null) |
| `DayMonday` | `bool?` | Optional | (optional) - If the class occurs on Monday (ignored if EndDate is null) |
| `DayTuesday` | `bool?` | Optional | (optional) - If the class occurs on Tuesday (ignored if EndDate is null) |
| `DayWednesday` | `bool?` | Optional | (optional) - If the class occurs on Wednesday (ignored if EndDate is null) |
| `DayThursday` | `bool?` | Optional | (optional) - If the class occurs on Thursday (ignored if EndDate is null) |
| `DayFriday` | `bool?` | Optional | (optional) - If the class occurs on Friday (ignored if EndDate is null) |
| `DaySaturday` | `bool?` | Optional | (optional) - If the class occurs on Saturday (ignored if EndDate is null |
| `StaffId` | `long?` | Optional | The staff member teaching the class |
| `StaffPayRate` | `int?` | Optional | The staff pay rate |
| `ResourceId` | `int?` | Optional | (optional) - The room where the class is taking place |
| `MaxCapacity` | `int?` | Optional | How many people can attend |
| `WebCapacity` | `int?` | Optional | How many people can signup online (if 0 clients cannot signup online) |
| `WaitlistCapacity` | `int?` | Optional | One of: PaymentRequired, BookAndPayLater, Free |
| `BookingStatus` | `string` | Optional | One of: PaymentRequired, BookAndPayLater, Free |
| `AllowOpenEnrollment` | `bool?` | Optional | Allow clients to choose which sessions they'd like to sign up for |
| `AllowDateForwardEnrollment` | `bool?` | Optional | Allow booking after the enrollment has started |

## Example (as JSON)

```json
{
  "ClassId": null,
  "ClassDescriptionId": null,
  "LocationId": null,
  "StartDate": null,
  "EndDate": null,
  "StartTime": null,
  "EndTime": null,
  "DaySunday": null,
  "DayMonday": null,
  "DayTuesday": null,
  "DayWednesday": null,
  "DayThursday": null,
  "DayFriday": null,
  "DaySaturday": null,
  "StaffId": null,
  "StaffPayRate": null,
  "ResourceId": null,
  "MaxCapacity": null,
  "WebCapacity": null,
  "WaitlistCapacity": null,
  "BookingStatus": null,
  "AllowOpenEnrollment": null,
  "AllowDateForwardEnrollment": null
}
```

