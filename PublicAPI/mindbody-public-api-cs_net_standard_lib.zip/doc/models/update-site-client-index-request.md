
# Update Site Client Index Request

## Structure

`UpdateSiteClientIndexRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientIndexID` | `int` | Required | The ID of the client index. |
| `ClientIndexName` | `string` | Required | The name of the client index. |
| `Active` | `bool?` | Optional | Indicates if Client Index is Active |
| `ShowOnNewClient` | `bool?` | Optional | Indicates if Client Index is shown on a new client profile |
| `ShowOnEnrollmentRoster` | `bool?` | Optional | Indicates if Client Index is shown on Enrollement Roster |
| `EditOnEnrollmentRoster` | `bool?` | Optional | Indicates if Client Index can be edited on Enrollement Roster |
| `SortOrder` | `int?` | Optional | Indicates sort order |
| `ShowInConsumerMode` | `bool?` | Optional | Indicates if Client Index is shown in consumer mode. |
| `RequiredConsumerMode` | `bool?` | Optional | Indicates if the index is required when creating profiles in consumer mode. |
| `RequiredBizMode` | `bool?` | Optional | Indicates if the index is required when creating profiles in business mode. |

## Example (as JSON)

```json
{
  "ClientIndexID": 94,
  "ClientIndexName": "ClientIndexName4",
  "Active": false,
  "ShowOnNewClient": false,
  "ShowOnEnrollmentRoster": false,
  "EditOnEnrollmentRoster": false,
  "SortOrder": 18
}
```

