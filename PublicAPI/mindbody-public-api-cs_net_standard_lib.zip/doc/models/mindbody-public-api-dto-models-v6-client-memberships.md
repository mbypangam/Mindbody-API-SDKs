
# Mindbody Public Api Dto Models V6 Client Memberships

## Structure

`MindbodyPublicApiDtoModelsV6ClientMemberships`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Optional | ID of the client. |
| `Memberships` | [`List<Models.MindbodyPublicApiDtoModelsV6ClientMembership>`](../../doc/models/mindbody-public-api-dto-models-v6-client-membership.md) | Optional | Contains information about the Client Memberships details. |
| `ErrorMessage` | `string` | Optional | Incase if invalid clientID passed, we get ErrorMessage instead of Memberships. |

## Example (as JSON)

```json
{
  "ClientId": null,
  "Memberships": null,
  "ErrorMessage": null
}
```

