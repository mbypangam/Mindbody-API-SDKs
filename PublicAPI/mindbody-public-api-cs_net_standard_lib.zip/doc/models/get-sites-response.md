
# Get Sites Response

## Structure

`GetSitesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Sites` | [`List<Models.Site>`](../../doc/models/site.md) | Optional | Contains information about the sites. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Sites": null
}
```

