
# Update Sale Date Response

Update Sale Date Response Properties

## Structure

`UpdateSaleDateResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Sale` | [`Models.Sale`](../../doc/models/sale.md) | Optional | The updated Sale corresponding to the modified date |

## Example (as JSON)

```json
{
  "Sale": null
}
```

