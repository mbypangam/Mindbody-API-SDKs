
# Update Sale Date Response

Update Sale Date Response Properties

## Structure

`UpdateSaleDateResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Sale` | [`Models.Sale`](../../doc/models/sale.md) | Optional | Contains the Sale details. |

## Example (as JSON)

```json
{
  "Sale": null
}
```

