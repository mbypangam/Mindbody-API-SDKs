
# Add Class Enrollment Schedule Request

## Structure

`AddClassEnrollmentScheduleRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClassDescriptionId` | `int?` | Optional | The Id of the class/enrollment description. This can be found in GetClassDescriptions. |
| `LocationId` | `int?` | Optional | The Location Id of the enrollment schedule. |
| `StartDate` | `DateTime?` | Optional | The start date of the enrollment schedule. |
| `EndDate` | `DateTime?` | Optional | The end date of the enrollment schedule. |
| `StartTime` | `DateTime?` | Optional | Enrollment start time (use null or omit for TBD). |
| `EndTime` | `DateTime?` | Optional | Enrollment end time (ignored if StartTime is null or omitted). |
| `DaySunday` | `bool?` | Optional | If the enrollment occurs on Sunday(s). |
| `DayMonday` | `bool?` | Optional | If the enrollment occurs on Monday(s). |
| `DayTuesday` | `bool?` | Optional | If the enrollment occurs on Tuesday(s). |
| `DayWednesday` | `bool?` | Optional | If the enrollment occurs on Wednesday(s). |
| `DayThursday` | `bool?` | Optional | If the enrollment occurs on Thursday(s). |
| `DayFriday` | `bool?` | Optional | If the enrollment occurs on Friday(s). |
| `DaySaturday` | `bool?` | Optional | If the enrollment occurs on Saturday(s). |
| `StaffId` | `long?` | Optional | The staff member teaching the enrollment. |
| `StaffPayRate` | `int?` | Optional | The staff pay rate. Must be between 1-21. |
| `ResourceId` | `int?` | Optional | The room where the enrollment is taking place. |
| `MaxCapacity` | `int?` | Optional | How many people can attend. |
| `WebCapacity` | `int?` | Optional | How many people can signup online.<br>Default: **0** |
| `WaitlistCapacity` | `int?` | Optional | How many people can waitlist.<br>Default:**0** |
| `BookingStatus` | `string` | Optional | One of: PaymentRequired, BookAndPayLater, Free |
| `AllowOpenEnrollment` | `bool?` | Optional | Allow clients to choose which sessions they’d like to sign up for.<br>Default: **false** |
| `AllowDateForwardEnrollment` | `bool?` | Optional | Allow booking after the enrollment has started.<br>Default: **false** |
| `PricingOptionsProductIds` | `List<int>` | Optional | Pricing Options for this schedule |

## Example (as JSON)

```json
{
  "ClassDescriptionId": 176,
  "LocationId": 4,
  "StartDate": "2016-03-13T12:52:32.123Z",
  "EndDate": "2016-03-13T12:52:32.123Z",
  "StartTime": "2016-03-13T12:52:32.123Z"
}
```

