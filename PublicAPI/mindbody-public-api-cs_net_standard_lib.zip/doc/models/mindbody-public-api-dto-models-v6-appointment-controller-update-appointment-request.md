
# Mindbody Public Api Dto Models V6 Appointment Controller Update Appointment Request

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AppointmentId` | `long` | Required | A unique ID for the appointment. |
| `EndDateTime` | `DateTime?` | Optional | The end date and time of the new appointment.<br><br />Default: **StartDateTime**, offset by the staff member?s default appointment duration. |
| `Execute` | `string` | Optional | The action taken to add this appointment. |
| `GenderPreference` | `string` | Optional | The client?s service provider gender preference. |
| `Notes` | `string` | Optional | Any general notes about this appointment. |
| `PartnerExternalId` | `string` | Optional | Optional external key for api partners. |
| `ProviderId` | `string` | Optional | If a user has Complementary and Alternative Medicine features enabled, this parameter assigns a provider ID to the appointment. |
| `ResourceIds` | `List<int>` | Optional | A list of resource IDs to associate with the new appointment. |
| `SendEmail` | `bool?` | Optional | Whether to send client an email for cancellations. An email is sent only if the client has an email address and automatic emails have been set up.<br><br />Default: **false** |
| `SessionTypeId` | `int?` | Optional | The session type associated with the new appointment. |
| `StaffId` | `long?` | Optional | The ID of the staff member who is adding the new appointment. |
| `StartDateTime` | `DateTime?` | Optional | The start date and time of the new appointment. |
| `Test` | `bool?` | Optional | When `true`, indicates that the method is to be validated, but no new appointment data is added.<br><br />Default: **false** |

## Example (as JSON)

```json
{
  "AppointmentId": 22,
  "EndDateTime": null,
  "Execute": null,
  "GenderPreference": null,
  "Notes": null,
  "PartnerExternalId": null,
  "ProviderId": null,
  "ResourceIds": null,
  "SendEmail": null,
  "SessionTypeId": null,
  "StaffId": null,
  "StartDateTime": null,
  "Test": null
}
```

