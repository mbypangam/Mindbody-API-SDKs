
# Mindbody Public Api Dto Models V6 Client Controller Get Custom Client Fields Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetCustomClientFieldsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `CustomClientFields` | [`List<Models.MindbodyPublicApiDtoModelsV6CustomClientField>`](../../doc/models/mindbody-public-api-dto-models-v6-custom-client-field.md) | Optional | Contains information about the available custom client fields. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "CustomClientFields": null
}
```

