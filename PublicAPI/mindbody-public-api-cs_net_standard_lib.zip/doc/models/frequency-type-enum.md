
# Frequency Type Enum

The class schedule recurrence type.

## Enumeration

`FrequencyTypeEnum`

## Fields

| Name |
|  --- |
| `Daily` |
| `Weekly` |
| `Monthly` |

