
# Get Scheduled Service Earnings Response

## Structure

`GetScheduledServiceEarningsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `ScheduledServiceEarnings` | [`List<ScheduledServiceEarningsEvent>`](../../doc/models/scheduled-service-earnings-event.md) | Optional | Contains the class payroll events. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "ScheduledServiceEarnings": [
    {
      "StaffId": 171,
      "ScheduledServiceId": 255,
      "ScheduledServiceType": "All",
      "Earnings": 141.51,
      "DateTime": "2016-03-13T12:52:32.123Z"
    }
  ]
}
```

