
# Get Scheduled Service Earnings Response

## Structure

`GetScheduledServiceEarningsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `ScheduledServiceEarnings` | [`List<Models.MindbodyPublicApiDtoModelsV6ScheduledServiceEarningsEvent>`](../../doc/models/mindbody-public-api-dto-models-v6-scheduled-service-earnings-event.md) | Optional | Contains the class payroll events. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ScheduledServiceEarnings": null
}
```

