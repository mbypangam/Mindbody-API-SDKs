
# Mindbody Public Api Dto Models V6 Client Controller Suspend Contract Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | The RSSID of the client for whom the contract is getting suspended. |
| `ClientContractId` | `int` | Required | The unique ID of the sale of the contract |
| `SuspensionType` | `string` | Optional | The suspension type |
| `SuspensionStart` | `DateTime?` | Optional | The date to start contract suspension |
| `Duration` | `int?` | Optional | The number of (DurationUnit) the suspension lasts |
| `DurationUnit` | `int?` | Optional | The unit applied to duration |
| `OpenEnded` | `bool?` | Optional | Indicates open ended suspension |
| `SuspensionNotes` | `string` | Optional | The suspension notes |
| `SuspensionFee` | `double?` | Optional | charge to suspend a contract for a set period of time |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "ClientContractId": 86,
  "SuspensionType": null,
  "SuspensionStart": null,
  "Duration": null,
  "DurationUnit": null,
  "OpenEnded": null,
  "SuspensionNotes": null,
  "SuspensionFee": null
}
```

