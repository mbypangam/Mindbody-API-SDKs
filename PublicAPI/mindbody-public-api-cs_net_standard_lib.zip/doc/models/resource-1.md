
# Resource 1

## Structure

`Resource1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |
| `LocationId` | `int?` | Optional | - |
| `IsActive` | `bool?` | Optional | - |
| `ScheduleTypes` | [`List<Models.ScheduleType4Enum>`](../../doc/models/schedule-type-4-enum.md) | Optional | - |
| `ProgramIds` | `List<int>` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "LocationId": null,
  "IsActive": null,
  "ScheduleTypes": null,
  "ProgramIds": null
}
```

