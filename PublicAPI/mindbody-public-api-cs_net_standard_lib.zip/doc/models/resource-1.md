
# Resource 1

## Structure

`Resource1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | - |
| `Name` | `string` | Optional | - |
| `LocationId` | `int?` | Optional | - |
| `IsActive` | `bool?` | Optional | - |
| `ScheduleTypes` | [`List<ScheduleType4Enum>`](../../doc/models/schedule-type-4-enum.md) | Optional | - |
| `ProgramIds` | `List<int>` | Optional | - |

## Example (as JSON)

```json
{
  "Id": 168,
  "Name": "Name8",
  "LocationId": 28,
  "IsActive": false,
  "ScheduleTypes": [
    "Media",
    "Resource",
    "Appointment"
  ]
}
```

