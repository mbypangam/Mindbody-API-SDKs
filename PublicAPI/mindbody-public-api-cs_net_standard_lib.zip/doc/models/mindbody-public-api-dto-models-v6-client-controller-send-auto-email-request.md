
# Mindbody Public Api Dto Models V6 Client Controller Send Auto Email Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClientId` | `string` | Required | The ID of the client email will be sent to. |
| `EmailType` | `string` | Required | The type of the email that will be sent to a client.<br>Possible values are:<br><br>* BusinessWelcomeEmail<br>* ConsumerWelcomeEmail |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "EmailType": "EmailType8"
}
```

