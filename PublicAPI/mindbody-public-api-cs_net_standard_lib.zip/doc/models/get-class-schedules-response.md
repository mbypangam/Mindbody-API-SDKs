
# Get Class Schedules Response

## Structure

`GetClassSchedulesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `ClassSchedules` | [`List<Models.ClassSchedule>`](../../doc/models/class-schedule.md) | Optional | Contains information about the class schedules. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClassSchedules": null
}
```

