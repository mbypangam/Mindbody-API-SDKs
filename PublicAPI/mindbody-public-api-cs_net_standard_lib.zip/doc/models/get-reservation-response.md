
# Get Reservation Response

Get reservation response

## Structure

`GetReservationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Reservations` | [`List<Models.Reservation>`](../../doc/models/reservation.md) | Optional | - |
| `Pagination` | [`Models.Pagination`](../../doc/models/pagination.md) | Optional | - |
| `ResponseDetails` | [`Models.ResponseDetails`](../../doc/models/response-details.md) | Optional | - |

## Example (as JSON)

```json
{
  "Reservations": null,
  "Pagination": null,
  "ResponseDetails": null
}
```

