
# Add Arrival Response

## Structure

`AddArrivalResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ArrivalAdded` | `bool?` | Optional | When `true`, indicates that the arrival was added to the database. |
| `ClientService` | [`Models.ClientService`](../../doc/models/client-service.md) | Optional | Contains information about the pricing option being used to pay for the client’s current service session. |

## Example (as JSON)

```json
{
  "ArrivalAdded": null,
  "ClientService": null
}
```

