
# Get Client Duplicates Response

## Structure

`GetClientDuplicatesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `ClientDuplicates` | [`List<Models.MindbodyPublicApiDtoModelsV6ClientDuplicate>`](../../doc/models/mindbody-public-api-dto-models-v6-client-duplicate.md) | Optional | The requested clients. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientDuplicates": null
}
```

