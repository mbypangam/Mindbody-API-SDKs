
# Add Promo Code Response

## Structure

`AddPromoCodeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PromoCode` | [`Models.PromoCode`](../../doc/models/promo-code.md) | Optional | - |

## Example (as JSON)

```json
{
  "PromoCode": null
}
```

