
# Terminate Contract Response

## Structure

`TerminateContractResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Contract` | [`Models.ClientContract`](../../doc/models/client-contract.md) | Optional | Contains confirmation message for the successful contract termination. |

## Example (as JSON)

```json
{
  "Contract": null
}
```

