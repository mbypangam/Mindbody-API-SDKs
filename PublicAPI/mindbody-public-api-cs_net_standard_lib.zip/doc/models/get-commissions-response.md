
# Get Commissions Response

## Structure

`GetCommissionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `Commissions` | [`List<CommissionPayrollPurchaseEvent>`](../../doc/models/commission-payroll-purchase-event.md) | Optional | Contains information about commissions earned by staff for sales within the given date range. Results are ordered by `SaleId`, then by `StaffId`. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Commissions": [
    {
      "StaffId": 58,
      "SaleDateTime": "2016-03-13T12:52:32.123Z",
      "SaleId": 220,
      "SaleType": "SaleType2",
      "ProductId": 6
    },
    {
      "StaffId": 59,
      "SaleDateTime": "2016-03-13T12:52:32.123Z",
      "SaleId": 221,
      "SaleType": "SaleType3",
      "ProductId": 7
    }
  ]
}
```

