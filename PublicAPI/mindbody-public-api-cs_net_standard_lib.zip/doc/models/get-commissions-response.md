
# Get Commissions Response

## Structure

`GetCommissionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Commissions` | [`List<Models.CommissionPayrollPurchaseEvent>`](../../doc/models/commission-payroll-purchase-event.md) | Optional | Contains information about commissions earned by staff for sales within the given date range. Results are ordered by `SaleId`, then by `StaffId`. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Commissions": null
}
```

