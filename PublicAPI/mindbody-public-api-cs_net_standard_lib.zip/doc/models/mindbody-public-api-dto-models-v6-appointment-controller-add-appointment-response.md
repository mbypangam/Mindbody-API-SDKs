
# Mindbody Public Api Dto Models V6 Appointment Controller Add Appointment Response

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Appointment` | [`Models.MindbodyPublicApiDtoModelsV6Appointment`](../../doc/models/mindbody-public-api-dto-models-v6-appointment.md) | Optional | Contains information about an appointment. |

## Example (as JSON)

```json
{
  "Appointment": null
}
```

