
# Add Appointment Add on Request

Creates an add-on for an appointment

## Structure

`AddAppointmentAddOnRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ApplyPayment` | `bool?` | Optional | When `true`, indicates that a payment should be applied to the appointment. Currently only ApplyPayment=false is implemented.<br>Default: **true** |
| `AppointmentId` | `long?` | Optional | The appointment ID the add-on is getting added to. |
| `SessionTypeId` | `int?` | Optional | The session type associated with the new appointment add-on. |
| `StaffId` | `long?` | Optional | The ID of the staff member who is adding the new appointment add-on.<br>Default: staff member performing the appointment. |
| `Test` | `bool?` | Optional | When `true`, indicates that the method is to be validated, but no new appointment add-on data is added.<br>Default: **false** |

## Example (as JSON)

```json
{
  "ApplyPayment": false,
  "AppointmentId": 22,
  "SessionTypeId": 50,
  "StaffId": 156,
  "Test": false
}
```

