
# Mindbody Public Api Dto Models V6 Sale Controller Get Services Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetServicesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `Services` | [`List<Models.MindbodyPublicApiDtoModelsV6Service>`](../../doc/models/mindbody-public-api-dto-models-v6-service.md) | Optional | Contains information about the services. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Services": null
}
```

