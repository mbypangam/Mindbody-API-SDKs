
# Get Time Cards Response

## Structure

`GetTimeCardsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `TimeCards` | [`List<Models.TimeCardEvent>`](../../doc/models/time-card-event.md) | Optional | Information about time card entries, ordered by staff ID. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "TimeCards": null
}
```

