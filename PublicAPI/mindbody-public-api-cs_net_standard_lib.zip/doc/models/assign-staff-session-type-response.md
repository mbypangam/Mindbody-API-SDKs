
# Assign Staff Session Type Response

## Structure

`AssignStaffSessionTypeResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StaffId` | `long?` | Optional | Staff member assigned to the session type |
| `SessionTypeId` | `int?` | Optional | The session type the staff member is assigned to |
| `PayRateType` | `string` | Optional | The pay rate type name<br>Can be: "Flat", "Percent", or "No Pay" |
| `PayRateAmount` | `double?` | Optional | The pay rate amount. It is interpreted based on the value of PayRateTypeId |
| `TimeLength` | `int?` | Optional | The staff specific amount of time that a session of this type typically lasts. |
| `PrepTime` | `int?` | Optional | Prep time in minutes |
| `FinishTime` | `int?` | Optional | Finish time in minutes |
| `Active` | `bool?` | Optional | Whether this association is active |

## Example (as JSON)

```json
{
  "StaffId": null,
  "SessionTypeId": null,
  "PayRateType": null,
  "PayRateAmount": null,
  "TimeLength": null,
  "PrepTime": null,
  "FinishTime": null,
  "Active": null
}
```

