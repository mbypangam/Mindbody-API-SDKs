
# Unavailability 1

## Structure

`Unavailability1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | Unavailabiltity ID. |
| `StartDateTime` | `DateTime?` | Optional | Start of the unavailability. |
| `EndDateTime` | `DateTime?` | Optional | End of the unavailability. |
| `Description` | `string` | Optional | Description of the unavailability. |

## Example (as JSON)

```json
{
  "Id": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Description": null
}
```

