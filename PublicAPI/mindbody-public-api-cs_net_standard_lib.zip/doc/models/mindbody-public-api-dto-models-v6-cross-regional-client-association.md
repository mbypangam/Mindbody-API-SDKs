
# Mindbody Public Api Dto Models V6 Cross Regional Client Association

A client cross region association

## Structure

`MindbodyPublicApiDtoModelsV6CrossRegionalClientAssociation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SiteId` | `int?` | Optional | The ID of the site to which the client belongs. |
| `ClientId` | `string` | Optional | The client’s RSSID. |
| `UniqueId` | `long?` | Optional | The client’s unique ID. |

## Example (as JSON)

```json
{
  "SiteId": null,
  "ClientId": null,
  "UniqueId": null
}
```

