
# Mindbody Public Api Common Models Staff

## Structure

`MindbodyPublicApiCommonModelsStaff`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | The ID assigned to the staff member. |
| `FirstName` | `string` | Optional | The staff member?s first name. |
| `LastName` | `string` | Optional | The staff member?s last name. |
| `DisplayName` | `string` | Optional | The display name of the staff member. |
| `Email` | `string` | Optional | The staff member?s email address. |
| `Bio` | `string` | Optional | The staff member?s biography. This string contains HTML. |
| `Address` | `string` | Optional | The address of the staff member who is teaching the class. |
| `Address2` | `string` | Optional | The address2 of the staff member who is teaching the class. |
| `City` | `string` | Optional | The staff member?s city. |
| `State` | `string` | Optional | The staff member?s state. |
| `PostalCode` | `string` | Optional | The staff member?s postal code. |
| `ForeignZip` | `string` | Optional | The staff member?s Foreign Zip code. |
| `Country` | `string` | Optional | The staff member?s country. |
| `WorkPhone` | `string` | Optional | The staff member?s work phone number. |
| `HomePhone` | `string` | Optional | The staff member?s home phone number. |
| `CellPhone` | `string` | Optional | The staff member?s mobile phone number. |
| `Active` | `bool?` | Optional | When `true`, indicates that the staff member is Active.<br>When `false`, indicates that the staff member is not Active. |
| `IsSystem` | `bool?` | Optional | When `true`, indicates that the staff member is a system .<br>When `false`, indicates that the staff member is not system. |
| `SmodeId` | `int?` | Optional | The Staff's Smode Id |
| `AppointmentTrn` | `bool?` | Optional | When `true`, indicates that the staff member offers appointments.<br>When `false`, indicates that the staff member does not offer appointments. |
| `AlwaysAllowDoubleBooking` | `bool?` | Optional | When `true`, indicates that the staff member can be scheduled for overlapping services.<br>When `false`, indicates that the staff can only be scheduled for one service at a time in any given time-frame. |
| `IndependentContractor` | `bool?` | Optional | When `true`, indicates that the staff member is an independent contractor.<br>When `false`, indicates that the staff member is not an independent contractor. |
| `ImageUrl` | `string` | Optional | The URL of the staff member?s image, if one has been uploaded. |
| `IsMale` | `bool?` | Optional | When `true`, indicates that the staff member is male.<br>When `false`, indicates that the staff member is female. |
| `ReservationTrn` | `bool?` | Optional | When `true`, indicates that the staff member offers Reservation.<br>When `false`, indicates that the staff member does not offer Reservation. |
| `SortOrder` | `int?` | Optional | If configured by the business owner, this field determines a staff member?s weight when sorting. Use this field to sort staff members on your interface. |
| `MultiLocationPermission` | `bool?` | Optional | When `true`, indicates that the staff member has Multi Location Permission.<br>When `false`, indicates that the staff member does not has Multi Location Permission. |
| `Name` | `string` | Optional | The staff member?s name. |
| `ProviderIDs` | `List<string>` | Optional | A list of ProviderIds for the staff. |
| `StaffSettings` | [`Models.MindbodyPublicApiCommonModelsStaffSetting`](../../doc/models/mindbody-public-api-common-models-staff-setting.md) | Optional | This object contains the staff settings. |
| `Rep` | `bool?` | Optional | When `true`, indicates that the staff is sales Rep 1 else `false`. |
| `Rep2` | `bool?` | Optional | When `true`, indicates that the staff is sales Rep 2 else `false`. |
| `Rep3` | `bool?` | Optional | When `true`, indicates that the staff is sales Rep 3 else `false`. |
| `Rep4` | `bool?` | Optional | When `true`, indicates that the staff is sales Rep 4 else `false`. |
| `Rep5` | `bool?` | Optional | When `true`, indicates that the staff is sales Rep 5 else `false`. |
| `Rep6` | `bool?` | Optional | When `true`, indicates that the staff is sales Rep 6 else `false`. |
| `Assistant` | `bool?` | Optional | When `true`, indicates that the staff is assistant.<br>When `false`, indicates that the staff is not assistant. |
| `Assistant2` | `bool?` | Optional | When `true`, indicates that the staff is assistant2.<br>When `false`, indicates that the staff is not assistant2. |
| `EmploymentStart` | `DateTime?` | Optional | The start date of employment. |
| `EmploymentEnd` | `DateTime?` | Optional | The end date of employment. |
| `EmpID` | `string` | Optional | The custom staff ID assigned to the staff member. |
| `Appointments` | [`List<Models.MindbodyPublicApiCommonModelsAppointment>`](../../doc/models/mindbody-public-api-common-models-appointment.md) | Optional | A list of appointments for the staff. |
| `Unavailabilities` | [`List<Models.MindbodyPublicApiCommonModelsUnavailability>`](../../doc/models/mindbody-public-api-common-models-unavailability.md) | Optional | A list of unavailabilities for the staff. |
| `Availabilities` | [`List<Models.MindbodyPublicApiCommonModelsAvailability>`](../../doc/models/mindbody-public-api-common-models-availability.md) | Optional | A list of availabilities for the staff. |
| `LoginLocations` | [`List<Models.MindbodyPublicApiCommonModelsLocation>`](../../doc/models/mindbody-public-api-common-models-location.md) | Optional | A list of LoginLocations for the staff |

## Example (as JSON)

```json
{
  "Id": null,
  "FirstName": null,
  "LastName": null,
  "DisplayName": null,
  "Email": null,
  "Bio": null,
  "Address": null,
  "Address2": null,
  "City": null,
  "State": null,
  "PostalCode": null,
  "ForeignZip": null,
  "Country": null,
  "WorkPhone": null,
  "HomePhone": null,
  "CellPhone": null,
  "Active": null,
  "IsSystem": null,
  "SmodeId": null,
  "AppointmentTrn": null,
  "AlwaysAllowDoubleBooking": null,
  "IndependentContractor": null,
  "ImageUrl": null,
  "IsMale": null,
  "ReservationTrn": null,
  "SortOrder": null,
  "MultiLocationPermission": null,
  "Name": null,
  "ProviderIDs": null,
  "StaffSettings": null,
  "Rep": null,
  "Rep2": null,
  "Rep3": null,
  "Rep4": null,
  "Rep5": null,
  "Rep6": null,
  "Assistant": null,
  "Assistant2": null,
  "EmploymentStart": null,
  "EmploymentEnd": null,
  "EmpID": null,
  "Appointments": null,
  "Unavailabilities": null,
  "Availabilities": null,
  "LoginLocations": null
}
```

