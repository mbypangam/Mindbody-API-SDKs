
# Mindbody Public Api Common Models Staff

## Structure

`MindbodyPublicApiCommonModelsStaff`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `long?` | Optional | - |
| `FirstName` | `string` | Optional | - |
| `LastName` | `string` | Optional | - |
| `DisplayName` | `string` | Optional | - |
| `Email` | `string` | Optional | - |
| `Bio` | `string` | Optional | - |
| `Address` | `string` | Optional | - |
| `Address2` | `string` | Optional | - |
| `City` | `string` | Optional | - |
| `State` | `string` | Optional | - |
| `PostalCode` | `string` | Optional | - |
| `ForeignZip` | `string` | Optional | - |
| `Country` | `string` | Optional | - |
| `WorkPhone` | `string` | Optional | - |
| `HomePhone` | `string` | Optional | - |
| `CellPhone` | `string` | Optional | - |
| `Active` | `bool?` | Optional | - |
| `IsSystem` | `bool?` | Optional | - |
| `SmodeId` | `int?` | Optional | - |
| `AppointmentTrn` | `bool?` | Optional | - |
| `AlwaysAllowDoubleBooking` | `bool?` | Optional | - |
| `IndependentContractor` | `bool?` | Optional | - |
| `ImageUrl` | `string` | Optional | - |
| `IsMale` | `bool?` | Optional | - |
| `ReservationTrn` | `bool?` | Optional | - |
| `SortOrder` | `int?` | Optional | - |
| `MultiLocationPermission` | `bool?` | Optional | - |
| `Name` | `string` | Optional | - |
| `ProviderIDs` | `List<string>` | Optional | - |
| `StaffSettings` | [`Models.MindbodyPublicApiCommonModelsStaffSetting`](../../doc/models/mindbody-public-api-common-models-staff-setting.md) | Optional | - |
| `Rep` | `bool?` | Optional | - |
| `Rep2` | `bool?` | Optional | - |
| `Rep3` | `bool?` | Optional | - |
| `Rep4` | `bool?` | Optional | - |
| `Rep5` | `bool?` | Optional | - |
| `Rep6` | `bool?` | Optional | - |
| `Assistant` | `bool?` | Optional | - |
| `Assistant2` | `bool?` | Optional | - |
| `EmploymentStart` | `DateTime?` | Optional | - |
| `EmploymentEnd` | `DateTime?` | Optional | - |
| `EmpID` | `string` | Optional | - |
| `Appointments` | [`List<Models.MindbodyPublicApiCommonModelsAppointment>`](../../doc/models/mindbody-public-api-common-models-appointment.md) | Optional | List of appointments for the staff. |
| `Unavailabilities` | [`List<Models.MindbodyPublicApiCommonModelsUnavailability>`](../../doc/models/mindbody-public-api-common-models-unavailability.md) | Optional | List of unavailabilities for the staff. |
| `Availabilities` | [`List<Models.MindbodyPublicApiCommonModelsAvailability>`](../../doc/models/mindbody-public-api-common-models-availability.md) | Optional | List of availabilities for the staff. |
| `LoginLocations` | [`List<Models.MindbodyPublicApiCommonModelsLocation>`](../../doc/models/mindbody-public-api-common-models-location.md) | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "FirstName": null,
  "LastName": null,
  "DisplayName": null,
  "Email": null,
  "Bio": null,
  "Address": null,
  "Address2": null,
  "City": null,
  "State": null,
  "PostalCode": null,
  "ForeignZip": null,
  "Country": null,
  "WorkPhone": null,
  "HomePhone": null,
  "CellPhone": null,
  "Active": null,
  "IsSystem": null,
  "SmodeId": null,
  "AppointmentTrn": null,
  "AlwaysAllowDoubleBooking": null,
  "IndependentContractor": null,
  "ImageUrl": null,
  "IsMale": null,
  "ReservationTrn": null,
  "SortOrder": null,
  "MultiLocationPermission": null,
  "Name": null,
  "ProviderIDs": null,
  "StaffSettings": null,
  "Rep": null,
  "Rep2": null,
  "Rep3": null,
  "Rep4": null,
  "Rep5": null,
  "Rep6": null,
  "Assistant": null,
  "Assistant2": null,
  "EmploymentStart": null,
  "EmploymentEnd": null,
  "EmpID": null,
  "Appointments": null,
  "Unavailabilities": null,
  "Availabilities": null,
  "LoginLocations": null
}
```

