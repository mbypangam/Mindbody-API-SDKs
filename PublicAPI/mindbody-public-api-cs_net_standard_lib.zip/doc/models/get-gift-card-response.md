
# Get Gift Card Response

## Structure

`GetGiftCardResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `GiftCards` | [`List<Models.GiftCard>`](../../doc/models/gift-card.md) | Optional | Contains information about the gift cards. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "GiftCards": [
    {
      "Id": 62,
      "LocationIds": [
        100,
        101,
        102
      ],
      "Description": "Description8",
      "EditableByConsumer": false,
      "CardValue": 66.24
    },
    {
      "Id": 63,
      "LocationIds": [
        101
      ],
      "Description": "Description9",
      "EditableByConsumer": true,
      "CardValue": 66.25
    },
    {
      "Id": 64,
      "LocationIds": [
        102,
        103
      ],
      "Description": "Description0",
      "EditableByConsumer": false,
      "CardValue": 66.26
    }
  ]
}
```

