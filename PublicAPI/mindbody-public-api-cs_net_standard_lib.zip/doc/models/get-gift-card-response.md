
# Get Gift Card Response

## Structure

`GetGiftCardResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `GiftCards` | [`List<Models.GiftCard>`](../../doc/models/gift-card.md) | Optional | Contains information about the gift cards. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "GiftCards": null
}
```

