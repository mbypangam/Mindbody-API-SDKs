
# Mindbody Public Api Dto Models V6 Client Controller Update Client Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Client` | [`Models.MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo`](../../doc/models/mindbody-public-api-dto-models-v6-client-with-suspension-info.md) | Required | A Client DTO with Suspension Informatoin |
| `Test` | `bool?` | Optional | When `true`, indicates that test mode is enabled. The method is validated, but no client data is added or updated.<br /><br>Default: **false** |
| `CrossRegionalUpdate` | `bool?` | Optional | When `true`, the updated information is propagated to all of the region’s sites where the client has a profile.<br /><br>When `false`, only the local client is updated.<br /><br>Default: **true** |
| `NewId` | `string` | Optional | The new RSSID to be used for the client. Use `NewId` to assign a specific number to be a client’s ID. If that number is not available, the call returns an error. This RSSID must be unique within the subscriber’s site. If this is a cross-regional update, the RSSID must be unique across the region. If the requested number is already in use, an error is returned. |

## Example (as JSON)

```json
{
  "Client": {
    "SuspensionInfo": null,
    "AppointmentGenderPreference": null,
    "BirthDate": null,
    "Country": null,
    "CreationDate": null,
    "CustomClientFields": null,
    "ClientCreditCard": null,
    "ClientIndexes": null,
    "ClientRelationships": null,
    "FirstAppointmentDate": null,
    "FirstClassDate": null,
    "FirstName": null,
    "Id": null,
    "IsCompany": null,
    "IsProspect": null,
    "LastName": null,
    "Liability": null,
    "LiabilityRelease": null,
    "MembershipIcon": null,
    "MobileProvider": null,
    "Notes": null,
    "State": null,
    "UniqueId": null,
    "LastModifiedDateTime": null,
    "RedAlert": null,
    "YellowAlert": null,
    "MiddleName": null,
    "ProspectStage": null,
    "Email": null,
    "MobilePhone": null,
    "HomePhone": null,
    "WorkPhone": null,
    "AccountBalance": null,
    "AddressLine1": null,
    "AddressLine2": null,
    "City": null,
    "PostalCode": null,
    "WorkExtension": null,
    "ReferredBy": null,
    "PhotoUrl": null,
    "EmergencyContactInfoName": null,
    "EmergencyContactInfoEmail": null,
    "EmergencyContactInfoPhone": null,
    "EmergencyContactInfoRelationship": null,
    "Gender": null,
    "LastFormulaNotes": null,
    "Active": null,
    "SalesReps": null,
    "Status": null,
    "Action": null,
    "SendAccountEmails": null,
    "SendAccountTexts": null,
    "SendPromotionalEmails": null,
    "SendPromotionalTexts": null,
    "SendScheduleEmails": null,
    "SendScheduleTexts": null,
    "HomeLocation": null,
    "LockerNumber": null
  },
  "Test": null,
  "CrossRegionalUpdate": null,
  "NewId": null
}
```

