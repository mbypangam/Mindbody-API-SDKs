
# Return Sale Request

ReturnSaleRequest

## Structure

`ReturnSaleRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `SaleId` | `long?` | Optional | The Sale ID of the sale item to be returned. |
| `ReturnReason` | `string` | Optional | The reason for the return. |

## Example (as JSON)

```json
{
  "SaleId": 62,
  "ReturnReason": "ReturnReason8"
}
```

