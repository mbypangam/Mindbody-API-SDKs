
# Category

## Structure

`Category`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The category Id used for api calls. |
| `CategoryName` | `string` | Optional | Category Name |
| `Description` | `string` | Optional | Category Description |
| `Service` | `bool?` | Optional | Category service |
| `Active` | `bool?` | Optional | Check if Category is active. |
| `IsPrimary` | `bool?` | Optional | Check if Category is of primary type. |
| `IsSecondary` | `bool?` | Optional | Check if Category is of secondary type. |
| `CreatedDateTimeUTC` | `DateTime?` | Optional | Category Created DateTime UTC |
| `ModifiedDateTimeUTC` | `DateTime?` | Optional | Category Modified DateTime UTC |
| `SubCategories` | [`List<SubCategory>`](../../doc/models/sub-category.md) | Optional | Contains the SubCategory objects, each of which describes the subcategories for a category. |
| `TotalCount` | `int?` | Optional | Get total number of rows |

## Example (as JSON)

```json
{
  "Id": 30,
  "CategoryName": "CategoryName0",
  "Description": "Description8",
  "Service": false,
  "Active": false
}
```

