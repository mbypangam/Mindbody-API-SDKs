
# Get Payment Types Response

Get Payment Types Response Model

## Structure

`GetPaymentTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaymentTypes` | [`List<Models.PaymentType>`](../../doc/models/payment-type.md) | Optional | The requested payment types. |

## Example (as JSON)

```json
{
  "PaymentTypes": null
}
```

