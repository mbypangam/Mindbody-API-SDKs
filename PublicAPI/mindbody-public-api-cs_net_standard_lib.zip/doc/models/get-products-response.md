
# Get Products Response

## Structure

`GetProductsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Products` | [`List<Models.MindbodyPublicApiDtoModelsV6Product>`](../../doc/models/mindbody-public-api-dto-models-v6-product.md) | Optional | Contains information about the products. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Products": null
}
```

