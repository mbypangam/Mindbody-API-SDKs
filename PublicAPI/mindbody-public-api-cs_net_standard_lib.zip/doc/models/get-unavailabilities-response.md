
# Get Unavailabilities Response

## Structure

`GetUnavailabilitiesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Unavailabilities` | [`List<Models.UnavailabilityPlain>`](../../doc/models/unavailability-plain.md) | Optional | Contains information about unavailabilities |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Unavailabilities": null
}
```

