
# Get Unavailabilities Response

## Structure

`GetUnavailabilitiesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Unavailabilities` | [`List<Models.MindbodyPublicApiDtoModelsV6UnavailabilityPlain>`](../../doc/models/mindbody-public-api-dto-models-v6-unavailability-plain.md) | Optional | Contains information about unavailabilities |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Unavailabilities": null
}
```

