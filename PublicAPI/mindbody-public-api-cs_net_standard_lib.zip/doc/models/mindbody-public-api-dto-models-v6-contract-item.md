
# Mindbody Public Api Dto Models V6 Contract Item

## Structure

`MindbodyPublicApiDtoModelsV6ContractItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Optional | The ID of the item. |
| `Name` | `string` | Optional | The name of the item. |
| `Description` | `string` | Optional | A description of the item. |
| `Type` | `string` | Optional | The type of the item. |
| `Price` | `double?` | Optional | The price of the item. |
| `Quantity` | `int?` | Optional | The quantity of the item. |
| `OneTimeItem` | `bool?` | Optional | When `true`, indicates that the item is charged only once.<br /><br>When `false`, indicates that the item is charged multiple times. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null,
  "Type": null,
  "Price": null,
  "Quantity": null,
  "OneTimeItem": null
}
```

