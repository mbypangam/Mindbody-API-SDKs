
# Mindbody Public Api Dto Models V6 Credit Card Info

INformation about an individual credit card

## Structure

`MindbodyPublicApiDtoModelsV6CreditCardInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CreditCardNumber` | `string` | Optional | - |
| `ExpMonth` | `string` | Optional | - |
| `ExpYear` | `string` | Optional | - |
| `BillingName` | `string` | Optional | - |
| `BillingAddress` | `string` | Optional | - |
| `BillingCity` | `string` | Optional | - |
| `BillingState` | `string` | Optional | - |
| `BillingPostalCode` | `string` | Optional | - |
| `SaveInfo` | `bool?` | Optional | - |
| `CardId` | `string` | Optional | Card Id of a stored instruments card |

## Example (as JSON)

```json
{
  "CreditCardNumber": null,
  "ExpMonth": null,
  "ExpYear": null,
  "BillingName": null,
  "BillingAddress": null,
  "BillingCity": null,
  "BillingState": null,
  "BillingPostalCode": null,
  "SaveInfo": null,
  "CardId": null
}
```

