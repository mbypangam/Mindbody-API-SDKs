
# Initialize Credit Card Entry Response

## Structure

`InitializeCreditCardEntryResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `CallbackUrl` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "CallbackUrl": null
}
```

