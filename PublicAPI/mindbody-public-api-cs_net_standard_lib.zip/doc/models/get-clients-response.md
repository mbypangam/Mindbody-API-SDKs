
# Get Clients Response

## Structure

`GetClientsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination properties to use. |
| `Clients` | [`List<Models.MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo>`](../../doc/models/mindbody-public-api-dto-models-v6-client-with-suspension-info.md) | Optional | The requested clients. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Clients": null
}
```

