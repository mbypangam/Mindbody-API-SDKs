
# Get Staff Session Types Response

## Structure

`GetStaffSessionTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `StaffSessionTypes` | [`List<Models.StaffSessionType>`](../../doc/models/staff-session-type.md) | Optional | Contains information about staff member session types. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "StaffSessionTypes": [
    {
      "StaffId": 116,
      "Type": "Arrival",
      "Id": 106,
      "Name": "Name4",
      "NumDeducted": 246
    },
    {
      "StaffId": 117,
      "Type": "All",
      "Id": 107,
      "Name": "Name5",
      "NumDeducted": 247
    }
  ]
}
```

