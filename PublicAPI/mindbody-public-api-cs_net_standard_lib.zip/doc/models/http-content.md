
# Http Content

## Structure

`HttpContent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Headers` | [`List<M0CultureNeutralPublicKeyTokenB77a5c561934e089>`](../../doc/models/m0-culture-neutral-public-key-token-b77-a-5-c-561934-e-089.md) | Optional | - |

## Example (as JSON)

```json
{
  "Headers": [
    {
      "key": "key6",
      "value": [
        "value4",
        "value5"
      ]
    },
    {
      "key": "key7",
      "value": [
        "value5",
        "value6",
        "value7"
      ]
    }
  ]
}
```

