
# Http Content

## Structure

`HttpContent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Headers` | [`List<Models.M0CultureNeutralPublicKeyTokenB77a5c561934e089>`](../../doc/models/m0-culture-neutral-public-key-token-b77-a-5-c-561934-e-089.md) | Optional | - |

## Example (as JSON)

```json
{
  "Headers": null
}
```

