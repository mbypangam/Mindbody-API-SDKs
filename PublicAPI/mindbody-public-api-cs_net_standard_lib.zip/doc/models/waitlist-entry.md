
# Waitlist Entry

## Structure

`WaitlistEntry`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ClassDate` | `DateTime?` | Optional | The date of the class or enrollment. |
| `ClassId` | `long?` | Optional | The ID of the class or enrollment. |
| `ClassSchedule` | [`Models.ClassSchedule`](../../doc/models/class-schedule.md) | Optional | Contains information about the class schedule for this waiting list entry. |
| `Client` | [`Models.Client`](../../doc/models/client.md) | Optional | Contains information about the requested client who is on the waiting list. |
| `EnrollmentDateForward` | `DateTime?` | Optional | If the waiting list entry was created for an enrollment, this is the date on or after which the client can be added to the enrollment from the waitlist. |
| `Id` | `int?` | Optional | The ID of the waiting list entry. |
| `RequestDateTime` | `DateTime?` | Optional | The date and time that the request to be on the waiting list was made. |
| `VisitRefNo` | `int?` | Optional | The ID of the visit that is associated with the waiting list entry. |
| `Web` | `bool?` | Optional | If `true`, the entry on the waiting list was requested online.<br /><br>If `false`, the entry on the waiting list was requested off-line, for example in person or by phone. |

## Example (as JSON)

```json
{
  "ClassDate": null,
  "ClassId": null,
  "ClassSchedule": null,
  "Client": null,
  "EnrollmentDateForward": null,
  "Id": null,
  "RequestDateTime": null,
  "VisitRefNo": null,
  "Web": null
}
```

