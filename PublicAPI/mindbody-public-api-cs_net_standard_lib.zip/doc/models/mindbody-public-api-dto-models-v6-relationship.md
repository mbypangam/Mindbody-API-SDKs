
# Mindbody Public Api Dto Models V6 Relationship

Jim is a RelationshipName1 of John. John is a RelationshipName2 of Jim.

## Structure

`MindbodyPublicApiDtoModelsV6Relationship`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The ID of the relationship. |
| `RelationshipName1` | `string` | Optional | The name of the first relationship. |
| `RelationshipName2` | `string` | Optional | The name of the second relationship. |

## Example (as JSON)

```json
{
  "Id": null,
  "RelationshipName1": null,
  "RelationshipName2": null
}
```

