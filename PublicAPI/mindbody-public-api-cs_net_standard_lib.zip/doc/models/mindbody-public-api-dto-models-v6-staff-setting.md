
# Mindbody Public Api Dto Models V6 Staff Setting

## Structure

`MindbodyPublicApiDtoModelsV6StaffSetting`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `UseStaffNicknames` | `bool?` | Optional | - |
| `ShowStaffLastNamesOnSchedules` | `bool?` | Optional | - |

## Example (as JSON)

```json
{
  "UseStaffNicknames": null,
  "ShowStaffLastNamesOnSchedules": null
}
```

