
# Mindbody Public Api Dto Models V6 Color

A color used by products.

## Structure

`MindbodyPublicApiDtoModelsV6Color`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `int?` | Optional | The unique ID of the product color. |
| `Name` | `string` | Optional | The name of the color of product. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

