
# Time Card Event

## Structure

`TimeCardEvent`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StaffId` | `long?` | Optional | The ID of the requested staff member. |
| `Task` | `string` | Optional | The staff member’s job title. |
| `TimeIn` | `DateTime?` | Optional | The time that the staff member started the job task. |
| `TimeOut` | `DateTime?` | Optional | The time that the staff member stopped doing the job task. |
| `Hours` | `double?` | Optional | The number of hours on this time card, rounded to the nearest fourth decimal place. |
| `HourlyRate` | `double?` | Optional | The hourly rate the business pays this staff for this `Task`. |
| `Earnings` | `double?` | Optional | The total amount earned by the staff member for this time card entry. |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "Task": "Task4",
  "TimeIn": "2016-03-13T12:52:32.123Z",
  "TimeOut": "2016-03-13T12:52:32.123Z",
  "Hours": 135.24
}
```

