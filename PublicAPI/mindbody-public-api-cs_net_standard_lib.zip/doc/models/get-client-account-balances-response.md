
# Get Client Account Balances Response

## Structure

`GetClientAccountBalancesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `Clients` | [`List<Client>`](../../doc/models/client.md) | Optional | A list of clients. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Clients": [
    {
      "AppointmentGenderPreference": "Male",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country9",
      "CreationDate": "2016-03-13T12:52:32.123Z",
      "CustomClientFields": [
        {
          "Value": "Value0",
          "Id": 12,
          "DataType": "DataType6",
          "Name": "Name2"
        },
        {
          "Value": "Value1",
          "Id": 13,
          "DataType": "DataType7",
          "Name": "Name3"
        },
        {
          "Value": "Value2",
          "Id": 14,
          "DataType": "DataType8",
          "Name": "Name4"
        }
      ]
    },
    {
      "AppointmentGenderPreference": "None",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country0",
      "CreationDate": "2016-03-13T12:52:32.123Z",
      "CustomClientFields": [
        {
          "Value": "Value1",
          "Id": 13,
          "DataType": "DataType7",
          "Name": "Name3"
        }
      ]
    },
    {
      "AppointmentGenderPreference": "Female",
      "BirthDate": "2016-03-13T12:52:32.123Z",
      "Country": "Country1",
      "CreationDate": "2016-03-13T12:52:32.123Z",
      "CustomClientFields": [
        {
          "Value": "Value2",
          "Id": 14,
          "DataType": "DataType8",
          "Name": "Name4"
        },
        {
          "Value": "Value3",
          "Id": 15,
          "DataType": "DataType9",
          "Name": "Name5"
        }
      ]
    }
  ]
}
```

