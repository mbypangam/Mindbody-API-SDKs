
# Update Client Visit Response

## Structure

`UpdateClientVisitResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Visit` | [`Models.Visit`](../../doc/models/visit.md) | Optional | The updated visit. |

## Example (as JSON)

```json
{
  "Visit": null
}
```

