
# Update Client Visit Response

## Structure

`UpdateClientVisitResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Visit` | [`Models.Visit`](../../doc/models/visit.md) | Optional | Represents a specific visit to a class |

## Example (as JSON)

```json
{
  "Visit": null
}
```

