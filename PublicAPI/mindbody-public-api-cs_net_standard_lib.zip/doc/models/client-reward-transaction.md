
# Client Reward Transaction

Contains information about the transaction details.

## Structure

`ClientRewardTransaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ActionDateTime` | `DateTime?` | Optional | The date and time when the points were earned or redeemed in the site local time zone. |
| `Action` | [`Models.Action9Enum?`](../../doc/models/action-9-enum.md) | Optional | Indicates if rewards were earned or redeemed. |
| `Source` | `string` | Optional | The source of the reward transaction. |
| `SourceID` | `long?` | Optional | The unique identifier in the MINDBODY system for the **Source**. |
| `ExpirationDateTime` | `DateTime?` | Optional | The date and time when earned points expire. This is calculated based on site and client rewards settings. This date will be in the site local time zone and may be **null**. |
| `Points` | `long?` | Optional | The amount of points the client earned or redeemed. |

## Example (as JSON)

```json
{
  "ActionDateTime": "2016-03-13T12:52:32.123Z",
  "Action": "Earned",
  "Source": "Source0",
  "SourceID": 242,
  "ExpirationDateTime": "2016-03-13T12:52:32.123Z"
}
```

