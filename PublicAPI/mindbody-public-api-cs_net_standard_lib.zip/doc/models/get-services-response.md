
# Get Services Response

## Structure

`GetServicesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `Services` | [`List<Models.Service>`](../../doc/models/service.md) | Optional | Contains information about the services. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Services": null
}
```

