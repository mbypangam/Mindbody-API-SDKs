
# Get Services Response

## Structure

`GetServicesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `PaginationResponse` | [`Models.PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `Services` | [`List<Models.MindbodyPublicApiDtoModelsV6Service>`](../../doc/models/mindbody-public-api-dto-models-v6-service.md) | Optional | Contains information about the services. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Services": null
}
```

