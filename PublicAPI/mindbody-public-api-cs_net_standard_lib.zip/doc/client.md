
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `Timeout` | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |
| `APIKey` | `string` | API Key Authentication |

The API client can be initialized as follows:

```csharp
MINDBODYPublicAPI.Standard.MINDBODYPublicAPIClient client = new MINDBODYPublicAPI.Standard.MINDBODYPublicAPIClient.Builder()
    .CustomHeaderAuthenticationCredentials("API-Key")
    .Build();
```

## MINDBODY Public APIClient Class

The gateway for the SDK. This class acts as a factory for the Controllers and also holds the configuration of the SDK.

### Controllers

| Name | Description |
|  --- | --- |
| AppointmentController | Gets AppointmentController controller. |
| ClassController | Gets ClassController controller. |
| ClientController | Gets ClientController controller. |
| EnrollmentController | Gets EnrollmentController controller. |
| PayrollController | Gets PayrollController controller. |
| PickASpotvController | Gets PickASpotvController controller. |
| SaleController | Gets SaleController controller. |
| SiteController | Gets SiteController controller. |
| StaffController | Gets StaffController controller. |

### Properties

| Name | Description | Type |
|  --- | --- | --- |
| HttpClientConfiguration | Gets the configuration of the Http Client associated with this client. | [`IHttpClientConfiguration`](http-client-configuration.md) |
| Timeout | Http client timeout. | `TimeSpan` |
| Environment | Current API environment. | `Environment` |

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `GetBaseUri(Server alias = Server.Default)` | Gets the URL for a particular alias in the current environment and appends it with template parameters. | `string` |
| `ToBuilder()` | Creates an object of the MINDBODY Public APIClient using the values provided for the builder. | `Builder` |

## MINDBODY Public APIClient Builder Class

Class to build instances of MINDBODY Public APIClient.

### Methods

| Name | Description | Return Type |
|  --- | --- | --- |
| `HttpClientConfiguration(Action<`[`HttpClientConfiguration.Builder`](http-client-configuration-builder.md)`> action)` | Gets the configuration of the Http Client associated with this client. | `Builder` |
| `Timeout(TimeSpan timeout)` | Http client timeout. | `Builder` |
| `Environment(Environment environment)` | Current API environment. | `Builder` |

