// <copyright file="CustomHeaderAuthenticationManager.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Authentication
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard.Http.Request;
    using APIMatic.Core.Authentication;

    /// <summary>
    /// CustomHeaderAuthenticationManager Class.
    /// </summary>
    internal class CustomHeaderAuthenticationManager : AuthManager, ICustomHeaderAuthenticationCredentials
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomHeaderAuthenticationManager"/> class.
        /// </summary>
        /// <param name="aPIKey">API-Key.</param>
        public CustomHeaderAuthenticationManager(string aPIKey)
        {
            this.APIKey = aPIKey;
            Parameters(paramBuilder => paramBuilder
                .Header(header => header.Setup("API-Key", APIKey))
            );
        }

        /// <summary>
        /// Gets string value for aPIKey.
        /// </summary>
        public string APIKey { get; }

        /// <summary>
        /// Check if credentials match.
        /// </summary>
        /// <param name="aPIKey"> The string value for credentials.</param>
        /// <returns> True if credentials matched.</returns>
        public bool Equals(string aPIKey)
        {
            return aPIKey.Equals(this.APIKey);
        }
    }
}