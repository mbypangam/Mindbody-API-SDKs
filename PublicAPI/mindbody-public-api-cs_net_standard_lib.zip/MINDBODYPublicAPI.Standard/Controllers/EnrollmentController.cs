// <copyright file="EnrollmentController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// EnrollmentController.
    /// </summary>
    public class EnrollmentController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EnrollmentController"/> class.
        /// </summary>
        internal EnrollmentController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Returns a list of enrollments. An enrollment is a service, such as a workshop or an event, that a staff member offers to multiple students, who commit to coming to all or most of the scheduled sessions. Enrollments typically run for a limited time only.
        ///             .
        /// When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:.
        ///             .
        /// * FirstName.
        /// * LastName.
        /// * Id.
        /// * Bio.
        /// * DisplayName.
        /// * ImageUrl.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassScheduleIds">Optional parameter: A list of the requested class schedule IDs. If omitted, all class schedule IDs return..</param>
        /// <param name="requestEndDate">Optional parameter: The end of the date range. The response returns any active enrollments that occur on or before this day.<br />  Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: List of the IDs for the requested locations. If omitted, all location IDs return..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: List of the IDs for the requested programs. If omitted, all program IDs return..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: List of the IDs for the requested session types. If omitted, all session types IDs return..</param>
        /// <param name="requestStaffIds">Optional parameter: List of the IDs for the requested staff IDs. If omitted, all staff IDs return..</param>
        /// <param name="requestStartDate">Optional parameter: The start of the date range. The response returns any active enrollments that occur on or after this day.<br />  Default: **today’s date**.</param>
        /// <returns>Returns the Models.GetEnrollmentsResponse response from the API call.</returns>
        public Models.GetEnrollmentsResponse GetEnrollments(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestClassScheduleIds = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                List<int> requestSessionTypeIds = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(GetEnrollmentsAsync(version, siteId, authorization, requestClassScheduleIds, requestEndDate, requestLimit, requestLocationIds, requestOffset, requestProgramIds, requestSessionTypeIds, requestStaffIds, requestStartDate));

        /// <summary>
        /// Returns a list of enrollments. An enrollment is a service, such as a workshop or an event, that a staff member offers to multiple students, who commit to coming to all or most of the scheduled sessions. Enrollments typically run for a limited time only.
        ///             .
        /// When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:.
        ///             .
        /// * FirstName.
        /// * LastName.
        /// * Id.
        /// * Bio.
        /// * DisplayName.
        /// * ImageUrl.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassScheduleIds">Optional parameter: A list of the requested class schedule IDs. If omitted, all class schedule IDs return..</param>
        /// <param name="requestEndDate">Optional parameter: The end of the date range. The response returns any active enrollments that occur on or before this day.<br />  Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: List of the IDs for the requested locations. If omitted, all location IDs return..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: List of the IDs for the requested programs. If omitted, all program IDs return..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: List of the IDs for the requested session types. If omitted, all session types IDs return..</param>
        /// <param name="requestStaffIds">Optional parameter: List of the IDs for the requested staff IDs. If omitted, all staff IDs return..</param>
        /// <param name="requestStartDate">Optional parameter: The start of the date range. The response returns any active enrollments that occur on or after this day.<br />  Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetEnrollmentsResponse response from the API call.</returns>
        public async Task<Models.GetEnrollmentsResponse> GetEnrollmentsAsync(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestClassScheduleIds = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                List<int> requestSessionTypeIds = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetEnrollmentsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/enrollment/enrollments")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.classScheduleIds", requestClassScheduleIds))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationIds", requestLocationIds))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.programIds", requestProgramIds))
                      .Query(_query => _query.Setup("request.sessionTypeIds", requestSessionTypeIds))
                      .Query(_query => _query.Setup("request.staffIds", requestStaffIds))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Book a client into an enrollment.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.ClassSchedule response from the API call.</returns>
        public Models.ClassSchedule AddClientToEnrollment(
                string version,
                Models.AddClientToEnrollmentRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddClientToEnrollmentAsync(version, request, siteId, authorization));

        /// <summary>
        /// Book a client into an enrollment.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ClassSchedule response from the API call.</returns>
        public async Task<Models.ClassSchedule> AddClientToEnrollmentAsync(
                string version,
                Models.AddClientToEnrollmentRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ClassSchedule>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/enrollment/addclienttoenrollment")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint adds a enrollment schedule. You can require clients to sign up for the entire enrollment schedule or allow them to pick specific sessions using the AllowOpenEnrollment parameter.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.WrittenClassSchedulesInfo response from the API call.</returns>
        public Models.WrittenClassSchedulesInfo AddEnrollmentSchedule(
                string version,
                Models.AddClassEnrollmentScheduleRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddEnrollmentScheduleAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint adds a enrollment schedule. You can require clients to sign up for the entire enrollment schedule or allow them to pick specific sessions using the AllowOpenEnrollment parameter.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.WrittenClassSchedulesInfo response from the API call.</returns>
        public async Task<Models.WrittenClassSchedulesInfo> AddEnrollmentScheduleAsync(
                string version,
                Models.AddClassEnrollmentScheduleRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.WrittenClassSchedulesInfo>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/enrollment/addenrollmentschedule")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint update a enrollment schedule.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.WrittenClassSchedulesInfo response from the API call.</returns>
        public Models.WrittenClassSchedulesInfo UpdateEnrollmentSchedule(
                string version,
                Models.UpdateClassEnrollmentScheduleRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateEnrollmentScheduleAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint update a enrollment schedule.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.WrittenClassSchedulesInfo response from the API call.</returns>
        public async Task<Models.WrittenClassSchedulesInfo> UpdateEnrollmentScheduleAsync(
                string version,
                Models.UpdateClassEnrollmentScheduleRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.WrittenClassSchedulesInfo>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/enrollment/updateenrollmentschedule")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}