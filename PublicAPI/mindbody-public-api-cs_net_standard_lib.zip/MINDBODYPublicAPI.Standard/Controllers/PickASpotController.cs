// <copyright file="PickASpotController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// PickASpotController.
    /// </summary>
    public class PickASpotController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PickASpotController"/> class.
        /// </summary>
        internal PickASpotController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// A user token is required for this endpoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object PickASpotClassList(
                string version,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PickASpotClassListAsync(version, siteId, authorization));

        /// <summary>
        /// A user token is required for this endpoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> PickASpotClassListAsync(
                string version,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/pickaspot/v1/class")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// A user token is required for this endpoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="classId">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object PickASpotClass(
                string version,
                string classId,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PickASpotClassAsync(version, classId, siteId, authorization));

        /// <summary>
        /// A user token is required for this endpoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="classId">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> PickASpotClassAsync(
                string version,
                string classId,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/pickaspot/v1/class/{classId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("classId", classId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// A user token is required for this endpoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object PickASpotReservationGet(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PickASpotReservationGetAsync(version, pathInfo, siteId, authorization));

        /// <summary>
        /// A user token is required for this endpoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> PickASpotReservationGetAsync(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/pickaspot/v1/reservation/{pathInfo}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("pathInfo", pathInfo))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// A user token is required for this endpoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object ToUpdateAClass(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(ToUpdateAClassAsync(version, pathInfo, siteId, authorization));

        /// <summary>
        /// A user token is required for this endpoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> ToUpdateAClassAsync(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/public/v{version}/pickaspot/v1/reservation/{pathInfo}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("pathInfo", pathInfo))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// A user token is required for this endpoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object PickASpotReservationPost(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PickASpotReservationPostAsync(version, pathInfo, siteId, authorization));

        /// <summary>
        /// A user token is required for this endpoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> PickASpotReservationPostAsync(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/pickaspot/v1/reservation/{pathInfo}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("pathInfo", pathInfo))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// A user token is required for this endpoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object PickASpotReservationDelete(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PickASpotReservationDeleteAsync(version, pathInfo, siteId, authorization));

        /// <summary>
        /// A user token is required for this endpoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> PickASpotReservationDeleteAsync(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/public/v{version}/pickaspot/v1/reservation/{pathInfo}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("pathInfo", pathInfo))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);
    }
}