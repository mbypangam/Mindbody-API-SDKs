// <copyright file="PickASpotController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// PickASpotController.
    /// </summary>
    public class PickASpotController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PickASpotController"/> class.
        /// </summary>
        internal PickASpotController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// This endpoint supports pagination. See Pagination object for a description.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.GetPickASpotClassResponse response from the API call.</returns>
        public Models.GetPickASpotClassResponse GetClassList(
                string version,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(GetClassListAsync(version, siteId, authorization));

        /// <summary>
        /// This endpoint supports pagination. See Pagination object for a description.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetPickASpotClassResponse response from the API call.</returns>
        public async Task<Models.GetPickASpotClassResponse> GetClassListAsync(
                string version,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetPickASpotClassResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/pickaspot/v1/class")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetPickASpotClassResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get a class filtered by classId.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="classId">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.GetPickASpotClassResponse response from the API call.</returns>
        public Models.GetPickASpotClassResponse GetClass(
                string version,
                string classId,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(GetClassAsync(version, classId, siteId, authorization));

        /// <summary>
        /// Get a class filtered by classId.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="classId">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetPickASpotClassResponse response from the API call.</returns>
        public async Task<Models.GetPickASpotClassResponse> GetClassAsync(
                string version,
                string classId,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetPickASpotClassResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/pickaspot/v1/class/{classId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("classId", classId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetPickASpotClassResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Retrieves reservation for Pick a Spot.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.GetReservationResponse response from the API call.</returns>
        public Models.GetReservationResponse GetReservation(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(GetReservationAsync(version, pathInfo, siteId, authorization));

        /// <summary>
        /// Retrieves reservation for Pick a Spot.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetReservationResponse response from the API call.</returns>
        public async Task<Models.GetReservationResponse> GetReservationAsync(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetReservationResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/pickaspot/v1/reservation/{pathInfo}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("pathInfo", pathInfo))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetReservationResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// A user token is required for this endpoint.
        /// This endpoint updates a single reservation.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.UpdateReservationResponse response from the API call.</returns>
        public Models.UpdateReservationResponse UpdateReservation(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateReservationAsync(version, pathInfo, siteId, authorization));

        /// <summary>
        /// A user token is required for this endpoint.
        /// This endpoint updates a single reservation.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UpdateReservationResponse response from the API call.</returns>
        public async Task<Models.UpdateReservationResponse> UpdateReservationAsync(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.UpdateReservationResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/public/v{version}/pickaspot/v1/reservation/{pathInfo}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("pathInfo", pathInfo))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.UpdateReservationResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Creates a spot reservation for a given pick-a-spot class. The actual class visit must be created prior to calling this endpoint.
        /// A user token is required for this endpoint.
        ///             .
        /// Sample request:.
        ///             .
        ///     POST /pickaspot/v1/reservation.
        ///     {.
        ///         "SiteId": -1147483363,.
        ///         "LocationId": 1,.
        ///         "ClassId": "64b14ac8c20ae8f0afd2d409",.
        ///         "ReservationExternalId": "44724", // this is a Visit.Id and should be linked to a specific class visit.
        ///         "MemberExternalId": "100000136", // this is Client's UniqueId.
        ///         "SpotNumber": "5",.
        ///         "ReservationDisplayName": "ReservationDisplayName", // optional.
        ///         "ReservationType": "Member" // optional. Can be Member, Guest, Instructor, FamilyMember.
        ///     }.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.CreateReservationResponse response from the API call.</returns>
        public Models.CreateReservationResponse CreateReservation(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(CreateReservationAsync(version, pathInfo, siteId, authorization));

        /// <summary>
        /// Creates a spot reservation for a given pick-a-spot class. The actual class visit must be created prior to calling this endpoint.
        /// A user token is required for this endpoint.
        ///             .
        /// Sample request:.
        ///             .
        ///     POST /pickaspot/v1/reservation.
        ///     {.
        ///         "SiteId": -1147483363,.
        ///         "LocationId": 1,.
        ///         "ClassId": "64b14ac8c20ae8f0afd2d409",.
        ///         "ReservationExternalId": "44724", // this is a Visit.Id and should be linked to a specific class visit.
        ///         "MemberExternalId": "100000136", // this is Client's UniqueId.
        ///         "SpotNumber": "5",.
        ///         "ReservationDisplayName": "ReservationDisplayName", // optional.
        ///         "ReservationType": "Member" // optional. Can be Member, Guest, Instructor, FamilyMember.
        ///     }.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CreateReservationResponse response from the API call.</returns>
        public async Task<Models.CreateReservationResponse> CreateReservationAsync(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CreateReservationResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/pickaspot/v1/reservation/{pathInfo}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("pathInfo", pathInfo))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.CreateReservationResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// A user token is required for this endpoint.
        /// This endpoint deletes a single reservation.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.HttpContent response from the API call.</returns>
        public Models.HttpContent DeleteReservation(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(DeleteReservationAsync(version, pathInfo, siteId, authorization));

        /// <summary>
        /// A user token is required for this endpoint.
        /// This endpoint deletes a single reservation.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.HttpContent response from the API call.</returns>
        public async Task<Models.HttpContent> DeleteReservationAsync(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.HttpContent>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/public/v{version}/pickaspot/v1/reservation/{pathInfo}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("pathInfo", pathInfo))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.HttpContent>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}