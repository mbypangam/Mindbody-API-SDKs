// <copyright file="UserTokenController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using APIMatic.Core;
using APIMatic.Core.Types;
using APIMatic.Core.Utilities;
using APIMatic.Core.Utilities.Date.Xml;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Http.Client;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json.Converters;
using System.Net.Http;

namespace MINDBODYPublicAPI.Standard.Controllers
{
    /// <summary>
    /// UserTokenController.
    /// </summary>
    public class UserTokenController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserTokenController"/> class.
        /// </summary>
        internal UserTokenController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// When users interact with your Public API integration as staff members, they need to get a staff user token for authentication.
        /// You can use the issue endpoint to get a staff user token, then pass the token in the headers for all of your requests.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <returns>Returns the Models.IssueResponse response from the API call.</returns>
        public Models.IssueResponse IssueToken(
                string version,
                Models.IssueRequest request,
                string siteId)
            => CoreHelper.RunTask(IssueTokenAsync(version, request, siteId));

        /// <summary>
        /// When users interact with your Public API integration as staff members, they need to get a staff user token for authentication.
        /// You can use the issue endpoint to get a staff user token, then pass the token in the headers for all of your requests.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.IssueResponse response from the API call.</returns>
        public async Task<Models.IssueResponse> IssueTokenAsync(
                string version,
                Models.IssueRequest request,
                string siteId,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.IssueResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/usertoken/issue")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Renews a token. Can be used to extend the lifetime of a token.
        /// Current lifetime expansion: 24hrs from current expiration, up to 7 renewals.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object RenewToken(
                string version,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(RenewTokenAsync(version, siteId, authorization));

        /// <summary>
        /// Renews a token. Can be used to extend the lifetime of a token.
        /// Current lifetime expansion: 24hrs from current expiration, up to 7 renewals.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> RenewTokenAsync(
                string version,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/usertoken/renew")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Revokes the user token in the Authorization header.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object RevokeToken(
                string version,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(RevokeTokenAsync(version, siteId, authorization));

        /// <summary>
        /// Revokes the user token in the Authorization header.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> RevokeTokenAsync(
                string version,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/public/v{version}/usertoken/revoke")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}