// <copyright file="StaffController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Http.Request;
    using MINDBODYPublicAPI.Standard.Http.Request.Configuration;
    using MINDBODYPublicAPI.Standard.Http.Response;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// StaffController.
    /// </summary>
    public class StaffController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StaffController"/> class.
        /// </summary>
        /// <param name="config"> config instance. </param>
        /// <param name="httpClient"> httpClient. </param>
        /// <param name="authManagers"> authManager. </param>
        internal StaffController(IConfiguration config, IHttpClient httpClient, IDictionary<string, IAuthManager> authManagers)
            : base(config, httpClient, authManagers)
        {
        }

        /// <summary>
        /// When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:.
        ///             .
        /// * FirstName.
        /// * LastName.
        /// * Id.
        /// * Bio.
        /// * DisplayName.
        /// * ImageUrl.
        /// * EmpID.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestFilters">Optional parameter: Filters to apply to the search. Possible values are:  * StaffViewable  * AppointmentInstructor  * ClassInstructor  * Male  * Female.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSessionTypeId">Optional parameter: Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of the requested staff IDs..</param>
        /// <param name="requestStartDateTime">Optional parameter: Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse StaffGetStaff(
                string version,
                string siteId,
                string authorization = null,
                List<string> requestFilters = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                int? requestSessionTypeId = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDateTime = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse> t = this.StaffGetStaffAsync(version, siteId, authorization, requestFilters, requestLimit, requestLocationId, requestOffset, requestSessionTypeId, requestStaffIds, requestStartDateTime);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:.
        ///             .
        /// * FirstName.
        /// * LastName.
        /// * Id.
        /// * Bio.
        /// * DisplayName.
        /// * ImageUrl.
        /// * EmpID.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestFilters">Optional parameter: Filters to apply to the search. Possible values are:  * StaffViewable  * AppointmentInstructor  * ClassInstructor  * Male  * Female.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSessionTypeId">Optional parameter: Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of the requested staff IDs..</param>
        /// <param name="requestStartDateTime">Optional parameter: Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse> StaffGetStaffAsync(
                string version,
                string siteId,
                string authorization = null,
                List<string> requestFilters = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                int? requestSessionTypeId = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDateTime = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/staff");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.filters", requestFilters },
                { "request.limit", requestLimit },
                { "request.locationId", requestLocationId },
                { "request.offset", requestOffset },
                { "request.sessionTypeId", requestSessionTypeId },
                { "request.staffIds", requestStaffIds },
                { "request.startDateTime", requestStartDateTime.HasValue ? requestStartDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse>(response.Body);
        }

        /// <summary>
        /// Get configured staff permissions for a staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestStaffId">Required parameter: The ID of the staff member whose permissions you want to return..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse StaffGetStaffPermissions(
                string version,
                long requestStaffId,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse> t = this.StaffGetStaffPermissionsAsync(version, requestStaffId, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Get configured staff permissions for a staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestStaffId">Required parameter: The ID of the staff member whose permissions you want to return..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse> StaffGetStaffPermissionsAsync(
                string version,
                long requestStaffId,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/staffpermissions");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.staffId", requestStaffId },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint can be utilized to retrieve image urls for requested staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestStaffId">Optional parameter: The ID of the staff member whose image URL details you want to retrieve..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse StaffGetStaffImageURL(
                string version,
                string siteId,
                string authorization = null,
                long? requestStaffId = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse> t = this.StaffGetStaffImageURLAsync(version, siteId, authorization, requestStaffId);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint can be utilized to retrieve image urls for requested staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestStaffId">Optional parameter: The ID of the staff member whose image URL details you want to retrieve..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse> StaffGetStaffImageURLAsync(
                string version,
                string siteId,
                string authorization = null,
                long? requestStaffId = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/imageurl");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.staffId", requestStaffId },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse>(response.Body);
        }

        /// <summary>
        /// Assigns a permission group to a staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse StaffUpdateStaffPermissions(
                string version,
                Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse> t = this.StaffUpdateStaffPermissionsAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Assigns a permission group to a staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse> StaffUpdateStaffPermissionsAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/updatestaffpermissions");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse>(response.Body);
        }

        /// <summary>
        /// Creates a new staff member record at the specified business. The `FirstName` and `LastName` parameters are always required for this request.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse StaffAddStaff(
                string version,
                Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse> t = this.StaffAddStaffAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Creates a new staff member record at the specified business. The `FirstName` and `LastName` parameters are always required for this request.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse> StaffAddStaffAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/addstaff");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse>(response.Body);
        }

        /// <summary>
        /// Updates an existing staff member record at the specified business. The ID is a required parameters for this request.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse StaffUpdateStaff(
                string version,
                Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse> t = this.StaffUpdateStaffAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Updates an existing staff member record at the specified business. The ID is a required parameters for this request.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse> StaffUpdateStaffAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/updatestaff");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse>(response.Body);
        }

        /// <summary>
        /// Enables to add staff availability or unavailability for a given staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        public void StaffAddStaffAvailability(
                string version,
                Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest request,
                string siteId,
                string authorization = null)
        {
            Task t = this.StaffAddStaffAvailabilityAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
        }

        /// <summary>
        /// Enables to add staff availability or unavailability for a given staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task StaffAddStaffAvailabilityAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/staffavailability");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);
        }

        /// <summary>
        /// Gets a list of active session types for a specific staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestStaffId">Required parameter: The ID of the staff member whose session types you want to return..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: When `true`, indicates that only the session types that can be booked online should be returned.  Default: **false**.</param>
        /// <param name="requestProgramIds">Optional parameter: Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse StaffGetStaffSessionTypes(
                string version,
                long requestStaffId,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                List<int> requestProgramIds = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse> t = this.StaffGetStaffSessionTypesAsync(version, requestStaffId, siteId, authorization, requestLimit, requestOffset, requestOnlineOnly, requestProgramIds);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Gets a list of active session types for a specific staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestStaffId">Required parameter: The ID of the staff member whose session types you want to return..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: When `true`, indicates that only the session types that can be booked online should be returned.  Default: **false**.</param>
        /// <param name="requestProgramIds">Optional parameter: Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse> StaffGetStaffSessionTypesAsync(
                string version,
                long requestStaffId,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                List<int> requestProgramIds = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/sessiontypes");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.staffId", requestStaffId },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.onlineOnly", requestOnlineOnly },
                { "request.programIds", requestProgramIds },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse>(response.Body);
        }

        /// <summary>
        /// Assigns a staff member to an appointment session type with staff specific properties such as time length and pay rate. A staff user token must be included with staff assigned the ManageStaffPayRates permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse StaffAssignStaffSessionType(
                string version,
                Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest request,
                string siteId,
                string authorization = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse> t = this.StaffAssignStaffSessionTypeAsync(version, request, siteId, authorization);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// Assigns a staff member to an appointment session type with staff specific properties such as time length and pay rate. A staff user token must be included with staff assigned the ManageStaffPayRates permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse> StaffAssignStaffSessionTypeAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/assignsessiontype");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "Content-Type", "application/json" },
                { "authorization", authorization },
            };

            // append body params.
            var bodyText = ApiHelper.JsonSerialize(request);

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().PostBody(queryBuilder.ToString(), headers, bodyText);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse>(response.Body);
        }

        /// <summary>
        /// This endpoint returns the basic details of the staffs that are marked as sales reps.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActiveOnly">Optional parameter: When `true`, will return only active reps data.  Default : **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSalesRepNumbers">Optional parameter: This is the list of the sales rep numbers for which the salesrep data will be fetched..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse StaffGetSalesReps(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActiveOnly = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSalesRepNumbers = null)
        {
            Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse> t = this.StaffGetSalesRepsAsync(version, siteId, authorization, requestActiveOnly, requestLimit, requestOffset, requestSalesRepNumbers);
            ApiHelper.RunTaskSynchronously(t);
            return t.Result;
        }

        /// <summary>
        /// This endpoint returns the basic details of the staffs that are marked as sales reps.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActiveOnly">Optional parameter: When `true`, will return only active reps data.  Default : **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSalesRepNumbers">Optional parameter: This is the list of the sales rep numbers for which the salesrep data will be fetched..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse> StaffGetSalesRepsAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActiveOnly = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSalesRepNumbers = null,
                CancellationToken cancellationToken = default)
        {
            // the base uri for api requests.
            string baseUri = this.Config.GetBaseUri();

            // prepare query string for API call.
            StringBuilder queryBuilder = new StringBuilder(baseUri);
            queryBuilder.Append("/public/v{version}/staff/salesreps");

            // process optional template parameters.
            ApiHelper.AppendUrlWithTemplateParameters(queryBuilder, new Dictionary<string, object>()
            {
                { "version", version },
            });

            // prepare specfied query parameters.
            var queryParams = new Dictionary<string, object>()
            {
                { "request.activeOnly", requestActiveOnly },
                { "request.limit", requestLimit },
                { "request.offset", requestOffset },
                { "request.salesRepNumbers", requestSalesRepNumbers },
            };

            // append request with appropriate headers and parameters
            var headers = new Dictionary<string, string>()
            {
                { "user-agent", this.UserAgent },
                { "accept", "application/json" },
                { "siteId", siteId },
                { "authorization", authorization },
            };

            // prepare the API call request to fetch the response.
            HttpRequest httpRequest = this.GetClientInstance().Get(queryBuilder.ToString(), headers, queryParameters: queryParams);

            httpRequest = await this.AuthManagers["global"].ApplyAsync(httpRequest).ConfigureAwait(false);

            // invoke request and get response.
            HttpStringResponse response = await this.GetClientInstance().ExecuteAsStringAsync(httpRequest, cancellationToken: cancellationToken).ConfigureAwait(false);
            HttpContext context = new HttpContext(httpRequest, response);

            // handle errors defined at the API level.
            this.ValidateResponse(response, context);

            return ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse>(response.Body);
        }
    }
}