// <copyright file="StaffController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// StaffController.
    /// </summary>
    public class StaffController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StaffController"/> class.
        /// </summary>
        internal StaffController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// This endpoint can be utilized to retrieve image urls for requested staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestStaffId">Optional parameter: The ID of the staff member whose image URL details you want to retrieve..</param>
        /// <returns>Returns the Models.GetStaffImageURLResponse response from the API call.</returns>
        public Models.GetStaffImageURLResponse GetStaffImageURL(
                string version,
                string siteId,
                string authorization = null,
                long? requestStaffId = null)
            => CoreHelper.RunTask(GetStaffImageURLAsync(version, siteId, authorization, requestStaffId));

        /// <summary>
        /// This endpoint can be utilized to retrieve image urls for requested staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestStaffId">Optional parameter: The ID of the staff member whose image URL details you want to retrieve..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetStaffImageURLResponse response from the API call.</returns>
        public async Task<Models.GetStaffImageURLResponse> GetStaffImageURLAsync(
                string version,
                string siteId,
                string authorization = null,
                long? requestStaffId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetStaffImageURLResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/staff/imageurl")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.staffId", requestStaffId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetStaffImageURLResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// This endpoint returns the basic details of the staffs that are marked as sales reps.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActiveOnly">Optional parameter: When `true`, will return only active reps data.  Default : **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSalesRepNumbers">Optional parameter: This is the list of the sales rep numbers for which the salesrep data will be fetched..</param>
        /// <returns>Returns the Models.GetSalesRepsResponse response from the API call.</returns>
        public Models.GetSalesRepsResponse GetSalesReps(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActiveOnly = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSalesRepNumbers = null)
            => CoreHelper.RunTask(GetSalesRepsAsync(version, siteId, authorization, requestActiveOnly, requestLimit, requestOffset, requestSalesRepNumbers));

        /// <summary>
        /// This endpoint returns the basic details of the staffs that are marked as sales reps.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActiveOnly">Optional parameter: When `true`, will return only active reps data.  Default : **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSalesRepNumbers">Optional parameter: This is the list of the sales rep numbers for which the salesrep data will be fetched..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetSalesRepsResponse response from the API call.</returns>
        public async Task<Models.GetSalesRepsResponse> GetSalesRepsAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActiveOnly = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSalesRepNumbers = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetSalesRepsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/staff/salesreps")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.activeOnly", requestActiveOnly))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.salesRepNumbers", requestSalesRepNumbers))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetSalesRepsResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Gets a list of active session types for a specific staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestStaffId">Required parameter: The ID of the staff member whose session types you want to return..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: When `true`, indicates that only the session types that can be booked online should be returned.  Default: **false**.</param>
        /// <param name="requestProgramIds">Optional parameter: Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return..</param>
        /// <returns>Returns the Models.GetStaffSessionTypesResponse response from the API call.</returns>
        public Models.GetStaffSessionTypesResponse GetStaffSessionTypes(
                string version,
                long requestStaffId,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                List<int> requestProgramIds = null)
            => CoreHelper.RunTask(GetStaffSessionTypesAsync(version, requestStaffId, siteId, authorization, requestLimit, requestOffset, requestOnlineOnly, requestProgramIds));

        /// <summary>
        /// Gets a list of active session types for a specific staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestStaffId">Required parameter: The ID of the staff member whose session types you want to return..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: When `true`, indicates that only the session types that can be booked online should be returned.  Default: **false**.</param>
        /// <param name="requestProgramIds">Optional parameter: Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetStaffSessionTypesResponse response from the API call.</returns>
        public async Task<Models.GetStaffSessionTypesResponse> GetStaffSessionTypesAsync(
                string version,
                long requestStaffId,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                List<int> requestProgramIds = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetStaffSessionTypesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/staff/sessiontypes")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.staffId", requestStaffId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.onlineOnly", requestOnlineOnly))
                      .Query(_query => _query.Setup("request.programIds", requestProgramIds))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetStaffSessionTypesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:.
        ///             .
        /// * FirstName.
        /// * LastName.
        /// * Id.
        /// * Bio.
        /// * DisplayName.
        /// * ImageUrl.
        /// * EmpID.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestFilters">Optional parameter: Filters to apply to the search. Possible values are:  * StaffViewable  * AppointmentInstructor  * ClassInstructor  * Male  * Female.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSessionTypeId">Optional parameter: Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of the requested staff IDs..</param>
        /// <param name="requestStartDateTime">Optional parameter: Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter..</param>
        /// <returns>Returns the Models.GetStaffResponse response from the API call.</returns>
        public Models.GetStaffResponse GetStaff(
                string version,
                string siteId,
                string authorization = null,
                List<string> requestFilters = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                int? requestSessionTypeId = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDateTime = null)
            => CoreHelper.RunTask(GetStaffAsync(version, siteId, authorization, requestFilters, requestLimit, requestLocationId, requestOffset, requestSessionTypeId, requestStaffIds, requestStartDateTime));

        /// <summary>
        /// When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:.
        ///             .
        /// * FirstName.
        /// * LastName.
        /// * Id.
        /// * Bio.
        /// * DisplayName.
        /// * ImageUrl.
        /// * EmpID.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestFilters">Optional parameter: Filters to apply to the search. Possible values are:  * StaffViewable  * AppointmentInstructor  * ClassInstructor  * Male  * Female.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSessionTypeId">Optional parameter: Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of the requested staff IDs..</param>
        /// <param name="requestStartDateTime">Optional parameter: Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetStaffResponse response from the API call.</returns>
        public async Task<Models.GetStaffResponse> GetStaffAsync(
                string version,
                string siteId,
                string authorization = null,
                List<string> requestFilters = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                int? requestSessionTypeId = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDateTime = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetStaffResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/staff/staff")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.filters", requestFilters))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.sessionTypeId", requestSessionTypeId))
                      .Query(_query => _query.Setup("request.staffIds", requestStaffIds))
                      .Query(_query => _query.Setup("request.startDateTime", requestStartDateTime.HasValue ? requestStartDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetStaffResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get configured staff permissions for a staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestStaffId">Required parameter: The ID of the staff member whose permissions you want to return..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.GetStaffPermissionsResponse response from the API call.</returns>
        public Models.GetStaffPermissionsResponse GetStaffPermissions(
                string version,
                long requestStaffId,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(GetStaffPermissionsAsync(version, requestStaffId, siteId, authorization));

        /// <summary>
        /// Get configured staff permissions for a staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestStaffId">Required parameter: The ID of the staff member whose permissions you want to return..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetStaffPermissionsResponse response from the API call.</returns>
        public async Task<Models.GetStaffPermissionsResponse> GetStaffPermissionsAsync(
                string version,
                long requestStaffId,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetStaffPermissionsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/staff/staffpermissions")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.staffId", requestStaffId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetStaffPermissionsResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Creates a new staff member record at the specified business. The `FirstName` and `LastName` parameters are always required for this request.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.AddStaffResponse response from the API call.</returns>
        public Models.AddStaffResponse AddStaff(
                string version,
                Models.AddStaffRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddStaffAsync(version, request, siteId, authorization));

        /// <summary>
        /// Creates a new staff member record at the specified business. The `FirstName` and `LastName` parameters are always required for this request.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.AddStaffResponse response from the API call.</returns>
        public async Task<Models.AddStaffResponse> AddStaffAsync(
                string version,
                Models.AddStaffRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.AddStaffResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/staff/addstaff")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.AddStaffResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Assigns a staff member to an appointment session type with staff specific properties such as time length and pay rate. A staff user token must be included with staff assigned the ManageStaffPayRates permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.AssignStaffSessionTypeResponse response from the API call.</returns>
        public Models.AssignStaffSessionTypeResponse AssignStaffSessionType(
                string version,
                Models.AssignStaffSessionTypeRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AssignStaffSessionTypeAsync(version, request, siteId, authorization));

        /// <summary>
        /// Assigns a staff member to an appointment session type with staff specific properties such as time length and pay rate. A staff user token must be included with staff assigned the ManageStaffPayRates permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.AssignStaffSessionTypeResponse response from the API call.</returns>
        public async Task<Models.AssignStaffSessionTypeResponse> AssignStaffSessionTypeAsync(
                string version,
                Models.AssignStaffSessionTypeRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.AssignStaffSessionTypeResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/staff/assignsessiontype")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.AssignStaffSessionTypeResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Enables to add staff availability or unavailability for a given staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        public void AddStaffAvailability(
                string version,
                Models.AddStaffAvailabilityRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunVoidTask(AddStaffAvailabilityAsync(version, request, siteId, authorization));

        /// <summary>
        /// Enables to add staff availability or unavailability for a given staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task AddStaffAvailabilityAsync(
                string version,
                Models.AddStaffAvailabilityRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/staff/staffavailability")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Updates an existing staff member record at the specified business. The ID is a required parameters for this request.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.UpdateStaffResponse response from the API call.</returns>
        public Models.UpdateStaffResponse UpdateStaff(
                string version,
                Models.UpdateStaffRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateStaffAsync(version, request, siteId, authorization));

        /// <summary>
        /// Updates an existing staff member record at the specified business. The ID is a required parameters for this request.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UpdateStaffResponse response from the API call.</returns>
        public async Task<Models.UpdateStaffResponse> UpdateStaffAsync(
                string version,
                Models.UpdateStaffRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.UpdateStaffResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/staff/updatestaff")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.UpdateStaffResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Assigns a permission group to a staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.UpdateStaffPermissionsResponse response from the API call.</returns>
        public Models.UpdateStaffPermissionsResponse UpdateStaffPermissions(
                string version,
                Models.UpdateStaffPermissionsRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateStaffPermissionsAsync(version, request, siteId, authorization));

        /// <summary>
        /// Assigns a permission group to a staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UpdateStaffPermissionsResponse response from the API call.</returns>
        public async Task<Models.UpdateStaffPermissionsResponse> UpdateStaffPermissionsAsync(
                string version,
                Models.UpdateStaffPermissionsRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.UpdateStaffPermissionsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/staff/updatestaffpermissions")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.UpdateStaffPermissionsResponse>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}