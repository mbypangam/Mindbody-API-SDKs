// <copyright file="ClientController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// ClientController.
    /// </summary>
    public class ClientController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClientController"/> class.
        /// </summary>
        internal ClientController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Please note that client memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client for whom memberships are returned..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call GET `ActiveClientMemberships` three times, as follows:  * Use GET `CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s memberships from sites 1-10  * Set `ClientAssociatedSitesOffset` to 10 to return the client’s memberships from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client’s memberships from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.GetActiveClientMembershipsResponse response from the API call.</returns>
        public Models.GetActiveClientMembershipsResponse GetActiveClientMemberships(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null)
            => CoreHelper.RunTask(GetActiveClientMembershipsAsync(version, requestClientId, siteId, authorization, requestClientAssociatedSitesOffset, requestCrossRegionalLookup, requestLimit, requestLocationId, requestOffset));

        /// <summary>
        /// Please note that client memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client for whom memberships are returned..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call GET `ActiveClientMemberships` three times, as follows:  * Use GET `CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s memberships from sites 1-10  * Set `ClientAssociatedSitesOffset` to 10 to return the client’s memberships from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client’s memberships from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetActiveClientMembershipsResponse response from the API call.</returns>
        public async Task<Models.GetActiveClientMembershipsResponse> GetActiveClientMembershipsAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetActiveClientMembershipsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/activeclientmemberships")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset))
                      .Query(_query => _query.Setup("request.crossRegionalLookup", requestCrossRegionalLookup))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// The endpoint returns a list of memberships for multiple clients we pass in query parameter. Please note that clients memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientIds">Required parameter: The ID of the client for whom memberships are returned. Maximum allowed : 200..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.GetActiveClientsMembershipsResponse response from the API call.</returns>
        public Models.GetActiveClientsMembershipsResponse GetActiveClientsMemberships(
                string version,
                List<string> requestClientIds,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null)
            => CoreHelper.RunTask(GetActiveClientsMembershipsAsync(version, requestClientIds, siteId, authorization, requestClientAssociatedSitesOffset, requestCrossRegionalLookup, requestLimit, requestLocationId, requestOffset));

        /// <summary>
        /// The endpoint returns a list of memberships for multiple clients we pass in query parameter. Please note that clients memberships with location restrictions can only be used to pay for scheduled services at the site to which they belong. Memberships with location restrictions can not be used to pay for scheduled services at other sites within an organization.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientIds">Required parameter: The ID of the client for whom memberships are returned. Maximum allowed : 200..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a client’s memberships from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to memberships that can be used to pay for scheduled services at that location. This parameter can not be passed when `CrossRegionalLookup` is `true`..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetActiveClientsMembershipsResponse response from the API call.</returns>
        public async Task<Models.GetActiveClientsMembershipsResponse> GetActiveClientsMembershipsAsync(
                string version,
                List<string> requestClientIds,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetActiveClientsMembershipsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/activeclientsmemberships")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.clientIds", requestClientIds))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset))
                      .Query(_query => _query.Setup("request.crossRegionalLookup", requestCrossRegionalLookup))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Get account balance information for one or more client(s).
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientIds">Required parameter: The list of clients IDs for which you want account balances..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestBalanceDate">Optional parameter: The date you want a balance relative to.   Default: **the current date**.</param>
        /// <param name="requestClassId">Optional parameter: The class ID of the event for which you want a balance..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.GetClientAccountBalancesResponse response from the API call.</returns>
        public Models.GetClientAccountBalancesResponse GetClientAccountBalances(
                string version,
                List<string> requestClientIds,
                string siteId,
                string authorization = null,
                DateTime? requestBalanceDate = null,
                int? requestClassId = null,
                int? requestLimit = null,
                int? requestOffset = null)
            => CoreHelper.RunTask(GetClientAccountBalancesAsync(version, requestClientIds, siteId, authorization, requestBalanceDate, requestClassId, requestLimit, requestOffset));

        /// <summary>
        /// Get account balance information for one or more client(s).
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientIds">Required parameter: The list of clients IDs for which you want account balances..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestBalanceDate">Optional parameter: The date you want a balance relative to.   Default: **the current date**.</param>
        /// <param name="requestClassId">Optional parameter: The class ID of the event for which you want a balance..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientAccountBalancesResponse response from the API call.</returns>
        public async Task<Models.GetClientAccountBalancesResponse> GetClientAccountBalancesAsync(
                string version,
                List<string> requestClientIds,
                string siteId,
                string authorization = null,
                DateTime? requestBalanceDate = null,
                int? requestClassId = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientAccountBalancesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clientaccountbalances")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.clientIds", requestClientIds))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.balanceDate", requestBalanceDate.HasValue ? requestBalanceDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.classId", requestClassId))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint returns complete client information along with list of purchased services, contract details, membership details and arrival programs for a specific client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: Filters results to client with these ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a clients pricing options from multiple sites within an organization.When included and set to `true`,  it searches a maximum of ten sites with which this client is associated.When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated.  You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with.   Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.   Default: **false**.</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to pricing options that are purchased on or before this date.   Default: **today’s date**..</param>
        /// <param name="requestExcludeInactiveSites">Optional parameter: Used to exclude inactive and deleted sites from the results.</param>
        /// <param name="requestRequiredClientData">Optional parameter: Used to retrieve list of purchased services, contract details, membership details and arrival programs for a specific client.   Default `ClientServices`, `ClientContracts`, `ClientMemberships` and `ClientArrivals` will be returned when `RequiredClientDatais` not set.   When `RequiredClientData` is set to `Contracts` then only `ClientContracts` will be returned in the response.   When `RequiredClientData` is set to Services then only `ClientServices` will be returned in the response.  When `RequiredClientData` is set to `Memberships` then only `ClientMemberships` will be returned in the response.   When `RequiredClientData` is set to `ArrivalPrograms` then only `ClientArrivals` will be returned in the response..</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to pricing options that are purchased on or after this date.   Default: **today’s date**..</param>
        /// <returns>Returns the Models.GetClientCompleteInfoResponse response from the API call.</returns>
        public Models.GetClientCompleteInfoResponse GetClientCompleteInfo(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                bool? requestExcludeInactiveSites = null,
                List<string> requestRequiredClientData = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(GetClientCompleteInfoAsync(version, requestClientId, siteId, authorization, requestClientAssociatedSitesOffset, requestCrossRegionalLookup, requestEndDate, requestExcludeInactiveSites, requestRequiredClientData, requestStartDate));

        /// <summary>
        /// This endpoint returns complete client information along with list of purchased services, contract details, membership details and arrival programs for a specific client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: Filters results to client with these ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a clients pricing options from multiple sites within an organization.When included and set to `true`,  it searches a maximum of ten sites with which this client is associated.When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated.  You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with.   Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.   Default: **false**.</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to pricing options that are purchased on or before this date.   Default: **today’s date**..</param>
        /// <param name="requestExcludeInactiveSites">Optional parameter: Used to exclude inactive and deleted sites from the results.</param>
        /// <param name="requestRequiredClientData">Optional parameter: Used to retrieve list of purchased services, contract details, membership details and arrival programs for a specific client.   Default `ClientServices`, `ClientContracts`, `ClientMemberships` and `ClientArrivals` will be returned when `RequiredClientDatais` not set.   When `RequiredClientData` is set to `Contracts` then only `ClientContracts` will be returned in the response.   When `RequiredClientData` is set to Services then only `ClientServices` will be returned in the response.  When `RequiredClientData` is set to `Memberships` then only `ClientMemberships` will be returned in the response.   When `RequiredClientData` is set to `ArrivalPrograms` then only `ClientArrivals` will be returned in the response..</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to pricing options that are purchased on or after this date.   Default: **today’s date**..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientCompleteInfoResponse response from the API call.</returns>
        public async Task<Models.GetClientCompleteInfoResponse> GetClientCompleteInfoAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                bool? requestExcludeInactiveSites = null,
                List<string> requestRequiredClientData = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientCompleteInfoResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clientcompleteinfo")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset))
                      .Query(_query => _query.Setup("request.crossRegionalLookup", requestCrossRegionalLookup))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.excludeInactiveSites", requestExcludeInactiveSites))
                      .Query(_query => _query.Setup("request.requiredClientData", requestRequiredClientData))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Get contracts that a client has purchased.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client (RssId)..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Determines how many sites are skipped over when retrieving a client’s cross regional contracts. Used when a client ID is linked to more than ten sites in an organization. Only a maximum of ten site databases are queried when this call is made and `CrossRegionalLookup` is set to `true`. To change which sites are queried, change this offset value.  Default: **0**.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: When `true`, indicates that the requesting client’s cross regional contracts are returned, if any.<br />  When `false`, indicates that cross regional contracts are not returned..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.GetClientContractsResponse response from the API call.</returns>
        public Models.GetClientContractsResponse GetClientContracts(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                int? requestLimit = null,
                int? requestOffset = null)
            => CoreHelper.RunTask(GetClientContractsAsync(version, requestClientId, siteId, authorization, requestClientAssociatedSitesOffset, requestCrossRegionalLookup, requestLimit, requestOffset));

        /// <summary>
        /// Get contracts that a client has purchased.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client (RssId)..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Determines how many sites are skipped over when retrieving a client’s cross regional contracts. Used when a client ID is linked to more than ten sites in an organization. Only a maximum of ten site databases are queried when this call is made and `CrossRegionalLookup` is set to `true`. To change which sites are queried, change this offset value.  Default: **0**.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: When `true`, indicates that the requesting client’s cross regional contracts are returned, if any.<br />  When `false`, indicates that cross regional contracts are not returned..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientContractsResponse response from the API call.</returns>
        public async Task<Models.GetClientContractsResponse> GetClientContractsAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientContractsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clientcontracts")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset))
                      .Query(_query => _query.Setup("request.crossRegionalLookup", requestCrossRegionalLookup))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint returns direct debit info stored on a client's account. This endpoint requires staff user credentials.
        ///             .
        /// A null response from this endpoint indicates that the client has no usable direct debit information on their account.Use the POST AddClientDirectDebitInfo endpoint to add direct debit information to a client’s account.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="clientId">Optional parameter: The ID of the client..</param>
        /// <returns>Returns the Models.DirectDebitInfo response from the API call.</returns>
        public Models.DirectDebitInfo GetDirectDebitInfo(
                string version,
                string siteId,
                string authorization = null,
                string clientId = null)
            => CoreHelper.RunTask(GetDirectDebitInfoAsync(version, siteId, authorization, clientId));

        /// <summary>
        /// This endpoint returns direct debit info stored on a client's account. This endpoint requires staff user credentials.
        ///             .
        /// A null response from this endpoint indicates that the client has no usable direct debit information on their account.Use the POST AddClientDirectDebitInfo endpoint to add direct debit information to a client’s account.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="clientId">Optional parameter: The ID of the client..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.DirectDebitInfo response from the API call.</returns>
        public async Task<Models.DirectDebitInfo> GetDirectDebitInfoAsync(
                string version,
                string siteId,
                string authorization = null,
                string clientId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.DirectDebitInfo>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clientdirectdebitinfo")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("clientId", clientId))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint deletes direct debit info from a client’s account. This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="clientId">Optional parameter: The ID of the client..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object DeleteDirectDebitInfo(
                string version,
                string siteId,
                string authorization = null,
                string clientId = null)
            => CoreHelper.RunTask(DeleteDirectDebitInfoAsync(version, siteId, authorization, clientId));

        /// <summary>
        /// This endpoint deletes direct debit info from a client’s account. This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="clientId">Optional parameter: The ID of the client..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> DeleteDirectDebitInfoAsync(
                string version,
                string siteId,
                string authorization = null,
                string clientId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/public/v{version}/client/clientdirectdebitinfo")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("clientId", clientId))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint gets client records that would be considered duplicates based on case-insensitive matching of the client’s first name, last name, and email. For there to be results, all three parameters must match a client record. This endpoint requires staff user credentials.
        ///             .
        /// An empty `ClientDuplicates` object in the response from this endpoint indicates that there were no client records found that match the first name, last name, and email fields passed in.
        ///             .
        /// If one client record is returned, it is not a duplicate itself, but no other client record can be created or updated that would match this client’s first name, last name, and email combination.
        ///             .
        /// If more than one client record is returned, these clients are duplicates of each other.We recommend discussing with the business how they would like to resolve duplicate records in the event the response contains more than one client record.Businesses can use the Merge Duplicate Clients tool in the Core Business Mode software to resolve the duplicate client records.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEmail">Optional parameter: The client email to match on when searching for duplicates..</param>
        /// <param name="requestFirstName">Optional parameter: The client first name to match on when searching for duplicates..</param>
        /// <param name="requestLastName">Optional parameter: The client last name to match on when searching for duplicates..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.GetClientDuplicatesResponse response from the API call.</returns>
        public Models.GetClientDuplicatesResponse GetClientDuplicates(
                string version,
                string siteId,
                string authorization = null,
                string requestEmail = null,
                string requestFirstName = null,
                string requestLastName = null,
                int? requestLimit = null,
                int? requestOffset = null)
            => CoreHelper.RunTask(GetClientDuplicatesAsync(version, siteId, authorization, requestEmail, requestFirstName, requestLastName, requestLimit, requestOffset));

        /// <summary>
        /// This endpoint gets client records that would be considered duplicates based on case-insensitive matching of the client’s first name, last name, and email. For there to be results, all three parameters must match a client record. This endpoint requires staff user credentials.
        ///             .
        /// An empty `ClientDuplicates` object in the response from this endpoint indicates that there were no client records found that match the first name, last name, and email fields passed in.
        ///             .
        /// If one client record is returned, it is not a duplicate itself, but no other client record can be created or updated that would match this client’s first name, last name, and email combination.
        ///             .
        /// If more than one client record is returned, these clients are duplicates of each other.We recommend discussing with the business how they would like to resolve duplicate records in the event the response contains more than one client record.Businesses can use the Merge Duplicate Clients tool in the Core Business Mode software to resolve the duplicate client records.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEmail">Optional parameter: The client email to match on when searching for duplicates..</param>
        /// <param name="requestFirstName">Optional parameter: The client first name to match on when searching for duplicates..</param>
        /// <param name="requestLastName">Optional parameter: The client last name to match on when searching for duplicates..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientDuplicatesResponse response from the API call.</returns>
        public async Task<Models.GetClientDuplicatesResponse> GetClientDuplicatesAsync(
                string version,
                string siteId,
                string authorization = null,
                string requestEmail = null,
                string requestFirstName = null,
                string requestLastName = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientDuplicatesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clientduplicates")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.email", requestEmail))
                      .Query(_query => _query.Setup("request.firstName", requestFirstName))
                      .Query(_query => _query.Setup("request.lastName", requestLastName))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// ***QueryParams***: Enables to retrieve cross regional formula notes for a client, or for a specific appointment. The two parameters are optional, however at least one must be provided. This endpoint supports pagination.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentId">Optional parameter: The appointment ID of an appointment in the studio specified in the header of the request..</param>
        /// <param name="requestClientId">Optional parameter: The client ID of the client whose formula notes are being requested..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.GetClientFormulaNotesResponse response from the API call.</returns>
        public Models.GetClientFormulaNotesResponse GetClientFormulaNotes(
                string version,
                string siteId,
                string authorization = null,
                long? requestAppointmentId = null,
                string requestClientId = null,
                int? requestLimit = null,
                int? requestOffset = null)
            => CoreHelper.RunTask(GetClientFormulaNotesAsync(version, siteId, authorization, requestAppointmentId, requestClientId, requestLimit, requestOffset));

        /// <summary>
        /// ***QueryParams***: Enables to retrieve cross regional formula notes for a client, or for a specific appointment. The two parameters are optional, however at least one must be provided. This endpoint supports pagination.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentId">Optional parameter: The appointment ID of an appointment in the studio specified in the header of the request..</param>
        /// <param name="requestClientId">Optional parameter: The client ID of the client whose formula notes are being requested..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientFormulaNotesResponse response from the API call.</returns>
        public async Task<Models.GetClientFormulaNotesResponse> GetClientFormulaNotesAsync(
                string version,
                string siteId,
                string authorization = null,
                long? requestAppointmentId = null,
                string requestClientId = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientFormulaNotesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clientformulanotes")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.appointmentId", requestAppointmentId))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Client indexes are used to analyze client demographics. A business owner can set up different categories with sets of values which they can assign to each client. Client indexes are used in client searches, for tagging clients so that the owner can send mass emails to similar groups, and for many reports.
        /// For more information, see Client Indexes and [Client Index Values (video tutorial)](https://support.mindbodyonline.com/s/article/203261653-Client-indexes-and-client-index-values-video-tutorial?language=en_USclient).
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestRequiredOnly">Optional parameter: When `true`, filters the results to only indexes that are required on creation.<br />  When `false` or omitted, returns all of the client indexes..</param>
        /// <returns>Returns the Models.GetClientIndexesResponse response from the API call.</returns>
        public Models.GetClientIndexesResponse GetClientIndexes(
                string version,
                string siteId,
                string authorization = null,
                bool? requestRequiredOnly = null)
            => CoreHelper.RunTask(GetClientIndexesAsync(version, siteId, authorization, requestRequiredOnly));

        /// <summary>
        /// Client indexes are used to analyze client demographics. A business owner can set up different categories with sets of values which they can assign to each client. Client indexes are used in client searches, for tagging clients so that the owner can send mass emails to similar groups, and for many reports.
        /// For more information, see Client Indexes and [Client Index Values (video tutorial)](https://support.mindbodyonline.com/s/article/203261653-Client-indexes-and-client-index-values-video-tutorial?language=en_USclient).
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestRequiredOnly">Optional parameter: When `true`, filters the results to only indexes that are required on creation.<br />  When `false` or omitted, returns all of the client indexes..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientIndexesResponse response from the API call.</returns>
        public async Task<Models.GetClientIndexesResponse> GetClientIndexesAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestRequiredOnly = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientIndexesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clientindexes")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.requiredOnly", requestRequiredOnly))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Gets a list of purchases made by a specific client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client you are querying for purchases..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to purchases made before this timestamp.<br />  Default: **end of today**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSaleId">Optional parameter: Filters results to the single record associated with this ID..</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to purchases made on or after this timestamp.<br />  Default: **now**.</param>
        /// <returns>Returns the Models.GetClientPurchasesResponse response from the API call.</returns>
        public Models.GetClientPurchasesResponse GetClientPurchases(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestSaleId = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(GetClientPurchasesAsync(version, requestClientId, siteId, authorization, requestEndDate, requestLimit, requestOffset, requestSaleId, requestStartDate));

        /// <summary>
        /// Gets a list of purchases made by a specific client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client you are querying for purchases..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to purchases made before this timestamp.<br />  Default: **end of today**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSaleId">Optional parameter: Filters results to the single record associated with this ID..</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to purchases made on or after this timestamp.<br />  Default: **now**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientPurchasesResponse response from the API call.</returns>
        public async Task<Models.GetClientPurchasesResponse> GetClientPurchasesAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestSaleId = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientPurchasesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clientpurchases")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.saleId", requestSaleId))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Gets a list of referral types. Referral types are options that new clients can choose to identify how they learned about the business. Referral types are typically used for the sign-up process.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestIncludeInactive">Optional parameter: When `true`, filters the results to include subtypes and inactive referral types.<br />  When `false`, includes no subtypes and only active types.  Default:**false**.</param>
        /// <returns>Returns the Models.GetClientReferralTypesResponse response from the API call.</returns>
        public Models.GetClientReferralTypesResponse GetClientReferralTypes(
                string version,
                string siteId,
                string authorization = null,
                bool? requestIncludeInactive = null)
            => CoreHelper.RunTask(GetClientReferralTypesAsync(version, siteId, authorization, requestIncludeInactive));

        /// <summary>
        /// Gets a list of referral types. Referral types are options that new clients can choose to identify how they learned about the business. Referral types are typically used for the sign-up process.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestIncludeInactive">Optional parameter: When `true`, filters the results to include subtypes and inactive referral types.<br />  When `false`, includes no subtypes and only active types.  Default:**false**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientReferralTypesResponse response from the API call.</returns>
        public async Task<Models.GetClientReferralTypesResponse> GetClientReferralTypesAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestIncludeInactive = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientReferralTypesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clientreferraltypes")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.includeInactive", requestIncludeInactive))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Gets the client rewards.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of transaction.  Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of transaction.  Default: **today**.</param>
        /// <returns>Returns the Models.GetClientRewardsResponse response from the API call.</returns>
        public Models.GetClientRewardsResponse GetClientRewards(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(GetClientRewardsAsync(version, requestClientId, siteId, authorization, requestEndDate, requestLimit, requestOffset, requestStartDate));

        /// <summary>
        /// Gets the client rewards.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of transaction.  Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of transaction.  Default: **today**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientRewardsResponse response from the API call.</returns>
        public async Task<Models.GetClientRewardsResponse> GetClientRewardsAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientRewardsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clientrewards")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Earns or redeems rewards points for a given client, based on site settings. Cross regional rewards are not supported at this time.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.GetClientRewardsResponse response from the API call.</returns>
        public Models.GetClientRewardsResponse UpdateClientRewards(
                string version,
                Models.UpdateClientRewardsRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateClientRewardsAsync(version, request, siteId, authorization));

        /// <summary>
        /// Earns or redeems rewards points for a given client, based on site settings. Cross regional rewards are not supported at this time.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientRewardsResponse response from the API call.</returns>
        public async Task<Models.GetClientRewardsResponse> UpdateClientRewardsAsync(
                string version,
                Models.UpdateClientRewardsRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientRewardsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/clientrewards")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint requires staff user credentials. This endpoint supports pagination. See Pagination for a description of the Pagination information.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientIDs">Optional parameter: The requested client IDs.  Default: **all IDs** that the authenticated user’s access level allows.<br />  Note: You can fetch information for maximum 20 clients at once..</param>
        /// <param name="requestIncludeInactive">Optional parameter: When `true`, indicates the results to include active and inactive clients.<br />  When `false`, indicates that only those clients who are marked as active should be returned.  Default: **false**.</param>
        /// <param name="requestIsProspect">Optional parameter: When `true`, filters the results to include only those clients marked as prospects for the business.<br />  When `false`, indicates that only those clients who are not marked prospects should be returned..</param>
        /// <param name="requestLastModifiedDate">Optional parameter: Filters the results to include only the clients that have been modified on or after this date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSearchText">Optional parameter: Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided..</param>
        /// <param name="requestUniqueIds">Optional parameter: Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.  Default: **all UniqueIDs** that the authenticated user’s access level allows..</param>
        /// <returns>Returns the Models.GetClientsResponse response from the API call.</returns>
        public Models.GetClientsResponse GetClients(
                string version,
                string siteId,
                string authorization = null,
                List<string> requestClientIDs = null,
                bool? requestIncludeInactive = null,
                bool? requestIsProspect = null,
                DateTime? requestLastModifiedDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                string requestSearchText = null,
                List<long> requestUniqueIds = null)
            => CoreHelper.RunTask(GetClientsAsync(version, siteId, authorization, requestClientIDs, requestIncludeInactive, requestIsProspect, requestLastModifiedDate, requestLimit, requestOffset, requestSearchText, requestUniqueIds));

        /// <summary>
        /// This endpoint requires staff user credentials. This endpoint supports pagination. See Pagination for a description of the Pagination information.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientIDs">Optional parameter: The requested client IDs.  Default: **all IDs** that the authenticated user’s access level allows.<br />  Note: You can fetch information for maximum 20 clients at once..</param>
        /// <param name="requestIncludeInactive">Optional parameter: When `true`, indicates the results to include active and inactive clients.<br />  When `false`, indicates that only those clients who are marked as active should be returned.  Default: **false**.</param>
        /// <param name="requestIsProspect">Optional parameter: When `true`, filters the results to include only those clients marked as prospects for the business.<br />  When `false`, indicates that only those clients who are not marked prospects should be returned..</param>
        /// <param name="requestLastModifiedDate">Optional parameter: Filters the results to include only the clients that have been modified on or after this date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSearchText">Optional parameter: Text to use in the search. Can include FirstName, LastName, and Email. Note that user credentials must be provided..</param>
        /// <param name="requestUniqueIds">Optional parameter: Filters results to clients with these `UniqueIDs`. This parameter cannot be used with `ClientIDs` or `SearchText`.  Default: **all UniqueIDs** that the authenticated user’s access level allows..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientsResponse response from the API call.</returns>
        public async Task<Models.GetClientsResponse> GetClientsAsync(
                string version,
                string siteId,
                string authorization = null,
                List<string> requestClientIDs = null,
                bool? requestIncludeInactive = null,
                bool? requestIsProspect = null,
                DateTime? requestLastModifiedDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                string requestSearchText = null,
                List<long> requestUniqueIds = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clients")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.clientIDs", requestClientIDs))
                      .Query(_query => _query.Setup("request.includeInactive", requestIncludeInactive))
                      .Query(_query => _query.Setup("request.isProspect", requestIsProspect))
                      .Query(_query => _query.Setup("request.lastModifiedDate", requestLastModifiedDate.HasValue ? requestLastModifiedDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.searchText", requestSearchText))
                      .Query(_query => _query.Setup("request.uniqueIds", requestUniqueIds))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint can be utilized to retrieve scheduled visits which is associated with the requested client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the requested client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: The number of sites to skip when returning the site associated with a client..</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: When `true`, indicates that past and scheduled client visits across all sites in the region are returned.  When `false`, indicates that only visits at the current site are returned..</param>
        /// <param name="requestEndDate">Optional parameter: The date past which class visits are not returned.  Default is today’s date.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStartDate">Optional parameter: The date before which class visits are not returned.  Default is the end date.</param>
        /// <returns>Returns the Models.GetClientScheduleResponse response from the API call.</returns>
        public Models.GetClientScheduleResponse GetClientSchedule(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(GetClientScheduleAsync(version, requestClientId, siteId, authorization, requestClientAssociatedSitesOffset, requestCrossRegionalLookup, requestEndDate, requestLimit, requestOffset, requestStartDate));

        /// <summary>
        /// This endpoint can be utilized to retrieve scheduled visits which is associated with the requested client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the requested client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: The number of sites to skip when returning the site associated with a client..</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: When `true`, indicates that past and scheduled client visits across all sites in the region are returned.  When `false`, indicates that only visits at the current site are returned..</param>
        /// <param name="requestEndDate">Optional parameter: The date past which class visits are not returned.  Default is today’s date.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStartDate">Optional parameter: The date before which class visits are not returned.  Default is the end date.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientScheduleResponse response from the API call.</returns>
        public async Task<Models.GetClientScheduleResponse> GetClientScheduleAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientScheduleResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clientschedule")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset))
                      .Query(_query => _query.Setup("request.crossRegionalLookup", requestCrossRegionalLookup))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Get pricing options that a client has purchased.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client to query. The results are a list of pricing options that the client has purchased. Note that “service” and “pricing option” are synonymous in this section of the documentation..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassId">Optional parameter: Filters results to only those pricing options that can be used to pay for this class..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestClientIds">Optional parameter: The IDs of the clients to query. The results are a list of pricing options that the clients have purchased.  ClientId parameter takes priority over ClientIds due to backward compatibility.  So if you want to use ClientIds, then ClientId needs to be empty.  Either of ClientId or ClientIds need to be specified.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a client’s pricing options from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.  Default: **false**.</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to pricing options that are purchased on or before this date.   Default: **today’s date**.</param>
        /// <param name="requestIgnoreCrossRegionalSiteLimit">Optional parameter: Used to specify if the number of cross regional sites used to search for client’s pricing options should be ignored.   Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: Filters results to pricing options that can be used at the listed location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filters results to pricing options that belong to one of the given program IDs..</param>
        /// <param name="requestSessionTypeId">Optional parameter: Filters results to pricing options that will pay for the given session type ID. Use this to find pricing options that will pay for a specific appointment type..</param>
        /// <param name="requestShowActiveOnly">Optional parameter: When `true`, includes active services only.  Default: **false**.</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to pricing options that are purchased on or after this date.  Default: **today’s date**.</param>
        /// <param name="requestUseActivateDate">Optional parameter: When this flag is set to true the date filtering will use activate date to filter the pricing options  When this flag is set to false the date filtering will use purchase date to filter the pricing options [ Existing logic ].</param>
        /// <param name="requestVisitCount">Optional parameter: A filter on the minimum number of visits a service can pay for..</param>
        /// <returns>Returns the Models.GetClientServicesResponse response from the API call.</returns>
        public Models.GetClientServicesResponse GetClientServices(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClassId = null,
                int? requestClientAssociatedSitesOffset = null,
                List<string> requestClientIds = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                bool? requestIgnoreCrossRegionalSiteLimit = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                int? requestSessionTypeId = null,
                bool? requestShowActiveOnly = null,
                DateTime? requestStartDate = null,
                bool? requestUseActivateDate = null,
                int? requestVisitCount = null)
            => CoreHelper.RunTask(GetClientServicesAsync(version, requestClientId, siteId, authorization, requestClassId, requestClientAssociatedSitesOffset, requestClientIds, requestCrossRegionalLookup, requestEndDate, requestIgnoreCrossRegionalSiteLimit, requestLimit, requestLocationIds, requestOffset, requestProgramIds, requestSessionTypeId, requestShowActiveOnly, requestStartDate, requestUseActivateDate, requestVisitCount));

        /// <summary>
        /// Get pricing options that a client has purchased.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client to query. The results are a list of pricing options that the client has purchased. Note that “service” and “pricing option” are synonymous in this section of the documentation..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassId">Optional parameter: Filters results to only those pricing options that can be used to pay for this class..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: Used to retrieve a client’s pricing options from multiple sites within an organization when the client is associated with more than ten sites. To change which ten sites are searched, change this offset value. A value of 0 means that no sites are skipped and the first ten sites are returned. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that you must always have `CrossRegionalLookup` set to `true` to use this parameter.<br />  Default: **0**    For example, if a client is associated with 25 sites, you need to call `GetClientServices` three times, as follows:  * Use `GET CrossRegionalClientAssociations` to determine how many sites a client is associated with, which tells you how many additional calls you need to make.  * Either omit `ClientAssociatedSitesOffset` or set it to 0 to return the client’s services (pricing options) from sites 1-10.  * Set `ClientAssociatedSitesOffset` to 10 to return the client pricing options from sites 11-20  * Set `ClientAssociatedSitesOffset` to 20 to return the client pricing options from sites 21-25.</param>
        /// <param name="requestClientIds">Optional parameter: The IDs of the clients to query. The results are a list of pricing options that the clients have purchased.  ClientId parameter takes priority over ClientIds due to backward compatibility.  So if you want to use ClientIds, then ClientId needs to be empty.  Either of ClientId or ClientIds need to be specified.</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: Used to retrieve a client’s pricing options from multiple sites within an organization. When included and set to `true`, it searches a maximum of ten sites with which this client is associated. When a client is associated with more than ten sites, use `ClientAssociatedSitesOffset` as many times as needed to search the additional sites with which the client is associated. You can use the `CrossRegionalClientAssociations` value from `GET CrossRegionalClientAssociations` to determine how many sites the client is associated with. Note that a `SiteID` is returned and populated in the `ClientServices` response when `CrossRegionalLookup` is set to `true`.  Default: **false**.</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to pricing options that are purchased on or before this date.   Default: **today’s date**.</param>
        /// <param name="requestIgnoreCrossRegionalSiteLimit">Optional parameter: Used to specify if the number of cross regional sites used to search for client’s pricing options should be ignored.   Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: Filters results to pricing options that can be used at the listed location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filters results to pricing options that belong to one of the given program IDs..</param>
        /// <param name="requestSessionTypeId">Optional parameter: Filters results to pricing options that will pay for the given session type ID. Use this to find pricing options that will pay for a specific appointment type..</param>
        /// <param name="requestShowActiveOnly">Optional parameter: When `true`, includes active services only.  Default: **false**.</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to pricing options that are purchased on or after this date.  Default: **today’s date**.</param>
        /// <param name="requestUseActivateDate">Optional parameter: When this flag is set to true the date filtering will use activate date to filter the pricing options  When this flag is set to false the date filtering will use purchase date to filter the pricing options [ Existing logic ].</param>
        /// <param name="requestVisitCount">Optional parameter: A filter on the minimum number of visits a service can pay for..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientServicesResponse response from the API call.</returns>
        public async Task<Models.GetClientServicesResponse> GetClientServicesAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClassId = null,
                int? requestClientAssociatedSitesOffset = null,
                List<string> requestClientIds = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                bool? requestIgnoreCrossRegionalSiteLimit = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                int? requestSessionTypeId = null,
                bool? requestShowActiveOnly = null,
                DateTime? requestStartDate = null,
                bool? requestUseActivateDate = null,
                int? requestVisitCount = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientServicesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clientservices")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.classId", requestClassId))
                      .Query(_query => _query.Setup("request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset))
                      .Query(_query => _query.Setup("request.clientIds", requestClientIds))
                      .Query(_query => _query.Setup("request.crossRegionalLookup", requestCrossRegionalLookup))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.ignoreCrossRegionalSiteLimit", requestIgnoreCrossRegionalSiteLimit))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationIds", requestLocationIds))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.programIds", requestProgramIds))
                      .Query(_query => _query.Setup("request.sessionTypeId", requestSessionTypeId))
                      .Query(_query => _query.Setup("request.showActiveOnly", requestShowActiveOnly))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.useActivateDate", requestUseActivateDate))
                      .Query(_query => _query.Setup("request.visitCount", requestVisitCount))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Gets the Client Visits for a specific client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the requested client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: The number of sites to skip when returning the site associated with a client..</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br />  When `false`, indicates that only visits at the current site are returned..</param>
        /// <param name="requestEndDate">Optional parameter: The date past which class visits are not returned.  Default: **today’s date**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStartDate">Optional parameter: The date before which class visits are not returned.  Default: **the end date**.</param>
        /// <param name="requestUnpaidsOnly">Optional parameter: When `true`, indicates that only visits that have not been paid for are returned.<br />  When `false`, indicates that all visits are returned, regardless of whether they have been paid for.<br />  Default: **false**.</param>
        /// <returns>Returns the Models.GetClientVisitsResponse response from the API call.</returns>
        public Models.GetClientVisitsResponse GetClientVisits(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                DateTime? requestStartDate = null,
                bool? requestUnpaidsOnly = null)
            => CoreHelper.RunTask(GetClientVisitsAsync(version, requestClientId, siteId, authorization, requestClientAssociatedSitesOffset, requestCrossRegionalLookup, requestEndDate, requestLimit, requestOffset, requestStartDate, requestUnpaidsOnly));

        /// <summary>
        /// Gets the Client Visits for a specific client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the requested client..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientAssociatedSitesOffset">Optional parameter: The number of sites to skip when returning the site associated with a client..</param>
        /// <param name="requestCrossRegionalLookup">Optional parameter: When `true`, indicates that past and scheduled client visits across all sites in the region are returned.<br />  When `false`, indicates that only visits at the current site are returned..</param>
        /// <param name="requestEndDate">Optional parameter: The date past which class visits are not returned.  Default: **today’s date**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStartDate">Optional parameter: The date before which class visits are not returned.  Default: **the end date**.</param>
        /// <param name="requestUnpaidsOnly">Optional parameter: When `true`, indicates that only visits that have not been paid for are returned.<br />  When `false`, indicates that all visits are returned, regardless of whether they have been paid for.<br />  Default: **false**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClientVisitsResponse response from the API call.</returns>
        public async Task<Models.GetClientVisitsResponse> GetClientVisitsAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                int? requestClientAssociatedSitesOffset = null,
                bool? requestCrossRegionalLookup = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                DateTime? requestStartDate = null,
                bool? requestUnpaidsOnly = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClientVisitsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/clientvisits")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.clientAssociatedSitesOffset", requestClientAssociatedSitesOffset))
                      .Query(_query => _query.Setup("request.crossRegionalLookup", requestCrossRegionalLookup))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.unpaidsOnly", requestUnpaidsOnly))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client whose contact logs are being requested..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: Filters the results to contact logs created before this date.<br />  Default: **the start date**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestShowSystemGenerated">Optional parameter: When `true`, system-generated contact logs are returned in the results.<br />  Default: **false**.</param>
        /// <param name="requestStaffIds">Optional parameter: Filters the results to return contact logs assigned to one or more staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: Filters the results to contact logs created on or after this date.<br />  Default: **the current date**.</param>
        /// <param name="requestSubtypeIds">Optional parameter: Filters the results to contact logs assigned one or more of these subtype IDs..</param>
        /// <param name="requestTypeIds">Optional parameter: Filters the results to contact logs assigned one or more of these type IDs..</param>
        /// <returns>Returns the Models.GetContactLogsResponse response from the API call.</returns>
        public Models.GetContactLogsResponse GetContactLogs(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestShowSystemGenerated = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                List<int> requestSubtypeIds = null,
                List<int> requestTypeIds = null)
            => CoreHelper.RunTask(GetContactLogsAsync(version, requestClientId, siteId, authorization, requestEndDate, requestLimit, requestOffset, requestShowSystemGenerated, requestStaffIds, requestStartDate, requestSubtypeIds, requestTypeIds));

        /// <summary>
        /// This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The ID of the client whose contact logs are being requested..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: Filters the results to contact logs created before this date.<br />  Default: **the start date**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestShowSystemGenerated">Optional parameter: When `true`, system-generated contact logs are returned in the results.<br />  Default: **false**.</param>
        /// <param name="requestStaffIds">Optional parameter: Filters the results to return contact logs assigned to one or more staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: Filters the results to contact logs created on or after this date.<br />  Default: **the current date**.</param>
        /// <param name="requestSubtypeIds">Optional parameter: Filters the results to contact logs assigned one or more of these subtype IDs..</param>
        /// <param name="requestTypeIds">Optional parameter: Filters the results to contact logs assigned one or more of these type IDs..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetContactLogsResponse response from the API call.</returns>
        public async Task<Models.GetContactLogsResponse> GetContactLogsAsync(
                string version,
                string requestClientId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestShowSystemGenerated = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                List<int> requestSubtypeIds = null,
                List<int> requestTypeIds = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetContactLogsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/contactlogs")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.showSystemGenerated", requestShowSystemGenerated))
                      .Query(_query => _query.Setup("request.staffIds", requestStaffIds))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.subtypeIds", requestSubtypeIds))
                      .Query(_query => _query.Setup("request.typeIds", requestTypeIds))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestContactLogTypeId">Optional parameter: The requested ContactLogType ID.  Default: **all** IDs that the authenticated user’s access level allows..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.GetContactLogTypesResponse response from the API call.</returns>
        public Models.GetContactLogTypesResponse GetContactLogTypes(
                string version,
                string siteId,
                string authorization = null,
                int? requestContactLogTypeId = null,
                int? requestLimit = null,
                int? requestOffset = null)
            => CoreHelper.RunTask(GetContactLogTypesAsync(version, siteId, authorization, requestContactLogTypeId, requestLimit, requestOffset));

        /// <summary>
        /// This endpoint contains a variety of filters that can return not just all contact logs, but also system-generated contact logs, contact logs assigned to specific staff members, and contact logs of specific types or subtypes.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestContactLogTypeId">Optional parameter: The requested ContactLogType ID.  Default: **all** IDs that the authenticated user’s access level allows..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetContactLogTypesResponse response from the API call.</returns>
        public async Task<Models.GetContactLogTypesResponse> GetContactLogTypesAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestContactLogTypeId = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetContactLogTypesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/contactlogtypes")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.contactLogTypeId", requestContactLogTypeId))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Returns a list of sites that a particular client ID (also referred to as an RSSID) or a client email address is associated with in a cross-regional organization. Either the `ClientID` or `Email` parameter is required. If both are provided, the `ClientID` is used.
        /// Use this endpoint to retrieve information for other Public API endpoints, about the same client at multiple sites within an organization. To use this endpoint, your developer account must have been granted permission to the site’s entire organization.
        /// Note that this endpoint does not work on the Developer Sandbox site, as it is not set up for cross-regional use cases.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientId">Optional parameter: Looks up the cross regional associations by the client’s ID. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default..</param>
        /// <param name="requestEmail">Optional parameter: Looks up the cross regional associations by the client’s email address. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default..</param>
        /// <param name="requestFirstName">Optional parameter: First name (used for email queries).</param>
        /// <param name="requestLastName">Optional parameter: Last name (used for email queries).</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestV2">Optional parameter: Use newer method.</param>
        /// <returns>Returns the Models.GetCrossRegionalClientAssociationsResponse response from the API call.</returns>
        public Models.GetCrossRegionalClientAssociationsResponse GetCrossRegionalClientAssociations(
                string version,
                string siteId,
                string authorization = null,
                string requestClientId = null,
                string requestEmail = null,
                string requestFirstName = null,
                string requestLastName = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestV2 = null)
            => CoreHelper.RunTask(GetCrossRegionalClientAssociationsAsync(version, siteId, authorization, requestClientId, requestEmail, requestFirstName, requestLastName, requestLimit, requestOffset, requestV2));

        /// <summary>
        /// Returns a list of sites that a particular client ID (also referred to as an RSSID) or a client email address is associated with in a cross-regional organization. Either the `ClientID` or `Email` parameter is required. If both are provided, the `ClientID` is used.
        /// Use this endpoint to retrieve information for other Public API endpoints, about the same client at multiple sites within an organization. To use this endpoint, your developer account must have been granted permission to the site’s entire organization.
        /// Note that this endpoint does not work on the Developer Sandbox site, as it is not set up for cross-regional use cases.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientId">Optional parameter: Looks up the cross regional associations by the client’s ID. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default..</param>
        /// <param name="requestEmail">Optional parameter: Looks up the cross regional associations by the client’s email address. Either `ClientId` or `Email` must be provided. If both are provided, the `ClientId` is used by default..</param>
        /// <param name="requestFirstName">Optional parameter: First name (used for email queries).</param>
        /// <param name="requestLastName">Optional parameter: Last name (used for email queries).</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestV2">Optional parameter: Use newer method.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetCrossRegionalClientAssociationsResponse response from the API call.</returns>
        public async Task<Models.GetCrossRegionalClientAssociationsResponse> GetCrossRegionalClientAssociationsAsync(
                string version,
                string siteId,
                string authorization = null,
                string requestClientId = null,
                string requestEmail = null,
                string requestFirstName = null,
                string requestLastName = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestV2 = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetCrossRegionalClientAssociationsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/crossregionalclientassociations")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Query(_query => _query.Setup("request.email", requestEmail))
                      .Query(_query => _query.Setup("request.firstName", requestFirstName))
                      .Query(_query => _query.Setup("request.lastName", requestLastName))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.v2", requestV2))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Get a site's configured custom client fields.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.GetCustomClientFieldsResponse response from the API call.</returns>
        public Models.GetCustomClientFieldsResponse GetCustomClientFields(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null)
            => CoreHelper.RunTask(GetCustomClientFieldsAsync(version, siteId, authorization, requestLimit, requestOffset));

        /// <summary>
        /// Get a site's configured custom client fields.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetCustomClientFieldsResponse response from the API call.</returns>
        public async Task<Models.GetCustomClientFieldsResponse> GetCustomClientFieldsAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetCustomClientFieldsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/customclientfields")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Gets the list of fields that a new client has to fill out in business mode, specifically for the sign-up process. `AddClient` and `UpdateClient` validate against these fields.
        /// This endpoint has no query parameters.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.GetRequiredClientFieldsResponse response from the API call.</returns>
        public Models.GetRequiredClientFieldsResponse GetRequiredClientFields(
                string version,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(GetRequiredClientFieldsAsync(version, siteId, authorization));

        /// <summary>
        /// Gets the list of fields that a new client has to fill out in business mode, specifically for the sign-up process. `AddClient` and `UpdateClient` validate against these fields.
        /// This endpoint has no query parameters.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetRequiredClientFieldsResponse response from the API call.</returns>
        public async Task<Models.GetRequiredClientFieldsResponse> GetRequiredClientFieldsAsync(
                string version,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetRequiredClientFieldsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/client/requiredclientfields")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Marks a client as arrived for a specified location. A staff user token must be included with staff assigned the LaunchSignInScreen permission.
        ///             .
        /// When used on a site that is part of a region, the following additional logic will apply:.
        ///             .
        /// * When a client exists within the region but not at the studio where the arrival is being logged, a local client record will be automatically created.
        /// * If the local client does not have an applicable local membership or pricing option, a membership or pricing option will be automatically used if it exists elsewhere within the region.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.AddArrivalResponse response from the API call.</returns>
        public Models.AddArrivalResponse AddArrival(
                string version,
                Models.AddArrivalRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddArrivalAsync(version, request, siteId, authorization));

        /// <summary>
        /// Marks a client as arrived for a specified location. A staff user token must be included with staff assigned the LaunchSignInScreen permission.
        ///             .
        /// When used on a site that is part of a region, the following additional logic will apply:.
        ///             .
        /// * When a client exists within the region but not at the studio where the arrival is being logged, a local client record will be automatically created.
        /// * If the local client does not have an applicable local membership or pricing option, a membership or pricing option will be automatically used if it exists elsewhere within the region.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.AddArrivalResponse response from the API call.</returns>
        public async Task<Models.AddArrivalResponse> AddArrivalAsync(
                string version,
                Models.AddArrivalRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.AddArrivalResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/addarrival")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />.
        /// Creates a new client record at the specified business.Passing a User Token as Authorization will create a client and respect Business Mode required fields.Omitting the token will create a client and respect Consumer Mode required fi elds. To make sure you are collecting all required pieces of information, first run GetRequired ClientFields.<br />.
        /// If you have purchased an Ultimate tier then this endpoint will automatically start showing new opportunity on Sales Pipeline.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: The `FirstName` and `LastName` parameters are always required in this request.               All other parameters are optional, but note that any of the optional parameters could be required by a particular business,              depending on how the business has configured the site settings. If `GetRequiredClientFields` returns `EmergContact` in the list of required fields,              then all emergency contact parameters are required, which includes `EmergencyContactInfoEmail`, `EmergencyContactInfoName`, `EmergencyContactInfoPhone`, and `EmergencyContactInfoRelationship`..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.AddClientResponse response from the API call.</returns>
        public Models.AddClientResponse AddClient(
                string version,
                Models.AddClientRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddClientAsync(version, request, siteId, authorization));

        /// <summary>
        /// Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />.
        /// Creates a new client record at the specified business.Passing a User Token as Authorization will create a client and respect Business Mode required fields.Omitting the token will create a client and respect Consumer Mode required fi elds. To make sure you are collecting all required pieces of information, first run GetRequired ClientFields.<br />.
        /// If you have purchased an Ultimate tier then this endpoint will automatically start showing new opportunity on Sales Pipeline.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: The `FirstName` and `LastName` parameters are always required in this request.               All other parameters are optional, but note that any of the optional parameters could be required by a particular business,              depending on how the business has configured the site settings. If `GetRequiredClientFields` returns `EmergContact` in the list of required fields,              then all emergency contact parameters are required, which includes `EmergencyContactInfoEmail`, `EmergencyContactInfoName`, `EmergencyContactInfoPhone`, and `EmergencyContactInfoRelationship`..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.AddClientResponse response from the API call.</returns>
        public async Task<Models.AddClientResponse> AddClientAsync(
                string version,
                Models.AddClientRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.AddClientResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/addclient")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint adds direct debit info to a client’s account. This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.AddClientDirectDebitInfoResponse response from the API call.</returns>
        public Models.AddClientDirectDebitInfoResponse AddClientDirectDebitInfo(
                string version,
                Models.AddClientDirectDebitInfoRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddClientDirectDebitInfoAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint adds direct debit info to a client’s account. This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.AddClientDirectDebitInfoResponse response from the API call.</returns>
        public async Task<Models.AddClientDirectDebitInfoResponse> AddClientDirectDebitInfoAsync(
                string version,
                Models.AddClientDirectDebitInfoRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.AddClientDirectDebitInfoResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/addclientdirectdebitinfo")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint adds a formula note for a specified client or specified client appointment. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.FormulaNoteResponse response from the API call.</returns>
        public Models.FormulaNoteResponse AddFormulaNote(
                string version,
                Models.AddFormulaNoteRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddFormulaNoteAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint adds a formula note for a specified client or specified client appointment. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.FormulaNoteResponse response from the API call.</returns>
        public async Task<Models.FormulaNoteResponse> AddFormulaNoteAsync(
                string version,
                Models.AddFormulaNoteRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.FormulaNoteResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/addclientformulanote")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Add a contact log to a client's account.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.ContactLog response from the API call.</returns>
        public Models.ContactLog AddContactLog(
                string version,
                Models.AddContactLogRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddContactLogAsync(version, request, siteId, authorization));

        /// <summary>
        /// Add a contact log to a client's account.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ContactLog response from the API call.</returns>
        public async Task<Models.ContactLog> AddContactLogAsync(
                string version,
                Models.AddContactLogRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ContactLog>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/addcontactlog")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint helps to merge clients.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object MergeClient(
                string version,
                Models.MergeClientsRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(MergeClientAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint helps to merge clients.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> MergeClientAsync(
                string version,
                Models.MergeClientsRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/mergeclients")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object SendAutoEmail(
                string version,
                Models.SendAutoEmailRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(SendAutoEmailAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> SendAutoEmailAsync(
                string version,
                Models.SendAutoEmailRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/sendautoemail")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Send a password reset email to a client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object SendPasswordResetEmail(
                string version,
                Models.SendPasswordResetEmailRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(SendPasswordResetEmailAsync(version, request, siteId, authorization));

        /// <summary>
        /// Send a password reset email to a client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> SendPasswordResetEmailAsync(
                string version,
                Models.SendPasswordResetEmailRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/sendpasswordresetemail")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Suspend client contract.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.SuspendContractResponse response from the API call.</returns>
        public Models.SuspendContractResponse SuspendContract(
                string version,
                Models.SuspendContractRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(SuspendContractAsync(version, request, siteId, authorization));

        /// <summary>
        /// Suspend client contract.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.SuspendContractResponse response from the API call.</returns>
        public async Task<Models.SuspendContractResponse> SuspendContractAsync(
                string version,
                Models.SuspendContractRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.SuspendContractResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/suspendcontract")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint terminates a client contract. This endpoint requires staff user credentials with TerminateClientContract permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.TerminateContractResponse response from the API call.</returns>
        public Models.TerminateContractResponse TerminateContract(
                string version,
                Models.TerminateContractRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(TerminateContractAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint terminates a client contract. This endpoint requires staff user credentials with TerminateClientContract permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.TerminateContractResponse response from the API call.</returns>
        public async Task<Models.TerminateContractResponse> TerminateContractAsync(
                string version,
                Models.TerminateContractRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.TerminateContractResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/terminatecontract")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />.
        /// Updates an existing client for a specific subscriber.Passing a User Token as Authorization respects Business Mode required fields.Omitting the token respects Consumer Mode required fields.To make sure you are collecting all required pieces of information, first run GetRequiredClientFields..Use this endpoint as follows:.
        /// * If you need to update the `ReferredBy` parameter, use this endpoint after calling `GET ClientReferralTypes`.
        /// * When updating a client’s home location, use after calling `GET Locations`.
        /// * If you are updating a client’s stored credit card, use after calling `GET AcceptedCardTypes` so that you can make sure the card is a type that is accepted at the subscriber.
        /// If this endpoint is used on a cross-regional site, passing in a client’s RSSID and email address creates a cross-regional link. This means that the client is created in cross-regional sites where the client does not exist and `GET CrossRegionalClientAssociations` returns all appropriate cross-regional sites. When `CrossRegionalUpdate` is omitted or set to `true`, the client’s updated information is propagated to all of the region’s sites. If `CrossRegionalUpdate` is set to `false`, only the local client is updated.
        /// Note that the following items cannot be updated for a cross-regional client:.
        /// * `ClientIndexes`.
        /// * `ClientRelationships`.
        /// * `CustomClientFields`.
        /// * `SalesReps`.
        /// * `SendAccountEmails`.
        /// * `SendAccountTexts`.
        /// * `SendPromotionalEmails`.
        /// * `SendPromotionalTexts`.
        /// * `SendScheduleEmails`.
        /// * `SendScheduleTexts`.
        /// * `Gender` (for site custom values).
        /// Custom client Gender options can only be created with non-cross-regional requests.
        ///             .
        /// If you have purchased an Ultimate tier then this endpoint will automatically start showing a new opportunity on Sales Pipeline.It will create a new opportunity if the current request modify the contact as follows::.
        ///             .
        /// * You need to update the `IsProspect` parameter, to `true`.<br />.
        /// * You need to update the `ProspectStage`.`Description parameter`, to `New Lead`.<br />.
        /// Updates made to any inactive clients will automatically reactivate the client unless the `Acive` property is explicitly set to `false` in the request body.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.UpdateClientResponse response from the API call.</returns>
        public Models.UpdateClientResponse UpdateClient(
                string version,
                Models.UpdateClientRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateClientAsync(version, request, siteId, authorization));

        /// <summary>
        /// Starting the week of May 11th, 2020 all versions of the Public API will no longer allow duplicate clients to be created. This applies to both adding a client and updating a client record. A duplicate client is created when two profiles have the same first name, last name and email.<br />.
        /// Updates an existing client for a specific subscriber.Passing a User Token as Authorization respects Business Mode required fields.Omitting the token respects Consumer Mode required fields.To make sure you are collecting all required pieces of information, first run GetRequiredClientFields..Use this endpoint as follows:.
        /// * If you need to update the `ReferredBy` parameter, use this endpoint after calling `GET ClientReferralTypes`.
        /// * When updating a client’s home location, use after calling `GET Locations`.
        /// * If you are updating a client’s stored credit card, use after calling `GET AcceptedCardTypes` so that you can make sure the card is a type that is accepted at the subscriber.
        /// If this endpoint is used on a cross-regional site, passing in a client’s RSSID and email address creates a cross-regional link. This means that the client is created in cross-regional sites where the client does not exist and `GET CrossRegionalClientAssociations` returns all appropriate cross-regional sites. When `CrossRegionalUpdate` is omitted or set to `true`, the client’s updated information is propagated to all of the region’s sites. If `CrossRegionalUpdate` is set to `false`, only the local client is updated.
        /// Note that the following items cannot be updated for a cross-regional client:.
        /// * `ClientIndexes`.
        /// * `ClientRelationships`.
        /// * `CustomClientFields`.
        /// * `SalesReps`.
        /// * `SendAccountEmails`.
        /// * `SendAccountTexts`.
        /// * `SendPromotionalEmails`.
        /// * `SendPromotionalTexts`.
        /// * `SendScheduleEmails`.
        /// * `SendScheduleTexts`.
        /// * `Gender` (for site custom values).
        /// Custom client Gender options can only be created with non-cross-regional requests.
        ///             .
        /// If you have purchased an Ultimate tier then this endpoint will automatically start showing a new opportunity on Sales Pipeline.It will create a new opportunity if the current request modify the contact as follows::.
        ///             .
        /// * You need to update the `IsProspect` parameter, to `true`.<br />.
        /// * You need to update the `ProspectStage`.`Description parameter`, to `New Lead`.<br />.
        /// Updates made to any inactive clients will automatically reactivate the client unless the `Acive` property is explicitly set to `false` in the request body.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UpdateClientResponse response from the API call.</returns>
        public async Task<Models.UpdateClientResponse> UpdateClientAsync(
                string version,
                Models.UpdateClientRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.UpdateClientResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/updateclient")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint can be used to update the amount and/or the item of a client’s autopay schedule.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.Contract response from the API call.</returns>
        public Models.Contract UpdateClientContractAutopays(
                string version,
                Models.UpdateClientContractAutopaysRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateClientContractAutopaysAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint can be used to update the amount and/or the item of a client’s autopay schedule.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.Contract response from the API call.</returns>
        public async Task<Models.Contract> UpdateClientContractAutopaysAsync(
                string version,
                Models.UpdateClientContractAutopaysRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.Contract>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/updateclientcontractautopays")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Updates the active date and/or expiration date of a client pricing option. This request requires staff user credentials. If the active date is modified, the expiration date is also modified accordingly. If the expiration date is modified, the active date is unchanged.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.UpdateClientServiceResponse response from the API call.</returns>
        public Models.UpdateClientServiceResponse UpdateClientService(
                string version,
                Models.UpdateClientServiceRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateClientServiceAsync(version, request, siteId, authorization));

        /// <summary>
        /// Updates the active date and/or expiration date of a client pricing option. This request requires staff user credentials. If the active date is modified, the expiration date is also modified accordingly. If the expiration date is modified, the active date is unchanged.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UpdateClientServiceResponse response from the API call.</returns>
        public async Task<Models.UpdateClientServiceResponse> UpdateClientServiceAsync(
                string version,
                Models.UpdateClientServiceRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.UpdateClientServiceResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/updateclientservice")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Updates the status of the specified visit.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.UpdateClientVisitResponse response from the API call.</returns>
        public Models.UpdateClientVisitResponse UpdateClientVisit(
                string version,
                Models.UpdateClientVisitRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateClientVisitAsync(version, request, siteId, authorization));

        /// <summary>
        /// Updates the status of the specified visit.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UpdateClientVisitResponse response from the API call.</returns>
        public async Task<Models.UpdateClientVisitResponse> UpdateClientVisitAsync(
                string version,
                Models.UpdateClientVisitRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.UpdateClientVisitResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/updateclientvisit")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Update a contact log on a client's account.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.ContactLog response from the API call.</returns>
        public Models.ContactLog UpdateContactLog(
                string version,
                Models.UpdateContactLogRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateContactLogAsync(version, request, siteId, authorization));

        /// <summary>
        /// Update a contact log on a client's account.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ContactLog response from the API call.</returns>
        public async Task<Models.ContactLog> UpdateContactLogAsync(
                string version,
                Models.UpdateContactLogRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ContactLog>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/updatecontactlog")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Uploads a document file for a specific client. Returns a string representation of the image byte array. The maximum size file that can be uploaded is **4MB**.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.UploadClientDocumentResponse response from the API call.</returns>
        public Models.UploadClientDocumentResponse UploadClientDocument(
                string version,
                Models.UploadClientDocumentRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UploadClientDocumentAsync(version, request, siteId, authorization));

        /// <summary>
        /// Uploads a document file for a specific client. Returns a string representation of the image byte array. The maximum size file that can be uploaded is **4MB**.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UploadClientDocumentResponse response from the API call.</returns>
        public async Task<Models.UploadClientDocumentResponse> UploadClientDocumentAsync(
                string version,
                Models.UploadClientDocumentRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.UploadClientDocumentResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/uploadclientdocument")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Uploads a client’s profile photo. The maximum file size is 4 MB and acceptable file types are:.
        /// * bmp.
        /// * jpeg.
        /// * gif.
        /// * tiff.
        /// * png.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.UploadClientPhotoResponse response from the API call.</returns>
        public Models.UploadClientPhotoResponse UploadClientPhoto(
                string version,
                Models.UploadClientPhotoRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UploadClientPhotoAsync(version, request, siteId, authorization));

        /// <summary>
        /// Uploads a client’s profile photo. The maximum file size is 4 MB and acceptable file types are:.
        /// * bmp.
        /// * jpeg.
        /// * gif.
        /// * tiff.
        /// * png.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UploadClientPhotoResponse response from the API call.</returns>
        public async Task<Models.UploadClientPhotoResponse> UploadClientPhotoAsync(
                string version,
                Models.UploadClientPhotoRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.UploadClientPhotoResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/client/uploadclientphoto")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint deletes an existing formula note. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The client ID of the client whose formula note needs to be deleted..</param>
        /// <param name="requestFormulaNoteId">Required parameter: The formula note ID for the note to be deleted..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        public void DeleteClientFormulaNote(
                string version,
                string requestClientId,
                long requestFormulaNoteId,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null)
            => CoreHelper.RunVoidTask(DeleteClientFormulaNoteAsync(version, requestClientId, requestFormulaNoteId, siteId, authorization, requestLimit, requestOffset));

        /// <summary>
        /// This endpoint deletes an existing formula note. A staff user token must be included with staff assigned permission to view client profile or have both ViewAppointmentDetails and ModifyAppointment permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The client ID of the client whose formula note needs to be deleted..</param>
        /// <param name="requestFormulaNoteId">Required parameter: The formula note ID for the note to be deleted..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteClientFormulaNoteAsync(
                string version,
                string requestClientId,
                long requestFormulaNoteId,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/public/v{version}/client/clientformulanote")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Query(_query => _query.Setup("request.formulaNoteId", requestFormulaNoteId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint deletes contactlog of client. This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The client ID of the client whose Contact Log is being deleted..</param>
        /// <param name="requestContactLogId">Required parameter: The Contact Log ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestTest">Optional parameter: When `true`, indicates that this is a test request and no data is inserted into the subscriber’s database.  When `false`, the database is updated..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object DeleteContactLog(
                string version,
                string requestClientId,
                long requestContactLogId,
                string siteId,
                string authorization = null,
                bool? requestTest = null)
            => CoreHelper.RunTask(DeleteContactLogAsync(version, requestClientId, requestContactLogId, siteId, authorization, requestTest));

        /// <summary>
        /// This endpoint deletes contactlog of client. This endpoint requires staff user credentials.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClientId">Required parameter: The client ID of the client whose Contact Log is being deleted..</param>
        /// <param name="requestContactLogId">Required parameter: The Contact Log ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestTest">Optional parameter: When `true`, indicates that this is a test request and no data is inserted into the subscriber’s database.  When `false`, the database is updated..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> DeleteContactLogAsync(
                string version,
                string requestClientId,
                long requestContactLogId,
                string siteId,
                string authorization = null,
                bool? requestTest = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/public/v{version}/client/deletecontactlog")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Query(_query => _query.Setup("request.contactLogId", requestContactLogId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.test", requestTest))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}