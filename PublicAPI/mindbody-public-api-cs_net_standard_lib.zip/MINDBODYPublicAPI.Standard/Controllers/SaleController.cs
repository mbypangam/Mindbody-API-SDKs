// <copyright file="SaleController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using APIMatic.Core;
using APIMatic.Core.Types;
using APIMatic.Core.Utilities;
using APIMatic.Core.Utilities.Date.Xml;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Http.Client;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json.Converters;
using System.Net.Http;

namespace MINDBODYPublicAPI.Standard.Controllers
{
    /// <summary>
    /// SaleController.
    /// </summary>
    public class SaleController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SaleController"/> class.
        /// </summary>
        internal SaleController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Gets a list of card types that the site accepts. You can also use `GET Sites` to return the Site object, which contains individual accepted card types for requested sites.
        /// This endpoint has no query parameters.The response returns a list of strings. Possible values are:.
        /// * Visa.
        /// * MasterCard.
        /// * Discover.
        /// * AMEX.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the List of string response from the API call.</returns>
        public List<string> GetAcceptedCardTypes(
                string version,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(GetAcceptedCardTypesAsync(version, siteId, authorization));

        /// <summary>
        /// Gets a list of card types that the site accepts. You can also use `GET Sites` to return the Site object, which contains individual accepted card types for requested sites.
        /// This endpoint has no query parameters.The response returns a list of strings. Possible values are:.
        /// * Visa.
        /// * MasterCard.
        /// * Discover.
        /// * AMEX.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the List of string response from the API call.</returns>
        public async Task<List<string>> GetAcceptedCardTypesAsync(
                string version,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<List<string>>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/sale/acceptedcardtypes")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Get alternative and local payment methods that are allowed for a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientId">Optional parameter: The client ID.</param>
        /// <param name="requestLocationId">Optional parameter: The location ID.</param>
        /// <returns>Returns the Models.GetAlternativePaymentMethodsResponse response from the API call.</returns>
        public Models.GetAlternativePaymentMethodsResponse Alternativepaymentmethods(
                string version,
                string siteId,
                string authorization = null,
                long? requestClientId = null,
                int? requestLocationId = null)
            => CoreHelper.RunTask(AlternativepaymentmethodsAsync(version, siteId, authorization, requestClientId, requestLocationId));

        /// <summary>
        /// Get alternative and local payment methods that are allowed for a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientId">Optional parameter: The client ID.</param>
        /// <param name="requestLocationId">Optional parameter: The location ID.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetAlternativePaymentMethodsResponse response from the API call.</returns>
        public async Task<Models.GetAlternativePaymentMethodsResponse> AlternativepaymentmethodsAsync(
                string version,
                string siteId,
                string authorization = null,
                long? requestClientId = null,
                int? requestLocationId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetAlternativePaymentMethodsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/sale/alternativepaymentmethods")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Returns the contracts and autopay options that are available on a location-by-location basis. Depending on the configurations established by the site, this endpoint returns options that can be used to sign up clients for recurring payments for services offered by the business.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestLocationId">Required parameter: The ID of the location that has the requested contracts and AutoPay options..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestConsumerId">Optional parameter: The ID of the client..</param>
        /// <param name="requestContractIds">Optional parameter: When included, the response only contains details about the specified contract IDs..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestPromoCode">Optional parameter: PromoCode to apply.</param>
        /// <param name="requestSoldOnline">Optional parameter: When `true`, the response only contains details about contracts and AutoPay options that can be sold online.   When `false`, all contracts are returned.  Default: **false**.</param>
        /// <returns>Returns the Models.GetContractsResponse response from the API call.</returns>
        public Models.GetContractsResponse GetContracts(
                string version,
                int requestLocationId,
                string siteId,
                string authorization = null,
                long? requestConsumerId = null,
                List<int> requestContractIds = null,
                int? requestLimit = null,
                int? requestOffset = null,
                string requestPromoCode = null,
                bool? requestSoldOnline = null)
            => CoreHelper.RunTask(GetContractsAsync(version, requestLocationId, siteId, authorization, requestConsumerId, requestContractIds, requestLimit, requestOffset, requestPromoCode, requestSoldOnline));

        /// <summary>
        /// Returns the contracts and autopay options that are available on a location-by-location basis. Depending on the configurations established by the site, this endpoint returns options that can be used to sign up clients for recurring payments for services offered by the business.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestLocationId">Required parameter: The ID of the location that has the requested contracts and AutoPay options..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestConsumerId">Optional parameter: The ID of the client..</param>
        /// <param name="requestContractIds">Optional parameter: When included, the response only contains details about the specified contract IDs..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestPromoCode">Optional parameter: PromoCode to apply.</param>
        /// <param name="requestSoldOnline">Optional parameter: When `true`, the response only contains details about contracts and AutoPay options that can be sold online.   When `false`, all contracts are returned.  Default: **false**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetContractsResponse response from the API call.</returns>
        public async Task<Models.GetContractsResponse> GetContractsAsync(
                string version,
                int requestLocationId,
                string siteId,
                string authorization = null,
                long? requestConsumerId = null,
                List<int> requestContractIds = null,
                int? requestLimit = null,
                int? requestOffset = null,
                string requestPromoCode = null,
                bool? requestSoldOnline = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetContractsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/sale/contracts")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.consumerId", requestConsumerId))
                      .Query(_query => _query.Setup("request.contractIds", requestContractIds))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.promoCode", requestPromoCode))
                      .Query(_query => _query.Setup("request.soldOnline", requestSoldOnline))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Get payment methods that can be used to pay for sales at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.GetCustomPaymentMethodsResponse response from the API call.</returns>
        public Models.GetCustomPaymentMethodsResponse GetCustomPaymentMethods(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null)
            => CoreHelper.RunTask(GetCustomPaymentMethodsAsync(version, siteId, authorization, requestLimit, requestOffset));

        /// <summary>
        /// Get payment methods that can be used to pay for sales at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetCustomPaymentMethodsResponse response from the API call.</returns>
        public async Task<Models.GetCustomPaymentMethodsResponse> GetCustomPaymentMethodsAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetCustomPaymentMethodsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/sale/custompaymentmethods")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Returns a gift card’s remaining balance.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="barcodeId">Optional parameter: The barcode ID of the gift card for which you want the balance..</param>
        /// <returns>Returns the Models.GetGiftCardBalanceResponse response from the API call.</returns>
        public Models.GetGiftCardBalanceResponse GetGiftCardBalance(
                string version,
                string siteId,
                string authorization = null,
                string barcodeId = null)
            => CoreHelper.RunTask(GetGiftCardBalanceAsync(version, siteId, authorization, barcodeId));

        /// <summary>
        /// Returns a gift card’s remaining balance.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="barcodeId">Optional parameter: The barcode ID of the gift card for which you want the balance..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetGiftCardBalanceResponse response from the API call.</returns>
        public async Task<Models.GetGiftCardBalanceResponse> GetGiftCardBalanceAsync(
                string version,
                string siteId,
                string authorization = null,
                string barcodeId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetGiftCardBalanceResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/sale/giftcardbalance")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("barcodeId", barcodeId))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Returns information about gift cards that can be purchased.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestIds">Optional parameter: Filters the results to the requested gift card IDs.<br />  Default: **all** gift cards..</param>
        /// <param name="requestIncludeCustomLayouts">Optional parameter: When `true`, includes custom gift card layouts.<br />  When `false`, includes only system layouts.  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: When included, returns gift cards that are sold at the provided location ID..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSoldOnline">Optional parameter: When `true`, only returns gift cards that are sold online.<br />  Default: **false**.</param>
        /// <returns>Returns the Models.GetGiftCardResponse response from the API call.</returns>
        public Models.GetGiftCardResponse GetGiftCards(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestIds = null,
                bool? requestIncludeCustomLayouts = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                bool? requestSoldOnline = null)
            => CoreHelper.RunTask(GetGiftCardsAsync(version, siteId, authorization, requestIds, requestIncludeCustomLayouts, requestLimit, requestLocationId, requestOffset, requestSoldOnline));

        /// <summary>
        /// Returns information about gift cards that can be purchased.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestIds">Optional parameter: Filters the results to the requested gift card IDs.<br />  Default: **all** gift cards..</param>
        /// <param name="requestIncludeCustomLayouts">Optional parameter: When `true`, includes custom gift card layouts.<br />  When `false`, includes only system layouts.  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: When included, returns gift cards that are sold at the provided location ID..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSoldOnline">Optional parameter: When `true`, only returns gift cards that are sold online.<br />  Default: **false**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetGiftCardResponse response from the API call.</returns>
        public async Task<Models.GetGiftCardResponse> GetGiftCardsAsync(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestIds = null,
                bool? requestIncludeCustomLayouts = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                bool? requestSoldOnline = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetGiftCardResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/sale/giftcards")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.ids", requestIds))
                      .Query(_query => _query.Setup("request.includeCustomLayouts", requestIncludeCustomLayouts))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.soldOnline", requestSoldOnline))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// A package is typically used to combine multiple services and/or products into a single offering. Staff members can check out multiple appointments while selling the package, and can discount the items included. For example, a spa might bundle a massage, a pedicure, a manicure, a facial, and a few selected beauty products into a package.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: The location ID to use to determine the tax for the products that this request returns.<br />  Default: **online store**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestPackageIds">Optional parameter: A list of the packages IDs to filter by..</param>
        /// <param name="requestSellOnline">Optional parameter: When `true`, only returns products that can be sold online.<br />  When `false`, all products are returned.<br />  Default: **false**.</param>
        /// <returns>Returns the Models.GetPackagesResponse response from the API call.</returns>
        public Models.GetPackagesResponse GetPackages(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestPackageIds = null,
                bool? requestSellOnline = null)
            => CoreHelper.RunTask(GetPackagesAsync(version, siteId, authorization, requestLimit, requestLocationId, requestOffset, requestPackageIds, requestSellOnline));

        /// <summary>
        /// A package is typically used to combine multiple services and/or products into a single offering. Staff members can check out multiple appointments while selling the package, and can discount the items included. For example, a spa might bundle a massage, a pedicure, a manicure, a facial, and a few selected beauty products into a package.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: The location ID to use to determine the tax for the products that this request returns.<br />  Default: **online store**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestPackageIds">Optional parameter: A list of the packages IDs to filter by..</param>
        /// <param name="requestSellOnline">Optional parameter: When `true`, only returns products that can be sold online.<br />  When `false`, all products are returned.<br />  Default: **false**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetPackagesResponse response from the API call.</returns>
        public async Task<Models.GetPackagesResponse> GetPackagesAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestPackageIds = null,
                bool? requestSellOnline = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetPackagesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/sale/packages")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.packageIds", requestPackageIds))
                      .Query(_query => _query.Setup("request.sellOnline", requestSellOnline))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Get retail products available for purchase at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestCategoryIds">Optional parameter: A list of revenue category IDs to filter by. Use this ID when calling the GET Categories endpoint..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: The location ID to use to determine the tax for the products that this request returns.<br />  Default: **online store**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProductIds">Optional parameter: The barcode number of the product to be filter by..</param>
        /// <param name="requestSearchText">Optional parameter: A search filter, used for searching by term..</param>
        /// <param name="requestSecondaryCategoryIds">Optional parameter: A list of secondary categories to filter by. Use this ID when calling the GET Categories endpoint..</param>
        /// <param name="requestSellOnline">Optional parameter: When `true`, only products that can be sold online are returned.<br />  When `false`, all products are returned.<br />  Default: **false**.</param>
        /// <param name="requestSubCategoryIds">Optional parameter: A list of subcategory IDs to filter by. Use this ID when calling the GET Categories endpoint..</param>
        /// <returns>Returns the Models.GetProductsResponse response from the API call.</returns>
        public Models.GetProductsResponse GetProducts(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestCategoryIds = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<string> requestProductIds = null,
                string requestSearchText = null,
                List<int> requestSecondaryCategoryIds = null,
                bool? requestSellOnline = null,
                List<int> requestSubCategoryIds = null)
            => CoreHelper.RunTask(GetProductsAsync(version, siteId, authorization, requestCategoryIds, requestLimit, requestLocationId, requestOffset, requestProductIds, requestSearchText, requestSecondaryCategoryIds, requestSellOnline, requestSubCategoryIds));

        /// <summary>
        /// Get retail products available for purchase at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestCategoryIds">Optional parameter: A list of revenue category IDs to filter by. Use this ID when calling the GET Categories endpoint..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: The location ID to use to determine the tax for the products that this request returns.<br />  Default: **online store**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProductIds">Optional parameter: The barcode number of the product to be filter by..</param>
        /// <param name="requestSearchText">Optional parameter: A search filter, used for searching by term..</param>
        /// <param name="requestSecondaryCategoryIds">Optional parameter: A list of secondary categories to filter by. Use this ID when calling the GET Categories endpoint..</param>
        /// <param name="requestSellOnline">Optional parameter: When `true`, only products that can be sold online are returned.<br />  When `false`, all products are returned.<br />  Default: **false**.</param>
        /// <param name="requestSubCategoryIds">Optional parameter: A list of subcategory IDs to filter by. Use this ID when calling the GET Categories endpoint..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetProductsResponse response from the API call.</returns>
        public async Task<Models.GetProductsResponse> GetProductsAsync(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestCategoryIds = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<string> requestProductIds = null,
                string requestSearchText = null,
                List<int> requestSecondaryCategoryIds = null,
                bool? requestSellOnline = null,
                List<int> requestSubCategoryIds = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetProductsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/sale/products")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.categoryIds", requestCategoryIds))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.productIds", requestProductIds))
                      .Query(_query => _query.Setup("request.searchText", requestSearchText))
                      .Query(_query => _query.Setup("request.secondaryCategoryIds", requestSecondaryCategoryIds))
                      .Query(_query => _query.Setup("request.sellOnline", requestSellOnline))
                      .Query(_query => _query.Setup("request.subCategoryIds", requestSubCategoryIds))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Update retail products available for purchase at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateProductsRequests">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.GetProductsResponse response from the API call.</returns>
        public Models.GetProductsResponse UpdateProducts(
                string version,
                string siteId,
                List<Models.UpdateProductRequest> updateProductsRequests,
                string authorization = null)
            => CoreHelper.RunTask(UpdateProductsAsync(version, siteId, updateProductsRequests, authorization));

        /// <summary>
        /// Update retail products available for purchase at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateProductsRequests">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetProductsResponse response from the API call.</returns>
        public async Task<Models.GetProductsResponse> UpdateProductsAsync(
                string version,
                string siteId,
                List<Models.UpdateProductRequest> updateProductsRequests,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetProductsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/public/v{version}/sale/products")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(updateProductsRequests))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Get retail products inventory data available at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestBarcodeIds">Optional parameter: When included, the response only contains details about the specified Barcode Ids..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: When included, the response only contains details about the specified location Ids..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProductIds">Optional parameter: When included, the response only contains details about the specified product Ids..</param>
        /// <returns>Returns the Models.GetProductsInventoryResponse response from the API call.</returns>
        public Models.GetProductsInventoryResponse GetProductsInventory(
                string version,
                string siteId,
                string authorization = null,
                List<string> requestBarcodeIds = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<string> requestProductIds = null)
            => CoreHelper.RunTask(GetProductsInventoryAsync(version, siteId, authorization, requestBarcodeIds, requestLimit, requestLocationIds, requestOffset, requestProductIds));

        /// <summary>
        /// Get retail products inventory data available at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestBarcodeIds">Optional parameter: When included, the response only contains details about the specified Barcode Ids..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: When included, the response only contains details about the specified location Ids..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProductIds">Optional parameter: When included, the response only contains details about the specified product Ids..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetProductsInventoryResponse response from the API call.</returns>
        public async Task<Models.GetProductsInventoryResponse> GetProductsInventoryAsync(
                string version,
                string siteId,
                string authorization = null,
                List<string> requestBarcodeIds = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<string> requestProductIds = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetProductsInventoryResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/sale/productsinventory")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.barcodeIds", requestBarcodeIds))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationIds", requestLocationIds))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.productIds", requestProductIds))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Get sales completed at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndSaleDateTime">Optional parameter: Filters results to sales that happened before this date and time..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestPaymentMethodId">Optional parameter: Filters results to sales paid for by the given payment method ID which indicates payment method(s) (i.e. cash, VISA, AMEX, Check, etc.)..</param>
        /// <param name="requestSaleId">Optional parameter: The sale ID associated with the particular item. It Filters results to the requested sale ID..</param>
        /// <param name="requestStartSaleDateTime">Optional parameter: Filters results to sales that happened after this date and time..</param>
        /// <returns>Returns the Models.GetSalesResponse response from the API call.</returns>
        public Models.GetSalesResponse GetSales(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndSaleDateTime = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestPaymentMethodId = null,
                long? requestSaleId = null,
                DateTime? requestStartSaleDateTime = null)
            => CoreHelper.RunTask(GetSalesAsync(version, siteId, authorization, requestEndSaleDateTime, requestLimit, requestOffset, requestPaymentMethodId, requestSaleId, requestStartSaleDateTime));

        /// <summary>
        /// Get sales completed at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndSaleDateTime">Optional parameter: Filters results to sales that happened before this date and time..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestPaymentMethodId">Optional parameter: Filters results to sales paid for by the given payment method ID which indicates payment method(s) (i.e. cash, VISA, AMEX, Check, etc.)..</param>
        /// <param name="requestSaleId">Optional parameter: The sale ID associated with the particular item. It Filters results to the requested sale ID..</param>
        /// <param name="requestStartSaleDateTime">Optional parameter: Filters results to sales that happened after this date and time..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetSalesResponse response from the API call.</returns>
        public async Task<Models.GetSalesResponse> GetSalesAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndSaleDateTime = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestPaymentMethodId = null,
                long? requestSaleId = null,
                DateTime? requestStartSaleDateTime = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetSalesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/sale/sales")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endSaleDateTime", requestEndSaleDateTime.HasValue ? requestEndSaleDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.paymentMethodId", requestPaymentMethodId))
                      .Query(_query => _query.Setup("request.saleId", requestSaleId))
                      .Query(_query => _query.Setup("request.startSaleDateTime", requestStartSaleDateTime.HasValue ? requestStartSaleDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Get pricing options available for purchase at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassId">Optional parameter: Filters to the pricing options for the specified class ID..</param>
        /// <param name="requestClassScheduleId">Optional parameter: Filters to the pricing options for the specified class schedule ID..</param>
        /// <param name="requestHideRelatedPrograms">Optional parameter: When `true`, indicates that pricing options of related programs are omitted from the response.<br />  Default: **false**.</param>
        /// <param name="requestIncludeDiscontinued">Optional parameter: When `true`, indicates that the filtered pricing option list includes discontinued pricing options.<br />  Default: **false**.</param>
        /// <param name="requestIncludeSaleInContractOnly">Optional parameter: When `true`, indicates that the filtered pricing option list includes sale in contract only pricing options.<br />  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: When specified, for each returned pricing option, `TaxRate` and `TaxIncluded` are calculated according to the specified location. Note that this does not filter results to only services provided at the given location, and for locations where Value-Added Tax (VAT) rules apply, the `TaxRate` is set to zero..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filters to pricing options with the specified program IDs..</param>
        /// <param name="requestSellOnline">Optional parameter: When `true`, filters to the pricing options that can be sold online.<br />  Default: **false**.</param>
        /// <param name="requestServiceIds">Optional parameter: Filters to the pricing options with the specified IDs. In this context, service and pricing option are used interchangeably. These are the `PurchasedItems[].Id` returned from GET Sales..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: Filters to the pricing options with the specified session types IDs..</param>
        /// <param name="requestStaffId">Optional parameter: Sets `Price` and `OnlinePrice` to the particular pricing of a specific staff member, if allowed by the business..</param>
        /// <returns>Returns the Models.GetServicesResponse response from the API call.</returns>
        public Models.GetServicesResponse GetServices(
                string version,
                string siteId,
                string authorization = null,
                int? requestClassId = null,
                int? requestClassScheduleId = null,
                bool? requestHideRelatedPrograms = null,
                bool? requestIncludeDiscontinued = null,
                bool? requestIncludeSaleInContractOnly = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                bool? requestSellOnline = null,
                List<string> requestServiceIds = null,
                List<int> requestSessionTypeIds = null,
                long? requestStaffId = null)
            => CoreHelper.RunTask(GetServicesAsync(version, siteId, authorization, requestClassId, requestClassScheduleId, requestHideRelatedPrograms, requestIncludeDiscontinued, requestIncludeSaleInContractOnly, requestLimit, requestLocationId, requestOffset, requestProgramIds, requestSellOnline, requestServiceIds, requestSessionTypeIds, requestStaffId));

        /// <summary>
        /// Get pricing options available for purchase at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassId">Optional parameter: Filters to the pricing options for the specified class ID..</param>
        /// <param name="requestClassScheduleId">Optional parameter: Filters to the pricing options for the specified class schedule ID..</param>
        /// <param name="requestHideRelatedPrograms">Optional parameter: When `true`, indicates that pricing options of related programs are omitted from the response.<br />  Default: **false**.</param>
        /// <param name="requestIncludeDiscontinued">Optional parameter: When `true`, indicates that the filtered pricing option list includes discontinued pricing options.<br />  Default: **false**.</param>
        /// <param name="requestIncludeSaleInContractOnly">Optional parameter: When `true`, indicates that the filtered pricing option list includes sale in contract only pricing options.<br />  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: When specified, for each returned pricing option, `TaxRate` and `TaxIncluded` are calculated according to the specified location. Note that this does not filter results to only services provided at the given location, and for locations where Value-Added Tax (VAT) rules apply, the `TaxRate` is set to zero..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filters to pricing options with the specified program IDs..</param>
        /// <param name="requestSellOnline">Optional parameter: When `true`, filters to the pricing options that can be sold online.<br />  Default: **false**.</param>
        /// <param name="requestServiceIds">Optional parameter: Filters to the pricing options with the specified IDs. In this context, service and pricing option are used interchangeably. These are the `PurchasedItems[].Id` returned from GET Sales..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: Filters to the pricing options with the specified session types IDs..</param>
        /// <param name="requestStaffId">Optional parameter: Sets `Price` and `OnlinePrice` to the particular pricing of a specific staff member, if allowed by the business..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetServicesResponse response from the API call.</returns>
        public async Task<Models.GetServicesResponse> GetServicesAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestClassId = null,
                int? requestClassScheduleId = null,
                bool? requestHideRelatedPrograms = null,
                bool? requestIncludeDiscontinued = null,
                bool? requestIncludeSaleInContractOnly = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                bool? requestSellOnline = null,
                List<string> requestServiceIds = null,
                List<int> requestSessionTypeIds = null,
                long? requestStaffId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetServicesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/sale/services")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.classId", requestClassId))
                      .Query(_query => _query.Setup("request.classScheduleId", requestClassScheduleId))
                      .Query(_query => _query.Setup("request.hideRelatedPrograms", requestHideRelatedPrograms))
                      .Query(_query => _query.Setup("request.includeDiscontinued", requestIncludeDiscontinued))
                      .Query(_query => _query.Setup("request.includeSaleInContractOnly", requestIncludeSaleInContractOnly))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.programIds", requestProgramIds))
                      .Query(_query => _query.Setup("request.sellOnline", requestSellOnline))
                      .Query(_query => _query.Setup("request.serviceIds", requestServiceIds))
                      .Query(_query => _query.Setup("request.sessionTypeIds", requestSessionTypeIds))
                      .Query(_query => _query.Setup("request.staffId", requestStaffId))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Update unit price and online price of provided services.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateServicesRequest">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.UpdateServiceResponse response from the API call.</returns>
        public Models.UpdateServiceResponse UpdateServices(
                string version,
                string siteId,
                List<Models.UpdateServiceRequest> updateServicesRequest,
                string authorization = null)
            => CoreHelper.RunTask(UpdateServicesAsync(version, siteId, updateServicesRequest, authorization));

        /// <summary>
        /// Update unit price and online price of provided services.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateServicesRequest">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UpdateServiceResponse response from the API call.</returns>
        public async Task<Models.UpdateServiceResponse> UpdateServicesAsync(
                string version,
                string siteId,
                List<Models.UpdateServiceRequest> updateServicesRequest,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.UpdateServiceResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/public/v{version}/sale/services")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(updateServicesRequest))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint returns a list of transaction details of processed sales.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientId">Optional parameter: Filters results to the requested client ID..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters the transaction results with the ID number associated with the location of the sale..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSaleId">Optional parameter: Filters the transaction results with the ID number associated with the sale..</param>
        /// <param name="requestStatus">Optional parameter: Filters the transaction results by the estimated transaction status..</param>
        /// <param name="requestTransactionEndDateTime">Optional parameter: Filters the transaction results that happpened before this date and time.   Default: **today’s date**.</param>
        /// <param name="requestTransactionId">Optional parameter: Filters the transaction results with the ID number generated when the sale is processed..</param>
        /// <param name="requestTransactionStartDateTime">Optional parameter: Filters the transaction results that happpened after this date and time.   Default: **today’s date**.</param>
        /// <returns>Returns the Models.GetTransactionsResponse response from the API call.</returns>
        public Models.GetTransactionsResponse GetTransactions(
                string version,
                string siteId,
                string authorization = null,
                long? requestClientId = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                long? requestSaleId = null,
                string requestStatus = null,
                DateTime? requestTransactionEndDateTime = null,
                int? requestTransactionId = null,
                DateTime? requestTransactionStartDateTime = null)
            => CoreHelper.RunTask(GetTransactionsAsync(version, siteId, authorization, requestClientId, requestLimit, requestLocationId, requestOffset, requestSaleId, requestStatus, requestTransactionEndDateTime, requestTransactionId, requestTransactionStartDateTime));

        /// <summary>
        /// This endpoint returns a list of transaction details of processed sales.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClientId">Optional parameter: Filters results to the requested client ID..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters the transaction results with the ID number associated with the location of the sale..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSaleId">Optional parameter: Filters the transaction results with the ID number associated with the sale..</param>
        /// <param name="requestStatus">Optional parameter: Filters the transaction results by the estimated transaction status..</param>
        /// <param name="requestTransactionEndDateTime">Optional parameter: Filters the transaction results that happpened before this date and time.   Default: **today’s date**.</param>
        /// <param name="requestTransactionId">Optional parameter: Filters the transaction results with the ID number generated when the sale is processed..</param>
        /// <param name="requestTransactionStartDateTime">Optional parameter: Filters the transaction results that happpened after this date and time.   Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetTransactionsResponse response from the API call.</returns>
        public async Task<Models.GetTransactionsResponse> GetTransactionsAsync(
                string version,
                string siteId,
                string authorization = null,
                long? requestClientId = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                long? requestSaleId = null,
                string requestStatus = null,
                DateTime? requestTransactionEndDateTime = null,
                int? requestTransactionId = null,
                DateTime? requestTransactionStartDateTime = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetTransactionsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/sale/transactions")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.saleId", requestSaleId))
                      .Query(_query => _query.Setup("request.status", requestStatus))
                      .Query(_query => _query.Setup("request.transactionEndDateTime", requestTransactionEndDateTime.HasValue ? requestTransactionEndDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.transactionId", requestTransactionId))
                      .Query(_query => _query.Setup("request.transactionStartDateTime", requestTransactionStartDateTime.HasValue ? requestTransactionStartDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint provides a wide range of functionality. For example, you can use it when a client purchases new pricing options, retail products, packages, and tips. You can also combine purchasing a new pricing option and many other functions, such as booking a client into a class, booking a new appointment for a client, enrolling a client into an enrollment or course, or reconciling an unpaid, already booked appointment or class. Use this call when a client purchases:.
        /// * a pricing option, after calling `GET Services` and choosing a specific pricing option’s ID.
        /// * a retail product, after calling `GET Products` and choosing a specific retail product’s ID.
        /// * a package, after calling `GET Packages` and choosing a specific package’s ID.
        /// * a tip to give to a staff member, after calling `GET Staff` and choosing a specific staff member ID, and the amount that the client wants to tip.
        /// The documentation provides explanations of the request body and response, as well as the cart item metadata, payment item metadata, and purchased cart items.
        /// This endpoint had been updated to support Strong Customer Authentication (SCA).
        /// **Note :**.
        /// Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.CheckoutShoppingCartResponse response from the API call.</returns>
        public Models.CheckoutShoppingCartResponse CheckoutShoppingCart(
                string version,
                Models.CheckoutShoppingCartRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(CheckoutShoppingCartAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint provides a wide range of functionality. For example, you can use it when a client purchases new pricing options, retail products, packages, and tips. You can also combine purchasing a new pricing option and many other functions, such as booking a client into a class, booking a new appointment for a client, enrolling a client into an enrollment or course, or reconciling an unpaid, already booked appointment or class. Use this call when a client purchases:.
        /// * a pricing option, after calling `GET Services` and choosing a specific pricing option’s ID.
        /// * a retail product, after calling `GET Products` and choosing a specific retail product’s ID.
        /// * a package, after calling `GET Packages` and choosing a specific package’s ID.
        /// * a tip to give to a staff member, after calling `GET Staff` and choosing a specific staff member ID, and the amount that the client wants to tip.
        /// The documentation provides explanations of the request body and response, as well as the cart item metadata, payment item metadata, and purchased cart items.
        /// This endpoint had been updated to support Strong Customer Authentication (SCA).
        /// **Note :**.
        /// Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CheckoutShoppingCartResponse response from the API call.</returns>
        public async Task<Models.CheckoutShoppingCartResponse> CheckoutShoppingCartAsync(
                string version,
                Models.CheckoutShoppingCartRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CheckoutShoppingCartResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/sale/checkoutshoppingcart")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Initiates purchase contract workflow for a client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object InitiatePurchaseContract(
                string version,
                Models.InitiatePurchaseContractRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(InitiatePurchaseContractAsync(version, request, siteId, authorization));

        /// <summary>
        /// Initiates purchase contract workflow for a client.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> InitiatePurchaseContractAsync(
                string version,
                Models.InitiatePurchaseContractRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/sale/initiatepurchasecontract")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Allows a client to purchase account credit from a business.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.PurchaseAccountCreditResponse response from the API call.</returns>
        public Models.PurchaseAccountCreditResponse PurchaseAccountCredit(
                string version,
                Models.PurchaseAccountCreditRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PurchaseAccountCreditAsync(version, request, siteId, authorization));

        /// <summary>
        /// Allows a client to purchase account credit from a business.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PurchaseAccountCreditResponse response from the API call.</returns>
        public async Task<Models.PurchaseAccountCreditResponse> PurchaseAccountCreditAsync(
                string version,
                Models.PurchaseAccountCreditRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PurchaseAccountCreditResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/sale/purchaseaccountcredit")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Allows a client to sign up for a contract or autopay using the information returned from the `GET Contracts` endpoint. The client can pay with a new credit card or with a stored credit card. The client must exist at the site specified before this call is made.
        /// This endpoint allows a developer to specify whether a client pays now or pays on the `StartDate`.If you are building a client-facing experience, you should talk with the business owner to understand the owner’s policies before you give clients a choice of the two payment types.
        /// This endpoint had been updated to support Strong Customer Authentication (SCA).
        /// **Note**.
        /// Protect yourself from processor fees and credit card fraud. Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.PurchaseContractResponse response from the API call.</returns>
        public Models.PurchaseContractResponse PurchaseContract(
                string version,
                Models.PurchaseContractRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PurchaseContractAsync(version, request, siteId, authorization));

        /// <summary>
        /// Allows a client to sign up for a contract or autopay using the information returned from the `GET Contracts` endpoint. The client can pay with a new credit card or with a stored credit card. The client must exist at the site specified before this call is made.
        /// This endpoint allows a developer to specify whether a client pays now or pays on the `StartDate`.If you are building a client-facing experience, you should talk with the business owner to understand the owner’s policies before you give clients a choice of the two payment types.
        /// This endpoint had been updated to support Strong Customer Authentication (SCA).
        /// **Note**.
        /// Protect yourself from processor fees and credit card fraud. Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PurchaseContractResponse response from the API call.</returns>
        public async Task<Models.PurchaseContractResponse> PurchaseContractAsync(
                string version,
                Models.PurchaseContractRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PurchaseContractResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/sale/purchasecontract")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        ///  Allows a client to purchase a gift card from a business in a variety of designs. The card can be emailed to the recipient on a specific day, and a card title and a personal message can be added.
        ///  **Note**.
        /// Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.PurchaseGiftCardResponse response from the API call.</returns>
        public Models.PurchaseGiftCardResponse PurchaseGiftCard(
                string version,
                Models.PurchaseGiftCardRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PurchaseGiftCardAsync(version, request, siteId, authorization));

        /// <summary>
        ///  Allows a client to purchase a gift card from a business in a variety of designs. The card can be emailed to the recipient on a specific day, and a card title and a personal message can be added.
        ///  **Note**.
        /// Protect yourself from processor fees and credit card fraud.Remember to always protect your web forms that leverage POST CheckoutShoppingCart, POST PurchaseContract or POST PurchaseGiftCard with a CAPTCHA!.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.PurchaseGiftCardResponse response from the API call.</returns>
        public async Task<Models.PurchaseGiftCardResponse> PurchaseGiftCardAsync(
                string version,
                Models.PurchaseGiftCardRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.PurchaseGiftCardResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/sale/purchasegiftcard")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Return a comped sale for a specified sale ID in business mode. The sale is returnable only if it is a sale of a service, product or gift card and it has not been used. Currently, only the comp payment method is supported.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="returnSaleRequest">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.ReturnSaleResponse response from the API call.</returns>
        public Models.ReturnSaleResponse ReturnSale(
                string version,
                Models.ReturnSaleRequest returnSaleRequest,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(ReturnSaleAsync(version, returnSaleRequest, siteId, authorization));

        /// <summary>
        /// Return a comped sale for a specified sale ID in business mode. The sale is returnable only if it is a sale of a service, product or gift card and it has not been used. Currently, only the comp payment method is supported.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="returnSaleRequest">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ReturnSaleResponse response from the API call.</returns>
        public async Task<Models.ReturnSaleResponse> ReturnSaleAsync(
                string version,
                Models.ReturnSaleRequest returnSaleRequest,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ReturnSaleResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/sale/returnsale")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(returnSaleRequest))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint updates the retail price and an online price for a product. Passing at least one of them is mandatory.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.UpdateProductPriceResponse response from the API call.</returns>
        public Models.UpdateProductPriceResponse UpdateProductPrice(
                string version,
                Models.UpdateProductPriceRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateProductPriceAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint updates the retail price and an online price for a product. Passing at least one of them is mandatory.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UpdateProductPriceResponse response from the API call.</returns>
        public async Task<Models.UpdateProductPriceResponse> UpdateProductPriceAsync(
                string version,
                Models.UpdateProductPriceRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.UpdateProductPriceResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/sale/updateproductprice")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint updates the SaleDate and returns the details of the sale.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.UpdateSaleDateResponse response from the API call.</returns>
        public Models.UpdateSaleDateResponse UpdateSaleDate(
                string version,
                Models.UpdateSaleDateRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateSaleDateAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint updates the SaleDate and returns the details of the sale.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UpdateSaleDateResponse response from the API call.</returns>
        public async Task<Models.UpdateSaleDateResponse> UpdateSaleDateAsync(
                string version,
                Models.UpdateSaleDateRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.UpdateSaleDateResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/public/v{version}/sale/updatesaledate")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}