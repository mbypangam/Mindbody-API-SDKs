// <copyright file="PickASpotvController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// PickASpotvController.
    /// </summary>
    public class PickASpotvController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PickASpotvController"/> class.
        /// </summary>
        internal PickASpotvController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// PickASpotv_ClassList EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object PickASpotvClassList(
                string version,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PickASpotvClassListAsync(version, siteId, authorization));

        /// <summary>
        /// PickASpotv_ClassList EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> PickASpotvClassListAsync(
                string version,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/pickaspot/v1/class")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// PickASpotv_Class EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="classId">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object PickASpotvClass(
                string version,
                string classId,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PickASpotvClassAsync(version, classId, siteId, authorization));

        /// <summary>
        /// PickASpotv_Class EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="classId">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> PickASpotvClassAsync(
                string version,
                string classId,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/pickaspot/v1/class/{classId}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("classId", classId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// PickASpotv_ReservationGet EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object PickASpotvReservationGet(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PickASpotvReservationGetAsync(version, pathInfo, siteId, authorization));

        /// <summary>
        /// PickASpotv_ReservationGet EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> PickASpotvReservationGetAsync(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/pickaspot/v1/reservation/{pathInfo}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("pathInfo", pathInfo))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// PickASpotv_ReservationPut EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object PickASpotvReservationPut(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PickASpotvReservationPutAsync(version, pathInfo, siteId, authorization));

        /// <summary>
        /// PickASpotv_ReservationPut EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> PickASpotvReservationPutAsync(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/public/v{version}/pickaspot/v1/reservation/{pathInfo}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("pathInfo", pathInfo))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// PickASpotv_ReservationPost EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object PickASpotvReservationPost(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PickASpotvReservationPostAsync(version, pathInfo, siteId, authorization));

        /// <summary>
        /// PickASpotv_ReservationPost EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> PickASpotvReservationPostAsync(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/pickaspot/v1/reservation/{pathInfo}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("pathInfo", pathInfo))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// PickASpotv_ReservationDelete EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object PickASpotvReservationDelete(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(PickASpotvReservationDeleteAsync(version, pathInfo, siteId, authorization));

        /// <summary>
        /// PickASpotv_ReservationDelete EndPoint.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="pathInfo">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> PickASpotvReservationDeleteAsync(
                string version,
                string pathInfo,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/public/v{version}/pickaspot/v1/reservation/{pathInfo}")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Template(_template => _template.Setup("pathInfo", pathInfo))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);
    }
}