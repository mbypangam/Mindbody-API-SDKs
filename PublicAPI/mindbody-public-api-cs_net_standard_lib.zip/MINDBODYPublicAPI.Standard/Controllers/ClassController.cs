// <copyright file="ClassController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// ClassController.
    /// </summary>
    public class ClassController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClassController"/> class.
        /// </summary>
        internal ClassController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// To find class descriptions associated with **scheduled classes**, pass `StaffId`, `StartClassDateTime`, `EndClassDateTime`, or `LocationId` in the request.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassDescriptionId">Optional parameter: The ID of the requested client..</param>
        /// <param name="requestEndClassDateTime">Optional parameter: Filters the results to class descriptions for scheduled classes that happen before the given date and time..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to classes descriptions for schedule classes as the given location..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: A list of requested program IDs..</param>
        /// <param name="requestStaffId">Optional parameter: Filters results to class descriptions for scheduled classes taught by the given staff member..</param>
        /// <param name="requestStartClassDateTime">Optional parameter: Filters the results to class descriptions for scheduled classes that happen on or after the given date and time..</param>
        /// <returns>Returns the Models.GetClassDescriptionsResponse response from the API call.</returns>
        public Models.GetClassDescriptionsResponse GetClassDescriptions(
                string version,
                string siteId,
                string authorization = null,
                int? requestClassDescriptionId = null,
                DateTime? requestEndClassDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                long? requestStaffId = null,
                DateTime? requestStartClassDateTime = null)
            => CoreHelper.RunTask(GetClassDescriptionsAsync(version, siteId, authorization, requestClassDescriptionId, requestEndClassDateTime, requestLimit, requestLocationId, requestOffset, requestProgramIds, requestStaffId, requestStartClassDateTime));

        /// <summary>
        /// To find class descriptions associated with **scheduled classes**, pass `StaffId`, `StartClassDateTime`, `EndClassDateTime`, or `LocationId` in the request.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassDescriptionId">Optional parameter: The ID of the requested client..</param>
        /// <param name="requestEndClassDateTime">Optional parameter: Filters the results to class descriptions for scheduled classes that happen before the given date and time..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: Filters results to classes descriptions for schedule classes as the given location..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: A list of requested program IDs..</param>
        /// <param name="requestStaffId">Optional parameter: Filters results to class descriptions for scheduled classes taught by the given staff member..</param>
        /// <param name="requestStartClassDateTime">Optional parameter: Filters the results to class descriptions for scheduled classes that happen on or after the given date and time..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClassDescriptionsResponse response from the API call.</returns>
        public async Task<Models.GetClassDescriptionsResponse> GetClassDescriptionsAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestClassDescriptionId = null,
                DateTime? requestEndClassDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                long? requestStaffId = null,
                DateTime? requestStartClassDateTime = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClassDescriptionsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/class/classdescriptions")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.classDescriptionId", requestClassDescriptionId))
                      .Query(_query => _query.Setup("request.endClassDateTime", requestEndClassDateTime.HasValue ? requestEndClassDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.programIds", requestProgramIds))
                      .Query(_query => _query.Setup("request.staffId", requestStaffId))
                      .Query(_query => _query.Setup("request.startClassDateTime", requestStartClassDateTime.HasValue ? requestStartClassDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get scheduled classes.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassDescriptionIds">Optional parameter: The requested class description IDs..</param>
        /// <param name="requestClassIds">Optional parameter: The requested class IDs..</param>
        /// <param name="requestClassScheduleIds">Optional parameter: The requested classSchedule Ids..</param>
        /// <param name="requestClientId">Optional parameter: The client ID of the client who is viewing this class list. Based on identity, the client may be able to see additional information, such as membership specials..</param>
        /// <param name="requestEndDateTime">Optional parameter: The requested end date for filtering.  <br />Default: **today’s date**.</param>
        /// <param name="requestHideCanceledClasses">Optional parameter: When `true`, canceled classes are removed from the response.<br />  When `false`, canceled classes are included in the response.<br />  Default: **false**.</param>
        /// <param name="requestLastModifiedDate">Optional parameter: When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of location IDs on which to base the search..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: A list of program IDs on which to base the search..</param>
        /// <param name="requestSchedulingWindow">Optional parameter: When `true`, classes outside scheduling window are removed from the response.<br />  When `false`, classes are included in the response, regardless of the scheduling window.<br />  Default: **false**.</param>
        /// <param name="requestSemesterIds">Optional parameter: A list of semester IDs on which to base the search..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: A list of session type IDs on which to base the search..</param>
        /// <param name="requestStaffIds">Optional parameter: The requested IDs of the teaching staff members..</param>
        /// <param name="requestStartDateTime">Optional parameter: The requested start date for filtering. This also determines what you will see for the ‘BookingWindow’ StartDateTime in the response. For example, if you pass a StartDateTime that is on OR before the BookingWindow ‘Open’ days of the class, you will retrieve the actual ‘StartDateTime’ for the Booking Window. If you pass a StartDateTime that is after the BookingWindow ‘date’, then you will receive results based on that start date..</param>
        /// <returns>Returns the Models.GetClassesResponse response from the API call.</returns>
        public Models.GetClassesResponse GetClasses(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestClassDescriptionIds = null,
                List<int> requestClassIds = null,
                List<int> requestClassScheduleIds = null,
                string requestClientId = null,
                DateTime? requestEndDateTime = null,
                bool? requestHideCanceledClasses = null,
                DateTime? requestLastModifiedDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                bool? requestSchedulingWindow = null,
                List<int> requestSemesterIds = null,
                List<int> requestSessionTypeIds = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDateTime = null)
            => CoreHelper.RunTask(GetClassesAsync(version, siteId, authorization, requestClassDescriptionIds, requestClassIds, requestClassScheduleIds, requestClientId, requestEndDateTime, requestHideCanceledClasses, requestLastModifiedDate, requestLimit, requestLocationIds, requestOffset, requestProgramIds, requestSchedulingWindow, requestSemesterIds, requestSessionTypeIds, requestStaffIds, requestStartDateTime));

        /// <summary>
        /// Get scheduled classes.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassDescriptionIds">Optional parameter: The requested class description IDs..</param>
        /// <param name="requestClassIds">Optional parameter: The requested class IDs..</param>
        /// <param name="requestClassScheduleIds">Optional parameter: The requested classSchedule Ids..</param>
        /// <param name="requestClientId">Optional parameter: The client ID of the client who is viewing this class list. Based on identity, the client may be able to see additional information, such as membership specials..</param>
        /// <param name="requestEndDateTime">Optional parameter: The requested end date for filtering.  <br />Default: **today’s date**.</param>
        /// <param name="requestHideCanceledClasses">Optional parameter: When `true`, canceled classes are removed from the response.<br />  When `false`, canceled classes are included in the response.<br />  Default: **false**.</param>
        /// <param name="requestLastModifiedDate">Optional parameter: When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of location IDs on which to base the search..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: A list of program IDs on which to base the search..</param>
        /// <param name="requestSchedulingWindow">Optional parameter: When `true`, classes outside scheduling window are removed from the response.<br />  When `false`, classes are included in the response, regardless of the scheduling window.<br />  Default: **false**.</param>
        /// <param name="requestSemesterIds">Optional parameter: A list of semester IDs on which to base the search..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: A list of session type IDs on which to base the search..</param>
        /// <param name="requestStaffIds">Optional parameter: The requested IDs of the teaching staff members..</param>
        /// <param name="requestStartDateTime">Optional parameter: The requested start date for filtering. This also determines what you will see for the ‘BookingWindow’ StartDateTime in the response. For example, if you pass a StartDateTime that is on OR before the BookingWindow ‘Open’ days of the class, you will retrieve the actual ‘StartDateTime’ for the Booking Window. If you pass a StartDateTime that is after the BookingWindow ‘date’, then you will receive results based on that start date..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClassesResponse response from the API call.</returns>
        public async Task<Models.GetClassesResponse> GetClassesAsync(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestClassDescriptionIds = null,
                List<int> requestClassIds = null,
                List<int> requestClassScheduleIds = null,
                string requestClientId = null,
                DateTime? requestEndDateTime = null,
                bool? requestHideCanceledClasses = null,
                DateTime? requestLastModifiedDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                bool? requestSchedulingWindow = null,
                List<int> requestSemesterIds = null,
                List<int> requestSessionTypeIds = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDateTime = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClassesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/class/classes")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.classDescriptionIds", requestClassDescriptionIds))
                      .Query(_query => _query.Setup("request.classIds", requestClassIds))
                      .Query(_query => _query.Setup("request.classScheduleIds", requestClassScheduleIds))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Query(_query => _query.Setup("request.endDateTime", requestEndDateTime.HasValue ? requestEndDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.hideCanceledClasses", requestHideCanceledClasses))
                      .Query(_query => _query.Setup("request.lastModifiedDate", requestLastModifiedDate.HasValue ? requestLastModifiedDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationIds", requestLocationIds))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.programIds", requestProgramIds))
                      .Query(_query => _query.Setup("request.schedulingWindow", requestSchedulingWindow))
                      .Query(_query => _query.Setup("request.semesterIds", requestSemesterIds))
                      .Query(_query => _query.Setup("request.sessionTypeIds", requestSessionTypeIds))
                      .Query(_query => _query.Setup("request.staffIds", requestStaffIds))
                      .Query(_query => _query.Setup("request.startDateTime", requestStartDateTime.HasValue ? requestStartDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get class schedules.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassScheduleIds">Optional parameter: The class schedule IDs.  <br />Default: **all**.</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the range. Return any active enrollments that occur on or before this day.  <br />Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: The location IDs.   <br />Default: **all**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: The program IDs.   <br />Default: **all**.</param>
        /// <param name="requestSessionTypeIds">Optional parameter: The session type IDs.   <br />Default: **all**.</param>
        /// <param name="requestStaffIds">Optional parameter: The staff IDs.   <br />Default: **all**.</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the range. Return any active enrollments that occur on or after this day.  <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.GetClassSchedulesResponse response from the API call.</returns>
        public Models.GetClassSchedulesResponse GetClassSchedules(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestClassScheduleIds = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                List<int> requestSessionTypeIds = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(GetClassSchedulesAsync(version, siteId, authorization, requestClassScheduleIds, requestEndDate, requestLimit, requestLocationIds, requestOffset, requestProgramIds, requestSessionTypeIds, requestStaffIds, requestStartDate));

        /// <summary>
        /// Get class schedules.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassScheduleIds">Optional parameter: The class schedule IDs.  <br />Default: **all**.</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the range. Return any active enrollments that occur on or before this day.  <br />Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: The location IDs.   <br />Default: **all**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: The program IDs.   <br />Default: **all**.</param>
        /// <param name="requestSessionTypeIds">Optional parameter: The session type IDs.   <br />Default: **all**.</param>
        /// <param name="requestStaffIds">Optional parameter: The staff IDs.   <br />Default: **all**.</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the range. Return any active enrollments that occur on or after this day.  <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClassSchedulesResponse response from the API call.</returns>
        public async Task<Models.GetClassSchedulesResponse> GetClassSchedulesAsync(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestClassScheduleIds = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                List<int> requestSessionTypeIds = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClassSchedulesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/class/classschedules")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.classScheduleIds", requestClassScheduleIds))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationIds", requestLocationIds))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.programIds", requestProgramIds))
                      .Query(_query => _query.Setup("request.sessionTypeIds", requestSessionTypeIds))
                      .Query(_query => _query.Setup("request.staffIds", requestStaffIds))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Returns a list of visits that contain information for a specified class. On success, this request returns the class object in the response with a list of visits.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClassID">Required parameter: The class ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLastModifiedDate">Optional parameter: When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response..</param>
        /// <returns>Returns the Models.GetClassVisitsResponse response from the API call.</returns>
        public Models.GetClassVisitsResponse GetClassVisits(
                string version,
                long requestClassID,
                string siteId,
                string authorization = null,
                DateTime? requestLastModifiedDate = null)
            => CoreHelper.RunTask(GetClassVisitsAsync(version, requestClassID, siteId, authorization, requestLastModifiedDate));

        /// <summary>
        /// Returns a list of visits that contain information for a specified class. On success, this request returns the class object in the response with a list of visits.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestClassID">Required parameter: The class ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLastModifiedDate">Optional parameter: When included in the request, only records modified on or after the `LastModifiedDate` specified are included in the response..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetClassVisitsResponse response from the API call.</returns>
        public async Task<Models.GetClassVisitsResponse> GetClassVisitsAsync(
                string version,
                long requestClassID,
                string siteId,
                string authorization = null,
                DateTime? requestLastModifiedDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetClassVisitsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/class/classvisits")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.classID", requestClassID))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.lastModifiedDate", requestLastModifiedDate.HasValue ? requestLastModifiedDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// This endpoint will provide all the data related to courses depending on the access level.<br />.
        /// Note: The Authorization is an optional header.If Authorization header is not passed, the response will be masked else full response will be provided.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="getCoursesRequestCourseIDs">Optional parameter: Return only courses that are available for the specified CourseIds..</param>
        /// <param name="getCoursesRequestEndDate">Optional parameter: The end date range. Any active courses that are on or before this day.  <br />(optional) Defaults to StartDate..</param>
        /// <param name="getCoursesRequestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="getCoursesRequestLocationIDs">Optional parameter: Return only courses that are available for the specified LocationIds..</param>
        /// <param name="getCoursesRequestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="getCoursesRequestProgramIDs">Optional parameter: Return only courses that are available for the specified ProgramIds..</param>
        /// <param name="getCoursesRequestSemesterIDs">Optional parameter: Return only courses that are available for the specified SemesterIds..</param>
        /// <param name="getCoursesRequestStaffIDs">Optional parameter: Return only courses that are available for the specified StaffIds..</param>
        /// <param name="getCoursesRequestStartDate">Optional parameter: The start date range. Any active courses that are on or after this day.  <br />(optional) Defaults to today..</param>
        /// <returns>Returns the Models.GetCoursesReponse response from the API call.</returns>
        public Models.GetCoursesReponse GetCourses(
                string version,
                string siteId,
                string authorization = null,
                List<long> getCoursesRequestCourseIDs = null,
                DateTime? getCoursesRequestEndDate = null,
                int? getCoursesRequestLimit = null,
                List<int> getCoursesRequestLocationIDs = null,
                int? getCoursesRequestOffset = null,
                List<int> getCoursesRequestProgramIDs = null,
                List<int> getCoursesRequestSemesterIDs = null,
                List<long> getCoursesRequestStaffIDs = null,
                DateTime? getCoursesRequestStartDate = null)
            => CoreHelper.RunTask(GetCoursesAsync(version, siteId, authorization, getCoursesRequestCourseIDs, getCoursesRequestEndDate, getCoursesRequestLimit, getCoursesRequestLocationIDs, getCoursesRequestOffset, getCoursesRequestProgramIDs, getCoursesRequestSemesterIDs, getCoursesRequestStaffIDs, getCoursesRequestStartDate));

        /// <summary>
        /// This endpoint will provide all the data related to courses depending on the access level.<br />.
        /// Note: The Authorization is an optional header.If Authorization header is not passed, the response will be masked else full response will be provided.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="getCoursesRequestCourseIDs">Optional parameter: Return only courses that are available for the specified CourseIds..</param>
        /// <param name="getCoursesRequestEndDate">Optional parameter: The end date range. Any active courses that are on or before this day.  <br />(optional) Defaults to StartDate..</param>
        /// <param name="getCoursesRequestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="getCoursesRequestLocationIDs">Optional parameter: Return only courses that are available for the specified LocationIds..</param>
        /// <param name="getCoursesRequestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="getCoursesRequestProgramIDs">Optional parameter: Return only courses that are available for the specified ProgramIds..</param>
        /// <param name="getCoursesRequestSemesterIDs">Optional parameter: Return only courses that are available for the specified SemesterIds..</param>
        /// <param name="getCoursesRequestStaffIDs">Optional parameter: Return only courses that are available for the specified StaffIds..</param>
        /// <param name="getCoursesRequestStartDate">Optional parameter: The start date range. Any active courses that are on or after this day.  <br />(optional) Defaults to today..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetCoursesReponse response from the API call.</returns>
        public async Task<Models.GetCoursesReponse> GetCoursesAsync(
                string version,
                string siteId,
                string authorization = null,
                List<long> getCoursesRequestCourseIDs = null,
                DateTime? getCoursesRequestEndDate = null,
                int? getCoursesRequestLimit = null,
                List<int> getCoursesRequestLocationIDs = null,
                int? getCoursesRequestOffset = null,
                List<int> getCoursesRequestProgramIDs = null,
                List<int> getCoursesRequestSemesterIDs = null,
                List<long> getCoursesRequestStaffIDs = null,
                DateTime? getCoursesRequestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetCoursesReponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/class/courses")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("getCoursesRequest.courseIDs", getCoursesRequestCourseIDs))
                      .Query(_query => _query.Setup("getCoursesRequest.endDate", getCoursesRequestEndDate.HasValue ? getCoursesRequestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("getCoursesRequest.limit", getCoursesRequestLimit))
                      .Query(_query => _query.Setup("getCoursesRequest.locationIDs", getCoursesRequestLocationIDs))
                      .Query(_query => _query.Setup("getCoursesRequest.offset", getCoursesRequestOffset))
                      .Query(_query => _query.Setup("getCoursesRequest.programIDs", getCoursesRequestProgramIDs))
                      .Query(_query => _query.Setup("getCoursesRequest.semesterIDs", getCoursesRequestSemesterIDs))
                      .Query(_query => _query.Setup("getCoursesRequest.staffIDs", getCoursesRequestStaffIDs))
                      .Query(_query => _query.Setup("getCoursesRequest.startDate", getCoursesRequestStartDate.HasValue ? getCoursesRequestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// This endpoint retrieves the business class semesters.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When true, the response only contains semesters which are activated. When false, only deactivated semesters are returned.  Default: **All semesters**.</param>
        /// <param name="requestEndDate">Optional parameter: The end date for the range. All semesters that are on or before this day.  Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSemesterIDs">Optional parameter: The requested semester IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date for the range. All semesters that are on or after this day.  Default: **today’s date**.</param>
        /// <returns>Returns the Models.GetSemestersResponse response from the API call.</returns>
        public Models.GetSemestersResponse GetSemesters(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSemesterIDs = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(GetSemestersAsync(version, siteId, authorization, requestActive, requestEndDate, requestLimit, requestOffset, requestSemesterIDs, requestStartDate));

        /// <summary>
        /// This endpoint retrieves the business class semesters.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When true, the response only contains semesters which are activated. When false, only deactivated semesters are returned.  Default: **All semesters**.</param>
        /// <param name="requestEndDate">Optional parameter: The end date for the range. All semesters that are on or before this day.  Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSemesterIDs">Optional parameter: The requested semester IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date for the range. All semesters that are on or after this day.  Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetSemestersResponse response from the API call.</returns>
        public async Task<Models.GetSemestersResponse> GetSemestersAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSemesterIDs = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetSemestersResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/class/semesters")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.active", requestActive))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.semesterIDs", requestSemesterIDs))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Returns a list of waiting list entries for a specified class schedule or class. The request requires staff credentials and either a class schedule ID or class ID.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassIds">Optional parameter: The requested class IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request. <br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all ClassIds**.</param>
        /// <param name="requestClassScheduleIds">Optional parameter: The requested class schedule IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request.<br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all ClassScheduleIds**.</param>
        /// <param name="requestClientIds">Optional parameter: The requested client IDs.<br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all ClientIds**.</param>
        /// <param name="requestHidePastEntries">Optional parameter: When `true`, indicates that past waiting list entries are hidden from clients.<br />  When `false`, indicates that past entries are not hidden from clients.<br />  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestWaitlistEntryIds">Optional parameter: The requested waiting list entry IDs.<br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all WaitlistEntryIds**.</param>
        /// <returns>Returns the Models.GetWaitlistEntriesResponse response from the API call.</returns>
        public Models.GetWaitlistEntriesResponse GetWaitlistEntries(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestClassIds = null,
                List<int> requestClassScheduleIds = null,
                List<string> requestClientIds = null,
                bool? requestHidePastEntries = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestWaitlistEntryIds = null)
            => CoreHelper.RunTask(GetWaitlistEntriesAsync(version, siteId, authorization, requestClassIds, requestClassScheduleIds, requestClientIds, requestHidePastEntries, requestLimit, requestOffset, requestWaitlistEntryIds));

        /// <summary>
        /// Returns a list of waiting list entries for a specified class schedule or class. The request requires staff credentials and either a class schedule ID or class ID.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestClassIds">Optional parameter: The requested class IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request. <br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all ClassIds**.</param>
        /// <param name="requestClassScheduleIds">Optional parameter: The requested class schedule IDs. If a class ID is present, the request automatically disregards any class schedule IDs in the request.<br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all ClassScheduleIds**.</param>
        /// <param name="requestClientIds">Optional parameter: The requested client IDs.<br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all ClientIds**.</param>
        /// <param name="requestHidePastEntries">Optional parameter: When `true`, indicates that past waiting list entries are hidden from clients.<br />  When `false`, indicates that past entries are not hidden from clients.<br />  Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestWaitlistEntryIds">Optional parameter: The requested waiting list entry IDs.<br />  Either `ClassScheduleIds`, `ClientIds`, `WaitlistEntryIds`, or `ClassIds` is required; the others become optional.<br />  Default: **all WaitlistEntryIds**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetWaitlistEntriesResponse response from the API call.</returns>
        public async Task<Models.GetWaitlistEntriesResponse> GetWaitlistEntriesAsync(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestClassIds = null,
                List<int> requestClassScheduleIds = null,
                List<string> requestClientIds = null,
                bool? requestHidePastEntries = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestWaitlistEntryIds = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetWaitlistEntriesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/class/waitlistentries")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.classIds", requestClassIds))
                      .Query(_query => _query.Setup("request.classScheduleIds", requestClassScheduleIds))
                      .Query(_query => _query.Setup("request.clientIds", requestClientIds))
                      .Query(_query => _query.Setup("request.hidePastEntries", requestHidePastEntries))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.waitlistEntryIds", requestWaitlistEntryIds))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// This endpoint adds a class schedule. For a single day schedule, the EndDate parameter can be omitted.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.WrittenClassSchedulesInfo response from the API call.</returns>
        public Models.WrittenClassSchedulesInfo AddClassSchedule(
                string version,
                Models.AddClassEnrollmentScheduleRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddClassScheduleAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint adds a class schedule. For a single day schedule, the EndDate parameter can be omitted.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.WrittenClassSchedulesInfo response from the API call.</returns>
        public async Task<Models.WrittenClassSchedulesInfo> AddClassScheduleAsync(
                string version,
                Models.AddClassEnrollmentScheduleRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.WrittenClassSchedulesInfo>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/class/addclassschedule")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// This endpoint adds a client to a class or to a class waiting list. To prevent overbooking a class or booking outside the schedule windows set forth by the business, it is necessary to first check the capacity level of the class (‘MaxCapacity’ and 'TotalBooked’) and the 'IsAvailable’ parameter by running the GetClasses REQUEST. It is helpful to use this endpoint in the following situations:.
        /// * Use after calling `GET Clients` and `GET Classes` so that you are sure which client to book in which class.
        /// * If adding a client to a class from a waiting list, use this call after you call `GET WaitlistEntries` and determine the ID of the waiting list from which you are moving the client.
        /// * If adding a client to a class and using a pricing option that the client has already purchased, use this call after you call `GET ClientServices` to determine the ID of the pricing option that the client wants to use.
        /// If you add a client to a class and the client purchases a new pricing option, use `GET Services`, `GET Classes`, and then `POST CheckoutShoppingCart` in place of this call.
        /// This endpoint also supports cross-regional class bookings. If you want to perform a cross-regional class booking, set `CrossRegionalBooking` to `true`. This endpoint does not support adding a user to a waiting list using a cross-regional client pricing option(service). Cross-regional booking workflows do not support client service scheduling restrictions.
        /// When performing a cross-regional class booking, this endpoint loops through the first ten sites that the client is associated with, looks for client pricing options at each of those sites, and then uses the oldest client pricing option found.It is important to note that this endpoint only loops through a maximum of ten associated client sites. If a `ClientID` is associated with more than ten sites in an organization, this endpoint only loops through the first ten.If you know that a client has a client service at another site, you can specify that site using the `CrossRegionalBookingClientServiceSiteId` query parameter.
        /// If you perform a cross-regional booking, two additional fields are included in the `SessionType` object of the response:.
        /// * `SiteID`, which specifies where the client service is coming from.
        /// * `CrossRegionalBookingPerformed`, a Boolean field that is set to `true`.
        /// As a prerequisite to using this endpoint, your `SourceName` must have been granted access to the organization to which the site belongs.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.AddClientToClassResponse response from the API call.</returns>
        public Models.AddClientToClassResponse AddClientToClass(
                string version,
                Models.AddClientToClassRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddClientToClassAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint adds a client to a class or to a class waiting list. To prevent overbooking a class or booking outside the schedule windows set forth by the business, it is necessary to first check the capacity level of the class (‘MaxCapacity’ and 'TotalBooked’) and the 'IsAvailable’ parameter by running the GetClasses REQUEST. It is helpful to use this endpoint in the following situations:.
        /// * Use after calling `GET Clients` and `GET Classes` so that you are sure which client to book in which class.
        /// * If adding a client to a class from a waiting list, use this call after you call `GET WaitlistEntries` and determine the ID of the waiting list from which you are moving the client.
        /// * If adding a client to a class and using a pricing option that the client has already purchased, use this call after you call `GET ClientServices` to determine the ID of the pricing option that the client wants to use.
        /// If you add a client to a class and the client purchases a new pricing option, use `GET Services`, `GET Classes`, and then `POST CheckoutShoppingCart` in place of this call.
        /// This endpoint also supports cross-regional class bookings. If you want to perform a cross-regional class booking, set `CrossRegionalBooking` to `true`. This endpoint does not support adding a user to a waiting list using a cross-regional client pricing option(service). Cross-regional booking workflows do not support client service scheduling restrictions.
        /// When performing a cross-regional class booking, this endpoint loops through the first ten sites that the client is associated with, looks for client pricing options at each of those sites, and then uses the oldest client pricing option found.It is important to note that this endpoint only loops through a maximum of ten associated client sites. If a `ClientID` is associated with more than ten sites in an organization, this endpoint only loops through the first ten.If you know that a client has a client service at another site, you can specify that site using the `CrossRegionalBookingClientServiceSiteId` query parameter.
        /// If you perform a cross-regional booking, two additional fields are included in the `SessionType` object of the response:.
        /// * `SiteID`, which specifies where the client service is coming from.
        /// * `CrossRegionalBookingPerformed`, a Boolean field that is set to `true`.
        /// As a prerequisite to using this endpoint, your `SourceName` must have been granted access to the organization to which the site belongs.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.AddClientToClassResponse response from the API call.</returns>
        public async Task<Models.AddClientToClassResponse> AddClientToClassAsync(
                string version,
                Models.AddClientToClassRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.AddClientToClassResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/class/addclienttoclass")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// This endpoint will cancel a single class from studio.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.CancelSingleClassResponse response from the API call.</returns>
        public Models.CancelSingleClassResponse CancelSingleClass(
                string version,
                Models.CancelSingleClassRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(CancelSingleClassAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint will cancel a single class from studio.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.CancelSingleClassResponse response from the API call.</returns>
        public async Task<Models.CancelSingleClassResponse> CancelSingleClassAsync(
                string version,
                Models.CancelSingleClassRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.CancelSingleClassResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/class/cancelsingleclass")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Remove a client from a class.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.RemoveClientFromClassResponse response from the API call.</returns>
        public Models.RemoveClientFromClassResponse RemoveClientFromClass(
                string version,
                Models.RemoveClientFromClassRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(RemoveClientFromClassAsync(version, request, siteId, authorization));

        /// <summary>
        /// Remove a client from a class.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.RemoveClientFromClassResponse response from the API call.</returns>
        public async Task<Models.RemoveClientFromClassResponse> RemoveClientFromClassAsync(
                string version,
                Models.RemoveClientFromClassRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.RemoveClientFromClassResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/class/removeclientfromclass")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// This endpoint can be utilized for removing multiple clients from multiple classes in one request.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.RemoveClientsFromClassesResponse response from the API call.</returns>
        public Models.RemoveClientsFromClassesResponse RemoveClientsFromClasses(
                string version,
                Models.RemoveClientsFromClassesRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(RemoveClientsFromClassesAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint can be utilized for removing multiple clients from multiple classes in one request.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.RemoveClientsFromClassesResponse response from the API call.</returns>
        public async Task<Models.RemoveClientsFromClassesResponse> RemoveClientsFromClassesAsync(
                string version,
                Models.RemoveClientsFromClassesRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.RemoveClientsFromClassesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/class/removeclientsfromclasses")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// This endpoint does not return a response. If a call to this endpoint results in a 200 OK HTTP status code, then the call was successful.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestWaitlistEntryIds">Required parameter: A list of `WaitlistEntryIds` to remove from the waiting list..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object RemoveFromWaitlist(
                string version,
                List<int> requestWaitlistEntryIds,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(RemoveFromWaitlistAsync(version, requestWaitlistEntryIds, siteId, authorization));

        /// <summary>
        /// This endpoint does not return a response. If a call to this endpoint results in a 200 OK HTTP status code, then the call was successful.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestWaitlistEntryIds">Required parameter: A list of `WaitlistEntryIds` to remove from the waiting list..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> RemoveFromWaitlistAsync(
                string version,
                List<int> requestWaitlistEntryIds,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/class/removefromwaitlist")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.waitlistEntryIds", requestWaitlistEntryIds))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Substitute a class teacher.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.SubstituteClassTeacherResponse response from the API call.</returns>
        public Models.SubstituteClassTeacherResponse SubstituteClassTeacher(
                string version,
                Models.SubstituteClassTeacherRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(SubstituteClassTeacherAsync(version, request, siteId, authorization));

        /// <summary>
        /// Substitute a class teacher.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.SubstituteClassTeacherResponse response from the API call.</returns>
        public async Task<Models.SubstituteClassTeacherResponse> SubstituteClassTeacherAsync(
                string version,
                Models.SubstituteClassTeacherRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.SubstituteClassTeacherResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/class/substituteclassteacher")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// This endpoint updates a class schedule.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.WrittenClassSchedulesInfo response from the API call.</returns>
        public Models.WrittenClassSchedulesInfo UpdateClassSchedule(
                string version,
                Models.UpdateClassEnrollmentScheduleRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateClassScheduleAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint updates a class schedule.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.WrittenClassSchedulesInfo response from the API call.</returns>
        public async Task<Models.WrittenClassSchedulesInfo> UpdateClassScheduleAsync(
                string version,
                Models.UpdateClassEnrollmentScheduleRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.WrittenClassSchedulesInfo>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/class/updateclassschedule")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken);
    }
}