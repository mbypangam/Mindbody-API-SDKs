// <copyright file="AppointmentController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// AppointmentController.
    /// </summary>
    public class AppointmentController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AppointmentController"/> class.
        /// </summary>
        internal AppointmentController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// This is not appointment availability but rather the active business hours for studios and which increments services can be booked at. See BookableItems for appointment availability.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndTime">Optional parameter: Filters results to times that end on or before this time on the current date. Any date provided is ignored..  <br />Default: **23:59:59**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestScheduleType">Optional parameter: Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided..</param>
        /// <param name="requestStartTime">Optional parameter: Filters results to times that start on or after this time on the current date. Any date provided is ignored.  <br />Default: **00:00:00**.</param>
        /// <returns>Returns the Models.GetActiveSessionTimesResponse response from the API call.</returns>
        public Models.GetActiveSessionTimesResponse GetActiveSessionTimes(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndTime = null,
                int? requestLimit = null,
                int? requestOffset = null,
                Models.RequestScheduleTypeEnum? requestScheduleType = null,
                List<int> requestSessionTypeIds = null,
                DateTime? requestStartTime = null)
            => CoreHelper.RunTask(GetActiveSessionTimesAsync(version, siteId, authorization, requestEndTime, requestLimit, requestOffset, requestScheduleType, requestSessionTypeIds, requestStartTime));

        /// <summary>
        /// This is not appointment availability but rather the active business hours for studios and which increments services can be booked at. See BookableItems for appointment availability.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndTime">Optional parameter: Filters results to times that end on or before this time on the current date. Any date provided is ignored..  <br />Default: **23:59:59**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestScheduleType">Optional parameter: Filters on the provided the schedule type. Either `SessionTypeIds` or `ScheduleType` must be provided..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: Filters on the provided session type IDs. Either `SessionTypeIds` or `ScheduleType` must be provided..</param>
        /// <param name="requestStartTime">Optional parameter: Filters results to times that start on or after this time on the current date. Any date provided is ignored.  <br />Default: **00:00:00**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetActiveSessionTimesResponse response from the API call.</returns>
        public async Task<Models.GetActiveSessionTimesResponse> GetActiveSessionTimesAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndTime = null,
                int? requestLimit = null,
                int? requestOffset = null,
                Models.RequestScheduleTypeEnum? requestScheduleType = null,
                List<int> requestSessionTypeIds = null,
                DateTime? requestStartTime = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetActiveSessionTimesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/appointment/activesessiontimes")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endTime", requestEndTime.HasValue ? requestEndTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.scheduleType", (requestScheduleType.HasValue) ? ApiHelper.JsonSerialize(requestScheduleType.Value).Trim('\"') : null))
                      .Query(_query => _query.Setup("request.sessionTypeIds", requestSessionTypeIds))
                      .Query(_query => _query.Setup("request.startTime", requestStartTime.HasValue ? requestStartTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Get active appointment add-ons.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffId">Optional parameter: Filter to add-ons only performed by this staff member..</param>
        /// <returns>Returns the Models.GetAddOnsResponse response from the API call.</returns>
        public Models.GetAddOnsResponse GetAddOns(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestStaffId = null)
            => CoreHelper.RunTask(GetAddOnsAsync(version, siteId, authorization, requestLimit, requestOffset, requestStaffId));

        /// <summary>
        /// Get active appointment add-ons.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffId">Optional parameter: Filter to add-ons only performed by this staff member..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetAddOnsResponse response from the API call.</returns>
        public async Task<Models.GetAddOnsResponse> GetAddOnsAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                int? requestStaffId = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetAddOnsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/appointment/addons")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.staffId", requestStaffId))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint has no query parameters.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.GetAppointmentOptionsResponse response from the API call.</returns>
        public Models.GetAppointmentOptionsResponse GetAppointmentOptions(
                string version,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(GetAppointmentOptionsAsync(version, siteId, authorization));

        /// <summary>
        /// This endpoint has no query parameters.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetAppointmentOptionsResponse response from the API call.</returns>
        public async Task<Models.GetAppointmentOptionsResponse> GetAppointmentOptionsAsync(
                string version,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetAppointmentOptionsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/appointment/appointmentoptions")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Returns a list of dates to narrow down staff availability when booking. Dates are those which staff are scheduled to work and do not guarantee booking availabilities. After this call is made, use GET BookableItems to retrieve availabilities for specific dates before booking.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestSessionTypeId">Required parameter: required requested session type ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestLocationId">Optional parameter: optional requested location ID..</param>
        /// <param name="requestStaffId">Optional parameter: optional requested staff ID..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range. If omitted, the default is used.  <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.GetAvailableDatesResponse response from the API call.</returns>
        public Models.GetAvailableDatesResponse GetAvailableDates(
                string version,
                int requestSessionTypeId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLocationId = null,
                long? requestStaffId = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(GetAvailableDatesAsync(version, requestSessionTypeId, siteId, authorization, requestEndDate, requestLocationId, requestStaffId, requestStartDate));

        /// <summary>
        /// Returns a list of dates to narrow down staff availability when booking. Dates are those which staff are scheduled to work and do not guarantee booking availabilities. After this call is made, use GET BookableItems to retrieve availabilities for specific dates before booking.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestSessionTypeId">Required parameter: required requested session type ID..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestLocationId">Optional parameter: optional requested location ID..</param>
        /// <param name="requestStaffId">Optional parameter: optional requested staff ID..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range. If omitted, the default is used.  <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetAvailableDatesResponse response from the API call.</returns>
        public async Task<Models.GetAvailableDatesResponse> GetAvailableDatesAsync(
                string version,
                int requestSessionTypeId,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLocationId = null,
                long? requestStaffId = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetAvailableDatesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/appointment/availabledates")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.sessionTypeId", requestSessionTypeId))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.staffId", requestStaffId))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Returns a list of availabilities with the information needed to book appointments. Availabilities include information such as the location and its amenities, staff members, programs, and session types. Recommended to use with GET AvailableDates to see what dates the staff is scheduled to work and narrow down the dates searched. Recommended to use with GET ActiveSessionTimes to see which increments each business allows for booking appointments.
        /// Notes: .
        /// - With a wider range of dates, this call may take longer to return results. .
        /// - With a higher number of request.sessionTypeIds, this call may take longer to return results.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestSessionTypeIds">Required parameter: A list of the requested session type IDs..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentId">Optional parameter: If provided, filters out the appointment with this ID..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestIgnoreDefaultSessionLength">Optional parameter: When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br />  When `false`, only availabilities that have the default session length return..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of the requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of the requested staff IDs. Omit parameter to return all staff availabilities..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.GetBookableItemsResponse response from the API call.</returns>
        public Models.GetBookableItemsResponse GetBookableItems(
                string version,
                List<int> requestSessionTypeIds,
                string siteId,
                string authorization = null,
                long? requestAppointmentId = null,
                DateTime? requestEndDate = null,
                bool? requestIgnoreDefaultSessionLength = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(GetBookableItemsAsync(version, requestSessionTypeIds, siteId, authorization, requestAppointmentId, requestEndDate, requestIgnoreDefaultSessionLength, requestLimit, requestLocationIds, requestOffset, requestStaffIds, requestStartDate));

        /// <summary>
        /// Returns a list of availabilities with the information needed to book appointments. Availabilities include information such as the location and its amenities, staff members, programs, and session types. Recommended to use with GET AvailableDates to see what dates the staff is scheduled to work and narrow down the dates searched. Recommended to use with GET ActiveSessionTimes to see which increments each business allows for booking appointments.
        /// Notes: .
        /// - With a wider range of dates, this call may take longer to return results. .
        /// - With a higher number of request.sessionTypeIds, this call may take longer to return results.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestSessionTypeIds">Required parameter: A list of the requested session type IDs..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentId">Optional parameter: If provided, filters out the appointment with this ID..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestIgnoreDefaultSessionLength">Optional parameter: When `true`, availabilities that are non-default return, for example, a 30-minute availability with a 60-minute default session length.<br />  When `false`, only availabilities that have the default session length return..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of the requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of the requested staff IDs. Omit parameter to return all staff availabilities..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetBookableItemsResponse response from the API call.</returns>
        public async Task<Models.GetBookableItemsResponse> GetBookableItemsAsync(
                string version,
                List<int> requestSessionTypeIds,
                string siteId,
                string authorization = null,
                long? requestAppointmentId = null,
                DateTime? requestEndDate = null,
                bool? requestIgnoreDefaultSessionLength = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetBookableItemsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/appointment/bookableitems")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.sessionTypeIds", requestSessionTypeIds))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.appointmentId", requestAppointmentId))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.ignoreDefaultSessionLength", requestIgnoreDefaultSessionLength))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationIds", requestLocationIds))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.staffIds", requestStaffIds))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Returns a list of schedule items, including appointments, availabilities, and unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="requestIgnorePrepFinishTimes">Optional parameter: When `true`, appointment preparation and finish unavailabilities are not returned.   <br />Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of requested staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.GetScheduleItemsResponse response from the API call.</returns>
        public Models.GetScheduleItemsResponse GetScheduleItems(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                bool? requestIgnorePrepFinishTimes = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(GetScheduleItemsAsync(version, siteId, authorization, requestEndDate, requestIgnorePrepFinishTimes, requestLimit, requestLocationIds, requestOffset, requestStaffIds, requestStartDate));

        /// <summary>
        /// Returns a list of schedule items, including appointments, availabilities, and unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="requestIgnorePrepFinishTimes">Optional parameter: When `true`, appointment preparation and finish unavailabilities are not returned.   <br />Default: **false**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of requested staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetScheduleItemsResponse response from the API call.</returns>
        public async Task<Models.GetScheduleItemsResponse> GetScheduleItemsAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                bool? requestIgnorePrepFinishTimes = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetScheduleItemsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/appointment/scheduleitems")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.ignorePrepFinishTimes", requestIgnorePrepFinishTimes))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationIds", requestLocationIds))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.staffIds", requestStaffIds))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Returns a list of appointments by staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentIds">Optional parameter: A list of the requested appointment IDs..</param>
        /// <param name="requestClientId">Optional parameter: The client ID to be returned..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of the requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: List of staff IDs to be returned. Omit parameter to return staff appointments for all staff..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range. If omitted, the default is used.   <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.GetStaffAppointmentsResponse response from the API call.</returns>
        public Models.GetStaffAppointmentsResponse GetStaffAppointments(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestAppointmentIds = null,
                string requestClientId = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(GetStaffAppointmentsAsync(version, siteId, authorization, requestAppointmentIds, requestClientId, requestEndDate, requestLimit, requestLocationIds, requestOffset, requestStaffIds, requestStartDate));

        /// <summary>
        /// Returns a list of appointments by staff member.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestAppointmentIds">Optional parameter: A list of the requested appointment IDs..</param>
        /// <param name="requestClientId">Optional parameter: The client ID to be returned..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **StartDate**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: A list of the requested location IDs..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: List of staff IDs to be returned. Omit parameter to return staff appointments for all staff..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range. If omitted, the default is used.   <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetStaffAppointmentsResponse response from the API call.</returns>
        public async Task<Models.GetStaffAppointmentsResponse> GetStaffAppointmentsAsync(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestAppointmentIds = null,
                string requestClientId = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetStaffAppointmentsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/appointment/staffappointments")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.appointmentIds", requestAppointmentIds))
                      .Query(_query => _query.Setup("request.clientId", requestClientId))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationIds", requestLocationIds))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.staffIds", requestStaffIds))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Returns a list of unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of requested staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <returns>Returns the Models.GetUnavailabilitiesResponse response from the API call.</returns>
        public Models.GetUnavailabilitiesResponse GetUnavailabilities(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(GetUnavailabilitiesAsync(version, siteId, authorization, requestEndDate, requestLimit, requestOffset, requestStaffIds, requestStartDate));

        /// <summary>
        /// Returns a list of unavailabilities. Unavailabilities are the times at which appointments cannot be booked, for example, on holidays or after hours when the business is closed.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: The end date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffIds">Optional parameter: A list of requested staff IDs..</param>
        /// <param name="requestStartDate">Optional parameter: The start date of the requested date range.   <br />Default: **today’s date**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetUnavailabilitiesResponse response from the API call.</returns>
        public async Task<Models.GetUnavailabilitiesResponse> GetUnavailabilitiesAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<long> requestStaffIds = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetUnavailabilitiesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/appointment/unavailabilities")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.staffIds", requestStaffIds))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// A user token is required for this endpoint. To book an appointment, you must use a location ID, staff ID, client ID, session type ID, and the StartDateTime of the appointment. You can get most of this information using GET BookableItems.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.AddAppointmentResponse response from the API call.</returns>
        public Models.AddAppointmentResponse AddAppointment(
                string version,
                Models.AddAppointmentRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddAppointmentAsync(version, request, siteId, authorization));

        /// <summary>
        /// A user token is required for this endpoint. To book an appointment, you must use a location ID, staff ID, client ID, session type ID, and the StartDateTime of the appointment. You can get most of this information using GET BookableItems.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.AddAppointmentResponse response from the API call.</returns>
        public async Task<Models.AddAppointmentResponse> AddAppointmentAsync(
                string version,
                Models.AddAppointmentRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.AddAppointmentResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/appointment/addappointment")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint books an add-on on top of an existing, regular appointment. To book an add-on, you must use an existing appointment ID and session type ID. You can get a session type ID using `GET AppointmentAddOns`.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.AddAppointmentAddOnResponse response from the API call.</returns>
        public Models.AddAppointmentAddOnResponse AddAppointmentAddOn(
                string version,
                Models.AddAppointmentAddOnRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddAppointmentAddOnAsync(version, request, siteId, authorization));

        /// <summary>
        /// This endpoint books an add-on on top of an existing, regular appointment. To book an add-on, you must use an existing appointment ID and session type ID. You can get a session type ID using `GET AppointmentAddOns`.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.AddAppointmentAddOnResponse response from the API call.</returns>
        public async Task<Models.AddAppointmentAddOnResponse> AddAppointmentAddOnAsync(
                string version,
                Models.AddAppointmentAddOnRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.AddAppointmentAddOnResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/appointment/addappointmentaddon")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// To update the information for a specific availability or unavailability of the staff.<br />.
        /// Note: You must have a staff user token with the required permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateAvailabilityRequest">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.UpdateAvailabilityResponse response from the API call.</returns>
        public Models.UpdateAvailabilityResponse UpdateAvailability(
                string version,
                string siteId,
                Models.UpdateAvailabilityRequest updateAvailabilityRequest,
                string authorization = null)
            => CoreHelper.RunTask(UpdateAvailabilityAsync(version, siteId, updateAvailabilityRequest, authorization));

        /// <summary>
        /// To update the information for a specific availability or unavailability of the staff.<br />.
        /// Note: You must have a staff user token with the required permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="updateAvailabilityRequest">Required parameter: Example: .</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UpdateAvailabilityResponse response from the API call.</returns>
        public async Task<Models.UpdateAvailabilityResponse> UpdateAvailabilityAsync(
                string version,
                string siteId,
                Models.UpdateAvailabilityRequest updateAvailabilityRequest,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.UpdateAvailabilityResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Put, "/public/v{version}/appointment/availabilities")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(updateAvailabilityRequest))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Add availabilities and unavailabilities for a staff member.<br />.
        /// Note: You must have a staff user token with the required permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.AddAvailabilitiesResponse response from the API call.</returns>
        public Models.AddAvailabilitiesResponse AddAvailabilities(
                string version,
                Models.AddAvailabilitiesRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddAvailabilitiesAsync(version, request, siteId, authorization));

        /// <summary>
        /// Add availabilities and unavailabilities for a staff member.<br />.
        /// Note: You must have a staff user token with the required permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.AddAvailabilitiesResponse response from the API call.</returns>
        public async Task<Models.AddAvailabilitiesResponse> AddAvailabilitiesAsync(
                string version,
                Models.AddAvailabilitiesRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.AddAvailabilitiesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/appointment/availabilities")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// To update the information for a specific appointment, you must have a staff user token with the proper permissions. Note that you can only update the appointment’s `StartDateTime`, `EndDateTime`, `StaffId`, `Notes`, and `SessionTypeId`.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.UpdateAppointmentResponse response from the API call.</returns>
        public Models.UpdateAppointmentResponse UpdateAppointment(
                string version,
                Models.UpdateAppointmentRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(UpdateAppointmentAsync(version, request, siteId, authorization));

        /// <summary>
        /// To update the information for a specific appointment, you must have a staff user token with the proper permissions. Note that you can only update the appointment’s `StartDateTime`, `EndDateTime`, `StaffId`, `Notes`, and `SessionTypeId`.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.UpdateAppointmentResponse response from the API call.</returns>
        public async Task<Models.UpdateAppointmentResponse> UpdateAppointmentAsync(
                string version,
                Models.UpdateAppointmentRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.UpdateAppointmentResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/appointment/updateappointment")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// Remove an appointment from waitlist.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestWaitlistEntryIds">Required parameter: A list of `WaitlistEntryIds` to remove from the waiting list..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        public void RemoveFromWaitlist(
                string version,
                List<int> requestWaitlistEntryIds,
                string siteId,
                string authorization = null)
            => CoreHelper.RunVoidTask(RemoveFromWaitlistAsync(version, requestWaitlistEntryIds, siteId, authorization));

        /// <summary>
        /// Remove an appointment from waitlist.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="requestWaitlistEntryIds">Required parameter: A list of `WaitlistEntryIds` to remove from the waiting list..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task RemoveFromWaitlistAsync(
                string version,
                List<int> requestWaitlistEntryIds,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/public/v{version}/appointment/appointmentfromwaitlist")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("request.waitlistEntryIds", requestWaitlistEntryIds))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint deletes the availability or unavailability.
        /// Note: You must have a staff user token with the required permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="deleteAvailabilityRequestAvailabilityId">Optional parameter: The ID of the availability or unavailability..</param>
        /// <param name="deleteAvailabilityRequestTest">Optional parameter: When `true`, indicates that this is a test request and no data is deleted from the subscriber’s database.  When `false`, the record will be deleted.  Default: **false**.</param>
        public void DeleteAvailability(
                string version,
                string siteId,
                string authorization = null,
                int? deleteAvailabilityRequestAvailabilityId = null,
                bool? deleteAvailabilityRequestTest = null)
            => CoreHelper.RunVoidTask(DeleteAvailabilityAsync(version, siteId, authorization, deleteAvailabilityRequestAvailabilityId, deleteAvailabilityRequestTest));

        /// <summary>
        /// This endpoint deletes the availability or unavailability.
        /// Note: You must have a staff user token with the required permissions.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="deleteAvailabilityRequestAvailabilityId">Optional parameter: The ID of the availability or unavailability..</param>
        /// <param name="deleteAvailabilityRequestTest">Optional parameter: When `true`, indicates that this is a test request and no data is deleted from the subscriber’s database.  When `false`, the record will be deleted.  Default: **false**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteAvailabilityAsync(
                string version,
                string siteId,
                string authorization = null,
                int? deleteAvailabilityRequestAvailabilityId = null,
                bool? deleteAvailabilityRequestTest = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/public/v{version}/appointment/availability")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("deleteAvailabilityRequest.availabilityId", deleteAvailabilityRequestAvailabilityId))
                      .Query(_query => _query.Setup("deleteAvailabilityRequest.test", deleteAvailabilityRequestTest))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);

        /// <summary>
        /// This endpoint can be used to early-cancel a booked appointment add-on.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="id">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        public void DeleteAppointmentAddOn(
                string version,
                long id,
                string siteId,
                string authorization = null)
            => CoreHelper.RunVoidTask(DeleteAppointmentAddOnAsync(version, id, siteId, authorization));

        /// <summary>
        /// This endpoint can be used to early-cancel a booked appointment add-on.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="id">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the void response from the API call.</returns>
        public async Task DeleteAppointmentAddOnAsync(
                string version,
                long id,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<VoidType>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Delete, "/public/v{version}/appointment/deleteappointmentaddon")
                  .WithAuth("API-Key")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Query(_query => _query.Setup("id", id))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ExecuteAsync(cancellationToken).ConfigureAwait(false);
    }
}