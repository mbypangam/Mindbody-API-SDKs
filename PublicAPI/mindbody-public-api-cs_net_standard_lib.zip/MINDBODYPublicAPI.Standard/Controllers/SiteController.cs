// <copyright file="SiteController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// SiteController.
    /// </summary>
    public class SiteController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SiteController"/> class.
        /// </summary>
        internal SiteController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Before you can use this endpoint, MINDBODY must approve your developer account for live access. If you have finished testing in the sandbox and are ready to begin working with MINDBODY customers, log into your account and request to go live.
        /// See [Accessing Business Data From MINDBODY](https://developers.mindbodyonline.com/PublicDocumentation/V6#accessing-business-data) for more information about the activation code and how to use it.
        /// Once you are approved, this endpoint returns an activation code.This endpoint supports only one site per call.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.GetActivationCodeResponse response from the API call.</returns>
        public Models.GetActivationCodeResponse GetActivationCode(
                string version,
                string authorization = null)
            => CoreHelper.RunTask(GetActivationCodeAsync(version, authorization));

        /// <summary>
        /// Before you can use this endpoint, MINDBODY must approve your developer account for live access. If you have finished testing in the sandbox and are ready to begin working with MINDBODY customers, log into your account and request to go live.
        /// See [Accessing Business Data From MINDBODY](https://developers.mindbodyonline.com/PublicDocumentation/V6#accessing-business-data) for more information about the activation code and how to use it.
        /// Once you are approved, this endpoint returns an activation code.This endpoint supports only one site per call.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetActivationCodeResponse response from the API call.</returns>
        public async Task<Models.GetActivationCodeResponse> GetActivationCodeAsync(
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetActivationCodeResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/activationcode")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetActivationCodeResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Gets the categories.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains categories which are activated.   When `false`, only deactivated categories are returned.  Default: **All Categories**.</param>
        /// <param name="requestCategoryIds">Optional parameter: When included, the response only contains details about the specified category Ids..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestService">Optional parameter: When `true`, the response only contains details about Revenue Categories.  When `false`, only Product Revenue Categories are returned.  Default: **All Categories**.</param>
        /// <param name="requestSubCategoryIds">Optional parameter: When included, the response only contains details about the specified subcategory Ids..</param>
        /// <returns>Returns the Models.GetCategoriesResponse response from the API call.</returns>
        public Models.GetCategoriesResponse GetCategories(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                List<int> requestCategoryIds = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestService = null,
                List<int> requestSubCategoryIds = null)
            => CoreHelper.RunTask(GetCategoriesAsync(version, siteId, authorization, requestActive, requestCategoryIds, requestLimit, requestOffset, requestService, requestSubCategoryIds));

        /// <summary>
        /// Gets the categories.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains categories which are activated.   When `false`, only deactivated categories are returned.  Default: **All Categories**.</param>
        /// <param name="requestCategoryIds">Optional parameter: When included, the response only contains details about the specified category Ids..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestService">Optional parameter: When `true`, the response only contains details about Revenue Categories.  When `false`, only Product Revenue Categories are returned.  Default: **All Categories**.</param>
        /// <param name="requestSubCategoryIds">Optional parameter: When included, the response only contains details about the specified subcategory Ids..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetCategoriesResponse response from the API call.</returns>
        public async Task<Models.GetCategoriesResponse> GetCategoriesAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                List<int> requestCategoryIds = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestService = null,
                List<int> requestSubCategoryIds = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetCategoriesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/categories")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.active", requestActive))
                      .Query(_query => _query.Setup("request.categoryIds", requestCategoryIds))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.service", requestService))
                      .Query(_query => _query.Setup("request.subCategoryIds", requestSubCategoryIds))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetCategoriesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// The endpoint returns a list of configured client gender options for a site. Custom gender options are assignable to client genders only. Currently, custom values returned from this endpoint cannot be used as input for other endpoints to specify the genders of staff or client preferences.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.GetGendersResponse response from the API call.</returns>
        public Models.GetGendersResponse GetGenders(
                string version,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(GetGendersAsync(version, siteId, authorization));

        /// <summary>
        /// The endpoint returns a list of configured client gender options for a site. Custom gender options are assignable to client genders only. Currently, custom values returned from this endpoint cannot be used as input for other endpoints to specify the genders of staff or client preferences.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetGendersResponse response from the API call.</returns>
        public async Task<Models.GetGendersResponse> GetGendersAsync(
                string version,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetGendersResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/genders")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetGendersResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get locations for a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.GetLocationsResponse response from the API call.</returns>
        public Models.GetLocationsResponse GetLocations(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null)
            => CoreHelper.RunTask(GetLocationsAsync(version, siteId, authorization, requestLimit, requestOffset));

        /// <summary>
        /// Get locations for a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetLocationsResponse response from the API call.</returns>
        public async Task<Models.GetLocationsResponse> GetLocationsAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetLocationsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/locations")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetLocationsResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get the memberships at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestMembershipIds">Optional parameter: The requested membership IDs.<br />  Default: **all** IDs that the authenticated user’s access level allows..</param>
        /// <returns>Returns the Models.GetMembershipsResponse response from the API call.</returns>
        public Models.GetMembershipsResponse GetMemberships(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestMembershipIds = null)
            => CoreHelper.RunTask(GetMembershipsAsync(version, siteId, authorization, requestMembershipIds));

        /// <summary>
        /// Get the memberships at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestMembershipIds">Optional parameter: The requested membership IDs.<br />  Default: **all** IDs that the authenticated user’s access level allows..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetMembershipsResponse response from the API call.</returns>
        public async Task<Models.GetMembershipsResponse> GetMembershipsAsync(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestMembershipIds = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetMembershipsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/memberships")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.membershipIds", requestMembershipIds))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetMembershipsResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get the list of mobile providers that are supported by the business.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains mobile providers which are activated.   When `false`, only deactivated mobile providers are returned.  Default: **All Mobile Providers**.</param>
        /// <returns>Returns the Models.GetMobileProvidersResponse response from the API call.</returns>
        public Models.GetMobileProvidersResponse GetMobileProviders(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null)
            => CoreHelper.RunTask(GetMobileProvidersAsync(version, siteId, authorization, requestActive));

        /// <summary>
        /// Get the list of mobile providers that are supported by the business.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains mobile providers which are activated.   When `false`, only deactivated mobile providers are returned.  Default: **All Mobile Providers**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetMobileProvidersResponse response from the API call.</returns>
        public async Task<Models.GetMobileProvidersResponse> GetMobileProvidersAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetMobileProvidersResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/mobileproviders")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.active", requestActive))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetMobileProvidersResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get payment types for a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains payment types which are activated.  When `false`, only deactivated payment types are returned.  Default: **All Payment Types**.</param>
        /// <returns>Returns the Models.GetPaymentTypesResponse response from the API call.</returns>
        public Models.GetPaymentTypesResponse GetPaymentTypes(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null)
            => CoreHelper.RunTask(GetPaymentTypesAsync(version, siteId, authorization, requestActive));

        /// <summary>
        /// Get payment types for a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains payment types which are activated.  When `false`, only deactivated payment types are returned.  Default: **All Payment Types**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetPaymentTypesResponse response from the API call.</returns>
        public async Task<Models.GetPaymentTypesResponse> GetPaymentTypesAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetPaymentTypesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/paymenttypes")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.active", requestActive))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetPaymentTypesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get service categories offered at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: If `true`, filters results to show only those programs that are shown online.<br />  If `false`, all programs are returned.<br />  Default: **false**.</param>
        /// <param name="requestProgramIds">Optional parameter: Program Ids to filter for.</param>
        /// <param name="requestScheduleType">Optional parameter: A schedule type used to filter the returned results. Possible values are:  * All  * Class  * Enrollment  * Appointment  * Resource  * Media  * Arrival.</param>
        /// <returns>Returns the Models.GetProgramsResponse response from the API call.</returns>
        public Models.GetProgramsResponse GetPrograms(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                List<int> requestProgramIds = null,
                Models.RequestScheduleTypeEnum? requestScheduleType = null)
            => CoreHelper.RunTask(GetProgramsAsync(version, siteId, authorization, requestLimit, requestOffset, requestOnlineOnly, requestProgramIds, requestScheduleType));

        /// <summary>
        /// Get service categories offered at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: If `true`, filters results to show only those programs that are shown online.<br />  If `false`, all programs are returned.<br />  Default: **false**.</param>
        /// <param name="requestProgramIds">Optional parameter: Program Ids to filter for.</param>
        /// <param name="requestScheduleType">Optional parameter: A schedule type used to filter the returned results. Possible values are:  * All  * Class  * Enrollment  * Appointment  * Resource  * Media  * Arrival.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetProgramsResponse response from the API call.</returns>
        public async Task<Models.GetProgramsResponse> GetProgramsAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                List<int> requestProgramIds = null,
                Models.RequestScheduleTypeEnum? requestScheduleType = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetProgramsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/programs")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.onlineOnly", requestOnlineOnly))
                      .Query(_query => _query.Setup("request.programIds", requestProgramIds))
                      .Query(_query => _query.Setup("request.scheduleType", (requestScheduleType.HasValue) ? ApiHelper.JsonSerialize(requestScheduleType.Value).Trim('\"') : null))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetProgramsResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Gets a list of promocodes at the specified business. This endpoint requires staff user credentials. .
        /// This staff member should have enabled the Set up promotions / **Semester discounts** staff permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActiveOnly">Optional parameter: If true, filters results to show only promocodes that are active. If **false**, all promocodes are returned.  Default: **true**.</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to promocodes that were activated before this date..</param>
        /// <param name="requestLastModifiedDate">Optional parameter: Filters results to promocodes that were modified on or after this date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: If `true`, filters results to show only promocodes that can be used for online sale.  If `false`, all promocodes are returned.  Default: **false**.</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to promocodes that were activated after this date..</param>
        /// <returns>Returns the Models.GetPromoCodesResponse response from the API call.</returns>
        public Models.GetPromoCodesResponse GetPromoCodes(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActiveOnly = null,
                DateTime? requestEndDate = null,
                DateTime? requestLastModifiedDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(GetPromoCodesAsync(version, siteId, authorization, requestActiveOnly, requestEndDate, requestLastModifiedDate, requestLimit, requestOffset, requestOnlineOnly, requestStartDate));

        /// <summary>
        /// Gets a list of promocodes at the specified business. This endpoint requires staff user credentials. .
        /// This staff member should have enabled the Set up promotions / **Semester discounts** staff permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActiveOnly">Optional parameter: If true, filters results to show only promocodes that are active. If **false**, all promocodes are returned.  Default: **true**.</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to promocodes that were activated before this date..</param>
        /// <param name="requestLastModifiedDate">Optional parameter: Filters results to promocodes that were modified on or after this date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: If `true`, filters results to show only promocodes that can be used for online sale.  If `false`, all promocodes are returned.  Default: **false**.</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to promocodes that were activated after this date..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetPromoCodesResponse response from the API call.</returns>
        public async Task<Models.GetPromoCodesResponse> GetPromoCodesAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActiveOnly = null,
                DateTime? requestEndDate = null,
                DateTime? requestLastModifiedDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetPromoCodesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/promocodes")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.activeOnly", requestActiveOnly))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.lastModifiedDate", requestLastModifiedDate.HasValue ? requestLastModifiedDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.onlineOnly", requestOnlineOnly))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetPromoCodesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get the list of prospect stages that represent the prospect stage options for prospective clients.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains prospect stages which are activated.  When `false`, only deactivated prospect stages are returned.  Default: **All Prospect Stages**.</param>
        /// <returns>Returns the Models.GetProspectStagesResponse response from the API call.</returns>
        public Models.GetProspectStagesResponse GetProspectStages(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null)
            => CoreHelper.RunTask(GetProspectStagesAsync(version, siteId, authorization, requestActive));

        /// <summary>
        /// Get the list of prospect stages that represent the prospect stage options for prospective clients.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains prospect stages which are activated.  When `false`, only deactivated prospect stages are returned.  Default: **All Prospect Stages**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetProspectStagesResponse response from the API call.</returns>
        public async Task<Models.GetProspectStagesResponse> GetProspectStagesAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetProspectStagesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/prospectstages")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.active", requestActive))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetProspectStagesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// This endpoint retrieves the business site relationships.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains relationships which are activated.  When `false`, only deactivated relationships are returned.  Default: **All Relationships**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.GetRelationshipsResponse response from the API call.</returns>
        public Models.GetRelationshipsResponse GetRelationships(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                int? requestLimit = null,
                int? requestOffset = null)
            => CoreHelper.RunTask(GetRelationshipsAsync(version, siteId, authorization, requestActive, requestLimit, requestOffset));

        /// <summary>
        /// This endpoint retrieves the business site relationships.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains relationships which are activated.  When `false`, only deactivated relationships are returned.  Default: **All Relationships**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetRelationshipsResponse response from the API call.</returns>
        public async Task<Models.GetRelationshipsResponse> GetRelationshipsAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetRelationshipsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/relationships")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.active", requestActive))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetRelationshipsResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get resource availabilities used at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: End date. If default, StartDate is used..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: Filter by location ids (optional).</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filter by program ids (optional).</param>
        /// <param name="requestResourceIds">Optional parameter: Filter on resourceIds.</param>
        /// <param name="requestScheduleTypes">Optional parameter: Filter by schedule types (optional).</param>
        /// <param name="requestStartDate">Optional parameter: Start time.</param>
        /// <returns>Returns the Models.GetResourcesResponse response from the API call.</returns>
        public Models.GetResourcesResponse SiteGetResourceAvailabilities(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                List<int> requestResourceIds = null,
                List<Models.RequestScheduleTypeEnum> requestScheduleTypes = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(SiteGetResourceAvailabilitiesAsync(version, siteId, authorization, requestEndDate, requestLimit, requestLocationIds, requestOffset, requestProgramIds, requestResourceIds, requestScheduleTypes, requestStartDate));

        /// <summary>
        /// Get resource availabilities used at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDate">Optional parameter: End date. If default, StartDate is used..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationIds">Optional parameter: Filter by location ids (optional).</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filter by program ids (optional).</param>
        /// <param name="requestResourceIds">Optional parameter: Filter on resourceIds.</param>
        /// <param name="requestScheduleTypes">Optional parameter: Filter by schedule types (optional).</param>
        /// <param name="requestStartDate">Optional parameter: Start time.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetResourcesResponse response from the API call.</returns>
        public async Task<Models.GetResourcesResponse> SiteGetResourceAvailabilitiesAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                List<int> requestResourceIds = null,
                List<Models.RequestScheduleTypeEnum> requestScheduleTypes = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetResourcesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/resourceavailabilities")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationIds", requestLocationIds))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.programIds", requestProgramIds))
                      .Query(_query => _query.Setup("request.resourceIds", requestResourceIds))
                      .Query(_query => _query.Setup("request.scheduleTypes", requestScheduleTypes?.Select(a => ApiHelper.JsonSerialize(a).Trim('\"')).ToList()))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetResourcesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get resources used at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDateTime">Optional parameter: The time the resource ends. This parameter is ignored if `EndDateTime` or `LocationID` is not set..</param>
        /// <param name="requestIncludeInactive">Optional parameter: Enable to include inactive.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: The location of the resource. This parameter is ignored if `EndDateTime` or `LocationID` is not set.<br />  Default: **all**.</param>
        /// <param name="requestLocationIds">Optional parameter: Filter by location ids (optional).</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filter by program ids (optional).</param>
        /// <param name="requestResourceIds">Optional parameter: Filter on resourceIds.</param>
        /// <param name="requestScheduleTypes">Optional parameter: Filter by schedule types (optional).</param>
        /// <param name="requestSessionTypeIds">Optional parameter: List of session type IDs.<br />  Default: **all**.</param>
        /// <param name="requestStartDateTime">Optional parameter: The time the resource starts. This parameter is ignored if `EndDateTime` or `LocationID` is not set..</param>
        /// <returns>Returns the object response from the API call.</returns>
        public object GetResources(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDateTime = null,
                bool? requestIncludeInactive = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                List<int> requestResourceIds = null,
                List<Models.RequestScheduleTypeEnum> requestScheduleTypes = null,
                List<int> requestSessionTypeIds = null,
                DateTime? requestStartDateTime = null)
            => CoreHelper.RunTask(GetResourcesAsync(version, siteId, authorization, requestEndDateTime, requestIncludeInactive, requestLimit, requestLocationId, requestLocationIds, requestOffset, requestProgramIds, requestResourceIds, requestScheduleTypes, requestSessionTypeIds, requestStartDateTime));

        /// <summary>
        /// Get resources used at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDateTime">Optional parameter: The time the resource ends. This parameter is ignored if `EndDateTime` or `LocationID` is not set..</param>
        /// <param name="requestIncludeInactive">Optional parameter: Enable to include inactive.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: The location of the resource. This parameter is ignored if `EndDateTime` or `LocationID` is not set.<br />  Default: **all**.</param>
        /// <param name="requestLocationIds">Optional parameter: Filter by location ids (optional).</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestProgramIds">Optional parameter: Filter by program ids (optional).</param>
        /// <param name="requestResourceIds">Optional parameter: Filter on resourceIds.</param>
        /// <param name="requestScheduleTypes">Optional parameter: Filter by schedule types (optional).</param>
        /// <param name="requestSessionTypeIds">Optional parameter: List of session type IDs.<br />  Default: **all**.</param>
        /// <param name="requestStartDateTime">Optional parameter: The time the resource starts. This parameter is ignored if `EndDateTime` or `LocationID` is not set..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the object response from the API call.</returns>
        public async Task<object> GetResourcesAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDateTime = null,
                bool? requestIncludeInactive = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                List<int> requestLocationIds = null,
                int? requestOffset = null,
                List<int> requestProgramIds = null,
                List<int> requestResourceIds = null,
                List<Models.RequestScheduleTypeEnum> requestScheduleTypes = null,
                List<int> requestSessionTypeIds = null,
                DateTime? requestStartDateTime = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<object>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/resources")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endDateTime", requestEndDateTime.HasValue ? requestEndDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.includeInactive", requestIncludeInactive))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.locationIds", requestLocationIds))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.programIds", requestProgramIds))
                      .Query(_query => _query.Setup("request.resourceIds", requestResourceIds))
                      .Query(_query => _query.Setup("request.scheduleTypes", requestScheduleTypes?.Select(a => ApiHelper.JsonSerialize(a).Trim('\"')).ToList()))
                      .Query(_query => _query.Setup("request.sessionTypeIds", requestSessionTypeIds))
                      .Query(_query => _query.Setup("request.startDateTime", requestStartDateTime.HasValue ? requestStartDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => _response))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get the session types used at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: When `true`, indicates that only the session types that can be booked online should be returned.<br />  Default: **false**.</param>
        /// <param name="requestProgramIDs">Optional parameter: Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return..</param>
        /// <returns>Returns the Models.GetSessionTypesResponse response from the API call.</returns>
        public Models.GetSessionTypesResponse GetSessionTypes(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                List<int> requestProgramIDs = null)
            => CoreHelper.RunTask(GetSessionTypesAsync(version, siteId, authorization, requestLimit, requestOffset, requestOnlineOnly, requestProgramIDs));

        /// <summary>
        /// Get the session types used at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: When `true`, indicates that only the session types that can be booked online should be returned.<br />  Default: **false**.</param>
        /// <param name="requestProgramIDs">Optional parameter: Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetSessionTypesResponse response from the API call.</returns>
        public async Task<Models.GetSessionTypesResponse> GetSessionTypesAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                List<int> requestProgramIDs = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetSessionTypesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/sessiontypes")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.onlineOnly", requestOnlineOnly))
                      .Query(_query => _query.Setup("request.programIDs", requestProgramIDs))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetSessionTypesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Gets a list of sites that the developer has permission to view.
        /// * Passing in no `SiteIds` returns all sites that the developer has access to.
        /// * Passing in one `SiteIds` returns more detailed information about the specified site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestIncludeLeadChannels">Optional parameter: This is an optional parameter to get lead channels for a Site..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSiteIds">Optional parameter: List of the requested site IDs. When omitted, returns all sites that the source has access to..</param>
        /// <returns>Returns the Models.GetSitesResponse response from the API call.</returns>
        public Models.GetSitesResponse GetSites(
                string version,
                string authorization = null,
                bool? requestIncludeLeadChannels = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSiteIds = null)
            => CoreHelper.RunTask(GetSitesAsync(version, authorization, requestIncludeLeadChannels, requestLimit, requestOffset, requestSiteIds));

        /// <summary>
        /// Gets a list of sites that the developer has permission to view.
        /// * Passing in no `SiteIds` returns all sites that the developer has access to.
        /// * Passing in one `SiteIds` returns more detailed information about the specified site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestIncludeLeadChannels">Optional parameter: This is an optional parameter to get lead channels for a Site..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSiteIds">Optional parameter: List of the requested site IDs. When omitted, returns all sites that the source has access to..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.GetSitesResponse response from the API call.</returns>
        public async Task<Models.GetSitesResponse> GetSitesAsync(
                string version,
                string authorization = null,
                bool? requestIncludeLeadChannels = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSiteIds = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.GetSitesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/sites")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.includeLeadChannels", requestIncludeLeadChannels))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.siteIds", requestSiteIds))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.GetSitesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Creates a new promocode record at the specified business. .
        /// This endpoint requires staff user credentials. This staff memeber should have enabled the **Set up promotions / Semester discounts** staff permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.AddPromoCodeResponse response from the API call.</returns>
        public Models.AddPromoCodeResponse AddPromoCode(
                string version,
                Models.AddPromoCodeRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(AddPromoCodeAsync(version, request, siteId, authorization));

        /// <summary>
        /// Creates a new promocode record at the specified business. .
        /// This endpoint requires staff user credentials. This staff memeber should have enabled the **Set up promotions / Semester discounts** staff permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.AddPromoCodeResponse response from the API call.</returns>
        public async Task<Models.AddPromoCodeResponse> AddPromoCodeAsync(
                string version,
                Models.AddPromoCodeRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.AddPromoCodeResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/site/addpromocode")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.AddPromoCodeResponse>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}