// <copyright file="SiteController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// SiteController.
    /// </summary>
    public class SiteController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SiteController"/> class.
        /// </summary>
        internal SiteController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// Before you can use this endpoint, MINDBODY must approve your developer account for live access. If you have finished testing in the sandbox and are ready to begin working with MINDBODY customers, log into your account and request to go live.
        /// See [Accessing Business Data From MINDBODY](https://developers.mindbodyonline.com/PublicDocumentation/V6#accessing-business-data) for more information about the activation code and how to use it.
        /// Once you are approved, this endpoint returns an activation code.This endpoint supports only one site per call.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetActivationCodeResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerGetActivationCodeResponse SiteGetActivationCode(
                string version,
                string authorization = null)
            => CoreHelper.RunTask(SiteGetActivationCodeAsync(version, authorization));

        /// <summary>
        /// Before you can use this endpoint, MINDBODY must approve your developer account for live access. If you have finished testing in the sandbox and are ready to begin working with MINDBODY customers, log into your account and request to go live.
        /// See [Accessing Business Data From MINDBODY](https://developers.mindbodyonline.com/PublicDocumentation/V6#accessing-business-data) for more information about the activation code and how to use it.
        /// Once you are approved, this endpoint returns an activation code.This endpoint supports only one site per call.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetActivationCodeResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetActivationCodeResponse> SiteGetActivationCodeAsync(
                string version,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetActivationCodeResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/activationcode")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetActivationCodeResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Gets the categories.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains categories which are activated.   When `false`, only deactivated categories are returned.  Default: **All Categories**.</param>
        /// <param name="requestCategoryIds">Optional parameter: When included, the response only contains details about the specified category Ids..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestService">Optional parameter: When `true`, the response only contains details about Revenue Categories.  When `false`, only Product Revenue Categories are returned.  Default: **All Categories**.</param>
        /// <param name="requestSubCategoryIds">Optional parameter: When included, the response only contains details about the specified subcategory Ids..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetCategoriesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerGetCategoriesResponse SiteGetCategories(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                List<int> requestCategoryIds = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestService = null,
                List<int> requestSubCategoryIds = null)
            => CoreHelper.RunTask(SiteGetCategoriesAsync(version, siteId, authorization, requestActive, requestCategoryIds, requestLimit, requestOffset, requestService, requestSubCategoryIds));

        /// <summary>
        /// Gets the categories.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains categories which are activated.   When `false`, only deactivated categories are returned.  Default: **All Categories**.</param>
        /// <param name="requestCategoryIds">Optional parameter: When included, the response only contains details about the specified category Ids..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestService">Optional parameter: When `true`, the response only contains details about Revenue Categories.  When `false`, only Product Revenue Categories are returned.  Default: **All Categories**.</param>
        /// <param name="requestSubCategoryIds">Optional parameter: When included, the response only contains details about the specified subcategory Ids..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetCategoriesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetCategoriesResponse> SiteGetCategoriesAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                List<int> requestCategoryIds = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestService = null,
                List<int> requestSubCategoryIds = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetCategoriesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/categories")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.active", requestActive))
                      .Query(_query => _query.Setup("request.categoryIds", requestCategoryIds))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.service", requestService))
                      .Query(_query => _query.Setup("request.subCategoryIds", requestSubCategoryIds))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetCategoriesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// The endpoint returns a list of configured client gender options for a site. Custom gender options are assignable to client genders only. Currently, custom values returned from this endpoint cannot be used as input for other endpoints to specify the genders of staff or client preferences.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetGendersResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerGetGendersResponse SiteGetGenders(
                string version,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(SiteGetGendersAsync(version, siteId, authorization));

        /// <summary>
        /// The endpoint returns a list of configured client gender options for a site. Custom gender options are assignable to client genders only. Currently, custom values returned from this endpoint cannot be used as input for other endpoints to specify the genders of staff or client preferences.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetGendersResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetGendersResponse> SiteGetGendersAsync(
                string version,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetGendersResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/genders")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetGendersResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get locations for a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetLocationsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerGetLocationsResponse SiteGetLocations(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null)
            => CoreHelper.RunTask(SiteGetLocationsAsync(version, siteId, authorization, requestLimit, requestOffset));

        /// <summary>
        /// Get locations for a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetLocationsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetLocationsResponse> SiteGetLocationsAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetLocationsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/locations")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetLocationsResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get the memberships at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestMembershipIds">Optional parameter: The requested membership IDs.<br />  Default: **all** IDs that the authenticated user's access level allows..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse SiteGetMemberships(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestMembershipIds = null)
            => CoreHelper.RunTask(SiteGetMembershipsAsync(version, siteId, authorization, requestMembershipIds));

        /// <summary>
        /// Get the memberships at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestMembershipIds">Optional parameter: The requested membership IDs.<br />  Default: **all** IDs that the authenticated user's access level allows..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse> SiteGetMembershipsAsync(
                string version,
                string siteId,
                string authorization = null,
                List<int> requestMembershipIds = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/memberships")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.membershipIds", requestMembershipIds))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get the list of mobile providers that are supported by the business.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains mobile providers which are activated.   When `false`, only deactivated mobile providers are returned.  Default: **All Mobile Providers**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetMobileProvidersResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerGetMobileProvidersResponse SiteGetMobileProviders(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null)
            => CoreHelper.RunTask(SiteGetMobileProvidersAsync(version, siteId, authorization, requestActive));

        /// <summary>
        /// Get the list of mobile providers that are supported by the business.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains mobile providers which are activated.   When `false`, only deactivated mobile providers are returned.  Default: **All Mobile Providers**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetMobileProvidersResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetMobileProvidersResponse> SiteGetMobileProvidersAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetMobileProvidersResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/mobileproviders")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.active", requestActive))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetMobileProvidersResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get payment types for a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains payment types which are activated.  When `false`, only deactivated payment types are returned.  Default: **All Payment Types**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetPaymentTypesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerGetPaymentTypesResponse SiteGetPaymentTypes(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null)
            => CoreHelper.RunTask(SiteGetPaymentTypesAsync(version, siteId, authorization, requestActive));

        /// <summary>
        /// Get payment types for a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains payment types which are activated.  When `false`, only deactivated payment types are returned.  Default: **All Payment Types**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetPaymentTypesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetPaymentTypesResponse> SiteGetPaymentTypesAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetPaymentTypesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/paymenttypes")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.active", requestActive))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetPaymentTypesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get service categories offered at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: If `true`, filters results to show only those programs that are shown online.<br />  If `false`, all programs are returned.<br />  Default: **false**.</param>
        /// <param name="requestScheduleType">Optional parameter: A schedule type used to filter the returned results. Possible values are:  * All  * Class  * Enrollment  * Appointment  * Resource  * Media  * Arrival.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetProgramsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerGetProgramsResponse SiteGetPrograms(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                Models.RequestScheduleTypeEnum? requestScheduleType = null)
            => CoreHelper.RunTask(SiteGetProgramsAsync(version, siteId, authorization, requestLimit, requestOffset, requestOnlineOnly, requestScheduleType));

        /// <summary>
        /// Get service categories offered at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: If `true`, filters results to show only those programs that are shown online.<br />  If `false`, all programs are returned.<br />  Default: **false**.</param>
        /// <param name="requestScheduleType">Optional parameter: A schedule type used to filter the returned results. Possible values are:  * All  * Class  * Enrollment  * Appointment  * Resource  * Media  * Arrival.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetProgramsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetProgramsResponse> SiteGetProgramsAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                Models.RequestScheduleTypeEnum? requestScheduleType = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetProgramsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/programs")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.onlineOnly", requestOnlineOnly))
                      .Query(_query => _query.Setup("request.scheduleType", (requestScheduleType.HasValue) ? ApiHelper.JsonSerialize(requestScheduleType.Value).Trim('\"') : null))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetProgramsResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Gets a list of promocodes at the specified business. This endpoint requires staff user credentials. .
        /// This staff member should have enabled the Set up promotions / **Semester discounts** staff permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActiveOnly">Optional parameter: If true, filters results to show only promocodes that are active. If **false**, all promocodes are returned.  Default: **true**.</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to promocodes that were activated before this date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: If `true`, filters results to show only promocodes that can be used for online sale.  If `false`, all promocodes are returned.  Default: **false**.</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to promocodes that were activated after this date..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetPromoCodesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerGetPromoCodesResponse SiteGetPromoCodes(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActiveOnly = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                DateTime? requestStartDate = null)
            => CoreHelper.RunTask(SiteGetPromoCodesAsync(version, siteId, authorization, requestActiveOnly, requestEndDate, requestLimit, requestOffset, requestOnlineOnly, requestStartDate));

        /// <summary>
        /// Gets a list of promocodes at the specified business. This endpoint requires staff user credentials. .
        /// This staff member should have enabled the Set up promotions / **Semester discounts** staff permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActiveOnly">Optional parameter: If true, filters results to show only promocodes that are active. If **false**, all promocodes are returned.  Default: **true**.</param>
        /// <param name="requestEndDate">Optional parameter: Filters results to promocodes that were activated before this date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: If `true`, filters results to show only promocodes that can be used for online sale.  If `false`, all promocodes are returned.  Default: **false**.</param>
        /// <param name="requestStartDate">Optional parameter: Filters results to promocodes that were activated after this date..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetPromoCodesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetPromoCodesResponse> SiteGetPromoCodesAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActiveOnly = null,
                DateTime? requestEndDate = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                DateTime? requestStartDate = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetPromoCodesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/promocodes")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.activeOnly", requestActiveOnly))
                      .Query(_query => _query.Setup("request.endDate", requestEndDate.HasValue ? requestEndDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.onlineOnly", requestOnlineOnly))
                      .Query(_query => _query.Setup("request.startDate", requestStartDate.HasValue ? requestStartDate.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetPromoCodesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get the list of prospect stages that represent the prospect stage options for prospective clients.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains prospect stages which are activated.  When `false`, only deactivated prospect stages are returned.  Default: **All Prospect Stages**.</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetProspectStagesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerGetProspectStagesResponse SiteGetProspectStages(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null)
            => CoreHelper.RunTask(SiteGetProspectStagesAsync(version, siteId, authorization, requestActive));

        /// <summary>
        /// Get the list of prospect stages that represent the prospect stage options for prospective clients.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains prospect stages which are activated.  When `false`, only deactivated prospect stages are returned.  Default: **All Prospect Stages**.</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetProspectStagesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetProspectStagesResponse> SiteGetProspectStagesAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetProspectStagesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/prospectstages")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.active", requestActive))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetProspectStagesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// This endpoint retrieves the business site relationships.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains relationships which are activated.  When `false`, only deactivated relationships are returned.  Default: **All Relationships**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetRelationshipsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerGetRelationshipsResponse SiteGetRelationships(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                int? requestLimit = null,
                int? requestOffset = null)
            => CoreHelper.RunTask(SiteGetRelationshipsAsync(version, siteId, authorization, requestActive, requestLimit, requestOffset));

        /// <summary>
        /// This endpoint retrieves the business site relationships.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestActive">Optional parameter: When `true`, the response only contains relationships which are activated.  When `false`, only deactivated relationships are returned.  Default: **All Relationships**.</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetRelationshipsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetRelationshipsResponse> SiteGetRelationshipsAsync(
                string version,
                string siteId,
                string authorization = null,
                bool? requestActive = null,
                int? requestLimit = null,
                int? requestOffset = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetRelationshipsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/relationships")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.active", requestActive))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetRelationshipsResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get resources used at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDateTime">Optional parameter: The time the resource ends. This parameter is ignored if `EndDateTime` or `LocationID` is not set..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: The location of the resource. This parameter is ignored if `EndDateTime` or `LocationID` is not set.<br />  Default: **all**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: List of session type IDs.<br />  Default: **all**.</param>
        /// <param name="requestStartDateTime">Optional parameter: The time the resource starts. This parameter is ignored if `EndDateTime` or `LocationID` is not set..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetResourcesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerGetResourcesResponse SiteGetResources(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestSessionTypeIds = null,
                DateTime? requestStartDateTime = null)
            => CoreHelper.RunTask(SiteGetResourcesAsync(version, siteId, authorization, requestEndDateTime, requestLimit, requestLocationId, requestOffset, requestSessionTypeIds, requestStartDateTime));

        /// <summary>
        /// Get resources used at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDateTime">Optional parameter: The time the resource ends. This parameter is ignored if `EndDateTime` or `LocationID` is not set..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: The location of the resource. This parameter is ignored if `EndDateTime` or `LocationID` is not set.<br />  Default: **all**.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSessionTypeIds">Optional parameter: List of session type IDs.<br />  Default: **all**.</param>
        /// <param name="requestStartDateTime">Optional parameter: The time the resource starts. This parameter is ignored if `EndDateTime` or `LocationID` is not set..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetResourcesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetResourcesResponse> SiteGetResourcesAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                List<int> requestSessionTypeIds = null,
                DateTime? requestStartDateTime = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetResourcesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/resources")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endDateTime", requestEndDateTime.HasValue ? requestEndDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.sessionTypeIds", requestSessionTypeIds))
                      .Query(_query => _query.Setup("request.startDateTime", requestStartDateTime.HasValue ? requestStartDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetResourcesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Get the session types used at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: When `true`, indicates that only the session types that can be booked online should be returned.<br />  Default: **false**.</param>
        /// <param name="requestProgramIDs">Optional parameter: Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetSessionTypesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerGetSessionTypesResponse SiteGetSessionTypes(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                List<int> requestProgramIDs = null)
            => CoreHelper.RunTask(SiteGetSessionTypesAsync(version, siteId, authorization, requestLimit, requestOffset, requestOnlineOnly, requestProgramIDs));

        /// <summary>
        /// Get the session types used at a site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestOnlineOnly">Optional parameter: When `true`, indicates that only the session types that can be booked online should be returned.<br />  Default: **false**.</param>
        /// <param name="requestProgramIDs">Optional parameter: Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetSessionTypesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetSessionTypesResponse> SiteGetSessionTypesAsync(
                string version,
                string siteId,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                bool? requestOnlineOnly = null,
                List<int> requestProgramIDs = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetSessionTypesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/sessiontypes")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.onlineOnly", requestOnlineOnly))
                      .Query(_query => _query.Setup("request.programIDs", requestProgramIDs))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetSessionTypesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Gets a list of sites that the developer has permission to view.
        /// * Passing in no `SiteIds` returns all sites that the developer has access to.
        /// * Passing in one `SiteIds` returns more detailed information about the specified site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSiteIds">Optional parameter: List of the requested site IDs. When omitted, returns all sites that the source has access to..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetSitesResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerGetSitesResponse SiteGetSites(
                string version,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSiteIds = null)
            => CoreHelper.RunTask(SiteGetSitesAsync(version, authorization, requestLimit, requestOffset, requestSiteIds));

        /// <summary>
        /// Gets a list of sites that the developer has permission to view.
        /// * Passing in no `SiteIds` returns all sites that the developer has access to.
        /// * Passing in one `SiteIds` returns more detailed information about the specified site.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestSiteIds">Optional parameter: List of the requested site IDs. When omitted, returns all sites that the source has access to..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerGetSitesResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetSitesResponse> SiteGetSitesAsync(
                string version,
                string authorization = null,
                int? requestLimit = null,
                int? requestOffset = null,
                List<int> requestSiteIds = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetSitesResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/site/sites")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.siteIds", requestSiteIds))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerGetSitesResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Creates a new promocode record at the specified business. .
        /// This endpoint requires staff user credentials. This staff memeber should have enabled the **Set up promotions / Semester discounts** staff permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeResponse SiteAddPromoCode(
                string version,
                Models.MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeRequest request,
                string siteId,
                string authorization = null)
            => CoreHelper.RunTask(SiteAddPromoCodeAsync(version, request, siteId, authorization));

        /// <summary>
        /// Creates a new promocode record at the specified business. .
        /// This endpoint requires staff user credentials. This staff memeber should have enabled the **Set up promotions / Semester discounts** staff permission.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="request">Required parameter: Example: .</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeResponse> SiteAddPromoCodeAsync(
                string version,
                Models.MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeRequest request,
                string siteId,
                string authorization = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/public/v{version}/site/addpromocode")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Body(_bodyParameter => _bodyParameter.Setup(request))
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("Content-Type", "application/json"))
                      .Header(_header => _header.Setup("authorization", authorization))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6SiteControllerAddPromoCodeResponse>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}