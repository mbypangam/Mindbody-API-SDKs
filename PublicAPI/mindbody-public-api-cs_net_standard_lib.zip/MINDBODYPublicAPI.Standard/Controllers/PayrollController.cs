// <copyright file="PayrollController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// PayrollController.
    /// </summary>
    public class PayrollController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PayrollController"/> class.
        /// </summary>
        internal PayrollController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// A staff authorization token is not required for this endpoint, but if one is passed, its permissions are honored. Depending on the access permissions configured for the staff member whose token is passed, .
        /// the endpoint returns either only the payroll information for that staff member or it returns the payroll information for all staff members.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDateTime">Optional parameter: The end of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br />  Default: **Today's date**  * If you do not supply an `EndDateTime`, the data returns for the period from the `StartDateTime` that you supply to today's date.  * If you do not supply an `EndDateTime` or a `StartDateTime`, data returns for the seven days prior to today's date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: A LocationId that you want to retrieve payroll information for. If you do not supply a `LocationId`, data from all locations is returned..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffId">Optional parameter: A list of staff IDs that you want to retrieve payroll information for. If you do not supply a `StaffId`, all active staff members return, ordered by staff ID..</param>
        /// <param name="requestStartDateTime">Optional parameter: The beginning of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.  * If you do not supply a `StartDateTime`, data returns for the seven days prior to the `EndDateTime` that you supply.  * If you do not supply either a `StartDateTime` or an `EndDateTime`, the data returns for seven days prior to today's date..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetCommissionsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetCommissionsResponse PayrollGetCommissions(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                long? requestStaffId = null,
                DateTime? requestStartDateTime = null)
            => CoreHelper.RunTask(PayrollGetCommissionsAsync(version, siteId, authorization, requestEndDateTime, requestLimit, requestLocationId, requestOffset, requestStaffId, requestStartDateTime));

        /// <summary>
        /// A staff authorization token is not required for this endpoint, but if one is passed, its permissions are honored. Depending on the access permissions configured for the staff member whose token is passed, .
        /// the endpoint returns either only the payroll information for that staff member or it returns the payroll information for all staff members.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDateTime">Optional parameter: The end of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br />  Default: **Today's date**  * If you do not supply an `EndDateTime`, the data returns for the period from the `StartDateTime` that you supply to today's date.  * If you do not supply an `EndDateTime` or a `StartDateTime`, data returns for the seven days prior to today's date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: A LocationId that you want to retrieve payroll information for. If you do not supply a `LocationId`, data from all locations is returned..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffId">Optional parameter: A list of staff IDs that you want to retrieve payroll information for. If you do not supply a `StaffId`, all active staff members return, ordered by staff ID..</param>
        /// <param name="requestStartDateTime">Optional parameter: The beginning of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.  * If you do not supply a `StartDateTime`, data returns for the seven days prior to the `EndDateTime` that you supply.  * If you do not supply either a `StartDateTime` or an `EndDateTime`, the data returns for seven days prior to today's date..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetCommissionsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetCommissionsResponse> PayrollGetCommissionsAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                long? requestStaffId = null,
                DateTime? requestStartDateTime = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetCommissionsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/payroll/commissions")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endDateTime", requestEndDateTime.HasValue ? requestEndDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.staffId", requestStaffId))
                      .Query(_query => _query.Setup("request.startDateTime", requestStartDateTime.HasValue ? requestStartDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetCommissionsResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// A staff authorization token is not required for this endpoint, but if one is passed, its permissions are honored. Depending on the access permissions configured for the staff member whose token is passed, the endpoint returns either only the payroll information for that staff member or it returns the payroll information for all staff members.
        /// Note that if a staff member is not paid for a class, earnings of zero are returned by this endpoint.
        /// Note that this endpoint calculates both bonus and no-reg rates for assistants.These rates are not supported by the Payroll report in the web interface.
        /// Note that this endpoint returns both the teacher's adjusted rate and the assistant's pay rate when the assistant is paid by the teacher.The Payroll report in the web interface only returns the teacher's adjusted rate.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDateTime">Optional parameter: The end of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br />  Default: **Today's date**  * If you do not supply an `EndDateTime`, the data returns for the period from the `StartDateTime` that you supply to today's date.  * If you do not supply an `EndDateTime` or a `StartDateTime`, data returns for the seven days prior to today's date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: A LocationId that you want to retrieve payroll information for. If you do not supply a `LocationId`, data from all locations is returned..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestScheduledServiceId">Optional parameter: Filters the results to a single scheduled service. This parameter must be used with a single ScheduledServiceType..</param>
        /// <param name="requestScheduledServiceType">Optional parameter: Filters the results to schedule service earnings for specific types of services. Possible values:  * Class  * Appointment.</param>
        /// <param name="requestStaffId">Optional parameter: A list of staff IDs that you want to retrieve payroll information for. If you do not supply a `StaffId`, all active staff members return, ordered by staff ID..</param>
        /// <param name="requestStartDateTime">Optional parameter: The beginning of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.  * If you do not supply a `StartDateTime`, data returns for the seven days prior to the `EndDateTime` that you supply.  * If you do not supply either a `StartDateTime` or an `EndDateTime`, the data returns for seven days prior to today's date..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetScheduledServiceEarningsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetScheduledServiceEarningsResponse PayrollGetScheduledServiceEarnings(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                long? requestScheduledServiceId = null,
                string requestScheduledServiceType = null,
                long? requestStaffId = null,
                DateTime? requestStartDateTime = null)
            => CoreHelper.RunTask(PayrollGetScheduledServiceEarningsAsync(version, siteId, authorization, requestEndDateTime, requestLimit, requestLocationId, requestOffset, requestScheduledServiceId, requestScheduledServiceType, requestStaffId, requestStartDateTime));

        /// <summary>
        /// A staff authorization token is not required for this endpoint, but if one is passed, its permissions are honored. Depending on the access permissions configured for the staff member whose token is passed, the endpoint returns either only the payroll information for that staff member or it returns the payroll information for all staff members.
        /// Note that if a staff member is not paid for a class, earnings of zero are returned by this endpoint.
        /// Note that this endpoint calculates both bonus and no-reg rates for assistants.These rates are not supported by the Payroll report in the web interface.
        /// Note that this endpoint returns both the teacher's adjusted rate and the assistant's pay rate when the assistant is paid by the teacher.The Payroll report in the web interface only returns the teacher's adjusted rate.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDateTime">Optional parameter: The end of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br />  Default: **Today's date**  * If you do not supply an `EndDateTime`, the data returns for the period from the `StartDateTime` that you supply to today's date.  * If you do not supply an `EndDateTime` or a `StartDateTime`, data returns for the seven days prior to today's date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: A LocationId that you want to retrieve payroll information for. If you do not supply a `LocationId`, data from all locations is returned..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestScheduledServiceId">Optional parameter: Filters the results to a single scheduled service. This parameter must be used with a single ScheduledServiceType..</param>
        /// <param name="requestScheduledServiceType">Optional parameter: Filters the results to schedule service earnings for specific types of services. Possible values:  * Class  * Appointment.</param>
        /// <param name="requestStaffId">Optional parameter: A list of staff IDs that you want to retrieve payroll information for. If you do not supply a `StaffId`, all active staff members return, ordered by staff ID..</param>
        /// <param name="requestStartDateTime">Optional parameter: The beginning of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.  * If you do not supply a `StartDateTime`, data returns for the seven days prior to the `EndDateTime` that you supply.  * If you do not supply either a `StartDateTime` or an `EndDateTime`, the data returns for seven days prior to today's date..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetScheduledServiceEarningsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetScheduledServiceEarningsResponse> PayrollGetScheduledServiceEarningsAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                long? requestScheduledServiceId = null,
                string requestScheduledServiceType = null,
                long? requestStaffId = null,
                DateTime? requestStartDateTime = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetScheduledServiceEarningsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/payroll/scheduledserviceearnings")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endDateTime", requestEndDateTime.HasValue ? requestEndDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.scheduledServiceId", requestScheduledServiceId))
                      .Query(_query => _query.Setup("request.scheduledServiceType", requestScheduledServiceType))
                      .Query(_query => _query.Setup("request.staffId", requestStaffId))
                      .Query(_query => _query.Setup("request.startDateTime", requestStartDateTime.HasValue ? requestStartDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetScheduledServiceEarningsResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// This endpoint returns information for all locations. The **View reports for all locations permission **is not supported for staff auth tokens.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDateTime">Optional parameter: The end of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br />  Default: **Today's date**  * If you do not supply an `EndDateTime`, the data returns for the period from the `StartDateTime` that you supply to today's date.  * If you do not supply an `EndDateTime` or a `StartDateTime`, data returns for the seven days prior to today's date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: A LocationId that you want to retrieve payroll information for. If you do not supply a `LocationId`, data from all locations is returned..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffId">Optional parameter: A list of staff IDs that you want to retrieve payroll information for. If you do not supply a `StaffId`, all active staff members return, ordered by staff ID..</param>
        /// <param name="requestStartDateTime">Optional parameter: The beginning of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.  * If you do not supply a `StartDateTime`, data returns for the seven days prior to the `EndDateTime` that you supply.  * If you do not supply either a `StartDateTime` or an `EndDateTime`, the data returns for seven days prior to today's date..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetTimeCardsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetTimeCardsResponse PayrollGetTimeCards(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                long? requestStaffId = null,
                DateTime? requestStartDateTime = null)
            => CoreHelper.RunTask(PayrollGetTimeCardsAsync(version, siteId, authorization, requestEndDateTime, requestLimit, requestLocationId, requestOffset, requestStaffId, requestStartDateTime));

        /// <summary>
        /// This endpoint returns information for all locations. The **View reports for all locations permission **is not supported for staff auth tokens.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDateTime">Optional parameter: The end of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br />  Default: **Today's date**  * If you do not supply an `EndDateTime`, the data returns for the period from the `StartDateTime` that you supply to today's date.  * If you do not supply an `EndDateTime` or a `StartDateTime`, data returns for the seven days prior to today's date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: A LocationId that you want to retrieve payroll information for. If you do not supply a `LocationId`, data from all locations is returned..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffId">Optional parameter: A list of staff IDs that you want to retrieve payroll information for. If you do not supply a `StaffId`, all active staff members return, ordered by staff ID..</param>
        /// <param name="requestStartDateTime">Optional parameter: The beginning of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.  * If you do not supply a `StartDateTime`, data returns for the seven days prior to the `EndDateTime` that you supply.  * If you do not supply either a `StartDateTime` or an `EndDateTime`, the data returns for seven days prior to today's date..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetTimeCardsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetTimeCardsResponse> PayrollGetTimeCardsAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                long? requestStaffId = null,
                DateTime? requestStartDateTime = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetTimeCardsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/payroll/timecards")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endDateTime", requestEndDateTime.HasValue ? requestEndDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.staffId", requestStaffId))
                      .Query(_query => _query.Setup("request.startDateTime", requestStartDateTime.HasValue ? requestStartDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetTimeCardsResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// A staff authorization token is not required for this endpoint, but if one is passed, its permissions are honored. Depending on the access permissions configured for the staff member whose token is passed, .
        /// the endpoint returns either only the payroll information for that staff member or it returns the payroll information for all staff members.
        /// This endpoint returns information for all locations.The** View reports for all locations **permission is not supported for staff auth tokens.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDateTime">Optional parameter: The end of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br />  Default: **Today's date**  * If you do not supply an `EndDateTime`, the data returns for the period from the `StartDateTime` that you supply to today's date.  * If you do not supply an `EndDateTime` or a `StartDateTime`, data returns for the seven days prior to today's date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: A LocationId that you want to retrieve payroll information for. If you do not supply a `LocationId`, data from all locations is returned..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffId">Optional parameter: A list of staff IDs that you want to retrieve payroll information for. If you do not supply a `StaffId`, all active staff members return, ordered by staff ID..</param>
        /// <param name="requestStartDateTime">Optional parameter: The beginning of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.  * If you do not supply a `StartDateTime`, data returns for the seven days prior to the `EndDateTime` that you supply.  * If you do not supply either a `StartDateTime` or an `EndDateTime`, the data returns for seven days prior to today's date..</param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetTipsResponse response from the API call.</returns>
        public Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetTipsResponse PayrollGetTips(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                long? requestStaffId = null,
                DateTime? requestStartDateTime = null)
            => CoreHelper.RunTask(PayrollGetTipsAsync(version, siteId, authorization, requestEndDateTime, requestLimit, requestLocationId, requestOffset, requestStaffId, requestStartDateTime));

        /// <summary>
        /// A staff authorization token is not required for this endpoint, but if one is passed, its permissions are honored. Depending on the access permissions configured for the staff member whose token is passed, .
        /// the endpoint returns either only the payroll information for that staff member or it returns the payroll information for all staff members.
        /// This endpoint returns information for all locations.The** View reports for all locations **permission is not supported for staff auth tokens.
        /// </summary>
        /// <param name="version">Required parameter: version of the api..</param>
        /// <param name="siteId">Required parameter: ID of the site from which to pull data..</param>
        /// <param name="authorization">Optional parameter: A staff user authorization token..</param>
        /// <param name="requestEndDateTime">Optional parameter: The end of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.<br />  Default: **Today's date**  * If you do not supply an `EndDateTime`, the data returns for the period from the `StartDateTime` that you supply to today's date.  * If you do not supply an `EndDateTime` or a `StartDateTime`, data returns for the seven days prior to today's date..</param>
        /// <param name="requestLimit">Optional parameter: Number of results to include, defaults to 100.</param>
        /// <param name="requestLocationId">Optional parameter: A LocationId that you want to retrieve payroll information for. If you do not supply a `LocationId`, data from all locations is returned..</param>
        /// <param name="requestOffset">Optional parameter: Page offset, defaults to 0..</param>
        /// <param name="requestStaffId">Optional parameter: A list of staff IDs that you want to retrieve payroll information for. If you do not supply a `StaffId`, all active staff members return, ordered by staff ID..</param>
        /// <param name="requestStartDateTime">Optional parameter: The beginning of the date range for the payroll information to be returned. The maximum allowed date range is 14 days.  * If you do not supply a `StartDateTime`, data returns for the seven days prior to the `EndDateTime` that you supply.  * If you do not supply either a `StartDateTime` or an `EndDateTime`, the data returns for seven days prior to today's date..</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetTipsResponse response from the API call.</returns>
        public async Task<Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetTipsResponse> PayrollGetTipsAsync(
                string version,
                string siteId,
                string authorization = null,
                DateTime? requestEndDateTime = null,
                int? requestLimit = null,
                int? requestLocationId = null,
                int? requestOffset = null,
                long? requestStaffId = null,
                DateTime? requestStartDateTime = null,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetTipsResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Get, "/public/v{version}/payroll/tips")
                  .WithAuth("global")
                  .Parameters(_parameters => _parameters
                      .Template(_template => _template.Setup("version", version))
                      .Header(_header => _header.Setup("siteId", siteId))
                      .Header(_header => _header.Setup("authorization", authorization))
                      .Query(_query => _query.Setup("request.endDateTime", requestEndDateTime.HasValue ? requestEndDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))
                      .Query(_query => _query.Setup("request.limit", requestLimit))
                      .Query(_query => _query.Setup("request.locationId", requestLocationId))
                      .Query(_query => _query.Setup("request.offset", requestOffset))
                      .Query(_query => _query.Setup("request.staffId", requestStaffId))
                      .Query(_query => _query.Setup("request.startDateTime", requestStartDateTime.HasValue ? requestStartDateTime.Value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss.FFFFFFFK") : null))))
              .ResponseHandler(_responseHandler => _responseHandler
                  .Deserializer(_response => ApiHelper.JsonDeserialize<Models.MindbodyPublicApiDtoModelsV6PayrollControllerGetTipsResponse>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}