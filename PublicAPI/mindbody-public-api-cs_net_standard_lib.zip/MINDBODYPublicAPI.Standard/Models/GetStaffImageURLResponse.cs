// <copyright file="GetStaffImageURLResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetStaffImageURLResponse.
    /// </summary>
    public class GetStaffImageURLResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetStaffImageURLResponse"/> class.
        /// </summary>
        public GetStaffImageURLResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetStaffImageURLResponse"/> class.
        /// </summary>
        /// <param name="imageURL">ImageURL.</param>
        /// <param name="mobileImageURL">MobileImageURL.</param>
        public GetStaffImageURLResponse(
            string imageURL = null,
            string mobileImageURL = null)
        {
            this.ImageURL = imageURL;
            this.MobileImageURL = mobileImageURL;
        }

        /// <summary>
        /// A staff member's image URL.
        /// </summary>
        [JsonProperty("ImageURL", NullValueHandling = NullValueHandling.Ignore)]
        public string ImageURL { get; set; }

        /// <summary>
        /// A staff member's mobile image URL.
        /// </summary>
        [JsonProperty("MobileImageURL", NullValueHandling = NullValueHandling.Ignore)]
        public string MobileImageURL { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetStaffImageURLResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetStaffImageURLResponse other &&
                ((this.ImageURL == null && other.ImageURL == null) || (this.ImageURL?.Equals(other.ImageURL) == true)) &&
                ((this.MobileImageURL == null && other.MobileImageURL == null) || (this.MobileImageURL?.Equals(other.MobileImageURL) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ImageURL = {(this.ImageURL == null ? "null" : this.ImageURL == string.Empty ? "" : this.ImageURL)}");
            toStringOutput.Add($"this.MobileImageURL = {(this.MobileImageURL == null ? "null" : this.MobileImageURL == string.Empty ? "" : this.MobileImageURL)}");
        }
    }
}