// <copyright file="DeleteReservationResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// DeleteReservationResponse.
    /// </summary>
    public class DeleteReservationResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DeleteReservationResponse"/> class.
        /// </summary>
        public DeleteReservationResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DeleteReservationResponse"/> class.
        /// </summary>
        /// <param name="deleteSucceeded">DeleteSucceeded.</param>
        /// <param name="responseDetail">ResponseDetail.</param>
        public DeleteReservationResponse(
            bool? deleteSucceeded = null,
            Models.ResponseDetails responseDetail = null)
        {
            this.DeleteSucceeded = deleteSucceeded;
            this.ResponseDetail = responseDetail;
        }

        /// <summary>
        /// delete successded status.
        /// </summary>
        [JsonProperty("DeleteSucceeded", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DeleteSucceeded { get; set; }

        /// <summary>
        /// Response details information.
        /// </summary>
        [JsonProperty("ResponseDetail", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseDetails ResponseDetail { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"DeleteReservationResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is DeleteReservationResponse other &&
                ((this.DeleteSucceeded == null && other.DeleteSucceeded == null) || (this.DeleteSucceeded?.Equals(other.DeleteSucceeded) == true)) &&
                ((this.ResponseDetail == null && other.ResponseDetail == null) || (this.ResponseDetail?.Equals(other.ResponseDetail) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.DeleteSucceeded = {(this.DeleteSucceeded == null ? "null" : this.DeleteSucceeded.ToString())}");
            toStringOutput.Add($"this.ResponseDetail = {(this.ResponseDetail == null ? "null" : this.ResponseDetail.ToString())}");
        }
    }
}