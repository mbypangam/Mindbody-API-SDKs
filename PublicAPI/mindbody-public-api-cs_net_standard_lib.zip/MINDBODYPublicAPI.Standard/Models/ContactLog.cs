// <copyright file="ContactLog.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// ContactLog.
    /// </summary>
    public class ContactLog
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ContactLog"/> class.
        /// </summary>
        public ContactLog()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ContactLog"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="text">Text.</param>
        /// <param name="createdDateTime">CreatedDateTime.</param>
        /// <param name="followupByDate">FollowupByDate.</param>
        /// <param name="contactMethod">ContactMethod.</param>
        /// <param name="contactName">ContactName.</param>
        /// <param name="client">Client.</param>
        /// <param name="createdBy">CreatedBy.</param>
        /// <param name="assignedTo">AssignedTo.</param>
        /// <param name="comments">Comments.</param>
        /// <param name="types">Types.</param>
        public ContactLog(
            long? id = null,
            string text = null,
            DateTime? createdDateTime = null,
            DateTime? followupByDate = null,
            string contactMethod = null,
            string contactName = null,
            Models.Client client = null,
            Models.Staff createdBy = null,
            Models.Staff assignedTo = null,
            List<Models.ContactLogComment> comments = null,
            List<Models.ContactLogType> types = null)
        {
            this.Id = id;
            this.Text = text;
            this.CreatedDateTime = createdDateTime;
            this.FollowupByDate = followupByDate;
            this.ContactMethod = contactMethod;
            this.ContactName = contactName;
            this.Client = client;
            this.CreatedBy = createdBy;
            this.AssignedTo = assignedTo;
            this.Comments = comments;
            this.Types = types;
        }

        /// <summary>
        /// The contact log’s ID.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public long? Id { get; set; }

        /// <summary>
        /// The contact log’s body text.
        /// </summary>
        [JsonProperty("Text", NullValueHandling = NullValueHandling.Ignore)]
        public string Text { get; set; }

        /// <summary>
        /// The local date and time when the contact log was created.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("CreatedDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? CreatedDateTime { get; set; }

        /// <summary>
        /// The date by which the assigned staff member should close or follow up on this contact log.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("FollowupByDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? FollowupByDate { get; set; }

        /// <summary>
        /// The method by which the client wants to be contacted.
        /// </summary>
        [JsonProperty("ContactMethod", NullValueHandling = NullValueHandling.Ignore)]
        public string ContactMethod { get; set; }

        /// <summary>
        /// The name of the client to contact.
        /// </summary>
        [JsonProperty("ContactName", NullValueHandling = NullValueHandling.Ignore)]
        public string ContactName { get; set; }

        /// <summary>
        /// The Client.
        /// </summary>
        [JsonProperty("Client", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Client Client { get; set; }

        /// <summary>
        /// The Staff
        /// </summary>
        [JsonProperty("CreatedBy", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Staff CreatedBy { get; set; }

        /// <summary>
        /// The Staff
        /// </summary>
        [JsonProperty("AssignedTo", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Staff AssignedTo { get; set; }

        /// <summary>
        /// Information about the comment.
        /// </summary>
        [JsonProperty("Comments", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ContactLogComment> Comments { get; set; }

        /// <summary>
        /// Information about the type of contact log.
        /// </summary>
        [JsonProperty("Types", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ContactLogType> Types { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ContactLog : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is ContactLog other &&                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Text == null && other.Text == null) || (this.Text?.Equals(other.Text) == true)) &&
                ((this.CreatedDateTime == null && other.CreatedDateTime == null) || (this.CreatedDateTime?.Equals(other.CreatedDateTime) == true)) &&
                ((this.FollowupByDate == null && other.FollowupByDate == null) || (this.FollowupByDate?.Equals(other.FollowupByDate) == true)) &&
                ((this.ContactMethod == null && other.ContactMethod == null) || (this.ContactMethod?.Equals(other.ContactMethod) == true)) &&
                ((this.ContactName == null && other.ContactName == null) || (this.ContactName?.Equals(other.ContactName) == true)) &&
                ((this.Client == null && other.Client == null) || (this.Client?.Equals(other.Client) == true)) &&
                ((this.CreatedBy == null && other.CreatedBy == null) || (this.CreatedBy?.Equals(other.CreatedBy) == true)) &&
                ((this.AssignedTo == null && other.AssignedTo == null) || (this.AssignedTo?.Equals(other.AssignedTo) == true)) &&
                ((this.Comments == null && other.Comments == null) || (this.Comments?.Equals(other.Comments) == true)) &&
                ((this.Types == null && other.Types == null) || (this.Types?.Equals(other.Types) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Text = {(this.Text == null ? "null" : this.Text)}");
            toStringOutput.Add($"this.CreatedDateTime = {(this.CreatedDateTime == null ? "null" : this.CreatedDateTime.ToString())}");
            toStringOutput.Add($"this.FollowupByDate = {(this.FollowupByDate == null ? "null" : this.FollowupByDate.ToString())}");
            toStringOutput.Add($"this.ContactMethod = {(this.ContactMethod == null ? "null" : this.ContactMethod)}");
            toStringOutput.Add($"this.ContactName = {(this.ContactName == null ? "null" : this.ContactName)}");
            toStringOutput.Add($"this.Client = {(this.Client == null ? "null" : this.Client.ToString())}");
            toStringOutput.Add($"this.CreatedBy = {(this.CreatedBy == null ? "null" : this.CreatedBy.ToString())}");
            toStringOutput.Add($"this.AssignedTo = {(this.AssignedTo == null ? "null" : this.AssignedTo.ToString())}");
            toStringOutput.Add($"this.Comments = {(this.Comments == null ? "null" : $"[{string.Join(", ", this.Comments)} ]")}");
            toStringOutput.Add($"this.Types = {(this.Types == null ? "null" : $"[{string.Join(", ", this.Types)} ]")}");
        }
    }
}