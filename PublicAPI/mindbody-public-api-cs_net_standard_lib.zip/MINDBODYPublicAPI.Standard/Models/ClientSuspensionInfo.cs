// <copyright file="ClientSuspensionInfo.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// ClientSuspensionInfo.
    /// </summary>
    public class ClientSuspensionInfo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClientSuspensionInfo"/> class.
        /// </summary>
        public ClientSuspensionInfo()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ClientSuspensionInfo"/> class.
        /// </summary>
        /// <param name="bookingSuspended">BookingSuspended.</param>
        /// <param name="suspensionStartDate">SuspensionStartDate.</param>
        /// <param name="suspensionEndDate">SuspensionEndDate.</param>
        public ClientSuspensionInfo(
            bool? bookingSuspended = null,
            string suspensionStartDate = null,
            string suspensionEndDate = null)
        {
            this.BookingSuspended = bookingSuspended;
            this.SuspensionStartDate = suspensionStartDate;
            this.SuspensionEndDate = suspensionEndDate;
        }

        /// <summary>
        /// When 'true', indicates that the client is suspended from booking
        /// </summary>
        [JsonProperty("BookingSuspended", NullValueHandling = NullValueHandling.Ignore)]
        public bool? BookingSuspended { get; set; }

        /// <summary>
        /// Indicates the Date that BookingSuspension starts 'YYYY-MM-DD'
        /// </summary>
        [JsonProperty("SuspensionStartDate", NullValueHandling = NullValueHandling.Ignore)]
        public string SuspensionStartDate { get; set; }

        /// <summary>
        /// Indicates the Date that BookingSuspension ends 'YYYY-MM-DD'
        /// </summary>
        [JsonProperty("SuspensionEndDate", NullValueHandling = NullValueHandling.Ignore)]
        public string SuspensionEndDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ClientSuspensionInfo : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is ClientSuspensionInfo other &&                ((this.BookingSuspended == null && other.BookingSuspended == null) || (this.BookingSuspended?.Equals(other.BookingSuspended) == true)) &&
                ((this.SuspensionStartDate == null && other.SuspensionStartDate == null) || (this.SuspensionStartDate?.Equals(other.SuspensionStartDate) == true)) &&
                ((this.SuspensionEndDate == null && other.SuspensionEndDate == null) || (this.SuspensionEndDate?.Equals(other.SuspensionEndDate) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BookingSuspended = {(this.BookingSuspended == null ? "null" : this.BookingSuspended.ToString())}");
            toStringOutput.Add($"this.SuspensionStartDate = {(this.SuspensionStartDate == null ? "null" : this.SuspensionStartDate)}");
            toStringOutput.Add($"this.SuspensionEndDate = {(this.SuspensionEndDate == null ? "null" : this.SuspensionEndDate)}");
        }
    }
}