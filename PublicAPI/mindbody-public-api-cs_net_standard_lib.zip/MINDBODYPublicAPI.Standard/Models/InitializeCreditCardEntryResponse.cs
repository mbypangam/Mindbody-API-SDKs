// <copyright file="InitializeCreditCardEntryResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// InitializeCreditCardEntryResponse.
    /// </summary>
    public class InitializeCreditCardEntryResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InitializeCreditCardEntryResponse"/> class.
        /// </summary>
        public InitializeCreditCardEntryResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InitializeCreditCardEntryResponse"/> class.
        /// </summary>
        /// <param name="callbackUrl">CallbackUrl.</param>
        public InitializeCreditCardEntryResponse(
            string callbackUrl = null)
        {
            this.CallbackUrl = callbackUrl;
        }

        /// <summary>
        /// Gets or sets CallbackUrl.
        /// </summary>
        [JsonProperty("CallbackUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string CallbackUrl { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"InitializeCreditCardEntryResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is InitializeCreditCardEntryResponse other &&
                ((this.CallbackUrl == null && other.CallbackUrl == null) || (this.CallbackUrl?.Equals(other.CallbackUrl) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CallbackUrl = {(this.CallbackUrl == null ? "null" : this.CallbackUrl == string.Empty ? "" : this.CallbackUrl)}");
        }
    }
}