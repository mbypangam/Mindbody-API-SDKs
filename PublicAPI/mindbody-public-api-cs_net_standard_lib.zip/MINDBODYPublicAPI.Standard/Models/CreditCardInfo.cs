// <copyright file="CreditCardInfo.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CreditCardInfo.
    /// </summary>
    public class CreditCardInfo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreditCardInfo"/> class.
        /// </summary>
        public CreditCardInfo()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreditCardInfo"/> class.
        /// </summary>
        /// <param name="creditCardNumber">CreditCardNumber.</param>
        /// <param name="expMonth">ExpMonth.</param>
        /// <param name="expYear">ExpYear.</param>
        /// <param name="billingName">BillingName.</param>
        /// <param name="billingAddress">BillingAddress.</param>
        /// <param name="billingCity">BillingCity.</param>
        /// <param name="billingState">BillingState.</param>
        /// <param name="billingPostalCode">BillingPostalCode.</param>
        /// <param name="saveInfo">SaveInfo.</param>
        /// <param name="cardId">CardId.</param>
        public CreditCardInfo(
            string creditCardNumber = null,
            string expMonth = null,
            string expYear = null,
            string billingName = null,
            string billingAddress = null,
            string billingCity = null,
            string billingState = null,
            string billingPostalCode = null,
            bool? saveInfo = null,
            string cardId = null)
        {
            this.CreditCardNumber = creditCardNumber;
            this.ExpMonth = expMonth;
            this.ExpYear = expYear;
            this.BillingName = billingName;
            this.BillingAddress = billingAddress;
            this.BillingCity = billingCity;
            this.BillingState = billingState;
            this.BillingPostalCode = billingPostalCode;
            this.SaveInfo = saveInfo;
            this.CardId = cardId;
        }

        /// <summary>
        /// Gets or sets CreditCardNumber.
        /// </summary>
        [JsonProperty("CreditCardNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string CreditCardNumber { get; set; }

        /// <summary>
        /// Gets or sets ExpMonth.
        /// </summary>
        [JsonProperty("ExpMonth", NullValueHandling = NullValueHandling.Ignore)]
        public string ExpMonth { get; set; }

        /// <summary>
        /// Gets or sets ExpYear.
        /// </summary>
        [JsonProperty("ExpYear", NullValueHandling = NullValueHandling.Ignore)]
        public string ExpYear { get; set; }

        /// <summary>
        /// Gets or sets BillingName.
        /// </summary>
        [JsonProperty("BillingName", NullValueHandling = NullValueHandling.Ignore)]
        public string BillingName { get; set; }

        /// <summary>
        /// Gets or sets BillingAddress.
        /// </summary>
        [JsonProperty("BillingAddress", NullValueHandling = NullValueHandling.Ignore)]
        public string BillingAddress { get; set; }

        /// <summary>
        /// Gets or sets BillingCity.
        /// </summary>
        [JsonProperty("BillingCity", NullValueHandling = NullValueHandling.Ignore)]
        public string BillingCity { get; set; }

        /// <summary>
        /// Gets or sets BillingState.
        /// </summary>
        [JsonProperty("BillingState", NullValueHandling = NullValueHandling.Ignore)]
        public string BillingState { get; set; }

        /// <summary>
        /// Gets or sets BillingPostalCode.
        /// </summary>
        [JsonProperty("BillingPostalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string BillingPostalCode { get; set; }

        /// <summary>
        /// Gets or sets SaveInfo.
        /// </summary>
        [JsonProperty("SaveInfo", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SaveInfo { get; set; }

        /// <summary>
        /// Card Id of a stored instruments card
        /// </summary>
        [JsonProperty("CardId", NullValueHandling = NullValueHandling.Ignore)]
        public string CardId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CreditCardInfo : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is CreditCardInfo other &&                ((this.CreditCardNumber == null && other.CreditCardNumber == null) || (this.CreditCardNumber?.Equals(other.CreditCardNumber) == true)) &&
                ((this.ExpMonth == null && other.ExpMonth == null) || (this.ExpMonth?.Equals(other.ExpMonth) == true)) &&
                ((this.ExpYear == null && other.ExpYear == null) || (this.ExpYear?.Equals(other.ExpYear) == true)) &&
                ((this.BillingName == null && other.BillingName == null) || (this.BillingName?.Equals(other.BillingName) == true)) &&
                ((this.BillingAddress == null && other.BillingAddress == null) || (this.BillingAddress?.Equals(other.BillingAddress) == true)) &&
                ((this.BillingCity == null && other.BillingCity == null) || (this.BillingCity?.Equals(other.BillingCity) == true)) &&
                ((this.BillingState == null && other.BillingState == null) || (this.BillingState?.Equals(other.BillingState) == true)) &&
                ((this.BillingPostalCode == null && other.BillingPostalCode == null) || (this.BillingPostalCode?.Equals(other.BillingPostalCode) == true)) &&
                ((this.SaveInfo == null && other.SaveInfo == null) || (this.SaveInfo?.Equals(other.SaveInfo) == true)) &&
                ((this.CardId == null && other.CardId == null) || (this.CardId?.Equals(other.CardId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CreditCardNumber = {(this.CreditCardNumber == null ? "null" : this.CreditCardNumber == string.Empty ? "" : this.CreditCardNumber)}");
            toStringOutput.Add($"this.ExpMonth = {(this.ExpMonth == null ? "null" : this.ExpMonth == string.Empty ? "" : this.ExpMonth)}");
            toStringOutput.Add($"this.ExpYear = {(this.ExpYear == null ? "null" : this.ExpYear == string.Empty ? "" : this.ExpYear)}");
            toStringOutput.Add($"this.BillingName = {(this.BillingName == null ? "null" : this.BillingName == string.Empty ? "" : this.BillingName)}");
            toStringOutput.Add($"this.BillingAddress = {(this.BillingAddress == null ? "null" : this.BillingAddress == string.Empty ? "" : this.BillingAddress)}");
            toStringOutput.Add($"this.BillingCity = {(this.BillingCity == null ? "null" : this.BillingCity == string.Empty ? "" : this.BillingCity)}");
            toStringOutput.Add($"this.BillingState = {(this.BillingState == null ? "null" : this.BillingState == string.Empty ? "" : this.BillingState)}");
            toStringOutput.Add($"this.BillingPostalCode = {(this.BillingPostalCode == null ? "null" : this.BillingPostalCode == string.Empty ? "" : this.BillingPostalCode)}");
            toStringOutput.Add($"this.SaveInfo = {(this.SaveInfo == null ? "null" : this.SaveInfo.ToString())}");
            toStringOutput.Add($"this.CardId = {(this.CardId == null ? "null" : this.CardId == string.Empty ? "" : this.CardId)}");
        }
    }
}