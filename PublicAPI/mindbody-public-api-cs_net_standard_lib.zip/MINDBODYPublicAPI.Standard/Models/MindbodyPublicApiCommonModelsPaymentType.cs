// <copyright file="MindbodyPublicApiCommonModelsPaymentType.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiCommonModelsPaymentType.
    /// </summary>
    public class MindbodyPublicApiCommonModelsPaymentType
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsPaymentType"/> class.
        /// </summary>
        public MindbodyPublicApiCommonModelsPaymentType()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsPaymentType"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="paymentTypeName">PaymentTypeName.</param>
        /// <param name="active">Active.</param>
        /// <param name="fee">Fee.</param>
        public MindbodyPublicApiCommonModelsPaymentType(
            int? id = null,
            string paymentTypeName = null,
            bool? active = null,
            double? fee = null)
        {
            this.Id = id;
            this.PaymentTypeName = paymentTypeName;
            this.Active = active;
            this.Fee = fee;
        }

        /// <summary>
        /// The Payment Type Id used for api calls.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Payment Type Name
        /// </summary>
        [JsonProperty("PaymentTypeName", NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentTypeName { get; set; }

        /// <summary>
        /// Check if Payment type is active.
        /// </summary>
        [JsonProperty("Active", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Active { get; set; }

        /// <summary>
        /// Payment type fee.
        /// </summary>
        [JsonProperty("Fee", NullValueHandling = NullValueHandling.Ignore)]
        public double? Fee { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiCommonModelsPaymentType : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiCommonModelsPaymentType other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.PaymentTypeName == null && other.PaymentTypeName == null) || (this.PaymentTypeName?.Equals(other.PaymentTypeName) == true)) &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true)) &&
                ((this.Fee == null && other.Fee == null) || (this.Fee?.Equals(other.Fee) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.PaymentTypeName = {(this.PaymentTypeName == null ? "null" : this.PaymentTypeName == string.Empty ? "" : this.PaymentTypeName)}");
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active.ToString())}");
            toStringOutput.Add($"this.Fee = {(this.Fee == null ? "null" : this.Fee.ToString())}");
        }
    }
}