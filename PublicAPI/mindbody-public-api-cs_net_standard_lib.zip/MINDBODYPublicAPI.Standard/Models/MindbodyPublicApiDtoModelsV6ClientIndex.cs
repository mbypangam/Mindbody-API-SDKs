// <copyright file="MindbodyPublicApiDtoModelsV6ClientIndex.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientIndex.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientIndex
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientIndex"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientIndex()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientIndex"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="name">Name.</param>
        /// <param name="requiredBusinessMode">RequiredBusinessMode.</param>
        /// <param name="requiredConsumerMode">RequiredConsumerMode.</param>
        /// <param name="values">Values.</param>
        /// <param name="action">Action.</param>
        public MindbodyPublicApiDtoModelsV6ClientIndex(
            int? id = null,
            string name = null,
            bool? requiredBusinessMode = null,
            bool? requiredConsumerMode = null,
            List<Models.MindbodyPublicApiDtoModelsV6ClientIndexValue> values = null,
            Models.Action7Enum? action = null)
        {
            this.Id = id;
            this.Name = name;
            this.RequiredBusinessMode = requiredBusinessMode;
            this.RequiredConsumerMode = requiredConsumerMode;
            this.Values = values;
            this.Action = action;
        }

        /// <summary>
        /// The unique ID of the client index.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// The name of the client index.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// When `true`, indicates that the index is required when creating profiles in business mode.
        /// </summary>
        [JsonProperty("RequiredBusinessMode", NullValueHandling = NullValueHandling.Ignore)]
        public bool? RequiredBusinessMode { get; set; }

        /// <summary>
        /// When `true`, indicates that the index is required when creating profiles in consumer mode.
        /// </summary>
        [JsonProperty("RequiredConsumerMode", NullValueHandling = NullValueHandling.Ignore)]
        public bool? RequiredConsumerMode { get; set; }

        /// <summary>
        /// Contains information about the index's possible values.
        /// </summary>
        [JsonProperty("Values", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6ClientIndexValue> Values { get; set; }

        /// <summary>
        /// The action performed on this object.
        /// </summary>
        [JsonProperty("Action", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.Action7Enum? Action { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientIndex : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientIndex other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.RequiredBusinessMode == null && other.RequiredBusinessMode == null) || (this.RequiredBusinessMode?.Equals(other.RequiredBusinessMode) == true)) &&
                ((this.RequiredConsumerMode == null && other.RequiredConsumerMode == null) || (this.RequiredConsumerMode?.Equals(other.RequiredConsumerMode) == true)) &&
                ((this.Values == null && other.Values == null) || (this.Values?.Equals(other.Values) == true)) &&
                ((this.Action == null && other.Action == null) || (this.Action?.Equals(other.Action) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.RequiredBusinessMode = {(this.RequiredBusinessMode == null ? "null" : this.RequiredBusinessMode.ToString())}");
            toStringOutput.Add($"this.RequiredConsumerMode = {(this.RequiredConsumerMode == null ? "null" : this.RequiredConsumerMode.ToString())}");
            toStringOutput.Add($"this.Values = {(this.Values == null ? "null" : $"[{string.Join(", ", this.Values)} ]")}");
            toStringOutput.Add($"this.Action = {(this.Action == null ? "null" : this.Action.ToString())}");
        }
    }
}