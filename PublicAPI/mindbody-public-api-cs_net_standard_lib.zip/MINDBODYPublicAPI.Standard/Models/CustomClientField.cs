// <copyright file="CustomClientField.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// CustomClientField.
    /// </summary>
    public class CustomClientField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomClientField"/> class.
        /// </summary>
        public CustomClientField()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomClientField"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="dataType">DataType.</param>
        /// <param name="name">Name.</param>
        public CustomClientField(
            int? id = null,
            string dataType = null,
            string name = null)
        {
            this.Id = id;
            this.DataType = dataType;
            this.Name = name;
        }

        /// <summary>
        /// The ID of the custom client field.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// The data type of the field.
        /// </summary>
        [JsonProperty("DataType", NullValueHandling = NullValueHandling.Ignore)]
        public string DataType { get; set; }

        /// <summary>
        /// The name of the field.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CustomClientField : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is CustomClientField other &&                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.DataType == null && other.DataType == null) || (this.DataType?.Equals(other.DataType) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.DataType = {(this.DataType == null ? "null" : this.DataType)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name)}");
        }
    }
}