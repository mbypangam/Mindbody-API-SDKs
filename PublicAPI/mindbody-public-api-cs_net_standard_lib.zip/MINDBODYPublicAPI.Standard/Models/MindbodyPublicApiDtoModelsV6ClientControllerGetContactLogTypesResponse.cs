// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="contactLogTypes">ContactLogTypes.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse(
            Models.MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse = null,
            List<Models.MindbodyPublicApiDtoModelsV6ContactLogType> contactLogTypes = null)
        {
            this.PaginationResponse = paginationResponse;
            this.ContactLogTypes = contactLogTypes;
        }

        /// <summary>
        /// Contains information about the pagination to use.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// The requested Active ContactLogTypes
        /// </summary>
        [JsonProperty("ContactLogTypes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6ContactLogType> ContactLogTypes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerGetContactLogTypesResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.ContactLogTypes == null && other.ContactLogTypes == null) || (this.ContactLogTypes?.Equals(other.ContactLogTypes) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.ContactLogTypes = {(this.ContactLogTypes == null ? "null" : $"[{string.Join(", ", this.ContactLogTypes)} ]")}");
        }
    }
}