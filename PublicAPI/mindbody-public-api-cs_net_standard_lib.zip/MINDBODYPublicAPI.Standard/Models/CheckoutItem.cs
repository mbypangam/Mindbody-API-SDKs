// <copyright file="CheckoutItem.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// CheckoutItem.
    /// </summary>
    public class CheckoutItem
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutItem"/> class.
        /// </summary>
        public CheckoutItem()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutItem"/> class.
        /// </summary>
        /// <param name="type">Type.</param>
        /// <param name="metadata">Metadata.</param>
        public CheckoutItem(
            string type = null,
            object metadata = null)
        {
            this.Type = type;
            this.Metadata = metadata;
        }

        /// <summary>
        /// The type of item. Possible values are:
        /// * Service - Indicates that this item is a pricing option.
        /// * Product - Indicates that this item is a retail product.
        /// * Package - Indicates that this item is a package.
        /// * Tip - Indicates that this item is a tip.
        /// </summary>
        [JsonProperty("Type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        /// <summary>
        /// Contains information about the item to be purchased. See [Cart Item Metadata](https://developers.mindbodyonline.com/PublicDocumentation/V6#cart-item-metadata) for more information.
        /// </summary>
        [JsonProperty("Metadata", NullValueHandling = NullValueHandling.Ignore)]
        public object Metadata { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CheckoutItem : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is CheckoutItem other &&                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.Metadata == null && other.Metadata == null) || (this.Metadata?.Equals(other.Metadata) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type)}");
            toStringOutput.Add($"Metadata = {(this.Metadata == null ? "null" : this.Metadata.ToString())}");
        }
    }
}