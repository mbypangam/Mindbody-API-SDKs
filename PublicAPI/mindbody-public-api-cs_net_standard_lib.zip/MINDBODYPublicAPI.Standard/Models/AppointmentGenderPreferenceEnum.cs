// <copyright file="AppointmentGenderPreferenceEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// AppointmentGenderPreferenceEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum AppointmentGenderPreferenceEnum
    {
        /// <summary>
        /// None.
        /// </summary>
        [EnumMember(Value = "None")]
        None,

        /// <summary>
        /// Female.
        /// </summary>
        [EnumMember(Value = "Female")]
        Female,

        /// <summary>
        /// Male.
        /// </summary>
        [EnumMember(Value = "Male")]
        Male
    }
}