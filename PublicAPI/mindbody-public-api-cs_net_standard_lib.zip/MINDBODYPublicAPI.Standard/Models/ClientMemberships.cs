// <copyright file="ClientMemberships.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ClientMemberships.
    /// </summary>
    public class ClientMemberships
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClientMemberships"/> class.
        /// </summary>
        public ClientMemberships()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ClientMemberships"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="memberships">Memberships.</param>
        /// <param name="errorMessage">ErrorMessage.</param>
        public ClientMemberships(
            string clientId = null,
            List<Models.ClientMembership> memberships = null,
            string errorMessage = null)
        {
            this.ClientId = clientId;
            this.Memberships = memberships;
            this.ErrorMessage = errorMessage;
        }

        /// <summary>
        /// ID of the client.
        /// </summary>
        [JsonProperty("ClientId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientId { get; set; }

        /// <summary>
        /// Contains information about the Client Memberships details.
        /// </summary>
        [JsonProperty("Memberships", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ClientMembership> Memberships { get; set; }

        /// <summary>
        /// Gets or sets ErrorMessage.
        /// </summary>
        [JsonProperty("ErrorMessage", NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorMessage { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ClientMemberships : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is ClientMemberships other &&                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.Memberships == null && other.Memberships == null) || (this.Memberships?.Equals(other.Memberships) == true)) &&
                ((this.ErrorMessage == null && other.ErrorMessage == null) || (this.ErrorMessage?.Equals(other.ErrorMessage) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.Memberships = {(this.Memberships == null ? "null" : $"[{string.Join(", ", this.Memberships)} ]")}");
            toStringOutput.Add($"this.ErrorMessage = {(this.ErrorMessage == null ? "null" : this.ErrorMessage == string.Empty ? "" : this.ErrorMessage)}");
        }
    }
}