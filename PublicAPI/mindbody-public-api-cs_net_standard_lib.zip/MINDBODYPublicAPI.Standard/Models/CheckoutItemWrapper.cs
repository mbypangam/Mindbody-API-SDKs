// <copyright file="CheckoutItemWrapper.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CheckoutItemWrapper.
    /// </summary>
    public class CheckoutItemWrapper
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutItemWrapper"/> class.
        /// </summary>
        public CheckoutItemWrapper()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutItemWrapper"/> class.
        /// </summary>
        /// <param name="item">Item.</param>
        /// <param name="discountAmount">DiscountAmount.</param>
        /// <param name="appointmentBookingRequests">AppointmentBookingRequests.</param>
        /// <param name="enrollmentIds">EnrollmentIds.</param>
        /// <param name="classIds">ClassIds.</param>
        /// <param name="courseIds">CourseIds.</param>
        /// <param name="visitIds">VisitIds.</param>
        /// <param name="appointmentIds">AppointmentIds.</param>
        /// <param name="id">Id.</param>
        /// <param name="quantity">Quantity.</param>
        public CheckoutItemWrapper(
            Models.CheckoutItem item = null,
            double? discountAmount = null,
            List<Models.CheckoutAppointmentBookingRequest> appointmentBookingRequests = null,
            List<int> enrollmentIds = null,
            List<int> classIds = null,
            List<long> courseIds = null,
            List<long> visitIds = null,
            List<long> appointmentIds = null,
            int? id = null,
            int? quantity = null)
        {
            this.Item = item;
            this.DiscountAmount = discountAmount;
            this.AppointmentBookingRequests = appointmentBookingRequests;
            this.EnrollmentIds = enrollmentIds;
            this.ClassIds = classIds;
            this.CourseIds = courseIds;
            this.VisitIds = visitIds;
            this.AppointmentIds = appointmentIds;
            this.Id = id;
            this.Quantity = quantity;
        }

        /// <summary>
        /// Information about an item in the cart.
        /// </summary>
        [JsonProperty("Item", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CheckoutItem Item { get; set; }

        /// <summary>
        /// The amount the item is discounted. This parameter is ignored for packages.
        /// </summary>
        [JsonProperty("DiscountAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? DiscountAmount { get; set; }

        /// <summary>
        /// A list of appointments to be booked then paid for by this item. This parameter applies only to pricing option items.
        /// </summary>
        [JsonProperty("AppointmentBookingRequests", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.CheckoutAppointmentBookingRequest> AppointmentBookingRequests { get; set; }

        /// <summary>
        /// A list of enrollment IDs that this item is to pay for. This parameter applies only to pricing option items.
        /// </summary>
        [JsonProperty("EnrollmentIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> EnrollmentIds { get; set; }

        /// <summary>
        /// A list of class IDs that this item is to pay for. This parameter applies only to pricing option items.
        /// </summary>
        [JsonProperty("ClassIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ClassIds { get; set; }

        /// <summary>
        /// A list of course IDs that this item is to pay for. This parameter applies only to pricing option items.
        /// </summary>
        [JsonProperty("CourseIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<long> CourseIds { get; set; }

        /// <summary>
        /// A list of visit IDs that this item is to pay for. This parameter applies only to pricing option items.
        /// </summary>
        [JsonProperty("VisitIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<long> VisitIds { get; set; }

        /// <summary>
        /// A list of appointment IDs that this item is to reconcile.
        /// </summary>
        [JsonProperty("AppointmentIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<long> AppointmentIds { get; set; }

        /// <summary>
        /// The item’s unique ID within the cart.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// The number of this item to be purchased.
        /// </summary>
        [JsonProperty("Quantity", NullValueHandling = NullValueHandling.Ignore)]
        public int? Quantity { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CheckoutItemWrapper : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CheckoutItemWrapper other &&
                ((this.Item == null && other.Item == null) || (this.Item?.Equals(other.Item) == true)) &&
                ((this.DiscountAmount == null && other.DiscountAmount == null) || (this.DiscountAmount?.Equals(other.DiscountAmount) == true)) &&
                ((this.AppointmentBookingRequests == null && other.AppointmentBookingRequests == null) || (this.AppointmentBookingRequests?.Equals(other.AppointmentBookingRequests) == true)) &&
                ((this.EnrollmentIds == null && other.EnrollmentIds == null) || (this.EnrollmentIds?.Equals(other.EnrollmentIds) == true)) &&
                ((this.ClassIds == null && other.ClassIds == null) || (this.ClassIds?.Equals(other.ClassIds) == true)) &&
                ((this.CourseIds == null && other.CourseIds == null) || (this.CourseIds?.Equals(other.CourseIds) == true)) &&
                ((this.VisitIds == null && other.VisitIds == null) || (this.VisitIds?.Equals(other.VisitIds) == true)) &&
                ((this.AppointmentIds == null && other.AppointmentIds == null) || (this.AppointmentIds?.Equals(other.AppointmentIds) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Quantity == null && other.Quantity == null) || (this.Quantity?.Equals(other.Quantity) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Item = {(this.Item == null ? "null" : this.Item.ToString())}");
            toStringOutput.Add($"this.DiscountAmount = {(this.DiscountAmount == null ? "null" : this.DiscountAmount.ToString())}");
            toStringOutput.Add($"this.AppointmentBookingRequests = {(this.AppointmentBookingRequests == null ? "null" : $"[{string.Join(", ", this.AppointmentBookingRequests)} ]")}");
            toStringOutput.Add($"this.EnrollmentIds = {(this.EnrollmentIds == null ? "null" : $"[{string.Join(", ", this.EnrollmentIds)} ]")}");
            toStringOutput.Add($"this.ClassIds = {(this.ClassIds == null ? "null" : $"[{string.Join(", ", this.ClassIds)} ]")}");
            toStringOutput.Add($"this.CourseIds = {(this.CourseIds == null ? "null" : $"[{string.Join(", ", this.CourseIds)} ]")}");
            toStringOutput.Add($"this.VisitIds = {(this.VisitIds == null ? "null" : $"[{string.Join(", ", this.VisitIds)} ]")}");
            toStringOutput.Add($"this.AppointmentIds = {(this.AppointmentIds == null ? "null" : $"[{string.Join(", ", this.AppointmentIds)} ]")}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Quantity = {(this.Quantity == null ? "null" : this.Quantity.ToString())}");
        }
    }
}