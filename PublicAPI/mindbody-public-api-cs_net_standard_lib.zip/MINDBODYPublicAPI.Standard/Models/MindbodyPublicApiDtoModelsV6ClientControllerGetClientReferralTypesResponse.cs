// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse"/> class.
        /// </summary>
        /// <param name="referralTypes">ReferralTypes.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse(
            List<string> referralTypes = null)
        {
            this.ReferralTypes = referralTypes;
        }

        /// <summary>
        /// The list of available referral types.
        /// </summary>
        [JsonProperty("ReferralTypes", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> ReferralTypes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerGetClientReferralTypesResponse other &&
                ((this.ReferralTypes == null && other.ReferralTypes == null) || (this.ReferralTypes?.Equals(other.ReferralTypes) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ReferralTypes = {(this.ReferralTypes == null ? "null" : $"[{string.Join(", ", this.ReferralTypes)} ]")}");
        }
    }
}