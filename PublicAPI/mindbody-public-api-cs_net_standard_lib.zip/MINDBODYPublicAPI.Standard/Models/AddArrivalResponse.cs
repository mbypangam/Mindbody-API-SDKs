// <copyright file="AddArrivalResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// AddArrivalResponse.
    /// </summary>
    public class AddArrivalResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddArrivalResponse"/> class.
        /// </summary>
        public AddArrivalResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddArrivalResponse"/> class.
        /// </summary>
        /// <param name="arrivalAdded">ArrivalAdded.</param>
        /// <param name="clientService">ClientService.</param>
        public AddArrivalResponse(
            bool? arrivalAdded = null,
            Models.ClientService clientService = null)
        {
            this.ArrivalAdded = arrivalAdded;
            this.ClientService = clientService;
        }

        /// <summary>
        /// When `true`, indicates that the arrival was added to the database.
        /// </summary>
        [JsonProperty("ArrivalAdded", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ArrivalAdded { get; set; }

        /// <summary>
        /// A service that is on a client's account.
        /// </summary>
        [JsonProperty("ClientService", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ClientService ClientService { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddArrivalResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddArrivalResponse other &&                ((this.ArrivalAdded == null && other.ArrivalAdded == null) || (this.ArrivalAdded?.Equals(other.ArrivalAdded) == true)) &&
                ((this.ClientService == null && other.ClientService == null) || (this.ClientService?.Equals(other.ClientService) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ArrivalAdded = {(this.ArrivalAdded == null ? "null" : this.ArrivalAdded.ToString())}");
            toStringOutput.Add($"this.ClientService = {(this.ClientService == null ? "null" : this.ClientService.ToString())}");
        }
    }
}