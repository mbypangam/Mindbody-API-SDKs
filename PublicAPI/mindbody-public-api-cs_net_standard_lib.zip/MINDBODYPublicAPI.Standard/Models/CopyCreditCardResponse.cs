// <copyright file="CopyCreditCardResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// CopyCreditCardResponse.
    /// </summary>
    public class CopyCreditCardResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CopyCreditCardResponse"/> class.
        /// </summary>
        public CopyCreditCardResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CopyCreditCardResponse"/> class.
        /// </summary>
        /// <param name="copiedFrom">CopiedFrom.</param>
        /// <param name="copiedTo">CopiedTo.</param>
        public CopyCreditCardResponse(
            Models.CopyCreditCardResponseClient copiedFrom = null,
            Models.CopyCreditCardResponseClient copiedTo = null)
        {
            this.CopiedFrom = copiedFrom;
            this.CopiedTo = copiedTo;
        }

        /// <summary>
        /// Gets or sets CopiedFrom.
        /// </summary>
        [JsonProperty("CopiedFrom", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CopyCreditCardResponseClient CopiedFrom { get; set; }

        /// <summary>
        /// Gets or sets CopiedTo.
        /// </summary>
        [JsonProperty("CopiedTo", NullValueHandling = NullValueHandling.Ignore)]
        public Models.CopyCreditCardResponseClient CopiedTo { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CopyCreditCardResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is CopyCreditCardResponse other &&                ((this.CopiedFrom == null && other.CopiedFrom == null) || (this.CopiedFrom?.Equals(other.CopiedFrom) == true)) &&
                ((this.CopiedTo == null && other.CopiedTo == null) || (this.CopiedTo?.Equals(other.CopiedTo) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CopiedFrom = {(this.CopiedFrom == null ? "null" : this.CopiedFrom.ToString())}");
            toStringOutput.Add($"this.CopiedTo = {(this.CopiedTo == null ? "null" : this.CopiedTo.ToString())}");
        }
    }
}