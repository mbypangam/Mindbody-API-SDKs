// <copyright file="GetClientVisitsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetClientVisitsResponse.
    /// </summary>
    public class GetClientVisitsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetClientVisitsResponse"/> class.
        /// </summary>
        public GetClientVisitsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetClientVisitsResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="visits">Visits.</param>
        public GetClientVisitsResponse(
            Models.PaginationResponse paginationResponse = null,
            List<Models.Visit> visits = null)
        {
            this.PaginationResponse = paginationResponse;
            this.Visits = visits;
        }

        /// <summary>
        /// Contains information about the pagination to use.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// Contains information about client visits.
        /// </summary>
        [JsonProperty("Visits", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Visit> Visits { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetClientVisitsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is GetClientVisitsResponse other &&                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.Visits == null && other.Visits == null) || (this.Visits?.Equals(other.Visits) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.Visits = {(this.Visits == null ? "null" : $"[{string.Join(", ", this.Visits)} ]")}");
        }
    }
}