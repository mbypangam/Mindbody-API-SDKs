// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="clientContractId">ClientContractId.</param>
        /// <param name="suspensionType">SuspensionType.</param>
        /// <param name="suspensionStart">SuspensionStart.</param>
        /// <param name="duration">Duration.</param>
        /// <param name="durationUnit">DurationUnit.</param>
        /// <param name="openEnded">OpenEnded.</param>
        /// <param name="suspensionNotes">SuspensionNotes.</param>
        /// <param name="suspensionFee">SuspensionFee.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest(
            string clientId,
            int clientContractId,
            string suspensionType = null,
            DateTime? suspensionStart = null,
            int? duration = null,
            int? durationUnit = null,
            bool? openEnded = null,
            string suspensionNotes = null,
            double? suspensionFee = null)
        {
            this.ClientId = clientId;
            this.ClientContractId = clientContractId;
            this.SuspensionType = suspensionType;
            this.SuspensionStart = suspensionStart;
            this.Duration = duration;
            this.DurationUnit = durationUnit;
            this.OpenEnded = openEnded;
            this.SuspensionNotes = suspensionNotes;
            this.SuspensionFee = suspensionFee;
        }

        /// <summary>
        /// The ID of the client.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// The unique ID of the sale of the contract.
        /// </summary>
        [JsonProperty("ClientContractId")]
        public int ClientContractId { get; set; }

        /// <summary>
        /// ex. Illness, Injury, Vacation. (Note this can be customized by each studio).
        /// If provided, then Duration, DurationUnit, and SuspensionFee (if applicable) are automatically applied. Restrict Days are not supported.
        /// </summary>
        [JsonProperty("SuspensionType", NullValueHandling = NullValueHandling.Ignore)]
        public string SuspensionType { get; set; }

        /// <summary>
        /// The contract suspension start date.
        /// Default: *today?s date*
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("SuspensionStart", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? SuspensionStart { get; set; }

        /// <summary>
        /// The number of (DurationUnit) the suspension lasts.
        /// </summary>
        [JsonProperty("Duration", NullValueHandling = NullValueHandling.Ignore)]
        public int? Duration { get; set; }

        /// <summary>
        /// The unit applied to Duration.
        /// </summary>
        [JsonProperty("DurationUnit", NullValueHandling = NullValueHandling.Ignore)]
        public int? DurationUnit { get; set; }

        /// <summary>
        /// When `true`, indicates that suspension is open ended. Also, when `true`, then Duration and DurationUnit are ignored.
        /// Default: *false*
        /// </summary>
        [JsonProperty("OpenEnded", NullValueHandling = NullValueHandling.Ignore)]
        public bool? OpenEnded { get; set; }

        /// <summary>
        /// The comments for suspending a contract.
        /// </summary>
        [JsonProperty("SuspensionNotes", NullValueHandling = NullValueHandling.Ignore)]
        public string SuspensionNotes { get; set; }

        /// <summary>
        /// An optional charge that clients who wish to pause a contract for a set period of time can be charged.
        /// </summary>
        [JsonProperty("SuspensionFee", NullValueHandling = NullValueHandling.Ignore)]
        public double? SuspensionFee { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest other &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                this.ClientContractId.Equals(other.ClientContractId) &&
                ((this.SuspensionType == null && other.SuspensionType == null) || (this.SuspensionType?.Equals(other.SuspensionType) == true)) &&
                ((this.SuspensionStart == null && other.SuspensionStart == null) || (this.SuspensionStart?.Equals(other.SuspensionStart) == true)) &&
                ((this.Duration == null && other.Duration == null) || (this.Duration?.Equals(other.Duration) == true)) &&
                ((this.DurationUnit == null && other.DurationUnit == null) || (this.DurationUnit?.Equals(other.DurationUnit) == true)) &&
                ((this.OpenEnded == null && other.OpenEnded == null) || (this.OpenEnded?.Equals(other.OpenEnded) == true)) &&
                ((this.SuspensionNotes == null && other.SuspensionNotes == null) || (this.SuspensionNotes?.Equals(other.SuspensionNotes) == true)) &&
                ((this.SuspensionFee == null && other.SuspensionFee == null) || (this.SuspensionFee?.Equals(other.SuspensionFee) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.ClientContractId = {this.ClientContractId}");
            toStringOutput.Add($"this.SuspensionType = {(this.SuspensionType == null ? "null" : this.SuspensionType == string.Empty ? "" : this.SuspensionType)}");
            toStringOutput.Add($"this.SuspensionStart = {(this.SuspensionStart == null ? "null" : this.SuspensionStart.ToString())}");
            toStringOutput.Add($"this.Duration = {(this.Duration == null ? "null" : this.Duration.ToString())}");
            toStringOutput.Add($"this.DurationUnit = {(this.DurationUnit == null ? "null" : this.DurationUnit.ToString())}");
            toStringOutput.Add($"this.OpenEnded = {(this.OpenEnded == null ? "null" : this.OpenEnded.ToString())}");
            toStringOutput.Add($"this.SuspensionNotes = {(this.SuspensionNotes == null ? "null" : this.SuspensionNotes == string.Empty ? "" : this.SuspensionNotes)}");
            toStringOutput.Add($"this.SuspensionFee = {(this.SuspensionFee == null ? "null" : this.SuspensionFee.ToString())}");
        }
    }
}