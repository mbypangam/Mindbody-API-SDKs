// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="test">Test.</param>
        /// <param name="assignedToStaffId">AssignedToStaffId.</param>
        /// <param name="text">Text.</param>
        /// <param name="contactName">ContactName.</param>
        /// <param name="followupByDate">FollowupByDate.</param>
        /// <param name="contactMethod">ContactMethod.</param>
        /// <param name="isComplete">IsComplete.</param>
        /// <param name="comments">Comments.</param>
        /// <param name="types">Types.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest(
            int? id = null,
            bool? test = null,
            long? assignedToStaffId = null,
            string text = null,
            string contactName = null,
            DateTime? followupByDate = null,
            string contactMethod = null,
            bool? isComplete = null,
            List<Models.MindbodyPublicApiDtoModelsV6UpdateContactLogComment> comments = null,
            List<Models.MindbodyPublicApiDtoModelsV6UpdateContactLogType> types = null)
        {
            this.Id = id;
            this.Test = test;
            this.AssignedToStaffId = assignedToStaffId;
            this.Text = text;
            this.ContactName = contactName;
            this.FollowupByDate = followupByDate;
            this.ContactMethod = contactMethod;
            this.IsComplete = isComplete;
            this.Comments = comments;
            this.Types = types;
        }

        /// <summary>
        /// The ID of the contact log being updated.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// When `true`, indicates that this is a test request and no data is inserted into the subscriber?s database.<br />
        /// When `false`, the database is updated.
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <summary>
        /// The ID of the staff member to whom the contact log is now being assigned.
        /// </summary>
        [JsonProperty("AssignedToStaffId", NullValueHandling = NullValueHandling.Ignore)]
        public long? AssignedToStaffId { get; set; }

        /// <summary>
        /// The contact log?s new text.
        /// </summary>
        [JsonProperty("Text", NullValueHandling = NullValueHandling.Ignore)]
        public string Text { get; set; }

        /// <summary>
        /// The name of the new person to be contacted by the assigned staff member.
        /// </summary>
        [JsonProperty("ContactName", NullValueHandling = NullValueHandling.Ignore)]
        public string ContactName { get; set; }

        /// <summary>
        /// The new date by which the assigned staff member should complete this contact log.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("FollowupByDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? FollowupByDate { get; set; }

        /// <summary>
        /// The new method by which the client wants to be contacted.
        /// </summary>
        [JsonProperty("ContactMethod", NullValueHandling = NullValueHandling.Ignore)]
        public string ContactMethod { get; set; }

        /// <summary>
        /// When `true`, indicates that the contact log is complete.
        /// When `false`, indicates the contact log isn?t complete.
        /// </summary>
        [JsonProperty("IsComplete", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsComplete { get; set; }

        /// <summary>
        /// Contains information about the comments being updated or added to the contact log. Comments that have an ID of `0` are added to the contact log.
        /// </summary>
        [JsonProperty("Comments", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6UpdateContactLogComment> Comments { get; set; }

        /// <summary>
        /// Contains information about the contact logs types being assigned to the contact log, in addition to the contact log types that are already assigned.
        /// </summary>
        [JsonProperty("Types", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6UpdateContactLogType> Types { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerUpdateContactLogRequest other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true)) &&
                ((this.AssignedToStaffId == null && other.AssignedToStaffId == null) || (this.AssignedToStaffId?.Equals(other.AssignedToStaffId) == true)) &&
                ((this.Text == null && other.Text == null) || (this.Text?.Equals(other.Text) == true)) &&
                ((this.ContactName == null && other.ContactName == null) || (this.ContactName?.Equals(other.ContactName) == true)) &&
                ((this.FollowupByDate == null && other.FollowupByDate == null) || (this.FollowupByDate?.Equals(other.FollowupByDate) == true)) &&
                ((this.ContactMethod == null && other.ContactMethod == null) || (this.ContactMethod?.Equals(other.ContactMethod) == true)) &&
                ((this.IsComplete == null && other.IsComplete == null) || (this.IsComplete?.Equals(other.IsComplete) == true)) &&
                ((this.Comments == null && other.Comments == null) || (this.Comments?.Equals(other.Comments) == true)) &&
                ((this.Types == null && other.Types == null) || (this.Types?.Equals(other.Types) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
            toStringOutput.Add($"this.AssignedToStaffId = {(this.AssignedToStaffId == null ? "null" : this.AssignedToStaffId.ToString())}");
            toStringOutput.Add($"this.Text = {(this.Text == null ? "null" : this.Text == string.Empty ? "" : this.Text)}");
            toStringOutput.Add($"this.ContactName = {(this.ContactName == null ? "null" : this.ContactName == string.Empty ? "" : this.ContactName)}");
            toStringOutput.Add($"this.FollowupByDate = {(this.FollowupByDate == null ? "null" : this.FollowupByDate.ToString())}");
            toStringOutput.Add($"this.ContactMethod = {(this.ContactMethod == null ? "null" : this.ContactMethod == string.Empty ? "" : this.ContactMethod)}");
            toStringOutput.Add($"this.IsComplete = {(this.IsComplete == null ? "null" : this.IsComplete.ToString())}");
            toStringOutput.Add($"this.Comments = {(this.Comments == null ? "null" : $"[{string.Join(", ", this.Comments)} ]")}");
            toStringOutput.Add($"this.Types = {(this.Types == null ? "null" : $"[{string.Join(", ", this.Types)} ]")}");
        }
    }
}