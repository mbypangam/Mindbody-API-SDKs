// <copyright file="GetClientReferralTypesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetClientReferralTypesResponse.
    /// </summary>
    public class GetClientReferralTypesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetClientReferralTypesResponse"/> class.
        /// </summary>
        public GetClientReferralTypesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetClientReferralTypesResponse"/> class.
        /// </summary>
        /// <param name="referralTypes">ReferralTypes.</param>
        public GetClientReferralTypesResponse(
            List<string> referralTypes = null)
        {
            this.ReferralTypes = referralTypes;
        }

        /// <summary>
        /// The list of available referral types.
        /// </summary>
        [JsonProperty("ReferralTypes", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> ReferralTypes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetClientReferralTypesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is GetClientReferralTypesResponse other &&                ((this.ReferralTypes == null && other.ReferralTypes == null) || (this.ReferralTypes?.Equals(other.ReferralTypes) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ReferralTypes = {(this.ReferralTypes == null ? "null" : $"[{string.Join(", ", this.ReferralTypes)} ]")}");
        }
    }
}