// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest"/> class.
        /// </summary>
        /// <param name="serviceId">ServiceId.</param>
        /// <param name="activeDate">ActiveDate.</param>
        /// <param name="expirationDate">ExpirationDate.</param>
        /// <param name="count">Count.</param>
        /// <param name="test">Test.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest(
            int serviceId,
            DateTime? activeDate = null,
            DateTime? expirationDate = null,
            int? count = null,
            bool? test = null)
        {
            this.ServiceId = serviceId;
            this.ActiveDate = activeDate;
            this.ExpirationDate = expirationDate;
            this.Count = count;
            this.Test = test;
        }

        /// <summary>
        /// The ID of the service to update.
        /// </summary>
        [JsonProperty("ServiceId")]
        public int ServiceId { get; set; }

        /// <summary>
        /// The date that the service became active.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("ActiveDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ActiveDate { get; set; }

        /// <summary>
        /// The date that the service is to expire.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("ExpirationDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ExpirationDate { get; set; }

        /// <summary>
        /// The number of client service sessions to update.
        /// </summary>
        [JsonProperty("Count", NullValueHandling = NullValueHandling.Ignore)]
        public int? Count { get; set; }

        /// <summary>
        /// When `true`, indicates that input information is to be validated, but not committed.<br />
        /// When `false` or omitted, the database is affected.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceRequest other &&
                this.ServiceId.Equals(other.ServiceId) &&
                ((this.ActiveDate == null && other.ActiveDate == null) || (this.ActiveDate?.Equals(other.ActiveDate) == true)) &&
                ((this.ExpirationDate == null && other.ExpirationDate == null) || (this.ExpirationDate?.Equals(other.ExpirationDate) == true)) &&
                ((this.Count == null && other.Count == null) || (this.Count?.Equals(other.Count) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ServiceId = {this.ServiceId}");
            toStringOutput.Add($"this.ActiveDate = {(this.ActiveDate == null ? "null" : this.ActiveDate.ToString())}");
            toStringOutput.Add($"this.ExpirationDate = {(this.ExpirationDate == null ? "null" : this.ExpirationDate.ToString())}");
            toStringOutput.Add($"this.Count = {(this.Count == null ? "null" : this.Count.ToString())}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
        }
    }
}