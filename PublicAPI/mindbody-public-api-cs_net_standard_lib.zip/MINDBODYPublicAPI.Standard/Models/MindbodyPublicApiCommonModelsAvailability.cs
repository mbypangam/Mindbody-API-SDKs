// <copyright file="MindbodyPublicApiCommonModelsAvailability.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiCommonModelsAvailability.
    /// </summary>
    public class MindbodyPublicApiCommonModelsAvailability
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsAvailability"/> class.
        /// </summary>
        public MindbodyPublicApiCommonModelsAvailability()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsAvailability"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="staff">Staff.</param>
        /// <param name="sessionType">SessionType.</param>
        /// <param name="programs">Programs.</param>
        /// <param name="startDateTime">StartDateTime.</param>
        /// <param name="endDateTime">EndDateTime.</param>
        /// <param name="bookableEndDateTime">BookableEndDateTime.</param>
        /// <param name="location">Location.</param>
        /// <param name="prepTime">PrepTime.</param>
        /// <param name="finishTime">FinishTime.</param>
        public MindbodyPublicApiCommonModelsAvailability(
            int? id = null,
            Models.MindbodyPublicApiCommonModelsStaff staff = null,
            Models.MindbodyPublicApiCommonModelsSessionType sessionType = null,
            List<Models.MindbodyPublicApiCommonModelsProgram> programs = null,
            DateTime? startDateTime = null,
            DateTime? endDateTime = null,
            DateTime? bookableEndDateTime = null,
            Models.MindbodyPublicApiCommonModelsLocation location = null,
            int? prepTime = null,
            int? finishTime = null)
        {
            this.Id = id;
            this.Staff = staff;
            this.SessionType = sessionType;
            this.Programs = programs;
            this.StartDateTime = startDateTime;
            this.EndDateTime = endDateTime;
            this.BookableEndDateTime = bookableEndDateTime;
            this.Location = location;
            this.PrepTime = prepTime;
            this.FinishTime = finishTime;
        }

        /// <summary>
        /// Id of the availability
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Gets or sets Staff.
        /// </summary>
        [JsonProperty("Staff", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiCommonModelsStaff Staff { get; set; }

        /// <summary>
        /// Gets or sets SessionType.
        /// </summary>
        [JsonProperty("SessionType", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiCommonModelsSessionType SessionType { get; set; }

        /// <summary>
        /// Availabilities program list.
        /// </summary>
        [JsonProperty("Programs", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiCommonModelsProgram> Programs { get; set; }

        /// <summary>
        /// Availabilities start date and time.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDateTime { get; set; }

        /// <summary>
        /// Availabilities end date and time.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDateTime { get; set; }

        /// <summary>
        /// Availabilities bookable end date and time.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("BookableEndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? BookableEndDateTime { get; set; }

        /// <summary>
        /// Gets or sets Location.
        /// </summary>
        [JsonProperty("Location", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiCommonModelsLocation Location { get; set; }

        /// <summary>
        /// Appointment prep time
        /// </summary>
        [JsonProperty("PrepTime", NullValueHandling = NullValueHandling.Ignore)]
        public int? PrepTime { get; set; }

        /// <summary>
        /// Appointment finish time
        /// </summary>
        [JsonProperty("FinishTime", NullValueHandling = NullValueHandling.Ignore)]
        public int? FinishTime { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiCommonModelsAvailability : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiCommonModelsAvailability other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Staff == null && other.Staff == null) || (this.Staff?.Equals(other.Staff) == true)) &&
                ((this.SessionType == null && other.SessionType == null) || (this.SessionType?.Equals(other.SessionType) == true)) &&
                ((this.Programs == null && other.Programs == null) || (this.Programs?.Equals(other.Programs) == true)) &&
                ((this.StartDateTime == null && other.StartDateTime == null) || (this.StartDateTime?.Equals(other.StartDateTime) == true)) &&
                ((this.EndDateTime == null && other.EndDateTime == null) || (this.EndDateTime?.Equals(other.EndDateTime) == true)) &&
                ((this.BookableEndDateTime == null && other.BookableEndDateTime == null) || (this.BookableEndDateTime?.Equals(other.BookableEndDateTime) == true)) &&
                ((this.Location == null && other.Location == null) || (this.Location?.Equals(other.Location) == true)) &&
                ((this.PrepTime == null && other.PrepTime == null) || (this.PrepTime?.Equals(other.PrepTime) == true)) &&
                ((this.FinishTime == null && other.FinishTime == null) || (this.FinishTime?.Equals(other.FinishTime) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Staff = {(this.Staff == null ? "null" : this.Staff.ToString())}");
            toStringOutput.Add($"this.SessionType = {(this.SessionType == null ? "null" : this.SessionType.ToString())}");
            toStringOutput.Add($"this.Programs = {(this.Programs == null ? "null" : $"[{string.Join(", ", this.Programs)} ]")}");
            toStringOutput.Add($"this.StartDateTime = {(this.StartDateTime == null ? "null" : this.StartDateTime.ToString())}");
            toStringOutput.Add($"this.EndDateTime = {(this.EndDateTime == null ? "null" : this.EndDateTime.ToString())}");
            toStringOutput.Add($"this.BookableEndDateTime = {(this.BookableEndDateTime == null ? "null" : this.BookableEndDateTime.ToString())}");
            toStringOutput.Add($"this.Location = {(this.Location == null ? "null" : this.Location.ToString())}");
            toStringOutput.Add($"this.PrepTime = {(this.PrepTime == null ? "null" : this.PrepTime.ToString())}");
            toStringOutput.Add($"this.FinishTime = {(this.FinishTime == null ? "null" : this.FinishTime.ToString())}");
        }
    }
}