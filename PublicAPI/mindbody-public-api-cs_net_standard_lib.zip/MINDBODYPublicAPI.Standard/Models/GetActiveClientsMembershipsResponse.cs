// <copyright file="GetActiveClientsMembershipsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetActiveClientsMembershipsResponse.
    /// </summary>
    public class GetActiveClientsMembershipsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetActiveClientsMembershipsResponse"/> class.
        /// </summary>
        public GetActiveClientsMembershipsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetActiveClientsMembershipsResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="clientMemberships">ClientMemberships.</param>
        public GetActiveClientsMembershipsResponse(
            Models.PaginationResponse paginationResponse = null,
            List<Models.ClientMemberships> clientMemberships = null)
        {
            this.PaginationResponse = paginationResponse;
            this.ClientMemberships = clientMemberships;
        }

        /// <summary>
        /// Contains information about the pagination used.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// Details about the requested memberships.
        /// </summary>
        [JsonProperty("ClientMemberships", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ClientMemberships> ClientMemberships { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetActiveClientsMembershipsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetActiveClientsMembershipsResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.ClientMemberships == null && other.ClientMemberships == null) || (this.ClientMemberships?.Equals(other.ClientMemberships) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.ClientMemberships = {(this.ClientMemberships == null ? "null" : $"[{string.Join(", ", this.ClientMemberships)} ]")}");
        }
    }
}