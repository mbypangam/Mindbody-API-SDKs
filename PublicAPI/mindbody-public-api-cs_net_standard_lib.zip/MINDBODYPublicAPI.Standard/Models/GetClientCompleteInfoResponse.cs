// <copyright file="GetClientCompleteInfoResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetClientCompleteInfoResponse.
    /// </summary>
    public class GetClientCompleteInfoResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetClientCompleteInfoResponse"/> class.
        /// </summary>
        public GetClientCompleteInfoResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetClientCompleteInfoResponse"/> class.
        /// </summary>
        /// <param name="client">Client.</param>
        /// <param name="clientServices">ClientServices.</param>
        /// <param name="clientContracts">ClientContracts.</param>
        /// <param name="clientMemberships">ClientMemberships.</param>
        /// <param name="clientArrivals">ClientArrivals.</param>
        public GetClientCompleteInfoResponse(
            Models.ClientWithSuspensionInfo client = null,
            List<Models.ClientService> clientServices = null,
            List<Models.ClientContract> clientContracts = null,
            List<Models.ClientMembership> clientMemberships = null,
            List<Models.ClientArrival> clientArrivals = null)
        {
            this.Client = client;
            this.ClientServices = clientServices;
            this.ClientContracts = clientContracts;
            this.ClientMemberships = clientMemberships;
            this.ClientArrivals = clientArrivals;
        }

        /// <summary>
        /// A Client DTO with Suspension Informatoin
        /// </summary>
        [JsonProperty("Client", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ClientWithSuspensionInfo Client { get; set; }

        /// <summary>
        /// Contains information about client pricing options.
        /// </summary>
        [JsonProperty("ClientServices", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ClientService> ClientServices { get; set; }

        /// <summary>
        /// Contains information about client contract.
        /// </summary>
        [JsonProperty("ClientContracts", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ClientContract> ClientContracts { get; set; }

        /// <summary>
        /// Contains information about client Memberships.
        /// </summary>
        [JsonProperty("ClientMemberships", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ClientMembership> ClientMemberships { get; set; }

        /// <summary>
        /// Contains information about client arrival services.
        /// </summary>
        [JsonProperty("ClientArrivals", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ClientArrival> ClientArrivals { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetClientCompleteInfoResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is GetClientCompleteInfoResponse other &&                ((this.Client == null && other.Client == null) || (this.Client?.Equals(other.Client) == true)) &&
                ((this.ClientServices == null && other.ClientServices == null) || (this.ClientServices?.Equals(other.ClientServices) == true)) &&
                ((this.ClientContracts == null && other.ClientContracts == null) || (this.ClientContracts?.Equals(other.ClientContracts) == true)) &&
                ((this.ClientMemberships == null && other.ClientMemberships == null) || (this.ClientMemberships?.Equals(other.ClientMemberships) == true)) &&
                ((this.ClientArrivals == null && other.ClientArrivals == null) || (this.ClientArrivals?.Equals(other.ClientArrivals) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Client = {(this.Client == null ? "null" : this.Client.ToString())}");
            toStringOutput.Add($"this.ClientServices = {(this.ClientServices == null ? "null" : $"[{string.Join(", ", this.ClientServices)} ]")}");
            toStringOutput.Add($"this.ClientContracts = {(this.ClientContracts == null ? "null" : $"[{string.Join(", ", this.ClientContracts)} ]")}");
            toStringOutput.Add($"this.ClientMemberships = {(this.ClientMemberships == null ? "null" : $"[{string.Join(", ", this.ClientMemberships)} ]")}");
            toStringOutput.Add($"this.ClientArrivals = {(this.ClientArrivals == null ? "null" : $"[{string.Join(", ", this.ClientArrivals)} ]")}");
        }
    }
}