// <copyright file="AddClientResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// AddClientResponse.
    /// </summary>
    public class AddClientResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddClientResponse"/> class.
        /// </summary>
        public AddClientResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddClientResponse"/> class.
        /// </summary>
        /// <param name="client">Client.</param>
        public AddClientResponse(
            Models.Client client = null)
        {
            this.Client = client;
        }

        /// <summary>
        /// The Client.
        /// </summary>
        [JsonProperty("Client", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Client Client { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddClientResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddClientResponse other &&                ((this.Client == null && other.Client == null) || (this.Client?.Equals(other.Client) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Client = {(this.Client == null ? "null" : this.Client.ToString())}");
        }
    }
}