// <copyright file="GetMobileProvidersResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetMobileProvidersResponse.
    /// </summary>
    public class GetMobileProvidersResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetMobileProvidersResponse"/> class.
        /// </summary>
        public GetMobileProvidersResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetMobileProvidersResponse"/> class.
        /// </summary>
        /// <param name="mobileProviders">MobileProviders.</param>
        public GetMobileProvidersResponse(
            List<Models.MindbodyPublicApiCommonModelsMobileProvider> mobileProviders = null)
        {
            this.MobileProviders = mobileProviders;
        }

        /// <summary>
        /// A list of mobile providers.
        /// </summary>
        [JsonProperty("MobileProviders", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiCommonModelsMobileProvider> MobileProviders { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetMobileProvidersResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetMobileProvidersResponse other &&
                ((this.MobileProviders == null && other.MobileProviders == null) || (this.MobileProviders?.Equals(other.MobileProviders) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MobileProviders = {(this.MobileProviders == null ? "null" : $"[{string.Join(", ", this.MobileProviders)} ]")}");
        }
    }
}