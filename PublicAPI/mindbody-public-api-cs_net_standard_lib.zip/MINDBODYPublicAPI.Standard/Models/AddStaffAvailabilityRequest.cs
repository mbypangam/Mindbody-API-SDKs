// <copyright file="AddStaffAvailabilityRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AddStaffAvailabilityRequest.
    /// </summary>
    public class AddStaffAvailabilityRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddStaffAvailabilityRequest"/> class.
        /// </summary>
        public AddStaffAvailabilityRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddStaffAvailabilityRequest"/> class.
        /// </summary>
        /// <param name="staffId">StaffId.</param>
        /// <param name="isAvailability">IsAvailability.</param>
        /// <param name="daysOfWeek">DaysOfWeek.</param>
        /// <param name="startTime">StartTime.</param>
        /// <param name="endTime">EndTime.</param>
        /// <param name="startDate">StartDate.</param>
        /// <param name="endDate">EndDate.</param>
        /// <param name="description">Description.</param>
        /// <param name="programIds">ProgramIds.</param>
        /// <param name="locationId">LocationId.</param>
        /// <param name="status">Status.</param>
        public AddStaffAvailabilityRequest(
            long staffId,
            bool isAvailability,
            List<string> daysOfWeek,
            string startTime,
            string endTime,
            string startDate,
            string endDate,
            string description = null,
            List<int> programIds = null,
            int? locationId = null,
            string status = null)
        {
            this.StaffId = staffId;
            this.IsAvailability = isAvailability;
            this.Description = description;
            this.ProgramIds = programIds;
            this.LocationId = locationId;
            this.DaysOfWeek = daysOfWeek;
            this.StartTime = startTime;
            this.EndTime = endTime;
            this.StartDate = startDate;
            this.EndDate = endDate;
            this.Status = status;
        }

        /// <summary>
        /// The ID of the staff member that availability or unavailability will be added.
        /// </summary>
        [JsonProperty("StaffId")]
        public long StaffId { get; set; }

        /// <summary>
        /// When `true`, indicates that availability will be added, <br />
        /// When `false`, indicates that unavailability will be added.
        /// </summary>
        [JsonProperty("IsAvailability")]
        public bool IsAvailability { get; set; }

        /// <summary>
        /// The description of the unavailability, ex. Lunch, Vacation. Required if IsAvailability passed as `false`.
        /// Omit if IsAvailability passed as `true`.
        /// </summary>
        [JsonProperty("Description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <summary>
        /// A list of program IDs. Must be a valid active schedulable Program ID. Required if IsAvailability passed as `true`.
        /// Omit if IsAvailability passed as `false`.
        /// </summary>
        [JsonProperty("ProgramIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ProgramIds { get; set; }

        /// <summary>
        /// The ID of the location where the availability is added. Required if IsAvailability passed as `true`.
        /// Omit if IsAvailability passed as `false`.
        /// </summary>
        [JsonProperty("LocationId", NullValueHandling = NullValueHandling.Ignore)]
        public int? LocationId { get; set; }

        /// <summary>
        /// The days of the week. Must contain at least one of the following Sunday, Monday, Tuesday etc.
        /// </summary>
        [JsonProperty("DaysOfWeek")]
        public List<string> DaysOfWeek { get; set; }

        /// <summary>
        /// The start time of the schedule. Must be in HH:MM:SS format.
        /// </summary>
        [JsonProperty("StartTime")]
        public string StartTime { get; set; }

        /// <summary>
        /// The end time of the schedule. Must be in HH:MM:SS format.
        /// </summary>
        [JsonProperty("EndTime")]
        public string EndTime { get; set; }

        /// <summary>
        /// The start date of the schedule. Must be in YYYY-MM-DD format.
        /// </summary>
        [JsonProperty("StartDate")]
        public string StartDate { get; set; }

        /// <summary>
        /// The end date of the schedule. Must be in YYYY-MM-DD format.
        /// </summary>
        [JsonProperty("EndDate")]
        public string EndDate { get; set; }

        /// <summary>
        /// The status of availability or unavailability. Possible values are:
        /// * Masked
        /// * Hidden
        /// * Public
        /// Default: Public
        /// </summary>
        [JsonProperty("Status", NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddStaffAvailabilityRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddStaffAvailabilityRequest other &&                this.StaffId.Equals(other.StaffId) &&
                this.IsAvailability.Equals(other.IsAvailability) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.ProgramIds == null && other.ProgramIds == null) || (this.ProgramIds?.Equals(other.ProgramIds) == true)) &&
                ((this.LocationId == null && other.LocationId == null) || (this.LocationId?.Equals(other.LocationId) == true)) &&
                ((this.DaysOfWeek == null && other.DaysOfWeek == null) || (this.DaysOfWeek?.Equals(other.DaysOfWeek) == true)) &&
                ((this.StartTime == null && other.StartTime == null) || (this.StartTime?.Equals(other.StartTime) == true)) &&
                ((this.EndTime == null && other.EndTime == null) || (this.EndTime?.Equals(other.EndTime) == true)) &&
                ((this.StartDate == null && other.StartDate == null) || (this.StartDate?.Equals(other.StartDate) == true)) &&
                ((this.EndDate == null && other.EndDate == null) || (this.EndDate?.Equals(other.EndDate) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.StaffId = {this.StaffId}");
            toStringOutput.Add($"this.IsAvailability = {this.IsAvailability}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.ProgramIds = {(this.ProgramIds == null ? "null" : $"[{string.Join(", ", this.ProgramIds)} ]")}");
            toStringOutput.Add($"this.LocationId = {(this.LocationId == null ? "null" : this.LocationId.ToString())}");
            toStringOutput.Add($"this.DaysOfWeek = {(this.DaysOfWeek == null ? "null" : $"[{string.Join(", ", this.DaysOfWeek)} ]")}");
            toStringOutput.Add($"this.StartTime = {(this.StartTime == null ? "null" : this.StartTime == string.Empty ? "" : this.StartTime)}");
            toStringOutput.Add($"this.EndTime = {(this.EndTime == null ? "null" : this.EndTime == string.Empty ? "" : this.EndTime)}");
            toStringOutput.Add($"this.StartDate = {(this.StartDate == null ? "null" : this.StartDate == string.Empty ? "" : this.StartDate)}");
            toStringOutput.Add($"this.EndDate = {(this.EndDate == null ? "null" : this.EndDate == string.Empty ? "" : this.EndDate)}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status == string.Empty ? "" : this.Status)}");
        }
    }
}