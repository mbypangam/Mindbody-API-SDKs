// <copyright file="AddAppointmentRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AddAppointmentRequest.
    /// </summary>
    public class AddAppointmentRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddAppointmentRequest"/> class.
        /// </summary>
        public AddAppointmentRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddAppointmentRequest"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="locationId">LocationId.</param>
        /// <param name="sessionTypeId">SessionTypeId.</param>
        /// <param name="staffId">StaffId.</param>
        /// <param name="startDateTime">StartDateTime.</param>
        /// <param name="applyPayment">ApplyPayment.</param>
        /// <param name="duration">Duration.</param>
        /// <param name="execute">Execute.</param>
        /// <param name="endDateTime">EndDateTime.</param>
        /// <param name="genderPreference">GenderPreference.</param>
        /// <param name="notes">Notes.</param>
        /// <param name="providerId">ProviderId.</param>
        /// <param name="resourceIds">ResourceIds.</param>
        /// <param name="sendEmail">SendEmail.</param>
        /// <param name="staffRequested">StaffRequested.</param>
        /// <param name="test">Test.</param>
        /// <param name="isWaitlist">IsWaitlist.</param>
        /// <param name="partnerExternalId">PartnerExternalId.</param>
        public AddAppointmentRequest(
            string clientId,
            int locationId,
            int sessionTypeId,
            long staffId,
            DateTime startDateTime,
            bool? applyPayment = null,
            int? duration = null,
            string execute = null,
            DateTime? endDateTime = null,
            string genderPreference = null,
            string notes = null,
            string providerId = null,
            List<int> resourceIds = null,
            bool? sendEmail = null,
            bool? staffRequested = null,
            bool? test = null,
            bool? isWaitlist = null,
            string partnerExternalId = null)
        {
            this.ApplyPayment = applyPayment;
            this.ClientId = clientId;
            this.Duration = duration;
            this.Execute = execute;
            this.EndDateTime = endDateTime;
            this.GenderPreference = genderPreference;
            this.LocationId = locationId;
            this.Notes = notes;
            this.ProviderId = providerId;
            this.ResourceIds = resourceIds;
            this.SendEmail = sendEmail;
            this.SessionTypeId = sessionTypeId;
            this.StaffId = staffId;
            this.StaffRequested = staffRequested;
            this.StartDateTime = startDateTime;
            this.Test = test;
            this.IsWaitlist = isWaitlist;
            this.PartnerExternalId = partnerExternalId;
        }

        /// <summary>
        /// When `true`, indicates that a payment should be applied to the appointment.
        /// <br />Default: **true**
        /// </summary>
        [JsonProperty("ApplyPayment", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ApplyPayment { get; set; }

        /// <summary>
        /// The RRSID of the client for whom the new appointment is being made.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// The duration of the appointment. This parameter is used to change the default duration of an appointment.
        /// </summary>
        [JsonProperty("Duration", NullValueHandling = NullValueHandling.Ignore)]
        public int? Duration { get; set; }

        /// <summary>
        /// The action taken to add this appointment.
        /// </summary>
        [JsonProperty("Execute", NullValueHandling = NullValueHandling.Ignore)]
        public string Execute { get; set; }

        /// <summary>
        /// The end date and time of the new appointment. <br />
        /// Default: **StartDateTime**, offset by the staff member’s default appointment duration.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDateTime { get; set; }

        /// <summary>
        /// The client’s service provider gender preference.
        /// </summary>
        [JsonProperty("GenderPreference", NullValueHandling = NullValueHandling.Ignore)]
        public string GenderPreference { get; set; }

        /// <summary>
        /// The ID of the location where the new appointment is to take place.
        /// </summary>
        [JsonProperty("LocationId")]
        public int LocationId { get; set; }

        /// <summary>
        /// Any general notes about this appointment.
        /// </summary>
        [JsonProperty("Notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <summary>
        /// If a user has Complementary and Alternative Medicine features enabled, this parameter assigns a provider ID to the appointment.
        /// </summary>
        [JsonProperty("ProviderId", NullValueHandling = NullValueHandling.Ignore)]
        public string ProviderId { get; set; }

        /// <summary>
        /// A list of resource IDs to associate with the new appointment.
        /// </summary>
        [JsonProperty("ResourceIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ResourceIds { get; set; }

        /// <summary>
        /// Whether to send client an email for cancellations. An email is sent only if the client has an email address and automatic emails have been set up.
        /// <br />Default: **false**
        /// </summary>
        [JsonProperty("SendEmail", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendEmail { get; set; }

        /// <summary>
        /// The session type associated with the new appointment.
        /// </summary>
        [JsonProperty("SessionTypeId")]
        public int SessionTypeId { get; set; }

        /// <summary>
        /// The ID of the staff member who is adding the new appointment.
        /// </summary>
        [JsonProperty("StaffId")]
        public long StaffId { get; set; }

        /// <summary>
        /// When `true`, indicates that the staff member was requested specifically by the client.
        /// </summary>
        [JsonProperty("StaffRequested", NullValueHandling = NullValueHandling.Ignore)]
        public bool? StaffRequested { get; set; }

        /// <summary>
        /// The start date and time of the new appointment.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDateTime")]
        public DateTime StartDateTime { get; set; }

        /// <summary>
        /// When true, indicates that the method is to be validated, but no new appointment data is added.
        /// <br />Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <summary>
        /// When `true`, indicates that the client should be added to a specific appointment waiting list.
        /// When `false`, the client should not be added to the waiting list.
        /// Default: **false**
        /// </summary>
        [JsonProperty("IsWaitlist", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsWaitlist { get; set; }

        /// <summary>
        /// Optional external key for api partners.
        /// </summary>
        [JsonProperty("PartnerExternalId", NullValueHandling = NullValueHandling.Ignore)]
        public string PartnerExternalId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddAppointmentRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddAppointmentRequest other &&                ((this.ApplyPayment == null && other.ApplyPayment == null) || (this.ApplyPayment?.Equals(other.ApplyPayment) == true)) &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.Duration == null && other.Duration == null) || (this.Duration?.Equals(other.Duration) == true)) &&
                ((this.Execute == null && other.Execute == null) || (this.Execute?.Equals(other.Execute) == true)) &&
                ((this.EndDateTime == null && other.EndDateTime == null) || (this.EndDateTime?.Equals(other.EndDateTime) == true)) &&
                ((this.GenderPreference == null && other.GenderPreference == null) || (this.GenderPreference?.Equals(other.GenderPreference) == true)) &&
                this.LocationId.Equals(other.LocationId) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true)) &&
                ((this.ProviderId == null && other.ProviderId == null) || (this.ProviderId?.Equals(other.ProviderId) == true)) &&
                ((this.ResourceIds == null && other.ResourceIds == null) || (this.ResourceIds?.Equals(other.ResourceIds) == true)) &&
                ((this.SendEmail == null && other.SendEmail == null) || (this.SendEmail?.Equals(other.SendEmail) == true)) &&
                this.SessionTypeId.Equals(other.SessionTypeId) &&
                this.StaffId.Equals(other.StaffId) &&
                ((this.StaffRequested == null && other.StaffRequested == null) || (this.StaffRequested?.Equals(other.StaffRequested) == true)) &&
                this.StartDateTime.Equals(other.StartDateTime) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true)) &&
                ((this.IsWaitlist == null && other.IsWaitlist == null) || (this.IsWaitlist?.Equals(other.IsWaitlist) == true)) &&
                ((this.PartnerExternalId == null && other.PartnerExternalId == null) || (this.PartnerExternalId?.Equals(other.PartnerExternalId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ApplyPayment = {(this.ApplyPayment == null ? "null" : this.ApplyPayment.ToString())}");
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId)}");
            toStringOutput.Add($"this.Duration = {(this.Duration == null ? "null" : this.Duration.ToString())}");
            toStringOutput.Add($"this.Execute = {(this.Execute == null ? "null" : this.Execute)}");
            toStringOutput.Add($"this.EndDateTime = {(this.EndDateTime == null ? "null" : this.EndDateTime.ToString())}");
            toStringOutput.Add($"this.GenderPreference = {(this.GenderPreference == null ? "null" : this.GenderPreference)}");
            toStringOutput.Add($"this.LocationId = {this.LocationId}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes)}");
            toStringOutput.Add($"this.ProviderId = {(this.ProviderId == null ? "null" : this.ProviderId)}");
            toStringOutput.Add($"this.ResourceIds = {(this.ResourceIds == null ? "null" : $"[{string.Join(", ", this.ResourceIds)} ]")}");
            toStringOutput.Add($"this.SendEmail = {(this.SendEmail == null ? "null" : this.SendEmail.ToString())}");
            toStringOutput.Add($"this.SessionTypeId = {this.SessionTypeId}");
            toStringOutput.Add($"this.StaffId = {this.StaffId}");
            toStringOutput.Add($"this.StaffRequested = {(this.StaffRequested == null ? "null" : this.StaffRequested.ToString())}");
            toStringOutput.Add($"this.StartDateTime = {this.StartDateTime}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
            toStringOutput.Add($"this.IsWaitlist = {(this.IsWaitlist == null ? "null" : this.IsWaitlist.ToString())}");
            toStringOutput.Add($"this.PartnerExternalId = {(this.PartnerExternalId == null ? "null" : this.PartnerExternalId)}");
        }
    }
}