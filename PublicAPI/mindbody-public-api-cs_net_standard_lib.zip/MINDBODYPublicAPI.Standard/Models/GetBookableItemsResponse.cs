// <copyright file="GetBookableItemsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetBookableItemsResponse.
    /// </summary>
    public class GetBookableItemsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetBookableItemsResponse"/> class.
        /// </summary>
        public GetBookableItemsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetBookableItemsResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="availabilities">Availabilities.</param>
        public GetBookableItemsResponse(
            Models.PaginationResponse paginationResponse = null,
            List<Models.Availability> availabilities = null)
        {
            this.PaginationResponse = paginationResponse;
            this.Availabilities = availabilities;
        }

        /// <summary>
        /// Contains information about the pagination used.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// Contains information about the availabilities for appointment booking.
        /// </summary>
        [JsonProperty("Availabilities", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Availability> Availabilities { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetBookableItemsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetBookableItemsResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.Availabilities == null && other.Availabilities == null) || (this.Availabilities?.Equals(other.Availabilities) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.Availabilities = {(this.Availabilities == null ? "null" : $"[{string.Join(", ", this.Availabilities)} ]")}");
        }
    }
}