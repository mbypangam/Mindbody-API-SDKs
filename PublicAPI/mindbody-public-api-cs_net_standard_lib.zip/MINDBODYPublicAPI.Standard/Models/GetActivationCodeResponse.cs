// <copyright file="GetActivationCodeResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetActivationCodeResponse.
    /// </summary>
    public class GetActivationCodeResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetActivationCodeResponse"/> class.
        /// </summary>
        public GetActivationCodeResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetActivationCodeResponse"/> class.
        /// </summary>
        /// <param name="activationCode">ActivationCode.</param>
        /// <param name="activationLink">ActivationLink.</param>
        public GetActivationCodeResponse(
            string activationCode = null,
            string activationLink = null)
        {
            this.ActivationCode = activationCode;
            this.ActivationLink = activationLink;
        }

        /// <summary>
        /// An activation code used to provide access to a site’s business data through MINDBODY.
        /// </summary>
        [JsonProperty("ActivationCode", NullValueHandling = NullValueHandling.Ignore)]
        public string ActivationCode { get; set; }

        /// <summary>
        /// A link to the Manage Credentials screen.
        /// </summary>
        [JsonProperty("ActivationLink", NullValueHandling = NullValueHandling.Ignore)]
        public string ActivationLink { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetActivationCodeResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetActivationCodeResponse other &&
                ((this.ActivationCode == null && other.ActivationCode == null) || (this.ActivationCode?.Equals(other.ActivationCode) == true)) &&
                ((this.ActivationLink == null && other.ActivationLink == null) || (this.ActivationLink?.Equals(other.ActivationLink) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ActivationCode = {(this.ActivationCode == null ? "null" : this.ActivationCode == string.Empty ? "" : this.ActivationCode)}");
            toStringOutput.Add($"this.ActivationLink = {(this.ActivationLink == null ? "null" : this.ActivationLink == string.Empty ? "" : this.ActivationLink)}");
        }
    }
}