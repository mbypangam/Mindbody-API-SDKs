// <copyright file="AddClientToClassVisit.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AddClientToClassVisit.
    /// </summary>
    public class AddClientToClassVisit
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddClientToClassVisit"/> class.
        /// </summary>
        public AddClientToClassVisit()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddClientToClassVisit"/> class.
        /// </summary>
        /// <param name="appointmentId">AppointmentId.</param>
        /// <param name="appointmentGenderPreference">AppointmentGenderPreference.</param>
        /// <param name="appointmentStatus">AppointmentStatus.</param>
        /// <param name="classId">ClassId.</param>
        /// <param name="clientId">ClientId.</param>
        /// <param name="startDateTime">StartDateTime.</param>
        /// <param name="endDateTime">EndDateTime.</param>
        /// <param name="id">Id.</param>
        /// <param name="lastModifiedDateTime">LastModifiedDateTime.</param>
        /// <param name="lateCancelled">LateCancelled.</param>
        /// <param name="locationId">LocationId.</param>
        /// <param name="makeUp">MakeUp.</param>
        /// <param name="name">Name.</param>
        /// <param name="serviceId">ServiceId.</param>
        /// <param name="serviceName">ServiceName.</param>
        /// <param name="productId">ProductId.</param>
        /// <param name="signedIn">SignedIn.</param>
        /// <param name="staffId">StaffId.</param>
        /// <param name="webSignup">WebSignup.</param>
        /// <param name="action">Action.</param>
        /// <param name="crossRegionalBookingPerformed">CrossRegionalBookingPerformed.</param>
        /// <param name="siteId">SiteId.</param>
        /// <param name="waitlistEntryId">WaitlistEntryId.</param>
        public AddClientToClassVisit(
            int? appointmentId = null,
            Models.AppointmentGenderPreference1Enum? appointmentGenderPreference = null,
            Models.AppointmentStatusEnum? appointmentStatus = null,
            int? classId = null,
            string clientId = null,
            DateTime? startDateTime = null,
            DateTime? endDateTime = null,
            long? id = null,
            DateTime? lastModifiedDateTime = null,
            bool? lateCancelled = null,
            int? locationId = null,
            bool? makeUp = null,
            string name = null,
            long? serviceId = null,
            string serviceName = null,
            long? productId = null,
            bool? signedIn = null,
            long? staffId = null,
            bool? webSignup = null,
            Models.Action1Enum? action = null,
            bool? crossRegionalBookingPerformed = null,
            int? siteId = null,
            int? waitlistEntryId = null)
        {
            this.AppointmentId = appointmentId;
            this.AppointmentGenderPreference = appointmentGenderPreference;
            this.AppointmentStatus = appointmentStatus;
            this.ClassId = classId;
            this.ClientId = clientId;
            this.StartDateTime = startDateTime;
            this.EndDateTime = endDateTime;
            this.Id = id;
            this.LastModifiedDateTime = lastModifiedDateTime;
            this.LateCancelled = lateCancelled;
            this.LocationId = locationId;
            this.MakeUp = makeUp;
            this.Name = name;
            this.ServiceId = serviceId;
            this.ServiceName = serviceName;
            this.ProductId = productId;
            this.SignedIn = signedIn;
            this.StaffId = staffId;
            this.WebSignup = webSignup;
            this.Action = action;
            this.CrossRegionalBookingPerformed = crossRegionalBookingPerformed;
            this.SiteId = siteId;
            this.WaitlistEntryId = waitlistEntryId;
        }

        /// <summary>
        /// The appointment’s ID.
        /// </summary>
        [JsonProperty("AppointmentId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AppointmentId { get; set; }

        /// <summary>
        /// The gender of staff member with whom the client prefers to book appointments.
        /// </summary>
        [JsonProperty("AppointmentGenderPreference", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.AppointmentGenderPreference1Enum? AppointmentGenderPreference { get; set; }

        /// <summary>
        /// The status of the appointment.
        /// </summary>
        [JsonProperty("AppointmentStatus", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.AppointmentStatusEnum? AppointmentStatus { get; set; }

        /// <summary>
        /// The class ID that was used to retrieve the visits.
        /// </summary>
        [JsonProperty("ClassId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ClassId { get; set; }

        /// <summary>
        /// The ID of the client associated with the visit.
        /// </summary>
        [JsonProperty("ClientId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientId { get; set; }

        /// <summary>
        /// The time this class is scheduled to start.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDateTime { get; set; }

        /// <summary>
        /// The date and time the visit ends. The Public API returns UTC dates and times. For example, a class that occurs on June 25th, 2018 at 2:15PM (EST) appears as “2018-06-25T19:15:00Z” because EST is five hours behind UTC. Date time pairs always return in the format YYYY-MM-DDTHH:mm:ssZ.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDateTime { get; set; }

        /// <summary>
        /// The ID of the visit.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public long? Id { get; set; }

        /// <summary>
        /// When included in the request, only records modified on or after the specified `LastModifiedDate` are included in the response. The Public API returns UTC dates and times. For example, a class that occurs on June 25th, 2018 at 2:15PM (EST) appears as “2018-06-25T19:15:00Z” because EST is five hours behind UTC. Date time pairs always return in the format YYYY-MM-DDTHH:mm:ssZ.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("LastModifiedDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? LastModifiedDateTime { get; set; }

        /// <summary>
        /// When `true`, indicates that the class has been `LateCancelled`.<br />
        /// When `false`, indicates that the class has not been `LateCancelled`.
        /// </summary>
        [JsonProperty("LateCancelled", NullValueHandling = NullValueHandling.Ignore)]
        public bool? LateCancelled { get; set; }

        /// <summary>
        /// The ID of the location where the visit took place or is to take place.
        /// </summary>
        [JsonProperty("LocationId", NullValueHandling = NullValueHandling.Ignore)]
        public int? LocationId { get; set; }

        /// <summary>
        /// When `true`, the client can make up this session and a session is not deducted from the pricing option that was used to sign the client into the enrollment. When the client has the make-up session, a session is automatically removed from a pricing option that matches the service category of the enrollment and is within the same date range of the missed session.<br />
        /// When `false`, the client cannot make up this session. See [Enrollments: Make-ups](https://support.mindbodyonline.com/s/article/203259433-Enrollments-Make-ups?language=en_US) for more information.
        /// </summary>
        [JsonProperty("MakeUp", NullValueHandling = NullValueHandling.Ignore)]
        public bool? MakeUp { get; set; }

        /// <summary>
        /// The name of the class.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// The ID of the client's pricing option applied to the class visit.
        /// </summary>
        [JsonProperty("ServiceId", NullValueHandling = NullValueHandling.Ignore)]
        public long? ServiceId { get; set; }

        /// <summary>
        /// The name of the pricing option applied to the class visit.
        /// </summary>
        [JsonProperty("ServiceName", NullValueHandling = NullValueHandling.Ignore)]
        public string ServiceName { get; set; }

        /// <summary>
        /// The business' ID of the type of pricing option used to pay for the class visit.
        /// </summary>
        [JsonProperty("ProductId", NullValueHandling = NullValueHandling.Ignore)]
        public long? ProductId { get; set; }

        /// <summary>
        /// When `true`, indicates that the client has been signed in.<br />
        /// When `false`, indicates that the client has not been signed in.
        /// </summary>
        [JsonProperty("SignedIn", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SignedIn { get; set; }

        /// <summary>
        /// The ID of the staff member who is teaching the class.
        /// </summary>
        [JsonProperty("StaffId", NullValueHandling = NullValueHandling.Ignore)]
        public long? StaffId { get; set; }

        /// <summary>
        /// When `true`, indicates that the client signed up online.<br />
        /// When `false`, indicates that the client was signed up by a staff member.
        /// </summary>
        [JsonProperty("WebSignup", NullValueHandling = NullValueHandling.Ignore)]
        public bool? WebSignup { get; set; }

        /// <summary>
        /// The action taken.
        /// </summary>
        [JsonProperty("Action", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.Action1Enum? Action { get; set; }

        /// <summary>
        /// When `true`, indicates that the client is paying for the visit using a pricing option from one of their associated cross-regional profiles.
        /// </summary>
        [JsonProperty("CrossRegionalBookingPerformed", NullValueHandling = NullValueHandling.Ignore)]
        public bool? CrossRegionalBookingPerformed { get; set; }

        /// <summary>
        /// The ID of the business from which cross-regional payment is applied.
        /// </summary>
        [JsonProperty("SiteId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SiteId { get; set; }

        /// <summary>
        /// When this value is not null, it indicates that the client is on the waiting list for the requested class. The only additional fields that are populated when this is not null are:
        /// * ClassId
        /// * ClientId
        /// You can call GET WaitlistEntries using `WaitlistEntryId` to obtain more data about this waiting list entry.
        /// </summary>
        [JsonProperty("WaitlistEntryId", NullValueHandling = NullValueHandling.Ignore)]
        public int? WaitlistEntryId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddClientToClassVisit : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddClientToClassVisit other &&                ((this.AppointmentId == null && other.AppointmentId == null) || (this.AppointmentId?.Equals(other.AppointmentId) == true)) &&
                ((this.AppointmentGenderPreference == null && other.AppointmentGenderPreference == null) || (this.AppointmentGenderPreference?.Equals(other.AppointmentGenderPreference) == true)) &&
                ((this.AppointmentStatus == null && other.AppointmentStatus == null) || (this.AppointmentStatus?.Equals(other.AppointmentStatus) == true)) &&
                ((this.ClassId == null && other.ClassId == null) || (this.ClassId?.Equals(other.ClassId) == true)) &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.StartDateTime == null && other.StartDateTime == null) || (this.StartDateTime?.Equals(other.StartDateTime) == true)) &&
                ((this.EndDateTime == null && other.EndDateTime == null) || (this.EndDateTime?.Equals(other.EndDateTime) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.LastModifiedDateTime == null && other.LastModifiedDateTime == null) || (this.LastModifiedDateTime?.Equals(other.LastModifiedDateTime) == true)) &&
                ((this.LateCancelled == null && other.LateCancelled == null) || (this.LateCancelled?.Equals(other.LateCancelled) == true)) &&
                ((this.LocationId == null && other.LocationId == null) || (this.LocationId?.Equals(other.LocationId) == true)) &&
                ((this.MakeUp == null && other.MakeUp == null) || (this.MakeUp?.Equals(other.MakeUp) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.ServiceId == null && other.ServiceId == null) || (this.ServiceId?.Equals(other.ServiceId) == true)) &&
                ((this.ServiceName == null && other.ServiceName == null) || (this.ServiceName?.Equals(other.ServiceName) == true)) &&
                ((this.ProductId == null && other.ProductId == null) || (this.ProductId?.Equals(other.ProductId) == true)) &&
                ((this.SignedIn == null && other.SignedIn == null) || (this.SignedIn?.Equals(other.SignedIn) == true)) &&
                ((this.StaffId == null && other.StaffId == null) || (this.StaffId?.Equals(other.StaffId) == true)) &&
                ((this.WebSignup == null && other.WebSignup == null) || (this.WebSignup?.Equals(other.WebSignup) == true)) &&
                ((this.Action == null && other.Action == null) || (this.Action?.Equals(other.Action) == true)) &&
                ((this.CrossRegionalBookingPerformed == null && other.CrossRegionalBookingPerformed == null) || (this.CrossRegionalBookingPerformed?.Equals(other.CrossRegionalBookingPerformed) == true)) &&
                ((this.SiteId == null && other.SiteId == null) || (this.SiteId?.Equals(other.SiteId) == true)) &&
                ((this.WaitlistEntryId == null && other.WaitlistEntryId == null) || (this.WaitlistEntryId?.Equals(other.WaitlistEntryId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AppointmentId = {(this.AppointmentId == null ? "null" : this.AppointmentId.ToString())}");
            toStringOutput.Add($"this.AppointmentGenderPreference = {(this.AppointmentGenderPreference == null ? "null" : this.AppointmentGenderPreference.ToString())}");
            toStringOutput.Add($"this.AppointmentStatus = {(this.AppointmentStatus == null ? "null" : this.AppointmentStatus.ToString())}");
            toStringOutput.Add($"this.ClassId = {(this.ClassId == null ? "null" : this.ClassId.ToString())}");
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.StartDateTime = {(this.StartDateTime == null ? "null" : this.StartDateTime.ToString())}");
            toStringOutput.Add($"this.EndDateTime = {(this.EndDateTime == null ? "null" : this.EndDateTime.ToString())}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.LastModifiedDateTime = {(this.LastModifiedDateTime == null ? "null" : this.LastModifiedDateTime.ToString())}");
            toStringOutput.Add($"this.LateCancelled = {(this.LateCancelled == null ? "null" : this.LateCancelled.ToString())}");
            toStringOutput.Add($"this.LocationId = {(this.LocationId == null ? "null" : this.LocationId.ToString())}");
            toStringOutput.Add($"this.MakeUp = {(this.MakeUp == null ? "null" : this.MakeUp.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.ServiceId = {(this.ServiceId == null ? "null" : this.ServiceId.ToString())}");
            toStringOutput.Add($"this.ServiceName = {(this.ServiceName == null ? "null" : this.ServiceName == string.Empty ? "" : this.ServiceName)}");
            toStringOutput.Add($"this.ProductId = {(this.ProductId == null ? "null" : this.ProductId.ToString())}");
            toStringOutput.Add($"this.SignedIn = {(this.SignedIn == null ? "null" : this.SignedIn.ToString())}");
            toStringOutput.Add($"this.StaffId = {(this.StaffId == null ? "null" : this.StaffId.ToString())}");
            toStringOutput.Add($"this.WebSignup = {(this.WebSignup == null ? "null" : this.WebSignup.ToString())}");
            toStringOutput.Add($"this.Action = {(this.Action == null ? "null" : this.Action.ToString())}");
            toStringOutput.Add($"this.CrossRegionalBookingPerformed = {(this.CrossRegionalBookingPerformed == null ? "null" : this.CrossRegionalBookingPerformed.ToString())}");
            toStringOutput.Add($"this.SiteId = {(this.SiteId == null ? "null" : this.SiteId.ToString())}");
            toStringOutput.Add($"this.WaitlistEntryId = {(this.WaitlistEntryId == null ? "null" : this.WaitlistEntryId.ToString())}");
        }
    }
}