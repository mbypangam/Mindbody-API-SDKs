// <copyright file="CartItem.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CartItem.
    /// </summary>
    public class CartItem
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CartItem"/> class.
        /// </summary>
        public CartItem()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CartItem"/> class.
        /// </summary>
        /// <param name="item">Item.</param>
        /// <param name="discountAmount">DiscountAmount.</param>
        /// <param name="visitIds">VisitIds.</param>
        /// <param name="appointmentIds">AppointmentIds.</param>
        /// <param name="appointments">Appointments.</param>
        /// <param name="id">Id.</param>
        /// <param name="quantity">Quantity.</param>
        public CartItem(
            object item = null,
            double? discountAmount = null,
            List<long> visitIds = null,
            List<long> appointmentIds = null,
            List<Models.Appointment> appointments = null,
            int? id = null,
            int? quantity = null)
        {
            this.Item = item;
            this.DiscountAmount = discountAmount;
            this.VisitIds = visitIds;
            this.AppointmentIds = appointmentIds;
            this.Appointments = appointments;
            this.Id = id;
            this.Quantity = quantity;
        }

        /// <summary>
        /// Gets or sets Item.
        /// </summary>
        [JsonProperty("Item", NullValueHandling = NullValueHandling.Ignore)]
        public object Item { get; set; }

        /// <summary>
        /// The amount of the discount applied to the item.
        /// </summary>
        [JsonProperty("DiscountAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? DiscountAmount { get; set; }

        /// <summary>
        /// The IDs of the booked classes, enrollments, or courses that were reconciled by this cart item. This list is only returned if a valid visit ID was passed in the request’s `VisitIds` list.
        /// </summary>
        [JsonProperty("VisitIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<long> VisitIds { get; set; }

        /// <summary>
        /// Gets or sets the item.
        /// </summary>
        [JsonProperty("AppointmentIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<long> AppointmentIds { get; set; }

        /// <summary>
        /// The IDs of the appointments that were reconciled by this cart item. This list is only returned if a valid appointment ID was passed in the request’s `AppointmentIds` list.
        /// </summary>
        [JsonProperty("Appointments", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Appointment> Appointments { get; set; }

        /// <summary>
        /// The item’s ID in the current cart.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// The quantity of the item being purchased.
        /// </summary>
        [JsonProperty("Quantity", NullValueHandling = NullValueHandling.Ignore)]
        public int? Quantity { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CartItem : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CartItem other &&
                ((this.Item == null && other.Item == null) || (this.Item?.Equals(other.Item) == true)) &&
                ((this.DiscountAmount == null && other.DiscountAmount == null) || (this.DiscountAmount?.Equals(other.DiscountAmount) == true)) &&
                ((this.VisitIds == null && other.VisitIds == null) || (this.VisitIds?.Equals(other.VisitIds) == true)) &&
                ((this.AppointmentIds == null && other.AppointmentIds == null) || (this.AppointmentIds?.Equals(other.AppointmentIds) == true)) &&
                ((this.Appointments == null && other.Appointments == null) || (this.Appointments?.Equals(other.Appointments) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Quantity == null && other.Quantity == null) || (this.Quantity?.Equals(other.Quantity) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"Item = {(this.Item == null ? "null" : this.Item.ToString())}");
            toStringOutput.Add($"this.DiscountAmount = {(this.DiscountAmount == null ? "null" : this.DiscountAmount.ToString())}");
            toStringOutput.Add($"this.VisitIds = {(this.VisitIds == null ? "null" : $"[{string.Join(", ", this.VisitIds)} ]")}");
            toStringOutput.Add($"this.AppointmentIds = {(this.AppointmentIds == null ? "null" : $"[{string.Join(", ", this.AppointmentIds)} ]")}");
            toStringOutput.Add($"this.Appointments = {(this.Appointments == null ? "null" : $"[{string.Join(", ", this.Appointments)} ]")}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Quantity = {(this.Quantity == null ? "null" : this.Quantity.ToString())}");
        }
    }
}