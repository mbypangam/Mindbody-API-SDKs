// <copyright file="GetClientIndexesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetClientIndexesResponse.
    /// </summary>
    public class GetClientIndexesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetClientIndexesResponse"/> class.
        /// </summary>
        public GetClientIndexesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetClientIndexesResponse"/> class.
        /// </summary>
        /// <param name="clientIndexes">ClientIndexes.</param>
        public GetClientIndexesResponse(
            List<Models.ClientIndex> clientIndexes = null)
        {
            this.ClientIndexes = clientIndexes;
        }

        /// <summary>
        /// Contains information about the client indexes.
        /// </summary>
        [JsonProperty("ClientIndexes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ClientIndex> ClientIndexes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetClientIndexesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is GetClientIndexesResponse other &&                ((this.ClientIndexes == null && other.ClientIndexes == null) || (this.ClientIndexes?.Equals(other.ClientIndexes) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientIndexes = {(this.ClientIndexes == null ? "null" : $"[{string.Join(", ", this.ClientIndexes)} ]")}");
        }
    }
}