// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="classScheduleId">ClassScheduleId.</param>
        /// <param name="enrollDateForward">EnrollDateForward.</param>
        /// <param name="enrollOpen">EnrollOpen.</param>
        /// <param name="test">Test.</param>
        /// <param name="sendEmail">SendEmail.</param>
        /// <param name="waitlist">Waitlist.</param>
        /// <param name="waitlistEntryId">WaitlistEntryId.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest(
            string clientId,
            int classScheduleId,
            DateTime? enrollDateForward = null,
            List<DateTime> enrollOpen = null,
            bool? test = null,
            bool? sendEmail = null,
            bool? waitlist = null,
            int? waitlistEntryId = null)
        {
            this.ClientId = clientId;
            this.ClassScheduleId = classScheduleId;
            this.EnrollDateForward = enrollDateForward;
            this.EnrollOpen = enrollOpen;
            this.Test = test;
            this.SendEmail = sendEmail;
            this.Waitlist = waitlist;
            this.WaitlistEntryId = waitlistEntryId;
        }

        /// <summary>
        /// The client IDs of the clients to add to the specified enrollments.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// The class schedule IDs of the enrollments to add the clients to. The ClassScheduleId can be found in GetEnrollments as the EnrollmentId.
        /// </summary>
        [JsonProperty("ClassScheduleId")]
        public int ClassScheduleId { get; set; }

        /// <summary>
        /// Enroll the clients from this date forward. EnrollDateForward takes priority over open enrollment.
        /// Default: **null**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EnrollDateForward", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EnrollDateForward { get; set; }

        /// <summary>
        /// Enroll for selected dates.
        /// </summary>
        [JsonConverter(typeof(ListDateTimeConverter), typeof(IsoDateTimeConverter))]
        [JsonProperty("EnrollOpen", NullValueHandling = NullValueHandling.Ignore)]
        public List<DateTime> EnrollOpen { get; set; }

        /// <summary>
        /// When `true`, input information is validated, but not committed.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <summary>
        /// When `true`, indicates that the client should be sent an email. An email is only sent if the client has an email address and automatic emails have been set up. <br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("SendEmail", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendEmail { get; set; }

        /// <summary>
        /// When `true`, the client is added to a specific enrollments waiting list..
        /// </summary>
        [JsonProperty("Waitlist", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Waitlist { get; set; }

        /// <summary>
        /// The waiting list entry to add. Used to add a client to an enrollment from a waiting list entry.
        /// </summary>
        [JsonProperty("WaitlistEntryId", NullValueHandling = NullValueHandling.Ignore)]
        public int? WaitlistEntryId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest other &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                this.ClassScheduleId.Equals(other.ClassScheduleId) &&
                ((this.EnrollDateForward == null && other.EnrollDateForward == null) || (this.EnrollDateForward?.Equals(other.EnrollDateForward) == true)) &&
                ((this.EnrollOpen == null && other.EnrollOpen == null) || (this.EnrollOpen?.Equals(other.EnrollOpen) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true)) &&
                ((this.SendEmail == null && other.SendEmail == null) || (this.SendEmail?.Equals(other.SendEmail) == true)) &&
                ((this.Waitlist == null && other.Waitlist == null) || (this.Waitlist?.Equals(other.Waitlist) == true)) &&
                ((this.WaitlistEntryId == null && other.WaitlistEntryId == null) || (this.WaitlistEntryId?.Equals(other.WaitlistEntryId) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.ClassScheduleId = {this.ClassScheduleId}");
            toStringOutput.Add($"this.EnrollDateForward = {(this.EnrollDateForward == null ? "null" : this.EnrollDateForward.ToString())}");
            toStringOutput.Add($"this.EnrollOpen = {(this.EnrollOpen == null ? "null" : $"[{string.Join(", ", this.EnrollOpen)} ]")}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
            toStringOutput.Add($"this.SendEmail = {(this.SendEmail == null ? "null" : this.SendEmail.ToString())}");
            toStringOutput.Add($"this.Waitlist = {(this.Waitlist == null ? "null" : this.Waitlist.ToString())}");
            toStringOutput.Add($"this.WaitlistEntryId = {(this.WaitlistEntryId == null ? "null" : this.WaitlistEntryId.ToString())}");
        }
    }
}