// <copyright file="GetCustomClientFieldsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetCustomClientFieldsResponse.
    /// </summary>
    public class GetCustomClientFieldsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetCustomClientFieldsResponse"/> class.
        /// </summary>
        public GetCustomClientFieldsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetCustomClientFieldsResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="customClientFields">CustomClientFields.</param>
        public GetCustomClientFieldsResponse(
            Models.PaginationResponse paginationResponse = null,
            List<Models.MindbodyPublicApiDtoModelsV6CustomClientField> customClientFields = null)
        {
            this.PaginationResponse = paginationResponse;
            this.CustomClientFields = customClientFields;
        }

        /// <summary>
        /// Contains information about the pagination used.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// Contains information about the available custom client fields.
        /// </summary>
        [JsonProperty("CustomClientFields", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6CustomClientField> CustomClientFields { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetCustomClientFieldsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetCustomClientFieldsResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.CustomClientFields == null && other.CustomClientFields == null) || (this.CustomClientFields?.Equals(other.CustomClientFields) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.CustomClientFields = {(this.CustomClientFields == null ? "null" : $"[{string.Join(", ", this.CustomClientFields)} ]")}");
        }
    }
}