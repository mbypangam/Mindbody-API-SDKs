// <copyright file="AddAppointmentResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AddAppointmentResponse.
    /// </summary>
    public class AddAppointmentResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddAppointmentResponse"/> class.
        /// </summary>
        public AddAppointmentResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddAppointmentResponse"/> class.
        /// </summary>
        /// <param name="appointment">Appointment.</param>
        public AddAppointmentResponse(
            Models.Appointment appointment = null)
        {
            this.Appointment = appointment;
        }

        /// <summary>
        /// Contains information about an appointment.
        /// </summary>
        [JsonProperty("Appointment", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Appointment Appointment { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddAppointmentResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddAppointmentResponse other &&                ((this.Appointment == null && other.Appointment == null) || (this.Appointment?.Equals(other.Appointment) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Appointment = {(this.Appointment == null ? "null" : this.Appointment.ToString())}");
        }
    }
}