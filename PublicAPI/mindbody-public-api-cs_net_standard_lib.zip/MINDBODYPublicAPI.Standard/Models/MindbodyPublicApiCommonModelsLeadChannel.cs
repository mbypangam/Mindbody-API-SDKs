// <copyright file="MindbodyPublicApiCommonModelsLeadChannel.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiCommonModelsLeadChannel.
    /// </summary>
    public class MindbodyPublicApiCommonModelsLeadChannel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsLeadChannel"/> class.
        /// </summary>
        public MindbodyPublicApiCommonModelsLeadChannel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsLeadChannel"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="name">Name.</param>
        /// <param name="salespipelineId">SalespipelineId.</param>
        /// <param name="universalCustomerId">UniversalCustomerId.</param>
        /// <param name="studioId">StudioId.</param>
        public MindbodyPublicApiCommonModelsLeadChannel(
            int? id = null,
            string name = null,
            int? salespipelineId = null,
            Guid? universalCustomerId = null,
            int? studioId = null)
        {
            this.Id = id;
            this.Name = name;
            this.SalespipelineId = salespipelineId;
            this.UniversalCustomerId = universalCustomerId;
            this.StudioId = studioId;
        }

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets SalespipelineId.
        /// </summary>
        [JsonProperty("SalespipelineId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SalespipelineId { get; set; }

        /// <summary>
        /// Gets or sets UniversalCustomerId.
        /// </summary>
        [JsonProperty("UniversalCustomerId", NullValueHandling = NullValueHandling.Ignore)]
        public Guid? UniversalCustomerId { get; set; }

        /// <summary>
        /// Gets or sets StudioId.
        /// </summary>
        [JsonProperty("StudioId", NullValueHandling = NullValueHandling.Ignore)]
        public int? StudioId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiCommonModelsLeadChannel : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiCommonModelsLeadChannel other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.SalespipelineId == null && other.SalespipelineId == null) || (this.SalespipelineId?.Equals(other.SalespipelineId) == true)) &&
                ((this.UniversalCustomerId == null && other.UniversalCustomerId == null) || (this.UniversalCustomerId?.Equals(other.UniversalCustomerId) == true)) &&
                ((this.StudioId == null && other.StudioId == null) || (this.StudioId?.Equals(other.StudioId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.SalespipelineId = {(this.SalespipelineId == null ? "null" : this.SalespipelineId.ToString())}");
            toStringOutput.Add($"this.UniversalCustomerId = {(this.UniversalCustomerId == null ? "null" : this.UniversalCustomerId.ToString())}");
            toStringOutput.Add($"this.StudioId = {(this.StudioId == null ? "null" : this.StudioId.ToString())}");
        }
    }
}