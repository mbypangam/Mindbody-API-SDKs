// <copyright file="GetAppointmentOptionsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetAppointmentOptionsResponse.
    /// </summary>
    public class GetAppointmentOptionsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetAppointmentOptionsResponse"/> class.
        /// </summary>
        public GetAppointmentOptionsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetAppointmentOptionsResponse"/> class.
        /// </summary>
        /// <param name="options">Options.</param>
        public GetAppointmentOptionsResponse(
            List<Models.AppointmentOption> options = null)
        {
            this.Options = options;
        }

        /// <summary>
        /// Contains information about the appointment options.
        /// </summary>
        [JsonProperty("Options", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AppointmentOption> Options { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetAppointmentOptionsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is GetAppointmentOptionsResponse other &&                ((this.Options == null && other.Options == null) || (this.Options?.Equals(other.Options) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Options = {(this.Options == null ? "null" : $"[{string.Join(", ", this.Options)} ]")}");
        }
    }
}