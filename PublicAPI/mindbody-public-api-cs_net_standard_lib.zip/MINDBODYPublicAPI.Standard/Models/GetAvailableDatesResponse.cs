// <copyright file="GetAvailableDatesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetAvailableDatesResponse.
    /// </summary>
    public class GetAvailableDatesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetAvailableDatesResponse"/> class.
        /// </summary>
        public GetAvailableDatesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetAvailableDatesResponse"/> class.
        /// </summary>
        /// <param name="availableDates">AvailableDates.</param>
        public GetAvailableDatesResponse(
            List<DateTime> availableDates = null)
        {
            this.AvailableDates = availableDates;
        }

        /// <summary>
        /// A list of dates where scheduled appointment availability was found after applying request filters.
        /// </summary>
        [JsonConverter(typeof(CoreListConverter), typeof(IsoDateTimeConverter))]
        [JsonProperty("AvailableDates", NullValueHandling = NullValueHandling.Ignore)]
        public List<DateTime> AvailableDates { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetAvailableDatesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is GetAvailableDatesResponse other &&                ((this.AvailableDates == null && other.AvailableDates == null) || (this.AvailableDates?.Equals(other.AvailableDates) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AvailableDates = {(this.AvailableDates == null ? "null" : $"[{string.Join(", ", this.AvailableDates)} ]")}");
        }
    }
}