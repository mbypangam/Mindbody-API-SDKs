// <copyright file="MindbodyPublicApiDtoModelsV6AppointmentAddOn.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6AppointmentAddOn.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6AppointmentAddOn
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentAddOn"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6AppointmentAddOn()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentAddOn"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="name">Name.</param>
        /// <param name="numDeducted">NumDeducted.</param>
        /// <param name="categoryId">CategoryId.</param>
        /// <param name="category">Category.</param>
        public MindbodyPublicApiDtoModelsV6AppointmentAddOn(
            int? id = null,
            string name = null,
            int? numDeducted = null,
            int? categoryId = null,
            string category = null)
        {
            this.Id = id;
            this.Name = name;
            this.NumDeducted = numDeducted;
            this.CategoryId = categoryId;
            this.Category = category;
        }

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets NumDeducted.
        /// </summary>
        [JsonProperty("NumDeducted", NullValueHandling = NullValueHandling.Ignore)]
        public int? NumDeducted { get; set; }

        /// <summary>
        /// Gets or sets CategoryId.
        /// </summary>
        [JsonProperty("CategoryId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CategoryId { get; set; }

        /// <summary>
        /// Gets or sets Category.
        /// </summary>
        [JsonProperty("Category", NullValueHandling = NullValueHandling.Ignore)]
        public string Category { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6AppointmentAddOn : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6AppointmentAddOn other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.NumDeducted == null && other.NumDeducted == null) || (this.NumDeducted?.Equals(other.NumDeducted) == true)) &&
                ((this.CategoryId == null && other.CategoryId == null) || (this.CategoryId?.Equals(other.CategoryId) == true)) &&
                ((this.Category == null && other.Category == null) || (this.Category?.Equals(other.Category) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.NumDeducted = {(this.NumDeducted == null ? "null" : this.NumDeducted.ToString())}");
            toStringOutput.Add($"this.CategoryId = {(this.CategoryId == null ? "null" : this.CategoryId.ToString())}");
            toStringOutput.Add($"this.Category = {(this.Category == null ? "null" : this.Category == string.Empty ? "" : this.Category)}");
        }
    }
}