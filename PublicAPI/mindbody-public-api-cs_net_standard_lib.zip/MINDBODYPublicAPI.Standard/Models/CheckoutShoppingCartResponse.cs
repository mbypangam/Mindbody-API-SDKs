// <copyright file="CheckoutShoppingCartResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CheckoutShoppingCartResponse.
    /// </summary>
    public class CheckoutShoppingCartResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutShoppingCartResponse"/> class.
        /// </summary>
        public CheckoutShoppingCartResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutShoppingCartResponse"/> class.
        /// </summary>
        /// <param name="shoppingCart">ShoppingCart.</param>
        /// <param name="classes">Classes.</param>
        /// <param name="appointments">Appointments.</param>
        /// <param name="enrollments">Enrollments.</param>
        public CheckoutShoppingCartResponse(
            Models.ShoppingCart shoppingCart = null,
            List<Models.Class> classes = null,
            List<Models.Appointment> appointments = null,
            List<Models.ClassSchedule> enrollments = null)
        {
            this.ShoppingCart = shoppingCart;
            this.Classes = classes;
            this.Appointments = appointments;
            this.Enrollments = enrollments;
        }

        /// <summary>
        /// Contains information about the shopping cart.
        /// </summary>
        [JsonProperty("ShoppingCart", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ShoppingCart ShoppingCart { get; set; }

        /// <summary>
        /// Contains information about the classes.
        /// </summary>
        [JsonProperty("Classes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Class> Classes { get; set; }

        /// <summary>
        /// Contains information about the appointments.
        /// </summary>
        [JsonProperty("Appointments", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Appointment> Appointments { get; set; }

        /// <summary>
        /// Contains information about enrollment class schedules.
        /// </summary>
        [JsonProperty("Enrollments", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ClassSchedule> Enrollments { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CheckoutShoppingCartResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CheckoutShoppingCartResponse other &&
                ((this.ShoppingCart == null && other.ShoppingCart == null) || (this.ShoppingCart?.Equals(other.ShoppingCart) == true)) &&
                ((this.Classes == null && other.Classes == null) || (this.Classes?.Equals(other.Classes) == true)) &&
                ((this.Appointments == null && other.Appointments == null) || (this.Appointments?.Equals(other.Appointments) == true)) &&
                ((this.Enrollments == null && other.Enrollments == null) || (this.Enrollments?.Equals(other.Enrollments) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ShoppingCart = {(this.ShoppingCart == null ? "null" : this.ShoppingCart.ToString())}");
            toStringOutput.Add($"this.Classes = {(this.Classes == null ? "null" : $"[{string.Join(", ", this.Classes)} ]")}");
            toStringOutput.Add($"this.Appointments = {(this.Appointments == null ? "null" : $"[{string.Join(", ", this.Appointments)} ]")}");
            toStringOutput.Add($"this.Enrollments = {(this.Enrollments == null ? "null" : $"[{string.Join(", ", this.Enrollments)} ]")}");
        }
    }
}