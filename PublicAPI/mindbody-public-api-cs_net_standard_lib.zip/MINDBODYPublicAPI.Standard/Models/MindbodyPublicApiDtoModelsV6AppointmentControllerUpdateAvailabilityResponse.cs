// <copyright file="MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse"/> class.
        /// </summary>
        /// <param name="staffMembers">StaffMembers.</param>
        /// <param name="errors">Errors.</param>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse(
            List<Models.MindbodyPublicApiDtoModelsV6Staff> staffMembers = null,
            List<Models.MindbodyPublicApiDtoModelsV6ApiError> errors = null)
        {
            this.StaffMembers = staffMembers;
            this.Errors = errors;
        }

        /// <summary>
        /// This is the success list of the trainer availability
        /// </summary>
        [JsonProperty("StaffMembers", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6Staff> StaffMembers { get; set; }

        /// <summary>
        /// Gets or sets Errors.
        /// </summary>
        [JsonProperty("Errors", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6ApiError> Errors { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAvailabilityResponse other &&
                ((this.StaffMembers == null && other.StaffMembers == null) || (this.StaffMembers?.Equals(other.StaffMembers) == true)) &&
                ((this.Errors == null && other.Errors == null) || (this.Errors?.Equals(other.Errors) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.StaffMembers = {(this.StaffMembers == null ? "null" : $"[{string.Join(", ", this.StaffMembers)} ]")}");
            toStringOutput.Add($"this.Errors = {(this.Errors == null ? "null" : $"[{string.Join(", ", this.Errors)} ]")}");
        }
    }
}