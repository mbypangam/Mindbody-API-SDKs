// <copyright file="MindbodyPublicApiDtoModelsV6ClassDescription.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassDescription.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassDescription
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassDescription"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassDescription()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassDescription"/> class.
        /// </summary>
        /// <param name="active">Active.</param>
        /// <param name="description">Description.</param>
        /// <param name="id">Id.</param>
        /// <param name="imageURL">ImageURL.</param>
        /// <param name="lastUpdated">LastUpdated.</param>
        /// <param name="level">Level.</param>
        /// <param name="name">Name.</param>
        /// <param name="notes">Notes.</param>
        /// <param name="prereq">Prereq.</param>
        /// <param name="program">Program.</param>
        /// <param name="sessionType">SessionType.</param>
        /// <param name="category">Category.</param>
        /// <param name="categoryId">CategoryId.</param>
        /// <param name="subcategory">Subcategory.</param>
        /// <param name="subcategoryId">SubcategoryId.</param>
        public MindbodyPublicApiDtoModelsV6ClassDescription(
            bool? active = null,
            string description = null,
            int? id = null,
            string imageURL = null,
            DateTime? lastUpdated = null,
            Models.MindbodyPublicApiDtoModelsV6Level level = null,
            string name = null,
            string notes = null,
            string prereq = null,
            Models.MindbodyPublicApiDtoModelsV6Program program = null,
            Models.MindbodyPublicApiDtoModelsV6SessionType sessionType = null,
            string category = null,
            int? categoryId = null,
            string subcategory = null,
            int? subcategoryId = null)
        {
            this.Active = active;
            this.Description = description;
            this.Id = id;
            this.ImageURL = imageURL;
            this.LastUpdated = lastUpdated;
            this.Level = level;
            this.Name = name;
            this.Notes = notes;
            this.Prereq = prereq;
            this.Program = program;
            this.SessionType = sessionType;
            this.Category = category;
            this.CategoryId = categoryId;
            this.Subcategory = subcategory;
            this.SubcategoryId = subcategoryId;
        }

        /// <summary>
        /// When `true`, indicates that the business can assign this class description to new class schedules.<br />
        /// When `false`, indicates that the business cannot assign this class description to new class schedules.
        /// </summary>
        [JsonProperty("Active", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Active { get; set; }

        /// <summary>
        /// The long version of the class description.
        /// </summary>
        [JsonProperty("Description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <summary>
        /// The class description's ID.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// The class description's image URL, if any. If it does not exist, nothing is returned.
        /// </summary>
        [JsonProperty("ImageURL", NullValueHandling = NullValueHandling.Ignore)]
        public string ImageURL { get; set; }

        /// <summary>
        /// The date this class description was last modified.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("LastUpdated", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? LastUpdated { get; set; }

        /// <summary>
        /// The level information about this class.
        /// </summary>
        [JsonProperty("Level", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6Level Level { get; set; }

        /// <summary>
        /// The name of this class description.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Any notes about the class description.
        /// </summary>
        [JsonProperty("Notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <summary>
        /// Any prerequisites for the class.
        /// </summary>
        [JsonProperty("Prereq", NullValueHandling = NullValueHandling.Ignore)]
        public string Prereq { get; set; }

        /// <summary>
        /// Contains information about the class description's program.
        /// </summary>
        [JsonProperty("Program", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6Program Program { get; set; }

        /// <summary>
        /// Contains information about the class description's session type.
        /// </summary>
        [JsonProperty("SessionType", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6SessionType SessionType { get; set; }

        /// <summary>
        /// The category of this class description.
        /// </summary>
        [JsonProperty("Category", NullValueHandling = NullValueHandling.Ignore)]
        public string Category { get; set; }

        /// <summary>
        /// The category ID of this class description.
        /// </summary>
        [JsonProperty("CategoryId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CategoryId { get; set; }

        /// <summary>
        /// The subcategory of this class description.
        /// </summary>
        [JsonProperty("Subcategory", NullValueHandling = NullValueHandling.Ignore)]
        public string Subcategory { get; set; }

        /// <summary>
        /// The subcategory ID of this class description.
        /// </summary>
        [JsonProperty("SubcategoryId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SubcategoryId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassDescription : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassDescription other &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.ImageURL == null && other.ImageURL == null) || (this.ImageURL?.Equals(other.ImageURL) == true)) &&
                ((this.LastUpdated == null && other.LastUpdated == null) || (this.LastUpdated?.Equals(other.LastUpdated) == true)) &&
                ((this.Level == null && other.Level == null) || (this.Level?.Equals(other.Level) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true)) &&
                ((this.Prereq == null && other.Prereq == null) || (this.Prereq?.Equals(other.Prereq) == true)) &&
                ((this.Program == null && other.Program == null) || (this.Program?.Equals(other.Program) == true)) &&
                ((this.SessionType == null && other.SessionType == null) || (this.SessionType?.Equals(other.SessionType) == true)) &&
                ((this.Category == null && other.Category == null) || (this.Category?.Equals(other.Category) == true)) &&
                ((this.CategoryId == null && other.CategoryId == null) || (this.CategoryId?.Equals(other.CategoryId) == true)) &&
                ((this.Subcategory == null && other.Subcategory == null) || (this.Subcategory?.Equals(other.Subcategory) == true)) &&
                ((this.SubcategoryId == null && other.SubcategoryId == null) || (this.SubcategoryId?.Equals(other.SubcategoryId) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active.ToString())}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.ImageURL = {(this.ImageURL == null ? "null" : this.ImageURL == string.Empty ? "" : this.ImageURL)}");
            toStringOutput.Add($"this.LastUpdated = {(this.LastUpdated == null ? "null" : this.LastUpdated.ToString())}");
            toStringOutput.Add($"this.Level = {(this.Level == null ? "null" : this.Level.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes == string.Empty ? "" : this.Notes)}");
            toStringOutput.Add($"this.Prereq = {(this.Prereq == null ? "null" : this.Prereq == string.Empty ? "" : this.Prereq)}");
            toStringOutput.Add($"this.Program = {(this.Program == null ? "null" : this.Program.ToString())}");
            toStringOutput.Add($"this.SessionType = {(this.SessionType == null ? "null" : this.SessionType.ToString())}");
            toStringOutput.Add($"this.Category = {(this.Category == null ? "null" : this.Category == string.Empty ? "" : this.Category)}");
            toStringOutput.Add($"this.CategoryId = {(this.CategoryId == null ? "null" : this.CategoryId.ToString())}");
            toStringOutput.Add($"this.Subcategory = {(this.Subcategory == null ? "null" : this.Subcategory == string.Empty ? "" : this.Subcategory)}");
            toStringOutput.Add($"this.SubcategoryId = {(this.SubcategoryId == null ? "null" : this.SubcategoryId.ToString())}");
        }
    }
}