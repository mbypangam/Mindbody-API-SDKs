// <copyright file="CreateReservationResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CreateReservationResponse.
    /// </summary>
    public class CreateReservationResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateReservationResponse"/> class.
        /// </summary>
        public CreateReservationResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateReservationResponse"/> class.
        /// </summary>
        /// <param name="reservation">Reservation.</param>
        /// <param name="responseDetails">ResponseDetails.</param>
        public CreateReservationResponse(
            Models.Reservation reservation = null,
            Models.ResponseDetails responseDetails = null)
        {
            this.Reservation = reservation;
            this.ResponseDetails = responseDetails;
        }

        /// <summary>
        /// Contains information about the reservation.
        /// </summary>
        [JsonProperty("Reservation", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Reservation Reservation { get; set; }

        /// <summary>
        /// Contains information about the response message detail.
        /// </summary>
        [JsonProperty("ResponseDetails", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseDetails ResponseDetails { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CreateReservationResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is CreateReservationResponse other &&
                ((this.Reservation == null && other.Reservation == null) || (this.Reservation?.Equals(other.Reservation) == true)) &&
                ((this.ResponseDetails == null && other.ResponseDetails == null) || (this.ResponseDetails?.Equals(other.ResponseDetails) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Reservation = {(this.Reservation == null ? "null" : this.Reservation.ToString())}");
            toStringOutput.Add($"this.ResponseDetails = {(this.ResponseDetails == null ? "null" : this.ResponseDetails.ToString())}");
        }
    }
}