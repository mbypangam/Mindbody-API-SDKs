// <copyright file="CheckoutShoppingCartRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// CheckoutShoppingCartRequest.
    /// </summary>
    public class CheckoutShoppingCartRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutShoppingCartRequest"/> class.
        /// </summary>
        public CheckoutShoppingCartRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutShoppingCartRequest"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="items">Items.</param>
        /// <param name="payments">Payments.</param>
        /// <param name="cartId">CartId.</param>
        /// <param name="payerClientId">PayerClientId.</param>
        /// <param name="test">Test.</param>
        /// <param name="inStore">InStore.</param>
        /// <param name="calculateTax">CalculateTax.</param>
        /// <param name="promotionCode">PromotionCode.</param>
        /// <param name="sendEmail">SendEmail.</param>
        /// <param name="locationId">LocationId.</param>
        /// <param name="image">Image.</param>
        /// <param name="imageFileName">ImageFileName.</param>
        /// <param name="consumerPresent">ConsumerPresent.</param>
        /// <param name="paymentAuthenticationCallbackUrl">PaymentAuthenticationCallbackUrl.</param>
        /// <param name="transactionIds">TransactionIds.</param>
        /// <param name="isBillingPostalCodeRequired">IsBillingPostalCodeRequired.</param>
        /// <param name="enforceLocationRestrictions">EnforceLocationRestrictions.</param>
        public CheckoutShoppingCartRequest(
            string clientId,
            List<Models.CheckoutItemWrapper> items,
            List<Models.CheckoutPaymentInfo> payments,
            string cartId = null,
            string payerClientId = null,
            bool? test = null,
            bool? inStore = null,
            bool? calculateTax = null,
            string promotionCode = null,
            bool? sendEmail = null,
            int? locationId = null,
            string image = null,
            string imageFileName = null,
            bool? consumerPresent = null,
            string paymentAuthenticationCallbackUrl = null,
            List<int> transactionIds = null,
            bool? isBillingPostalCodeRequired = null,
            bool? enforceLocationRestrictions = null)
        {
            this.CartId = cartId;
            this.ClientId = clientId;
            this.PayerClientId = payerClientId;
            this.Test = test;
            this.Items = items;
            this.InStore = inStore;
            this.CalculateTax = calculateTax;
            this.PromotionCode = promotionCode;
            this.Payments = payments;
            this.SendEmail = sendEmail;
            this.LocationId = locationId;
            this.Image = image;
            this.ImageFileName = imageFileName;
            this.ConsumerPresent = consumerPresent;
            this.PaymentAuthenticationCallbackUrl = paymentAuthenticationCallbackUrl;
            this.TransactionIds = transactionIds;
            this.IsBillingPostalCodeRequired = isBillingPostalCodeRequired;
            this.EnforceLocationRestrictions = enforceLocationRestrictions;
        }

        /// <summary>
        /// The unique ID of the shopping cart to be processed. You can use this value to maintain a persistent cart. If you do not specify a cart ID, the MINDBODY software generates one.
        /// </summary>
        [JsonProperty("CartId", NullValueHandling = NullValueHandling.Ignore)]
        public string CartId { get; set; }

        /// <summary>
        /// The RSSID of the client making the purchase. A cart can be validated without a client ID, but a client ID must be specified to complete a sale.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// The RSSID of the client paying for the purchase. This client needs to have a relationship of type "Pays for" with the client specified in the "ClientId" field.
        /// </summary>
        [JsonProperty("PayerClientId", NullValueHandling = NullValueHandling.Ignore)]
        public string PayerClientId { get; set; }

        /// <summary>
        /// When `true`, indicates that the contents of the cart are validated, but the transaction does not take place. You should use this parameter during testing and when checking the calculated totals of the items in the cart.<br />
        /// When `false`, the transaction takes place and the database is affected.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <summary>
        /// A list of the items in the cart.
        /// </summary>
        [JsonProperty("Items")]
        public List<Models.CheckoutItemWrapper> Items { get; set; }

        /// <summary>
        /// When `true`, indicates that the cart is to be completed by a staff member and is to take place at one of the business’ physical locations.<br />
        /// When `false`, indicates that the cart is to be completed by a client from the business’ online store.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("InStore", NullValueHandling = NullValueHandling.Ignore)]
        public bool? InStore { get; set; }

        /// <summary>
        /// When `true`, indicates that the tax should be calculated.
        /// When `false`, indicates that the tax should not be calculated.
        /// Default: **true**
        /// </summary>
        [JsonProperty("CalculateTax", NullValueHandling = NullValueHandling.Ignore)]
        public bool? CalculateTax { get; set; }

        /// <summary>
        /// Promotion code to be applied to the cart.
        /// </summary>
        [JsonProperty("PromotionCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PromotionCode { get; set; }

        /// <summary>
        /// A list of payment information objects to be applied to payment against the items in the cart.
        /// </summary>
        [JsonProperty("Payments")]
        public List<Models.CheckoutPaymentInfo> Payments { get; set; }

        /// <summary>
        /// When `true`, sends a purchase receipt email to the client. Note that all appropriate permissions and settings must be enabled for the client to receive an email.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("SendEmail", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendEmail { get; set; }

        /// <summary>
        /// The location ID to be used for pulling business mode prices and taxes. If no location ID is supplied, it defaults to the online store, represented by a null value.
        /// Default: **null** (the online store)
        /// </summary>
        [JsonProperty("LocationId", NullValueHandling = NullValueHandling.Ignore)]
        public int? LocationId { get; set; }

        /// <summary>
        /// The byte array data of the signature image.
        /// </summary>
        [JsonProperty("Image", NullValueHandling = NullValueHandling.Ignore)]
        public string Image { get; set; }

        /// <summary>
        /// The name of the signature image being uploaded.
        /// </summary>
        [JsonProperty("ImageFileName", NullValueHandling = NullValueHandling.Ignore)]
        public string ImageFileName { get; set; }

        /// <summary>
        /// When `true`, indicates that the consumer is present or otherwise able to successfully negotiate an SCA challenge. It is not a good idea to have this always be `false` as that could very likely lead to a bank declining all transactions for the merchant.
        /// Defaults to `false`.
        /// </summary>
        [JsonProperty("ConsumerPresent", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ConsumerPresent { get; set; }

        /// <summary>
        /// The URL consumer is redirected to if the bank requests SCA. This field is only needed if ConsumerPresent is `true`
        /// </summary>
        [JsonProperty("PaymentAuthenticationCallbackUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentAuthenticationCallbackUrl { get; set; }

        /// <summary>
        /// The list of TransactionIds provided with initial response containing SCA Challenge URLs for ConsumerPresent transactions
        /// </summary>
        [JsonProperty("TransactionIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> TransactionIds { get; set; }

        /// <summary>
        /// the flag to check billing post code is required or not.
        /// </summary>
        [JsonProperty("IsBillingPostalCodeRequired", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsBillingPostalCodeRequired { get; set; }

        /// <summary>
        /// When `true`, enforces "sell at" location restrictions on the cart items.
        /// When `false`, "sell at" location restrictions are not enforced.
        /// Default: **false**
        /// </summary>
        [JsonProperty("EnforceLocationRestrictions", NullValueHandling = NullValueHandling.Ignore)]
        public bool? EnforceLocationRestrictions { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CheckoutShoppingCartRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is CheckoutShoppingCartRequest other &&                ((this.CartId == null && other.CartId == null) || (this.CartId?.Equals(other.CartId) == true)) &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.PayerClientId == null && other.PayerClientId == null) || (this.PayerClientId?.Equals(other.PayerClientId) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true)) &&
                ((this.Items == null && other.Items == null) || (this.Items?.Equals(other.Items) == true)) &&
                ((this.InStore == null && other.InStore == null) || (this.InStore?.Equals(other.InStore) == true)) &&
                ((this.CalculateTax == null && other.CalculateTax == null) || (this.CalculateTax?.Equals(other.CalculateTax) == true)) &&
                ((this.PromotionCode == null && other.PromotionCode == null) || (this.PromotionCode?.Equals(other.PromotionCode) == true)) &&
                ((this.Payments == null && other.Payments == null) || (this.Payments?.Equals(other.Payments) == true)) &&
                ((this.SendEmail == null && other.SendEmail == null) || (this.SendEmail?.Equals(other.SendEmail) == true)) &&
                ((this.LocationId == null && other.LocationId == null) || (this.LocationId?.Equals(other.LocationId) == true)) &&
                ((this.Image == null && other.Image == null) || (this.Image?.Equals(other.Image) == true)) &&
                ((this.ImageFileName == null && other.ImageFileName == null) || (this.ImageFileName?.Equals(other.ImageFileName) == true)) &&
                ((this.ConsumerPresent == null && other.ConsumerPresent == null) || (this.ConsumerPresent?.Equals(other.ConsumerPresent) == true)) &&
                ((this.PaymentAuthenticationCallbackUrl == null && other.PaymentAuthenticationCallbackUrl == null) || (this.PaymentAuthenticationCallbackUrl?.Equals(other.PaymentAuthenticationCallbackUrl) == true)) &&
                ((this.TransactionIds == null && other.TransactionIds == null) || (this.TransactionIds?.Equals(other.TransactionIds) == true)) &&
                ((this.IsBillingPostalCodeRequired == null && other.IsBillingPostalCodeRequired == null) || (this.IsBillingPostalCodeRequired?.Equals(other.IsBillingPostalCodeRequired) == true)) &&
                ((this.EnforceLocationRestrictions == null && other.EnforceLocationRestrictions == null) || (this.EnforceLocationRestrictions?.Equals(other.EnforceLocationRestrictions) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CartId = {(this.CartId == null ? "null" : this.CartId)}");
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId)}");
            toStringOutput.Add($"this.PayerClientId = {(this.PayerClientId == null ? "null" : this.PayerClientId)}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
            toStringOutput.Add($"this.Items = {(this.Items == null ? "null" : $"[{string.Join(", ", this.Items)} ]")}");
            toStringOutput.Add($"this.InStore = {(this.InStore == null ? "null" : this.InStore.ToString())}");
            toStringOutput.Add($"this.CalculateTax = {(this.CalculateTax == null ? "null" : this.CalculateTax.ToString())}");
            toStringOutput.Add($"this.PromotionCode = {(this.PromotionCode == null ? "null" : this.PromotionCode)}");
            toStringOutput.Add($"this.Payments = {(this.Payments == null ? "null" : $"[{string.Join(", ", this.Payments)} ]")}");
            toStringOutput.Add($"this.SendEmail = {(this.SendEmail == null ? "null" : this.SendEmail.ToString())}");
            toStringOutput.Add($"this.LocationId = {(this.LocationId == null ? "null" : this.LocationId.ToString())}");
            toStringOutput.Add($"this.Image = {(this.Image == null ? "null" : this.Image)}");
            toStringOutput.Add($"this.ImageFileName = {(this.ImageFileName == null ? "null" : this.ImageFileName)}");
            toStringOutput.Add($"this.ConsumerPresent = {(this.ConsumerPresent == null ? "null" : this.ConsumerPresent.ToString())}");
            toStringOutput.Add($"this.PaymentAuthenticationCallbackUrl = {(this.PaymentAuthenticationCallbackUrl == null ? "null" : this.PaymentAuthenticationCallbackUrl)}");
            toStringOutput.Add($"this.TransactionIds = {(this.TransactionIds == null ? "null" : $"[{string.Join(", ", this.TransactionIds)} ]")}");
            toStringOutput.Add($"this.IsBillingPostalCodeRequired = {(this.IsBillingPostalCodeRequired == null ? "null" : this.IsBillingPostalCodeRequired.ToString())}");
            toStringOutput.Add($"this.EnforceLocationRestrictions = {(this.EnforceLocationRestrictions == null ? "null" : this.EnforceLocationRestrictions.ToString())}");
        }
    }
}