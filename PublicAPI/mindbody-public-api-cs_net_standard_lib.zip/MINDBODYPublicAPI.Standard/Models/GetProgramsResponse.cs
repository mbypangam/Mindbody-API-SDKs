// <copyright file="GetProgramsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetProgramsResponse.
    /// </summary>
    public class GetProgramsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetProgramsResponse"/> class.
        /// </summary>
        public GetProgramsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetProgramsResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="programs">Programs.</param>
        public GetProgramsResponse(
            Models.PaginationResponse paginationResponse = null,
            List<Models.MindbodyPublicApiDtoModelsV6Program> programs = null)
        {
            this.PaginationResponse = paginationResponse;
            this.Programs = programs;
        }

        /// <summary>
        /// Contains information about the pagination used.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// Contains information about the programs.
        /// </summary>
        [JsonProperty("Programs", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6Program> Programs { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetProgramsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetProgramsResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.Programs == null && other.Programs == null) || (this.Programs?.Equals(other.Programs) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.Programs = {(this.Programs == null ? "null" : $"[{string.Join(", ", this.Programs)} ]")}");
        }
    }
}