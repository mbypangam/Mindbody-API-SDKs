// <copyright file="MindbodyPublicApiDtoModelsV6ClientRelationship.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientRelationship.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientRelationship
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientRelationship"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientRelationship()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientRelationship"/> class.
        /// </summary>
        /// <param name="relatedClientId">RelatedClientId.</param>
        /// <param name="relationship">Relationship.</param>
        /// <param name="relationshipName">RelationshipName.</param>
        /// <param name="delete">Delete.</param>
        public MindbodyPublicApiDtoModelsV6ClientRelationship(
            string relatedClientId = null,
            Models.MindbodyPublicApiDtoModelsV6Relationship relationship = null,
            string relationshipName = null,
            bool? delete = null)
        {
            this.RelatedClientId = relatedClientId;
            this.Relationship = relationship;
            this.RelationshipName = relationshipName;
            this.Delete = delete;
        }

        /// <summary>
        /// The RSSID of the related client.
        /// </summary>
        [JsonProperty("RelatedClientId", NullValueHandling = NullValueHandling.Ignore)]
        public string RelatedClientId { get; set; }

        /// <summary>
        /// Jim is a RelationshipName1 of John. John is a RelationshipName2 of Jim.
        /// </summary>
        [JsonProperty("Relationship", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6Relationship Relationship { get; set; }

        /// <summary>
        /// The name of the relationship of the related client.
        /// </summary>
        [JsonProperty("RelationshipName", NullValueHandling = NullValueHandling.Ignore)]
        public string RelationshipName { get; set; }

        /// <summary>
        /// When true, this relationship is removed from the associated clients.
        /// </summary>
        [JsonProperty("Delete", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Delete { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientRelationship : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientRelationship other &&
                ((this.RelatedClientId == null && other.RelatedClientId == null) || (this.RelatedClientId?.Equals(other.RelatedClientId) == true)) &&
                ((this.Relationship == null && other.Relationship == null) || (this.Relationship?.Equals(other.Relationship) == true)) &&
                ((this.RelationshipName == null && other.RelationshipName == null) || (this.RelationshipName?.Equals(other.RelationshipName) == true)) &&
                ((this.Delete == null && other.Delete == null) || (this.Delete?.Equals(other.Delete) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RelatedClientId = {(this.RelatedClientId == null ? "null" : this.RelatedClientId == string.Empty ? "" : this.RelatedClientId)}");
            toStringOutput.Add($"this.Relationship = {(this.Relationship == null ? "null" : this.Relationship.ToString())}");
            toStringOutput.Add($"this.RelationshipName = {(this.RelationshipName == null ? "null" : this.RelationshipName == string.Empty ? "" : this.RelationshipName)}");
            toStringOutput.Add($"this.Delete = {(this.Delete == null ? "null" : this.Delete.ToString())}");
        }
    }
}