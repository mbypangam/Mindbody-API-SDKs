// <copyright file="CheckoutPaymentInfo.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CheckoutPaymentInfo.
    /// </summary>
    public class CheckoutPaymentInfo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutPaymentInfo"/> class.
        /// </summary>
        public CheckoutPaymentInfo()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutPaymentInfo"/> class.
        /// </summary>
        /// <param name="type">Type.</param>
        /// <param name="metadata">Metadata.</param>
        public CheckoutPaymentInfo(
            string type = null,
            object metadata = null)
        {
            this.Type = type;
            this.Metadata = metadata;
        }

        /// <summary>
        /// The type of payment. Possible values are:
        /// * CreditCard - Indicates that this payment item is a credit card.
        /// * StoredCard - Indicates that this payment item is a credit card stored on the client’s account.
        /// * EncryptedTrackData - Indicates that this payment item is a swiped credit card.
        /// * TrackData - Indicates that this payment item is a swiped credit card.
        /// * DebitAccount - Indicates that funds should be debited from the client’s account.
        /// * Custom - Indicates that this payment item is a custom payment method configured by the business.
        /// * Comp - Indicates that this payment item is making all or part of the cart’s total complementary.
        /// * Cash - Indicates that this payment item is cash.
        /// * Check - Indicates that this payment item is a check.
        /// * GiftCard - Indicates that this payment item is a gift card.
        /// </summary>
        [JsonProperty("Type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        /// <summary>
        /// Contains information about the cart’s payments. See [Payment Item Metadata](https://developers.mindbodyonline.com/PublicDocumentation/V6#payment-item-metadata) for more information.
        /// </summary>
        [JsonProperty("Metadata", NullValueHandling = NullValueHandling.Ignore)]
        public object Metadata { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CheckoutPaymentInfo : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is CheckoutPaymentInfo other &&                ((this.Type == null && other.Type == null) || (this.Type?.Equals(other.Type) == true)) &&
                ((this.Metadata == null && other.Metadata == null) || (this.Metadata?.Equals(other.Metadata) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Type = {(this.Type == null ? "null" : this.Type == string.Empty ? "" : this.Type)}");
            toStringOutput.Add($"Metadata = {(this.Metadata == null ? "null" : this.Metadata.ToString())}");
        }
    }
}