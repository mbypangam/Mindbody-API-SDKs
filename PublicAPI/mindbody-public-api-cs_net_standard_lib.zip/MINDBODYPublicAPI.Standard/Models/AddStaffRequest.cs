// <copyright file="AddStaffRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// AddStaffRequest.
    /// </summary>
    public class AddStaffRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddStaffRequest"/> class.
        /// </summary>
        public AddStaffRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddStaffRequest"/> class.
        /// </summary>
        /// <param name="firstName">FirstName.</param>
        /// <param name="lastName">LastName.</param>
        /// <param name="email">Email.</param>
        /// <param name="isMale">IsMale.</param>
        /// <param name="homePhone">HomePhone.</param>
        /// <param name="workPhone">WorkPhone.</param>
        /// <param name="mobilePhone">MobilePhone.</param>
        /// <param name="bio">Bio.</param>
        /// <param name="address">Address.</param>
        /// <param name="address2">Address2.</param>
        /// <param name="city">City.</param>
        /// <param name="state">State.</param>
        /// <param name="country">Country.</param>
        /// <param name="postalCode">PostalCode.</param>
        /// <param name="classAssistant">ClassAssistant.</param>
        /// <param name="classAssistant2">ClassAssistant2.</param>
        /// <param name="independentContractor">IndependentContractor.</param>
        /// <param name="appointmentInstructor">AppointmentInstructor.</param>
        /// <param name="alwaysAllowDoubleBooking">AlwaysAllowDoubleBooking.</param>
        /// <param name="classTeacher">ClassTeacher.</param>
        /// <param name="employmentStart">EmploymentStart.</param>
        /// <param name="employmentEnd">EmploymentEnd.</param>
        /// <param name="sortOrder">SortOrder.</param>
        /// <param name="providerIDs">ProviderIDs.</param>
        /// <param name="notes">Notes.</param>
        /// <param name="empID">EmpID.</param>
        public AddStaffRequest(
            string firstName,
            string lastName,
            string email = null,
            bool? isMale = null,
            string homePhone = null,
            string workPhone = null,
            string mobilePhone = null,
            string bio = null,
            string address = null,
            string address2 = null,
            string city = null,
            string state = null,
            string country = null,
            string postalCode = null,
            bool? classAssistant = null,
            bool? classAssistant2 = null,
            bool? independentContractor = null,
            bool? appointmentInstructor = null,
            bool? alwaysAllowDoubleBooking = null,
            bool? classTeacher = null,
            DateTime? employmentStart = null,
            DateTime? employmentEnd = null,
            int? sortOrder = null,
            List<string> providerIDs = null,
            string notes = null,
            string empID = null)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Email = email;
            this.IsMale = isMale;
            this.HomePhone = homePhone;
            this.WorkPhone = workPhone;
            this.MobilePhone = mobilePhone;
            this.Bio = bio;
            this.Address = address;
            this.Address2 = address2;
            this.City = city;
            this.State = state;
            this.Country = country;
            this.PostalCode = postalCode;
            this.ClassAssistant = classAssistant;
            this.ClassAssistant2 = classAssistant2;
            this.IndependentContractor = independentContractor;
            this.AppointmentInstructor = appointmentInstructor;
            this.AlwaysAllowDoubleBooking = alwaysAllowDoubleBooking;
            this.ClassTeacher = classTeacher;
            this.EmploymentStart = employmentStart;
            this.EmploymentEnd = employmentEnd;
            this.SortOrder = sortOrder;
            this.ProviderIDs = providerIDs;
            this.Notes = notes;
            this.EmpID = empID;
        }

        /// <summary>
        /// The staff member first name. You must specify a first name when you add a staff member.
        /// </summary>
        [JsonProperty("FirstName")]
        public string FirstName { get; set; }

        /// <summary>
        /// The staff member last name. You must specify a last name when you add a staff member.
        /// </summary>
        [JsonProperty("LastName")]
        public string LastName { get; set; }

        /// <summary>
        /// The staff member’s email address.
        /// </summary>
        [JsonProperty("Email", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        /// <summary>
        /// When `true`, indicates that the staff member is male.
        /// When `false`, indicates that the staff member is female.
        /// </summary>
        [JsonProperty("IsMale", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsMale { get; set; }

        /// <summary>
        /// The staff member’s home phone number.
        /// </summary>
        [JsonProperty("HomePhone", NullValueHandling = NullValueHandling.Ignore)]
        public string HomePhone { get; set; }

        /// <summary>
        /// The staff member’s work phone number.
        /// </summary>
        [JsonProperty("WorkPhone", NullValueHandling = NullValueHandling.Ignore)]
        public string WorkPhone { get; set; }

        /// <summary>
        /// The staff member’s mobile phone number.
        /// </summary>
        [JsonProperty("MobilePhone", NullValueHandling = NullValueHandling.Ignore)]
        public string MobilePhone { get; set; }

        /// <summary>
        /// The staff member’s biography. This string contains HTML.
        /// </summary>
        [JsonProperty("Bio", NullValueHandling = NullValueHandling.Ignore)]
        public string Bio { get; set; }

        /// <summary>
        /// The first line of the staff member street address.
        /// </summary>
        [JsonProperty("Address", NullValueHandling = NullValueHandling.Ignore)]
        public string Address { get; set; }

        /// <summary>
        /// The second line of the staff member street address, if needed.
        /// </summary>
        [JsonProperty("Address2", NullValueHandling = NullValueHandling.Ignore)]
        public string Address2 { get; set; }

        /// <summary>
        /// The staff member’s city.
        /// </summary>
        [JsonProperty("City", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// The staff member’s state.
        /// </summary>
        [JsonProperty("State", NullValueHandling = NullValueHandling.Ignore)]
        public string State { get; set; }

        /// <summary>
        /// The staff member’s country.
        /// </summary>
        [JsonProperty("Country", NullValueHandling = NullValueHandling.Ignore)]
        public string Country { get; set; }

        /// <summary>
        /// The staff member’s postal code.
        /// </summary>
        [JsonProperty("PostalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        /// <summary>
        /// Is the staff an assistant
        /// </summary>
        [JsonProperty("ClassAssistant", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ClassAssistant { get; set; }

        /// <summary>
        /// Is the staff an assistant2
        /// </summary>
        [JsonProperty("ClassAssistant2", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ClassAssistant2 { get; set; }

        /// <summary>
        /// When `true`, indicates that the staff member is an independent contractor.
        /// When `false`, indicates that the staff member is not an independent contractor.
        /// </summary>
        [JsonProperty("IndependentContractor", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IndependentContractor { get; set; }

        /// <summary>
        /// When `true`, indicates that the staff member offers appointments.<br />
        /// When `false`, indicates that the staff member does not offer appointments.
        /// </summary>
        [JsonProperty("AppointmentInstructor", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AppointmentInstructor { get; set; }

        /// <summary>
        /// When `true`, indicates that the staff member can be scheduled for overlapping services.<br />
        /// When `false`, indicates that the staff can only be scheduled for one service at a time in any given time-frame.
        /// </summary>
        [JsonProperty("AlwaysAllowDoubleBooking", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AlwaysAllowDoubleBooking { get; set; }

        /// <summary>
        /// When `true`, indicates that the staff member can teach classes.
        /// When `false`, indicates that the staff member cannot teach classes.
        /// </summary>
        [JsonProperty("ClassTeacher", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ClassTeacher { get; set; }

        /// <summary>
        /// The start date of employment
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EmploymentStart", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EmploymentStart { get; set; }

        /// <summary>
        /// The end date of employment
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EmploymentEnd", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EmploymentEnd { get; set; }

        /// <summary>
        /// If configured by the business owner, this field determines a staff member’s weight when sorting. Use this field to sort staff members on your interface.
        /// </summary>
        [JsonProperty("SortOrder", NullValueHandling = NullValueHandling.Ignore)]
        public int? SortOrder { get; set; }

        /// <summary>
        /// A list of providerIDs for the staff.  In the US it is one per staff and is numeric, otherwise it can be a list and is alpha-numeric
        /// for more information see <a href=" https://support.mindbodyonline.com/s/article/204075743-Provider-IDs?language=en_US" target="blank">Provider IDs</a>
        /// </summary>
        [JsonProperty("ProviderIDs", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> ProviderIDs { get; set; }

        /// <summary>
        /// The staff member private notes.
        /// </summary>
        [JsonProperty("Notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <summary>
        /// The custom staff ID assigned to the staff member.
        /// </summary>
        [JsonProperty("EmpID", NullValueHandling = NullValueHandling.Ignore)]
        public string EmpID { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddStaffRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddStaffRequest other &&                ((this.FirstName == null && other.FirstName == null) || (this.FirstName?.Equals(other.FirstName) == true)) &&
                ((this.LastName == null && other.LastName == null) || (this.LastName?.Equals(other.LastName) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.IsMale == null && other.IsMale == null) || (this.IsMale?.Equals(other.IsMale) == true)) &&
                ((this.HomePhone == null && other.HomePhone == null) || (this.HomePhone?.Equals(other.HomePhone) == true)) &&
                ((this.WorkPhone == null && other.WorkPhone == null) || (this.WorkPhone?.Equals(other.WorkPhone) == true)) &&
                ((this.MobilePhone == null && other.MobilePhone == null) || (this.MobilePhone?.Equals(other.MobilePhone) == true)) &&
                ((this.Bio == null && other.Bio == null) || (this.Bio?.Equals(other.Bio) == true)) &&
                ((this.Address == null && other.Address == null) || (this.Address?.Equals(other.Address) == true)) &&
                ((this.Address2 == null && other.Address2 == null) || (this.Address2?.Equals(other.Address2) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.State == null && other.State == null) || (this.State?.Equals(other.State) == true)) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.ClassAssistant == null && other.ClassAssistant == null) || (this.ClassAssistant?.Equals(other.ClassAssistant) == true)) &&
                ((this.ClassAssistant2 == null && other.ClassAssistant2 == null) || (this.ClassAssistant2?.Equals(other.ClassAssistant2) == true)) &&
                ((this.IndependentContractor == null && other.IndependentContractor == null) || (this.IndependentContractor?.Equals(other.IndependentContractor) == true)) &&
                ((this.AppointmentInstructor == null && other.AppointmentInstructor == null) || (this.AppointmentInstructor?.Equals(other.AppointmentInstructor) == true)) &&
                ((this.AlwaysAllowDoubleBooking == null && other.AlwaysAllowDoubleBooking == null) || (this.AlwaysAllowDoubleBooking?.Equals(other.AlwaysAllowDoubleBooking) == true)) &&
                ((this.ClassTeacher == null && other.ClassTeacher == null) || (this.ClassTeacher?.Equals(other.ClassTeacher) == true)) &&
                ((this.EmploymentStart == null && other.EmploymentStart == null) || (this.EmploymentStart?.Equals(other.EmploymentStart) == true)) &&
                ((this.EmploymentEnd == null && other.EmploymentEnd == null) || (this.EmploymentEnd?.Equals(other.EmploymentEnd) == true)) &&
                ((this.SortOrder == null && other.SortOrder == null) || (this.SortOrder?.Equals(other.SortOrder) == true)) &&
                ((this.ProviderIDs == null && other.ProviderIDs == null) || (this.ProviderIDs?.Equals(other.ProviderIDs) == true)) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true)) &&
                ((this.EmpID == null && other.EmpID == null) || (this.EmpID?.Equals(other.EmpID) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.FirstName = {(this.FirstName == null ? "null" : this.FirstName)}");
            toStringOutput.Add($"this.LastName = {(this.LastName == null ? "null" : this.LastName)}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email)}");
            toStringOutput.Add($"this.IsMale = {(this.IsMale == null ? "null" : this.IsMale.ToString())}");
            toStringOutput.Add($"this.HomePhone = {(this.HomePhone == null ? "null" : this.HomePhone)}");
            toStringOutput.Add($"this.WorkPhone = {(this.WorkPhone == null ? "null" : this.WorkPhone)}");
            toStringOutput.Add($"this.MobilePhone = {(this.MobilePhone == null ? "null" : this.MobilePhone)}");
            toStringOutput.Add($"this.Bio = {(this.Bio == null ? "null" : this.Bio)}");
            toStringOutput.Add($"this.Address = {(this.Address == null ? "null" : this.Address)}");
            toStringOutput.Add($"this.Address2 = {(this.Address2 == null ? "null" : this.Address2)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City)}");
            toStringOutput.Add($"this.State = {(this.State == null ? "null" : this.State)}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode)}");
            toStringOutput.Add($"this.ClassAssistant = {(this.ClassAssistant == null ? "null" : this.ClassAssistant.ToString())}");
            toStringOutput.Add($"this.ClassAssistant2 = {(this.ClassAssistant2 == null ? "null" : this.ClassAssistant2.ToString())}");
            toStringOutput.Add($"this.IndependentContractor = {(this.IndependentContractor == null ? "null" : this.IndependentContractor.ToString())}");
            toStringOutput.Add($"this.AppointmentInstructor = {(this.AppointmentInstructor == null ? "null" : this.AppointmentInstructor.ToString())}");
            toStringOutput.Add($"this.AlwaysAllowDoubleBooking = {(this.AlwaysAllowDoubleBooking == null ? "null" : this.AlwaysAllowDoubleBooking.ToString())}");
            toStringOutput.Add($"this.ClassTeacher = {(this.ClassTeacher == null ? "null" : this.ClassTeacher.ToString())}");
            toStringOutput.Add($"this.EmploymentStart = {(this.EmploymentStart == null ? "null" : this.EmploymentStart.ToString())}");
            toStringOutput.Add($"this.EmploymentEnd = {(this.EmploymentEnd == null ? "null" : this.EmploymentEnd.ToString())}");
            toStringOutput.Add($"this.SortOrder = {(this.SortOrder == null ? "null" : this.SortOrder.ToString())}");
            toStringOutput.Add($"this.ProviderIDs = {(this.ProviderIDs == null ? "null" : $"[{string.Join(", ", this.ProviderIDs)} ]")}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes)}");
            toStringOutput.Add($"this.EmpID = {(this.EmpID == null ? "null" : this.EmpID)}");
        }
    }
}