// <copyright file="GetPaymentTypesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetPaymentTypesResponse.
    /// </summary>
    public class GetPaymentTypesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetPaymentTypesResponse"/> class.
        /// </summary>
        public GetPaymentTypesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetPaymentTypesResponse"/> class.
        /// </summary>
        /// <param name="paymentTypes">PaymentTypes.</param>
        public GetPaymentTypesResponse(
            List<Models.PaymentType> paymentTypes = null)
        {
            this.PaymentTypes = paymentTypes;
        }

        /// <summary>
        /// The requested payment types.
        /// </summary>
        [JsonProperty("PaymentTypes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.PaymentType> PaymentTypes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetPaymentTypesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetPaymentTypesResponse other &&
                ((this.PaymentTypes == null && other.PaymentTypes == null) || (this.PaymentTypes?.Equals(other.PaymentTypes) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaymentTypes = {(this.PaymentTypes == null ? "null" : $"[{string.Join(", ", this.PaymentTypes)} ]")}");
        }
    }
}