// <copyright file="AddPromoCodeRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// AddPromoCodeRequest.
    /// </summary>
    public class AddPromoCodeRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddPromoCodeRequest"/> class.
        /// </summary>
        public AddPromoCodeRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddPromoCodeRequest"/> class.
        /// </summary>
        /// <param name="code">Code.</param>
        /// <param name="name">Name.</param>
        /// <param name="active">Active.</param>
        /// <param name="discount">Discount.</param>
        /// <param name="activationDate">ActivationDate.</param>
        /// <param name="expirationDate">ExpirationDate.</param>
        /// <param name="maxUses">MaxUses.</param>
        /// <param name="daysAfterCloseDate">DaysAfterCloseDate.</param>
        /// <param name="allowOnline">AllowOnline.</param>
        /// <param name="daysValid">DaysValid.</param>
        /// <param name="applicableItems">ApplicableItems.</param>
        public AddPromoCodeRequest(
            string code,
            string name,
            bool? active = null,
            Models.Discount discount = null,
            DateTime? activationDate = null,
            DateTime? expirationDate = null,
            int? maxUses = null,
            int? daysAfterCloseDate = null,
            bool? allowOnline = null,
            List<string> daysValid = null,
            List<Models.ApplicableItem> applicableItems = null)
        {
            this.Code = code;
            this.Name = name;
            this.Active = active;
            this.Discount = discount;
            this.ActivationDate = activationDate;
            this.ExpirationDate = expirationDate;
            this.MaxUses = maxUses;
            this.DaysAfterCloseDate = daysAfterCloseDate;
            this.AllowOnline = allowOnline;
            this.DaysValid = daysValid;
            this.ApplicableItems = applicableItems;
        }

        /// <summary>
        /// The code of the promocode.
        /// </summary>
        [JsonProperty("Code")]
        public string Code { get; set; }

        /// <summary>
        /// The name of the promocode.
        /// </summary>
        [JsonProperty("Name")]
        public string Name { get; set; }

        /// <summary>
        /// Indicates that promocode is active. Default: **true**
        /// </summary>
        [JsonProperty("Active", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Active { get; set; }

        /// <summary>
        /// Discount for a promo code
        /// </summary>
        [JsonProperty("Discount", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Discount Discount { get; set; }

        /// <summary>
        /// The date of the promocode activation. Default: **today’s date**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("ActivationDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ActivationDate { get; set; }

        /// <summary>
        /// The date of the promocode expiration. Default: **a months from today’s date**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("ExpirationDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ExpirationDate { get; set; }

        /// <summary>
        /// The maximun number of uses. A use is considered a single sale.
        /// </summary>
        [JsonProperty("MaxUses", NullValueHandling = NullValueHandling.Ignore)]
        public int? MaxUses { get; set; }

        /// <summary>
        /// The number of days a client has to use a promocode after they are no longer a prospect.
        /// </summary>
        [JsonProperty("DaysAfterCloseDate", NullValueHandling = NullValueHandling.Ignore)]
        public int? DaysAfterCloseDate { get; set; }

        /// <summary>
        /// Indicates if promocode can be redeemed online in consumer mode. Default: **false**
        /// </summary>
        [JsonProperty("AllowOnline", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AllowOnline { get; set; }

        /// <summary>
        /// Indicates what days of the week promocode is valid. Defaults to 7 days of the week. Possible values are:
        /// * Monday
        /// * Tuesday
        /// * Wednesday
        /// * Thursday
        /// * Friday
        /// * Saturday
        /// * Sunday
        /// </summary>
        [JsonProperty("DaysValid", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> DaysValid { get; set; }

        /// <summary>
        /// Contains information about a promocode applicable items.
        /// See ApplicableItems for a details of the `ApplicableItems` object.
        /// </summary>
        [JsonProperty("ApplicableItems", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ApplicableItem> ApplicableItems { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddPromoCodeRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddPromoCodeRequest other &&                ((this.Code == null && other.Code == null) || (this.Code?.Equals(other.Code) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true)) &&
                ((this.Discount == null && other.Discount == null) || (this.Discount?.Equals(other.Discount) == true)) &&
                ((this.ActivationDate == null && other.ActivationDate == null) || (this.ActivationDate?.Equals(other.ActivationDate) == true)) &&
                ((this.ExpirationDate == null && other.ExpirationDate == null) || (this.ExpirationDate?.Equals(other.ExpirationDate) == true)) &&
                ((this.MaxUses == null && other.MaxUses == null) || (this.MaxUses?.Equals(other.MaxUses) == true)) &&
                ((this.DaysAfterCloseDate == null && other.DaysAfterCloseDate == null) || (this.DaysAfterCloseDate?.Equals(other.DaysAfterCloseDate) == true)) &&
                ((this.AllowOnline == null && other.AllowOnline == null) || (this.AllowOnline?.Equals(other.AllowOnline) == true)) &&
                ((this.DaysValid == null && other.DaysValid == null) || (this.DaysValid?.Equals(other.DaysValid) == true)) &&
                ((this.ApplicableItems == null && other.ApplicableItems == null) || (this.ApplicableItems?.Equals(other.ApplicableItems) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Code = {(this.Code == null ? "null" : this.Code)}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name)}");
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active.ToString())}");
            toStringOutput.Add($"this.Discount = {(this.Discount == null ? "null" : this.Discount.ToString())}");
            toStringOutput.Add($"this.ActivationDate = {(this.ActivationDate == null ? "null" : this.ActivationDate.ToString())}");
            toStringOutput.Add($"this.ExpirationDate = {(this.ExpirationDate == null ? "null" : this.ExpirationDate.ToString())}");
            toStringOutput.Add($"this.MaxUses = {(this.MaxUses == null ? "null" : this.MaxUses.ToString())}");
            toStringOutput.Add($"this.DaysAfterCloseDate = {(this.DaysAfterCloseDate == null ? "null" : this.DaysAfterCloseDate.ToString())}");
            toStringOutput.Add($"this.AllowOnline = {(this.AllowOnline == null ? "null" : this.AllowOnline.ToString())}");
            toStringOutput.Add($"this.DaysValid = {(this.DaysValid == null ? "null" : $"[{string.Join(", ", this.DaysValid)} ]")}");
            toStringOutput.Add($"this.ApplicableItems = {(this.ApplicableItems == null ? "null" : $"[{string.Join(", ", this.ApplicableItems)} ]")}");
        }
    }
}