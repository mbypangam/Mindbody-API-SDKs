// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest"/> class.
        /// </summary>
        /// <param name="visitId">VisitId.</param>
        /// <param name="makeup">Makeup.</param>
        /// <param name="signedIn">SignedIn.</param>
        /// <param name="execute">Execute.</param>
        /// <param name="test">Test.</param>
        /// <param name="sendEmail">SendEmail.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest(
            int visitId,
            bool? makeup = null,
            bool? signedIn = null,
            string execute = null,
            bool? test = null,
            bool? sendEmail = null)
        {
            this.VisitId = visitId;
            this.Makeup = makeup;
            this.SignedIn = signedIn;
            this.Execute = execute;
            this.Test = test;
            this.SendEmail = sendEmail;
        }

        /// <summary>
        /// The ID of the visit to be updated.
        /// </summary>
        [JsonProperty("VisitId")]
        public int VisitId { get; set; }

        /// <summary>
        /// When `true`, indicates that the visit is eligible to be made up.
        /// </summary>
        [JsonProperty("Makeup", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Makeup { get; set; }

        /// <summary>
        /// When `true`, indicates that the client has signed in for the visit.
        /// </summary>
        [JsonProperty("SignedIn", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SignedIn { get; set; }

        /// <summary>
        /// The execute code used to update this visit. Possible values are:
        /// * Cancel
        /// * Latecancel
        /// * Unlatecancel
        /// </summary>
        [JsonProperty("Execute", NullValueHandling = NullValueHandling.Ignore)]
        public string Execute { get; set; }

        /// <summary>
        /// When `true`, indicates that test mode is enabled. When test mode is enabled, input information is validated, but not committed.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <summary>
        /// When `true`, indicates that the client should be sent an email for cancellations. Note that email is not sent unless the client has an email address and automatic emails have been set up correctly.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("SendEmail", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendEmail { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitRequest other &&
                this.VisitId.Equals(other.VisitId) &&
                ((this.Makeup == null && other.Makeup == null) || (this.Makeup?.Equals(other.Makeup) == true)) &&
                ((this.SignedIn == null && other.SignedIn == null) || (this.SignedIn?.Equals(other.SignedIn) == true)) &&
                ((this.Execute == null && other.Execute == null) || (this.Execute?.Equals(other.Execute) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true)) &&
                ((this.SendEmail == null && other.SendEmail == null) || (this.SendEmail?.Equals(other.SendEmail) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.VisitId = {this.VisitId}");
            toStringOutput.Add($"this.Makeup = {(this.Makeup == null ? "null" : this.Makeup.ToString())}");
            toStringOutput.Add($"this.SignedIn = {(this.SignedIn == null ? "null" : this.SignedIn.ToString())}");
            toStringOutput.Add($"this.Execute = {(this.Execute == null ? "null" : this.Execute == string.Empty ? "" : this.Execute)}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
            toStringOutput.Add($"this.SendEmail = {(this.SendEmail == null ? "null" : this.SendEmail.ToString())}");
        }
    }
}