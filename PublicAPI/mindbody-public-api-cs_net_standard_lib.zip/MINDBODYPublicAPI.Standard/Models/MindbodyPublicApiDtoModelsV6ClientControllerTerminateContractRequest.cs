// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="clientContractId">ClientContractId.</param>
        /// <param name="terminationDate">TerminationDate.</param>
        /// <param name="terminationCode">TerminationCode.</param>
        /// <param name="terminationComments">TerminationComments.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest(
            string clientId,
            int clientContractId,
            DateTime terminationDate,
            string terminationCode = null,
            string terminationComments = null)
        {
            this.ClientId = clientId;
            this.ClientContractId = clientContractId;
            this.TerminationDate = terminationDate;
            this.TerminationCode = terminationCode;
            this.TerminationComments = terminationComments;
        }

        /// <summary>
        /// The ID of the client.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// The unique ID of the sale of the contract
        /// </summary>
        [JsonProperty("ClientContractId")]
        public int ClientContractId { get; set; }

        /// <summary>
        /// The contract termination date.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("TerminationDate")]
        public DateTime TerminationDate { get; set; }

        /// <summary>
        /// ex. Illness, Injury, Moving, BreakingContract (Note this can be customized by each studio).
        /// </summary>
        [JsonProperty("TerminationCode", NullValueHandling = NullValueHandling.Ignore)]
        public string TerminationCode { get; set; }

        /// <summary>
        /// The comments for terminating a contract.
        /// </summary>
        [JsonProperty("TerminationComments", NullValueHandling = NullValueHandling.Ignore)]
        public string TerminationComments { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractRequest other &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                this.ClientContractId.Equals(other.ClientContractId) &&
                this.TerminationDate.Equals(other.TerminationDate) &&
                ((this.TerminationCode == null && other.TerminationCode == null) || (this.TerminationCode?.Equals(other.TerminationCode) == true)) &&
                ((this.TerminationComments == null && other.TerminationComments == null) || (this.TerminationComments?.Equals(other.TerminationComments) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.ClientContractId = {this.ClientContractId}");
            toStringOutput.Add($"this.TerminationDate = {this.TerminationDate}");
            toStringOutput.Add($"this.TerminationCode = {(this.TerminationCode == null ? "null" : this.TerminationCode == string.Empty ? "" : this.TerminationCode)}");
            toStringOutput.Add($"this.TerminationComments = {(this.TerminationComments == null ? "null" : this.TerminationComments == string.Empty ? "" : this.TerminationComments)}");
        }
    }
}