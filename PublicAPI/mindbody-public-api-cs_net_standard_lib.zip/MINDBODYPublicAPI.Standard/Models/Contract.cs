// <copyright file="Contract.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Contract.
    /// </summary>
    public class Contract
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Contract"/> class.
        /// </summary>
        public Contract()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Contract"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="name">Name.</param>
        /// <param name="description">Description.</param>
        /// <param name="assignsMembershipId">AssignsMembershipId.</param>
        /// <param name="assignsMembershipName">AssignsMembershipName.</param>
        /// <param name="soldOnline">SoldOnline.</param>
        /// <param name="contractItems">ContractItems.</param>
        /// <param name="introOffer">IntroOffer.</param>
        /// <param name="autopaySchedule">AutopaySchedule.</param>
        /// <param name="numberOfAutopays">NumberOfAutopays.</param>
        /// <param name="autopayTriggerType">AutopayTriggerType.</param>
        /// <param name="actionUponCompletionOfAutopays">ActionUponCompletionOfAutopays.</param>
        /// <param name="clientsChargedOn">ClientsChargedOn.</param>
        /// <param name="clientsChargedOnSpecificDate">ClientsChargedOnSpecificDate.</param>
        /// <param name="discountAmount">DiscountAmount.</param>
        /// <param name="depositAmount">DepositAmount.</param>
        /// <param name="firstAutopayFree">FirstAutopayFree.</param>
        /// <param name="lastAutopayFree">LastAutopayFree.</param>
        /// <param name="clientTerminateOnline">ClientTerminateOnline.</param>
        /// <param name="membershipTypeRestrictions">MembershipTypeRestrictions.</param>
        /// <param name="locationPurchaseRestrictionIds">LocationPurchaseRestrictionIds.</param>
        /// <param name="locationPurchaseRestrictionNames">LocationPurchaseRestrictionNames.</param>
        /// <param name="agreementTerms">AgreementTerms.</param>
        /// <param name="requiresElectronicConfirmation">RequiresElectronicConfirmation.</param>
        /// <param name="autopayEnabled">AutopayEnabled.</param>
        /// <param name="firstPaymentAmountSubtotal">FirstPaymentAmountSubtotal.</param>
        /// <param name="firstPaymentAmountTax">FirstPaymentAmountTax.</param>
        /// <param name="firstPaymentAmountTotal">FirstPaymentAmountTotal.</param>
        /// <param name="recurringPaymentAmountSubtotal">RecurringPaymentAmountSubtotal.</param>
        /// <param name="recurringPaymentAmountTax">RecurringPaymentAmountTax.</param>
        /// <param name="recurringPaymentAmountTotal">RecurringPaymentAmountTotal.</param>
        /// <param name="totalContractAmountSubtotal">TotalContractAmountSubtotal.</param>
        /// <param name="totalContractAmountTax">TotalContractAmountTax.</param>
        /// <param name="totalContractAmountTotal">TotalContractAmountTotal.</param>
        /// <param name="promoPaymentAmountSubtotal">PromoPaymentAmountSubtotal.</param>
        /// <param name="promoPaymentAmountTax">PromoPaymentAmountTax.</param>
        /// <param name="promoPaymentAmountTotal">PromoPaymentAmountTotal.</param>
        /// <param name="numberOfPromoAutopays">NumberOfPromoAutopays.</param>
        public Contract(
            int? id = null,
            string name = null,
            string description = null,
            int? assignsMembershipId = null,
            string assignsMembershipName = null,
            bool? soldOnline = null,
            List<Models.ContractItem> contractItems = null,
            string introOffer = null,
            Models.AutopaySchedule autopaySchedule = null,
            int? numberOfAutopays = null,
            string autopayTriggerType = null,
            string actionUponCompletionOfAutopays = null,
            string clientsChargedOn = null,
            DateTime? clientsChargedOnSpecificDate = null,
            double? discountAmount = null,
            double? depositAmount = null,
            bool? firstAutopayFree = null,
            bool? lastAutopayFree = null,
            bool? clientTerminateOnline = null,
            List<Models.MembershipTypeRestriction> membershipTypeRestrictions = null,
            List<int> locationPurchaseRestrictionIds = null,
            List<string> locationPurchaseRestrictionNames = null,
            string agreementTerms = null,
            bool? requiresElectronicConfirmation = null,
            bool? autopayEnabled = null,
            double? firstPaymentAmountSubtotal = null,
            double? firstPaymentAmountTax = null,
            double? firstPaymentAmountTotal = null,
            double? recurringPaymentAmountSubtotal = null,
            double? recurringPaymentAmountTax = null,
            double? recurringPaymentAmountTotal = null,
            double? totalContractAmountSubtotal = null,
            double? totalContractAmountTax = null,
            double? totalContractAmountTotal = null,
            double? promoPaymentAmountSubtotal = null,
            double? promoPaymentAmountTax = null,
            double? promoPaymentAmountTotal = null,
            int? numberOfPromoAutopays = null)
        {
            this.Id = id;
            this.Name = name;
            this.Description = description;
            this.AssignsMembershipId = assignsMembershipId;
            this.AssignsMembershipName = assignsMembershipName;
            this.SoldOnline = soldOnline;
            this.ContractItems = contractItems;
            this.IntroOffer = introOffer;
            this.AutopaySchedule = autopaySchedule;
            this.NumberOfAutopays = numberOfAutopays;
            this.AutopayTriggerType = autopayTriggerType;
            this.ActionUponCompletionOfAutopays = actionUponCompletionOfAutopays;
            this.ClientsChargedOn = clientsChargedOn;
            this.ClientsChargedOnSpecificDate = clientsChargedOnSpecificDate;
            this.DiscountAmount = discountAmount;
            this.DepositAmount = depositAmount;
            this.FirstAutopayFree = firstAutopayFree;
            this.LastAutopayFree = lastAutopayFree;
            this.ClientTerminateOnline = clientTerminateOnline;
            this.MembershipTypeRestrictions = membershipTypeRestrictions;
            this.LocationPurchaseRestrictionIds = locationPurchaseRestrictionIds;
            this.LocationPurchaseRestrictionNames = locationPurchaseRestrictionNames;
            this.AgreementTerms = agreementTerms;
            this.RequiresElectronicConfirmation = requiresElectronicConfirmation;
            this.AutopayEnabled = autopayEnabled;
            this.FirstPaymentAmountSubtotal = firstPaymentAmountSubtotal;
            this.FirstPaymentAmountTax = firstPaymentAmountTax;
            this.FirstPaymentAmountTotal = firstPaymentAmountTotal;
            this.RecurringPaymentAmountSubtotal = recurringPaymentAmountSubtotal;
            this.RecurringPaymentAmountTax = recurringPaymentAmountTax;
            this.RecurringPaymentAmountTotal = recurringPaymentAmountTotal;
            this.TotalContractAmountSubtotal = totalContractAmountSubtotal;
            this.TotalContractAmountTax = totalContractAmountTax;
            this.TotalContractAmountTotal = totalContractAmountTotal;
            this.PromoPaymentAmountSubtotal = promoPaymentAmountSubtotal;
            this.PromoPaymentAmountTax = promoPaymentAmountTax;
            this.PromoPaymentAmountTotal = promoPaymentAmountTotal;
            this.NumberOfPromoAutopays = numberOfPromoAutopays;
        }

        /// <summary>
        /// The contract’s ID at the subscriber’s business.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// The name of the contract.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// A description of the contract.
        /// </summary>
        [JsonProperty("Description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <summary>
        /// The ID of the membership that was assigned to the client when the client signed up for a contract.
        /// </summary>
        [JsonProperty("AssignsMembershipId", NullValueHandling = NullValueHandling.Ignore)]
        public int? AssignsMembershipId { get; set; }

        /// <summary>
        /// The name of the membership that was assigned to the client when the client signed up for this contract.
        /// </summary>
        [JsonProperty("AssignsMembershipName", NullValueHandling = NullValueHandling.Ignore)]
        public string AssignsMembershipName { get; set; }

        /// <summary>
        /// When `true`, indicates that this membership is intended to be shown to clients in client experiences.<br />
        /// When `false`, this contract should only be shown to staff members.
        /// </summary>
        [JsonProperty("SoldOnline", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SoldOnline { get; set; }

        /// <summary>
        /// Contains information about the items in the contract.
        /// </summary>
        [JsonProperty("ContractItems", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ContractItem> ContractItems { get; set; }

        /// <summary>
        /// Defines whether this contract is treated as an introductory offer. If this is an introductory offer, then clients are always charged a set number of times rather than month to month, using their AutoPays. Possible values are:
        /// * None
        /// * NewConsumer
        /// * NewAndReturningConsumer
        /// </summary>
        [JsonProperty("IntroOffer", NullValueHandling = NullValueHandling.Ignore)]
        public string IntroOffer { get; set; }

        /// <summary>
        /// Contains information about the AutoPay schedule. This parameter is null if `AutopayTriggerType` has a value of `PricingOptionRunsOutOrExpires`.
        /// </summary>
        [JsonProperty("AutopaySchedule", NullValueHandling = NullValueHandling.Ignore)]
        public Models.AutopaySchedule AutopaySchedule { get; set; }

        /// <summary>
        /// The number of times that the AutoPay is to be run. This value is null if `FrequencyType` is `MonthToMonth`.
        /// </summary>
        [JsonProperty("NumberOfAutopays", NullValueHandling = NullValueHandling.Ignore)]
        public int? NumberOfAutopays { get; set; }

        /// <summary>
        /// Defines whether the AutoPay, if applicable to this contract, runs on a set schedule or when the pricing option runs out or expires. Possible values are:
        /// * OnSetSchedule
        /// * PricingOptionRunsOutOrExpires
        /// </summary>
        [JsonProperty("AutopayTriggerType", NullValueHandling = NullValueHandling.Ignore)]
        public string AutopayTriggerType { get; set; }

        /// <summary>
        /// The renewal action to be taken when this AutoPay is completed. Possible values are:
        /// * ContractExpires
        /// * ContractAutomaticallyRenews
        /// </summary>
        [JsonProperty("ActionUponCompletionOfAutopays", NullValueHandling = NullValueHandling.Ignore)]
        public string ActionUponCompletionOfAutopays { get; set; }

        /// <summary>
        /// The value that indicates when clients are charged. Possible values are:
        /// * OnSaleDate
        /// * FirstOfTheMonth
        /// * FifteenthOfTheMonth
        /// * LastDayOfTheMonth
        /// * FirstOrFifteenthOfTheMonth
        /// * FirstOrSixteenthOfTheMonth
        /// * FifteenthOrEndOfTheMonth
        /// * SpecificDate
        /// </summary>
        [JsonProperty("ClientsChargedOn", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientsChargedOn { get; set; }

        /// <summary>
        /// If `ClientsChargedOn` is defined as a specific date, this property holds the value of that date. Otherwise, this property is null.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("ClientsChargedOnSpecificDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ClientsChargedOnSpecificDate { get; set; }

        /// <summary>
        /// The calculated discount applied to the items in this contract.
        /// </summary>
        [JsonProperty("DiscountAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? DiscountAmount { get; set; }

        /// <summary>
        /// The amount of the deposit required for this contract.
        /// </summary>
        [JsonProperty("DepositAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? DepositAmount { get; set; }

        /// <summary>
        /// When `true`, indicates that the first payment for the AutoPay is free.
        /// </summary>
        [JsonProperty("FirstAutopayFree", NullValueHandling = NullValueHandling.Ignore)]
        public bool? FirstAutopayFree { get; set; }

        /// <summary>
        /// When `true`, indicates that the last payment for the AutoPay is free.
        /// </summary>
        [JsonProperty("LastAutopayFree", NullValueHandling = NullValueHandling.Ignore)]
        public bool? LastAutopayFree { get; set; }

        /// <summary>
        /// When `true`, indicates that the client can terminate this contract on the Internet.
        /// </summary>
        [JsonProperty("ClientTerminateOnline", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ClientTerminateOnline { get; set; }

        /// <summary>
        /// Contains information about the memberships that can purchase this contract. If null, then no membership restrictions exist, and anyone can purchase the contract.
        /// </summary>
        [JsonProperty("MembershipTypeRestrictions", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MembershipTypeRestriction> MembershipTypeRestrictions { get; set; }

        /// <summary>
        /// The IDs of the locations where this contract may be sold. If there are no restrictions, this value is null.
        /// </summary>
        [JsonProperty("LocationPurchaseRestrictionIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> LocationPurchaseRestrictionIds { get; set; }

        /// <summary>
        /// Location names where the contract may be purchased. If this value is null, there are no restrictions.
        /// </summary>
        [JsonProperty("LocationPurchaseRestrictionNames", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> LocationPurchaseRestrictionNames { get; set; }

        /// <summary>
        /// Business-defined terms and conditions for the contract.
        /// </summary>
        [JsonProperty("AgreementTerms", NullValueHandling = NullValueHandling.Ignore)]
        public string AgreementTerms { get; set; }

        /// <summary>
        /// When `true`, clients who purchase the contract are prompted to agree to the terms of the contract the next time that they log in.
        /// </summary>
        [JsonProperty("RequiresElectronicConfirmation", NullValueHandling = NullValueHandling.Ignore)]
        public bool? RequiresElectronicConfirmation { get; set; }

        /// <summary>
        /// When `true`, this contract establishes an AutoPay on the client’s account.
        /// </summary>
        [JsonProperty("AutopayEnabled", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AutopayEnabled { get; set; }

        /// <summary>
        /// The subtotal of the amount that the client is to be charged when signing up for the contract.
        /// </summary>
        [JsonProperty("FirstPaymentAmountSubtotal", NullValueHandling = NullValueHandling.Ignore)]
        public double? FirstPaymentAmountSubtotal { get; set; }

        /// <summary>
        /// The amount of tax that the client is to be charged when signing up for the contract.
        /// </summary>
        [JsonProperty("FirstPaymentAmountTax", NullValueHandling = NullValueHandling.Ignore)]
        public double? FirstPaymentAmountTax { get; set; }

        /// <summary>
        /// The total amount that the client is to be charged when signing up for the contract.
        /// </summary>
        [JsonProperty("FirstPaymentAmountTotal", NullValueHandling = NullValueHandling.Ignore)]
        public double? FirstPaymentAmountTotal { get; set; }

        /// <summary>
        /// The subtotal amount that the client is to be charged on an ongoing basis.
        /// </summary>
        [JsonProperty("RecurringPaymentAmountSubtotal", NullValueHandling = NullValueHandling.Ignore)]
        public double? RecurringPaymentAmountSubtotal { get; set; }

        /// <summary>
        /// The amount of tax the client is to be charged on an ongoing basis.
        /// </summary>
        [JsonProperty("RecurringPaymentAmountTax", NullValueHandling = NullValueHandling.Ignore)]
        public double? RecurringPaymentAmountTax { get; set; }

        /// <summary>
        /// The total amount that the client is to be charged on an ongoing basis.
        /// </summary>
        [JsonProperty("RecurringPaymentAmountTotal", NullValueHandling = NullValueHandling.Ignore)]
        public double? RecurringPaymentAmountTotal { get; set; }

        /// <summary>
        /// The subtotal amount that the client is to be charged over the lifespan of the contract.
        /// </summary>
        [JsonProperty("TotalContractAmountSubtotal", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalContractAmountSubtotal { get; set; }

        /// <summary>
        /// The total amount of tax the client is to be charged over the lifespan of the contract.
        /// </summary>
        [JsonProperty("TotalContractAmountTax", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalContractAmountTax { get; set; }

        /// <summary>
        /// The total amount the client is to be charged over the lifespan of the contract.
        /// </summary>
        [JsonProperty("TotalContractAmountTotal", NullValueHandling = NullValueHandling.Ignore)]
        public double? TotalContractAmountTotal { get; set; }

        /// <summary>
        /// Subtotal promotional period
        /// </summary>
        [JsonProperty("PromoPaymentAmountSubtotal", NullValueHandling = NullValueHandling.Ignore)]
        public double? PromoPaymentAmountSubtotal { get; set; }

        /// <summary>
        /// Taxes of promotional period
        /// </summary>
        [JsonProperty("PromoPaymentAmountTax", NullValueHandling = NullValueHandling.Ignore)]
        public double? PromoPaymentAmountTax { get; set; }

        /// <summary>
        /// Total of promotional period
        /// </summary>
        [JsonProperty("PromoPaymentAmountTotal", NullValueHandling = NullValueHandling.Ignore)]
        public double? PromoPaymentAmountTotal { get; set; }

        /// <summary>
        /// Number of times that the AutoPay runs under the promotional period
        /// </summary>
        [JsonProperty("NumberOfPromoAutopays", NullValueHandling = NullValueHandling.Ignore)]
        public int? NumberOfPromoAutopays { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Contract : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Contract other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.AssignsMembershipId == null && other.AssignsMembershipId == null) || (this.AssignsMembershipId?.Equals(other.AssignsMembershipId) == true)) &&
                ((this.AssignsMembershipName == null && other.AssignsMembershipName == null) || (this.AssignsMembershipName?.Equals(other.AssignsMembershipName) == true)) &&
                ((this.SoldOnline == null && other.SoldOnline == null) || (this.SoldOnline?.Equals(other.SoldOnline) == true)) &&
                ((this.ContractItems == null && other.ContractItems == null) || (this.ContractItems?.Equals(other.ContractItems) == true)) &&
                ((this.IntroOffer == null && other.IntroOffer == null) || (this.IntroOffer?.Equals(other.IntroOffer) == true)) &&
                ((this.AutopaySchedule == null && other.AutopaySchedule == null) || (this.AutopaySchedule?.Equals(other.AutopaySchedule) == true)) &&
                ((this.NumberOfAutopays == null && other.NumberOfAutopays == null) || (this.NumberOfAutopays?.Equals(other.NumberOfAutopays) == true)) &&
                ((this.AutopayTriggerType == null && other.AutopayTriggerType == null) || (this.AutopayTriggerType?.Equals(other.AutopayTriggerType) == true)) &&
                ((this.ActionUponCompletionOfAutopays == null && other.ActionUponCompletionOfAutopays == null) || (this.ActionUponCompletionOfAutopays?.Equals(other.ActionUponCompletionOfAutopays) == true)) &&
                ((this.ClientsChargedOn == null && other.ClientsChargedOn == null) || (this.ClientsChargedOn?.Equals(other.ClientsChargedOn) == true)) &&
                ((this.ClientsChargedOnSpecificDate == null && other.ClientsChargedOnSpecificDate == null) || (this.ClientsChargedOnSpecificDate?.Equals(other.ClientsChargedOnSpecificDate) == true)) &&
                ((this.DiscountAmount == null && other.DiscountAmount == null) || (this.DiscountAmount?.Equals(other.DiscountAmount) == true)) &&
                ((this.DepositAmount == null && other.DepositAmount == null) || (this.DepositAmount?.Equals(other.DepositAmount) == true)) &&
                ((this.FirstAutopayFree == null && other.FirstAutopayFree == null) || (this.FirstAutopayFree?.Equals(other.FirstAutopayFree) == true)) &&
                ((this.LastAutopayFree == null && other.LastAutopayFree == null) || (this.LastAutopayFree?.Equals(other.LastAutopayFree) == true)) &&
                ((this.ClientTerminateOnline == null && other.ClientTerminateOnline == null) || (this.ClientTerminateOnline?.Equals(other.ClientTerminateOnline) == true)) &&
                ((this.MembershipTypeRestrictions == null && other.MembershipTypeRestrictions == null) || (this.MembershipTypeRestrictions?.Equals(other.MembershipTypeRestrictions) == true)) &&
                ((this.LocationPurchaseRestrictionIds == null && other.LocationPurchaseRestrictionIds == null) || (this.LocationPurchaseRestrictionIds?.Equals(other.LocationPurchaseRestrictionIds) == true)) &&
                ((this.LocationPurchaseRestrictionNames == null && other.LocationPurchaseRestrictionNames == null) || (this.LocationPurchaseRestrictionNames?.Equals(other.LocationPurchaseRestrictionNames) == true)) &&
                ((this.AgreementTerms == null && other.AgreementTerms == null) || (this.AgreementTerms?.Equals(other.AgreementTerms) == true)) &&
                ((this.RequiresElectronicConfirmation == null && other.RequiresElectronicConfirmation == null) || (this.RequiresElectronicConfirmation?.Equals(other.RequiresElectronicConfirmation) == true)) &&
                ((this.AutopayEnabled == null && other.AutopayEnabled == null) || (this.AutopayEnabled?.Equals(other.AutopayEnabled) == true)) &&
                ((this.FirstPaymentAmountSubtotal == null && other.FirstPaymentAmountSubtotal == null) || (this.FirstPaymentAmountSubtotal?.Equals(other.FirstPaymentAmountSubtotal) == true)) &&
                ((this.FirstPaymentAmountTax == null && other.FirstPaymentAmountTax == null) || (this.FirstPaymentAmountTax?.Equals(other.FirstPaymentAmountTax) == true)) &&
                ((this.FirstPaymentAmountTotal == null && other.FirstPaymentAmountTotal == null) || (this.FirstPaymentAmountTotal?.Equals(other.FirstPaymentAmountTotal) == true)) &&
                ((this.RecurringPaymentAmountSubtotal == null && other.RecurringPaymentAmountSubtotal == null) || (this.RecurringPaymentAmountSubtotal?.Equals(other.RecurringPaymentAmountSubtotal) == true)) &&
                ((this.RecurringPaymentAmountTax == null && other.RecurringPaymentAmountTax == null) || (this.RecurringPaymentAmountTax?.Equals(other.RecurringPaymentAmountTax) == true)) &&
                ((this.RecurringPaymentAmountTotal == null && other.RecurringPaymentAmountTotal == null) || (this.RecurringPaymentAmountTotal?.Equals(other.RecurringPaymentAmountTotal) == true)) &&
                ((this.TotalContractAmountSubtotal == null && other.TotalContractAmountSubtotal == null) || (this.TotalContractAmountSubtotal?.Equals(other.TotalContractAmountSubtotal) == true)) &&
                ((this.TotalContractAmountTax == null && other.TotalContractAmountTax == null) || (this.TotalContractAmountTax?.Equals(other.TotalContractAmountTax) == true)) &&
                ((this.TotalContractAmountTotal == null && other.TotalContractAmountTotal == null) || (this.TotalContractAmountTotal?.Equals(other.TotalContractAmountTotal) == true)) &&
                ((this.PromoPaymentAmountSubtotal == null && other.PromoPaymentAmountSubtotal == null) || (this.PromoPaymentAmountSubtotal?.Equals(other.PromoPaymentAmountSubtotal) == true)) &&
                ((this.PromoPaymentAmountTax == null && other.PromoPaymentAmountTax == null) || (this.PromoPaymentAmountTax?.Equals(other.PromoPaymentAmountTax) == true)) &&
                ((this.PromoPaymentAmountTotal == null && other.PromoPaymentAmountTotal == null) || (this.PromoPaymentAmountTotal?.Equals(other.PromoPaymentAmountTotal) == true)) &&
                ((this.NumberOfPromoAutopays == null && other.NumberOfPromoAutopays == null) || (this.NumberOfPromoAutopays?.Equals(other.NumberOfPromoAutopays) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.AssignsMembershipId = {(this.AssignsMembershipId == null ? "null" : this.AssignsMembershipId.ToString())}");
            toStringOutput.Add($"this.AssignsMembershipName = {(this.AssignsMembershipName == null ? "null" : this.AssignsMembershipName == string.Empty ? "" : this.AssignsMembershipName)}");
            toStringOutput.Add($"this.SoldOnline = {(this.SoldOnline == null ? "null" : this.SoldOnline.ToString())}");
            toStringOutput.Add($"this.ContractItems = {(this.ContractItems == null ? "null" : $"[{string.Join(", ", this.ContractItems)} ]")}");
            toStringOutput.Add($"this.IntroOffer = {(this.IntroOffer == null ? "null" : this.IntroOffer == string.Empty ? "" : this.IntroOffer)}");
            toStringOutput.Add($"this.AutopaySchedule = {(this.AutopaySchedule == null ? "null" : this.AutopaySchedule.ToString())}");
            toStringOutput.Add($"this.NumberOfAutopays = {(this.NumberOfAutopays == null ? "null" : this.NumberOfAutopays.ToString())}");
            toStringOutput.Add($"this.AutopayTriggerType = {(this.AutopayTriggerType == null ? "null" : this.AutopayTriggerType == string.Empty ? "" : this.AutopayTriggerType)}");
            toStringOutput.Add($"this.ActionUponCompletionOfAutopays = {(this.ActionUponCompletionOfAutopays == null ? "null" : this.ActionUponCompletionOfAutopays == string.Empty ? "" : this.ActionUponCompletionOfAutopays)}");
            toStringOutput.Add($"this.ClientsChargedOn = {(this.ClientsChargedOn == null ? "null" : this.ClientsChargedOn == string.Empty ? "" : this.ClientsChargedOn)}");
            toStringOutput.Add($"this.ClientsChargedOnSpecificDate = {(this.ClientsChargedOnSpecificDate == null ? "null" : this.ClientsChargedOnSpecificDate.ToString())}");
            toStringOutput.Add($"this.DiscountAmount = {(this.DiscountAmount == null ? "null" : this.DiscountAmount.ToString())}");
            toStringOutput.Add($"this.DepositAmount = {(this.DepositAmount == null ? "null" : this.DepositAmount.ToString())}");
            toStringOutput.Add($"this.FirstAutopayFree = {(this.FirstAutopayFree == null ? "null" : this.FirstAutopayFree.ToString())}");
            toStringOutput.Add($"this.LastAutopayFree = {(this.LastAutopayFree == null ? "null" : this.LastAutopayFree.ToString())}");
            toStringOutput.Add($"this.ClientTerminateOnline = {(this.ClientTerminateOnline == null ? "null" : this.ClientTerminateOnline.ToString())}");
            toStringOutput.Add($"this.MembershipTypeRestrictions = {(this.MembershipTypeRestrictions == null ? "null" : $"[{string.Join(", ", this.MembershipTypeRestrictions)} ]")}");
            toStringOutput.Add($"this.LocationPurchaseRestrictionIds = {(this.LocationPurchaseRestrictionIds == null ? "null" : $"[{string.Join(", ", this.LocationPurchaseRestrictionIds)} ]")}");
            toStringOutput.Add($"this.LocationPurchaseRestrictionNames = {(this.LocationPurchaseRestrictionNames == null ? "null" : $"[{string.Join(", ", this.LocationPurchaseRestrictionNames)} ]")}");
            toStringOutput.Add($"this.AgreementTerms = {(this.AgreementTerms == null ? "null" : this.AgreementTerms == string.Empty ? "" : this.AgreementTerms)}");
            toStringOutput.Add($"this.RequiresElectronicConfirmation = {(this.RequiresElectronicConfirmation == null ? "null" : this.RequiresElectronicConfirmation.ToString())}");
            toStringOutput.Add($"this.AutopayEnabled = {(this.AutopayEnabled == null ? "null" : this.AutopayEnabled.ToString())}");
            toStringOutput.Add($"this.FirstPaymentAmountSubtotal = {(this.FirstPaymentAmountSubtotal == null ? "null" : this.FirstPaymentAmountSubtotal.ToString())}");
            toStringOutput.Add($"this.FirstPaymentAmountTax = {(this.FirstPaymentAmountTax == null ? "null" : this.FirstPaymentAmountTax.ToString())}");
            toStringOutput.Add($"this.FirstPaymentAmountTotal = {(this.FirstPaymentAmountTotal == null ? "null" : this.FirstPaymentAmountTotal.ToString())}");
            toStringOutput.Add($"this.RecurringPaymentAmountSubtotal = {(this.RecurringPaymentAmountSubtotal == null ? "null" : this.RecurringPaymentAmountSubtotal.ToString())}");
            toStringOutput.Add($"this.RecurringPaymentAmountTax = {(this.RecurringPaymentAmountTax == null ? "null" : this.RecurringPaymentAmountTax.ToString())}");
            toStringOutput.Add($"this.RecurringPaymentAmountTotal = {(this.RecurringPaymentAmountTotal == null ? "null" : this.RecurringPaymentAmountTotal.ToString())}");
            toStringOutput.Add($"this.TotalContractAmountSubtotal = {(this.TotalContractAmountSubtotal == null ? "null" : this.TotalContractAmountSubtotal.ToString())}");
            toStringOutput.Add($"this.TotalContractAmountTax = {(this.TotalContractAmountTax == null ? "null" : this.TotalContractAmountTax.ToString())}");
            toStringOutput.Add($"this.TotalContractAmountTotal = {(this.TotalContractAmountTotal == null ? "null" : this.TotalContractAmountTotal.ToString())}");
            toStringOutput.Add($"this.PromoPaymentAmountSubtotal = {(this.PromoPaymentAmountSubtotal == null ? "null" : this.PromoPaymentAmountSubtotal.ToString())}");
            toStringOutput.Add($"this.PromoPaymentAmountTax = {(this.PromoPaymentAmountTax == null ? "null" : this.PromoPaymentAmountTax.ToString())}");
            toStringOutput.Add($"this.PromoPaymentAmountTotal = {(this.PromoPaymentAmountTotal == null ? "null" : this.PromoPaymentAmountTotal.ToString())}");
            toStringOutput.Add($"this.NumberOfPromoAutopays = {(this.NumberOfPromoAutopays == null ? "null" : this.NumberOfPromoAutopays.ToString())}");
        }
    }
}