// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse"/> class.
        /// </summary>
        /// <param name="clientIndexes">ClientIndexes.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse(
            List<Models.MindbodyPublicApiDtoModelsV6ClientIndex> clientIndexes = null)
        {
            this.ClientIndexes = clientIndexes;
        }

        /// <summary>
        /// Contains information about the client indexes.
        /// </summary>
        [JsonProperty("ClientIndexes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6ClientIndex> ClientIndexes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerGetClientIndexesResponse other &&
                ((this.ClientIndexes == null && other.ClientIndexes == null) || (this.ClientIndexes?.Equals(other.ClientIndexes) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientIndexes = {(this.ClientIndexes == null ? "null" : $"[{string.Join(", ", this.ClientIndexes)} ]")}");
        }
    }
}