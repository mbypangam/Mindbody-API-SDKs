// <copyright file="AddAppointmentAddOnRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AddAppointmentAddOnRequest.
    /// </summary>
    public class AddAppointmentAddOnRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddAppointmentAddOnRequest"/> class.
        /// </summary>
        public AddAppointmentAddOnRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddAppointmentAddOnRequest"/> class.
        /// </summary>
        /// <param name="applyPayment">ApplyPayment.</param>
        /// <param name="appointmentId">AppointmentId.</param>
        /// <param name="sessionTypeId">SessionTypeId.</param>
        /// <param name="staffId">StaffId.</param>
        /// <param name="test">Test.</param>
        public AddAppointmentAddOnRequest(
            bool? applyPayment = null,
            long? appointmentId = null,
            int? sessionTypeId = null,
            long? staffId = null,
            bool? test = null)
        {
            this.ApplyPayment = applyPayment;
            this.AppointmentId = appointmentId;
            this.SessionTypeId = sessionTypeId;
            this.StaffId = staffId;
            this.Test = test;
        }

        /// <summary>
        /// When `true`, indicates that a payment should be applied to the appointment. Currently only ApplyPayment=false is implemented.
        /// Default: **true**
        /// </summary>
        [JsonProperty("ApplyPayment", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ApplyPayment { get; set; }

        /// <summary>
        /// The appointment ID the add-on is getting added to.
        /// </summary>
        [JsonProperty("AppointmentId", NullValueHandling = NullValueHandling.Ignore)]
        public long? AppointmentId { get; set; }

        /// <summary>
        /// The session type associated with the new appointment add-on.
        /// </summary>
        [JsonProperty("SessionTypeId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SessionTypeId { get; set; }

        /// <summary>
        /// The ID of the staff member who is adding the new appointment add-on.
        /// Default: staff member performing the appointment.
        /// </summary>
        [JsonProperty("StaffId", NullValueHandling = NullValueHandling.Ignore)]
        public long? StaffId { get; set; }

        /// <summary>
        /// When `true`, indicates that the method is to be validated, but no new appointment add-on data is added.
        /// Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddAppointmentAddOnRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddAppointmentAddOnRequest other &&                ((this.ApplyPayment == null && other.ApplyPayment == null) || (this.ApplyPayment?.Equals(other.ApplyPayment) == true)) &&
                ((this.AppointmentId == null && other.AppointmentId == null) || (this.AppointmentId?.Equals(other.AppointmentId) == true)) &&
                ((this.SessionTypeId == null && other.SessionTypeId == null) || (this.SessionTypeId?.Equals(other.SessionTypeId) == true)) &&
                ((this.StaffId == null && other.StaffId == null) || (this.StaffId?.Equals(other.StaffId) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ApplyPayment = {(this.ApplyPayment == null ? "null" : this.ApplyPayment.ToString())}");
            toStringOutput.Add($"this.AppointmentId = {(this.AppointmentId == null ? "null" : this.AppointmentId.ToString())}");
            toStringOutput.Add($"this.SessionTypeId = {(this.SessionTypeId == null ? "null" : this.SessionTypeId.ToString())}");
            toStringOutput.Add($"this.StaffId = {(this.StaffId == null ? "null" : this.StaffId.ToString())}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
        }
    }
}