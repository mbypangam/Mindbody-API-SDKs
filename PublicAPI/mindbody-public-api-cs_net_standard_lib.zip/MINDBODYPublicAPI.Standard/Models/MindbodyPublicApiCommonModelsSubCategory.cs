// <copyright file="MindbodyPublicApiCommonModelsSubCategory.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiCommonModelsSubCategory.
    /// </summary>
    public class MindbodyPublicApiCommonModelsSubCategory
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsSubCategory"/> class.
        /// </summary>
        public MindbodyPublicApiCommonModelsSubCategory()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsSubCategory"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="subCategoryName">SubCategoryName.</param>
        /// <param name="active">Active.</param>
        public MindbodyPublicApiCommonModelsSubCategory(
            int? id = null,
            string subCategoryName = null,
            bool? active = null)
        {
            this.Id = id;
            this.SubCategoryName = subCategoryName;
            this.Active = active;
        }

        /// <summary>
        /// The Id of the subcategory.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// The name of the subcategory.
        /// </summary>
        [JsonProperty("SubCategoryName", NullValueHandling = NullValueHandling.Ignore)]
        public string SubCategoryName { get; set; }

        /// <summary>
        /// When `true`, indicates that the subcategory is active.
        /// </summary>
        [JsonProperty("Active", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Active { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiCommonModelsSubCategory : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiCommonModelsSubCategory other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.SubCategoryName == null && other.SubCategoryName == null) || (this.SubCategoryName?.Equals(other.SubCategoryName) == true)) &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.SubCategoryName = {(this.SubCategoryName == null ? "null" : this.SubCategoryName == string.Empty ? "" : this.SubCategoryName)}");
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active.ToString())}");
        }
    }
}