// <copyright file="GetTipsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetTipsResponse.
    /// </summary>
    public class GetTipsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetTipsResponse"/> class.
        /// </summary>
        public GetTipsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetTipsResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="tips">Tips.</param>
        public GetTipsResponse(
            Models.PaginationResponse paginationResponse = null,
            List<Models.MindbodyPublicApiDtoModelsV6Tip> tips = null)
        {
            this.PaginationResponse = paginationResponse;
            this.Tips = tips;
        }

        /// <summary>
        /// Contains information about the pagination used. See Pagination for a description of the Pagination information.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// Contains information about tips given to staff members within the given date range. Results are ordered by StaffId.
        /// </summary>
        [JsonProperty("Tips", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6Tip> Tips { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetTipsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetTipsResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.Tips == null && other.Tips == null) || (this.Tips?.Equals(other.Tips) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.Tips = {(this.Tips == null ? "null" : $"[{string.Join(", ", this.Tips)} ]")}");
        }
    }
}