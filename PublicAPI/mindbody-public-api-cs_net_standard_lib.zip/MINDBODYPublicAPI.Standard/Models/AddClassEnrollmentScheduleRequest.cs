// <copyright file="AddClassEnrollmentScheduleRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AddClassEnrollmentScheduleRequest.
    /// </summary>
    public class AddClassEnrollmentScheduleRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddClassEnrollmentScheduleRequest"/> class.
        /// </summary>
        public AddClassEnrollmentScheduleRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddClassEnrollmentScheduleRequest"/> class.
        /// </summary>
        /// <param name="classDescriptionId">ClassDescriptionId.</param>
        /// <param name="locationId">LocationId.</param>
        /// <param name="startDate">StartDate.</param>
        /// <param name="endDate">EndDate.</param>
        /// <param name="startTime">StartTime.</param>
        /// <param name="endTime">EndTime.</param>
        /// <param name="daySunday">DaySunday.</param>
        /// <param name="dayMonday">DayMonday.</param>
        /// <param name="dayTuesday">DayTuesday.</param>
        /// <param name="dayWednesday">DayWednesday.</param>
        /// <param name="dayThursday">DayThursday.</param>
        /// <param name="dayFriday">DayFriday.</param>
        /// <param name="daySaturday">DaySaturday.</param>
        /// <param name="staffId">StaffId.</param>
        /// <param name="staffPayRate">StaffPayRate.</param>
        /// <param name="resourceId">ResourceId.</param>
        /// <param name="maxCapacity">MaxCapacity.</param>
        /// <param name="webCapacity">WebCapacity.</param>
        /// <param name="waitlistCapacity">WaitlistCapacity.</param>
        /// <param name="bookingStatus">BookingStatus.</param>
        /// <param name="allowOpenEnrollment">AllowOpenEnrollment.</param>
        /// <param name="allowDateForwardEnrollment">AllowDateForwardEnrollment.</param>
        /// <param name="pricingOptionsProductIds">PricingOptionsProductIds.</param>
        public AddClassEnrollmentScheduleRequest(
            int? classDescriptionId = null,
            int? locationId = null,
            DateTime? startDate = null,
            DateTime? endDate = null,
            DateTime? startTime = null,
            DateTime? endTime = null,
            bool? daySunday = null,
            bool? dayMonday = null,
            bool? dayTuesday = null,
            bool? dayWednesday = null,
            bool? dayThursday = null,
            bool? dayFriday = null,
            bool? daySaturday = null,
            long? staffId = null,
            int? staffPayRate = null,
            int? resourceId = null,
            int? maxCapacity = null,
            int? webCapacity = null,
            int? waitlistCapacity = null,
            string bookingStatus = null,
            bool? allowOpenEnrollment = null,
            bool? allowDateForwardEnrollment = null,
            List<int> pricingOptionsProductIds = null)
        {
            this.ClassDescriptionId = classDescriptionId;
            this.LocationId = locationId;
            this.StartDate = startDate;
            this.EndDate = endDate;
            this.StartTime = startTime;
            this.EndTime = endTime;
            this.DaySunday = daySunday;
            this.DayMonday = dayMonday;
            this.DayTuesday = dayTuesday;
            this.DayWednesday = dayWednesday;
            this.DayThursday = dayThursday;
            this.DayFriday = dayFriday;
            this.DaySaturday = daySaturday;
            this.StaffId = staffId;
            this.StaffPayRate = staffPayRate;
            this.ResourceId = resourceId;
            this.MaxCapacity = maxCapacity;
            this.WebCapacity = webCapacity;
            this.WaitlistCapacity = waitlistCapacity;
            this.BookingStatus = bookingStatus;
            this.AllowOpenEnrollment = allowOpenEnrollment;
            this.AllowDateForwardEnrollment = allowDateForwardEnrollment;
            this.PricingOptionsProductIds = pricingOptionsProductIds;
        }

        /// <summary>
        /// The Id of the class/enrollment description. This can be found in GetClassDescriptions.
        /// </summary>
        [JsonProperty("ClassDescriptionId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ClassDescriptionId { get; set; }

        /// <summary>
        /// The Location Id of the enrollment schedule.
        /// </summary>
        [JsonProperty("LocationId", NullValueHandling = NullValueHandling.Ignore)]
        public int? LocationId { get; set; }

        /// <summary>
        /// The start date of the enrollment schedule.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// The end date of the enrollment schedule.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Enrollment start time (use null or omit for TBD).
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartTime { get; set; }

        /// <summary>
        /// Enrollment end time (ignored if StartTime is null or omitted).
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndTime { get; set; }

        /// <summary>
        /// If the enrollment occurs on Sunday(s).
        /// </summary>
        [JsonProperty("DaySunday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DaySunday { get; set; }

        /// <summary>
        /// If the enrollment occurs on Monday(s).
        /// </summary>
        [JsonProperty("DayMonday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DayMonday { get; set; }

        /// <summary>
        /// If the enrollment occurs on Tuesday(s).
        /// </summary>
        [JsonProperty("DayTuesday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DayTuesday { get; set; }

        /// <summary>
        /// If the enrollment occurs on Wednesday(s).
        /// </summary>
        [JsonProperty("DayWednesday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DayWednesday { get; set; }

        /// <summary>
        /// If the enrollment occurs on Thursday(s).
        /// </summary>
        [JsonProperty("DayThursday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DayThursday { get; set; }

        /// <summary>
        /// If the enrollment occurs on Friday(s).
        /// </summary>
        [JsonProperty("DayFriday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DayFriday { get; set; }

        /// <summary>
        /// If the enrollment occurs on Saturday(s).
        /// </summary>
        [JsonProperty("DaySaturday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DaySaturday { get; set; }

        /// <summary>
        /// The staff member teaching the enrollment.
        /// </summary>
        [JsonProperty("StaffId", NullValueHandling = NullValueHandling.Ignore)]
        public long? StaffId { get; set; }

        /// <summary>
        /// The staff pay rate. Must be between 1-21.
        /// </summary>
        [JsonProperty("StaffPayRate", NullValueHandling = NullValueHandling.Ignore)]
        public int? StaffPayRate { get; set; }

        /// <summary>
        /// The room where the enrollment is taking place.
        /// </summary>
        [JsonProperty("ResourceId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ResourceId { get; set; }

        /// <summary>
        /// How many people can attend.
        /// </summary>
        [JsonProperty("MaxCapacity", NullValueHandling = NullValueHandling.Ignore)]
        public int? MaxCapacity { get; set; }

        /// <summary>
        /// How many people can signup online.
        /// Default: **0**
        /// </summary>
        [JsonProperty("WebCapacity", NullValueHandling = NullValueHandling.Ignore)]
        public int? WebCapacity { get; set; }

        /// <summary>
        /// How many people can waitlist.
        /// Default:**0**
        /// </summary>
        [JsonProperty("WaitlistCapacity", NullValueHandling = NullValueHandling.Ignore)]
        public int? WaitlistCapacity { get; set; }

        /// <summary>
        /// One of: PaymentRequired, BookAndPayLater, Free
        /// </summary>
        [JsonProperty("BookingStatus", NullValueHandling = NullValueHandling.Ignore)]
        public string BookingStatus { get; set; }

        /// <summary>
        /// Allow clients to choose which sessions they’d like to sign up for.
        /// Default: **false**
        /// </summary>
        [JsonProperty("AllowOpenEnrollment", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AllowOpenEnrollment { get; set; }

        /// <summary>
        /// Allow booking after the enrollment has started.
        /// Default: **false**
        /// </summary>
        [JsonProperty("AllowDateForwardEnrollment", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AllowDateForwardEnrollment { get; set; }

        /// <summary>
        /// Pricing Options for this schedule
        /// </summary>
        [JsonProperty("PricingOptionsProductIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> PricingOptionsProductIds { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddClassEnrollmentScheduleRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AddClassEnrollmentScheduleRequest other &&
                ((this.ClassDescriptionId == null && other.ClassDescriptionId == null) || (this.ClassDescriptionId?.Equals(other.ClassDescriptionId) == true)) &&
                ((this.LocationId == null && other.LocationId == null) || (this.LocationId?.Equals(other.LocationId) == true)) &&
                ((this.StartDate == null && other.StartDate == null) || (this.StartDate?.Equals(other.StartDate) == true)) &&
                ((this.EndDate == null && other.EndDate == null) || (this.EndDate?.Equals(other.EndDate) == true)) &&
                ((this.StartTime == null && other.StartTime == null) || (this.StartTime?.Equals(other.StartTime) == true)) &&
                ((this.EndTime == null && other.EndTime == null) || (this.EndTime?.Equals(other.EndTime) == true)) &&
                ((this.DaySunday == null && other.DaySunday == null) || (this.DaySunday?.Equals(other.DaySunday) == true)) &&
                ((this.DayMonday == null && other.DayMonday == null) || (this.DayMonday?.Equals(other.DayMonday) == true)) &&
                ((this.DayTuesday == null && other.DayTuesday == null) || (this.DayTuesday?.Equals(other.DayTuesday) == true)) &&
                ((this.DayWednesday == null && other.DayWednesday == null) || (this.DayWednesday?.Equals(other.DayWednesday) == true)) &&
                ((this.DayThursday == null && other.DayThursday == null) || (this.DayThursday?.Equals(other.DayThursday) == true)) &&
                ((this.DayFriday == null && other.DayFriday == null) || (this.DayFriday?.Equals(other.DayFriday) == true)) &&
                ((this.DaySaturday == null && other.DaySaturday == null) || (this.DaySaturday?.Equals(other.DaySaturday) == true)) &&
                ((this.StaffId == null && other.StaffId == null) || (this.StaffId?.Equals(other.StaffId) == true)) &&
                ((this.StaffPayRate == null && other.StaffPayRate == null) || (this.StaffPayRate?.Equals(other.StaffPayRate) == true)) &&
                ((this.ResourceId == null && other.ResourceId == null) || (this.ResourceId?.Equals(other.ResourceId) == true)) &&
                ((this.MaxCapacity == null && other.MaxCapacity == null) || (this.MaxCapacity?.Equals(other.MaxCapacity) == true)) &&
                ((this.WebCapacity == null && other.WebCapacity == null) || (this.WebCapacity?.Equals(other.WebCapacity) == true)) &&
                ((this.WaitlistCapacity == null && other.WaitlistCapacity == null) || (this.WaitlistCapacity?.Equals(other.WaitlistCapacity) == true)) &&
                ((this.BookingStatus == null && other.BookingStatus == null) || (this.BookingStatus?.Equals(other.BookingStatus) == true)) &&
                ((this.AllowOpenEnrollment == null && other.AllowOpenEnrollment == null) || (this.AllowOpenEnrollment?.Equals(other.AllowOpenEnrollment) == true)) &&
                ((this.AllowDateForwardEnrollment == null && other.AllowDateForwardEnrollment == null) || (this.AllowDateForwardEnrollment?.Equals(other.AllowDateForwardEnrollment) == true)) &&
                ((this.PricingOptionsProductIds == null && other.PricingOptionsProductIds == null) || (this.PricingOptionsProductIds?.Equals(other.PricingOptionsProductIds) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClassDescriptionId = {(this.ClassDescriptionId == null ? "null" : this.ClassDescriptionId.ToString())}");
            toStringOutput.Add($"this.LocationId = {(this.LocationId == null ? "null" : this.LocationId.ToString())}");
            toStringOutput.Add($"this.StartDate = {(this.StartDate == null ? "null" : this.StartDate.ToString())}");
            toStringOutput.Add($"this.EndDate = {(this.EndDate == null ? "null" : this.EndDate.ToString())}");
            toStringOutput.Add($"this.StartTime = {(this.StartTime == null ? "null" : this.StartTime.ToString())}");
            toStringOutput.Add($"this.EndTime = {(this.EndTime == null ? "null" : this.EndTime.ToString())}");
            toStringOutput.Add($"this.DaySunday = {(this.DaySunday == null ? "null" : this.DaySunday.ToString())}");
            toStringOutput.Add($"this.DayMonday = {(this.DayMonday == null ? "null" : this.DayMonday.ToString())}");
            toStringOutput.Add($"this.DayTuesday = {(this.DayTuesday == null ? "null" : this.DayTuesday.ToString())}");
            toStringOutput.Add($"this.DayWednesday = {(this.DayWednesday == null ? "null" : this.DayWednesday.ToString())}");
            toStringOutput.Add($"this.DayThursday = {(this.DayThursday == null ? "null" : this.DayThursday.ToString())}");
            toStringOutput.Add($"this.DayFriday = {(this.DayFriday == null ? "null" : this.DayFriday.ToString())}");
            toStringOutput.Add($"this.DaySaturday = {(this.DaySaturday == null ? "null" : this.DaySaturday.ToString())}");
            toStringOutput.Add($"this.StaffId = {(this.StaffId == null ? "null" : this.StaffId.ToString())}");
            toStringOutput.Add($"this.StaffPayRate = {(this.StaffPayRate == null ? "null" : this.StaffPayRate.ToString())}");
            toStringOutput.Add($"this.ResourceId = {(this.ResourceId == null ? "null" : this.ResourceId.ToString())}");
            toStringOutput.Add($"this.MaxCapacity = {(this.MaxCapacity == null ? "null" : this.MaxCapacity.ToString())}");
            toStringOutput.Add($"this.WebCapacity = {(this.WebCapacity == null ? "null" : this.WebCapacity.ToString())}");
            toStringOutput.Add($"this.WaitlistCapacity = {(this.WaitlistCapacity == null ? "null" : this.WaitlistCapacity.ToString())}");
            toStringOutput.Add($"this.BookingStatus = {(this.BookingStatus == null ? "null" : this.BookingStatus == string.Empty ? "" : this.BookingStatus)}");
            toStringOutput.Add($"this.AllowOpenEnrollment = {(this.AllowOpenEnrollment == null ? "null" : this.AllowOpenEnrollment.ToString())}");
            toStringOutput.Add($"this.AllowDateForwardEnrollment = {(this.AllowDateForwardEnrollment == null ? "null" : this.AllowDateForwardEnrollment.ToString())}");
            toStringOutput.Add($"this.PricingOptionsProductIds = {(this.PricingOptionsProductIds == null ? "null" : $"[{string.Join(", ", this.PricingOptionsProductIds)} ]")}");
        }
    }
}