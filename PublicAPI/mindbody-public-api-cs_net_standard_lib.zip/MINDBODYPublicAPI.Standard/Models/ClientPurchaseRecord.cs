// <copyright file="ClientPurchaseRecord.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ClientPurchaseRecord.
    /// </summary>
    public class ClientPurchaseRecord
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClientPurchaseRecord"/> class.
        /// </summary>
        public ClientPurchaseRecord()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ClientPurchaseRecord"/> class.
        /// </summary>
        /// <param name="sale">Sale.</param>
        /// <param name="description">Description.</param>
        /// <param name="accountPayment">AccountPayment.</param>
        /// <param name="price">Price.</param>
        /// <param name="amountPaid">AmountPaid.</param>
        /// <param name="discount">Discount.</param>
        /// <param name="tax">Tax.</param>
        /// <param name="returned">Returned.</param>
        /// <param name="quantity">Quantity.</param>
        public ClientPurchaseRecord(
            Models.Sale sale = null,
            string description = null,
            bool? accountPayment = null,
            double? price = null,
            double? amountPaid = null,
            double? discount = null,
            double? tax = null,
            bool? returned = null,
            int? quantity = null)
        {
            this.Sale = sale;
            this.Description = description;
            this.AccountPayment = accountPayment;
            this.Price = price;
            this.AmountPaid = amountPaid;
            this.Discount = discount;
            this.Tax = tax;
            this.Returned = returned;
            this.Quantity = quantity;
        }

        /// <summary>
        /// Contains details about the sale and payment for a purchase event.
        /// </summary>
        [JsonProperty("Sale", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Sale Sale { get; set; }

        /// <summary>
        /// The item name and description.
        /// </summary>
        [JsonProperty("Description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <summary>
        /// If `true`, the item was a payment credited to an account.
        /// </summary>
        [JsonProperty("AccountPayment", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AccountPayment { get; set; }

        /// <summary>
        /// The price paid for the item.
        /// </summary>
        [JsonProperty("Price", NullValueHandling = NullValueHandling.Ignore)]
        public double? Price { get; set; }

        /// <summary>
        /// The amount paid for the item.
        /// </summary>
        [JsonProperty("AmountPaid", NullValueHandling = NullValueHandling.Ignore)]
        public double? AmountPaid { get; set; }

        /// <summary>
        /// The discount amount that was applied to the item.
        /// </summary>
        [JsonProperty("Discount", NullValueHandling = NullValueHandling.Ignore)]
        public double? Discount { get; set; }

        /// <summary>
        /// The amount of tax that was applied to the item.
        /// </summary>
        [JsonProperty("Tax", NullValueHandling = NullValueHandling.Ignore)]
        public double? Tax { get; set; }

        /// <summary>
        /// The return status of the item. If `true`, this item was returned.
        /// </summary>
        [JsonProperty("Returned", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Returned { get; set; }

        /// <summary>
        /// The quantity of the item purchased.
        /// </summary>
        [JsonProperty("Quantity", NullValueHandling = NullValueHandling.Ignore)]
        public int? Quantity { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ClientPurchaseRecord : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ClientPurchaseRecord other &&
                ((this.Sale == null && other.Sale == null) || (this.Sale?.Equals(other.Sale) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.AccountPayment == null && other.AccountPayment == null) || (this.AccountPayment?.Equals(other.AccountPayment) == true)) &&
                ((this.Price == null && other.Price == null) || (this.Price?.Equals(other.Price) == true)) &&
                ((this.AmountPaid == null && other.AmountPaid == null) || (this.AmountPaid?.Equals(other.AmountPaid) == true)) &&
                ((this.Discount == null && other.Discount == null) || (this.Discount?.Equals(other.Discount) == true)) &&
                ((this.Tax == null && other.Tax == null) || (this.Tax?.Equals(other.Tax) == true)) &&
                ((this.Returned == null && other.Returned == null) || (this.Returned?.Equals(other.Returned) == true)) &&
                ((this.Quantity == null && other.Quantity == null) || (this.Quantity?.Equals(other.Quantity) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Sale = {(this.Sale == null ? "null" : this.Sale.ToString())}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.AccountPayment = {(this.AccountPayment == null ? "null" : this.AccountPayment.ToString())}");
            toStringOutput.Add($"this.Price = {(this.Price == null ? "null" : this.Price.ToString())}");
            toStringOutput.Add($"this.AmountPaid = {(this.AmountPaid == null ? "null" : this.AmountPaid.ToString())}");
            toStringOutput.Add($"this.Discount = {(this.Discount == null ? "null" : this.Discount.ToString())}");
            toStringOutput.Add($"this.Tax = {(this.Tax == null ? "null" : this.Tax.ToString())}");
            toStringOutput.Add($"this.Returned = {(this.Returned == null ? "null" : this.Returned.ToString())}");
            toStringOutput.Add($"this.Quantity = {(this.Quantity == null ? "null" : this.Quantity.ToString())}");
        }
    }
}