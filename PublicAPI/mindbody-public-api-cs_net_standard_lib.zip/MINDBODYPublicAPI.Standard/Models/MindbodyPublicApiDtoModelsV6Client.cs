// <copyright file="MindbodyPublicApiDtoModelsV6Client.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6Client.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6Client
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6Client"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6Client()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6Client"/> class.
        /// </summary>
        /// <param name="appointmentGenderPreference">AppointmentGenderPreference.</param>
        /// <param name="birthDate">BirthDate.</param>
        /// <param name="country">Country.</param>
        /// <param name="creationDate">CreationDate.</param>
        /// <param name="customClientFields">CustomClientFields.</param>
        /// <param name="clientCreditCard">ClientCreditCard.</param>
        /// <param name="clientIndexes">ClientIndexes.</param>
        /// <param name="clientRelationships">ClientRelationships.</param>
        /// <param name="firstAppointmentDate">FirstAppointmentDate.</param>
        /// <param name="firstClassDate">FirstClassDate.</param>
        /// <param name="firstName">FirstName.</param>
        /// <param name="id">Id.</param>
        /// <param name="isCompany">IsCompany.</param>
        /// <param name="isProspect">IsProspect.</param>
        /// <param name="lastName">LastName.</param>
        /// <param name="liability">Liability.</param>
        /// <param name="liabilityRelease">LiabilityRelease.</param>
        /// <param name="membershipIcon">MembershipIcon.</param>
        /// <param name="mobileProvider">MobileProvider.</param>
        /// <param name="notes">Notes.</param>
        /// <param name="state">State.</param>
        /// <param name="uniqueId">UniqueId.</param>
        /// <param name="lastModifiedDateTime">LastModifiedDateTime.</param>
        /// <param name="redAlert">RedAlert.</param>
        /// <param name="yellowAlert">YellowAlert.</param>
        /// <param name="middleName">MiddleName.</param>
        /// <param name="prospectStage">ProspectStage.</param>
        /// <param name="email">Email.</param>
        /// <param name="mobilePhone">MobilePhone.</param>
        /// <param name="homePhone">HomePhone.</param>
        /// <param name="workPhone">WorkPhone.</param>
        /// <param name="accountBalance">AccountBalance.</param>
        /// <param name="addressLine1">AddressLine1.</param>
        /// <param name="addressLine2">AddressLine2.</param>
        /// <param name="city">City.</param>
        /// <param name="postalCode">PostalCode.</param>
        /// <param name="workExtension">WorkExtension.</param>
        /// <param name="referredBy">ReferredBy.</param>
        /// <param name="photoUrl">PhotoUrl.</param>
        /// <param name="emergencyContactInfoName">EmergencyContactInfoName.</param>
        /// <param name="emergencyContactInfoEmail">EmergencyContactInfoEmail.</param>
        /// <param name="emergencyContactInfoPhone">EmergencyContactInfoPhone.</param>
        /// <param name="emergencyContactInfoRelationship">EmergencyContactInfoRelationship.</param>
        /// <param name="gender">Gender.</param>
        /// <param name="lastFormulaNotes">LastFormulaNotes.</param>
        /// <param name="active">Active.</param>
        /// <param name="salesReps">SalesReps.</param>
        /// <param name="status">Status.</param>
        /// <param name="action">Action.</param>
        /// <param name="sendAccountEmails">SendAccountEmails.</param>
        /// <param name="sendAccountTexts">SendAccountTexts.</param>
        /// <param name="sendPromotionalEmails">SendPromotionalEmails.</param>
        /// <param name="sendPromotionalTexts">SendPromotionalTexts.</param>
        /// <param name="sendScheduleEmails">SendScheduleEmails.</param>
        /// <param name="sendScheduleTexts">SendScheduleTexts.</param>
        /// <param name="homeLocation">HomeLocation.</param>
        /// <param name="lockerNumber">LockerNumber.</param>
        public MindbodyPublicApiDtoModelsV6Client(
            Models.AppointmentGenderPreference1Enum? appointmentGenderPreference = null,
            DateTime? birthDate = null,
            string country = null,
            DateTime? creationDate = null,
            List<Models.MindbodyPublicApiDtoModelsV6CustomClientFieldValue> customClientFields = null,
            Models.MindbodyPublicApiDtoModelsV6ClientCreditCard clientCreditCard = null,
            List<Models.MindbodyPublicApiDtoModelsV6AssignedClientIndex> clientIndexes = null,
            List<Models.MindbodyPublicApiDtoModelsV6ClientRelationship> clientRelationships = null,
            DateTime? firstAppointmentDate = null,
            DateTime? firstClassDate = null,
            string firstName = null,
            string id = null,
            bool? isCompany = null,
            bool? isProspect = null,
            string lastName = null,
            Models.MindbodyPublicApiDtoModelsV6Liability liability = null,
            bool? liabilityRelease = null,
            int? membershipIcon = null,
            int? mobileProvider = null,
            string notes = null,
            string state = null,
            long? uniqueId = null,
            DateTime? lastModifiedDateTime = null,
            string redAlert = null,
            string yellowAlert = null,
            string middleName = null,
            Models.MindbodyPublicApiDtoModelsV6ProspectStage prospectStage = null,
            string email = null,
            string mobilePhone = null,
            string homePhone = null,
            string workPhone = null,
            double? accountBalance = null,
            string addressLine1 = null,
            string addressLine2 = null,
            string city = null,
            string postalCode = null,
            string workExtension = null,
            string referredBy = null,
            string photoUrl = null,
            string emergencyContactInfoName = null,
            string emergencyContactInfoEmail = null,
            string emergencyContactInfoPhone = null,
            string emergencyContactInfoRelationship = null,
            string gender = null,
            string lastFormulaNotes = null,
            bool? active = null,
            List<Models.MindbodyPublicApiDtoModelsV6SalesRep> salesReps = null,
            string status = null,
            Models.Action1Enum? action = null,
            bool? sendAccountEmails = null,
            bool? sendAccountTexts = null,
            bool? sendPromotionalEmails = null,
            bool? sendPromotionalTexts = null,
            bool? sendScheduleEmails = null,
            bool? sendScheduleTexts = null,
            Models.MindbodyPublicApiDtoModelsV6Location homeLocation = null,
            string lockerNumber = null)
        {
            this.AppointmentGenderPreference = appointmentGenderPreference;
            this.BirthDate = birthDate;
            this.Country = country;
            this.CreationDate = creationDate;
            this.CustomClientFields = customClientFields;
            this.ClientCreditCard = clientCreditCard;
            this.ClientIndexes = clientIndexes;
            this.ClientRelationships = clientRelationships;
            this.FirstAppointmentDate = firstAppointmentDate;
            this.FirstClassDate = firstClassDate;
            this.FirstName = firstName;
            this.Id = id;
            this.IsCompany = isCompany;
            this.IsProspect = isProspect;
            this.LastName = lastName;
            this.Liability = liability;
            this.LiabilityRelease = liabilityRelease;
            this.MembershipIcon = membershipIcon;
            this.MobileProvider = mobileProvider;
            this.Notes = notes;
            this.State = state;
            this.UniqueId = uniqueId;
            this.LastModifiedDateTime = lastModifiedDateTime;
            this.RedAlert = redAlert;
            this.YellowAlert = yellowAlert;
            this.MiddleName = middleName;
            this.ProspectStage = prospectStage;
            this.Email = email;
            this.MobilePhone = mobilePhone;
            this.HomePhone = homePhone;
            this.WorkPhone = workPhone;
            this.AccountBalance = accountBalance;
            this.AddressLine1 = addressLine1;
            this.AddressLine2 = addressLine2;
            this.City = city;
            this.PostalCode = postalCode;
            this.WorkExtension = workExtension;
            this.ReferredBy = referredBy;
            this.PhotoUrl = photoUrl;
            this.EmergencyContactInfoName = emergencyContactInfoName;
            this.EmergencyContactInfoEmail = emergencyContactInfoEmail;
            this.EmergencyContactInfoPhone = emergencyContactInfoPhone;
            this.EmergencyContactInfoRelationship = emergencyContactInfoRelationship;
            this.Gender = gender;
            this.LastFormulaNotes = lastFormulaNotes;
            this.Active = active;
            this.SalesReps = salesReps;
            this.Status = status;
            this.Action = action;
            this.SendAccountEmails = sendAccountEmails;
            this.SendAccountTexts = sendAccountTexts;
            this.SendPromotionalEmails = sendPromotionalEmails;
            this.SendPromotionalTexts = sendPromotionalTexts;
            this.SendScheduleEmails = sendScheduleEmails;
            this.SendScheduleTexts = sendScheduleTexts;
            this.HomeLocation = homeLocation;
            this.LockerNumber = lockerNumber;
        }

        /// <summary>
        /// The gender of staff member with whom the client prefers to book appointments.
        /// </summary>
        [JsonProperty("AppointmentGenderPreference", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.AppointmentGenderPreference1Enum? AppointmentGenderPreference { get; set; }

        /// <summary>
        /// The client’s date of birth.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("BirthDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? BirthDate { get; set; }

        /// <summary>
        /// The client’s country.
        /// </summary>
        [JsonProperty("Country", NullValueHandling = NullValueHandling.Ignore)]
        public string Country { get; set; }

        /// <summary>
        /// The date the client’s profile was created and added to the business, either by the client from the online store, or by a staff member. This value always returns in the format `yyyy-mm-ddThh:mm:ss:ms`.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("CreationDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? CreationDate { get; set; }

        /// <summary>
        /// Contains information about the custom client fields assigned to the client.
        /// </summary>
        [JsonProperty("CustomClientFields", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6CustomClientFieldValue> CustomClientFields { get; set; }

        /// <summary>
        /// Contains information about the client’s credit card.
        /// </summary>
        [JsonProperty("ClientCreditCard", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6ClientCreditCard ClientCreditCard { get; set; }

        /// <summary>
        /// Contains the IDs of the client’s assigned ClientIndexes and ClientIndexValues.
        /// If an index is already assigned to the client, it is overwritten with the passed index value. You cannot currently remove client indexes using the Public API. Only the indexes passed in the request are returned in the response.
        /// </summary>
        [JsonProperty("ClientIndexes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6AssignedClientIndex> ClientIndexes { get; set; }

        /// <summary>
        /// Contains information about the relationship between two clients.
        /// This parameter does not include all of the relationships assigned to the client, only the ones passed in the request.
        /// </summary>
        [JsonProperty("ClientRelationships", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6ClientRelationship> ClientRelationships { get; set; }

        /// <summary>
        /// The date of the client’s first booked appointment at the business.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("FirstAppointmentDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? FirstAppointmentDate { get; set; }

        /// <summary>
        /// The date of the clients first booked class at the business.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("FirstClassDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? FirstClassDate { get; set; }

        /// <summary>
        /// The client’s first name.
        /// </summary>
        [JsonProperty("FirstName", NullValueHandling = NullValueHandling.Ignore)]
        public string FirstName { get; set; }

        /// <summary>
        /// The client’s ID, as configured by the business owner. This is the client’s barcode ID if the business owner assigns barcodes to clients. This ID is used throughout the Public API for client-related Public API calls. When used in a POST `UpdateClient` request, the `Id` is used to identify the client for the update.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public string Id { get; set; }

        /// <summary>
        /// When `true`, indicates that the client should be marked as a company at the business.<br />
        /// When `false`, indicates the client is an individual and does not represent a company.
        /// </summary>
        [JsonProperty("IsCompany", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsCompany { get; set; }

        /// <summary>
        /// This value is set only if the business owner allows individuals to be prospects.<br />
        /// When `true`, indicates that the client should be marked as a prospect for the business.<br />
        /// When `false`, indicates that the client should not be marked as a prospect for the business.
        /// </summary>
        [JsonProperty("IsProspect", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsProspect { get; set; }

        /// <summary>
        /// The client’s last name.
        /// </summary>
        [JsonProperty("LastName", NullValueHandling = NullValueHandling.Ignore)]
        public string LastName { get; set; }

        /// <summary>
        /// Contains the client’s liability agreement information for the business.
        /// </summary>
        [JsonProperty("Liability", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6Liability Liability { get; set; }

        /// <summary>
        /// Passing `true` sets the client’s liability information as follows:
        /// * `IsReleased` is set to `true`.
        /// * `AgreementDate` is set to the time zone of the business when the call was processed.
        /// * `ReleasedBy` is set to `null` if the call is made by the client, `0` if the call was made by the business owner, or to a specific staff member’s ID if a staff member made the call.
        /// Passing `false` sets the client’s liability information as follows:
        /// * `IsReleased` is set to `false`.
        /// * `AgreementDate` is set to `null`.
        /// * `ReleasedBy` is set to `null`.
        /// </summary>
        [JsonProperty("LiabilityRelease", NullValueHandling = NullValueHandling.Ignore)]
        public bool? LiabilityRelease { get; set; }

        /// <summary>
        /// The ID of the [membership icon](https://support.mindbodyonline.com/s/article/203259703-Membership-Setup-screen?language=en_US) displayed next to the client’s name, if the client has a membership on their account.
        /// </summary>
        [JsonProperty("MembershipIcon", NullValueHandling = NullValueHandling.Ignore)]
        public int? MembershipIcon { get; set; }

        /// <summary>
        /// The client’s mobile provider.
        /// </summary>
        [JsonProperty("MobileProvider", NullValueHandling = NullValueHandling.Ignore)]
        public int? MobileProvider { get; set; }

        /// <summary>
        /// Any notes entered on the client’s account by staff members. This value should never be shown to clients unless the business owner has a specific reason for showing them.
        /// </summary>
        [JsonProperty("Notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <summary>
        /// The client’s state.
        /// </summary>
        [JsonProperty("State", NullValueHandling = NullValueHandling.Ignore)]
        public string State { get; set; }

        /// <summary>
        /// The client’s system-generated ID at the business. This value cannot be changed by business owners and is always unique across all clients at the business. This ID is not widely used in the Public API, but can be used by your application to uniquely identify clients.
        /// </summary>
        [JsonProperty("UniqueId", NullValueHandling = NullValueHandling.Ignore)]
        public long? UniqueId { get; set; }

        /// <summary>
        /// The UTC date and time when the client’s information was last modified.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("LastModifiedDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? LastModifiedDateTime { get; set; }

        /// <summary>
        /// Contains any red alert information entered by the business owner for the client.
        /// </summary>
        [JsonProperty("RedAlert", NullValueHandling = NullValueHandling.Ignore)]
        public string RedAlert { get; set; }

        /// <summary>
        /// Contains any yellow alert information entered by the business owner for the client.
        /// </summary>
        [JsonProperty("YellowAlert", NullValueHandling = NullValueHandling.Ignore)]
        public string YellowAlert { get; set; }

        /// <summary>
        /// The client’s middle name.
        /// </summary>
        [JsonProperty("MiddleName", NullValueHandling = NullValueHandling.Ignore)]
        public string MiddleName { get; set; }

        /// <summary>
        /// Contains information about the client [prospect stage](https://support.mindbodyonline.com/s/article/206176457-Prospect-Stages?language=en_US).
        /// </summary>
        [JsonProperty("ProspectStage", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6ProspectStage ProspectStage { get; set; }

        /// <summary>
        /// The client’s email address.
        /// </summary>
        [JsonProperty("Email", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        /// <summary>
        /// The client’s mobile phone number.
        /// </summary>
        [JsonProperty("MobilePhone", NullValueHandling = NullValueHandling.Ignore)]
        public string MobilePhone { get; set; }

        /// <summary>
        /// The client’s home phone number.
        /// </summary>
        [JsonProperty("HomePhone", NullValueHandling = NullValueHandling.Ignore)]
        public string HomePhone { get; set; }

        /// <summary>
        /// The client’s work phone number.
        /// </summary>
        [JsonProperty("WorkPhone", NullValueHandling = NullValueHandling.Ignore)]
        public string WorkPhone { get; set; }

        /// <summary>
        /// The client’s current [account balance](https://mindbody-online-support.force.com/support/s/article/203262013-Adding-account-payments-video-tutorial?language=en_US).
        /// </summary>
        [JsonProperty("AccountBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? AccountBalance { get; set; }

        /// <summary>
        /// The first line of the client’s street address.
        /// </summary>
        [JsonProperty("AddressLine1", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// The second line of the client’s street address, if needed.
        /// </summary>
        [JsonProperty("AddressLine2", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// The client’s city.
        /// </summary>
        [JsonProperty("City", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// The client’s postal code.
        /// </summary>
        [JsonProperty("PostalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        /// <summary>
        /// The client’s work phone extension number.
        /// </summary>
        [JsonProperty("WorkExtension", NullValueHandling = NullValueHandling.Ignore)]
        public string WorkExtension { get; set; }

        /// <summary>
        /// Specifies how the client was referred to the business. You can get a list of possible strings using the `GetClientReferralTypes` endpoint.
        /// </summary>
        [JsonProperty("ReferredBy", NullValueHandling = NullValueHandling.Ignore)]
        public string ReferredBy { get; set; }

        /// <summary>
        /// The URL of the client’s photo for the client profile.
        /// </summary>
        [JsonProperty("PhotoUrl", NullValueHandling = NullValueHandling.Ignore)]
        public string PhotoUrl { get; set; }

        /// <summary>
        /// The name of the client’s emergency contact.
        /// </summary>
        [JsonProperty("EmergencyContactInfoName", NullValueHandling = NullValueHandling.Ignore)]
        public string EmergencyContactInfoName { get; set; }

        /// <summary>
        /// The email address of the client’s emergency contact.
        /// </summary>
        [JsonProperty("EmergencyContactInfoEmail", NullValueHandling = NullValueHandling.Ignore)]
        public string EmergencyContactInfoEmail { get; set; }

        /// <summary>
        /// The phone number of the client’s emergency contact.
        /// </summary>
        [JsonProperty("EmergencyContactInfoPhone", NullValueHandling = NullValueHandling.Ignore)]
        public string EmergencyContactInfoPhone { get; set; }

        /// <summary>
        /// The client’s relationship with the emergency contact.
        /// </summary>
        [JsonProperty("EmergencyContactInfoRelationship", NullValueHandling = NullValueHandling.Ignore)]
        public string EmergencyContactInfoRelationship { get; set; }

        /// <summary>
        /// The gender of the client.
        /// </summary>
        [JsonProperty("Gender", NullValueHandling = NullValueHandling.Ignore)]
        public string Gender { get; set; }

        /// <summary>
        /// The last [formula note](https://support.mindbodyonline.com/s/article/203259903-Appointments-Formula-notes?language=en_US) entered for the client.
        /// </summary>
        [JsonProperty("LastFormulaNotes", NullValueHandling = NullValueHandling.Ignore)]
        public string LastFormulaNotes { get; set; }

        /// <summary>
        /// When `true`, indicates that the client’s profile is marked as active on the site.<br />
        /// When `false`, the client’s profile is inactive.
        /// Defaults to `true` based on the assumption that if a client is currently inactive OR is to be marked inactive, this property will explicitly be mapped/set to `false`.
        /// </summary>
        [JsonProperty("Active", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Active { get; set; }

        /// <summary>
        /// A list of sales representatives.
        /// </summary>
        [JsonProperty("SalesReps", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6SalesRep> SalesReps { get; set; }

        /// <summary>
        /// The status of the client in the business. Possible values are:
        /// * Declined
        /// * Non-Member
        /// * Active
        /// * Expired
        /// * Suspended
        /// * Terminated
        /// </summary>
        [JsonProperty("Status", NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; }

        /// <summary>
        /// The action taken.
        /// </summary>
        [JsonProperty("Action", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.Action1Enum? Action { get; set; }

        /// <summary>
        /// When `true`, indicates that the client has opted to receive general account notifications by email. This property is editable.
        /// <br />Default: **false**
        /// </summary>
        [JsonProperty("SendAccountEmails", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendAccountEmails { get; set; }

        /// <summary>
        /// When `true`, indicates that the client has opted to receive general account notifications by text message. This parameter cannot be updated by developers. If included in a request, it is ignored.
        /// </summary>
        [JsonProperty("SendAccountTexts", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendAccountTexts { get; set; }

        /// <summary>
        /// When `true`, indicates that the client has opted to receive promotional notifications by email. This property is editable.
        /// <br />Default: **false**
        /// </summary>
        [JsonProperty("SendPromotionalEmails", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendPromotionalEmails { get; set; }

        /// <summary>
        /// When `true`, indicates that the client has opted to receive promotional notifications by text message. This parameter cannot be updated by developers. If included in a request, it is ignored.
        /// </summary>
        [JsonProperty("SendPromotionalTexts", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendPromotionalTexts { get; set; }

        /// <summary>
        /// When `true`, indicates that the client has opted to receive schedule notifications by email. This property is editable.
        /// <br />Default: **false**
        /// </summary>
        [JsonProperty("SendScheduleEmails", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendScheduleEmails { get; set; }

        /// <summary>
        /// When `true`, indicates that the client has opted to receive schedule notifications by text message. This parameter cannot be updated by developers. If included in a request, it is ignored.
        /// </summary>
        [JsonProperty("SendScheduleTexts", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendScheduleTexts { get; set; }

        /// <summary>
        /// Information about the Home Location for this client
        /// </summary>
        [JsonProperty("HomeLocation", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6Location HomeLocation { get; set; }

        /// <summary>
        /// The clients locker number.
        /// </summary>
        [JsonProperty("LockerNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string LockerNumber { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6Client : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6Client other &&
                ((this.AppointmentGenderPreference == null && other.AppointmentGenderPreference == null) || (this.AppointmentGenderPreference?.Equals(other.AppointmentGenderPreference) == true)) &&
                ((this.BirthDate == null && other.BirthDate == null) || (this.BirthDate?.Equals(other.BirthDate) == true)) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.CreationDate == null && other.CreationDate == null) || (this.CreationDate?.Equals(other.CreationDate) == true)) &&
                ((this.CustomClientFields == null && other.CustomClientFields == null) || (this.CustomClientFields?.Equals(other.CustomClientFields) == true)) &&
                ((this.ClientCreditCard == null && other.ClientCreditCard == null) || (this.ClientCreditCard?.Equals(other.ClientCreditCard) == true)) &&
                ((this.ClientIndexes == null && other.ClientIndexes == null) || (this.ClientIndexes?.Equals(other.ClientIndexes) == true)) &&
                ((this.ClientRelationships == null && other.ClientRelationships == null) || (this.ClientRelationships?.Equals(other.ClientRelationships) == true)) &&
                ((this.FirstAppointmentDate == null && other.FirstAppointmentDate == null) || (this.FirstAppointmentDate?.Equals(other.FirstAppointmentDate) == true)) &&
                ((this.FirstClassDate == null && other.FirstClassDate == null) || (this.FirstClassDate?.Equals(other.FirstClassDate) == true)) &&
                ((this.FirstName == null && other.FirstName == null) || (this.FirstName?.Equals(other.FirstName) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.IsCompany == null && other.IsCompany == null) || (this.IsCompany?.Equals(other.IsCompany) == true)) &&
                ((this.IsProspect == null && other.IsProspect == null) || (this.IsProspect?.Equals(other.IsProspect) == true)) &&
                ((this.LastName == null && other.LastName == null) || (this.LastName?.Equals(other.LastName) == true)) &&
                ((this.Liability == null && other.Liability == null) || (this.Liability?.Equals(other.Liability) == true)) &&
                ((this.LiabilityRelease == null && other.LiabilityRelease == null) || (this.LiabilityRelease?.Equals(other.LiabilityRelease) == true)) &&
                ((this.MembershipIcon == null && other.MembershipIcon == null) || (this.MembershipIcon?.Equals(other.MembershipIcon) == true)) &&
                ((this.MobileProvider == null && other.MobileProvider == null) || (this.MobileProvider?.Equals(other.MobileProvider) == true)) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true)) &&
                ((this.State == null && other.State == null) || (this.State?.Equals(other.State) == true)) &&
                ((this.UniqueId == null && other.UniqueId == null) || (this.UniqueId?.Equals(other.UniqueId) == true)) &&
                ((this.LastModifiedDateTime == null && other.LastModifiedDateTime == null) || (this.LastModifiedDateTime?.Equals(other.LastModifiedDateTime) == true)) &&
                ((this.RedAlert == null && other.RedAlert == null) || (this.RedAlert?.Equals(other.RedAlert) == true)) &&
                ((this.YellowAlert == null && other.YellowAlert == null) || (this.YellowAlert?.Equals(other.YellowAlert) == true)) &&
                ((this.MiddleName == null && other.MiddleName == null) || (this.MiddleName?.Equals(other.MiddleName) == true)) &&
                ((this.ProspectStage == null && other.ProspectStage == null) || (this.ProspectStage?.Equals(other.ProspectStage) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.MobilePhone == null && other.MobilePhone == null) || (this.MobilePhone?.Equals(other.MobilePhone) == true)) &&
                ((this.HomePhone == null && other.HomePhone == null) || (this.HomePhone?.Equals(other.HomePhone) == true)) &&
                ((this.WorkPhone == null && other.WorkPhone == null) || (this.WorkPhone?.Equals(other.WorkPhone) == true)) &&
                ((this.AccountBalance == null && other.AccountBalance == null) || (this.AccountBalance?.Equals(other.AccountBalance) == true)) &&
                ((this.AddressLine1 == null && other.AddressLine1 == null) || (this.AddressLine1?.Equals(other.AddressLine1) == true)) &&
                ((this.AddressLine2 == null && other.AddressLine2 == null) || (this.AddressLine2?.Equals(other.AddressLine2) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.WorkExtension == null && other.WorkExtension == null) || (this.WorkExtension?.Equals(other.WorkExtension) == true)) &&
                ((this.ReferredBy == null && other.ReferredBy == null) || (this.ReferredBy?.Equals(other.ReferredBy) == true)) &&
                ((this.PhotoUrl == null && other.PhotoUrl == null) || (this.PhotoUrl?.Equals(other.PhotoUrl) == true)) &&
                ((this.EmergencyContactInfoName == null && other.EmergencyContactInfoName == null) || (this.EmergencyContactInfoName?.Equals(other.EmergencyContactInfoName) == true)) &&
                ((this.EmergencyContactInfoEmail == null && other.EmergencyContactInfoEmail == null) || (this.EmergencyContactInfoEmail?.Equals(other.EmergencyContactInfoEmail) == true)) &&
                ((this.EmergencyContactInfoPhone == null && other.EmergencyContactInfoPhone == null) || (this.EmergencyContactInfoPhone?.Equals(other.EmergencyContactInfoPhone) == true)) &&
                ((this.EmergencyContactInfoRelationship == null && other.EmergencyContactInfoRelationship == null) || (this.EmergencyContactInfoRelationship?.Equals(other.EmergencyContactInfoRelationship) == true)) &&
                ((this.Gender == null && other.Gender == null) || (this.Gender?.Equals(other.Gender) == true)) &&
                ((this.LastFormulaNotes == null && other.LastFormulaNotes == null) || (this.LastFormulaNotes?.Equals(other.LastFormulaNotes) == true)) &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true)) &&
                ((this.SalesReps == null && other.SalesReps == null) || (this.SalesReps?.Equals(other.SalesReps) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.Action == null && other.Action == null) || (this.Action?.Equals(other.Action) == true)) &&
                ((this.SendAccountEmails == null && other.SendAccountEmails == null) || (this.SendAccountEmails?.Equals(other.SendAccountEmails) == true)) &&
                ((this.SendAccountTexts == null && other.SendAccountTexts == null) || (this.SendAccountTexts?.Equals(other.SendAccountTexts) == true)) &&
                ((this.SendPromotionalEmails == null && other.SendPromotionalEmails == null) || (this.SendPromotionalEmails?.Equals(other.SendPromotionalEmails) == true)) &&
                ((this.SendPromotionalTexts == null && other.SendPromotionalTexts == null) || (this.SendPromotionalTexts?.Equals(other.SendPromotionalTexts) == true)) &&
                ((this.SendScheduleEmails == null && other.SendScheduleEmails == null) || (this.SendScheduleEmails?.Equals(other.SendScheduleEmails) == true)) &&
                ((this.SendScheduleTexts == null && other.SendScheduleTexts == null) || (this.SendScheduleTexts?.Equals(other.SendScheduleTexts) == true)) &&
                ((this.HomeLocation == null && other.HomeLocation == null) || (this.HomeLocation?.Equals(other.HomeLocation) == true)) &&
                ((this.LockerNumber == null && other.LockerNumber == null) || (this.LockerNumber?.Equals(other.LockerNumber) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AppointmentGenderPreference = {(this.AppointmentGenderPreference == null ? "null" : this.AppointmentGenderPreference.ToString())}");
            toStringOutput.Add($"this.BirthDate = {(this.BirthDate == null ? "null" : this.BirthDate.ToString())}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country == string.Empty ? "" : this.Country)}");
            toStringOutput.Add($"this.CreationDate = {(this.CreationDate == null ? "null" : this.CreationDate.ToString())}");
            toStringOutput.Add($"this.CustomClientFields = {(this.CustomClientFields == null ? "null" : $"[{string.Join(", ", this.CustomClientFields)} ]")}");
            toStringOutput.Add($"this.ClientCreditCard = {(this.ClientCreditCard == null ? "null" : this.ClientCreditCard.ToString())}");
            toStringOutput.Add($"this.ClientIndexes = {(this.ClientIndexes == null ? "null" : $"[{string.Join(", ", this.ClientIndexes)} ]")}");
            toStringOutput.Add($"this.ClientRelationships = {(this.ClientRelationships == null ? "null" : $"[{string.Join(", ", this.ClientRelationships)} ]")}");
            toStringOutput.Add($"this.FirstAppointmentDate = {(this.FirstAppointmentDate == null ? "null" : this.FirstAppointmentDate.ToString())}");
            toStringOutput.Add($"this.FirstClassDate = {(this.FirstClassDate == null ? "null" : this.FirstClassDate.ToString())}");
            toStringOutput.Add($"this.FirstName = {(this.FirstName == null ? "null" : this.FirstName == string.Empty ? "" : this.FirstName)}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id == string.Empty ? "" : this.Id)}");
            toStringOutput.Add($"this.IsCompany = {(this.IsCompany == null ? "null" : this.IsCompany.ToString())}");
            toStringOutput.Add($"this.IsProspect = {(this.IsProspect == null ? "null" : this.IsProspect.ToString())}");
            toStringOutput.Add($"this.LastName = {(this.LastName == null ? "null" : this.LastName == string.Empty ? "" : this.LastName)}");
            toStringOutput.Add($"this.Liability = {(this.Liability == null ? "null" : this.Liability.ToString())}");
            toStringOutput.Add($"this.LiabilityRelease = {(this.LiabilityRelease == null ? "null" : this.LiabilityRelease.ToString())}");
            toStringOutput.Add($"this.MembershipIcon = {(this.MembershipIcon == null ? "null" : this.MembershipIcon.ToString())}");
            toStringOutput.Add($"this.MobileProvider = {(this.MobileProvider == null ? "null" : this.MobileProvider.ToString())}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes == string.Empty ? "" : this.Notes)}");
            toStringOutput.Add($"this.State = {(this.State == null ? "null" : this.State == string.Empty ? "" : this.State)}");
            toStringOutput.Add($"this.UniqueId = {(this.UniqueId == null ? "null" : this.UniqueId.ToString())}");
            toStringOutput.Add($"this.LastModifiedDateTime = {(this.LastModifiedDateTime == null ? "null" : this.LastModifiedDateTime.ToString())}");
            toStringOutput.Add($"this.RedAlert = {(this.RedAlert == null ? "null" : this.RedAlert == string.Empty ? "" : this.RedAlert)}");
            toStringOutput.Add($"this.YellowAlert = {(this.YellowAlert == null ? "null" : this.YellowAlert == string.Empty ? "" : this.YellowAlert)}");
            toStringOutput.Add($"this.MiddleName = {(this.MiddleName == null ? "null" : this.MiddleName == string.Empty ? "" : this.MiddleName)}");
            toStringOutput.Add($"this.ProspectStage = {(this.ProspectStage == null ? "null" : this.ProspectStage.ToString())}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email == string.Empty ? "" : this.Email)}");
            toStringOutput.Add($"this.MobilePhone = {(this.MobilePhone == null ? "null" : this.MobilePhone == string.Empty ? "" : this.MobilePhone)}");
            toStringOutput.Add($"this.HomePhone = {(this.HomePhone == null ? "null" : this.HomePhone == string.Empty ? "" : this.HomePhone)}");
            toStringOutput.Add($"this.WorkPhone = {(this.WorkPhone == null ? "null" : this.WorkPhone == string.Empty ? "" : this.WorkPhone)}");
            toStringOutput.Add($"this.AccountBalance = {(this.AccountBalance == null ? "null" : this.AccountBalance.ToString())}");
            toStringOutput.Add($"this.AddressLine1 = {(this.AddressLine1 == null ? "null" : this.AddressLine1 == string.Empty ? "" : this.AddressLine1)}");
            toStringOutput.Add($"this.AddressLine2 = {(this.AddressLine2 == null ? "null" : this.AddressLine2 == string.Empty ? "" : this.AddressLine2)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
            toStringOutput.Add($"this.WorkExtension = {(this.WorkExtension == null ? "null" : this.WorkExtension == string.Empty ? "" : this.WorkExtension)}");
            toStringOutput.Add($"this.ReferredBy = {(this.ReferredBy == null ? "null" : this.ReferredBy == string.Empty ? "" : this.ReferredBy)}");
            toStringOutput.Add($"this.PhotoUrl = {(this.PhotoUrl == null ? "null" : this.PhotoUrl == string.Empty ? "" : this.PhotoUrl)}");
            toStringOutput.Add($"this.EmergencyContactInfoName = {(this.EmergencyContactInfoName == null ? "null" : this.EmergencyContactInfoName == string.Empty ? "" : this.EmergencyContactInfoName)}");
            toStringOutput.Add($"this.EmergencyContactInfoEmail = {(this.EmergencyContactInfoEmail == null ? "null" : this.EmergencyContactInfoEmail == string.Empty ? "" : this.EmergencyContactInfoEmail)}");
            toStringOutput.Add($"this.EmergencyContactInfoPhone = {(this.EmergencyContactInfoPhone == null ? "null" : this.EmergencyContactInfoPhone == string.Empty ? "" : this.EmergencyContactInfoPhone)}");
            toStringOutput.Add($"this.EmergencyContactInfoRelationship = {(this.EmergencyContactInfoRelationship == null ? "null" : this.EmergencyContactInfoRelationship == string.Empty ? "" : this.EmergencyContactInfoRelationship)}");
            toStringOutput.Add($"this.Gender = {(this.Gender == null ? "null" : this.Gender == string.Empty ? "" : this.Gender)}");
            toStringOutput.Add($"this.LastFormulaNotes = {(this.LastFormulaNotes == null ? "null" : this.LastFormulaNotes == string.Empty ? "" : this.LastFormulaNotes)}");
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active.ToString())}");
            toStringOutput.Add($"this.SalesReps = {(this.SalesReps == null ? "null" : $"[{string.Join(", ", this.SalesReps)} ]")}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status == string.Empty ? "" : this.Status)}");
            toStringOutput.Add($"this.Action = {(this.Action == null ? "null" : this.Action.ToString())}");
            toStringOutput.Add($"this.SendAccountEmails = {(this.SendAccountEmails == null ? "null" : this.SendAccountEmails.ToString())}");
            toStringOutput.Add($"this.SendAccountTexts = {(this.SendAccountTexts == null ? "null" : this.SendAccountTexts.ToString())}");
            toStringOutput.Add($"this.SendPromotionalEmails = {(this.SendPromotionalEmails == null ? "null" : this.SendPromotionalEmails.ToString())}");
            toStringOutput.Add($"this.SendPromotionalTexts = {(this.SendPromotionalTexts == null ? "null" : this.SendPromotionalTexts.ToString())}");
            toStringOutput.Add($"this.SendScheduleEmails = {(this.SendScheduleEmails == null ? "null" : this.SendScheduleEmails.ToString())}");
            toStringOutput.Add($"this.SendScheduleTexts = {(this.SendScheduleTexts == null ? "null" : this.SendScheduleTexts.ToString())}");
            toStringOutput.Add($"this.HomeLocation = {(this.HomeLocation == null ? "null" : this.HomeLocation.ToString())}");
            toStringOutput.Add($"this.LockerNumber = {(this.LockerNumber == null ? "null" : this.LockerNumber == string.Empty ? "" : this.LockerNumber)}");
        }
    }
}