// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest"/> class.
        /// </summary>
        /// <param name="bytes">Bytes.</param>
        /// <param name="clientId">ClientId.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest(
            string bytes,
            string clientId)
        {
            this.Bytes = bytes;
            this.ClientId = clientId;
        }

        /// <summary>
        /// A Base64-encoded string representation of the image's byte array.
        /// </summary>
        [JsonProperty("Bytes")]
        public string Bytes { get; set; }

        /// <summary>
        /// The RSSID of the client for whom the photo is to be uploaded.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerUploadClientPhotoRequest other &&
                ((this.Bytes == null && other.Bytes == null) || (this.Bytes?.Equals(other.Bytes) == true)) &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Bytes = {(this.Bytes == null ? "null" : this.Bytes == string.Empty ? "" : this.Bytes)}");
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
        }
    }
}