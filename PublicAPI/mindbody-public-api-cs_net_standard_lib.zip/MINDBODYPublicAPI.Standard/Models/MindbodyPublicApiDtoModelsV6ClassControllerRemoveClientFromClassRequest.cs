// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="classId">ClassId.</param>
        /// <param name="test">Test.</param>
        /// <param name="sendEmail">SendEmail.</param>
        /// <param name="lateCancel">LateCancel.</param>
        /// <param name="visitId">VisitId.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest(
            string clientId,
            int classId,
            bool? test = null,
            bool? sendEmail = null,
            bool? lateCancel = null,
            int? visitId = null)
        {
            this.ClientId = clientId;
            this.ClassId = classId;
            this.Test = test;
            this.SendEmail = sendEmail;
            this.LateCancel = lateCancel;
            this.VisitId = visitId;
        }

        /// <summary>
        /// The RSSID of the client to remove from the specified class.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// The ID of the class that you want to remove the client from.
        /// </summary>
        [JsonProperty("ClassId")]
        public int ClassId { get; set; }

        /// <summary>
        /// When `true`, the request ensures that its parameters are valid without affecting real data.<br />
        /// When `false`, the request performs as intended and may affect live client data.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <summary>
        /// When `true`, indicates that the client should be sent an email. Depending on the site and client settings, an email may or may not be sent.<br />
        /// Default: **false**
        /// Note: When the Authorization header is passed and the SendEmail is set to `true`, then an email will be sent.
        /// When the Authorization header is passed and the SendEmail is set to `false`, then an email will not be sent.
        /// When the Authorization header is not passed and the SendEmail is set to either `true` or `false`, then an email will not be sent.
        /// </summary>
        [JsonProperty("SendEmail", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendEmail { get; set; }

        /// <summary>
        /// When `true`, indicates that the client is to be late cancelled from the class.<br />
        /// When `false`, indicates that the client is to be early cancelled from the class.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("LateCancel", NullValueHandling = NullValueHandling.Ignore)]
        public bool? LateCancel { get; set; }

        /// <summary>
        /// The ID of the client visit that you want to remove from the class.
        /// Default: **0**
        /// </summary>
        [JsonProperty("VisitId", NullValueHandling = NullValueHandling.Ignore)]
        public int? VisitId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerRemoveClientFromClassRequest other &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                this.ClassId.Equals(other.ClassId) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true)) &&
                ((this.SendEmail == null && other.SendEmail == null) || (this.SendEmail?.Equals(other.SendEmail) == true)) &&
                ((this.LateCancel == null && other.LateCancel == null) || (this.LateCancel?.Equals(other.LateCancel) == true)) &&
                ((this.VisitId == null && other.VisitId == null) || (this.VisitId?.Equals(other.VisitId) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.ClassId = {this.ClassId}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
            toStringOutput.Add($"this.SendEmail = {(this.SendEmail == null ? "null" : this.SendEmail.ToString())}");
            toStringOutput.Add($"this.LateCancel = {(this.LateCancel == null ? "null" : this.LateCancel.ToString())}");
            toStringOutput.Add($"this.VisitId = {(this.VisitId == null ? "null" : this.VisitId.ToString())}");
        }
    }
}