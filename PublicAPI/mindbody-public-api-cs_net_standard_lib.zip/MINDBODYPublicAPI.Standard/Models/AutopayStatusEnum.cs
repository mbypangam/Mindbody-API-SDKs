// <copyright file="AutopayStatusEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AutopayStatusEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AutopayStatusEnum
    {
        /// <summary>
        /// Active.
        /// </summary>
        [EnumMember(Value = "Active")]
        Active,

        /// <summary>
        /// Inactive.
        /// </summary>
        [EnumMember(Value = "Inactive")]
        Inactive,

        /// <summary>
        /// Suspended.
        /// </summary>
        [EnumMember(Value = "Suspended")]
        Suspended
    }
}