// <copyright file="ClientRewardTransaction.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ClientRewardTransaction.
    /// </summary>
    public class ClientRewardTransaction
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClientRewardTransaction"/> class.
        /// </summary>
        public ClientRewardTransaction()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ClientRewardTransaction"/> class.
        /// </summary>
        /// <param name="actionDateTime">ActionDateTime.</param>
        /// <param name="action">Action.</param>
        /// <param name="source">Source.</param>
        /// <param name="sourceID">SourceID.</param>
        /// <param name="expirationDateTime">ExpirationDateTime.</param>
        /// <param name="points">Points.</param>
        public ClientRewardTransaction(
            DateTime? actionDateTime = null,
            Models.Action9Enum? action = null,
            string source = null,
            long? sourceID = null,
            DateTime? expirationDateTime = null,
            long? points = null)
        {
            this.ActionDateTime = actionDateTime;
            this.Action = action;
            this.Source = source;
            this.SourceID = sourceID;
            this.ExpirationDateTime = expirationDateTime;
            this.Points = points;
        }

        /// <summary>
        /// The date and time when the points were earned or redeemed in the site local time zone.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("ActionDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ActionDateTime { get; set; }

        /// <summary>
        /// Indicates if rewards were earned or redeemed.
        /// </summary>
        [JsonProperty("Action", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Action9Enum? Action { get; set; }

        /// <summary>
        /// The source of the reward transaction.
        /// </summary>
        [JsonProperty("Source", NullValueHandling = NullValueHandling.Ignore)]
        public string Source { get; set; }

        /// <summary>
        /// The unique identifier in the MINDBODY system for the **Source**.
        /// </summary>
        [JsonProperty("SourceID", NullValueHandling = NullValueHandling.Ignore)]
        public long? SourceID { get; set; }

        /// <summary>
        /// The date and time when earned points expire. This is calculated based on site and client rewards settings. This date will be in the site local time zone and may be **null**.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("ExpirationDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ExpirationDateTime { get; set; }

        /// <summary>
        /// The amount of points the client earned or redeemed.
        /// </summary>
        [JsonProperty("Points", NullValueHandling = NullValueHandling.Ignore)]
        public long? Points { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ClientRewardTransaction : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is ClientRewardTransaction other &&                ((this.ActionDateTime == null && other.ActionDateTime == null) || (this.ActionDateTime?.Equals(other.ActionDateTime) == true)) &&
                ((this.Action == null && other.Action == null) || (this.Action?.Equals(other.Action) == true)) &&
                ((this.Source == null && other.Source == null) || (this.Source?.Equals(other.Source) == true)) &&
                ((this.SourceID == null && other.SourceID == null) || (this.SourceID?.Equals(other.SourceID) == true)) &&
                ((this.ExpirationDateTime == null && other.ExpirationDateTime == null) || (this.ExpirationDateTime?.Equals(other.ExpirationDateTime) == true)) &&
                ((this.Points == null && other.Points == null) || (this.Points?.Equals(other.Points) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ActionDateTime = {(this.ActionDateTime == null ? "null" : this.ActionDateTime.ToString())}");
            toStringOutput.Add($"this.Action = {(this.Action == null ? "null" : this.Action.ToString())}");
            toStringOutput.Add($"this.Source = {(this.Source == null ? "null" : this.Source)}");
            toStringOutput.Add($"this.SourceID = {(this.SourceID == null ? "null" : this.SourceID.ToString())}");
            toStringOutput.Add($"this.ExpirationDateTime = {(this.ExpirationDateTime == null ? "null" : this.ExpirationDateTime.ToString())}");
            toStringOutput.Add($"this.Points = {(this.Points == null ? "null" : this.Points.ToString())}");
        }
    }
}