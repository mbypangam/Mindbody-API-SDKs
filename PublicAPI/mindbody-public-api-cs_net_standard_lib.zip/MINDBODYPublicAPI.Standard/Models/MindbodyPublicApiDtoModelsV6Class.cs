// <copyright file="MindbodyPublicApiDtoModelsV6Class.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6Class.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6Class
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6Class"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6Class()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6Class"/> class.
        /// </summary>
        /// <param name="classScheduleId">ClassScheduleId.</param>
        /// <param name="visits">Visits.</param>
        /// <param name="clients">Clients.</param>
        /// <param name="location">Location.</param>
        /// <param name="resource">Resource.</param>
        /// <param name="maxCapacity">MaxCapacity.</param>
        /// <param name="webCapacity">WebCapacity.</param>
        /// <param name="totalBooked">TotalBooked.</param>
        /// <param name="totalSignedIn">TotalSignedIn.</param>
        /// <param name="totalBookedWaitlist">TotalBookedWaitlist.</param>
        /// <param name="webBooked">WebBooked.</param>
        /// <param name="semesterId">SemesterId.</param>
        /// <param name="isCanceled">IsCanceled.</param>
        /// <param name="substitute">Substitute.</param>
        /// <param name="active">Active.</param>
        /// <param name="isWaitlistAvailable">IsWaitlistAvailable.</param>
        /// <param name="isEnrolled">IsEnrolled.</param>
        /// <param name="hideCancel">HideCancel.</param>
        /// <param name="id">Id.</param>
        /// <param name="isAvailable">IsAvailable.</param>
        /// <param name="startDateTime">StartDateTime.</param>
        /// <param name="endDateTime">EndDateTime.</param>
        /// <param name="lastModifiedDateTime">LastModifiedDateTime.</param>
        /// <param name="classDescription">ClassDescription.</param>
        /// <param name="staff">Staff.</param>
        /// <param name="bookingWindow">BookingWindow.</param>
        /// <param name="bookingStatus">BookingStatus.</param>
        /// <param name="virtualStreamLink">VirtualStreamLink.</param>
        public MindbodyPublicApiDtoModelsV6Class(
            int? classScheduleId = null,
            List<Models.MindbodyPublicApiDtoModelsV6Visit> visits = null,
            List<Models.MindbodyPublicApiDtoModelsV6Client> clients = null,
            Models.MindbodyPublicApiDtoModelsV6Location location = null,
            Models.MindbodyPublicApiDtoModelsV6Resource resource = null,
            int? maxCapacity = null,
            int? webCapacity = null,
            int? totalBooked = null,
            int? totalSignedIn = null,
            int? totalBookedWaitlist = null,
            int? webBooked = null,
            int? semesterId = null,
            bool? isCanceled = null,
            bool? substitute = null,
            bool? active = null,
            bool? isWaitlistAvailable = null,
            bool? isEnrolled = null,
            bool? hideCancel = null,
            int? id = null,
            bool? isAvailable = null,
            DateTime? startDateTime = null,
            DateTime? endDateTime = null,
            DateTime? lastModifiedDateTime = null,
            Models.MindbodyPublicApiDtoModelsV6ClassDescription classDescription = null,
            Models.MindbodyPublicApiDtoModelsV6Staff staff = null,
            Models.MindbodyPublicApiDtoModelsV6BookingWindow bookingWindow = null,
            Models.BookingStatusEnum? bookingStatus = null,
            string virtualStreamLink = null)
        {
            this.ClassScheduleId = classScheduleId;
            this.Visits = visits;
            this.Clients = clients;
            this.Location = location;
            this.Resource = resource;
            this.MaxCapacity = maxCapacity;
            this.WebCapacity = webCapacity;
            this.TotalBooked = totalBooked;
            this.TotalSignedIn = totalSignedIn;
            this.TotalBookedWaitlist = totalBookedWaitlist;
            this.WebBooked = webBooked;
            this.SemesterId = semesterId;
            this.IsCanceled = isCanceled;
            this.Substitute = substitute;
            this.Active = active;
            this.IsWaitlistAvailable = isWaitlistAvailable;
            this.IsEnrolled = isEnrolled;
            this.HideCancel = hideCancel;
            this.Id = id;
            this.IsAvailable = isAvailable;
            this.StartDateTime = startDateTime;
            this.EndDateTime = endDateTime;
            this.LastModifiedDateTime = lastModifiedDateTime;
            this.ClassDescription = classDescription;
            this.Staff = staff;
            this.BookingWindow = bookingWindow;
            this.BookingStatus = bookingStatus;
            this.VirtualStreamLink = virtualStreamLink;
        }

        /// <summary>
        /// The ID used to retrieve the class schedule for the desired class.
        /// </summary>
        [JsonProperty("ClassScheduleId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ClassScheduleId { get; set; }

        /// <summary>
        /// Contains information about visits.
        /// </summary>
        [JsonProperty("Visits", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6Visit> Visits { get; set; }

        /// <summary>
        /// Contains information about clients.
        /// </summary>
        [JsonProperty("Clients", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6Client> Clients { get; set; }

        /// <summary>
        /// Contains information about a location.
        /// </summary>
        [JsonProperty("Location", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6Location Location { get; set; }

        /// <summary>
        /// Contains information about a resource, such as a room, assigned to a class.
        /// </summary>
        [JsonProperty("Resource", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6Resource Resource { get; set; }

        /// <summary>
        /// The maximum number of clients allowed in the class.
        /// </summary>
        [JsonProperty("MaxCapacity", NullValueHandling = NullValueHandling.Ignore)]
        public int? MaxCapacity { get; set; }

        /// <summary>
        /// The maximum number of clients allowed to sign up online for the class.
        /// </summary>
        [JsonProperty("WebCapacity", NullValueHandling = NullValueHandling.Ignore)]
        public int? WebCapacity { get; set; }

        /// <summary>
        /// The total number of clients booked in the class.
        /// </summary>
        [JsonProperty("TotalBooked", NullValueHandling = NullValueHandling.Ignore)]
        public int? TotalBooked { get; set; }

        /// <summary>
        /// The total number of clients signed into the class.
        /// </summary>
        [JsonProperty("TotalSignedIn", NullValueHandling = NullValueHandling.Ignore)]
        public int? TotalSignedIn { get; set; }

        /// <summary>
        /// The total number of booked clients on the waiting list for the class.
        /// </summary>
        [JsonProperty("TotalBookedWaitlist", NullValueHandling = NullValueHandling.Ignore)]
        public int? TotalBookedWaitlist { get; set; }

        /// <summary>
        /// The total number of clients who signed up online for the class.
        /// </summary>
        [JsonProperty("WebBooked", NullValueHandling = NullValueHandling.Ignore)]
        public int? WebBooked { get; set; }

        /// <summary>
        /// The ID of the semester that the class is a part of, if any.
        /// </summary>
        [JsonProperty("SemesterId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SemesterId { get; set; }

        /// <summary>
        /// When `true`, indicates that the class has been cancelled.<br />
        /// When `false`, indicates that the class has not been cancelled.
        /// </summary>
        [JsonProperty("IsCanceled", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsCanceled { get; set; }

        /// <summary>
        /// When `true`, indicates that the class is being taught by a substitute teacher.<br />
        /// When `false`, indicates that the class is being taught by its regular teacher.
        /// </summary>
        [JsonProperty("Substitute", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Substitute { get; set; }

        /// <summary>
        /// When `true`, indicates that the class is shown to clients when in consumer mode.<br />
        /// When `false`, indicates that the class is not shown to clients when in consumer mode.
        /// </summary>
        [JsonProperty("Active", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Active { get; set; }

        /// <summary>
        /// When `true`, indicates that the clients can be placed on a waiting list for the class.<br />
        /// When `false`, indicates that the clients cannot be placed on a waiting list for the class.
        /// </summary>
        [JsonProperty("IsWaitlistAvailable", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsWaitlistAvailable { get; set; }

        /// <summary>
        /// When `true`, indicates that the client with the given `ClientId` is enrolled in this class.<br />
        /// When `false`, indicates that the client with the given `ClientId` is not enrolled in this class.
        /// </summary>
        [JsonProperty("IsEnrolled", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsEnrolled { get; set; }

        /// <summary>
        /// When `true`, indicates that this class is hidden when cancelled.<br />
        /// When `false`, indicates that this class is not hidden when cancelled.
        /// </summary>
        [JsonProperty("HideCancel", NullValueHandling = NullValueHandling.Ignore)]
        public bool? HideCancel { get; set; }

        /// <summary>
        /// The unique identifier for the class.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// When `true`, indicates that the client with the given client ID can book this class.<br />
        /// When `false`, indicates that the client with the given client ID cannot book this class.
        /// </summary>
        [JsonProperty("IsAvailable", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsAvailable { get; set; }

        /// <summary>
        /// The time this class is scheduled to start.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDateTime { get; set; }

        /// <summary>
        /// The time this class is scheduled to end.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDateTime { get; set; }

        /// <summary>
        /// The last time this class was modified.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("LastModifiedDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? LastModifiedDateTime { get; set; }

        /// <summary>
        /// Contains information that defines the class.
        /// </summary>
        [JsonProperty("ClassDescription", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6ClassDescription ClassDescription { get; set; }

        /// <summary>
        /// Contains information about the staff member.
        /// </summary>
        [JsonProperty("Staff", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6Staff Staff { get; set; }

        /// <summary>
        /// Contains information about the window for booking.
        /// </summary>
        [JsonProperty("BookingWindow", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6BookingWindow BookingWindow { get; set; }

        /// <summary>
        /// Contains the booking?s payment status.
        /// </summary>
        [JsonProperty("BookingStatus", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.BookingStatusEnum? BookingStatus { get; set; }

        /// <summary>
        /// The link to the Mindbody-hosted live stream for the class. This is `null` when no live stream is configured for the class.
        /// </summary>
        [JsonProperty("VirtualStreamLink", NullValueHandling = NullValueHandling.Ignore)]
        public string VirtualStreamLink { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6Class : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6Class other &&
                ((this.ClassScheduleId == null && other.ClassScheduleId == null) || (this.ClassScheduleId?.Equals(other.ClassScheduleId) == true)) &&
                ((this.Visits == null && other.Visits == null) || (this.Visits?.Equals(other.Visits) == true)) &&
                ((this.Clients == null && other.Clients == null) || (this.Clients?.Equals(other.Clients) == true)) &&
                ((this.Location == null && other.Location == null) || (this.Location?.Equals(other.Location) == true)) &&
                ((this.Resource == null && other.Resource == null) || (this.Resource?.Equals(other.Resource) == true)) &&
                ((this.MaxCapacity == null && other.MaxCapacity == null) || (this.MaxCapacity?.Equals(other.MaxCapacity) == true)) &&
                ((this.WebCapacity == null && other.WebCapacity == null) || (this.WebCapacity?.Equals(other.WebCapacity) == true)) &&
                ((this.TotalBooked == null && other.TotalBooked == null) || (this.TotalBooked?.Equals(other.TotalBooked) == true)) &&
                ((this.TotalSignedIn == null && other.TotalSignedIn == null) || (this.TotalSignedIn?.Equals(other.TotalSignedIn) == true)) &&
                ((this.TotalBookedWaitlist == null && other.TotalBookedWaitlist == null) || (this.TotalBookedWaitlist?.Equals(other.TotalBookedWaitlist) == true)) &&
                ((this.WebBooked == null && other.WebBooked == null) || (this.WebBooked?.Equals(other.WebBooked) == true)) &&
                ((this.SemesterId == null && other.SemesterId == null) || (this.SemesterId?.Equals(other.SemesterId) == true)) &&
                ((this.IsCanceled == null && other.IsCanceled == null) || (this.IsCanceled?.Equals(other.IsCanceled) == true)) &&
                ((this.Substitute == null && other.Substitute == null) || (this.Substitute?.Equals(other.Substitute) == true)) &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true)) &&
                ((this.IsWaitlistAvailable == null && other.IsWaitlistAvailable == null) || (this.IsWaitlistAvailable?.Equals(other.IsWaitlistAvailable) == true)) &&
                ((this.IsEnrolled == null && other.IsEnrolled == null) || (this.IsEnrolled?.Equals(other.IsEnrolled) == true)) &&
                ((this.HideCancel == null && other.HideCancel == null) || (this.HideCancel?.Equals(other.HideCancel) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.IsAvailable == null && other.IsAvailable == null) || (this.IsAvailable?.Equals(other.IsAvailable) == true)) &&
                ((this.StartDateTime == null && other.StartDateTime == null) || (this.StartDateTime?.Equals(other.StartDateTime) == true)) &&
                ((this.EndDateTime == null && other.EndDateTime == null) || (this.EndDateTime?.Equals(other.EndDateTime) == true)) &&
                ((this.LastModifiedDateTime == null && other.LastModifiedDateTime == null) || (this.LastModifiedDateTime?.Equals(other.LastModifiedDateTime) == true)) &&
                ((this.ClassDescription == null && other.ClassDescription == null) || (this.ClassDescription?.Equals(other.ClassDescription) == true)) &&
                ((this.Staff == null && other.Staff == null) || (this.Staff?.Equals(other.Staff) == true)) &&
                ((this.BookingWindow == null && other.BookingWindow == null) || (this.BookingWindow?.Equals(other.BookingWindow) == true)) &&
                ((this.BookingStatus == null && other.BookingStatus == null) || (this.BookingStatus?.Equals(other.BookingStatus) == true)) &&
                ((this.VirtualStreamLink == null && other.VirtualStreamLink == null) || (this.VirtualStreamLink?.Equals(other.VirtualStreamLink) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClassScheduleId = {(this.ClassScheduleId == null ? "null" : this.ClassScheduleId.ToString())}");
            toStringOutput.Add($"this.Visits = {(this.Visits == null ? "null" : $"[{string.Join(", ", this.Visits)} ]")}");
            toStringOutput.Add($"this.Clients = {(this.Clients == null ? "null" : $"[{string.Join(", ", this.Clients)} ]")}");
            toStringOutput.Add($"this.Location = {(this.Location == null ? "null" : this.Location.ToString())}");
            toStringOutput.Add($"this.Resource = {(this.Resource == null ? "null" : this.Resource.ToString())}");
            toStringOutput.Add($"this.MaxCapacity = {(this.MaxCapacity == null ? "null" : this.MaxCapacity.ToString())}");
            toStringOutput.Add($"this.WebCapacity = {(this.WebCapacity == null ? "null" : this.WebCapacity.ToString())}");
            toStringOutput.Add($"this.TotalBooked = {(this.TotalBooked == null ? "null" : this.TotalBooked.ToString())}");
            toStringOutput.Add($"this.TotalSignedIn = {(this.TotalSignedIn == null ? "null" : this.TotalSignedIn.ToString())}");
            toStringOutput.Add($"this.TotalBookedWaitlist = {(this.TotalBookedWaitlist == null ? "null" : this.TotalBookedWaitlist.ToString())}");
            toStringOutput.Add($"this.WebBooked = {(this.WebBooked == null ? "null" : this.WebBooked.ToString())}");
            toStringOutput.Add($"this.SemesterId = {(this.SemesterId == null ? "null" : this.SemesterId.ToString())}");
            toStringOutput.Add($"this.IsCanceled = {(this.IsCanceled == null ? "null" : this.IsCanceled.ToString())}");
            toStringOutput.Add($"this.Substitute = {(this.Substitute == null ? "null" : this.Substitute.ToString())}");
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active.ToString())}");
            toStringOutput.Add($"this.IsWaitlistAvailable = {(this.IsWaitlistAvailable == null ? "null" : this.IsWaitlistAvailable.ToString())}");
            toStringOutput.Add($"this.IsEnrolled = {(this.IsEnrolled == null ? "null" : this.IsEnrolled.ToString())}");
            toStringOutput.Add($"this.HideCancel = {(this.HideCancel == null ? "null" : this.HideCancel.ToString())}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.IsAvailable = {(this.IsAvailable == null ? "null" : this.IsAvailable.ToString())}");
            toStringOutput.Add($"this.StartDateTime = {(this.StartDateTime == null ? "null" : this.StartDateTime.ToString())}");
            toStringOutput.Add($"this.EndDateTime = {(this.EndDateTime == null ? "null" : this.EndDateTime.ToString())}");
            toStringOutput.Add($"this.LastModifiedDateTime = {(this.LastModifiedDateTime == null ? "null" : this.LastModifiedDateTime.ToString())}");
            toStringOutput.Add($"this.ClassDescription = {(this.ClassDescription == null ? "null" : this.ClassDescription.ToString())}");
            toStringOutput.Add($"this.Staff = {(this.Staff == null ? "null" : this.Staff.ToString())}");
            toStringOutput.Add($"this.BookingWindow = {(this.BookingWindow == null ? "null" : this.BookingWindow.ToString())}");
            toStringOutput.Add($"this.BookingStatus = {(this.BookingStatus == null ? "null" : this.BookingStatus.ToString())}");
            toStringOutput.Add($"this.VirtualStreamLink = {(this.VirtualStreamLink == null ? "null" : this.VirtualStreamLink == string.Empty ? "" : this.VirtualStreamLink)}");
        }
    }
}