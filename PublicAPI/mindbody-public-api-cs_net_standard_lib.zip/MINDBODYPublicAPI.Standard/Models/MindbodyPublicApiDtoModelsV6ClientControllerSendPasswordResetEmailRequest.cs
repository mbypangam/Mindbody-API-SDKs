// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest"/> class.
        /// </summary>
        /// <param name="userEmail">UserEmail.</param>
        /// <param name="userFirstName">UserFirstName.</param>
        /// <param name="userLastName">UserLastName.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest(
            string userEmail,
            string userFirstName,
            string userLastName)
        {
            this.UserEmail = userEmail;
            this.UserFirstName = userFirstName;
            this.UserLastName = userLastName;
        }

        /// <summary>
        /// The user's email address. The software uses this parameter as the username.
        /// </summary>
        [JsonProperty("UserEmail")]
        public string UserEmail { get; set; }

        /// <summary>
        /// The user's first name. The software uses this parameter to verify the user.
        /// </summary>
        [JsonProperty("UserFirstName")]
        public string UserFirstName { get; set; }

        /// <summary>
        /// The user's last name. The software uses this parameter to verify the user.
        /// </summary>
        [JsonProperty("UserLastName")]
        public string UserLastName { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerSendPasswordResetEmailRequest other &&
                ((this.UserEmail == null && other.UserEmail == null) || (this.UserEmail?.Equals(other.UserEmail) == true)) &&
                ((this.UserFirstName == null && other.UserFirstName == null) || (this.UserFirstName?.Equals(other.UserFirstName) == true)) &&
                ((this.UserLastName == null && other.UserLastName == null) || (this.UserLastName?.Equals(other.UserLastName) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.UserEmail = {(this.UserEmail == null ? "null" : this.UserEmail == string.Empty ? "" : this.UserEmail)}");
            toStringOutput.Add($"this.UserFirstName = {(this.UserFirstName == null ? "null" : this.UserFirstName == string.Empty ? "" : this.UserFirstName)}");
            toStringOutput.Add($"this.UserLastName = {(this.UserLastName == null ? "null" : this.UserLastName == string.Empty ? "" : this.UserLastName)}");
        }
    }
}