// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="formulaNotes">FormulaNotes.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse(
            Models.MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse = null,
            List<Models.MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse> formulaNotes = null)
        {
            this.PaginationResponse = paginationResponse;
            this.FormulaNotes = formulaNotes;
        }

        /// <summary>
        /// Contains information about the pagination used.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// Contains details about the client's formula.
        /// </summary>
        [JsonProperty("FormulaNotes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6ClientControllerFormulaNoteResponse> FormulaNotes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerGetClientFormulaNotesResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.FormulaNotes == null && other.FormulaNotes == null) || (this.FormulaNotes?.Equals(other.FormulaNotes) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.FormulaNotes = {(this.FormulaNotes == null ? "null" : $"[{string.Join(", ", this.FormulaNotes)} ]")}");
        }
    }
}