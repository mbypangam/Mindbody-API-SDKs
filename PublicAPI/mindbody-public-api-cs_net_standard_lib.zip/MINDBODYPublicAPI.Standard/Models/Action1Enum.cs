// <copyright file="Action1Enum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Action1Enum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum Action1Enum
    {
        /// <summary>
        /// None.
        /// </summary>
        [EnumMember(Value = "None")]
        None,

        /// <summary>
        /// Added.
        /// </summary>
        [EnumMember(Value = "Added")]
        Added,

        /// <summary>
        /// Updated.
        /// </summary>
        [EnumMember(Value = "Updated")]
        Updated,

        /// <summary>
        /// Failed.
        /// </summary>
        [EnumMember(Value = "Failed")]
        Failed,

        /// <summary>
        /// Removed.
        /// </summary>
        [EnumMember(Value = "Removed")]
        Removed
    }
}