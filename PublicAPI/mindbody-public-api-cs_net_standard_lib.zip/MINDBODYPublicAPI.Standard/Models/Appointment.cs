// <copyright file="Appointment.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Appointment.
    /// </summary>
    public class Appointment
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Appointment"/> class.
        /// </summary>
        public Appointment()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Appointment"/> class.
        /// </summary>
        /// <param name="genderPreference">GenderPreference.</param>
        /// <param name="duration">Duration.</param>
        /// <param name="providerId">ProviderId.</param>
        /// <param name="id">Id.</param>
        /// <param name="status">Status.</param>
        /// <param name="startDateTime">StartDateTime.</param>
        /// <param name="endDateTime">EndDateTime.</param>
        /// <param name="notes">Notes.</param>
        /// <param name="partnerExternalId">PartnerExternalId.</param>
        /// <param name="staffRequested">StaffRequested.</param>
        /// <param name="programId">ProgramId.</param>
        /// <param name="sessionTypeId">SessionTypeId.</param>
        /// <param name="locationId">LocationId.</param>
        /// <param name="staffId">StaffId.</param>
        /// <param name="clientId">ClientId.</param>
        /// <param name="firstAppointment">FirstAppointment.</param>
        /// <param name="isWaitlist">IsWaitlist.</param>
        /// <param name="waitlistEntryId">WaitlistEntryId.</param>
        /// <param name="clientServiceId">ClientServiceId.</param>
        /// <param name="resources">Resources.</param>
        /// <param name="addOns">AddOns.</param>
        /// <param name="onlineDescription">OnlineDescription.</param>
        public Appointment(
            Models.GenderPreferenceEnum? genderPreference = null,
            int? duration = null,
            string providerId = null,
            long? id = null,
            Models.StatusEnum? status = null,
            DateTime? startDateTime = null,
            DateTime? endDateTime = null,
            string notes = null,
            string partnerExternalId = null,
            bool? staffRequested = null,
            int? programId = null,
            int? sessionTypeId = null,
            int? locationId = null,
            long? staffId = null,
            string clientId = null,
            bool? firstAppointment = null,
            bool? isWaitlist = null,
            long? waitlistEntryId = null,
            long? clientServiceId = null,
            List<Models.Resource> resources = null,
            List<Models.AddOnSmall> addOns = null,
            string onlineDescription = null)
        {
            this.GenderPreference = genderPreference;
            this.Duration = duration;
            this.ProviderId = providerId;
            this.Id = id;
            this.Status = status;
            this.StartDateTime = startDateTime;
            this.EndDateTime = endDateTime;
            this.Notes = notes;
            this.PartnerExternalId = partnerExternalId;
            this.StaffRequested = staffRequested;
            this.ProgramId = programId;
            this.SessionTypeId = sessionTypeId;
            this.LocationId = locationId;
            this.StaffId = staffId;
            this.ClientId = clientId;
            this.FirstAppointment = firstAppointment;
            this.IsWaitlist = isWaitlist;
            this.WaitlistEntryId = waitlistEntryId;
            this.ClientServiceId = clientServiceId;
            this.Resources = resources;
            this.AddOns = addOns;
            this.OnlineDescription = onlineDescription;
        }

        /// <summary>
        /// The prefered gender of the appointment provider.
        /// Possible values are:
        /// * None
        /// * Female
        /// * Male
        /// </summary>
        [JsonProperty("GenderPreference", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.GenderPreferenceEnum? GenderPreference { get; set; }

        /// <summary>
        /// The duration of the appointment.
        /// </summary>
        [JsonProperty("Duration", NullValueHandling = NullValueHandling.Ignore)]
        public int? Duration { get; set; }

        /// <summary>
        /// If a user has Complementary and Alternative Medicine features enabled, this property indicates the provider assigned to the appointment.
        /// </summary>
        [JsonProperty("ProviderId", NullValueHandling = NullValueHandling.Ignore)]
        public string ProviderId { get; set; }

        /// <summary>
        /// The unique ID of the appointment.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public long? Id { get; set; }

        /// <summary>
        /// The status of this appointment.
        /// Possible values are:
        /// * None
        /// * Requested
        /// * Booked
        /// * Completed
        /// * Confirmed
        /// * Arrived
        /// * NoShow
        /// * Cancelled
        /// * LateCancelled
        /// </summary>
        [JsonProperty("Status", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.StatusEnum? Status { get; set; }

        /// <summary>
        /// The date and time the appointment is to start.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDateTime { get; set; }

        /// <summary>
        /// The date and time the appointment is to end.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDateTime { get; set; }

        /// <summary>
        /// Any notes associated with the appointment.
        /// </summary>
        [JsonProperty("Notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <summary>
        /// Optional external key for api partners.
        /// </summary>
        [JsonProperty("PartnerExternalId", NullValueHandling = NullValueHandling.Ignore)]
        public string PartnerExternalId { get; set; }

        /// <summary>
        /// When `true`, indicates that the staff member was requested specifically by the client.
        /// </summary>
        [JsonProperty("StaffRequested", NullValueHandling = NullValueHandling.Ignore)]
        public bool? StaffRequested { get; set; }

        /// <summary>
        /// The ID of the program to which this appointment belongs.
        /// </summary>
        [JsonProperty("ProgramId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ProgramId { get; set; }

        /// <summary>
        /// The ID of the session type of this appointment.
        /// </summary>
        [JsonProperty("SessionTypeId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SessionTypeId { get; set; }

        /// <summary>
        /// The ID of the location where this appointment is to take place.
        /// </summary>
        [JsonProperty("LocationId", NullValueHandling = NullValueHandling.Ignore)]
        public int? LocationId { get; set; }

        /// <summary>
        /// The ID of the staff member providing the service for this appointment.
        /// </summary>
        [JsonProperty("StaffId", NullValueHandling = NullValueHandling.Ignore)]
        public long? StaffId { get; set; }

        /// <summary>
        /// The RSSID of the client who is booked for this appointment.
        /// </summary>
        [JsonProperty("ClientId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientId { get; set; }

        /// <summary>
        /// When `true`, indicates that this is the client’s first appointment at this site.
        /// </summary>
        [JsonProperty("FirstAppointment", NullValueHandling = NullValueHandling.Ignore)]
        public bool? FirstAppointment { get; set; }

        /// <summary>
        /// When `true`, indicates that the client should be added to a specific appointment waiting list.
        /// When `false`, the client should not be added to the waiting list.
        /// Default: *false*
        /// </summary>
        [JsonProperty("IsWaitlist", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsWaitlist { get; set; }

        /// <summary>
        /// The unique ID of the appointment waitlist.
        /// </summary>
        [JsonProperty("WaitlistEntryId", NullValueHandling = NullValueHandling.Ignore)]
        public long? WaitlistEntryId { get; set; }

        /// <summary>
        /// The ID of the pass on the client’s account that is to pay for this appointment.
        /// </summary>
        [JsonProperty("ClientServiceId", NullValueHandling = NullValueHandling.Ignore)]
        public long? ClientServiceId { get; set; }

        /// <summary>
        /// The resources this appointment is to use.
        /// </summary>
        [JsonProperty("Resources", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Resource> Resources { get; set; }

        /// <summary>
        /// Any AddOns associated with the appointment
        /// </summary>
        [JsonProperty("AddOns", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.AddOnSmall> AddOns { get; set; }

        /// <summary>
        /// Online Description associated with the appointment
        /// </summary>
        [JsonProperty("OnlineDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string OnlineDescription { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Appointment : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Appointment other &&
                ((this.GenderPreference == null && other.GenderPreference == null) || (this.GenderPreference?.Equals(other.GenderPreference) == true)) &&
                ((this.Duration == null && other.Duration == null) || (this.Duration?.Equals(other.Duration) == true)) &&
                ((this.ProviderId == null && other.ProviderId == null) || (this.ProviderId?.Equals(other.ProviderId) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Status == null && other.Status == null) || (this.Status?.Equals(other.Status) == true)) &&
                ((this.StartDateTime == null && other.StartDateTime == null) || (this.StartDateTime?.Equals(other.StartDateTime) == true)) &&
                ((this.EndDateTime == null && other.EndDateTime == null) || (this.EndDateTime?.Equals(other.EndDateTime) == true)) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true)) &&
                ((this.PartnerExternalId == null && other.PartnerExternalId == null) || (this.PartnerExternalId?.Equals(other.PartnerExternalId) == true)) &&
                ((this.StaffRequested == null && other.StaffRequested == null) || (this.StaffRequested?.Equals(other.StaffRequested) == true)) &&
                ((this.ProgramId == null && other.ProgramId == null) || (this.ProgramId?.Equals(other.ProgramId) == true)) &&
                ((this.SessionTypeId == null && other.SessionTypeId == null) || (this.SessionTypeId?.Equals(other.SessionTypeId) == true)) &&
                ((this.LocationId == null && other.LocationId == null) || (this.LocationId?.Equals(other.LocationId) == true)) &&
                ((this.StaffId == null && other.StaffId == null) || (this.StaffId?.Equals(other.StaffId) == true)) &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.FirstAppointment == null && other.FirstAppointment == null) || (this.FirstAppointment?.Equals(other.FirstAppointment) == true)) &&
                ((this.IsWaitlist == null && other.IsWaitlist == null) || (this.IsWaitlist?.Equals(other.IsWaitlist) == true)) &&
                ((this.WaitlistEntryId == null && other.WaitlistEntryId == null) || (this.WaitlistEntryId?.Equals(other.WaitlistEntryId) == true)) &&
                ((this.ClientServiceId == null && other.ClientServiceId == null) || (this.ClientServiceId?.Equals(other.ClientServiceId) == true)) &&
                ((this.Resources == null && other.Resources == null) || (this.Resources?.Equals(other.Resources) == true)) &&
                ((this.AddOns == null && other.AddOns == null) || (this.AddOns?.Equals(other.AddOns) == true)) &&
                ((this.OnlineDescription == null && other.OnlineDescription == null) || (this.OnlineDescription?.Equals(other.OnlineDescription) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.GenderPreference = {(this.GenderPreference == null ? "null" : this.GenderPreference.ToString())}");
            toStringOutput.Add($"this.Duration = {(this.Duration == null ? "null" : this.Duration.ToString())}");
            toStringOutput.Add($"this.ProviderId = {(this.ProviderId == null ? "null" : this.ProviderId == string.Empty ? "" : this.ProviderId)}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Status = {(this.Status == null ? "null" : this.Status.ToString())}");
            toStringOutput.Add($"this.StartDateTime = {(this.StartDateTime == null ? "null" : this.StartDateTime.ToString())}");
            toStringOutput.Add($"this.EndDateTime = {(this.EndDateTime == null ? "null" : this.EndDateTime.ToString())}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes == string.Empty ? "" : this.Notes)}");
            toStringOutput.Add($"this.PartnerExternalId = {(this.PartnerExternalId == null ? "null" : this.PartnerExternalId == string.Empty ? "" : this.PartnerExternalId)}");
            toStringOutput.Add($"this.StaffRequested = {(this.StaffRequested == null ? "null" : this.StaffRequested.ToString())}");
            toStringOutput.Add($"this.ProgramId = {(this.ProgramId == null ? "null" : this.ProgramId.ToString())}");
            toStringOutput.Add($"this.SessionTypeId = {(this.SessionTypeId == null ? "null" : this.SessionTypeId.ToString())}");
            toStringOutput.Add($"this.LocationId = {(this.LocationId == null ? "null" : this.LocationId.ToString())}");
            toStringOutput.Add($"this.StaffId = {(this.StaffId == null ? "null" : this.StaffId.ToString())}");
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.FirstAppointment = {(this.FirstAppointment == null ? "null" : this.FirstAppointment.ToString())}");
            toStringOutput.Add($"this.IsWaitlist = {(this.IsWaitlist == null ? "null" : this.IsWaitlist.ToString())}");
            toStringOutput.Add($"this.WaitlistEntryId = {(this.WaitlistEntryId == null ? "null" : this.WaitlistEntryId.ToString())}");
            toStringOutput.Add($"this.ClientServiceId = {(this.ClientServiceId == null ? "null" : this.ClientServiceId.ToString())}");
            toStringOutput.Add($"this.Resources = {(this.Resources == null ? "null" : $"[{string.Join(", ", this.Resources)} ]")}");
            toStringOutput.Add($"this.AddOns = {(this.AddOns == null ? "null" : $"[{string.Join(", ", this.AddOns)} ]")}");
            toStringOutput.Add($"this.OnlineDescription = {(this.OnlineDescription == null ? "null" : this.OnlineDescription == string.Empty ? "" : this.OnlineDescription)}");
        }
    }
}