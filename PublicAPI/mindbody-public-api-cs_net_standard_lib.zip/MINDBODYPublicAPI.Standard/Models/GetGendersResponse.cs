// <copyright file="GetGendersResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetGendersResponse.
    /// </summary>
    public class GetGendersResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetGendersResponse"/> class.
        /// </summary>
        public GetGendersResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetGendersResponse"/> class.
        /// </summary>
        /// <param name="genderOptions">GenderOptions.</param>
        public GetGendersResponse(
            List<Models.MindbodyPublicApiDtoModelsV6GenderOption> genderOptions = null)
        {
            this.GenderOptions = genderOptions;
        }

        /// <summary>
        /// A list of the gender options and their properties at the site
        /// </summary>
        [JsonProperty("GenderOptions", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6GenderOption> GenderOptions { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetGendersResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetGendersResponse other &&
                ((this.GenderOptions == null && other.GenderOptions == null) || (this.GenderOptions?.Equals(other.GenderOptions) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.GenderOptions = {(this.GenderOptions == null ? "null" : $"[{string.Join(", ", this.GenderOptions)} ]")}");
        }
    }
}