// <copyright file="AddClientToClassRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// AddClientToClassRequest.
    /// </summary>
    public class AddClientToClassRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddClientToClassRequest"/> class.
        /// </summary>
        public AddClientToClassRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddClientToClassRequest"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="classId">ClassId.</param>
        /// <param name="test">Test.</param>
        /// <param name="requirePayment">RequirePayment.</param>
        /// <param name="waitlist">Waitlist.</param>
        /// <param name="sendEmail">SendEmail.</param>
        /// <param name="waitlistEntryId">WaitlistEntryId.</param>
        /// <param name="clientServiceId">ClientServiceId.</param>
        /// <param name="crossRegionalBooking">CrossRegionalBooking.</param>
        /// <param name="crossRegionalBookingClientServiceSiteId">CrossRegionalBookingClientServiceSiteId.</param>
        /// <param name="uniqueId">UniqueId.</param>
        public AddClientToClassRequest(
            string clientId,
            int classId,
            bool? test = null,
            bool? requirePayment = null,
            bool? waitlist = null,
            bool? sendEmail = null,
            int? waitlistEntryId = null,
            int? clientServiceId = null,
            bool? crossRegionalBooking = null,
            int? crossRegionalBookingClientServiceSiteId = null,
            long? uniqueId = null)
        {
            this.ClientId = clientId;
            this.ClassId = classId;
            this.Test = test;
            this.RequirePayment = requirePayment;
            this.Waitlist = waitlist;
            this.SendEmail = sendEmail;
            this.WaitlistEntryId = waitlistEntryId;
            this.ClientServiceId = clientServiceId;
            this.CrossRegionalBooking = crossRegionalBooking;
            this.CrossRegionalBookingClientServiceSiteId = crossRegionalBookingClientServiceSiteId;
            this.UniqueId = uniqueId;
        }

        /// <summary>
        /// The ID of the client who is being booked into the class
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// The ID of the class into which the client is being booked
        /// </summary>
        [JsonProperty("ClassId")]
        public int ClassId { get; set; }

        /// <summary>
        /// When `true`, indicates that input information is validated, but not committed.<br />
        /// When `false`, the information is committed and the database is affected.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <summary>
        /// When `true`, the client must have an active, usable pricing option on their account.<br />
        /// When `false` or omitted, an active pricing option is not required to complete the client’s booking.
        /// </summary>
        [JsonProperty("RequirePayment", NullValueHandling = NullValueHandling.Ignore)]
        public bool? RequirePayment { get; set; }

        /// <summary>
        /// When `true`, indicates that the client should be added to a specific class waiting list.<br />
        /// When `false`, the client should not be added to the waiting list.
        /// </summary>
        [JsonProperty("Waitlist", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Waitlist { get; set; }

        /// <summary>
        /// When `true`, the subscriber’s configured Booking Confirmation automatic email is sent to the client. Note that an email is sent only if the client has an email address and automatic emails have been set up.<br />
        /// When `false`, indicates that the client does not receive emails.<br />
        /// Default: **false**
        /// **Note**: When the Authorization header is passed and the SendEmail is set to `true`, then an email will be sent.
        /// When the Authorization header is passed and the SendEmail is set to `false`, then an email will not be sent.
        /// When the Authorization header is not passed and the SendEmail is set to either `true` or `false`, then an email will not be sent.
        /// </summary>
        [JsonProperty("SendEmail", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendEmail { get; set; }

        /// <summary>
        /// The ID of the waiting list entry from which you are moving a client into a class.
        /// </summary>
        [JsonProperty("WaitlistEntryId", NullValueHandling = NullValueHandling.Ignore)]
        public int? WaitlistEntryId { get; set; }

        /// <summary>
        /// The ID of the pricing option on the client’s account that you want to use to pay for this booking, if payment is required at the time of the update.
        /// </summary>
        [JsonProperty("ClientServiceId", NullValueHandling = NullValueHandling.Ignore)]
        public int? ClientServiceId { get; set; }

        /// <summary>
        /// When `true`, cross regional series are checked and used if applicable.
        /// </summary>
        [JsonProperty("CrossRegionalBooking", NullValueHandling = NullValueHandling.Ignore)]
        public bool? CrossRegionalBooking { get; set; }

        /// <summary>
        /// If the request is cross regional, use a purchased pricing option from this specified site. If omitted, an attempt is made to use an applicable pricing option from the local site.
        /// </summary>
        [JsonProperty("CrossRegionalBookingClientServiceSiteId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CrossRegionalBookingClientServiceSiteId { get; set; }

        /// <summary>
        /// The UniqueID of the client who is being booked into the class
        /// </summary>
        [JsonProperty("UniqueId", NullValueHandling = NullValueHandling.Ignore)]
        public long? UniqueId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddClientToClassRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddClientToClassRequest other &&                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                this.ClassId.Equals(other.ClassId) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true)) &&
                ((this.RequirePayment == null && other.RequirePayment == null) || (this.RequirePayment?.Equals(other.RequirePayment) == true)) &&
                ((this.Waitlist == null && other.Waitlist == null) || (this.Waitlist?.Equals(other.Waitlist) == true)) &&
                ((this.SendEmail == null && other.SendEmail == null) || (this.SendEmail?.Equals(other.SendEmail) == true)) &&
                ((this.WaitlistEntryId == null && other.WaitlistEntryId == null) || (this.WaitlistEntryId?.Equals(other.WaitlistEntryId) == true)) &&
                ((this.ClientServiceId == null && other.ClientServiceId == null) || (this.ClientServiceId?.Equals(other.ClientServiceId) == true)) &&
                ((this.CrossRegionalBooking == null && other.CrossRegionalBooking == null) || (this.CrossRegionalBooking?.Equals(other.CrossRegionalBooking) == true)) &&
                ((this.CrossRegionalBookingClientServiceSiteId == null && other.CrossRegionalBookingClientServiceSiteId == null) || (this.CrossRegionalBookingClientServiceSiteId?.Equals(other.CrossRegionalBookingClientServiceSiteId) == true)) &&
                ((this.UniqueId == null && other.UniqueId == null) || (this.UniqueId?.Equals(other.UniqueId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId)}");
            toStringOutput.Add($"this.ClassId = {this.ClassId}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
            toStringOutput.Add($"this.RequirePayment = {(this.RequirePayment == null ? "null" : this.RequirePayment.ToString())}");
            toStringOutput.Add($"this.Waitlist = {(this.Waitlist == null ? "null" : this.Waitlist.ToString())}");
            toStringOutput.Add($"this.SendEmail = {(this.SendEmail == null ? "null" : this.SendEmail.ToString())}");
            toStringOutput.Add($"this.WaitlistEntryId = {(this.WaitlistEntryId == null ? "null" : this.WaitlistEntryId.ToString())}");
            toStringOutput.Add($"this.ClientServiceId = {(this.ClientServiceId == null ? "null" : this.ClientServiceId.ToString())}");
            toStringOutput.Add($"this.CrossRegionalBooking = {(this.CrossRegionalBooking == null ? "null" : this.CrossRegionalBooking.ToString())}");
            toStringOutput.Add($"this.CrossRegionalBookingClientServiceSiteId = {(this.CrossRegionalBookingClientServiceSiteId == null ? "null" : this.CrossRegionalBookingClientServiceSiteId.ToString())}");
            toStringOutput.Add($"this.UniqueId = {(this.UniqueId == null ? "null" : this.UniqueId.ToString())}");
        }
    }
}