// <copyright file="GetGiftCardBalanceResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetGiftCardBalanceResponse.
    /// </summary>
    public class GetGiftCardBalanceResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetGiftCardBalanceResponse"/> class.
        /// </summary>
        public GetGiftCardBalanceResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetGiftCardBalanceResponse"/> class.
        /// </summary>
        /// <param name="barcodeId">BarcodeId.</param>
        /// <param name="remainingBalance">RemainingBalance.</param>
        public GetGiftCardBalanceResponse(
            string barcodeId = null,
            double? remainingBalance = null)
        {
            this.BarcodeId = barcodeId;
            this.RemainingBalance = remainingBalance;
        }

        /// <summary>
        /// The gift card's barcode ID.
        /// </summary>
        [JsonProperty("BarcodeId", NullValueHandling = NullValueHandling.Ignore)]
        public string BarcodeId { get; set; }

        /// <summary>
        /// The gift card's remaining balance.
        /// </summary>
        [JsonProperty("RemainingBalance", NullValueHandling = NullValueHandling.Ignore)]
        public double? RemainingBalance { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetGiftCardBalanceResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetGiftCardBalanceResponse other &&
                ((this.BarcodeId == null && other.BarcodeId == null) || (this.BarcodeId?.Equals(other.BarcodeId) == true)) &&
                ((this.RemainingBalance == null && other.RemainingBalance == null) || (this.RemainingBalance?.Equals(other.RemainingBalance) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BarcodeId = {(this.BarcodeId == null ? "null" : this.BarcodeId == string.Empty ? "" : this.BarcodeId)}");
            toStringOutput.Add($"this.RemainingBalance = {(this.RemainingBalance == null ? "null" : this.RemainingBalance.ToString())}");
        }
    }
}