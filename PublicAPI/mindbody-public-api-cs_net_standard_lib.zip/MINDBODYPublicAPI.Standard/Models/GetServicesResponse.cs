// <copyright file="GetServicesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetServicesResponse.
    /// </summary>
    public class GetServicesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetServicesResponse"/> class.
        /// </summary>
        public GetServicesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetServicesResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="services">Services.</param>
        public GetServicesResponse(
            Models.PaginationResponse paginationResponse = null,
            List<Models.Service> services = null)
        {
            this.PaginationResponse = paginationResponse;
            this.Services = services;
        }

        /// <summary>
        /// Contains information about the pagination to use.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// Contains information about the services.
        /// </summary>
        [JsonProperty("Services", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Service> Services { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetServicesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetServicesResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.Services == null && other.Services == null) || (this.Services?.Equals(other.Services) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.Services = {(this.Services == null ? "null" : $"[{string.Join(", ", this.Services)} ]")}");
        }
    }
}