// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse"/> class.
        /// </summary>
        /// <param name="mClass">Class.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse(
            Models.MindbodyPublicApiDtoModelsV6Class mClass = null)
        {
            this.MClass = mClass;
        }

        /// <summary>
        /// Contains class and booking information.
        /// </summary>
        [JsonProperty("Class", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6Class MClass { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerGetClassVisitsResponse other &&
                ((this.MClass == null && other.MClass == null) || (this.MClass?.Equals(other.MClass) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MClass = {(this.MClass == null ? "null" : this.MClass.ToString())}");
        }
    }
}