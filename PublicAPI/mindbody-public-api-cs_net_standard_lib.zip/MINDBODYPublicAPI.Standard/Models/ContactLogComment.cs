// <copyright file="ContactLogComment.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ContactLogComment.
    /// </summary>
    public class ContactLogComment
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ContactLogComment"/> class.
        /// </summary>
        public ContactLogComment()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ContactLogComment"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="text">Text.</param>
        /// <param name="createdDateTime">CreatedDateTime.</param>
        /// <param name="createdBy">CreatedBy.</param>
        public ContactLogComment(
            int? id = null,
            string text = null,
            DateTime? createdDateTime = null,
            Models.Staff createdBy = null)
        {
            this.Id = id;
            this.Text = text;
            this.CreatedDateTime = createdDateTime;
            this.CreatedBy = createdBy;
        }

        /// <summary>
        /// The comment’s ID.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// The comment’s body text.
        /// </summary>
        [JsonProperty("Text", NullValueHandling = NullValueHandling.Ignore)]
        public string Text { get; set; }

        /// <summary>
        /// The local time when the comment was created.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("CreatedDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? CreatedDateTime { get; set; }

        /// <summary>
        /// The Staff
        /// </summary>
        [JsonProperty("CreatedBy", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Staff CreatedBy { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ContactLogComment : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is ContactLogComment other &&                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Text == null && other.Text == null) || (this.Text?.Equals(other.Text) == true)) &&
                ((this.CreatedDateTime == null && other.CreatedDateTime == null) || (this.CreatedDateTime?.Equals(other.CreatedDateTime) == true)) &&
                ((this.CreatedBy == null && other.CreatedBy == null) || (this.CreatedBy?.Equals(other.CreatedBy) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Text = {(this.Text == null ? "null" : this.Text == string.Empty ? "" : this.Text)}");
            toStringOutput.Add($"this.CreatedDateTime = {(this.CreatedDateTime == null ? "null" : this.CreatedDateTime.ToString())}");
            toStringOutput.Add($"this.CreatedBy = {(this.CreatedBy == null ? "null" : this.CreatedBy.ToString())}");
        }
    }
}