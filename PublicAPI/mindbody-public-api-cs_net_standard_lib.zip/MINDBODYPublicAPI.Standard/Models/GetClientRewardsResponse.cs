// <copyright file="GetClientRewardsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetClientRewardsResponse.
    /// </summary>
    public class GetClientRewardsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetClientRewardsResponse"/> class.
        /// </summary>
        public GetClientRewardsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetClientRewardsResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="balance">Balance.</param>
        /// <param name="transactions">Transactions.</param>
        public GetClientRewardsResponse(
            Models.PaginationResponse paginationResponse = null,
            long? balance = null,
            List<Models.ClientRewardTransaction> transactions = null)
        {
            this.PaginationResponse = paginationResponse;
            this.Balance = balance;
            this.Transactions = transactions;
        }

        /// <summary>
        /// Contains information about the pagination to use.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// The total rewards points available to the indicated client after the above transaction.
        /// </summary>
        [JsonProperty("Balance", NullValueHandling = NullValueHandling.Ignore)]
        public long? Balance { get; set; }

        /// <summary>
        /// Contains information about the reward transaction details.
        /// </summary>
        [JsonProperty("Transactions", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ClientRewardTransaction> Transactions { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetClientRewardsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is GetClientRewardsResponse other &&                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.Balance == null && other.Balance == null) || (this.Balance?.Equals(other.Balance) == true)) &&
                ((this.Transactions == null && other.Transactions == null) || (this.Transactions?.Equals(other.Transactions) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.Balance = {(this.Balance == null ? "null" : this.Balance.ToString())}");
            toStringOutput.Add($"this.Transactions = {(this.Transactions == null ? "null" : $"[{string.Join(", ", this.Transactions)} ]")}");
        }
    }
}