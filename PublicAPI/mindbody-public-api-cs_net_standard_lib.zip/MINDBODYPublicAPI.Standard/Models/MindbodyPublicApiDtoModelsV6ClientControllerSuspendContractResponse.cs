// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse"/> class.
        /// </summary>
        /// <param name="contract">Contract.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse(
            Models.MindbodyPublicApiDtoModelsV6ClientContract contract = null)
        {
            this.Contract = contract;
        }

        /// <summary>
        /// Contains information about client contract.
        /// </summary>
        [JsonProperty("Contract", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6ClientContract Contract { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractResponse other &&
                ((this.Contract == null && other.Contract == null) || (this.Contract?.Equals(other.Contract) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Contract = {(this.Contract == null ? "null" : this.Contract.ToString())}");
        }
    }
}