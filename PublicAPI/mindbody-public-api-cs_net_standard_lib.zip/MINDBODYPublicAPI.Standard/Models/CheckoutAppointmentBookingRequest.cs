// <copyright file="CheckoutAppointmentBookingRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CheckoutAppointmentBookingRequest.
    /// </summary>
    public class CheckoutAppointmentBookingRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutAppointmentBookingRequest"/> class.
        /// </summary>
        public CheckoutAppointmentBookingRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CheckoutAppointmentBookingRequest"/> class.
        /// </summary>
        /// <param name="staffId">StaffId.</param>
        /// <param name="locationId">LocationId.</param>
        /// <param name="sessionTypeId">SessionTypeId.</param>
        /// <param name="resources">Resources.</param>
        /// <param name="startDateTime">StartDateTime.</param>
        /// <param name="endDateTime">EndDateTime.</param>
        /// <param name="providerId">ProviderId.</param>
        public CheckoutAppointmentBookingRequest(
            long? staffId = null,
            int? locationId = null,
            int? sessionTypeId = null,
            List<Models.ResourceSlim> resources = null,
            DateTime? startDateTime = null,
            DateTime? endDateTime = null,
            string providerId = null)
        {
            this.StaffId = staffId;
            this.LocationId = locationId;
            this.SessionTypeId = sessionTypeId;
            this.Resources = resources;
            this.StartDateTime = startDateTime;
            this.EndDateTime = endDateTime;
            this.ProviderId = providerId;
        }

        /// <summary>
        /// The ID of the staff member who is to provide the service being booked.
        /// </summary>
        [JsonProperty("StaffId", NullValueHandling = NullValueHandling.Ignore)]
        public long? StaffId { get; set; }

        /// <summary>
        /// The ID of the location where the appointment is to take place.
        /// </summary>
        [JsonProperty("LocationId", NullValueHandling = NullValueHandling.Ignore)]
        public int? LocationId { get; set; }

        /// <summary>
        /// The ID of the session type of this appointment.
        /// </summary>
        [JsonProperty("SessionTypeId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SessionTypeId { get; set; }

        /// <summary>
        /// Contains information about the resources to be used for the appointment.
        /// </summary>
        [JsonProperty("Resources", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ResourceSlim> Resources { get; set; }

        /// <summary>
        /// The date and time that the appointment is to start in the business’ timezone. This value must be passed in the format yyyy-mm-ddThh:mm:ss.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDateTime { get; set; }

        /// <summary>
        /// The date and time that the appointment is to end in the business’ timezone. This value must be passed in the format yyyy-mm-ddThh:mm:ss.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDateTime { get; set; }

        /// <summary>
        /// The National Provider Identifier (NPI) of the staff member who is to provide the service. For an explanation of Provider IDs, see [Provider IDs](https://support.mindbodyonline.com/s/article/204075743-Provider-IDs?language=en_US).
        /// </summary>
        [JsonProperty("ProviderId", NullValueHandling = NullValueHandling.Ignore)]
        public string ProviderId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CheckoutAppointmentBookingRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is CheckoutAppointmentBookingRequest other &&                ((this.StaffId == null && other.StaffId == null) || (this.StaffId?.Equals(other.StaffId) == true)) &&
                ((this.LocationId == null && other.LocationId == null) || (this.LocationId?.Equals(other.LocationId) == true)) &&
                ((this.SessionTypeId == null && other.SessionTypeId == null) || (this.SessionTypeId?.Equals(other.SessionTypeId) == true)) &&
                ((this.Resources == null && other.Resources == null) || (this.Resources?.Equals(other.Resources) == true)) &&
                ((this.StartDateTime == null && other.StartDateTime == null) || (this.StartDateTime?.Equals(other.StartDateTime) == true)) &&
                ((this.EndDateTime == null && other.EndDateTime == null) || (this.EndDateTime?.Equals(other.EndDateTime) == true)) &&
                ((this.ProviderId == null && other.ProviderId == null) || (this.ProviderId?.Equals(other.ProviderId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.StaffId = {(this.StaffId == null ? "null" : this.StaffId.ToString())}");
            toStringOutput.Add($"this.LocationId = {(this.LocationId == null ? "null" : this.LocationId.ToString())}");
            toStringOutput.Add($"this.SessionTypeId = {(this.SessionTypeId == null ? "null" : this.SessionTypeId.ToString())}");
            toStringOutput.Add($"this.Resources = {(this.Resources == null ? "null" : $"[{string.Join(", ", this.Resources)} ]")}");
            toStringOutput.Add($"this.StartDateTime = {(this.StartDateTime == null ? "null" : this.StartDateTime.ToString())}");
            toStringOutput.Add($"this.EndDateTime = {(this.EndDateTime == null ? "null" : this.EndDateTime.ToString())}");
            toStringOutput.Add($"this.ProviderId = {(this.ProviderId == null ? "null" : this.ProviderId == string.Empty ? "" : this.ProviderId)}");
        }
    }
}