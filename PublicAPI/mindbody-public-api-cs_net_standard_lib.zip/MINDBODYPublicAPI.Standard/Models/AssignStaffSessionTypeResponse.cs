// <copyright file="AssignStaffSessionTypeResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AssignStaffSessionTypeResponse.
    /// </summary>
    public class AssignStaffSessionTypeResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AssignStaffSessionTypeResponse"/> class.
        /// </summary>
        public AssignStaffSessionTypeResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AssignStaffSessionTypeResponse"/> class.
        /// </summary>
        /// <param name="staffId">StaffId.</param>
        /// <param name="sessionTypeId">SessionTypeId.</param>
        /// <param name="payRateType">PayRateType.</param>
        /// <param name="payRateAmount">PayRateAmount.</param>
        /// <param name="timeLength">TimeLength.</param>
        /// <param name="prepTime">PrepTime.</param>
        /// <param name="finishTime">FinishTime.</param>
        /// <param name="active">Active.</param>
        public AssignStaffSessionTypeResponse(
            long? staffId = null,
            int? sessionTypeId = null,
            string payRateType = null,
            double? payRateAmount = null,
            int? timeLength = null,
            int? prepTime = null,
            int? finishTime = null,
            bool? active = null)
        {
            this.StaffId = staffId;
            this.SessionTypeId = sessionTypeId;
            this.PayRateType = payRateType;
            this.PayRateAmount = payRateAmount;
            this.TimeLength = timeLength;
            this.PrepTime = prepTime;
            this.FinishTime = finishTime;
            this.Active = active;
        }

        /// <summary>
        /// Staff member assigned to the session type
        /// </summary>
        [JsonProperty("StaffId", NullValueHandling = NullValueHandling.Ignore)]
        public long? StaffId { get; set; }

        /// <summary>
        /// The session type the staff member is assigned to
        /// </summary>
        [JsonProperty("SessionTypeId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SessionTypeId { get; set; }

        /// <summary>
        /// The pay rate type name
        /// Can be: "Flat", "Percent", or "No Pay"
        /// </summary>
        [JsonProperty("PayRateType", NullValueHandling = NullValueHandling.Ignore)]
        public string PayRateType { get; set; }

        /// <summary>
        /// The pay rate amount. It is interpreted based on the value of PayRateTypeId
        /// </summary>
        [JsonProperty("PayRateAmount", NullValueHandling = NullValueHandling.Ignore)]
        public double? PayRateAmount { get; set; }

        /// <summary>
        /// The staff specific amount of time that a session of this type typically lasts.
        /// </summary>
        [JsonProperty("TimeLength", NullValueHandling = NullValueHandling.Ignore)]
        public int? TimeLength { get; set; }

        /// <summary>
        /// Prep time in minutes
        /// </summary>
        [JsonProperty("PrepTime", NullValueHandling = NullValueHandling.Ignore)]
        public int? PrepTime { get; set; }

        /// <summary>
        /// Finish time in minutes
        /// </summary>
        [JsonProperty("FinishTime", NullValueHandling = NullValueHandling.Ignore)]
        public int? FinishTime { get; set; }

        /// <summary>
        /// Whether this association is active
        /// </summary>
        [JsonProperty("Active", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Active { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AssignStaffSessionTypeResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is AssignStaffSessionTypeResponse other &&
                ((this.StaffId == null && other.StaffId == null) || (this.StaffId?.Equals(other.StaffId) == true)) &&
                ((this.SessionTypeId == null && other.SessionTypeId == null) || (this.SessionTypeId?.Equals(other.SessionTypeId) == true)) &&
                ((this.PayRateType == null && other.PayRateType == null) || (this.PayRateType?.Equals(other.PayRateType) == true)) &&
                ((this.PayRateAmount == null && other.PayRateAmount == null) || (this.PayRateAmount?.Equals(other.PayRateAmount) == true)) &&
                ((this.TimeLength == null && other.TimeLength == null) || (this.TimeLength?.Equals(other.TimeLength) == true)) &&
                ((this.PrepTime == null && other.PrepTime == null) || (this.PrepTime?.Equals(other.PrepTime) == true)) &&
                ((this.FinishTime == null && other.FinishTime == null) || (this.FinishTime?.Equals(other.FinishTime) == true)) &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.StaffId = {(this.StaffId == null ? "null" : this.StaffId.ToString())}");
            toStringOutput.Add($"this.SessionTypeId = {(this.SessionTypeId == null ? "null" : this.SessionTypeId.ToString())}");
            toStringOutput.Add($"this.PayRateType = {(this.PayRateType == null ? "null" : this.PayRateType == string.Empty ? "" : this.PayRateType)}");
            toStringOutput.Add($"this.PayRateAmount = {(this.PayRateAmount == null ? "null" : this.PayRateAmount.ToString())}");
            toStringOutput.Add($"this.TimeLength = {(this.TimeLength == null ? "null" : this.TimeLength.ToString())}");
            toStringOutput.Add($"this.PrepTime = {(this.PrepTime == null ? "null" : this.PrepTime.ToString())}");
            toStringOutput.Add($"this.FinishTime = {(this.FinishTime == null ? "null" : this.FinishTime.ToString())}");
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active.ToString())}");
        }
    }
}