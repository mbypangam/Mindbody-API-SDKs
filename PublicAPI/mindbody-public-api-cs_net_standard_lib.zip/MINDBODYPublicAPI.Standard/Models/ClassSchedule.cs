// <copyright file="ClassSchedule.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ClassSchedule.
    /// </summary>
    public class ClassSchedule
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClassSchedule"/> class.
        /// </summary>
        public ClassSchedule()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ClassSchedule"/> class.
        /// </summary>
        /// <param name="classes">Classes.</param>
        /// <param name="clients">Clients.</param>
        /// <param name="course">Course.</param>
        /// <param name="semesterId">SemesterId.</param>
        /// <param name="isAvailable">IsAvailable.</param>
        /// <param name="id">Id.</param>
        /// <param name="classDescription">ClassDescription.</param>
        /// <param name="daySunday">DaySunday.</param>
        /// <param name="dayMonday">DayMonday.</param>
        /// <param name="dayTuesday">DayTuesday.</param>
        /// <param name="dayWednesday">DayWednesday.</param>
        /// <param name="dayThursday">DayThursday.</param>
        /// <param name="dayFriday">DayFriday.</param>
        /// <param name="daySaturday">DaySaturday.</param>
        /// <param name="allowOpenEnrollment">AllowOpenEnrollment.</param>
        /// <param name="allowDateForwardEnrollment">AllowDateForwardEnrollment.</param>
        /// <param name="startTime">StartTime.</param>
        /// <param name="endTime">EndTime.</param>
        /// <param name="startDate">StartDate.</param>
        /// <param name="endDate">EndDate.</param>
        /// <param name="staff">Staff.</param>
        /// <param name="location">Location.</param>
        public ClassSchedule(
            List<Models.Class> classes = null,
            List<Models.Client> clients = null,
            Models.Course course = null,
            int? semesterId = null,
            bool? isAvailable = null,
            int? id = null,
            Models.ClassDescription classDescription = null,
            bool? daySunday = null,
            bool? dayMonday = null,
            bool? dayTuesday = null,
            bool? dayWednesday = null,
            bool? dayThursday = null,
            bool? dayFriday = null,
            bool? daySaturday = null,
            bool? allowOpenEnrollment = null,
            bool? allowDateForwardEnrollment = null,
            DateTime? startTime = null,
            DateTime? endTime = null,
            DateTime? startDate = null,
            DateTime? endDate = null,
            Models.Staff staff = null,
            Models.Location location = null)
        {
            this.Classes = classes;
            this.Clients = clients;
            this.Course = course;
            this.SemesterId = semesterId;
            this.IsAvailable = isAvailable;
            this.Id = id;
            this.ClassDescription = classDescription;
            this.DaySunday = daySunday;
            this.DayMonday = dayMonday;
            this.DayTuesday = dayTuesday;
            this.DayWednesday = dayWednesday;
            this.DayThursday = dayThursday;
            this.DayFriday = dayFriday;
            this.DaySaturday = daySaturday;
            this.AllowOpenEnrollment = allowOpenEnrollment;
            this.AllowDateForwardEnrollment = allowDateForwardEnrollment;
            this.StartTime = startTime;
            this.EndTime = endTime;
            this.StartDate = startDate;
            this.EndDate = endDate;
            this.Staff = staff;
            this.Location = location;
        }

        /// <summary>
        /// Contains information about a class.
        /// </summary>
        [JsonProperty("Classes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Class> Classes { get; set; }

        /// <summary>
        /// Contains information about clients.
        /// </summary>
        [JsonProperty("Clients", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Client> Clients { get; set; }

        /// <summary>
        /// A course.
        /// </summary>
        [JsonProperty("Course", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Course Course { get; set; }

        /// <summary>
        /// The semester ID for the enrollment (if any).
        /// </summary>
        [JsonProperty("SemesterId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SemesterId { get; set; }

        /// <summary>
        /// When `true`, indicates that the enrollment shows in consumer mode, has not started yet, and there is room in each class of the enrollment.<br />
        /// When `false`, indicates that either the enrollment does not show in consumer mode, has already started, or there is no room in some classes of the enrollment.
        /// </summary>
        [JsonProperty("IsAvailable", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsAvailable { get; set; }

        /// <summary>
        /// The unique ID of the class schedule.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Represents a class definition. The class meets at the start time, goes until the end time.
        /// </summary>
        [JsonProperty("ClassDescription", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ClassDescription ClassDescription { get; set; }

        /// <summary>
        /// When `true`, indicates that this schedule occurs on Sundays.
        /// </summary>
        [JsonProperty("DaySunday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DaySunday { get; set; }

        /// <summary>
        /// When `true`, indicates that this schedule occurs on Mondays.
        /// </summary>
        [JsonProperty("DayMonday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DayMonday { get; set; }

        /// <summary>
        /// When `true`, indicates that this schedule occurs on Tuesdays.
        /// </summary>
        [JsonProperty("DayTuesday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DayTuesday { get; set; }

        /// <summary>
        /// When `true`, indicates that this schedule occurs on Wednesdays.
        /// </summary>
        [JsonProperty("DayWednesday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DayWednesday { get; set; }

        /// <summary>
        /// When `true`, indicates that this schedule occurs on Thursdays.
        /// </summary>
        [JsonProperty("DayThursday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DayThursday { get; set; }

        /// <summary>
        /// When `true`, indicates that this schedule occurs on Fridays.
        /// </summary>
        [JsonProperty("DayFriday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DayFriday { get; set; }

        /// <summary>
        /// When `true`, indicates that this schedule occurs on Saturdays.
        /// </summary>
        [JsonProperty("DaySaturday", NullValueHandling = NullValueHandling.Ignore)]
        public bool? DaySaturday { get; set; }

        /// <summary>
        /// When `true`, indicates that the enrollment allows booking after the enrollment has started.
        /// </summary>
        [JsonProperty("AllowOpenEnrollment", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AllowOpenEnrollment { get; set; }

        /// <summary>
        /// When `true`, indicates that this the enrollment shows in consumer mode, the enrollment has not started yet, and there is room in each class of the enrollment.
        /// </summary>
        [JsonProperty("AllowDateForwardEnrollment", NullValueHandling = NullValueHandling.Ignore)]
        public bool? AllowDateForwardEnrollment { get; set; }

        /// <summary>
        /// The time this class schedule starts.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartTime { get; set; }

        /// <summary>
        /// The time this class schedule ends.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndTime { get; set; }

        /// <summary>
        /// The date this class schedule starts.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// The date this class schedule ends.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// The Staff
        /// </summary>
        [JsonProperty("Staff", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Staff Staff { get; set; }

        /// <summary>
        /// Gets or sets Location.
        /// </summary>
        [JsonProperty("Location", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Location Location { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ClassSchedule : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is ClassSchedule other &&                ((this.Classes == null && other.Classes == null) || (this.Classes?.Equals(other.Classes) == true)) &&
                ((this.Clients == null && other.Clients == null) || (this.Clients?.Equals(other.Clients) == true)) &&
                ((this.Course == null && other.Course == null) || (this.Course?.Equals(other.Course) == true)) &&
                ((this.SemesterId == null && other.SemesterId == null) || (this.SemesterId?.Equals(other.SemesterId) == true)) &&
                ((this.IsAvailable == null && other.IsAvailable == null) || (this.IsAvailable?.Equals(other.IsAvailable) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.ClassDescription == null && other.ClassDescription == null) || (this.ClassDescription?.Equals(other.ClassDescription) == true)) &&
                ((this.DaySunday == null && other.DaySunday == null) || (this.DaySunday?.Equals(other.DaySunday) == true)) &&
                ((this.DayMonday == null && other.DayMonday == null) || (this.DayMonday?.Equals(other.DayMonday) == true)) &&
                ((this.DayTuesday == null && other.DayTuesday == null) || (this.DayTuesday?.Equals(other.DayTuesday) == true)) &&
                ((this.DayWednesday == null && other.DayWednesday == null) || (this.DayWednesday?.Equals(other.DayWednesday) == true)) &&
                ((this.DayThursday == null && other.DayThursday == null) || (this.DayThursday?.Equals(other.DayThursday) == true)) &&
                ((this.DayFriday == null && other.DayFriday == null) || (this.DayFriday?.Equals(other.DayFriday) == true)) &&
                ((this.DaySaturday == null && other.DaySaturday == null) || (this.DaySaturday?.Equals(other.DaySaturday) == true)) &&
                ((this.AllowOpenEnrollment == null && other.AllowOpenEnrollment == null) || (this.AllowOpenEnrollment?.Equals(other.AllowOpenEnrollment) == true)) &&
                ((this.AllowDateForwardEnrollment == null && other.AllowDateForwardEnrollment == null) || (this.AllowDateForwardEnrollment?.Equals(other.AllowDateForwardEnrollment) == true)) &&
                ((this.StartTime == null && other.StartTime == null) || (this.StartTime?.Equals(other.StartTime) == true)) &&
                ((this.EndTime == null && other.EndTime == null) || (this.EndTime?.Equals(other.EndTime) == true)) &&
                ((this.StartDate == null && other.StartDate == null) || (this.StartDate?.Equals(other.StartDate) == true)) &&
                ((this.EndDate == null && other.EndDate == null) || (this.EndDate?.Equals(other.EndDate) == true)) &&
                ((this.Staff == null && other.Staff == null) || (this.Staff?.Equals(other.Staff) == true)) &&
                ((this.Location == null && other.Location == null) || (this.Location?.Equals(other.Location) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Classes = {(this.Classes == null ? "null" : $"[{string.Join(", ", this.Classes)} ]")}");
            toStringOutput.Add($"this.Clients = {(this.Clients == null ? "null" : $"[{string.Join(", ", this.Clients)} ]")}");
            toStringOutput.Add($"this.Course = {(this.Course == null ? "null" : this.Course.ToString())}");
            toStringOutput.Add($"this.SemesterId = {(this.SemesterId == null ? "null" : this.SemesterId.ToString())}");
            toStringOutput.Add($"this.IsAvailable = {(this.IsAvailable == null ? "null" : this.IsAvailable.ToString())}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.ClassDescription = {(this.ClassDescription == null ? "null" : this.ClassDescription.ToString())}");
            toStringOutput.Add($"this.DaySunday = {(this.DaySunday == null ? "null" : this.DaySunday.ToString())}");
            toStringOutput.Add($"this.DayMonday = {(this.DayMonday == null ? "null" : this.DayMonday.ToString())}");
            toStringOutput.Add($"this.DayTuesday = {(this.DayTuesday == null ? "null" : this.DayTuesday.ToString())}");
            toStringOutput.Add($"this.DayWednesday = {(this.DayWednesday == null ? "null" : this.DayWednesday.ToString())}");
            toStringOutput.Add($"this.DayThursday = {(this.DayThursday == null ? "null" : this.DayThursday.ToString())}");
            toStringOutput.Add($"this.DayFriday = {(this.DayFriday == null ? "null" : this.DayFriday.ToString())}");
            toStringOutput.Add($"this.DaySaturday = {(this.DaySaturday == null ? "null" : this.DaySaturday.ToString())}");
            toStringOutput.Add($"this.AllowOpenEnrollment = {(this.AllowOpenEnrollment == null ? "null" : this.AllowOpenEnrollment.ToString())}");
            toStringOutput.Add($"this.AllowDateForwardEnrollment = {(this.AllowDateForwardEnrollment == null ? "null" : this.AllowDateForwardEnrollment.ToString())}");
            toStringOutput.Add($"this.StartTime = {(this.StartTime == null ? "null" : this.StartTime.ToString())}");
            toStringOutput.Add($"this.EndTime = {(this.EndTime == null ? "null" : this.EndTime.ToString())}");
            toStringOutput.Add($"this.StartDate = {(this.StartDate == null ? "null" : this.StartDate.ToString())}");
            toStringOutput.Add($"this.EndDate = {(this.EndDate == null ? "null" : this.EndDate.ToString())}");
            toStringOutput.Add($"this.Staff = {(this.Staff == null ? "null" : this.Staff.ToString())}");
            toStringOutput.Add($"this.Location = {(this.Location == null ? "null" : this.Location.ToString())}");
        }
    }
}