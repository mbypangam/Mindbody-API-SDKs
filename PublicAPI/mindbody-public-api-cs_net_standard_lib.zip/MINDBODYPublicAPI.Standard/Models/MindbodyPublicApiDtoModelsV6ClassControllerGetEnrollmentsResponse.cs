// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="enrollments">Enrollments.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse(
            Models.MindbodyPublicApiDtoModelsV6PaginationResponse paginationResponse = null,
            List<Models.MindbodyPublicApiDtoModelsV6ClassSchedule> enrollments = null)
        {
            this.PaginationResponse = paginationResponse;
            this.Enrollments = enrollments;
        }

        /// <summary>
        /// Contains information about the pagination used.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// Contains information about the enrollments.
        /// </summary>
        [JsonProperty("Enrollments", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6ClassSchedule> Enrollments { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.Enrollments == null && other.Enrollments == null) || (this.Enrollments?.Equals(other.Enrollments) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.Enrollments = {(this.Enrollments == null ? "null" : $"[{string.Join(", ", this.Enrollments)} ]")}");
        }
    }
}