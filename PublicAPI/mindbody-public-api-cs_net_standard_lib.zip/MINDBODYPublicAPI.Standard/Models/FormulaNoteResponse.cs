// <copyright file="FormulaNoteResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// FormulaNoteResponse.
    /// </summary>
    public class FormulaNoteResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FormulaNoteResponse"/> class.
        /// </summary>
        public FormulaNoteResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FormulaNoteResponse"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="clientId">ClientId.</param>
        /// <param name="appointmentId">AppointmentId.</param>
        /// <param name="entryDate">EntryDate.</param>
        /// <param name="note">Note.</param>
        /// <param name="siteId">SiteId.</param>
        /// <param name="siteName">SiteName.</param>
        /// <param name="staffFirstName">StaffFirstName.</param>
        /// <param name="staffLastName">StaffLastName.</param>
        /// <param name="staffDisplayName">StaffDisplayName.</param>
        public FormulaNoteResponse(
            long? id = null,
            string clientId = null,
            long? appointmentId = null,
            DateTime? entryDate = null,
            string note = null,
            int? siteId = null,
            string siteName = null,
            string staffFirstName = null,
            string staffLastName = null,
            string staffDisplayName = null)
        {
            this.Id = id;
            this.ClientId = clientId;
            this.AppointmentId = appointmentId;
            this.EntryDate = entryDate;
            this.Note = note;
            this.SiteId = siteId;
            this.SiteName = siteName;
            this.StaffFirstName = staffFirstName;
            this.StaffLastName = staffLastName;
            this.StaffDisplayName = staffDisplayName;
        }

        /// <summary>
        /// The formula note ID.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public long? Id { get; set; }

        /// <summary>
        /// The unique Id of the client for the formula note. This is the unique ID for the client in the site where the formula note originated. This is different than the ClientId specified in the request, which is the id for the client assigned by the business.
        /// </summary>
        [JsonProperty("ClientId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientId { get; set; }

        /// <summary>
        /// The appointment ID that the formula note is related to.
        /// </summary>
        [JsonProperty("AppointmentId", NullValueHandling = NullValueHandling.Ignore)]
        public long? AppointmentId { get; set; }

        /// <summary>
        /// The date formula note was created.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EntryDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EntryDate { get; set; }

        /// <summary>
        /// The new formula note text.
        /// </summary>
        [JsonProperty("Note", NullValueHandling = NullValueHandling.Ignore)]
        public string Note { get; set; }

        /// <summary>
        /// The site Id.
        /// </summary>
        [JsonProperty("SiteId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SiteId { get; set; }

        /// <summary>
        /// The site name.
        /// </summary>
        [JsonProperty("SiteName", NullValueHandling = NullValueHandling.Ignore)]
        public string SiteName { get; set; }

        /// <summary>
        /// The first name of the staff for the optional associated appointment. If no appointment ID is provided, this will be null.
        /// </summary>
        [JsonProperty("StaffFirstName", NullValueHandling = NullValueHandling.Ignore)]
        public string StaffFirstName { get; set; }

        /// <summary>
        /// The last name of the staff for the optional associated appointment. If no appointment ID is provided, this will be null.
        /// </summary>
        [JsonProperty("StaffLastName", NullValueHandling = NullValueHandling.Ignore)]
        public string StaffLastName { get; set; }

        /// <summary>
        /// The display name of the staff for the optional associated appointment. If no appointment ID is provided, or no display name is specified for the staff member, this will be null.
        /// </summary>
        [JsonProperty("StaffDisplayName", NullValueHandling = NullValueHandling.Ignore)]
        public string StaffDisplayName { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"FormulaNoteResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is FormulaNoteResponse other &&                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.AppointmentId == null && other.AppointmentId == null) || (this.AppointmentId?.Equals(other.AppointmentId) == true)) &&
                ((this.EntryDate == null && other.EntryDate == null) || (this.EntryDate?.Equals(other.EntryDate) == true)) &&
                ((this.Note == null && other.Note == null) || (this.Note?.Equals(other.Note) == true)) &&
                ((this.SiteId == null && other.SiteId == null) || (this.SiteId?.Equals(other.SiteId) == true)) &&
                ((this.SiteName == null && other.SiteName == null) || (this.SiteName?.Equals(other.SiteName) == true)) &&
                ((this.StaffFirstName == null && other.StaffFirstName == null) || (this.StaffFirstName?.Equals(other.StaffFirstName) == true)) &&
                ((this.StaffLastName == null && other.StaffLastName == null) || (this.StaffLastName?.Equals(other.StaffLastName) == true)) &&
                ((this.StaffDisplayName == null && other.StaffDisplayName == null) || (this.StaffDisplayName?.Equals(other.StaffDisplayName) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId)}");
            toStringOutput.Add($"this.AppointmentId = {(this.AppointmentId == null ? "null" : this.AppointmentId.ToString())}");
            toStringOutput.Add($"this.EntryDate = {(this.EntryDate == null ? "null" : this.EntryDate.ToString())}");
            toStringOutput.Add($"this.Note = {(this.Note == null ? "null" : this.Note)}");
            toStringOutput.Add($"this.SiteId = {(this.SiteId == null ? "null" : this.SiteId.ToString())}");
            toStringOutput.Add($"this.SiteName = {(this.SiteName == null ? "null" : this.SiteName)}");
            toStringOutput.Add($"this.StaffFirstName = {(this.StaffFirstName == null ? "null" : this.StaffFirstName)}");
            toStringOutput.Add($"this.StaffLastName = {(this.StaffLastName == null ? "null" : this.StaffLastName)}");
            toStringOutput.Add($"this.StaffDisplayName = {(this.StaffDisplayName == null ? "null" : this.StaffDisplayName)}");
        }
    }
}