// <copyright file="MindbodyPublicApiCommonModelsCategory.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiCommonModelsCategory.
    /// </summary>
    public class MindbodyPublicApiCommonModelsCategory
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsCategory"/> class.
        /// </summary>
        public MindbodyPublicApiCommonModelsCategory()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsCategory"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="categoryName">CategoryName.</param>
        /// <param name="description">Description.</param>
        /// <param name="service">Service.</param>
        /// <param name="active">Active.</param>
        /// <param name="isPrimary">IsPrimary.</param>
        /// <param name="isSecondary">IsSecondary.</param>
        /// <param name="createdDateTimeUTC">CreatedDateTimeUTC.</param>
        /// <param name="modifiedDateTimeUTC">ModifiedDateTimeUTC.</param>
        /// <param name="subCategories">SubCategories.</param>
        /// <param name="totalCount">TotalCount.</param>
        public MindbodyPublicApiCommonModelsCategory(
            int? id = null,
            string categoryName = null,
            string description = null,
            bool? service = null,
            bool? active = null,
            bool? isPrimary = null,
            bool? isSecondary = null,
            DateTime? createdDateTimeUTC = null,
            DateTime? modifiedDateTimeUTC = null,
            List<Models.MindbodyPublicApiCommonModelsSubCategory> subCategories = null,
            int? totalCount = null)
        {
            this.Id = id;
            this.CategoryName = categoryName;
            this.Description = description;
            this.Service = service;
            this.Active = active;
            this.IsPrimary = isPrimary;
            this.IsSecondary = isSecondary;
            this.CreatedDateTimeUTC = createdDateTimeUTC;
            this.ModifiedDateTimeUTC = modifiedDateTimeUTC;
            this.SubCategories = subCategories;
            this.TotalCount = totalCount;
        }

        /// <summary>
        /// The category Id used for api calls.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Category Name
        /// </summary>
        [JsonProperty("CategoryName", NullValueHandling = NullValueHandling.Ignore)]
        public string CategoryName { get; set; }

        /// <summary>
        /// Category Description
        /// </summary>
        [JsonProperty("Description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <summary>
        /// Category service
        /// </summary>
        [JsonProperty("Service", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Service { get; set; }

        /// <summary>
        /// Check if Category is active.
        /// </summary>
        [JsonProperty("Active", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Active { get; set; }

        /// <summary>
        /// Check if Category is of primary type.
        /// </summary>
        [JsonProperty("IsPrimary", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsPrimary { get; set; }

        /// <summary>
        /// Check if Category is of secondary type.
        /// </summary>
        [JsonProperty("IsSecondary", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsSecondary { get; set; }

        /// <summary>
        /// Category Created DateTime UTC
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("CreatedDateTimeUTC", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? CreatedDateTimeUTC { get; set; }

        /// <summary>
        /// Category Modified DateTime UTC
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("ModifiedDateTimeUTC", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ModifiedDateTimeUTC { get; set; }

        /// <summary>
        /// List of sub categories tied with the category.
        /// </summary>
        [JsonProperty("SubCategories", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiCommonModelsSubCategory> SubCategories { get; set; }

        /// <summary>
        /// Get total number of rows
        /// </summary>
        [JsonProperty("TotalCount", NullValueHandling = NullValueHandling.Ignore)]
        public int? TotalCount { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiCommonModelsCategory : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiCommonModelsCategory other &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.CategoryName == null && other.CategoryName == null) || (this.CategoryName?.Equals(other.CategoryName) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.Service == null && other.Service == null) || (this.Service?.Equals(other.Service) == true)) &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true)) &&
                ((this.IsPrimary == null && other.IsPrimary == null) || (this.IsPrimary?.Equals(other.IsPrimary) == true)) &&
                ((this.IsSecondary == null && other.IsSecondary == null) || (this.IsSecondary?.Equals(other.IsSecondary) == true)) &&
                ((this.CreatedDateTimeUTC == null && other.CreatedDateTimeUTC == null) || (this.CreatedDateTimeUTC?.Equals(other.CreatedDateTimeUTC) == true)) &&
                ((this.ModifiedDateTimeUTC == null && other.ModifiedDateTimeUTC == null) || (this.ModifiedDateTimeUTC?.Equals(other.ModifiedDateTimeUTC) == true)) &&
                ((this.SubCategories == null && other.SubCategories == null) || (this.SubCategories?.Equals(other.SubCategories) == true)) &&
                ((this.TotalCount == null && other.TotalCount == null) || (this.TotalCount?.Equals(other.TotalCount) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.CategoryName = {(this.CategoryName == null ? "null" : this.CategoryName == string.Empty ? "" : this.CategoryName)}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.Service = {(this.Service == null ? "null" : this.Service.ToString())}");
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active.ToString())}");
            toStringOutput.Add($"this.IsPrimary = {(this.IsPrimary == null ? "null" : this.IsPrimary.ToString())}");
            toStringOutput.Add($"this.IsSecondary = {(this.IsSecondary == null ? "null" : this.IsSecondary.ToString())}");
            toStringOutput.Add($"this.CreatedDateTimeUTC = {(this.CreatedDateTimeUTC == null ? "null" : this.CreatedDateTimeUTC.ToString())}");
            toStringOutput.Add($"this.ModifiedDateTimeUTC = {(this.ModifiedDateTimeUTC == null ? "null" : this.ModifiedDateTimeUTC.ToString())}");
            toStringOutput.Add($"this.SubCategories = {(this.SubCategories == null ? "null" : $"[{string.Join(", ", this.SubCategories)} ]")}");
            toStringOutput.Add($"this.TotalCount = {(this.TotalCount == null ? "null" : this.TotalCount.ToString())}");
        }
    }
}