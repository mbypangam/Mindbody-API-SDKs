// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="contactMethod">ContactMethod.</param>
        /// <param name="assignedToStaffId">AssignedToStaffId.</param>
        /// <param name="text">Text.</param>
        /// <param name="followupByDate">FollowupByDate.</param>
        /// <param name="contactName">ContactName.</param>
        /// <param name="isComplete">IsComplete.</param>
        /// <param name="comments">Comments.</param>
        /// <param name="types">Types.</param>
        /// <param name="test">Test.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest(
            string clientId,
            string contactMethod,
            long? assignedToStaffId = null,
            string text = null,
            DateTime? followupByDate = null,
            string contactName = null,
            bool? isComplete = null,
            List<string> comments = null,
            List<Models.MindbodyPublicApiDtoModelsV6AddContactLogType> types = null,
            bool? test = null)
        {
            this.ClientId = clientId;
            this.AssignedToStaffId = assignedToStaffId;
            this.Text = text;
            this.FollowupByDate = followupByDate;
            this.ContactMethod = contactMethod;
            this.ContactName = contactName;
            this.IsComplete = isComplete;
            this.Comments = comments;
            this.Types = types;
            this.Test = test;
        }

        /// <summary>
        /// The ID of the client whose contact log is being added.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// The ID of the staff member to whom the contact log is assigned.
        /// </summary>
        [JsonProperty("AssignedToStaffId", NullValueHandling = NullValueHandling.Ignore)]
        public long? AssignedToStaffId { get; set; }

        /// <summary>
        /// The body of the contact log.
        /// </summary>
        [JsonProperty("Text", NullValueHandling = NullValueHandling.Ignore)]
        public string Text { get; set; }

        /// <summary>
        /// The date by which the assigned staff member should complete this contact log.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("FollowupByDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? FollowupByDate { get; set; }

        /// <summary>
        /// How the client wants to be contacted.
        /// </summary>
        [JsonProperty("ContactMethod")]
        public string ContactMethod { get; set; }

        /// <summary>
        /// The name of the person to be contacted by the assigned staff member.
        /// </summary>
        [JsonProperty("ContactName", NullValueHandling = NullValueHandling.Ignore)]
        public string ContactName { get; set; }

        /// <summary>
        /// When `true`, indicates that the contact log is complete.
        /// When `false`, indicates the contact log isn't complete.
        /// </summary>
        [JsonProperty("IsComplete", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsComplete { get; set; }

        /// <summary>
        /// Any comments on the contact log.
        /// </summary>
        [JsonProperty("Comments", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> Comments { get; set; }

        /// <summary>
        /// The contact log types used to tag this contact log.
        /// </summary>
        [JsonProperty("Types", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6AddContactLogType> Types { get; set; }

        /// <summary>
        /// When `true`, indicates that this is a test request and no data is inserted into the subscriber's database.<br />
        /// When `false`, the database is updated.
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerAddContactLogRequest other &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.AssignedToStaffId == null && other.AssignedToStaffId == null) || (this.AssignedToStaffId?.Equals(other.AssignedToStaffId) == true)) &&
                ((this.Text == null && other.Text == null) || (this.Text?.Equals(other.Text) == true)) &&
                ((this.FollowupByDate == null && other.FollowupByDate == null) || (this.FollowupByDate?.Equals(other.FollowupByDate) == true)) &&
                ((this.ContactMethod == null && other.ContactMethod == null) || (this.ContactMethod?.Equals(other.ContactMethod) == true)) &&
                ((this.ContactName == null && other.ContactName == null) || (this.ContactName?.Equals(other.ContactName) == true)) &&
                ((this.IsComplete == null && other.IsComplete == null) || (this.IsComplete?.Equals(other.IsComplete) == true)) &&
                ((this.Comments == null && other.Comments == null) || (this.Comments?.Equals(other.Comments) == true)) &&
                ((this.Types == null && other.Types == null) || (this.Types?.Equals(other.Types) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.AssignedToStaffId = {(this.AssignedToStaffId == null ? "null" : this.AssignedToStaffId.ToString())}");
            toStringOutput.Add($"this.Text = {(this.Text == null ? "null" : this.Text == string.Empty ? "" : this.Text)}");
            toStringOutput.Add($"this.FollowupByDate = {(this.FollowupByDate == null ? "null" : this.FollowupByDate.ToString())}");
            toStringOutput.Add($"this.ContactMethod = {(this.ContactMethod == null ? "null" : this.ContactMethod == string.Empty ? "" : this.ContactMethod)}");
            toStringOutput.Add($"this.ContactName = {(this.ContactName == null ? "null" : this.ContactName == string.Empty ? "" : this.ContactName)}");
            toStringOutput.Add($"this.IsComplete = {(this.IsComplete == null ? "null" : this.IsComplete.ToString())}");
            toStringOutput.Add($"this.Comments = {(this.Comments == null ? "null" : $"[{string.Join(", ", this.Comments)} ]")}");
            toStringOutput.Add($"this.Types = {(this.Types == null ? "null" : $"[{string.Join(", ", this.Types)} ]")}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
        }
    }
}