// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse"/> class.
        /// </summary>
        /// <param name="contract">Contract.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse(
            Models.MindbodyPublicApiDtoModelsV6ClientContract contract = null)
        {
            this.Contract = contract;
        }

        /// <summary>
        /// Contains confirmation message for the successful contract termination.
        /// </summary>
        [JsonProperty("Contract", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6ClientContract Contract { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerTerminateContractResponse other &&
                ((this.Contract == null && other.Contract == null) || (this.Contract?.Equals(other.Contract) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Contract = {(this.Contract == null ? "null" : this.Contract.ToString())}");
        }
    }
}