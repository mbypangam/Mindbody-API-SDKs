// <copyright file="GetClientAccountBalancesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetClientAccountBalancesResponse.
    /// </summary>
    public class GetClientAccountBalancesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetClientAccountBalancesResponse"/> class.
        /// </summary>
        public GetClientAccountBalancesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetClientAccountBalancesResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="clients">Clients.</param>
        public GetClientAccountBalancesResponse(
            Models.PaginationResponse paginationResponse = null,
            List<Models.Client> clients = null)
        {
            this.PaginationResponse = paginationResponse;
            this.Clients = clients;
        }

        /// <summary>
        /// Contains information about the pagination used.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// A list of clients.
        /// </summary>
        [JsonProperty("Clients", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Client> Clients { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetClientAccountBalancesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetClientAccountBalancesResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.Clients == null && other.Clients == null) || (this.Clients?.Equals(other.Clients) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.Clients = {(this.Clients == null ? "null" : $"[{string.Join(", ", this.Clients)} ]")}");
        }
    }
}