// <copyright file="GetResourcesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetResourcesResponse.
    /// </summary>
    public class GetResourcesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetResourcesResponse"/> class.
        /// </summary>
        public GetResourcesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetResourcesResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="resources">Resources.</param>
        public GetResourcesResponse(
            Models.PaginationResponse paginationResponse = null,
            List<Models.MindbodyPublicApiDtoModelsV6Resource> resources = null)
        {
            this.PaginationResponse = paginationResponse;
            this.Resources = resources;
        }

        /// <summary>
        /// Contains information about the pagination used.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// Contains information about resources as the business.
        /// </summary>
        [JsonProperty("Resources", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6Resource> Resources { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetResourcesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetResourcesResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.Resources == null && other.Resources == null) || (this.Resources?.Equals(other.Resources) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.Resources = {(this.Resources == null ? "null" : $"[{string.Join(", ", this.Resources)} ]")}");
        }
    }
}