// <copyright file="MindbodyPublicApiCommonModelsProgram.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiCommonModelsProgram.
    /// </summary>
    public class MindbodyPublicApiCommonModelsProgram
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsProgram"/> class.
        /// </summary>
        public MindbodyPublicApiCommonModelsProgram()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsProgram"/> class.
        /// </summary>
        /// <param name="cancelOffset">CancelOffset.</param>
        /// <param name="id">Id.</param>
        /// <param name="name">Name.</param>
        /// <param name="scheduleType">ScheduleType.</param>
        /// <param name="contentFormat">ContentFormat.</param>
        /// <param name="onlineBookingDisabled">OnlineBookingDisabled.</param>
        public MindbodyPublicApiCommonModelsProgram(
            int? cancelOffset = null,
            int? id = null,
            string name = null,
            Models.ScheduleType2Enum? scheduleType = null,
            Models.ContentFormatEnum? contentFormat = null,
            bool? onlineBookingDisabled = null)
        {
            this.CancelOffset = cancelOffset;
            this.Id = id;
            this.Name = name;
            this.ScheduleType = scheduleType;
            this.ContentFormat = contentFormat;
            this.OnlineBookingDisabled = onlineBookingDisabled;
        }

        /// <summary>
        /// Gets or sets CancelOffset.
        /// </summary>
        [JsonProperty("CancelOffset", NullValueHandling = NullValueHandling.Ignore)]
        public int? CancelOffset { get; set; }

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets ScheduleType.
        /// </summary>
        [JsonProperty("ScheduleType", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.ScheduleType2Enum? ScheduleType { get; set; }

        /// <summary>
        /// Gets or sets ContentFormat.
        /// </summary>
        [JsonProperty("ContentFormat", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.ContentFormatEnum? ContentFormat { get; set; }

        /// <summary>
        /// Gets or sets OnlineBookingDisabled.
        /// </summary>
        [JsonProperty("OnlineBookingDisabled", NullValueHandling = NullValueHandling.Ignore)]
        public bool? OnlineBookingDisabled { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiCommonModelsProgram : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiCommonModelsProgram other &&
                ((this.CancelOffset == null && other.CancelOffset == null) || (this.CancelOffset?.Equals(other.CancelOffset) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.ScheduleType == null && other.ScheduleType == null) || (this.ScheduleType?.Equals(other.ScheduleType) == true)) &&
                ((this.ContentFormat == null && other.ContentFormat == null) || (this.ContentFormat?.Equals(other.ContentFormat) == true)) &&
                ((this.OnlineBookingDisabled == null && other.OnlineBookingDisabled == null) || (this.OnlineBookingDisabled?.Equals(other.OnlineBookingDisabled) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.CancelOffset = {(this.CancelOffset == null ? "null" : this.CancelOffset.ToString())}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.ScheduleType = {(this.ScheduleType == null ? "null" : this.ScheduleType.ToString())}");
            toStringOutput.Add($"this.ContentFormat = {(this.ContentFormat == null ? "null" : this.ContentFormat.ToString())}");
            toStringOutput.Add($"this.OnlineBookingDisabled = {(this.OnlineBookingDisabled == null ? "null" : this.OnlineBookingDisabled.ToString())}");
        }
    }
}