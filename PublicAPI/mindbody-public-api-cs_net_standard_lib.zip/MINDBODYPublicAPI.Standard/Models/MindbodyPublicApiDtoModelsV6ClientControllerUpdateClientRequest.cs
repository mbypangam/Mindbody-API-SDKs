// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest"/> class.
        /// </summary>
        /// <param name="client">Client.</param>
        /// <param name="test">Test.</param>
        /// <param name="crossRegionalUpdate">CrossRegionalUpdate.</param>
        /// <param name="newId">NewId.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest(
            Models.MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo client,
            bool? test = null,
            bool? crossRegionalUpdate = null,
            string newId = null)
        {
            this.Client = client;
            this.Test = test;
            this.CrossRegionalUpdate = crossRegionalUpdate;
            this.NewId = newId;
        }

        /// <summary>
        /// Contains information about the client to be updated. The client ID is used to look up the existing client to update and any specified values are updated.
        /// </summary>
        [JsonProperty("Client")]
        public Models.MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo Client { get; set; }

        /// <summary>
        /// When `true`, indicates that test mode is enabled. The method is validated, but no client data is added or updated.<br />
        /// Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <summary>
        /// When `true`, the updated information is propagated to all of the region’s sites where the client has a profile.<br />
        /// When `false`, only the local client is updated.<br />
        /// Default: **true**
        /// </summary>
        [JsonProperty("CrossRegionalUpdate", NullValueHandling = NullValueHandling.Ignore)]
        public bool? CrossRegionalUpdate { get; set; }

        /// <summary>
        /// The new RSSID to be used for the client. Use `NewId` to assign a specific number to be a client’s ID. If that number is not available, the call returns an error. This RSSID must be unique within the subscriber’s site. If this is a cross-regional update, the RSSID must be unique across the region. If the requested number is already in use, an error is returned.
        /// </summary>
        [JsonProperty("NewId", NullValueHandling = NullValueHandling.Ignore)]
        public string NewId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRequest other &&
                ((this.Client == null && other.Client == null) || (this.Client?.Equals(other.Client) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true)) &&
                ((this.CrossRegionalUpdate == null && other.CrossRegionalUpdate == null) || (this.CrossRegionalUpdate?.Equals(other.CrossRegionalUpdate) == true)) &&
                ((this.NewId == null && other.NewId == null) || (this.NewId?.Equals(other.NewId) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Client = {(this.Client == null ? "null" : this.Client.ToString())}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
            toStringOutput.Add($"this.CrossRegionalUpdate = {(this.CrossRegionalUpdate == null ? "null" : this.CrossRegionalUpdate.ToString())}");
            toStringOutput.Add($"this.NewId = {(this.NewId == null ? "null" : this.NewId == string.Empty ? "" : this.NewId)}");
        }
    }
}