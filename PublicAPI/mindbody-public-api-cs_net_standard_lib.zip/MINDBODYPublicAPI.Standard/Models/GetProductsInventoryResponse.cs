// <copyright file="GetProductsInventoryResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetProductsInventoryResponse.
    /// </summary>
    public class GetProductsInventoryResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetProductsInventoryResponse"/> class.
        /// </summary>
        public GetProductsInventoryResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetProductsInventoryResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="productsInventory">ProductsInventory.</param>
        public GetProductsInventoryResponse(
            Models.PaginationResponse paginationResponse = null,
            List<Models.MindbodyPublicApiDtoModelsV6ProductsInventory> productsInventory = null)
        {
            this.PaginationResponse = paginationResponse;
            this.ProductsInventory = productsInventory;
        }

        /// <summary>
        /// Contains information about the pagination used.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// Contains information about the products inventory.
        /// </summary>
        [JsonProperty("ProductsInventory", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6ProductsInventory> ProductsInventory { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetProductsInventoryResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetProductsInventoryResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.ProductsInventory == null && other.ProductsInventory == null) || (this.ProductsInventory?.Equals(other.ProductsInventory) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.ProductsInventory = {(this.ProductsInventory == null ? "null" : $"[{string.Join(", ", this.ProductsInventory)} ]")}");
        }
    }
}