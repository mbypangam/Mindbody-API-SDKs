// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse"/> class.
        /// </summary>
        /// <param name="visit">Visit.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse(
            Models.MindbodyPublicApiDtoModelsV6Visit visit = null)
        {
            this.Visit = visit;
        }

        /// <summary>
        /// The updated visit.
        /// </summary>
        [JsonProperty("Visit", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6Visit Visit { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientVisitResponse other &&
                ((this.Visit == null && other.Visit == null) || (this.Visit?.Equals(other.Visit) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Visit = {(this.Visit == null ? "null" : this.Visit.ToString())}");
        }
    }
}