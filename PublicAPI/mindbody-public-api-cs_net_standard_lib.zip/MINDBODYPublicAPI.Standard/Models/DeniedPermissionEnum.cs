// <copyright file="DeniedPermissionEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// DeniedPermissionEnum.
    /// </summary>

    [JsonConverter(typeof(StringEnumConverter))]
    public enum DeniedPermissionEnum
    {
        /// <summary>
        /// ManageClassAndEventDescriptions.
        /// </summary>
        [EnumMember(Value = "ManageClassAndEventDescriptions")]
        ManageClassAndEventDescriptions,

        /// <summary>
        /// ManageClassSchedules.
        /// </summary>
        [EnumMember(Value = "ManageClassSchedules")]
        ManageClassSchedules,

        /// <summary>
        /// ScheduleFreeClassesAndEvents.
        /// </summary>
        [EnumMember(Value = "ScheduleFreeClassesAndEvents")]
        ScheduleFreeClassesAndEvents,

        /// <summary>
        /// ScheduleResourcesForClassesAndEvents.
        /// </summary>
        [EnumMember(Value = "ScheduleResourcesForClassesAndEvents")]
        ScheduleResourcesForClassesAndEvents,

        /// <summary>
        /// SubstituteClassAndEventTeachers.
        /// </summary>
        [EnumMember(Value = "SubstituteClassAndEventTeachers")]
        SubstituteClassAndEventTeachers,

        /// <summary>
        /// BulkEditClassSchedules.
        /// </summary>
        [EnumMember(Value = "BulkEditClassSchedules")]
        BulkEditClassSchedules,

        /// <summary>
        /// AddStaffMembers.
        /// </summary>
        [EnumMember(Value = "AddStaffMembers")]
        AddStaffMembers,

        /// <summary>
        /// ManagePersonalInfoForStaff.
        /// </summary>
        [EnumMember(Value = "ManagePersonalInfoForStaff")]
        ManagePersonalInfoForStaff,

        /// <summary>
        /// ManageStaffSettings.
        /// </summary>
        [EnumMember(Value = "ManageStaffSettings")]
        ManageStaffSettings,

        /// <summary>
        /// ManageStaffLogins.
        /// </summary>
        [EnumMember(Value = "ManageStaffLogins")]
        ManageStaffLogins,

        /// <summary>
        /// ManageStaffSchedules.
        /// </summary>
        [EnumMember(Value = "ManageStaffSchedules")]
        ManageStaffSchedules,

        /// <summary>
        /// ManageStaffPayRates.
        /// </summary>
        [EnumMember(Value = "ManageStaffPayRates")]
        ManageStaffPayRates,

        /// <summary>
        /// AccessBusinessInformationScreen.
        /// </summary>
        [EnumMember(Value = "AccessBusinessInformationScreen")]
        AccessBusinessInformationScreen,

        /// <summary>
        /// AccessGeneralSetupOptionsScreen.
        /// </summary>
        [EnumMember(Value = "AccessGeneralSetupOptionsScreen")]
        AccessGeneralSetupOptionsScreen,

        /// <summary>
        /// AccessNewsEventsScreen.
        /// </summary>
        [EnumMember(Value = "AccessNewsEventsScreen")]
        AccessNewsEventsScreen,

        /// <summary>
        /// ManageHolidays.
        /// </summary>
        [EnumMember(Value = "ManageHolidays")]
        ManageHolidays,

        /// <summary>
        /// ClassAndEventOptionsScreen.
        /// </summary>
        [EnumMember(Value = "ClassAndEventOptionsScreen")]
        ClassAndEventOptionsScreen,

        /// <summary>
        /// AppointmentOptionsScreen.
        /// </summary>
        [EnumMember(Value = "AppointmentOptionsScreen")]
        AppointmentOptionsScreen,

        /// <summary>
        /// AccessMediaManagementScreen.
        /// </summary>
        [EnumMember(Value = "AccessMediaManagementScreen")]
        AccessMediaManagementScreen,

        /// <summary>
        /// AccessMembershipSetupScreen.
        /// </summary>
        [EnumMember(Value = "AccessMembershipSetupScreen")]
        AccessMembershipSetupScreen,

        /// <summary>
        /// ManagePaymentMethods.
        /// </summary>
        [EnumMember(Value = "ManagePaymentMethods")]
        ManagePaymentMethods,

        /// <summary>
        /// ManageRoomNumbers.
        /// </summary>
        [EnumMember(Value = "ManageRoomNumbers")]
        ManageRoomNumbers,

        /// <summary>
        /// AccessResourceManagementScreen.
        /// </summary>
        [EnumMember(Value = "AccessResourceManagementScreen")]
        AccessResourceManagementScreen,

        /// <summary>
        /// AccessResourcesSchedulingTab.
        /// </summary>
        [EnumMember(Value = "AccessResourcesSchedulingTab")]
        AccessResourcesSchedulingTab,

        /// <summary>
        /// AccessLinksScreen.
        /// </summary>
        [EnumMember(Value = "AccessLinksScreen")]
        AccessLinksScreen,

        /// <summary>
        /// BulkCancelClientReservations.
        /// </summary>
        [EnumMember(Value = "BulkCancelClientReservations")]
        BulkCancelClientReservations,

        /// <summary>
        /// FindDuplicateClients.
        /// </summary>
        [EnumMember(Value = "FindDuplicateClients")]
        FindDuplicateClients,

        /// <summary>
        /// MergeDuplicateClients.
        /// </summary>
        [EnumMember(Value = "MergeDuplicateClients")]
        MergeDuplicateClients,

        /// <summary>
        /// ManageAutoEmails.
        /// </summary>
        [EnumMember(Value = "ManageAutoEmails")]
        ManageAutoEmails,

        /// <summary>
        /// ManageRevenueCategoriesForServices.
        /// </summary>
        [EnumMember(Value = "ManageRevenueCategoriesForServices")]
        ManageRevenueCategoriesForServices,

        /// <summary>
        /// ManageRevenueCategoriesForProducts.
        /// </summary>
        [EnumMember(Value = "ManageRevenueCategoriesForProducts")]
        ManageRevenueCategoriesForProducts,

        /// <summary>
        /// AccessActiveSessionTimesScreen.
        /// </summary>
        [EnumMember(Value = "AccessActiveSessionTimesScreen")]
        AccessActiveSessionTimesScreen,

        /// <summary>
        /// AccessClassSessionTypeScreens.
        /// </summary>
        [EnumMember(Value = "AccessClassSessionTypeScreens")]
        AccessClassSessionTypeScreens,

        /// <summary>
        /// AccessServiceCategoriesScreen.
        /// </summary>
        [EnumMember(Value = "AccessServiceCategoriesScreen")]
        AccessServiceCategoriesScreen,

        /// <summary>
        /// ManageSubscriberPricing.
        /// </summary>
        [EnumMember(Value = "ManageSubscriberPricing")]
        ManageSubscriberPricing,

        /// <summary>
        /// AddIntroOffersOnAcquisitionDashboard.
        /// </summary>
        [EnumMember(Value = "AddIntroOffersOnAcquisitionDashboard")]
        AddIntroOffersOnAcquisitionDashboard,

        /// <summary>
        /// ManageMindbodyNetworkSettings.
        /// </summary>
        [EnumMember(Value = "ManageMindbodyNetworkSettings")]
        ManageMindbodyNetworkSettings,

        /// <summary>
        /// ManageProducts.
        /// </summary>
        [EnumMember(Value = "ManageProducts")]
        ManageProducts,

        /// <summary>
        /// ViewProductCost.
        /// </summary>
        [EnumMember(Value = "ViewProductCost")]
        ViewProductCost,

        /// <summary>
        /// ManageMembershipSettingsForPricing.
        /// </summary>
        [EnumMember(Value = "ManageMembershipSettingsForPricing")]
        ManageMembershipSettingsForPricing,

        /// <summary>
        /// ManagePromotionCodes.
        /// </summary>
        [EnumMember(Value = "ManagePromotionCodes")]
        ManagePromotionCodes,

        /// <summary>
        /// EditSales.
        /// </summary>
        [EnumMember(Value = "EditSales")]
        EditSales,

        /// <summary>
        /// PrintProductBarcodes.
        /// </summary>
        [EnumMember(Value = "PrintProductBarcodes")]
        PrintProductBarcodes,

        /// <summary>
        /// MakeSales.
        /// </summary>
        [EnumMember(Value = "MakeSales")]
        MakeSales,

        /// <summary>
        /// AddProductsOnRetailScreen.
        /// </summary>
        [EnumMember(Value = "AddProductsOnRetailScreen")]
        AddProductsOnRetailScreen,

        /// <summary>
        /// EditSaleDateOnRetailScreen.
        /// </summary>
        [EnumMember(Value = "EditSaleDateOnRetailScreen")]
        EditSaleDateOnRetailScreen,

        /// <summary>
        /// EditSalePriceCountOnRetailScreen.
        /// </summary>
        [EnumMember(Value = "EditSalePriceCountOnRetailScreen")]
        EditSalePriceCountOnRetailScreen,

        /// <summary>
        /// EditActivationDateOnRetailScreen.
        /// </summary>
        [EnumMember(Value = "EditActivationDateOnRetailScreen")]
        EditActivationDateOnRetailScreen,

        /// <summary>
        /// ApplyCustomDiscountsOnRetailScreen.
        /// </summary>
        [EnumMember(Value = "ApplyCustomDiscountsOnRetailScreen")]
        ApplyCustomDiscountsOnRetailScreen,

        /// <summary>
        /// PayForAnotherClientOnRetailScreen.
        /// </summary>
        [EnumMember(Value = "PayForAnotherClientOnRetailScreen")]
        PayForAnotherClientOnRetailScreen,

        /// <summary>
        /// VoidEditPastSales.
        /// </summary>
        [EnumMember(Value = "VoidEditPastSales")]
        VoidEditPastSales,

        /// <summary>
        /// RefundSales.
        /// </summary>
        [EnumMember(Value = "RefundSales")]
        RefundSales,

        /// <summary>
        /// RefundSalesToCreditCards.
        /// </summary>
        [EnumMember(Value = "RefundSalesToCreditCards")]
        RefundSalesToCreditCards,

        /// <summary>
        /// LocationSwitching.
        /// </summary>
        [EnumMember(Value = "LocationSwitching")]
        LocationSwitching,

        /// <summary>
        /// PullReportsForAllLocations.
        /// </summary>
        [EnumMember(Value = "PullReportsForAllLocations")]
        PullReportsForAllLocations,

        /// <summary>
        /// LogInventory.
        /// </summary>
        [EnumMember(Value = "LogInventory")]
        LogInventory,

        /// <summary>
        /// AdjustInventory.
        /// </summary>
        [EnumMember(Value = "AdjustInventory")]
        AdjustInventory,

        /// <summary>
        /// TransferInventory.
        /// </summary>
        [EnumMember(Value = "TransferInventory")]
        TransferInventory,

        /// <summary>
        /// ManagePurchaseOrders.
        /// </summary>
        [EnumMember(Value = "ManagePurchaseOrders")]
        ManagePurchaseOrders,

        /// <summary>
        /// ManageLocationLocalization.
        /// </summary>
        [EnumMember(Value = "ManageLocationLocalization")]
        ManageLocationLocalization,

        /// <summary>
        /// ManagePermissionGroups.
        /// </summary>
        [EnumMember(Value = "ManagePermissionGroups")]
        ManagePermissionGroups,

        /// <summary>
        /// ManageConstantContactSettings.
        /// </summary>
        [EnumMember(Value = "ManageConstantContactSettings")]
        ManageConstantContactSettings,

        /// <summary>
        /// AccessServicesPricingScreen.
        /// </summary>
        [EnumMember(Value = "AccessServicesPricingScreen")]
        AccessServicesPricingScreen,

        /// <summary>
        /// ManageSemesters.
        /// </summary>
        [EnumMember(Value = "ManageSemesters")]
        ManageSemesters,

        /// <summary>
        /// ManageRetentionMarketing.
        /// </summary>
        [EnumMember(Value = "ManageRetentionMarketing")]
        ManageRetentionMarketing,

        /// <summary>
        /// ManageSubscriberSetupChecklist.
        /// </summary>
        [EnumMember(Value = "ManageSubscriberSetupChecklist")]
        ManageSubscriberSetupChecklist,

        /// <summary>
        /// ViewClassAndEventReservations.
        /// </summary>
        [EnumMember(Value = "ViewClassAndEventReservations")]
        ViewClassAndEventReservations,

        /// <summary>
        /// BookClassesAndEvents.
        /// </summary>
        [EnumMember(Value = "BookClassesAndEvents")]
        BookClassesAndEvents,

        /// <summary>
        /// BookClassesAndEventsInThePast.
        /// </summary>
        [EnumMember(Value = "BookClassesAndEventsInThePast")]
        BookClassesAndEventsInThePast,

        /// <summary>
        /// BookClassesAndEventsWithoutPayment.
        /// </summary>
        [EnumMember(Value = "BookClassesAndEventsWithoutPayment")]
        BookClassesAndEventsWithoutPayment,

        /// <summary>
        /// CancelClassesAndEvents.
        /// </summary>
        [EnumMember(Value = "CancelClassesAndEvents")]
        CancelClassesAndEvents,

        /// <summary>
        /// ManageClassNotes.
        /// </summary>
        [EnumMember(Value = "ManageClassNotes")]
        ManageClassNotes,

        /// <summary>
        /// ViewAppointmentSchedule.
        /// </summary>
        [EnumMember(Value = "ViewAppointmentSchedule")]
        ViewAppointmentSchedule,

        /// <summary>
        /// ViewPersonalAppointmentSchedule.
        /// </summary>
        [EnumMember(Value = "ViewPersonalAppointmentSchedule")]
        ViewPersonalAppointmentSchedule,

        /// <summary>
        /// EditPersonalAppointmentSchedule.
        /// </summary>
        [EnumMember(Value = "EditPersonalAppointmentSchedule")]
        EditPersonalAppointmentSchedule,

        /// <summary>
        /// ViewAppointmentDetails.
        /// </summary>
        [EnumMember(Value = "ViewAppointmentDetails")]
        ViewAppointmentDetails,

        /// <summary>
        /// ManageAppointmentRequests.
        /// </summary>
        [EnumMember(Value = "ManageAppointmentRequests")]
        ManageAppointmentRequests,

        /// <summary>
        /// BookAppointmentsForOtherStaffMembers.
        /// </summary>
        [EnumMember(Value = "BookAppointmentsForOtherStaffMembers")]
        BookAppointmentsForOtherStaffMembers,

        /// <summary>
        /// BookAppointmentsInThePast.
        /// </summary>
        [EnumMember(Value = "BookAppointmentsInThePast")]
        BookAppointmentsInThePast,

        /// <summary>
        /// ChangeAppointmentDetails.
        /// </summary>
        [EnumMember(Value = "ChangeAppointmentDetails")]
        ChangeAppointmentDetails,

        /// <summary>
        /// UseAnyAppointmentAsAnAddon.
        /// </summary>
        [EnumMember(Value = "UseAnyAppointmentAsAnAddon")]
        UseAnyAppointmentAsAnAddon,

        /// <summary>
        /// ChangeAppointmentDuration.
        /// </summary>
        [EnumMember(Value = "ChangeAppointmentDuration")]
        ChangeAppointmentDuration,

        /// <summary>
        /// CancelAppointments.
        /// </summary>
        [EnumMember(Value = "CancelAppointments")]
        CancelAppointments,

        /// <summary>
        /// ApplyPaymentToAppointments.
        /// </summary>
        [EnumMember(Value = "ApplyPaymentToAppointments")]
        ApplyPaymentToAppointments,

        /// <summary>
        /// CheckOutAppointments.
        /// </summary>
        [EnumMember(Value = "CheckOutAppointments")]
        CheckOutAppointments,

        /// <summary>
        /// OverrideAssignedPricing.
        /// </summary>
        [EnumMember(Value = "OverrideAssignedPricing")]
        OverrideAssignedPricing,

        /// <summary>
        /// ManageAppointmentColors.
        /// </summary>
        [EnumMember(Value = "ManageAppointmentColors")]
        ManageAppointmentColors,

        /// <summary>
        /// ViewAllLocationOnClientLookupScreen.
        /// </summary>
        [EnumMember(Value = "ViewAllLocationOnClientLookupScreen")]
        ViewAllLocationOnClientLookupScreen,

        /// <summary>
        /// AddClient.
        /// </summary>
        [EnumMember(Value = "AddClient")]
        AddClient,

        /// <summary>
        /// ViewClientProfileScreen.
        /// </summary>
        [EnumMember(Value = "ViewClientProfileScreen")]
        ViewClientProfileScreen,

        /// <summary>
        /// EditClientProfileScreen.
        /// </summary>
        [EnumMember(Value = "EditClientProfileScreen")]
        EditClientProfileScreen,

        /// <summary>
        /// AssignClientIndexes.
        /// </summary>
        [EnumMember(Value = "AssignClientIndexes")]
        AssignClientIndexes,

        /// <summary>
        /// ManageClientSuspensions.
        /// </summary>
        [EnumMember(Value = "ManageClientSuspensions")]
        ManageClientSuspensions,

        /// <summary>
        /// ViewClientPastVisits.
        /// </summary>
        [EnumMember(Value = "ViewClientPastVisits")]
        ViewClientPastVisits,

        /// <summary>
        /// ViewClientAccountAndPurchaseHistory.
        /// </summary>
        [EnumMember(Value = "ViewClientAccountAndPurchaseHistory")]
        ViewClientAccountAndPurchaseHistory,

        /// <summary>
        /// EditClientServiceDurationAndAssignedVisits.
        /// </summary>
        [EnumMember(Value = "EditClientServiceDurationAndAssignedVisits")]
        EditClientServiceDurationAndAssignedVisits,

        /// <summary>
        /// EditClientServiceSessionCount.
        /// </summary>
        [EnumMember(Value = "EditClientServiceSessionCount")]
        EditClientServiceSessionCount,

        /// <summary>
        /// IgnoreServiceCategoriesWhenReassigningPayment.
        /// </summary>
        [EnumMember(Value = "IgnoreServiceCategoriesWhenReassigningPayment")]
        IgnoreServiceCategoriesWhenReassigningPayment,

        /// <summary>
        /// ViewClientAutoPaySchedules.
        /// </summary>
        [EnumMember(Value = "ViewClientAutoPaySchedules")]
        ViewClientAutoPaySchedules,

        /// <summary>
        /// ManageClientAutoPaySchedules.
        /// </summary>
        [EnumMember(Value = "ManageClientAutoPaySchedules")]
        ManageClientAutoPaySchedules,

        /// <summary>
        /// ViewClientDocuments.
        /// </summary>
        [EnumMember(Value = "ViewClientDocuments")]
        ViewClientDocuments,

        /// <summary>
        /// AddClientDocuments.
        /// </summary>
        [EnumMember(Value = "AddClientDocuments")]
        AddClientDocuments,

        /// <summary>
        /// DeleteClientDocuments.
        /// </summary>
        [EnumMember(Value = "DeleteClientDocuments")]
        DeleteClientDocuments,

        /// <summary>
        /// ViewClientFutureVisits.
        /// </summary>
        [EnumMember(Value = "ViewClientFutureVisits")]
        ViewClientFutureVisits,

        /// <summary>
        /// ViewClientBillingInformation.
        /// </summary>
        [EnumMember(Value = "ViewClientBillingInformation")]
        ViewClientBillingInformation,

        /// <summary>
        /// EditClientBillingInformation.
        /// </summary>
        [EnumMember(Value = "EditClientBillingInformation")]
        EditClientBillingInformation,

        /// <summary>
        /// ManageClientLogins.
        /// </summary>
        [EnumMember(Value = "ManageClientLogins")]
        ManageClientLogins,

        /// <summary>
        /// UnassignClientGiftCards.
        /// </summary>
        [EnumMember(Value = "UnassignClientGiftCards")]
        UnassignClientGiftCards,

        /// <summary>
        /// IgnoreCancellationPolicy.
        /// </summary>
        [EnumMember(Value = "IgnoreCancellationPolicy")]
        IgnoreCancellationPolicy,

        /// <summary>
        /// LaunchSignInScreen.
        /// </summary>
        [EnumMember(Value = "LaunchSignInScreen")]
        LaunchSignInScreen,

        /// <summary>
        /// DeleteAndTerminateClientContracts.
        /// </summary>
        [EnumMember(Value = "DeleteAndTerminateClientContracts")]
        DeleteAndTerminateClientContracts,

        /// <summary>
        /// ReleaseContractDeposits.
        /// </summary>
        [EnumMember(Value = "ReleaseContractDeposits")]
        ReleaseContractDeposits,

        /// <summary>
        /// AutoRenewAndSuspendContracts.
        /// </summary>
        [EnumMember(Value = "AutoRenewAndSuspendContracts")]
        AutoRenewAndSuspendContracts,

        /// <summary>
        /// ManageClassTests.
        /// </summary>
        [EnumMember(Value = "ManageClassTests")]
        ManageClassTests,

        /// <summary>
        /// ScheduleClassTests.
        /// </summary>
        [EnumMember(Value = "ScheduleClassTests")]
        ScheduleClassTests,

        /// <summary>
        /// ManageClientRequiredFields.
        /// </summary>
        [EnumMember(Value = "ManageClientRequiredFields")]
        ManageClientRequiredFields,

        /// <summary>
        /// ManageClientAlerts.
        /// </summary>
        [EnumMember(Value = "ManageClientAlerts")]
        ManageClientAlerts,

        /// <summary>
        /// ManageClientTypesAndClientIndexes.
        /// </summary>
        [EnumMember(Value = "ManageClientTypesAndClientIndexes")]
        ManageClientTypesAndClientIndexes,

        /// <summary>
        /// ManageClientReferralTypes.
        /// </summary>
        [EnumMember(Value = "ManageClientReferralTypes")]
        ManageClientReferralTypes,

        /// <summary>
        /// ManageClientRelationshipTypes.
        /// </summary>
        [EnumMember(Value = "ManageClientRelationshipTypes")]
        ManageClientRelationshipTypes,

        /// <summary>
        /// ManageClientGenders.
        /// </summary>
        [EnumMember(Value = "ManageClientGenders")]
        ManageClientGenders,

        /// <summary>
        /// ClientAcquisitionAndAnalyticsDashboards.
        /// </summary>
        [EnumMember(Value = "ClientAcquisitionAndAnalyticsDashboards")]
        ClientAcquisitionAndAnalyticsDashboards,

        /// <summary>
        /// ViewRetentionMarketingDashboard.
        /// </summary>
        [EnumMember(Value = "ViewRetentionMarketingDashboard")]
        ViewRetentionMarketingDashboard,

        /// <summary>
        /// ExportReports.
        /// </summary>
        [EnumMember(Value = "ExportReports")]
        ExportReports,

        /// <summary>
        /// ManageTaggedClients.
        /// </summary>
        [EnumMember(Value = "ManageTaggedClients")]
        ManageTaggedClients,

        /// <summary>
        /// StaffPhoneBookReport.
        /// </summary>
        [EnumMember(Value = "StaffPhoneBookReport")]
        StaffPhoneBookReport,

        /// <summary>
        /// ScheduleAtAGlanceReportForAllStaff.
        /// </summary>
        [EnumMember(Value = "ScheduleAtAGlanceReportForAllStaff")]
        ScheduleAtAGlanceReportForAllStaff,

        /// <summary>
        /// PersonalScheduleAtAGlanceReport.
        /// </summary>
        [EnumMember(Value = "PersonalScheduleAtAGlanceReport")]
        PersonalScheduleAtAGlanceReport,

        /// <summary>
        /// AttendanceWithRevenueReport.
        /// </summary>
        [EnumMember(Value = "AttendanceWithRevenueReport")]
        AttendanceWithRevenueReport,

        /// <summary>
        /// CancellationsReport.
        /// </summary>
        [EnumMember(Value = "CancellationsReport")]
        CancellationsReport,

        /// <summary>
        /// PersonalCancellationsReport.
        /// </summary>
        [EnumMember(Value = "PersonalCancellationsReport")]
        PersonalCancellationsReport,

        /// <summary>
        /// AccountBalancesReport.
        /// </summary>
        [EnumMember(Value = "AccountBalancesReport")]
        AccountBalancesReport,

        /// <summary>
        /// BulkAutoPaySchedulingFromAccountBalancesReport.
        /// </summary>
        [EnumMember(Value = "BulkAutoPaySchedulingFromAccountBalancesReport")]
        BulkAutoPaySchedulingFromAccountBalancesReport,

        /// <summary>
        /// EventInvoicesReport.
        /// </summary>
        [EnumMember(Value = "EventInvoicesReport")]
        EventInvoicesReport,

        /// <summary>
        /// CashDrawerReportCurrentDate.
        /// </summary>
        [EnumMember(Value = "CashDrawerReportCurrentDate")]
        CashDrawerReportCurrentDate,

        /// <summary>
        /// CashDrawerReportAnyDate.
        /// </summary>
        [EnumMember(Value = "CashDrawerReportAnyDate")]
        CashDrawerReportAnyDate,

        /// <summary>
        /// DailyCloseoutReport.
        /// </summary>
        [EnumMember(Value = "DailyCloseoutReport")]
        DailyCloseoutReport,

        /// <summary>
        /// SalesReports.
        /// </summary>
        [EnumMember(Value = "SalesReports")]
        SalesReports,

        /// <summary>
        /// SalesBySupplierAndProductReports.
        /// </summary>
        [EnumMember(Value = "SalesBySupplierAndProductReports")]
        SalesBySupplierAndProductReports,

        /// <summary>
        /// PromoteFeesReport.
        /// </summary>
        [EnumMember(Value = "PromoteFeesReport")]
        PromoteFeesReport,

        /// <summary>
        /// GiftCardsReport.
        /// </summary>
        [EnumMember(Value = "GiftCardsReport")]
        GiftCardsReport,

        /// <summary>
        /// InventoryReports.
        /// </summary>
        [EnumMember(Value = "InventoryReports")]
        InventoryReports,

        /// <summary>
        /// MarketingReports.
        /// </summary>
        [EnumMember(Value = "MarketingReports")]
        MarketingReports,

        /// <summary>
        /// AnalysisReports.
        /// </summary>
        [EnumMember(Value = "AnalysisReports")]
        AnalysisReports,

        /// <summary>
        /// ClientIndexesReports.
        /// </summary>
        [EnumMember(Value = "ClientIndexesReports")]
        ClientIndexesReports,

        /// <summary>
        /// PayrollReportsForAllStaff.
        /// </summary>
        [EnumMember(Value = "PayrollReportsForAllStaff")]
        PayrollReportsForAllStaff,

        /// <summary>
        /// PersonalPayrollReports.
        /// </summary>
        [EnumMember(Value = "PersonalPayrollReports")]
        PersonalPayrollReports,

        /// <summary>
        /// StaffPerformanceReports.
        /// </summary>
        [EnumMember(Value = "StaffPerformanceReports")]
        StaffPerformanceReports,

        /// <summary>
        /// OnlineMetricsReport.
        /// </summary>
        [EnumMember(Value = "OnlineMetricsReport")]
        OnlineMetricsReport,

        /// <summary>
        /// RetentionManagementReport.
        /// </summary>
        [EnumMember(Value = "RetentionManagementReport")]
        RetentionManagementReport,

        /// <summary>
        /// EntryLogsReport.
        /// </summary>
        [EnumMember(Value = "EntryLogsReport")]
        EntryLogsReport,

        /// <summary>
        /// StaffActivityLogReport.
        /// </summary>
        [EnumMember(Value = "StaffActivityLogReport")]
        StaffActivityLogReport,

        /// <summary>
        /// MembershipReport.
        /// </summary>
        [EnumMember(Value = "MembershipReport")]
        MembershipReport,

        /// <summary>
        /// ManageOnlineOrdersReport.
        /// </summary>
        [EnumMember(Value = "ManageOnlineOrdersReport")]
        ManageOnlineOrdersReport,

        /// <summary>
        /// TasksReport.
        /// </summary>
        [EnumMember(Value = "TasksReport")]
        TasksReport,

        /// <summary>
        /// ClockSelfInAndOut.
        /// </summary>
        [EnumMember(Value = "ClockSelfInAndOut")]
        ClockSelfInAndOut,

        /// <summary>
        /// ClockOthersInAndOut.
        /// </summary>
        [EnumMember(Value = "ClockOthersInAndOut")]
        ClockOthersInAndOut,

        /// <summary>
        /// AccessTimeclockReport.
        /// </summary>
        [EnumMember(Value = "AccessTimeclockReport")]
        AccessTimeclockReport,

        /// <summary>
        /// ManageTimeClocks.
        /// </summary>
        [EnumMember(Value = "ManageTimeClocks")]
        ManageTimeClocks,

        /// <summary>
        /// ManageTimeClockTasks.
        /// </summary>
        [EnumMember(Value = "ManageTimeClockTasks")]
        ManageTimeClockTasks,

        /// <summary>
        /// ManageContactLogTypes.
        /// </summary>
        [EnumMember(Value = "ManageContactLogTypes")]
        ManageContactLogTypes,

        /// <summary>
        /// ViewContactLogs.
        /// </summary>
        [EnumMember(Value = "ViewContactLogs")]
        ViewContactLogs,

        /// <summary>
        /// AddContactLogs.
        /// </summary>
        [EnumMember(Value = "AddContactLogs")]
        AddContactLogs,

        /// <summary>
        /// EditOtherStaffMemberContactLogs.
        /// </summary>
        [EnumMember(Value = "EditOtherStaffMemberContactLogs")]
        EditOtherStaffMemberContactLogs,

        /// <summary>
        /// DeleteContactLogs.
        /// </summary>
        [EnumMember(Value = "DeleteContactLogs")]
        DeleteContactLogs,

        /// <summary>
        /// ContactLogAnalysisReport.
        /// </summary>
        [EnumMember(Value = "ContactLogAnalysisReport")]
        ContactLogAnalysisReport,

        /// <summary>
        /// SalesForecastReport.
        /// </summary>
        [EnumMember(Value = "SalesForecastReport")]
        SalesForecastReport,

        /// <summary>
        /// ViewAllClients.
        /// </summary>
        [EnumMember(Value = "ViewAllClients")]
        ViewAllClients,

        /// <summary>
        /// ManageClientSalesReps.
        /// </summary>
        [EnumMember(Value = "ManageClientSalesReps")]
        ManageClientSalesReps,

        /// <summary>
        /// CreateRetailTickets.
        /// </summary>
        [EnumMember(Value = "CreateRetailTickets")]
        CreateRetailTickets,

        /// <summary>
        /// EditRetailTickets.
        /// </summary>
        [EnumMember(Value = "EditRetailTickets")]
        EditRetailTickets,

        /// <summary>
        /// ManageTaskAssignments.
        /// </summary>
        [EnumMember(Value = "ManageTaskAssignments")]
        ManageTaskAssignments,

        /// <summary>
        /// MerchantAccountReports.
        /// </summary>
        [EnumMember(Value = "MerchantAccountReports")]
        MerchantAccountReports,

        /// <summary>
        /// VoidCreditCardTransactions.
        /// </summary>
        [EnumMember(Value = "VoidCreditCardTransactions")]
        VoidCreditCardTransactions,

        /// <summary>
        /// SettleCreditCardTransactions.
        /// </summary>
        [EnumMember(Value = "SettleCreditCardTransactions")]
        SettleCreditCardTransactions,

        /// <summary>
        /// UseStoredCreditCards.
        /// </summary>
        [EnumMember(Value = "UseStoredCreditCards")]
        UseStoredCreditCards,

        /// <summary>
        /// ManageAutoPays.
        /// </summary>
        [EnumMember(Value = "ManageAutoPays")]
        ManageAutoPays,

        /// <summary>
        /// ViewPersonalReviews.
        /// </summary>
        [EnumMember(Value = "ViewPersonalReviews")]
        ViewPersonalReviews,

        /// <summary>
        /// ViewOthersReviews.
        /// </summary>
        [EnumMember(Value = "ViewOthersReviews")]
        ViewOthersReviews,

        /// <summary>
        /// ViewClientNamesOnReviewReport.
        /// </summary>
        [EnumMember(Value = "ViewClientNamesOnReviewReport")]
        ViewClientNamesOnReviewReport,

        /// <summary>
        /// EmailClientsFromReviewReport.
        /// </summary>
        [EnumMember(Value = "EmailClientsFromReviewReport")]
        EmailClientsFromReviewReport,

        /// <summary>
        /// FlagReviewForRemoval.
        /// </summary>
        [EnumMember(Value = "FlagReviewForRemoval")]
        FlagReviewForRemoval,

        /// <summary>
        /// RespondPubliclyToReviews.
        /// </summary>
        [EnumMember(Value = "RespondPubliclyToReviews")]
        RespondPubliclyToReviews
    }
}