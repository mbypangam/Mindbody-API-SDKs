// <copyright file="AppointmentAddOn.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AppointmentAddOn.
    /// </summary>
    public class AppointmentAddOn
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AppointmentAddOn"/> class.
        /// </summary>
        public AppointmentAddOn()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AppointmentAddOn"/> class.
        /// </summary>
        /// <param name="id">Id.</param>
        /// <param name="name">Name.</param>
        /// <param name="numDeducted">NumDeducted.</param>
        /// <param name="categoryId">CategoryId.</param>
        /// <param name="category">Category.</param>
        public AppointmentAddOn(
            int? id = null,
            string name = null,
            int? numDeducted = null,
            int? categoryId = null,
            string category = null)
        {
            this.Id = id;
            this.Name = name;
            this.NumDeducted = numDeducted;
            this.CategoryId = categoryId;
            this.Category = category;
        }

        /// <summary>
        /// The ID of this add-on.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// The name of this add-on.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// The number of sessions that this add-on deducts from the pricing option used to pay for this add-on.
        /// </summary>
        [JsonProperty("NumDeducted", NullValueHandling = NullValueHandling.Ignore)]
        public int? NumDeducted { get; set; }

        /// <summary>
        /// This ID of this add-on’s category.
        /// </summary>
        [JsonProperty("CategoryId", NullValueHandling = NullValueHandling.Ignore)]
        public int? CategoryId { get; set; }

        /// <summary>
        /// The name of this add-on’s category.
        /// </summary>
        [JsonProperty("Category", NullValueHandling = NullValueHandling.Ignore)]
        public string Category { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AppointmentAddOn : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AppointmentAddOn other &&                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.NumDeducted == null && other.NumDeducted == null) || (this.NumDeducted?.Equals(other.NumDeducted) == true)) &&
                ((this.CategoryId == null && other.CategoryId == null) || (this.CategoryId?.Equals(other.CategoryId) == true)) &&
                ((this.Category == null && other.Category == null) || (this.Category?.Equals(other.Category) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name)}");
            toStringOutput.Add($"this.NumDeducted = {(this.NumDeducted == null ? "null" : this.NumDeducted.ToString())}");
            toStringOutput.Add($"this.CategoryId = {(this.CategoryId == null ? "null" : this.CategoryId.ToString())}");
            toStringOutput.Add($"this.Category = {(this.Category == null ? "null" : this.Category)}");
        }
    }
}