// <copyright file="BookingStatusEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// BookingStatusEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum BookingStatusEnum
    {
        /// <summary>
        /// PaymentRequired.
        /// </summary>
        [EnumMember(Value = "PaymentRequired")]
        PaymentRequired,

        /// <summary>
        /// BookAndPayLater.
        /// </summary>
        [EnumMember(Value = "BookAndPayLater")]
        BookAndPayLater,

        /// <summary>
        /// Free.
        /// </summary>
        [EnumMember(Value = "Free")]
        Free
    }
}