// <copyright file="GetPickASpotClassResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetPickASpotClassResponse.
    /// </summary>
    public class GetPickASpotClassResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetPickASpotClassResponse"/> class.
        /// </summary>
        public GetPickASpotClassResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetPickASpotClassResponse"/> class.
        /// </summary>
        /// <param name="classes">classes.</param>
        /// <param name="pagination">pagination.</param>
        /// <param name="responseDetails">responseDetails.</param>
        public GetPickASpotClassResponse(
            List<Models.PickASpotClass> classes = null,
            Models.Pagination pagination = null,
            Models.ResponseDetails responseDetails = null)
        {
            this.Classes = classes;
            this.Pagination = pagination;
            this.ResponseDetails = responseDetails;
        }

        /// <summary>
        /// Pick A Spot classes information.
        /// </summary>
        [JsonProperty("classes", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.PickASpotClass> Classes { get; set; }

        /// <summary>
        /// Contains information about the pagination used.
        /// </summary>
        [JsonProperty("pagination", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Pagination Pagination { get; set; }

        /// <summary>
        /// Contains information about the response details.
        /// </summary>
        [JsonProperty("responseDetails", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseDetails ResponseDetails { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetPickASpotClassResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetPickASpotClassResponse other &&
                ((this.Classes == null && other.Classes == null) || (this.Classes?.Equals(other.Classes) == true)) &&
                ((this.Pagination == null && other.Pagination == null) || (this.Pagination?.Equals(other.Pagination) == true)) &&
                ((this.ResponseDetails == null && other.ResponseDetails == null) || (this.ResponseDetails?.Equals(other.ResponseDetails) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Classes = {(this.Classes == null ? "null" : $"[{string.Join(", ", this.Classes)} ]")}");
            toStringOutput.Add($"this.Pagination = {(this.Pagination == null ? "null" : this.Pagination.ToString())}");
            toStringOutput.Add($"this.ResponseDetails = {(this.ResponseDetails == null ? "null" : this.ResponseDetails.ToString())}");
        }
    }
}