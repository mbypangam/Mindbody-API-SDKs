// <copyright file="MindbodyPublicApiCommonModelsLocation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiCommonModelsLocation.
    /// </summary>
    public class MindbodyPublicApiCommonModelsLocation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsLocation"/> class.
        /// </summary>
        public MindbodyPublicApiCommonModelsLocation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiCommonModelsLocation"/> class.
        /// </summary>
        /// <param name="businessId">BusinessId.</param>
        /// <param name="siteId">SiteId.</param>
        /// <param name="businessDescription">BusinessDescription.</param>
        /// <param name="additionalImageURLs">AdditionalImageURLs.</param>
        /// <param name="facilitySquareFeet">FacilitySquareFeet.</param>
        /// <param name="proSpaFinderSite">ProSpaFinderSite.</param>
        /// <param name="hasClasses">HasClasses.</param>
        /// <param name="phoneExtension">PhoneExtension.</param>
        /// <param name="action">Action.</param>
        /// <param name="id">Id.</param>
        /// <param name="name">Name.</param>
        /// <param name="address">Address.</param>
        /// <param name="address2">Address2.</param>
        /// <param name="tax1">Tax1.</param>
        /// <param name="tax2">Tax2.</param>
        /// <param name="tax3">Tax3.</param>
        /// <param name="tax4">Tax4.</param>
        /// <param name="tax5">Tax5.</param>
        /// <param name="phone">Phone.</param>
        /// <param name="city">City.</param>
        /// <param name="stateProvCode">StateProvCode.</param>
        /// <param name="postalCode">PostalCode.</param>
        /// <param name="latitude">Latitude.</param>
        /// <param name="longitude">Longitude.</param>
        /// <param name="distanceInMiles">DistanceInMiles.</param>
        /// <param name="imageURL">ImageURL.</param>
        /// <param name="description">Description.</param>
        /// <param name="hasSite">HasSite.</param>
        /// <param name="canBook">CanBook.</param>
        /// <param name="numberTreatmentRooms">NumberTreatmentRooms.</param>
        /// <param name="active">Active.</param>
        /// <param name="invActive">InvActive.</param>
        /// <param name="wsShow">WsShow.</param>
        /// <param name="email">Email.</param>
        /// <param name="contactName">ContactName.</param>
        /// <param name="shipAddress">ShipAddress.</param>
        /// <param name="shipState">ShipState.</param>
        /// <param name="shipPostal">ShipPostal.</param>
        /// <param name="shipPhone">ShipPhone.</param>
        /// <param name="shipPOC">ShipPOC.</param>
        /// <param name="taxGrouping">TaxGrouping.</param>
        /// <param name="labelTax1">LabelTax1.</param>
        /// <param name="labelTax2">LabelTax2.</param>
        /// <param name="labelTax3">LabelTax3.</param>
        /// <param name="labelTax4">LabelTax4.</param>
        /// <param name="labelTax5">LabelTax5.</param>
        /// <param name="wAC">WAC.</param>
        /// <param name="shipAddress2">ShipAddress2.</param>
        /// <param name="masterLocId">MasterLocId.</param>
        /// <param name="streetAddress">StreetAddress.</param>
        /// <param name="country">Country.</param>
        /// <param name="ext">Ext.</param>
        /// <param name="amenities">Amenities.</param>
        /// <param name="totalNumberOfDeals">TotalNumberOfDeals.</param>
        /// <param name="totalNumberOfRatings">TotalNumberOfRatings.</param>
        /// <param name="averageRating">AverageRating.</param>
        public MindbodyPublicApiCommonModelsLocation(
            int? businessId = null,
            int? siteId = null,
            string businessDescription = null,
            List<string> additionalImageURLs = null,
            int? facilitySquareFeet = null,
            bool? proSpaFinderSite = null,
            bool? hasClasses = null,
            string phoneExtension = null,
            Models.ActionEnum? action = null,
            int? id = null,
            string name = null,
            string address = null,
            string address2 = null,
            double? tax1 = null,
            double? tax2 = null,
            double? tax3 = null,
            double? tax4 = null,
            double? tax5 = null,
            string phone = null,
            string city = null,
            string stateProvCode = null,
            string postalCode = null,
            double? latitude = null,
            double? longitude = null,
            double? distanceInMiles = null,
            string imageURL = null,
            string description = null,
            bool? hasSite = null,
            bool? canBook = null,
            int? numberTreatmentRooms = null,
            bool? active = null,
            bool? invActive = null,
            bool? wsShow = null,
            string email = null,
            string contactName = null,
            string shipAddress = null,
            string shipState = null,
            string shipPostal = null,
            string shipPhone = null,
            string shipPOC = null,
            bool? taxGrouping = null,
            string labelTax1 = null,
            string labelTax2 = null,
            string labelTax3 = null,
            string labelTax4 = null,
            string labelTax5 = null,
            bool? wAC = null,
            string shipAddress2 = null,
            int? masterLocId = null,
            string streetAddress = null,
            string country = null,
            string ext = null,
            List<Models.MindbodyPublicApiCommonModelsAmenity> amenities = null,
            long? totalNumberOfDeals = null,
            int? totalNumberOfRatings = null,
            double? averageRating = null)
        {
            this.BusinessId = businessId;
            this.SiteId = siteId;
            this.BusinessDescription = businessDescription;
            this.AdditionalImageURLs = additionalImageURLs;
            this.FacilitySquareFeet = facilitySquareFeet;
            this.ProSpaFinderSite = proSpaFinderSite;
            this.HasClasses = hasClasses;
            this.PhoneExtension = phoneExtension;
            this.Action = action;
            this.Id = id;
            this.Name = name;
            this.Address = address;
            this.Address2 = address2;
            this.Tax1 = tax1;
            this.Tax2 = tax2;
            this.Tax3 = tax3;
            this.Tax4 = tax4;
            this.Tax5 = tax5;
            this.Phone = phone;
            this.City = city;
            this.StateProvCode = stateProvCode;
            this.PostalCode = postalCode;
            this.Latitude = latitude;
            this.Longitude = longitude;
            this.DistanceInMiles = distanceInMiles;
            this.ImageURL = imageURL;
            this.Description = description;
            this.HasSite = hasSite;
            this.CanBook = canBook;
            this.NumberTreatmentRooms = numberTreatmentRooms;
            this.Active = active;
            this.InvActive = invActive;
            this.WsShow = wsShow;
            this.Email = email;
            this.ContactName = contactName;
            this.ShipAddress = shipAddress;
            this.ShipState = shipState;
            this.ShipPostal = shipPostal;
            this.ShipPhone = shipPhone;
            this.ShipPOC = shipPOC;
            this.TaxGrouping = taxGrouping;
            this.LabelTax1 = labelTax1;
            this.LabelTax2 = labelTax2;
            this.LabelTax3 = labelTax3;
            this.LabelTax4 = labelTax4;
            this.LabelTax5 = labelTax5;
            this.WAC = wAC;
            this.ShipAddress2 = shipAddress2;
            this.MasterLocId = masterLocId;
            this.StreetAddress = streetAddress;
            this.Country = country;
            this.Ext = ext;
            this.Amenities = amenities;
            this.TotalNumberOfDeals = totalNumberOfDeals;
            this.TotalNumberOfRatings = totalNumberOfRatings;
            this.AverageRating = averageRating;
        }

        /// <summary>
        /// Gets or sets BusinessId.
        /// </summary>
        [JsonProperty("BusinessId", NullValueHandling = NullValueHandling.Ignore)]
        public int? BusinessId { get; set; }

        /// <summary>
        /// Gets or sets SiteId.
        /// </summary>
        [JsonProperty("SiteId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SiteId { get; set; }

        /// <summary>
        /// Gets or sets BusinessDescription.
        /// </summary>
        [JsonProperty("BusinessDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessDescription { get; set; }

        /// <summary>
        /// Gets or sets AdditionalImageURLs.
        /// </summary>
        [JsonProperty("AdditionalImageURLs", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> AdditionalImageURLs { get; set; }

        /// <summary>
        /// Gets or sets FacilitySquareFeet.
        /// </summary>
        [JsonProperty("FacilitySquareFeet", NullValueHandling = NullValueHandling.Ignore)]
        public int? FacilitySquareFeet { get; set; }

        /// <summary>
        /// Gets or sets ProSpaFinderSite.
        /// </summary>
        [JsonProperty("ProSpaFinderSite", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ProSpaFinderSite { get; set; }

        /// <summary>
        /// Gets or sets HasClasses.
        /// </summary>
        [JsonProperty("HasClasses", NullValueHandling = NullValueHandling.Ignore)]
        public bool? HasClasses { get; set; }

        /// <summary>
        /// Gets or sets PhoneExtension.
        /// </summary>
        [JsonProperty("PhoneExtension", NullValueHandling = NullValueHandling.Ignore)]
        public string PhoneExtension { get; set; }

        /// <summary>
        /// Gets or sets Action.
        /// </summary>
        [JsonProperty("Action", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.ActionEnum? Action { get; set; }

        /// <summary>
        /// Gets or sets Id.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Address.
        /// </summary>
        [JsonProperty("Address", NullValueHandling = NullValueHandling.Ignore)]
        public string Address { get; set; }

        /// <summary>
        /// Gets or sets Address2.
        /// </summary>
        [JsonProperty("Address2", NullValueHandling = NullValueHandling.Ignore)]
        public string Address2 { get; set; }

        /// <summary>
        /// Gets or sets Tax1.
        /// </summary>
        [JsonProperty("Tax1", NullValueHandling = NullValueHandling.Ignore)]
        public double? Tax1 { get; set; }

        /// <summary>
        /// Gets or sets Tax2.
        /// </summary>
        [JsonProperty("Tax2", NullValueHandling = NullValueHandling.Ignore)]
        public double? Tax2 { get; set; }

        /// <summary>
        /// Gets or sets Tax3.
        /// </summary>
        [JsonProperty("Tax3", NullValueHandling = NullValueHandling.Ignore)]
        public double? Tax3 { get; set; }

        /// <summary>
        /// Gets or sets Tax4.
        /// </summary>
        [JsonProperty("Tax4", NullValueHandling = NullValueHandling.Ignore)]
        public double? Tax4 { get; set; }

        /// <summary>
        /// Gets or sets Tax5.
        /// </summary>
        [JsonProperty("Tax5", NullValueHandling = NullValueHandling.Ignore)]
        public double? Tax5 { get; set; }

        /// <summary>
        /// Gets or sets Phone.
        /// </summary>
        [JsonProperty("Phone", NullValueHandling = NullValueHandling.Ignore)]
        public string Phone { get; set; }

        /// <summary>
        /// Gets or sets City.
        /// </summary>
        [JsonProperty("City", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets StateProvCode.
        /// </summary>
        [JsonProperty("StateProvCode", NullValueHandling = NullValueHandling.Ignore)]
        public string StateProvCode { get; set; }

        /// <summary>
        /// Gets or sets PostalCode.
        /// </summary>
        [JsonProperty("PostalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        /// <summary>
        /// Gets or sets Latitude.
        /// </summary>
        [JsonProperty("Latitude", NullValueHandling = NullValueHandling.Ignore)]
        public double? Latitude { get; set; }

        /// <summary>
        /// Gets or sets Longitude.
        /// </summary>
        [JsonProperty("Longitude", NullValueHandling = NullValueHandling.Ignore)]
        public double? Longitude { get; set; }

        /// <summary>
        /// Gets or sets DistanceInMiles.
        /// </summary>
        [JsonProperty("DistanceInMiles", NullValueHandling = NullValueHandling.Ignore)]
        public double? DistanceInMiles { get; set; }

        /// <summary>
        /// Gets or sets ImageURL.
        /// </summary>
        [JsonProperty("ImageURL", NullValueHandling = NullValueHandling.Ignore)]
        public string ImageURL { get; set; }

        /// <summary>
        /// Gets or sets Description.
        /// </summary>
        [JsonProperty("Description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets HasSite.
        /// </summary>
        [JsonProperty("HasSite", NullValueHandling = NullValueHandling.Ignore)]
        public bool? HasSite { get; set; }

        /// <summary>
        /// Gets or sets CanBook.
        /// </summary>
        [JsonProperty("CanBook", NullValueHandling = NullValueHandling.Ignore)]
        public bool? CanBook { get; set; }

        /// <summary>
        /// Gets or sets NumberTreatmentRooms.
        /// </summary>
        [JsonProperty("NumberTreatmentRooms", NullValueHandling = NullValueHandling.Ignore)]
        public int? NumberTreatmentRooms { get; set; }

        /// <summary>
        /// Gets or sets Active.
        /// </summary>
        [JsonProperty("Active", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Active { get; set; }

        /// <summary>
        /// Gets or sets InvActive.
        /// </summary>
        [JsonProperty("InvActive", NullValueHandling = NullValueHandling.Ignore)]
        public bool? InvActive { get; set; }

        /// <summary>
        /// Gets or sets WsShow.
        /// </summary>
        [JsonProperty("WsShow", NullValueHandling = NullValueHandling.Ignore)]
        public bool? WsShow { get; set; }

        /// <summary>
        /// Gets or sets Email.
        /// </summary>
        [JsonProperty("Email", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets ContactName.
        /// </summary>
        [JsonProperty("ContactName", NullValueHandling = NullValueHandling.Ignore)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets ShipAddress.
        /// </summary>
        [JsonProperty("ShipAddress", NullValueHandling = NullValueHandling.Ignore)]
        public string ShipAddress { get; set; }

        /// <summary>
        /// Gets or sets ShipState.
        /// </summary>
        [JsonProperty("ShipState", NullValueHandling = NullValueHandling.Ignore)]
        public string ShipState { get; set; }

        /// <summary>
        /// Gets or sets ShipPostal.
        /// </summary>
        [JsonProperty("ShipPostal", NullValueHandling = NullValueHandling.Ignore)]
        public string ShipPostal { get; set; }

        /// <summary>
        /// Gets or sets ShipPhone.
        /// </summary>
        [JsonProperty("ShipPhone", NullValueHandling = NullValueHandling.Ignore)]
        public string ShipPhone { get; set; }

        /// <summary>
        /// Gets or sets ShipPOC.
        /// </summary>
        [JsonProperty("ShipPOC", NullValueHandling = NullValueHandling.Ignore)]
        public string ShipPOC { get; set; }

        /// <summary>
        /// Gets or sets TaxGrouping.
        /// </summary>
        [JsonProperty("TaxGrouping", NullValueHandling = NullValueHandling.Ignore)]
        public bool? TaxGrouping { get; set; }

        /// <summary>
        /// Gets or sets LabelTax1.
        /// </summary>
        [JsonProperty("LabelTax1", NullValueHandling = NullValueHandling.Ignore)]
        public string LabelTax1 { get; set; }

        /// <summary>
        /// Gets or sets LabelTax2.
        /// </summary>
        [JsonProperty("LabelTax2", NullValueHandling = NullValueHandling.Ignore)]
        public string LabelTax2 { get; set; }

        /// <summary>
        /// Gets or sets LabelTax3.
        /// </summary>
        [JsonProperty("LabelTax3", NullValueHandling = NullValueHandling.Ignore)]
        public string LabelTax3 { get; set; }

        /// <summary>
        /// Gets or sets LabelTax4.
        /// </summary>
        [JsonProperty("LabelTax4", NullValueHandling = NullValueHandling.Ignore)]
        public string LabelTax4 { get; set; }

        /// <summary>
        /// Gets or sets LabelTax5.
        /// </summary>
        [JsonProperty("LabelTax5", NullValueHandling = NullValueHandling.Ignore)]
        public string LabelTax5 { get; set; }

        /// <summary>
        /// Gets or sets WAC.
        /// </summary>
        [JsonProperty("WAC", NullValueHandling = NullValueHandling.Ignore)]
        public bool? WAC { get; set; }

        /// <summary>
        /// Gets or sets ShipAddress2.
        /// </summary>
        [JsonProperty("ShipAddress2", NullValueHandling = NullValueHandling.Ignore)]
        public string ShipAddress2 { get; set; }

        /// <summary>
        /// Gets or sets MasterLocId.
        /// </summary>
        [JsonProperty("MasterLocId", NullValueHandling = NullValueHandling.Ignore)]
        public int? MasterLocId { get; set; }

        /// <summary>
        /// Gets or sets StreetAddress.
        /// </summary>
        [JsonProperty("StreetAddress", NullValueHandling = NullValueHandling.Ignore)]
        public string StreetAddress { get; set; }

        /// <summary>
        /// Gets or sets Country.
        /// </summary>
        [JsonProperty("Country", NullValueHandling = NullValueHandling.Ignore)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets Ext.
        /// </summary>
        [JsonProperty("Ext", NullValueHandling = NullValueHandling.Ignore)]
        public string Ext { get; set; }

        /// <summary>
        /// Gets or sets Amenities.
        /// </summary>
        [JsonProperty("Amenities", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiCommonModelsAmenity> Amenities { get; set; }

        /// <summary>
        /// Gets or sets TotalNumberOfDeals.
        /// </summary>
        [JsonProperty("TotalNumberOfDeals", NullValueHandling = NullValueHandling.Ignore)]
        public long? TotalNumberOfDeals { get; set; }

        /// <summary>
        /// Gets or sets TotalNumberOfRatings.
        /// </summary>
        [JsonProperty("TotalNumberOfRatings", NullValueHandling = NullValueHandling.Ignore)]
        public int? TotalNumberOfRatings { get; set; }

        /// <summary>
        /// Gets or sets AverageRating.
        /// </summary>
        [JsonProperty("AverageRating", NullValueHandling = NullValueHandling.Ignore)]
        public double? AverageRating { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiCommonModelsLocation : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiCommonModelsLocation other &&
                ((this.BusinessId == null && other.BusinessId == null) || (this.BusinessId?.Equals(other.BusinessId) == true)) &&
                ((this.SiteId == null && other.SiteId == null) || (this.SiteId?.Equals(other.SiteId) == true)) &&
                ((this.BusinessDescription == null && other.BusinessDescription == null) || (this.BusinessDescription?.Equals(other.BusinessDescription) == true)) &&
                ((this.AdditionalImageURLs == null && other.AdditionalImageURLs == null) || (this.AdditionalImageURLs?.Equals(other.AdditionalImageURLs) == true)) &&
                ((this.FacilitySquareFeet == null && other.FacilitySquareFeet == null) || (this.FacilitySquareFeet?.Equals(other.FacilitySquareFeet) == true)) &&
                ((this.ProSpaFinderSite == null && other.ProSpaFinderSite == null) || (this.ProSpaFinderSite?.Equals(other.ProSpaFinderSite) == true)) &&
                ((this.HasClasses == null && other.HasClasses == null) || (this.HasClasses?.Equals(other.HasClasses) == true)) &&
                ((this.PhoneExtension == null && other.PhoneExtension == null) || (this.PhoneExtension?.Equals(other.PhoneExtension) == true)) &&
                ((this.Action == null && other.Action == null) || (this.Action?.Equals(other.Action) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.Name == null && other.Name == null) || (this.Name?.Equals(other.Name) == true)) &&
                ((this.Address == null && other.Address == null) || (this.Address?.Equals(other.Address) == true)) &&
                ((this.Address2 == null && other.Address2 == null) || (this.Address2?.Equals(other.Address2) == true)) &&
                ((this.Tax1 == null && other.Tax1 == null) || (this.Tax1?.Equals(other.Tax1) == true)) &&
                ((this.Tax2 == null && other.Tax2 == null) || (this.Tax2?.Equals(other.Tax2) == true)) &&
                ((this.Tax3 == null && other.Tax3 == null) || (this.Tax3?.Equals(other.Tax3) == true)) &&
                ((this.Tax4 == null && other.Tax4 == null) || (this.Tax4?.Equals(other.Tax4) == true)) &&
                ((this.Tax5 == null && other.Tax5 == null) || (this.Tax5?.Equals(other.Tax5) == true)) &&
                ((this.Phone == null && other.Phone == null) || (this.Phone?.Equals(other.Phone) == true)) &&
                ((this.City == null && other.City == null) || (this.City?.Equals(other.City) == true)) &&
                ((this.StateProvCode == null && other.StateProvCode == null) || (this.StateProvCode?.Equals(other.StateProvCode) == true)) &&
                ((this.PostalCode == null && other.PostalCode == null) || (this.PostalCode?.Equals(other.PostalCode) == true)) &&
                ((this.Latitude == null && other.Latitude == null) || (this.Latitude?.Equals(other.Latitude) == true)) &&
                ((this.Longitude == null && other.Longitude == null) || (this.Longitude?.Equals(other.Longitude) == true)) &&
                ((this.DistanceInMiles == null && other.DistanceInMiles == null) || (this.DistanceInMiles?.Equals(other.DistanceInMiles) == true)) &&
                ((this.ImageURL == null && other.ImageURL == null) || (this.ImageURL?.Equals(other.ImageURL) == true)) &&
                ((this.Description == null && other.Description == null) || (this.Description?.Equals(other.Description) == true)) &&
                ((this.HasSite == null && other.HasSite == null) || (this.HasSite?.Equals(other.HasSite) == true)) &&
                ((this.CanBook == null && other.CanBook == null) || (this.CanBook?.Equals(other.CanBook) == true)) &&
                ((this.NumberTreatmentRooms == null && other.NumberTreatmentRooms == null) || (this.NumberTreatmentRooms?.Equals(other.NumberTreatmentRooms) == true)) &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true)) &&
                ((this.InvActive == null && other.InvActive == null) || (this.InvActive?.Equals(other.InvActive) == true)) &&
                ((this.WsShow == null && other.WsShow == null) || (this.WsShow?.Equals(other.WsShow) == true)) &&
                ((this.Email == null && other.Email == null) || (this.Email?.Equals(other.Email) == true)) &&
                ((this.ContactName == null && other.ContactName == null) || (this.ContactName?.Equals(other.ContactName) == true)) &&
                ((this.ShipAddress == null && other.ShipAddress == null) || (this.ShipAddress?.Equals(other.ShipAddress) == true)) &&
                ((this.ShipState == null && other.ShipState == null) || (this.ShipState?.Equals(other.ShipState) == true)) &&
                ((this.ShipPostal == null && other.ShipPostal == null) || (this.ShipPostal?.Equals(other.ShipPostal) == true)) &&
                ((this.ShipPhone == null && other.ShipPhone == null) || (this.ShipPhone?.Equals(other.ShipPhone) == true)) &&
                ((this.ShipPOC == null && other.ShipPOC == null) || (this.ShipPOC?.Equals(other.ShipPOC) == true)) &&
                ((this.TaxGrouping == null && other.TaxGrouping == null) || (this.TaxGrouping?.Equals(other.TaxGrouping) == true)) &&
                ((this.LabelTax1 == null && other.LabelTax1 == null) || (this.LabelTax1?.Equals(other.LabelTax1) == true)) &&
                ((this.LabelTax2 == null && other.LabelTax2 == null) || (this.LabelTax2?.Equals(other.LabelTax2) == true)) &&
                ((this.LabelTax3 == null && other.LabelTax3 == null) || (this.LabelTax3?.Equals(other.LabelTax3) == true)) &&
                ((this.LabelTax4 == null && other.LabelTax4 == null) || (this.LabelTax4?.Equals(other.LabelTax4) == true)) &&
                ((this.LabelTax5 == null && other.LabelTax5 == null) || (this.LabelTax5?.Equals(other.LabelTax5) == true)) &&
                ((this.WAC == null && other.WAC == null) || (this.WAC?.Equals(other.WAC) == true)) &&
                ((this.ShipAddress2 == null && other.ShipAddress2 == null) || (this.ShipAddress2?.Equals(other.ShipAddress2) == true)) &&
                ((this.MasterLocId == null && other.MasterLocId == null) || (this.MasterLocId?.Equals(other.MasterLocId) == true)) &&
                ((this.StreetAddress == null && other.StreetAddress == null) || (this.StreetAddress?.Equals(other.StreetAddress) == true)) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.Ext == null && other.Ext == null) || (this.Ext?.Equals(other.Ext) == true)) &&
                ((this.Amenities == null && other.Amenities == null) || (this.Amenities?.Equals(other.Amenities) == true)) &&
                ((this.TotalNumberOfDeals == null && other.TotalNumberOfDeals == null) || (this.TotalNumberOfDeals?.Equals(other.TotalNumberOfDeals) == true)) &&
                ((this.TotalNumberOfRatings == null && other.TotalNumberOfRatings == null) || (this.TotalNumberOfRatings?.Equals(other.TotalNumberOfRatings) == true)) &&
                ((this.AverageRating == null && other.AverageRating == null) || (this.AverageRating?.Equals(other.AverageRating) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.BusinessId = {(this.BusinessId == null ? "null" : this.BusinessId.ToString())}");
            toStringOutput.Add($"this.SiteId = {(this.SiteId == null ? "null" : this.SiteId.ToString())}");
            toStringOutput.Add($"this.BusinessDescription = {(this.BusinessDescription == null ? "null" : this.BusinessDescription == string.Empty ? "" : this.BusinessDescription)}");
            toStringOutput.Add($"this.AdditionalImageURLs = {(this.AdditionalImageURLs == null ? "null" : $"[{string.Join(", ", this.AdditionalImageURLs)} ]")}");
            toStringOutput.Add($"this.FacilitySquareFeet = {(this.FacilitySquareFeet == null ? "null" : this.FacilitySquareFeet.ToString())}");
            toStringOutput.Add($"this.ProSpaFinderSite = {(this.ProSpaFinderSite == null ? "null" : this.ProSpaFinderSite.ToString())}");
            toStringOutput.Add($"this.HasClasses = {(this.HasClasses == null ? "null" : this.HasClasses.ToString())}");
            toStringOutput.Add($"this.PhoneExtension = {(this.PhoneExtension == null ? "null" : this.PhoneExtension == string.Empty ? "" : this.PhoneExtension)}");
            toStringOutput.Add($"this.Action = {(this.Action == null ? "null" : this.Action.ToString())}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.Name = {(this.Name == null ? "null" : this.Name == string.Empty ? "" : this.Name)}");
            toStringOutput.Add($"this.Address = {(this.Address == null ? "null" : this.Address == string.Empty ? "" : this.Address)}");
            toStringOutput.Add($"this.Address2 = {(this.Address2 == null ? "null" : this.Address2 == string.Empty ? "" : this.Address2)}");
            toStringOutput.Add($"this.Tax1 = {(this.Tax1 == null ? "null" : this.Tax1.ToString())}");
            toStringOutput.Add($"this.Tax2 = {(this.Tax2 == null ? "null" : this.Tax2.ToString())}");
            toStringOutput.Add($"this.Tax3 = {(this.Tax3 == null ? "null" : this.Tax3.ToString())}");
            toStringOutput.Add($"this.Tax4 = {(this.Tax4 == null ? "null" : this.Tax4.ToString())}");
            toStringOutput.Add($"this.Tax5 = {(this.Tax5 == null ? "null" : this.Tax5.ToString())}");
            toStringOutput.Add($"this.Phone = {(this.Phone == null ? "null" : this.Phone == string.Empty ? "" : this.Phone)}");
            toStringOutput.Add($"this.City = {(this.City == null ? "null" : this.City == string.Empty ? "" : this.City)}");
            toStringOutput.Add($"this.StateProvCode = {(this.StateProvCode == null ? "null" : this.StateProvCode == string.Empty ? "" : this.StateProvCode)}");
            toStringOutput.Add($"this.PostalCode = {(this.PostalCode == null ? "null" : this.PostalCode == string.Empty ? "" : this.PostalCode)}");
            toStringOutput.Add($"this.Latitude = {(this.Latitude == null ? "null" : this.Latitude.ToString())}");
            toStringOutput.Add($"this.Longitude = {(this.Longitude == null ? "null" : this.Longitude.ToString())}");
            toStringOutput.Add($"this.DistanceInMiles = {(this.DistanceInMiles == null ? "null" : this.DistanceInMiles.ToString())}");
            toStringOutput.Add($"this.ImageURL = {(this.ImageURL == null ? "null" : this.ImageURL == string.Empty ? "" : this.ImageURL)}");
            toStringOutput.Add($"this.Description = {(this.Description == null ? "null" : this.Description == string.Empty ? "" : this.Description)}");
            toStringOutput.Add($"this.HasSite = {(this.HasSite == null ? "null" : this.HasSite.ToString())}");
            toStringOutput.Add($"this.CanBook = {(this.CanBook == null ? "null" : this.CanBook.ToString())}");
            toStringOutput.Add($"this.NumberTreatmentRooms = {(this.NumberTreatmentRooms == null ? "null" : this.NumberTreatmentRooms.ToString())}");
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active.ToString())}");
            toStringOutput.Add($"this.InvActive = {(this.InvActive == null ? "null" : this.InvActive.ToString())}");
            toStringOutput.Add($"this.WsShow = {(this.WsShow == null ? "null" : this.WsShow.ToString())}");
            toStringOutput.Add($"this.Email = {(this.Email == null ? "null" : this.Email == string.Empty ? "" : this.Email)}");
            toStringOutput.Add($"this.ContactName = {(this.ContactName == null ? "null" : this.ContactName == string.Empty ? "" : this.ContactName)}");
            toStringOutput.Add($"this.ShipAddress = {(this.ShipAddress == null ? "null" : this.ShipAddress == string.Empty ? "" : this.ShipAddress)}");
            toStringOutput.Add($"this.ShipState = {(this.ShipState == null ? "null" : this.ShipState == string.Empty ? "" : this.ShipState)}");
            toStringOutput.Add($"this.ShipPostal = {(this.ShipPostal == null ? "null" : this.ShipPostal == string.Empty ? "" : this.ShipPostal)}");
            toStringOutput.Add($"this.ShipPhone = {(this.ShipPhone == null ? "null" : this.ShipPhone == string.Empty ? "" : this.ShipPhone)}");
            toStringOutput.Add($"this.ShipPOC = {(this.ShipPOC == null ? "null" : this.ShipPOC == string.Empty ? "" : this.ShipPOC)}");
            toStringOutput.Add($"this.TaxGrouping = {(this.TaxGrouping == null ? "null" : this.TaxGrouping.ToString())}");
            toStringOutput.Add($"this.LabelTax1 = {(this.LabelTax1 == null ? "null" : this.LabelTax1 == string.Empty ? "" : this.LabelTax1)}");
            toStringOutput.Add($"this.LabelTax2 = {(this.LabelTax2 == null ? "null" : this.LabelTax2 == string.Empty ? "" : this.LabelTax2)}");
            toStringOutput.Add($"this.LabelTax3 = {(this.LabelTax3 == null ? "null" : this.LabelTax3 == string.Empty ? "" : this.LabelTax3)}");
            toStringOutput.Add($"this.LabelTax4 = {(this.LabelTax4 == null ? "null" : this.LabelTax4 == string.Empty ? "" : this.LabelTax4)}");
            toStringOutput.Add($"this.LabelTax5 = {(this.LabelTax5 == null ? "null" : this.LabelTax5 == string.Empty ? "" : this.LabelTax5)}");
            toStringOutput.Add($"this.WAC = {(this.WAC == null ? "null" : this.WAC.ToString())}");
            toStringOutput.Add($"this.ShipAddress2 = {(this.ShipAddress2 == null ? "null" : this.ShipAddress2 == string.Empty ? "" : this.ShipAddress2)}");
            toStringOutput.Add($"this.MasterLocId = {(this.MasterLocId == null ? "null" : this.MasterLocId.ToString())}");
            toStringOutput.Add($"this.StreetAddress = {(this.StreetAddress == null ? "null" : this.StreetAddress == string.Empty ? "" : this.StreetAddress)}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country == string.Empty ? "" : this.Country)}");
            toStringOutput.Add($"this.Ext = {(this.Ext == null ? "null" : this.Ext == string.Empty ? "" : this.Ext)}");
            toStringOutput.Add($"this.Amenities = {(this.Amenities == null ? "null" : $"[{string.Join(", ", this.Amenities)} ]")}");
            toStringOutput.Add($"this.TotalNumberOfDeals = {(this.TotalNumberOfDeals == null ? "null" : this.TotalNumberOfDeals.ToString())}");
            toStringOutput.Add($"this.TotalNumberOfRatings = {(this.TotalNumberOfRatings == null ? "null" : this.TotalNumberOfRatings.ToString())}");
            toStringOutput.Add($"this.AverageRating = {(this.AverageRating == null ? "null" : this.AverageRating.ToString())}");
        }
    }
}