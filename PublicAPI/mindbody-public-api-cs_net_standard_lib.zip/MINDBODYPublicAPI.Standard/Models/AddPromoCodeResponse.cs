// <copyright file="AddPromoCodeResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AddPromoCodeResponse.
    /// </summary>
    public class AddPromoCodeResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddPromoCodeResponse"/> class.
        /// </summary>
        public AddPromoCodeResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddPromoCodeResponse"/> class.
        /// </summary>
        /// <param name="promoCode">PromoCode.</param>
        public AddPromoCodeResponse(
            Models.PromoCode promoCode = null)
        {
            this.PromoCode = promoCode;
        }

        /// <summary>
        /// Gets or sets PromoCode.
        /// </summary>
        [JsonProperty("PromoCode", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PromoCode PromoCode { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddPromoCodeResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddPromoCodeResponse other &&                ((this.PromoCode == null && other.PromoCode == null) || (this.PromoCode?.Equals(other.PromoCode) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PromoCode = {(this.PromoCode == null ? "null" : this.PromoCode.ToString())}");
        }
    }
}