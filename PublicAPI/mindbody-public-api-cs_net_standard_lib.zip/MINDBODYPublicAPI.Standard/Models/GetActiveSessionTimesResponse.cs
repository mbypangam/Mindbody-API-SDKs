// <copyright file="GetActiveSessionTimesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetActiveSessionTimesResponse.
    /// </summary>
    public class GetActiveSessionTimesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetActiveSessionTimesResponse"/> class.
        /// </summary>
        public GetActiveSessionTimesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetActiveSessionTimesResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="activeSessionTimes">ActiveSessionTimes.</param>
        public GetActiveSessionTimesResponse(
            Models.PaginationResponse paginationResponse = null,
            List<string> activeSessionTimes = null)
        {
            this.PaginationResponse = paginationResponse;
            this.ActiveSessionTimes = activeSessionTimes;
        }

        /// <summary>
        /// Contains information about the pagination used.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// List of available start times for active sessions. Note the following:
        /// * The times returned represent possibilities for scheduling a session, not necessarily currently scheduled sessions.
        /// * The response includes either all schedule types or those filtered by supplying `ScheduleType` or `SessionTypeIds`.
        /// * Each session has an associated schedule type, but when you supply `SessionTypeIds`, they may map to one or more of the schedule types.
        /// </summary>
        [JsonProperty("ActiveSessionTimes", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> ActiveSessionTimes { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetActiveSessionTimesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetActiveSessionTimesResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.ActiveSessionTimes == null && other.ActiveSessionTimes == null) || (this.ActiveSessionTimes?.Equals(other.ActiveSessionTimes) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.ActiveSessionTimes = {(this.ActiveSessionTimes == null ? "null" : $"[{string.Join(", ", this.ActiveSessionTimes)} ]")}");
        }
    }
}