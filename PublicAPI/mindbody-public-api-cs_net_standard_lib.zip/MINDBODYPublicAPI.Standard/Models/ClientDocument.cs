// <copyright file="ClientDocument.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ClientDocument.
    /// </summary>
    public class ClientDocument
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ClientDocument"/> class.
        /// </summary>
        public ClientDocument()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ClientDocument"/> class.
        /// </summary>
        /// <param name="fileName">FileName.</param>
        /// <param name="mediaType">MediaType.</param>
        /// <param name="buffer">Buffer.</param>
        public ClientDocument(
            string fileName,
            string mediaType,
            string buffer)
        {
            this.FileName = fileName;
            this.MediaType = mediaType;
            this.Buffer = buffer;
        }

        /// <summary>
        /// The name of the file to be used on the client’s documents page when it is uploaded.
        /// </summary>
        [JsonProperty("FileName")]
        public string FileName { get; set; }

        /// <summary>
        /// The type of file or file extension. Possible values are:
        /// * pdf
        /// * jpg
        /// * jpeg
        /// * tif
        /// * tiff
        /// * png
        /// * doc
        /// * docx
        /// * bmp
        /// * txt
        /// * rtf
        /// * xlsx
        /// * xls
        /// * gif
        /// * zip
        /// * ppt
        /// * pptx
        /// * mov
        /// </summary>
        [JsonProperty("MediaType")]
        public string MediaType { get; set; }

        /// <summary>
        /// A Base64-encoded string representation of the file’s byte array.
        /// </summary>
        [JsonProperty("Buffer")]
        public string Buffer { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ClientDocument : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is ClientDocument other &&                ((this.FileName == null && other.FileName == null) || (this.FileName?.Equals(other.FileName) == true)) &&
                ((this.MediaType == null && other.MediaType == null) || (this.MediaType?.Equals(other.MediaType) == true)) &&
                ((this.Buffer == null && other.Buffer == null) || (this.Buffer?.Equals(other.Buffer) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.FileName = {(this.FileName == null ? "null" : this.FileName)}");
            toStringOutput.Add($"this.MediaType = {(this.MediaType == null ? "null" : this.MediaType)}");
            toStringOutput.Add($"this.Buffer = {(this.Buffer == null ? "null" : this.Buffer)}");
        }
    }
}