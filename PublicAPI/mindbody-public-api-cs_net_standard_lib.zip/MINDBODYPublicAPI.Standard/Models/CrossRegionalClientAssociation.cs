// <copyright file="CrossRegionalClientAssociation.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using APIMatic.Core.Utilities.Converters;
using MINDBODYPublicAPI.Standard;
using MINDBODYPublicAPI.Standard.Utilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MINDBODYPublicAPI.Standard.Models
{
    /// <summary>
    /// CrossRegionalClientAssociation.
    /// </summary>
    public class CrossRegionalClientAssociation
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CrossRegionalClientAssociation"/> class.
        /// </summary>
        public CrossRegionalClientAssociation()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CrossRegionalClientAssociation"/> class.
        /// </summary>
        /// <param name="siteId">SiteId.</param>
        /// <param name="clientId">ClientId.</param>
        /// <param name="uniqueId">UniqueId.</param>
        /// <param name="siteIsActive">SiteIsActive.</param>
        public CrossRegionalClientAssociation(
            int? siteId = null,
            string clientId = null,
            long? uniqueId = null,
            bool? siteIsActive = null)
        {
            this.SiteId = siteId;
            this.ClientId = clientId;
            this.UniqueId = uniqueId;
            this.SiteIsActive = siteIsActive;
        }

        /// <summary>
        /// The ID of the site to which the client belongs.
        /// </summary>
        [JsonProperty("SiteId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SiteId { get; set; }

        /// <summary>
        /// The client’s RSSID.
        /// </summary>
        [JsonProperty("ClientId", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientId { get; set; }

        /// <summary>
        /// The client’s unique ID.
        /// </summary>
        [JsonProperty("UniqueId", NullValueHandling = NullValueHandling.Ignore)]
        public long? UniqueId { get; set; }

        /// <summary>
        /// Indicates if site is active
        /// </summary>
        [JsonProperty("SiteIsActive", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SiteIsActive { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CrossRegionalClientAssociation : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is CrossRegionalClientAssociation other &&                ((this.SiteId == null && other.SiteId == null) || (this.SiteId?.Equals(other.SiteId) == true)) &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.UniqueId == null && other.UniqueId == null) || (this.UniqueId?.Equals(other.UniqueId) == true)) &&
                ((this.SiteIsActive == null && other.SiteIsActive == null) || (this.SiteIsActive?.Equals(other.SiteIsActive) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SiteId = {(this.SiteId == null ? "null" : this.SiteId.ToString())}");
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId)}");
            toStringOutput.Add($"this.UniqueId = {(this.UniqueId == null ? "null" : this.UniqueId.ToString())}");
            toStringOutput.Add($"this.SiteIsActive = {(this.SiteIsActive == null ? "null" : this.SiteIsActive.ToString())}");
        }
    }
}