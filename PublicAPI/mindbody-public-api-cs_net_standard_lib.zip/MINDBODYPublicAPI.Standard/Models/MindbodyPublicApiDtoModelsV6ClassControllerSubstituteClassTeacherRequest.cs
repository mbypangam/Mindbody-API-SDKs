// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest"/> class.
        /// </summary>
        /// <param name="classId">ClassId.</param>
        /// <param name="staffId">StaffId.</param>
        /// <param name="overrideConflicts">OverrideConflicts.</param>
        /// <param name="sendClientEmail">SendClientEmail.</param>
        /// <param name="sendOriginalTeacherEmail">SendOriginalTeacherEmail.</param>
        /// <param name="sendSubstituteTeacherEmail">SendSubstituteTeacherEmail.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest(
            int classId,
            long staffId,
            bool? overrideConflicts = null,
            bool? sendClientEmail = null,
            bool? sendOriginalTeacherEmail = null,
            bool? sendSubstituteTeacherEmail = null)
        {
            this.ClassId = classId;
            this.StaffId = staffId;
            this.OverrideConflicts = overrideConflicts;
            this.SendClientEmail = sendClientEmail;
            this.SendOriginalTeacherEmail = sendOriginalTeacherEmail;
            this.SendSubstituteTeacherEmail = sendSubstituteTeacherEmail;
        }

        /// <summary>
        /// The ID of the class to which a substitute teacher needs to be assigned.
        /// </summary>
        [JsonProperty("ClassId")]
        public int ClassId { get; set; }

        /// <summary>
        /// The staff ID of the teacher to substitute.
        /// </summary>
        [JsonProperty("StaffId")]
        public long StaffId { get; set; }

        /// <summary>
        /// When `true`, overrides any conflicts in the schedule.
        /// </summary>
        [JsonProperty("OverrideConflicts", NullValueHandling = NullValueHandling.Ignore)]
        public bool? OverrideConflicts { get; set; }

        /// <summary>
        /// When `true`, sends the client an automatic email about the substitution, if the client has opted to receive email.
        /// </summary>
        [JsonProperty("SendClientEmail", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendClientEmail { get; set; }

        /// <summary>
        /// When `true`, sends the originally scheduled teacher an automatic email about the substitution.
        /// </summary>
        [JsonProperty("SendOriginalTeacherEmail", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendOriginalTeacherEmail { get; set; }

        /// <summary>
        /// When `true`, sends the substituted teacher an automatic email about the substitution.
        /// </summary>
        [JsonProperty("SendSubstituteTeacherEmail", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendSubstituteTeacherEmail { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherRequest other &&
                this.ClassId.Equals(other.ClassId) &&
                this.StaffId.Equals(other.StaffId) &&
                ((this.OverrideConflicts == null && other.OverrideConflicts == null) || (this.OverrideConflicts?.Equals(other.OverrideConflicts) == true)) &&
                ((this.SendClientEmail == null && other.SendClientEmail == null) || (this.SendClientEmail?.Equals(other.SendClientEmail) == true)) &&
                ((this.SendOriginalTeacherEmail == null && other.SendOriginalTeacherEmail == null) || (this.SendOriginalTeacherEmail?.Equals(other.SendOriginalTeacherEmail) == true)) &&
                ((this.SendSubstituteTeacherEmail == null && other.SendSubstituteTeacherEmail == null) || (this.SendSubstituteTeacherEmail?.Equals(other.SendSubstituteTeacherEmail) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClassId = {this.ClassId}");
            toStringOutput.Add($"this.StaffId = {this.StaffId}");
            toStringOutput.Add($"this.OverrideConflicts = {(this.OverrideConflicts == null ? "null" : this.OverrideConflicts.ToString())}");
            toStringOutput.Add($"this.SendClientEmail = {(this.SendClientEmail == null ? "null" : this.SendClientEmail.ToString())}");
            toStringOutput.Add($"this.SendOriginalTeacherEmail = {(this.SendOriginalTeacherEmail == null ? "null" : this.SendOriginalTeacherEmail.ToString())}");
            toStringOutput.Add($"this.SendSubstituteTeacherEmail = {(this.SendSubstituteTeacherEmail == null ? "null" : this.SendSubstituteTeacherEmail.ToString())}");
        }
    }
}