// <copyright file="GetPackagesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetPackagesResponse.
    /// </summary>
    public class GetPackagesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetPackagesResponse"/> class.
        /// </summary>
        public GetPackagesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetPackagesResponse"/> class.
        /// </summary>
        /// <param name="packages">Packages.</param>
        /// <param name="paginationResponse">PaginationResponse.</param>
        public GetPackagesResponse(
            List<Models.MindbodyPublicApiDtoModelsV6Package> packages = null,
            Models.PaginationResponse paginationResponse = null)
        {
            this.Packages = packages;
            this.PaginationResponse = paginationResponse;
        }

        /// <summary>
        /// Contains information about the resulting packages.
        /// </summary>
        [JsonProperty("Packages", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6Package> Packages { get; set; }

        /// <summary>
        /// Contains information about the pagination used.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetPackagesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetPackagesResponse other &&
                ((this.Packages == null && other.Packages == null) || (this.Packages?.Equals(other.Packages) == true)) &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Packages = {(this.Packages == null ? "null" : $"[{string.Join(", ", this.Packages)} ]")}");
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
        }
    }
}