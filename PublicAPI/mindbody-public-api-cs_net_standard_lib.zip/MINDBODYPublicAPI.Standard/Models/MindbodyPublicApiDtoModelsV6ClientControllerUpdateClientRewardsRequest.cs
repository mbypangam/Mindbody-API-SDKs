// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="points">Points.</param>
        /// <param name="action">Action.</param>
        /// <param name="source">Source.</param>
        /// <param name="sourceId">SourceId.</param>
        /// <param name="actionDateTime">ActionDateTime.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest(
            string clientId,
            long points,
            string action,
            string source = null,
            long? sourceId = null,
            DateTime? actionDateTime = null)
        {
            this.ClientId = clientId;
            this.Points = points;
            this.Source = source;
            this.SourceId = sourceId;
            this.Action = action;
            this.ActionDateTime = actionDateTime;
        }

        /// <summary>
        /// The ID of the client that is getting rewards earned or redeemed.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// The amount of points the client is getting earned or redeemed, must be a positive number.
        /// </summary>
        [JsonProperty("Points")]
        public long Points { get; set; }

        /// <summary>
        /// If Action passed as **Earned**,
        /// possible values are:
        /// * Appointment Booking
        /// * Class Booking
        /// * Referral
        /// * Sale
        /// <br />Omit if Action passed as **Redeemed**.
        /// </summary>
        [JsonProperty("Source", NullValueHandling = NullValueHandling.Ignore)]
        public string Source { get; set; }

        /// <summary>
        /// The unique identifier in the MINDBODY system for the **Source**. If Action is **Earned**, and an optional SourceID is provided, it is validated as follows:
        /// * If Source is Appointment Booking, then a provided SourceID must be a valid Visit.AppointmentId for the indicated Client.
        /// * If Source is **Class Booking**, then a provided SourceID must be a valid Visit.Id for the indicated client.
        /// * If Source is **Sale**, then a provided SourceID must be a valid Sale.Id for the indicated client.
        /// * If Source is **Referral**, then a provided SourceID must be a valid Client.Id (RelatedClientId) and have been referred by the indicated client (ClientRelationship.Id = -1).
        /// If Action is **Redeemed**, and an optional SourceID is provided, then SourceID must be a valid Sale.Id for the indicated client, and refers to the sale where the indicated points were redeemed.
        /// </summary>
        [JsonProperty("SourceId", NullValueHandling = NullValueHandling.Ignore)]
        public long? SourceId { get; set; }

        /// <summary>
        /// Indicates if rewards are getting earned or redeemed.
        /// Possible values are:
        /// *Earned
        /// *Redeemed
        /// </summary>
        [JsonProperty("Action")]
        public string Action { get; set; }

        /// <summary>
        /// The date and time when the points were earned or redeemed in UTC format. This date may be in the past, however it may not be in the future.
        /// Default: **current date/time**
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("ActionDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ActionDateTime { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientRewardsRequest other &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                this.Points.Equals(other.Points) &&
                ((this.Source == null && other.Source == null) || (this.Source?.Equals(other.Source) == true)) &&
                ((this.SourceId == null && other.SourceId == null) || (this.SourceId?.Equals(other.SourceId) == true)) &&
                ((this.Action == null && other.Action == null) || (this.Action?.Equals(other.Action) == true)) &&
                ((this.ActionDateTime == null && other.ActionDateTime == null) || (this.ActionDateTime?.Equals(other.ActionDateTime) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.Points = {this.Points}");
            toStringOutput.Add($"this.Source = {(this.Source == null ? "null" : this.Source == string.Empty ? "" : this.Source)}");
            toStringOutput.Add($"this.SourceId = {(this.SourceId == null ? "null" : this.SourceId.ToString())}");
            toStringOutput.Add($"this.Action = {(this.Action == null ? "null" : this.Action == string.Empty ? "" : this.Action)}");
            toStringOutput.Add($"this.ActionDateTime = {(this.ActionDateTime == null ? "null" : this.ActionDateTime.ToString())}");
        }
    }
}