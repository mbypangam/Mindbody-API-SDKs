// <copyright file="MindbodyPublicApiDtoModelsV6ClientContract.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientContract.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientContract
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientContract"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientContract()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientContract"/> class.
        /// </summary>
        /// <param name="agreementDate">AgreementDate.</param>
        /// <param name="autopayStatus">AutopayStatus.</param>
        /// <param name="contractName">ContractName.</param>
        /// <param name="endDate">EndDate.</param>
        /// <param name="id">Id.</param>
        /// <param name="originationLocationId">OriginationLocationId.</param>
        /// <param name="startDate">StartDate.</param>
        /// <param name="siteId">SiteId.</param>
        /// <param name="upcomingAutopayEvents">UpcomingAutopayEvents.</param>
        /// <param name="contractID">ContractID.</param>
        /// <param name="terminationDate">TerminationDate.</param>
        public MindbodyPublicApiDtoModelsV6ClientContract(
            DateTime? agreementDate = null,
            Models.AutopayStatusEnum? autopayStatus = null,
            string contractName = null,
            DateTime? endDate = null,
            int? id = null,
            int? originationLocationId = null,
            DateTime? startDate = null,
            int? siteId = null,
            List<Models.MindbodyPublicApiDtoModelsV6UpcomingAutopayEvent> upcomingAutopayEvents = null,
            int? contractID = null,
            DateTime? terminationDate = null)
        {
            this.AgreementDate = agreementDate;
            this.AutopayStatus = autopayStatus;
            this.ContractName = contractName;
            this.EndDate = endDate;
            this.Id = id;
            this.OriginationLocationId = originationLocationId;
            this.StartDate = startDate;
            this.SiteId = siteId;
            this.UpcomingAutopayEvents = upcomingAutopayEvents;
            this.ContractID = contractID;
            this.TerminationDate = terminationDate;
        }

        /// <summary>
        /// The date on which the contract was signed.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("AgreementDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? AgreementDate { get; set; }

        /// <summary>
        /// The status of the client’s autopay.
        /// </summary>
        [JsonProperty("AutopayStatus", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.AutopayStatusEnum? AutopayStatus { get; set; }

        /// <summary>
        /// The name of the contract.
        /// </summary>
        [JsonProperty("ContractName", NullValueHandling = NullValueHandling.Ignore)]
        public string ContractName { get; set; }

        /// <summary>
        /// The date that the contract expires.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// The unique ID of the sale of the contract. Each time a contract is sold, this ID increases sequentially.
        /// </summary>
        [JsonProperty("Id", NullValueHandling = NullValueHandling.Ignore)]
        public int? Id { get; set; }

        /// <summary>
        /// The ID of the location where the contract was issued.
        /// </summary>
        [JsonProperty("OriginationLocationId", NullValueHandling = NullValueHandling.Ignore)]
        public int? OriginationLocationId { get; set; }

        /// <summary>
        /// The date that the contract became active.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// The ID of the site where the contract was issued.
        /// </summary>
        [JsonProperty("SiteId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SiteId { get; set; }

        /// <summary>
        /// Contains details of the autopay events.
        /// </summary>
        [JsonProperty("UpcomingAutopayEvents", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.MindbodyPublicApiDtoModelsV6UpcomingAutopayEvent> UpcomingAutopayEvents { get; set; }

        /// <summary>
        /// The ID of the contract
        /// </summary>
        [JsonProperty("ContractID", NullValueHandling = NullValueHandling.Ignore)]
        public int? ContractID { get; set; }

        /// <summary>
        /// The date that the contract was terminated.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("TerminationDate", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? TerminationDate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientContract : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientContract other &&
                ((this.AgreementDate == null && other.AgreementDate == null) || (this.AgreementDate?.Equals(other.AgreementDate) == true)) &&
                ((this.AutopayStatus == null && other.AutopayStatus == null) || (this.AutopayStatus?.Equals(other.AutopayStatus) == true)) &&
                ((this.ContractName == null && other.ContractName == null) || (this.ContractName?.Equals(other.ContractName) == true)) &&
                ((this.EndDate == null && other.EndDate == null) || (this.EndDate?.Equals(other.EndDate) == true)) &&
                ((this.Id == null && other.Id == null) || (this.Id?.Equals(other.Id) == true)) &&
                ((this.OriginationLocationId == null && other.OriginationLocationId == null) || (this.OriginationLocationId?.Equals(other.OriginationLocationId) == true)) &&
                ((this.StartDate == null && other.StartDate == null) || (this.StartDate?.Equals(other.StartDate) == true)) &&
                ((this.SiteId == null && other.SiteId == null) || (this.SiteId?.Equals(other.SiteId) == true)) &&
                ((this.UpcomingAutopayEvents == null && other.UpcomingAutopayEvents == null) || (this.UpcomingAutopayEvents?.Equals(other.UpcomingAutopayEvents) == true)) &&
                ((this.ContractID == null && other.ContractID == null) || (this.ContractID?.Equals(other.ContractID) == true)) &&
                ((this.TerminationDate == null && other.TerminationDate == null) || (this.TerminationDate?.Equals(other.TerminationDate) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AgreementDate = {(this.AgreementDate == null ? "null" : this.AgreementDate.ToString())}");
            toStringOutput.Add($"this.AutopayStatus = {(this.AutopayStatus == null ? "null" : this.AutopayStatus.ToString())}");
            toStringOutput.Add($"this.ContractName = {(this.ContractName == null ? "null" : this.ContractName == string.Empty ? "" : this.ContractName)}");
            toStringOutput.Add($"this.EndDate = {(this.EndDate == null ? "null" : this.EndDate.ToString())}");
            toStringOutput.Add($"this.Id = {(this.Id == null ? "null" : this.Id.ToString())}");
            toStringOutput.Add($"this.OriginationLocationId = {(this.OriginationLocationId == null ? "null" : this.OriginationLocationId.ToString())}");
            toStringOutput.Add($"this.StartDate = {(this.StartDate == null ? "null" : this.StartDate.ToString())}");
            toStringOutput.Add($"this.SiteId = {(this.SiteId == null ? "null" : this.SiteId.ToString())}");
            toStringOutput.Add($"this.UpcomingAutopayEvents = {(this.UpcomingAutopayEvents == null ? "null" : $"[{string.Join(", ", this.UpcomingAutopayEvents)} ]")}");
            toStringOutput.Add($"this.ContractID = {(this.ContractID == null ? "null" : this.ContractID.ToString())}");
            toStringOutput.Add($"this.TerminationDate = {(this.TerminationDate == null ? "null" : this.TerminationDate.ToString())}");
        }
    }
}