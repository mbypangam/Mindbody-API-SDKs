// <copyright file="GetReservationResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetReservationResponse.
    /// </summary>
    public class GetReservationResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetReservationResponse"/> class.
        /// </summary>
        public GetReservationResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetReservationResponse"/> class.
        /// </summary>
        /// <param name="reservations">Reservations.</param>
        /// <param name="pagination">Pagination.</param>
        /// <param name="responseDetails">ResponseDetails.</param>
        public GetReservationResponse(
            List<Models.Reservation> reservations = null,
            Models.Pagination pagination = null,
            Models.ResponseDetails responseDetails = null)
        {
            this.Reservations = reservations;
            this.Pagination = pagination;
            this.ResponseDetails = responseDetails;
        }

        /// <summary>
        /// Contains information about the reservation details.
        /// </summary>
        [JsonProperty("Reservations", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.Reservation> Reservations { get; set; }

        /// <summary>
        /// Contains information about the pagination used.
        /// </summary>
        [JsonProperty("Pagination", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Pagination Pagination { get; set; }

        /// <summary>
        /// Contains information about the response message detail.
        /// </summary>
        [JsonProperty("ResponseDetails", NullValueHandling = NullValueHandling.Ignore)]
        public Models.ResponseDetails ResponseDetails { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetReservationResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is GetReservationResponse other &&                ((this.Reservations == null && other.Reservations == null) || (this.Reservations?.Equals(other.Reservations) == true)) &&
                ((this.Pagination == null && other.Pagination == null) || (this.Pagination?.Equals(other.Pagination) == true)) &&
                ((this.ResponseDetails == null && other.ResponseDetails == null) || (this.ResponseDetails?.Equals(other.ResponseDetails) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Reservations = {(this.Reservations == null ? "null" : $"[{string.Join(", ", this.Reservations)} ]")}");
            toStringOutput.Add($"this.Pagination = {(this.Pagination == null ? "null" : this.Pagination.ToString())}");
            toStringOutput.Add($"this.ResponseDetails = {(this.ResponseDetails == null ? "null" : this.ResponseDetails.ToString())}");
        }
    }
}