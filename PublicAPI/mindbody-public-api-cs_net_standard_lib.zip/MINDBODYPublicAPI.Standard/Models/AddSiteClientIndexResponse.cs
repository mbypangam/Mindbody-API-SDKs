// <copyright file="AddSiteClientIndexResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// AddSiteClientIndexResponse.
    /// </summary>
    public class AddSiteClientIndexResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddSiteClientIndexResponse"/> class.
        /// </summary>
        public AddSiteClientIndexResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddSiteClientIndexResponse"/> class.
        /// </summary>
        /// <param name="clientIndexID">ClientIndexID.</param>
        /// <param name="clientIndexName">ClientIndexName.</param>
        /// <param name="active">Active.</param>
        /// <param name="showOnNewClient">ShowOnNewClient.</param>
        /// <param name="showOnEnrollmentRoster">ShowOnEnrollmentRoster.</param>
        /// <param name="editOnEnrollmentRoster">EditOnEnrollmentRoster.</param>
        /// <param name="sortOrder">SortOrder.</param>
        /// <param name="showInConsumerMode">ShowInConsumerMode.</param>
        /// <param name="requiredConsumerMode">RequiredConsumerMode.</param>
        /// <param name="requiredBizMode">RequiredBizMode.</param>
        public AddSiteClientIndexResponse(
            int? clientIndexID = null,
            string clientIndexName = null,
            bool? active = null,
            bool? showOnNewClient = null,
            bool? showOnEnrollmentRoster = null,
            bool? editOnEnrollmentRoster = null,
            int? sortOrder = null,
            bool? showInConsumerMode = null,
            bool? requiredConsumerMode = null,
            bool? requiredBizMode = null)
        {
            this.ClientIndexID = clientIndexID;
            this.ClientIndexName = clientIndexName;
            this.Active = active;
            this.ShowOnNewClient = showOnNewClient;
            this.ShowOnEnrollmentRoster = showOnEnrollmentRoster;
            this.EditOnEnrollmentRoster = editOnEnrollmentRoster;
            this.SortOrder = sortOrder;
            this.ShowInConsumerMode = showInConsumerMode;
            this.RequiredConsumerMode = requiredConsumerMode;
            this.RequiredBizMode = requiredBizMode;
        }

        /// <summary>
        /// ID of the client index.
        /// </summary>
        [JsonProperty("ClientIndexID", NullValueHandling = NullValueHandling.Ignore)]
        public int? ClientIndexID { get; set; }

        /// <summary>
        /// The name of the client index.
        /// </summary>
        [JsonProperty("ClientIndexName", NullValueHandling = NullValueHandling.Ignore)]
        public string ClientIndexName { get; set; }

        /// <summary>
        /// Indicates if Client Index is Active
        /// </summary>
        [JsonProperty("Active", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Active { get; set; }

        /// <summary>
        /// Indicates if Client Index is shown on a new client profile
        /// </summary>
        [JsonProperty("ShowOnNewClient", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ShowOnNewClient { get; set; }

        /// <summary>
        /// Indicates if Client Index is shown on Enrollement Roster
        /// </summary>
        [JsonProperty("ShowOnEnrollmentRoster", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ShowOnEnrollmentRoster { get; set; }

        /// <summary>
        /// Indicates if Client Index can be edited on Enrollement Roster
        /// </summary>
        [JsonProperty("EditOnEnrollmentRoster", NullValueHandling = NullValueHandling.Ignore)]
        public bool? EditOnEnrollmentRoster { get; set; }

        /// <summary>
        /// Indicates sort order
        /// </summary>
        [JsonProperty("SortOrder", NullValueHandling = NullValueHandling.Ignore)]
        public int? SortOrder { get; set; }

        /// <summary>
        /// Indicates if Client Index is shown in consumer mode.
        /// </summary>
        [JsonProperty("ShowInConsumerMode", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ShowInConsumerMode { get; set; }

        /// <summary>
        /// Indicates if the index is required when creating profiles in consumer mode.
        /// </summary>
        [JsonProperty("RequiredConsumerMode", NullValueHandling = NullValueHandling.Ignore)]
        public bool? RequiredConsumerMode { get; set; }

        /// <summary>
        /// Indicates if the index is required when creating profiles in business mode.
        /// </summary>
        [JsonProperty("RequiredBizMode", NullValueHandling = NullValueHandling.Ignore)]
        public bool? RequiredBizMode { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"AddSiteClientIndexResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is AddSiteClientIndexResponse other &&                ((this.ClientIndexID == null && other.ClientIndexID == null) || (this.ClientIndexID?.Equals(other.ClientIndexID) == true)) &&
                ((this.ClientIndexName == null && other.ClientIndexName == null) || (this.ClientIndexName?.Equals(other.ClientIndexName) == true)) &&
                ((this.Active == null && other.Active == null) || (this.Active?.Equals(other.Active) == true)) &&
                ((this.ShowOnNewClient == null && other.ShowOnNewClient == null) || (this.ShowOnNewClient?.Equals(other.ShowOnNewClient) == true)) &&
                ((this.ShowOnEnrollmentRoster == null && other.ShowOnEnrollmentRoster == null) || (this.ShowOnEnrollmentRoster?.Equals(other.ShowOnEnrollmentRoster) == true)) &&
                ((this.EditOnEnrollmentRoster == null && other.EditOnEnrollmentRoster == null) || (this.EditOnEnrollmentRoster?.Equals(other.EditOnEnrollmentRoster) == true)) &&
                ((this.SortOrder == null && other.SortOrder == null) || (this.SortOrder?.Equals(other.SortOrder) == true)) &&
                ((this.ShowInConsumerMode == null && other.ShowInConsumerMode == null) || (this.ShowInConsumerMode?.Equals(other.ShowInConsumerMode) == true)) &&
                ((this.RequiredConsumerMode == null && other.RequiredConsumerMode == null) || (this.RequiredConsumerMode?.Equals(other.RequiredConsumerMode) == true)) &&
                ((this.RequiredBizMode == null && other.RequiredBizMode == null) || (this.RequiredBizMode?.Equals(other.RequiredBizMode) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientIndexID = {(this.ClientIndexID == null ? "null" : this.ClientIndexID.ToString())}");
            toStringOutput.Add($"this.ClientIndexName = {(this.ClientIndexName == null ? "null" : this.ClientIndexName == string.Empty ? "" : this.ClientIndexName)}");
            toStringOutput.Add($"this.Active = {(this.Active == null ? "null" : this.Active.ToString())}");
            toStringOutput.Add($"this.ShowOnNewClient = {(this.ShowOnNewClient == null ? "null" : this.ShowOnNewClient.ToString())}");
            toStringOutput.Add($"this.ShowOnEnrollmentRoster = {(this.ShowOnEnrollmentRoster == null ? "null" : this.ShowOnEnrollmentRoster.ToString())}");
            toStringOutput.Add($"this.EditOnEnrollmentRoster = {(this.EditOnEnrollmentRoster == null ? "null" : this.EditOnEnrollmentRoster.ToString())}");
            toStringOutput.Add($"this.SortOrder = {(this.SortOrder == null ? "null" : this.SortOrder.ToString())}");
            toStringOutput.Add($"this.ShowInConsumerMode = {(this.ShowInConsumerMode == null ? "null" : this.ShowInConsumerMode.ToString())}");
            toStringOutput.Add($"this.RequiredConsumerMode = {(this.RequiredConsumerMode == null ? "null" : this.RequiredConsumerMode.ToString())}");
            toStringOutput.Add($"this.RequiredBizMode = {(this.RequiredBizMode == null ? "null" : this.RequiredBizMode.ToString())}");
        }
    }
}