// <copyright file="GetClassVisitsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetClassVisitsResponse.
    /// </summary>
    public class GetClassVisitsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetClassVisitsResponse"/> class.
        /// </summary>
        public GetClassVisitsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetClassVisitsResponse"/> class.
        /// </summary>
        /// <param name="mClass">Class.</param>
        public GetClassVisitsResponse(
            Models.Class mClass = null)
        {
            this.MClass = mClass;
        }

        /// <summary>
        /// Represents a single class instance. The class meets at the start time, goes until the end time.
        /// </summary>
        [JsonProperty("Class", NullValueHandling = NullValueHandling.Ignore)]
        public Models.Class MClass { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetClassVisitsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is GetClassVisitsResponse other &&                ((this.MClass == null && other.MClass == null) || (this.MClass?.Equals(other.MClass) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MClass = {(this.MClass == null ? "null" : this.MClass.ToString())}");
        }
    }
}