// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse"/> class.
        /// </summary>
        /// <param name="arrivalAdded">ArrivalAdded.</param>
        /// <param name="clientService">ClientService.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse(
            bool? arrivalAdded = null,
            Models.MindbodyPublicApiDtoModelsV6ClientService clientService = null)
        {
            this.ArrivalAdded = arrivalAdded;
            this.ClientService = clientService;
        }

        /// <summary>
        /// When `true`, indicates that the arrival was added to the database.
        /// </summary>
        [JsonProperty("ArrivalAdded", NullValueHandling = NullValueHandling.Ignore)]
        public bool? ArrivalAdded { get; set; }

        /// <summary>
        /// Contains information about the pricing option being used to pay for the client?s current service session.
        /// </summary>
        [JsonProperty("ClientService", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6ClientService ClientService { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerAddArrivalResponse other &&
                ((this.ArrivalAdded == null && other.ArrivalAdded == null) || (this.ArrivalAdded?.Equals(other.ArrivalAdded) == true)) &&
                ((this.ClientService == null && other.ClientService == null) || (this.ClientService?.Equals(other.ClientService) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ArrivalAdded = {(this.ArrivalAdded == null ? "null" : this.ArrivalAdded.ToString())}");
            toStringOutput.Add($"this.ClientService = {(this.ClientService == null ? "null" : this.ClientService.ToString())}");
        }
    }
}