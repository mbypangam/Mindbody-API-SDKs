// <copyright file="MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest"/> class.
        /// </summary>
        /// <param name="appointmentId">AppointmentId.</param>
        /// <param name="endDateTime">EndDateTime.</param>
        /// <param name="execute">Execute.</param>
        /// <param name="genderPreference">GenderPreference.</param>
        /// <param name="notes">Notes.</param>
        /// <param name="partnerExternalId">PartnerExternalId.</param>
        /// <param name="providerId">ProviderId.</param>
        /// <param name="resourceIds">ResourceIds.</param>
        /// <param name="sendEmail">SendEmail.</param>
        /// <param name="sessionTypeId">SessionTypeId.</param>
        /// <param name="staffId">StaffId.</param>
        /// <param name="startDateTime">StartDateTime.</param>
        /// <param name="test">Test.</param>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest(
            long appointmentId,
            DateTime? endDateTime = null,
            string execute = null,
            string genderPreference = null,
            string notes = null,
            string partnerExternalId = null,
            string providerId = null,
            List<int> resourceIds = null,
            bool? sendEmail = null,
            int? sessionTypeId = null,
            long? staffId = null,
            DateTime? startDateTime = null,
            bool? test = null)
        {
            this.AppointmentId = appointmentId;
            this.EndDateTime = endDateTime;
            this.Execute = execute;
            this.GenderPreference = genderPreference;
            this.Notes = notes;
            this.PartnerExternalId = partnerExternalId;
            this.ProviderId = providerId;
            this.ResourceIds = resourceIds;
            this.SendEmail = sendEmail;
            this.SessionTypeId = sessionTypeId;
            this.StaffId = staffId;
            this.StartDateTime = startDateTime;
            this.Test = test;
        }

        /// <summary>
        /// A unique ID for the appointment.
        /// </summary>
        [JsonProperty("AppointmentId")]
        public long AppointmentId { get; set; }

        /// <summary>
        /// The end date and time of the new appointment.
        /// <br />Default: **StartDateTime**, offset by the staff member?s default appointment duration.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDateTime { get; set; }

        /// <summary>
        /// The action taken to add this appointment.
        /// </summary>
        [JsonProperty("Execute", NullValueHandling = NullValueHandling.Ignore)]
        public string Execute { get; set; }

        /// <summary>
        /// The client?s service provider gender preference.
        /// </summary>
        [JsonProperty("GenderPreference", NullValueHandling = NullValueHandling.Ignore)]
        public string GenderPreference { get; set; }

        /// <summary>
        /// Any general notes about this appointment.
        /// </summary>
        [JsonProperty("Notes", NullValueHandling = NullValueHandling.Ignore)]
        public string Notes { get; set; }

        /// <summary>
        /// Optional external key for api partners.
        /// </summary>
        [JsonProperty("PartnerExternalId", NullValueHandling = NullValueHandling.Ignore)]
        public string PartnerExternalId { get; set; }

        /// <summary>
        /// If a user has Complementary and Alternative Medicine features enabled, this parameter assigns a provider ID to the appointment.
        /// </summary>
        [JsonProperty("ProviderId", NullValueHandling = NullValueHandling.Ignore)]
        public string ProviderId { get; set; }

        /// <summary>
        /// A list of resource IDs to associate with the new appointment.
        /// </summary>
        [JsonProperty("ResourceIds", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ResourceIds { get; set; }

        /// <summary>
        /// Whether to send client an email for cancellations. An email is sent only if the client has an email address and automatic emails have been set up.
        /// <br />Default: **false**
        /// </summary>
        [JsonProperty("SendEmail", NullValueHandling = NullValueHandling.Ignore)]
        public bool? SendEmail { get; set; }

        /// <summary>
        /// The session type associated with the new appointment.
        /// </summary>
        [JsonProperty("SessionTypeId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SessionTypeId { get; set; }

        /// <summary>
        /// The ID of the staff member who is adding the new appointment.
        /// </summary>
        [JsonProperty("StaffId", NullValueHandling = NullValueHandling.Ignore)]
        public long? StaffId { get; set; }

        /// <summary>
        /// The start date and time of the new appointment.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDateTime { get; set; }

        /// <summary>
        /// When `true`, indicates that the method is to be validated, but no new appointment data is added.
        /// <br />Default: **false**
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6AppointmentControllerUpdateAppointmentRequest other &&
                this.AppointmentId.Equals(other.AppointmentId) &&
                ((this.EndDateTime == null && other.EndDateTime == null) || (this.EndDateTime?.Equals(other.EndDateTime) == true)) &&
                ((this.Execute == null && other.Execute == null) || (this.Execute?.Equals(other.Execute) == true)) &&
                ((this.GenderPreference == null && other.GenderPreference == null) || (this.GenderPreference?.Equals(other.GenderPreference) == true)) &&
                ((this.Notes == null && other.Notes == null) || (this.Notes?.Equals(other.Notes) == true)) &&
                ((this.PartnerExternalId == null && other.PartnerExternalId == null) || (this.PartnerExternalId?.Equals(other.PartnerExternalId) == true)) &&
                ((this.ProviderId == null && other.ProviderId == null) || (this.ProviderId?.Equals(other.ProviderId) == true)) &&
                ((this.ResourceIds == null && other.ResourceIds == null) || (this.ResourceIds?.Equals(other.ResourceIds) == true)) &&
                ((this.SendEmail == null && other.SendEmail == null) || (this.SendEmail?.Equals(other.SendEmail) == true)) &&
                ((this.SessionTypeId == null && other.SessionTypeId == null) || (this.SessionTypeId?.Equals(other.SessionTypeId) == true)) &&
                ((this.StaffId == null && other.StaffId == null) || (this.StaffId?.Equals(other.StaffId) == true)) &&
                ((this.StartDateTime == null && other.StartDateTime == null) || (this.StartDateTime?.Equals(other.StartDateTime) == true)) &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.AppointmentId = {this.AppointmentId}");
            toStringOutput.Add($"this.EndDateTime = {(this.EndDateTime == null ? "null" : this.EndDateTime.ToString())}");
            toStringOutput.Add($"this.Execute = {(this.Execute == null ? "null" : this.Execute == string.Empty ? "" : this.Execute)}");
            toStringOutput.Add($"this.GenderPreference = {(this.GenderPreference == null ? "null" : this.GenderPreference == string.Empty ? "" : this.GenderPreference)}");
            toStringOutput.Add($"this.Notes = {(this.Notes == null ? "null" : this.Notes == string.Empty ? "" : this.Notes)}");
            toStringOutput.Add($"this.PartnerExternalId = {(this.PartnerExternalId == null ? "null" : this.PartnerExternalId == string.Empty ? "" : this.PartnerExternalId)}");
            toStringOutput.Add($"this.ProviderId = {(this.ProviderId == null ? "null" : this.ProviderId == string.Empty ? "" : this.ProviderId)}");
            toStringOutput.Add($"this.ResourceIds = {(this.ResourceIds == null ? "null" : $"[{string.Join(", ", this.ResourceIds)} ]")}");
            toStringOutput.Add($"this.SendEmail = {(this.SendEmail == null ? "null" : this.SendEmail.ToString())}");
            toStringOutput.Add($"this.SessionTypeId = {(this.SessionTypeId == null ? "null" : this.SessionTypeId.ToString())}");
            toStringOutput.Add($"this.StaffId = {(this.StaffId == null ? "null" : this.StaffId.ToString())}");
            toStringOutput.Add($"this.StartDateTime = {(this.StartDateTime == null ? "null" : this.StartDateTime.ToString())}");
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
        }
    }
}