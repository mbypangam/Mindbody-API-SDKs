// <copyright file="MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse"/> class.
        /// </summary>
        /// <param name="mClass">Class.</param>
        public MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse(
            Models.MindbodyPublicApiDtoModelsV6SubstituteTeacherClass mClass = null)
        {
            this.MClass = mClass;
        }

        /// <summary>
        /// Contains information about the class that is being assigned a substitute teacher.
        /// </summary>
        [JsonProperty("Class", NullValueHandling = NullValueHandling.Ignore)]
        public Models.MindbodyPublicApiDtoModelsV6SubstituteTeacherClass MClass { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClassControllerSubstituteClassTeacherResponse other &&
                ((this.MClass == null && other.MClass == null) || (this.MClass?.Equals(other.MClass) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MClass = {(this.MClass == null ? "null" : this.MClass.ToString())}");
        }
    }
}