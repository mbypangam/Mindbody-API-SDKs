// <copyright file="MindbodyPublicApiDtoModelsV6AutopaySchedule.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6AutopaySchedule.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6AutopaySchedule
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AutopaySchedule"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6AutopaySchedule()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AutopaySchedule"/> class.
        /// </summary>
        /// <param name="frequencyType">FrequencyType.</param>
        /// <param name="frequencyValue">FrequencyValue.</param>
        /// <param name="frequencyTimeUnit">FrequencyTimeUnit.</param>
        public MindbodyPublicApiDtoModelsV6AutopaySchedule(
            string frequencyType = null,
            int? frequencyValue = null,
            string frequencyTimeUnit = null)
        {
            this.FrequencyType = frequencyType;
            this.FrequencyValue = frequencyValue;
            this.FrequencyTimeUnit = frequencyTimeUnit;
        }

        /// <summary>
        /// Defines how often clients are charged. Possible values are:
        /// * SetNumberOfAutopays
        /// * MonthToMonth
        /// </summary>
        [JsonProperty("FrequencyType", NullValueHandling = NullValueHandling.Ignore)]
        public string FrequencyType { get; set; }

        /// <summary>
        /// The interval of AutoPay frequency, combined with `FrequencyTimeUnit`. This value is null if `FrequencyType` is `MonthToMonth`.
        /// </summary>
        [JsonProperty("FrequencyValue", NullValueHandling = NullValueHandling.Ignore)]
        public int? FrequencyValue { get; set; }

        /// <summary>
        /// Defines the time unit that sets how often to run the AutoPay, combined with `FrequencyValue`. This value is null if `FrequencyType` is `MonthToMonth`. Possible values are:
        /// * Weekly
        /// * Monthly
        /// * Yearly
        /// </summary>
        [JsonProperty("FrequencyTimeUnit", NullValueHandling = NullValueHandling.Ignore)]
        public string FrequencyTimeUnit { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6AutopaySchedule : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6AutopaySchedule other &&
                ((this.FrequencyType == null && other.FrequencyType == null) || (this.FrequencyType?.Equals(other.FrequencyType) == true)) &&
                ((this.FrequencyValue == null && other.FrequencyValue == null) || (this.FrequencyValue?.Equals(other.FrequencyValue) == true)) &&
                ((this.FrequencyTimeUnit == null && other.FrequencyTimeUnit == null) || (this.FrequencyTimeUnit?.Equals(other.FrequencyTimeUnit) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.FrequencyType = {(this.FrequencyType == null ? "null" : this.FrequencyType == string.Empty ? "" : this.FrequencyType)}");
            toStringOutput.Add($"this.FrequencyValue = {(this.FrequencyValue == null ? "null" : this.FrequencyValue.ToString())}");
            toStringOutput.Add($"this.FrequencyTimeUnit = {(this.FrequencyTimeUnit == null ? "null" : this.FrequencyTimeUnit == string.Empty ? "" : this.FrequencyTimeUnit)}");
        }
    }
}