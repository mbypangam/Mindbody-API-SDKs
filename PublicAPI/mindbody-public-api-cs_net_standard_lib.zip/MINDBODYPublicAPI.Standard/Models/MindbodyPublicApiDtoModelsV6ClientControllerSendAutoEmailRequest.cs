// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest"/> class.
        /// </summary>
        /// <param name="clientId">ClientId.</param>
        /// <param name="emailType">EmailType.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest(
            string clientId,
            string emailType)
        {
            this.ClientId = clientId;
            this.EmailType = emailType;
        }

        /// <summary>
        /// The Unique Id of the client as assigned by the business.
        /// </summary>
        [JsonProperty("ClientId")]
        public string ClientId { get; set; }

        /// <summary>
        /// The type of auto email to send (currently only BusinessWelcomeEmail or ConsumerWelcomeEmail are supported.)
        /// </summary>
        [JsonProperty("EmailType")]
        public string EmailType { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerSendAutoEmailRequest other &&
                ((this.ClientId == null && other.ClientId == null) || (this.ClientId?.Equals(other.ClientId) == true)) &&
                ((this.EmailType == null && other.EmailType == null) || (this.EmailType?.Equals(other.EmailType) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ClientId = {(this.ClientId == null ? "null" : this.ClientId == string.Empty ? "" : this.ClientId)}");
            toStringOutput.Add($"this.EmailType = {(this.EmailType == null ? "null" : this.EmailType == string.Empty ? "" : this.EmailType)}");
        }
    }
}