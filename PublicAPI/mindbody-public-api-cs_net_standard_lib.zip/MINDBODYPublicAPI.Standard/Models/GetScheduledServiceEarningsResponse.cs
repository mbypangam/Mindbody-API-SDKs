// <copyright file="GetScheduledServiceEarningsResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetScheduledServiceEarningsResponse.
    /// </summary>
    public class GetScheduledServiceEarningsResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetScheduledServiceEarningsResponse"/> class.
        /// </summary>
        public GetScheduledServiceEarningsResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetScheduledServiceEarningsResponse"/> class.
        /// </summary>
        /// <param name="paginationResponse">PaginationResponse.</param>
        /// <param name="scheduledServiceEarnings">ScheduledServiceEarnings.</param>
        public GetScheduledServiceEarningsResponse(
            Models.PaginationResponse paginationResponse = null,
            List<Models.ScheduledServiceEarningsEvent> scheduledServiceEarnings = null)
        {
            this.PaginationResponse = paginationResponse;
            this.ScheduledServiceEarnings = scheduledServiceEarnings;
        }

        /// <summary>
        /// Contains information about the pagination to use.
        /// </summary>
        [JsonProperty("PaginationResponse", NullValueHandling = NullValueHandling.Ignore)]
        public Models.PaginationResponse PaginationResponse { get; set; }

        /// <summary>
        /// Contains the class payroll events.
        /// </summary>
        [JsonProperty("ScheduledServiceEarnings", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ScheduledServiceEarningsEvent> ScheduledServiceEarnings { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetScheduledServiceEarningsResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetScheduledServiceEarningsResponse other &&
                ((this.PaginationResponse == null && other.PaginationResponse == null) || (this.PaginationResponse?.Equals(other.PaginationResponse) == true)) &&
                ((this.ScheduledServiceEarnings == null && other.ScheduledServiceEarnings == null) || (this.ScheduledServiceEarnings?.Equals(other.ScheduledServiceEarnings) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.PaginationResponse = {(this.PaginationResponse == null ? "null" : this.PaginationResponse.ToString())}");
            toStringOutput.Add($"this.ScheduledServiceEarnings = {(this.ScheduledServiceEarnings == null ? "null" : $"[{string.Join(", ", this.ScheduledServiceEarnings)} ]")}");
        }
    }
}