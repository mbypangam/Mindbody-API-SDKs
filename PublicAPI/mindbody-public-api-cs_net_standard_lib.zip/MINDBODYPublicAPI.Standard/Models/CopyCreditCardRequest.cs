// <copyright file="CopyCreditCardRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using APIMatic.Core.Utilities.Converters;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// CopyCreditCardRequest.
    /// </summary>
    public class CopyCreditCardRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CopyCreditCardRequest"/> class.
        /// </summary>
        public CopyCreditCardRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CopyCreditCardRequest"/> class.
        /// </summary>
        /// <param name="sourceSiteId">SourceSiteId.</param>
        /// <param name="sourceClientId">SourceClientId.</param>
        /// <param name="targetSiteId">TargetSiteId.</param>
        /// <param name="targetClientId">TargetClientId.</param>
        public CopyCreditCardRequest(
            int? sourceSiteId = null,
            string sourceClientId = null,
            int? targetSiteId = null,
            string targetClientId = null)
        {
            this.SourceSiteId = sourceSiteId;
            this.SourceClientId = sourceClientId;
            this.TargetSiteId = targetSiteId;
            this.TargetClientId = targetClientId;
        }

        /// <summary>
        /// The siteId of the source clientId.
        /// </summary>
        [JsonProperty("SourceSiteId", NullValueHandling = NullValueHandling.Ignore)]
        public int? SourceSiteId { get; set; }

        /// <summary>
        /// The clientId at the source siteId.
        /// </summary>
        [JsonProperty("SourceClientId", NullValueHandling = NullValueHandling.Ignore)]
        public string SourceClientId { get; set; }

        /// <summary>
        /// The siteId of the target clientId.
        /// </summary>
        [JsonProperty("TargetSiteId", NullValueHandling = NullValueHandling.Ignore)]
        public int? TargetSiteId { get; set; }

        /// <summary>
        /// The clientId at the target siteId.
        /// </summary>
        [JsonProperty("TargetClientId", NullValueHandling = NullValueHandling.Ignore)]
        public string TargetClientId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"CopyCreditCardRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }
            return obj is CopyCreditCardRequest other &&                ((this.SourceSiteId == null && other.SourceSiteId == null) || (this.SourceSiteId?.Equals(other.SourceSiteId) == true)) &&
                ((this.SourceClientId == null && other.SourceClientId == null) || (this.SourceClientId?.Equals(other.SourceClientId) == true)) &&
                ((this.TargetSiteId == null && other.TargetSiteId == null) || (this.TargetSiteId?.Equals(other.TargetSiteId) == true)) &&
                ((this.TargetClientId == null && other.TargetClientId == null) || (this.TargetClientId?.Equals(other.TargetClientId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.SourceSiteId = {(this.SourceSiteId == null ? "null" : this.SourceSiteId.ToString())}");
            toStringOutput.Add($"this.SourceClientId = {(this.SourceClientId == null ? "null" : this.SourceClientId)}");
            toStringOutput.Add($"this.TargetSiteId = {(this.TargetSiteId == null ? "null" : this.TargetSiteId.ToString())}");
            toStringOutput.Add($"this.TargetClientId = {(this.TargetClientId == null ? "null" : this.TargetClientId)}");
        }
    }
}