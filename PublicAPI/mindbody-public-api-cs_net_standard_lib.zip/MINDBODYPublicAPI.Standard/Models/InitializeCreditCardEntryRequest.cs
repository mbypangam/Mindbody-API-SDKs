// <copyright file="InitializeCreditCardEntryRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// InitializeCreditCardEntryRequest.
    /// </summary>
    public class InitializeCreditCardEntryRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InitializeCreditCardEntryRequest"/> class.
        /// </summary>
        public InitializeCreditCardEntryRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InitializeCreditCardEntryRequest"/> class.
        /// </summary>
        /// <param name="merchantAccountId">MerchantAccountId.</param>
        /// <param name="locationId">LocationId.</param>
        public InitializeCreditCardEntryRequest(
            string merchantAccountId = null,
            int? locationId = null)
        {
            this.MerchantAccountId = merchantAccountId;
            this.LocationId = locationId;
        }

        /// <summary>
        /// Gets or sets MerchantAccountId.
        /// </summary>
        [JsonProperty("MerchantAccountId", NullValueHandling = NullValueHandling.Ignore)]
        public string MerchantAccountId { get; set; }

        /// <summary>
        /// The ID associated with the location of the sale.
        /// </summary>
        [JsonProperty("LocationId", NullValueHandling = NullValueHandling.Ignore)]
        public int? LocationId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"InitializeCreditCardEntryRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is InitializeCreditCardEntryRequest other &&
                ((this.MerchantAccountId == null && other.MerchantAccountId == null) || (this.MerchantAccountId?.Equals(other.MerchantAccountId) == true)) &&
                ((this.LocationId == null && other.LocationId == null) || (this.LocationId?.Equals(other.LocationId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MerchantAccountId = {(this.MerchantAccountId == null ? "null" : this.MerchantAccountId == string.Empty ? "" : this.MerchantAccountId)}");
            toStringOutput.Add($"this.LocationId = {(this.LocationId == null ? "null" : this.LocationId.ToString())}");
        }
    }
}