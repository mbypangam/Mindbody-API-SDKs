// <copyright file="MindbodyPublicApiDtoModelsV6BookingWindow.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6BookingWindow.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6BookingWindow
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6BookingWindow"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6BookingWindow()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6BookingWindow"/> class.
        /// </summary>
        /// <param name="startDateTime">StartDateTime.</param>
        /// <param name="endDateTime">EndDateTime.</param>
        /// <param name="dailyStartTime">DailyStartTime.</param>
        /// <param name="dailyEndTime">DailyEndTime.</param>
        public MindbodyPublicApiDtoModelsV6BookingWindow(
            DateTime? startDateTime = null,
            DateTime? endDateTime = null,
            DateTime? dailyStartTime = null,
            DateTime? dailyEndTime = null)
        {
            this.StartDateTime = startDateTime;
            this.EndDateTime = endDateTime;
            this.DailyStartTime = dailyStartTime;
            this.DailyEndTime = dailyEndTime;
        }

        /// <summary>
        /// Date and time that the booking window opens; that is, the first day of sales.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDateTime { get; set; }

        /// <summary>
        /// Date and time that the booking window closes; that is, the last day of sales.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDateTime { get; set; }

        /// <summary>
        /// The time that the booking window opens; that is, the time that the store opens.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("DailyStartTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DailyStartTime { get; set; }

        /// <summary>
        /// The time that the booking window closes; that is, the time that the store closes.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("DailyEndTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? DailyEndTime { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6BookingWindow : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6BookingWindow other &&
                ((this.StartDateTime == null && other.StartDateTime == null) || (this.StartDateTime?.Equals(other.StartDateTime) == true)) &&
                ((this.EndDateTime == null && other.EndDateTime == null) || (this.EndDateTime?.Equals(other.EndDateTime) == true)) &&
                ((this.DailyStartTime == null && other.DailyStartTime == null) || (this.DailyStartTime?.Equals(other.DailyStartTime) == true)) &&
                ((this.DailyEndTime == null && other.DailyEndTime == null) || (this.DailyEndTime?.Equals(other.DailyEndTime) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.StartDateTime = {(this.StartDateTime == null ? "null" : this.StartDateTime.ToString())}");
            toStringOutput.Add($"this.EndDateTime = {(this.EndDateTime == null ? "null" : this.EndDateTime.ToString())}");
            toStringOutput.Add($"this.DailyStartTime = {(this.DailyStartTime == null ? "null" : this.DailyStartTime.ToString())}");
            toStringOutput.Add($"this.DailyEndTime = {(this.DailyEndTime == null ? "null" : this.DailyEndTime.ToString())}");
        }
    }
}