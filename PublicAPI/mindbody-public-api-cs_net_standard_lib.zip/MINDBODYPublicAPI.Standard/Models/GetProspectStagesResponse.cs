// <copyright file="GetProspectStagesResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// GetProspectStagesResponse.
    /// </summary>
    public class GetProspectStagesResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetProspectStagesResponse"/> class.
        /// </summary>
        public GetProspectStagesResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetProspectStagesResponse"/> class.
        /// </summary>
        /// <param name="prospectStages">ProspectStages.</param>
        public GetProspectStagesResponse(
            List<Models.ProspectStage> prospectStages = null)
        {
            this.ProspectStages = prospectStages;
        }

        /// <summary>
        /// List of Prospect Stages
        /// </summary>
        [JsonProperty("ProspectStages", NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.ProspectStage> ProspectStages { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"GetProspectStagesResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is GetProspectStagesResponse other &&
                ((this.ProspectStages == null && other.ProspectStages == null) || (this.ProspectStages?.Equals(other.ProspectStages) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ProspectStages = {(this.ProspectStages == null ? "null" : $"[{string.Join(", ", this.ProspectStages)} ]")}");
        }
    }
}