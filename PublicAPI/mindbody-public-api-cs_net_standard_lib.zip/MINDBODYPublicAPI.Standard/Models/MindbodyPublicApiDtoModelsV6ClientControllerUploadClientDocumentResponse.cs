// <copyright file="MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse"/> class.
        /// </summary>
        /// <param name="fileSize">FileSize.</param>
        /// <param name="fileName">FileName.</param>
        public MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse(
            long? fileSize = null,
            string fileName = null)
        {
            this.FileSize = fileSize;
            this.FileName = fileName;
        }

        /// <summary>
        /// The size of the uploaded file.
        /// </summary>
        [JsonProperty("FileSize", NullValueHandling = NullValueHandling.Ignore)]
        public long? FileSize { get; set; }

        /// <summary>
        /// The name of the uploaded file.
        /// </summary>
        [JsonProperty("FileName", NullValueHandling = NullValueHandling.Ignore)]
        public string FileName { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6ClientControllerUploadClientDocumentResponse other &&
                ((this.FileSize == null && other.FileSize == null) || (this.FileSize?.Equals(other.FileSize) == true)) &&
                ((this.FileName == null && other.FileName == null) || (this.FileName?.Equals(other.FileName) == true));
        }
        

        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.FileSize = {(this.FileSize == null ? "null" : this.FileSize.ToString())}");
            toStringOutput.Add($"this.FileName = {(this.FileName == null ? "null" : this.FileName == string.Empty ? "" : this.FileName)}");
        }
    }
}