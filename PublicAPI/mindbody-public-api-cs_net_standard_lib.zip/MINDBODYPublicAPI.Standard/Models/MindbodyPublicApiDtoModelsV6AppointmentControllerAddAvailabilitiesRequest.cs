// <copyright file="MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MINDBODYPublicAPI.Standard;
    using MINDBODYPublicAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest.
    /// </summary>
    public class MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest"/> class.
        /// </summary>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest"/> class.
        /// </summary>
        /// <param name="test">Test.</param>
        /// <param name="locationID">LocationID.</param>
        /// <param name="staffIDs">StaffIDs.</param>
        /// <param name="programIDs">ProgramIDs.</param>
        /// <param name="startDateTime">StartDateTime.</param>
        /// <param name="endDateTime">EndDateTime.</param>
        /// <param name="daysOfWeek">DaysOfWeek.</param>
        /// <param name="unavailableDescription">UnavailableDescription.</param>
        /// <param name="isUnavailable">IsUnavailable.</param>
        /// <param name="publicDisplay">PublicDisplay.</param>
        public MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest(
            bool? test = null,
            int? locationID = null,
            List<long> staffIDs = null,
            List<int> programIDs = null,
            DateTime? startDateTime = null,
            DateTime? endDateTime = null,
            List<Models.DaysOfWeekEnum> daysOfWeek = null,
            string unavailableDescription = null,
            bool? isUnavailable = null,
            Models.PublicDisplay1Enum? publicDisplay = null)
        {
            this.Test = test;
            this.LocationID = locationID;
            this.StaffIDs = staffIDs;
            this.ProgramIDs = programIDs;
            this.StartDateTime = startDateTime;
            this.EndDateTime = endDateTime;
            this.DaysOfWeek = daysOfWeek;
            this.UnavailableDescription = unavailableDescription;
            this.IsUnavailable = isUnavailable;
            this.PublicDisplay = publicDisplay;
        }

        /// <summary>
        /// When `true`, the request ensures that its parameters are valid without affecting real data.
        /// When `false`, the request performs as intended and may affect live client data.
        /// (optional) Defaults to false.
        /// </summary>
        [JsonProperty("Test", NullValueHandling = NullValueHandling.Ignore)]
        public bool? Test { get; set; }

        /// <summary>
        /// Location of availability.
        /// <br />Not used when IsUnavailable is `true`.
        /// </summary>
        [JsonProperty("LocationID", NullValueHandling = NullValueHandling.Ignore)]
        public int? LocationID { get; set; }

        /// <summary>
        /// A list of requested staff IDs.<br />
        /// (optional) Defaults to staff ID of user credentials. Use 0 for all.
        /// </summary>
        [JsonProperty("StaffIDs", NullValueHandling = NullValueHandling.Ignore)]
        public List<long> StaffIDs { get; set; }

        /// <summary>
        /// A list of program IDs.<br />
        /// (optional) Defaults to all.
        /// <br />Not used when IsUnavailable is true.
        /// </summary>
        [JsonProperty("ProgramIDs", NullValueHandling = NullValueHandling.Ignore)]
        public List<int> ProgramIDs { get; set; }

        /// <summary>
        /// The start date and time of the new availabilities or unavailabilities.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("StartDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? StartDateTime { get; set; }

        /// <summary>
        /// The end date and time of the new availabilities or unavailabilities.
        /// </summary>
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty("EndDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? EndDateTime { get; set; }

        /// <summary>
        /// The days of the week to set.<br />
        /// (optional) Defaults to all.
        /// </summary>
        [JsonProperty("DaysOfWeek", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public List<Models.DaysOfWeekEnum> DaysOfWeek { get; set; }

        /// <summary>
        /// Description of unavalability.
        /// <br />Only used when IsUnavailable is true.
        /// </summary>
        [JsonProperty("UnavailableDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string UnavailableDescription { get; set; }

        /// <summary>
        /// When `true`, indicates that unavailability is getting added. When `false`, indicates that availability is getting added.
        /// Default: **false**
        /// </summary>
        [JsonProperty("IsUnavailable", NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsUnavailable { get; set; }

        /// <summary>
        /// Sets the public display of the availability.<br /><ul><li>Show</li><li>Mask</li><li>Hide</li></ul>
        /// (optional) Defaults to Show.
        /// </summary>
        [JsonProperty("PublicDisplay", ItemConverterType = typeof(StringEnumConverter), NullValueHandling = NullValueHandling.Ignore)]
        public Models.PublicDisplay1Enum? PublicDisplay { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesRequest other &&
                ((this.Test == null && other.Test == null) || (this.Test?.Equals(other.Test) == true)) &&
                ((this.LocationID == null && other.LocationID == null) || (this.LocationID?.Equals(other.LocationID) == true)) &&
                ((this.StaffIDs == null && other.StaffIDs == null) || (this.StaffIDs?.Equals(other.StaffIDs) == true)) &&
                ((this.ProgramIDs == null && other.ProgramIDs == null) || (this.ProgramIDs?.Equals(other.ProgramIDs) == true)) &&
                ((this.StartDateTime == null && other.StartDateTime == null) || (this.StartDateTime?.Equals(other.StartDateTime) == true)) &&
                ((this.EndDateTime == null && other.EndDateTime == null) || (this.EndDateTime?.Equals(other.EndDateTime) == true)) &&
                ((this.DaysOfWeek == null && other.DaysOfWeek == null) || (this.DaysOfWeek?.Equals(other.DaysOfWeek) == true)) &&
                ((this.UnavailableDescription == null && other.UnavailableDescription == null) || (this.UnavailableDescription?.Equals(other.UnavailableDescription) == true)) &&
                ((this.IsUnavailable == null && other.IsUnavailable == null) || (this.IsUnavailable?.Equals(other.IsUnavailable) == true)) &&
                ((this.PublicDisplay == null && other.PublicDisplay == null) || (this.PublicDisplay?.Equals(other.PublicDisplay) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Test = {(this.Test == null ? "null" : this.Test.ToString())}");
            toStringOutput.Add($"this.LocationID = {(this.LocationID == null ? "null" : this.LocationID.ToString())}");
            toStringOutput.Add($"this.StaffIDs = {(this.StaffIDs == null ? "null" : $"[{string.Join(", ", this.StaffIDs)} ]")}");
            toStringOutput.Add($"this.ProgramIDs = {(this.ProgramIDs == null ? "null" : $"[{string.Join(", ", this.ProgramIDs)} ]")}");
            toStringOutput.Add($"this.StartDateTime = {(this.StartDateTime == null ? "null" : this.StartDateTime.ToString())}");
            toStringOutput.Add($"this.EndDateTime = {(this.EndDateTime == null ? "null" : this.EndDateTime.ToString())}");
            toStringOutput.Add($"this.DaysOfWeek = {(this.DaysOfWeek == null ? "null" : $"[{string.Join(", ", this.DaysOfWeek)} ]")}");
            toStringOutput.Add($"this.UnavailableDescription = {(this.UnavailableDescription == null ? "null" : this.UnavailableDescription == string.Empty ? "" : this.UnavailableDescription)}");
            toStringOutput.Add($"this.IsUnavailable = {(this.IsUnavailable == null ? "null" : this.IsUnavailable.ToString())}");
            toStringOutput.Add($"this.PublicDisplay = {(this.PublicDisplay == null ? "null" : this.PublicDisplay.ToString())}");
        }
    }
}