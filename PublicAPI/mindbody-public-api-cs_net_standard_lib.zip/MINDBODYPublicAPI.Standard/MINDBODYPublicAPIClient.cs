// <copyright file="MINDBODYPublicAPIClient.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace MINDBODYPublicAPI.Standard
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using APIMatic.Core;
    using APIMatic.Core.Authentication;
    using APIMatic.Core.Types;
    using MINDBODYPublicAPI.Standard.Authentication;
    using MINDBODYPublicAPI.Standard.Controllers;
    using MINDBODYPublicAPI.Standard.Http.Client;
    using MINDBODYPublicAPI.Standard.Utilities;

    /// <summary>
    /// The gateway for the SDK. This class acts as a factory for Controller and
    /// holds the configuration of the SDK.
    /// </summary>
    public sealed class MINDBODYPublicAPIClient : IConfiguration
    {
        // A map of environments and their corresponding servers/baseurls
        private static readonly Dictionary<Environment, Dictionary<Enum, string>> EnvironmentsMap =
            new Dictionary<Environment, Dictionary<Enum, string>>
        {
            {
                Environment.Production, new Dictionary<Enum, string>
                {
                    { Server.Default, "https://local-public-api.mbodev.me" },
                }
            },
        };

        private readonly GlobalConfiguration globalConfiguration;
        private const string userAgent = "APIMATIC 3.0";
        private readonly CustomHeaderAuthenticationManager customHeaderAuthenticationManager;
        private readonly Lazy<AppointmentController> appointment;
        private readonly Lazy<ClassController> mClass;
        private readonly Lazy<ClientController> client;
        private readonly Lazy<EnrollmentController> enrollment;
        private readonly Lazy<PayrollController> payroll;
        private readonly Lazy<SaleController> sale;
        private readonly Lazy<SiteController> site;
        private readonly Lazy<StaffController> staff;

        private MINDBODYPublicAPIClient(
            Environment environment,
            string aPIKey,
            IHttpClientConfiguration httpClientConfiguration)
        {
            this.Environment = environment;
            this.HttpClientConfiguration = httpClientConfiguration;
            customHeaderAuthenticationManager = new CustomHeaderAuthenticationManager(aPIKey);
            globalConfiguration = new GlobalConfiguration.Builder()
                .AuthManagers(new Dictionary<string, AuthManager> {
                        {"global", customHeaderAuthenticationManager}
                })
                .HttpConfiguration(httpClientConfiguration)
                .ServerUrls(EnvironmentsMap[environment], Server.Default)
                .UserAgent(userAgent)
                .Build();


            this.appointment = new Lazy<AppointmentController>(
                () => new AppointmentController(globalConfiguration));
            this.mClass = new Lazy<ClassController>(
                () => new ClassController(globalConfiguration));
            this.client = new Lazy<ClientController>(
                () => new ClientController(globalConfiguration));
            this.enrollment = new Lazy<EnrollmentController>(
                () => new EnrollmentController(globalConfiguration));
            this.payroll = new Lazy<PayrollController>(
                () => new PayrollController(globalConfiguration));
            this.sale = new Lazy<SaleController>(
                () => new SaleController(globalConfiguration));
            this.site = new Lazy<SiteController>(
                () => new SiteController(globalConfiguration));
            this.staff = new Lazy<StaffController>(
                () => new StaffController(globalConfiguration));
        }

        /// <summary>
        /// Gets AppointmentController controller.
        /// </summary>
        public AppointmentController AppointmentController => this.appointment.Value;

        /// <summary>
        /// Gets ClassController controller.
        /// </summary>
        public ClassController ClassController => this.mClass.Value;

        /// <summary>
        /// Gets ClientController controller.
        /// </summary>
        public ClientController ClientController => this.client.Value;

        /// <summary>
        /// Gets EnrollmentController controller.
        /// </summary>
        public EnrollmentController EnrollmentController => this.enrollment.Value;

        /// <summary>
        /// Gets PayrollController controller.
        /// </summary>
        public PayrollController PayrollController => this.payroll.Value;

        /// <summary>
        /// Gets SaleController controller.
        /// </summary>
        public SaleController SaleController => this.sale.Value;

        /// <summary>
        /// Gets SiteController controller.
        /// </summary>
        public SiteController SiteController => this.site.Value;

        /// <summary>
        /// Gets StaffController controller.
        /// </summary>
        public StaffController StaffController => this.staff.Value;

        /// <summary>
        /// Gets the configuration of the Http Client associated with this client.
        /// </summary>
        public IHttpClientConfiguration HttpClientConfiguration { get; }

        /// <summary>
        /// Gets Environment.
        /// Current API environment.
        /// </summary>
        public Environment Environment { get; }


        /// <summary>
        /// Gets the credentials to use with CustomHeaderAuthentication.
        /// </summary>
        public ICustomHeaderAuthenticationCredentials CustomHeaderAuthenticationCredentials => this.customHeaderAuthenticationManager;

        /// <summary>
        /// Gets the URL for a particular alias in the current environment and appends
        /// it with template parameters.
        /// </summary>
        /// <param name="alias">Default value:DEFAULT.</param>
        /// <returns>Returns the baseurl.</returns>
        public string GetBaseUri(Server alias = Server.Default)
        {
            return globalConfiguration.ServerUrl(alias);
        }

        /// <summary>
        /// Creates an object of the MINDBODYPublicAPIClient using the values provided for the builder.
        /// </summary>
        /// <returns>Builder.</returns>
        public Builder ToBuilder()
        {
            Builder builder = new Builder()
                .Environment(this.Environment)
                .CustomHeaderAuthenticationCredentials(customHeaderAuthenticationManager.APIKey)
                .HttpClientConfig(config => config.Build());

            return builder;
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            return
                $"Environment = {this.Environment}, " +
                $"HttpClientConfiguration = {this.HttpClientConfiguration}, ";
        }

        /// <summary>
        /// Creates the client using builder.
        /// </summary>
        /// <returns> MINDBODYPublicAPIClient.</returns>
        internal static MINDBODYPublicAPIClient CreateFromEnvironment()
        {
            var builder = new Builder();

            string environment = System.Environment.GetEnvironmentVariable("MINDBODY_PUBLIC_API_STANDARD_ENVIRONMENT");
            string aPIKey = System.Environment.GetEnvironmentVariable("MINDBODY_PUBLIC_API_STANDARD_A_PI_KEY");

            if (environment != null)
            {
                builder.Environment(ApiHelper.JsonDeserialize<Environment>($"\"{environment}\""));
            }

            if (aPIKey != null)
            {
                builder.CustomHeaderAuthenticationCredentials(aPIKey);
            }

            return builder.Build();
        }

        /// <summary>
        /// Builder class.
        /// </summary>
        public class Builder
        {
            private Environment environment = MINDBODYPublicAPI.Standard.Environment.Production;
            private string aPIKey = "";
            private HttpClientConfiguration.Builder httpClientConfig = new HttpClientConfiguration.Builder();

            /// <summary>
            /// Sets credentials for CustomHeaderAuthentication.
            /// </summary>
            /// <param name="aPIKey">APIKey.</param>
            /// <returns>Builder.</returns>
            public Builder CustomHeaderAuthenticationCredentials(string aPIKey)
            {
                this.aPIKey = aPIKey ?? throw new ArgumentNullException(nameof(aPIKey));
                return this;
            }

            /// <summary>
            /// Sets Environment.
            /// </summary>
            /// <param name="environment"> Environment. </param>
            /// <returns> Builder. </returns>
            public Builder Environment(Environment environment)
            {
                this.environment = environment;
                return this;
            }

            /// <summary>
            /// Sets HttpClientConfig.
            /// </summary>
            /// <param name="action"> Action. </param>
            /// <returns>Builder.</returns>
            public Builder HttpClientConfig(Action<HttpClientConfiguration.Builder> action)
            {
                if (action is null)
                {
                    throw new ArgumentNullException(nameof(action));
                }

                action(this.httpClientConfig);
                return this;
            }

           

            /// <summary>
            /// Creates an object of the MINDBODYPublicAPIClient using the values provided for the builder.
            /// </summary>
            /// <returns>MINDBODYPublicAPIClient.</returns>
            public MINDBODYPublicAPIClient Build()
            {

                return new MINDBODYPublicAPIClient(
                    environment,
                    aPIKey,
                    httpClientConfig.Build());
            }
        }
    }
}
