# Staff

```ruby
staff_controller = client.staff
```

## Class Name

`StaffController`

## Methods

* [Staff Get Staff Image URL](../../doc/controllers/staff.md#staff-get-staff-image-url)
* [Staff Get Sales Reps](../../doc/controllers/staff.md#staff-get-sales-reps)
* [Staff Get Staff Session Types](../../doc/controllers/staff.md#staff-get-staff-session-types)
* [Staff Get Staff](../../doc/controllers/staff.md#staff-get-staff)
* [Staff Get Staff Permissions](../../doc/controllers/staff.md#staff-get-staff-permissions)
* [Staff Add Staff](../../doc/controllers/staff.md#staff-add-staff)
* [Staff Assign Staff Session Type](../../doc/controllers/staff.md#staff-assign-staff-session-type)
* [Staff Add Staff Availability](../../doc/controllers/staff.md#staff-add-staff-availability)
* [Staff Update Staff](../../doc/controllers/staff.md#staff-update-staff)
* [Staff Update Staff Permissions](../../doc/controllers/staff.md#staff-update-staff-permissions)


# Staff Get Staff Image URL

This endpoint can be utilized to retrieve image urls for requested staff member.

```ruby
def staff_get_staff_image_url(version,
                              site_id,
                              authorization: nil,
                              request_staff_id: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_staff_id` | `Integer` | Query, Optional | The ID of the staff member whose image URL details you want to retrieve. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffImageURLResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-image-url-response.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = staff_controller.staff_get_staff_image_url(version, site_id, )
```


# Staff Get Sales Reps

This endpoint returns the basic details of the staffs that are marked as sales reps.

```ruby
def staff_get_sales_reps(version,
                         site_id,
                         authorization: nil,
                         request_active_only: nil,
                         request_limit: nil,
                         request_offset: nil,
                         request_sales_rep_numbers: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_active_only` | `TrueClass\|FalseClass` | Query, Optional | When `true`, will return only active reps data.<br>Default : **false** |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |
| `request_sales_rep_numbers` | `Array<Integer>` | Query, Optional | This is the list of the sales rep numbers for which the salesrep data will be fetched. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetSalesRepsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-sales-reps-response.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = staff_controller.staff_get_sales_reps(version, site_id, )
```


# Staff Get Staff Session Types

Gets a list of active session types for a specific staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```ruby
def staff_get_staff_session_types(version,
                                  request_staff_id,
                                  site_id,
                                  authorization: nil,
                                  request_limit: nil,
                                  request_offset: nil,
                                  request_online_only: nil,
                                  request_program_ids: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_staff_id` | `Integer` | Query, Required | The ID of the staff member whose session types you want to return. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |
| `request_online_only` | `TrueClass\|FalseClass` | Query, Optional | When `true`, indicates that only the session types that can be booked online should be returned.<br>Default: **false** |
| `request_program_ids` | `Array<Integer>` | Query, Optional | Filters results to session types that belong to one of the given program IDs. If omitted, all program IDs return. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffSessionTypesResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-session-types-response.md)

## Example Usage

```ruby
version = '6'
request_staff_id = 180
site_id = '-99'

result = staff_controller.staff_get_staff_session_types(version, request_staff_id, site_id, )
```


# Staff Get Staff

When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:

* FirstName
* LastName
* Id
* Bio
* DisplayName
* ImageUrl
* EmpID

```ruby
def staff_get_staff(version,
                    site_id,
                    authorization: nil,
                    request_filters: nil,
                    request_limit: nil,
                    request_location_id: nil,
                    request_offset: nil,
                    request_session_type_id: nil,
                    request_staff_ids: nil,
                    request_start_date_time: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_filters` | `Array<String>` | Query, Optional | Filters to apply to the search. Possible values are:<br><br>* StaffViewable<br>* AppointmentInstructor<br>* ClassInstructor<br>* Male<br>* Female |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_id` | `Integer` | Query, Optional | Return only staff members that are available at the specified location. You must supply a valid `SessionTypeID` and `StartDateTime` to use this parameter. |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |
| `request_session_type_id` | `Integer` | Query, Optional | Return only staff members that are available for the specified session type. You must supply a valid `StartDateTime` and `LocationID` to use this parameter. |
| `request_staff_ids` | `Array<Integer>` | Query, Optional | A list of the requested staff IDs. |
| `request_start_date_time` | `DateTime` | Query, Optional | Return only staff members that are available at the specified date and time. You must supply a valid `SessionTypeID` and `LocationID` to use this parameter. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-response.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = staff_controller.staff_get_staff(version, site_id, )
```


# Staff Get Staff Permissions

Get configured staff permissions for a staff member.

```ruby
def staff_get_staff_permissions(version,
                                request_staff_id,
                                site_id,
                                authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request_staff_id` | `Integer` | Query, Required | The ID of the staff member whose permissions you want to return. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-get-staff-permissions-response.md)

## Example Usage

```ruby
version = '6'
request_staff_id = 180
site_id = '-99'

result = staff_controller.staff_get_staff_permissions(version, request_staff_id, site_id, )
```


# Staff Add Staff

Creates a new staff member record at the specified business. The `FirstName` and `LastName` parameters are always required for this request.

```ruby
def staff_add_staff(version,
                    request,
                    site_id,
                    authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-add-staff-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-add-staff-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6StaffControllerAddStaffRequest.new
request.first_name = 'FirstName8'
request.last_name = 'LastName8'
site_id = '-99'

result = staff_controller.staff_add_staff(version, request, site_id, )
```


# Staff Assign Staff Session Type

Assigns a staff member to an appointment session type with staff specific properties such as time length and pay rate. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```ruby
def staff_assign_staff_session_type(version,
                                    request,
                                    site_id,
                                    authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-assign-staff-session-type-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-assign-staff-session-type-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6StaffControllerAssignStaffSessionTypeRequest.new
request.staff_id = 188
request.session_type_id = 82
request.active = false
site_id = '-99'

result = staff_controller.staff_assign_staff_session_type(version, request, site_id, )
```


# Staff Add Staff Availability

Enables to add staff availability or unavailability for a given staff member.

```ruby
def staff_add_staff_availability(version,
                                 request,
                                 site_id,
                                 authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-add-staff-availability-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`void`

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6StaffControllerAddStaffAvailabilityRequest.new
request.staff_id = 188
request.is_availability = false
request.days_of_week = ['DaysOfWeek7']
request.start_time = 'StartTime4'
request.end_time = 'EndTime0'
request.start_date = 'StartDate0'
request.end_date = 'EndDate6'
site_id = '-99'

result = staff_controller.staff_add_staff_availability(version, request, site_id, )
```


# Staff Update Staff

Updates an existing staff member record at the specified business. The ID is a required parameters for this request.

```ruby
def staff_update_staff(version,
                       request,
                       site_id,
                       authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffRequest.new
request.id = 142
site_id = '-99'

result = staff_controller.staff_update_staff(version, request, site_id, )
```


# Staff Update Staff Permissions

Assigns a permission group to a staff member. A staff user token must be included with staff assigned the ManageStaffPayRates permission.

```ruby
def staff_update_staff_permissions(version,
                                   request,
                                   site_id,
                                   authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-permissions-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-staff-controller-update-staff-permissions-response.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6StaffControllerUpdateStaffPermissionsRequest.new
request.staff_id = 188
request.permission_group_name = 'PermissionGroupName8'
site_id = '-99'

result = staff_controller.staff_update_staff_permissions(version, request, site_id, )
```

