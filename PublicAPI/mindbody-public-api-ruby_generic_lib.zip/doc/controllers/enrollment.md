# Enrollment

```ruby
enrollment_controller = client.enrollment
```

## Class Name

`EnrollmentController`

## Methods

* [Enrollment Add Client to Enrollment](../../doc/controllers/enrollment.md#enrollment-add-client-to-enrollment)
* [Enrollment Get Enrollments](../../doc/controllers/enrollment.md#enrollment-get-enrollments)
* [Enrollment Add Enrollment Schedule](../../doc/controllers/enrollment.md#enrollment-add-enrollment-schedule)
* [Enrollment Update Enrollment Schedule](../../doc/controllers/enrollment.md#enrollment-update-enrollment-schedule)


# Enrollment Add Client to Enrollment

Book a client into an enrollment.

```ruby
def enrollment_add_client_to_enrollment(version,
                                        request,
                                        site_id,
                                        authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-add-client-to-enrollment-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassSchedule`](../../doc/models/mindbody-public-api-dto-models-v6-class-schedule.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6ClassControllerAddClientToEnrollmentRequest.new
request.client_id = 'ClientId0'
request.class_schedule_id = 36
site_id = '-99'

result = enrollment_controller.enrollment_add_client_to_enrollment(version, request, site_id, )
```


# Enrollment Get Enrollments

Returns a list of enrollments. An enrollment is a service, such as a workshop or an event, that a staff member offers to multiple students, who commit to coming to all or most of the scheduled sessions. Enrollments typically run for a limited time only.

When a user token is not passed with the request or the passed user token has insufficient viewing permissions, only the following staff data is returned in the response:

* FirstName
* LastName
* Id
* Bio
* DisplayName
* ImageUrl

```ruby
def enrollment_get_enrollments(version,
                               site_id,
                               authorization: nil,
                               request_class_schedule_ids: nil,
                               request_end_date: nil,
                               request_limit: nil,
                               request_location_ids: nil,
                               request_offset: nil,
                               request_program_ids: nil,
                               request_session_type_ids: nil,
                               request_staff_ids: nil,
                               request_start_date: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |
| `request_class_schedule_ids` | `Array<Integer>` | Query, Optional | A list of the requested class schedule IDs. If omitted, all class schedule IDs return. |
| `request_end_date` | `DateTime` | Query, Optional | The end of the date range. The response returns any active enrollments that occur on or before this day.<br /><br>Default: **StartDate** |
| `request_limit` | `Integer` | Query, Optional | Number of results to include, defaults to 100 |
| `request_location_ids` | `Array<Integer>` | Query, Optional | List of the IDs for the requested locations. If omitted, all location IDs return. |
| `request_offset` | `Integer` | Query, Optional | Page offset, defaults to 0. |
| `request_program_ids` | `Array<Integer>` | Query, Optional | List of the IDs for the requested programs. If omitted, all program IDs return. |
| `request_session_type_ids` | `Array<Integer>` | Query, Optional | List of the IDs for the requested session types. If omitted, all session types IDs return. |
| `request_staff_ids` | `Array<Integer>` | Query, Optional | List of the IDs for the requested staff IDs. If omitted, all staff IDs return. |
| `request_start_date` | `DateTime` | Query, Optional | The start of the date range. The response returns any active enrollments that occur on or after this day.<br /><br>Default: **today’s date** |

## Response Type

[`MindbodyPublicApiDtoModelsV6ClassControllerGetEnrollmentsResponse`](../../doc/models/mindbody-public-api-dto-models-v6-class-controller-get-enrollments-response.md)

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = enrollment_controller.enrollment_get_enrollments(version, site_id, )
```


# Enrollment Add Enrollment Schedule

This endpoint adds a enrollment schedule. You can require clients to sign up for the entire enrollment schedule or allow them to pick specific sessions using the AllowOpenEnrollment parameter.

```ruby
def enrollment_add_enrollment_schedule(version,
                                       request,
                                       site_id,
                                       authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest`](../../doc/models/mindbody-public-api-dto-models-v6-add-class-enrollment-schedule-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

[`MindbodyPublicApiDataModelsWrittenClassSchedulesInfo`](../../doc/models/mindbody-public-api-data-models-written-class-schedules-info.md)

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6AddClassEnrollmentScheduleRequest.new
site_id = '-99'

result = enrollment_controller.enrollment_add_enrollment_schedule(version, request, site_id, )
```


# Enrollment Update Enrollment Schedule

```ruby
def enrollment_update_enrollment_schedule(version,
                                          request,
                                          site_id,
                                          authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `request` | [`MindbodyPublicApiDtoModelsV6UpdateClassEnrollmentScheduleRequest`](../../doc/models/mindbody-public-api-dto-models-v6-update-class-enrollment-schedule-request.md) | Body, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
request = MindbodyPublicApiDtoModelsV6UpdateClassEnrollmentScheduleRequest.new
site_id = '-99'

result = enrollment_controller.enrollment_update_enrollment_schedule(version, request, site_id, )
```

