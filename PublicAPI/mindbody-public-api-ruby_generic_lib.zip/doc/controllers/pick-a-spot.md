# Pick a Spot

```ruby
pick_a_spot_controller = client.pick_a_spot
```

## Class Name

`PickASpotController`

## Methods

* [Pick a Spot Class List](../../doc/controllers/pick-a-spot.md#pick-a-spot-class-list)
* [Pick a Spot Class](../../doc/controllers/pick-a-spot.md#pick-a-spot-class)
* [Pick a Spot Reservation Get](../../doc/controllers/pick-a-spot.md#pick-a-spot-reservation-get)
* [To Update a Class](../../doc/controllers/pick-a-spot.md#to-update-a-class)
* [Pick a Spot Reservation Post](../../doc/controllers/pick-a-spot.md#pick-a-spot-reservation-post)
* [Pick a Spot Reservation Delete](../../doc/controllers/pick-a-spot.md#pick-a-spot-reservation-delete)


# Pick a Spot Class List

A user token is required for this endpoint.

```ruby
def pick_a_spot_class_list(version,
                           site_id,
                           authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = pick_a_spot_controller.pick_a_spot_class_list(version, site_id, )
```


# Pick a Spot Class

A user token is required for this endpoint.

```ruby
def pick_a_spot_class(version,
                      class_id,
                      site_id,
                      authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `class_id` | `String` | Template, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
class_id = 'classId0'
site_id = '-99'

result = pick_a_spot_controller.pick_a_spot_class(version, class_id, site_id, )
```


# Pick a Spot Reservation Get

A user token is required for this endpoint.

```ruby
def pick_a_spot_reservation_get(version,
                                path_info,
                                site_id,
                                authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `path_info` | `String` | Template, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
path_info = 'pathInfo8'
site_id = '-99'

result = pick_a_spot_controller.pick_a_spot_reservation_get(version, path_info, site_id, )
```


# To Update a Class

A user token is required for this endpoint.

```ruby
def to_update_a_class(version,
                      path_info,
                      site_id,
                      authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `path_info` | `String` | Template, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
path_info = 'pathInfo8'
site_id = '-99'

result = pick_a_spot_controller.to_update_a_class(version, path_info, site_id, )
```


# Pick a Spot Reservation Post

A user token is required for this endpoint.

```ruby
def pick_a_spot_reservation_post(version,
                                 path_info,
                                 site_id,
                                 authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `path_info` | `String` | Template, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
path_info = 'pathInfo8'
site_id = '-99'

result = pick_a_spot_controller.pick_a_spot_reservation_post(version, path_info, site_id, )
```


# Pick a Spot Reservation Delete

A user token is required for this endpoint.

```ruby
def pick_a_spot_reservation_delete(version,
                                   path_info,
                                   site_id,
                                   authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `path_info` | `String` | Template, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
path_info = 'pathInfo8'
site_id = '-99'

result = pick_a_spot_controller.pick_a_spot_reservation_delete(version, path_info, site_id, )
```

