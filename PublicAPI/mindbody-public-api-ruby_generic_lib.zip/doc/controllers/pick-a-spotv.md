# Pick a Spotv

```ruby
pick_a_spotv_controller = client.pick_a_spotv
```

## Class Name

`PickASpotvController`

## Methods

* [Pick a Spotv Class List](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-class-list)
* [Pick a Spotv Class](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-class)
* [Pick a Spotv Reservation Get](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-get)
* [Pick a Spotv Reservation Put](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-put)
* [Pick a Spotv Reservation Post](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-post)
* [Pick a Spotv Reservation Delete](../../doc/controllers/pick-a-spotv.md#pick-a-spotv-reservation-delete)


# Pick a Spotv Class List

```ruby
def pick_a_spotv_class_list(version,
                            site_id,
                            authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
site_id = '-99'

result = pick_a_spotv_controller.pick_a_spotv_class_list(version, site_id, )
```


# Pick a Spotv Class

```ruby
def pick_a_spotv_class(version,
                       class_id,
                       site_id,
                       authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `class_id` | `String` | Template, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
class_id = 'classId0'
site_id = '-99'

result = pick_a_spotv_controller.pick_a_spotv_class(version, class_id, site_id, )
```


# Pick a Spotv Reservation Get

```ruby
def pick_a_spotv_reservation_get(version,
                                 path_info,
                                 site_id,
                                 authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `path_info` | `String` | Template, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
path_info = 'pathInfo8'
site_id = '-99'

result = pick_a_spotv_controller.pick_a_spotv_reservation_get(version, path_info, site_id, )
```


# Pick a Spotv Reservation Put

```ruby
def pick_a_spotv_reservation_put(version,
                                 path_info,
                                 site_id,
                                 authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `path_info` | `String` | Template, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
path_info = 'pathInfo8'
site_id = '-99'

result = pick_a_spotv_controller.pick_a_spotv_reservation_put(version, path_info, site_id, )
```


# Pick a Spotv Reservation Post

```ruby
def pick_a_spotv_reservation_post(version,
                                  path_info,
                                  site_id,
                                  authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `path_info` | `String` | Template, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
path_info = 'pathInfo8'
site_id = '-99'

result = pick_a_spotv_controller.pick_a_spotv_reservation_post(version, path_info, site_id, )
```


# Pick a Spotv Reservation Delete

```ruby
def pick_a_spotv_reservation_delete(version,
                                    path_info,
                                    site_id,
                                    authorization: nil)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `version` | `String` | Template, Required | version of the api. |
| `path_info` | `String` | Template, Required | - |
| `site_id` | `String` | Header, Required | ID of the site from which to pull data. |
| `authorization` | `String` | Header, Optional | A staff user authorization token. |

## Response Type

`Object`

## Example Usage

```ruby
version = '6'
path_info = 'pathInfo8'
site_id = '-99'

result = pick_a_spotv_controller.pick_a_spotv_reservation_delete(version, path_info, site_id, )
```

