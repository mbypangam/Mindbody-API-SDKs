
# Get Class Schedules Response

## Structure

`GetClassSchedulesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `class_schedules` | [`Array<ClassSchedule>`](../../doc/models/class-schedule.md) | Optional | Contains information about the class schedules. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "ClassSchedules": [
    {
      "Classes": [
        {
          "ClassScheduleId": 120,
          "Visits": [
            {
              "AppointmentId": 29,
              "AppointmentGenderPreference": "Male",
              "AppointmentStatus": "Booked",
              "ClassId": 51,
              "ClientId": "ClientId3"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "Male",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country5",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value6",
                  "Id": 128,
                  "DataType": "DataType2",
                  "Name": "Name8"
                },
                {
                  "Value": "Value7",
                  "Id": 129,
                  "DataType": "DataType3",
                  "Name": "Name9"
                },
                {
                  "Value": "Value8",
                  "Id": 130,
                  "DataType": "DataType4",
                  "Name": "Name0"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "None",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country6",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value7",
                  "Id": 129,
                  "DataType": "DataType3",
                  "Name": "Name9"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "Female",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country7",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value8",
                  "Id": 130,
                  "DataType": "DataType4",
                  "Name": "Name0"
                },
                {
                  "Value": "Value9",
                  "Id": 131,
                  "DataType": "DataType5",
                  "Name": "Name1"
                }
              ]
            }
          ],
          "Location": {},
          "Resource": {
            "Id": 162,
            "Name": "Name0"
          }
        },
        {
          "ClassScheduleId": 119,
          "Visits": [
            {
              "AppointmentId": 30,
              "AppointmentGenderPreference": "Female",
              "AppointmentStatus": "Completed",
              "ClassId": 50,
              "ClientId": "ClientId4"
            },
            {
              "AppointmentId": 29,
              "AppointmentGenderPreference": "Male",
              "AppointmentStatus": "Booked",
              "ClassId": 51,
              "ClientId": "ClientId3"
            },
            {
              "AppointmentId": 28,
              "AppointmentGenderPreference": "None",
              "AppointmentStatus": "Requested",
              "ClassId": 52,
              "ClientId": "ClientId2"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "Female",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country4",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value5",
                  "Id": 127,
                  "DataType": "DataType1",
                  "Name": "Name7"
                },
                {
                  "Value": "Value6",
                  "Id": 128,
                  "DataType": "DataType2",
                  "Name": "Name8"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "Male",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country5",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value6",
                  "Id": 128,
                  "DataType": "DataType2",
                  "Name": "Name8"
                },
                {
                  "Value": "Value7",
                  "Id": 129,
                  "DataType": "DataType3",
                  "Name": "Name9"
                },
                {
                  "Value": "Value8",
                  "Id": 130,
                  "DataType": "DataType4",
                  "Name": "Name0"
                }
              ]
            }
          ],
          "Location": {},
          "Resource": {
            "Id": 163,
            "Name": "Name1"
          }
        },
        {
          "ClassScheduleId": 118,
          "Visits": [
            {
              "AppointmentId": 31,
              "AppointmentGenderPreference": "None",
              "AppointmentStatus": "Confirmed",
              "ClassId": 49,
              "ClientId": "ClientId5"
            },
            {
              "AppointmentId": 30,
              "AppointmentGenderPreference": "Female",
              "AppointmentStatus": "Completed",
              "ClassId": 50,
              "ClientId": "ClientId4"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "None",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country3",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value4",
                  "Id": 126,
                  "DataType": "DataType0",
                  "Name": "Name6"
                }
              ]
            }
          ],
          "Location": {},
          "Resource": {
            "Id": 164,
            "Name": "Name2"
          }
        }
      ],
      "Clients": [
        {},
        {},
        {}
      ],
      "Course": {
        "Id": 209,
        "Name": "Name9",
        "Description": "Description3",
        "Notes": "Notes1",
        "StartDate": "2016-03-13T12:52:32.123Z"
      },
      "SemesterId": 17,
      "IsAvailable": true
    },
    {
      "Classes": [
        {
          "ClassScheduleId": 119,
          "Visits": [
            {
              "AppointmentId": 30,
              "AppointmentGenderPreference": "Female",
              "AppointmentStatus": "Completed",
              "ClassId": 50,
              "ClientId": "ClientId4"
            },
            {
              "AppointmentId": 29,
              "AppointmentGenderPreference": "Male",
              "AppointmentStatus": "Booked",
              "ClassId": 51,
              "ClientId": "ClientId3"
            },
            {
              "AppointmentId": 28,
              "AppointmentGenderPreference": "None",
              "AppointmentStatus": "Requested",
              "ClassId": 52,
              "ClientId": "ClientId2"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "Female",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country4",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value5",
                  "Id": 127,
                  "DataType": "DataType1",
                  "Name": "Name7"
                },
                {
                  "Value": "Value6",
                  "Id": 128,
                  "DataType": "DataType2",
                  "Name": "Name8"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "Male",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country5",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value6",
                  "Id": 128,
                  "DataType": "DataType2",
                  "Name": "Name8"
                },
                {
                  "Value": "Value7",
                  "Id": 129,
                  "DataType": "DataType3",
                  "Name": "Name9"
                },
                {
                  "Value": "Value8",
                  "Id": 130,
                  "DataType": "DataType4",
                  "Name": "Name0"
                }
              ]
            }
          ],
          "Location": {},
          "Resource": {
            "Id": 163,
            "Name": "Name1"
          }
        }
      ],
      "Clients": [
        {}
      ],
      "Course": {
        "Id": 210,
        "Name": "Name0",
        "Description": "Description4",
        "Notes": "Notes2",
        "StartDate": "2016-03-13T12:52:32.123Z"
      },
      "SemesterId": 18,
      "IsAvailable": false
    },
    {
      "Classes": [
        {
          "ClassScheduleId": 118,
          "Visits": [
            {
              "AppointmentId": 31,
              "AppointmentGenderPreference": "None",
              "AppointmentStatus": "Confirmed",
              "ClassId": 49,
              "ClientId": "ClientId5"
            },
            {
              "AppointmentId": 30,
              "AppointmentGenderPreference": "Female",
              "AppointmentStatus": "Completed",
              "ClassId": 50,
              "ClientId": "ClientId4"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "None",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country3",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value4",
                  "Id": 126,
                  "DataType": "DataType0",
                  "Name": "Name6"
                }
              ]
            }
          ],
          "Location": {},
          "Resource": {
            "Id": 164,
            "Name": "Name2"
          }
        },
        {
          "ClassScheduleId": 117,
          "Visits": [
            {
              "AppointmentId": 32,
              "AppointmentGenderPreference": "Male",
              "AppointmentStatus": "Arrived",
              "ClassId": 48,
              "ClientId": "ClientId6"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "Male",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country2",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value3",
                  "Id": 125,
                  "DataType": "DataType9",
                  "Name": "Name5"
                },
                {
                  "Value": "Value4",
                  "Id": 126,
                  "DataType": "DataType0",
                  "Name": "Name6"
                },
                {
                  "Value": "Value5",
                  "Id": 127,
                  "DataType": "DataType1",
                  "Name": "Name7"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "None",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country3",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value4",
                  "Id": 126,
                  "DataType": "DataType0",
                  "Name": "Name6"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "Female",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country4",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value5",
                  "Id": 127,
                  "DataType": "DataType1",
                  "Name": "Name7"
                },
                {
                  "Value": "Value6",
                  "Id": 128,
                  "DataType": "DataType2",
                  "Name": "Name8"
                }
              ]
            }
          ],
          "Location": {},
          "Resource": {
            "Id": 165,
            "Name": "Name3"
          }
        }
      ],
      "Clients": [
        {},
        {}
      ],
      "Course": {
        "Id": 211,
        "Name": "Name1",
        "Description": "Description5",
        "Notes": "Notes3",
        "StartDate": "2016-03-13T12:52:32.123Z"
      },
      "SemesterId": 19,
      "IsAvailable": true
    }
  ]
}
```

