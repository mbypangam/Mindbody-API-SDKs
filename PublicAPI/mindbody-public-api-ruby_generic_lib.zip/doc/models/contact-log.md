
# Contact Log

A contact log.

## Structure

`ContactLog`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The contact log’s ID. |
| `text` | `String` | Optional | The contact log’s body text. |
| `created_date_time` | `DateTime` | Optional | The local date and time when the contact log was created. |
| `followup_by_date` | `DateTime` | Optional | The date by which the assigned staff member should close or follow up on this contact log. |
| `contact_method` | `String` | Optional | The method by which the client wants to be contacted. |
| `contact_name` | `String` | Optional | The name of the client to contact. |
| `client` | [`Client`](../../doc/models/client.md) | Optional | Information about the client to whom the contact log belongs. |
| `created_by` | [`Staff`](../../doc/models/staff.md) | Optional | Information about the staff member who created the contact log. |
| `assigned_to` | [`Staff`](../../doc/models/staff.md) | Optional | Information about the staff member to whom the contact log is assigned for follow up. |
| `comments` | [`Array<ContactLogComment>`](../../doc/models/contact-log-comment.md) | Optional | Information about the comment. |
| `types` | [`Array<ContactLogType>`](../../doc/models/contact-log-type.md) | Optional | Information about the type of contact log. |

## Example (as JSON)

```json
{
  "Id": null,
  "Text": null,
  "CreatedDateTime": null,
  "FollowupByDate": null,
  "ContactMethod": null,
  "ContactName": null,
  "Client": null,
  "CreatedBy": null,
  "AssignedTo": null,
  "Comments": null,
  "Types": null
}
```

