
# Get Genders Response

## Structure

`GetGendersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `gender_options` | [`Array<MindbodyPublicApiDtoModelsV6GenderOption>`](../../doc/models/mindbody-public-api-dto-models-v6-gender-option.md) | Optional | A list of the gender options and their properties at the site |

## Example (as JSON)

```json
{
  "GenderOptions": null
}
```

