
# Mindbody Public Api Dto Models V6 Sale Controller Initialize Credit Card Entry Request

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerInitializeCreditCardEntryRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `String` | Optional | - |
| `merchant_account_id` | `String` | Optional | - |
| `location_id` | `Integer` | Optional | The ID associated with the location of the sale. |

## Example (as JSON)

```json
{
  "ClientId": null,
  "MerchantAccountId": null,
  "LocationId": null
}
```

