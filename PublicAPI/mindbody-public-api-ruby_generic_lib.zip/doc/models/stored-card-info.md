
# Stored Card Info

## Structure

`StoredCardInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `last_four` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "LastFour": null
}
```

