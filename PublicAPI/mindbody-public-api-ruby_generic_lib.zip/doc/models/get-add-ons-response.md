
# Get Add Ons Response

Get AddOns Response Model

## Structure

`GetAddOnsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `add_ons` | [`Array<AppointmentAddOn>`](../../doc/models/appointment-add-on.md) | Optional | A list of available add-ons. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "AddOns": null
}
```

