
# Mindbody Public Api Dto Models V6 Membership Type Restriction

## Structure

`MindbodyPublicApiDtoModelsV6MembershipTypeRestriction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The ID of the membership that is allowed to purchase the contract. |
| `name` | `String` | Optional | The name of the membership type. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

