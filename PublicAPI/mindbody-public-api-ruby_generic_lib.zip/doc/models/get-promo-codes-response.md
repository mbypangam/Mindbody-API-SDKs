
# Get Promo Codes Response

## Structure

`GetPromoCodesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Pagination Response |
| `promo_codes` | [`Array<PromoCode>`](../../doc/models/promo-code.md) | Optional | Contains information about Promocodes at a site |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "PromoCodes": null
}
```

