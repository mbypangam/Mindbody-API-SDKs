
# Get Promo Codes Response

## Structure

`GetPromoCodesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `promo_codes` | [`Array<PromoCode>`](../../doc/models/promo-code.md) | Optional | Contains information about Promocodes at a site |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "PromoCodes": [
    {
      "PromotionID": 146,
      "Name": "Name8",
      "Code": "Code8",
      "Active": false,
      "Discount": {
        "Type": "Type4",
        "Amount": 176.86
      }
    }
  ]
}
```

