
# Response Details

## Structure

`ResponseDetails`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `String` | Optional | - |
| `transaction_id` | `String` | Optional | - |
| `message` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "Status": null,
  "TransactionId": null,
  "Message": null
}
```

