
# Package

## Structure

`Package`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The ID of the package. |
| `name` | `String` | Optional | The name of the package. |
| `discount_percentage` | `Float` | Optional | The discount percentage applied to the package. |
| `sell_online` | `TrueClass\|FalseClass` | Optional | When `true`, only products that can be sold online are returned.<br /><br>When `false`, all products are returned. |
| `services` | [`Array<Service>`](../../doc/models/service.md) | Optional | Information about the services in the packages. |
| `products` | [`Array<Product>`](../../doc/models/product.md) | Optional | Information about the products in the packages. |

## Example (as JSON)

```json
{
  "Id": 146,
  "Name": "Name0",
  "DiscountPercentage": 242.62,
  "SellOnline": false,
  "Services": [
    {
      "Price": 77.35,
      "OnlinePrice": 111.87,
      "TaxIncluded": 184.89,
      "ProgramId": 101,
      "TaxRate": 45.39
    }
  ]
}
```

