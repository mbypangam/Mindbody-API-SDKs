
# Get Contact Logs Response

## Structure

`GetContactLogsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `contact_logs` | [`Array<ContactLog>`](../../doc/models/contact-log.md) | Optional | Contains the information about the contact logs. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ContactLogs": null
}
```

