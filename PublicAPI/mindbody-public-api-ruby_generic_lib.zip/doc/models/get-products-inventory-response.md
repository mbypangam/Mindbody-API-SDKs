
# Get Products Inventory Response

## Structure

`GetProductsInventoryResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `products_inventory` | [`Array<ProductsInventory>`](../../doc/models/products-inventory.md) | Optional | Contains information about the products inventory. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ProductsInventory": null
}
```

