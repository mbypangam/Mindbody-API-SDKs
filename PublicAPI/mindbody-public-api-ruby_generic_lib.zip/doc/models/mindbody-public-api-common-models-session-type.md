
# Mindbody Public Api Common Models Session Type

## Structure

`MindbodyPublicApiCommonModelsSessionType`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | [`Type1Enum`](../../doc/models/type-1-enum.md) | Optional | - |
| `default_time_length` | `Integer` | Optional | - |
| `staff_time_length` | `Integer` | Optional | - |
| `program_id` | `Integer` | Optional | - |
| `num_deducted` | `Integer` | Optional | - |
| `id` | `Integer` | Optional | - |
| `name` | `String` | Optional | - |
| `active` | `TrueClass\|FalseClass` | Optional | - |
| `capacity` | `Integer` | Optional | - |
| `resource_required` | `TrueClass\|FalseClass` | Optional | - |
| `category` | [`MindbodyPublicApiCommonModelsServiceTag`](../../doc/models/mindbody-public-api-common-models-service-tag.md) | Optional | ServiceTag refers to Category and Subcategory fields for classes and appointments |
| `subcategory` | [`MindbodyPublicApiCommonModelsServiceTag`](../../doc/models/mindbody-public-api-common-models-service-tag.md) | Optional | ServiceTag refers to Category and Subcategory fields for classes and appointments |
| `online_description` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "Type": null,
  "DefaultTimeLength": null,
  "StaffTimeLength": null,
  "ProgramId": null,
  "NumDeducted": null,
  "Id": null,
  "Name": null,
  "Active": null,
  "Capacity": null,
  "ResourceRequired": null,
  "Category": null,
  "Subcategory": null,
  "OnlineDescription": null
}
```

