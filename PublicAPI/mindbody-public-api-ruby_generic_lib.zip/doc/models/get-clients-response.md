
# Get Clients Response

## Structure

`GetClientsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination properties to use. |
| `clients` | [`Array<ClientWithSuspensionInfo>`](../../doc/models/client-with-suspension-info.md) | Optional | The requested clients. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Clients": null
}
```

