
# Get Locations Response

## Structure

`GetLocationsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `locations` | [`Array<Location>`](../../doc/models/location.md) | Optional | Contains information about the locations. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Locations": null
}
```

