
# Mindbody Public Api Dto Models V6 Promo Code

## Structure

`MindbodyPublicApiDtoModelsV6PromoCode`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | Name of the promo code |
| `code` | `String` | Optional | Code to be used at purchase for discount |
| `active` | `TrueClass\|FalseClass` | Optional | Active status |
| `discount` | [`MindbodyPublicApiDtoModelsV6Discount`](../../doc/models/mindbody-public-api-dto-models-v6-discount.md) | Optional | Discount info |
| `activation_date` | `DateTime` | Optional | Date activated |
| `expiration_date` | `DateTime` | Optional | Date expired |
| `max_uses` | `Integer` | Optional | How many times it can be used |
| `number_of_autopays` | `Integer` | Optional | Number of Autopays |
| `days_after_close_date` | `Integer` | Optional | Days after close date |
| `allow_online` | `TrueClass\|FalseClass` | Optional | Whether it can be used online |
| `days_valid` | [`Array<DaysValidEnum>`](../../doc/models/days-valid-enum.md) | Optional | What days the promo code can be used |
| `applicable_items` | [`Array<MindbodyPublicApiDtoModelsV6ApplicableItem>`](../../doc/models/mindbody-public-api-dto-models-v6-applicable-item.md) | Optional | Items that the promo code will have the discount for |

## Example (as JSON)

```json
{
  "Name": null,
  "Code": null,
  "Active": null,
  "Discount": null,
  "ActivationDate": null,
  "ExpirationDate": null,
  "MaxUses": null,
  "NumberOfAutopays": null,
  "DaysAfterCloseDate": null,
  "AllowOnline": null,
  "DaysValid": null,
  "ApplicableItems": null
}
```

