
# Initialize Credit Card Entry Request

## Structure

`InitializeCreditCardEntryRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `merchant_account_id` | `String` | Optional | - |
| `location_id` | `Integer` | Optional | The ID associated with the location of the sale. |

## Example (as JSON)

```json
{
  "MerchantAccountId": null,
  "LocationId": null
}
```

