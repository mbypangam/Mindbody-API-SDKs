
# Get Gift Card Response

## Structure

`GetGiftCardResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `gift_cards` | [`Array<MindbodyPublicApiDtoModelsV6GiftCard>`](../../doc/models/mindbody-public-api-dto-models-v6-gift-card.md) | Optional | Contains information about the gift cards. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "GiftCards": null
}
```

