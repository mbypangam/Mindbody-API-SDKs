
# Mindbody Public Api Dto Models V6 Site Controller Get Payment Types Response

Get Payment Types Response Model

## Structure

`MindbodyPublicApiDtoModelsV6SiteControllerGetPaymentTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `payment_types` | [`Array<MindbodyPublicApiCommonModelsPaymentType>`](../../doc/models/mindbody-public-api-common-models-payment-type.md) | Optional | The requested payment types. |

## Example (as JSON)

```json
{
  "PaymentTypes": null
}
```

