
# Pagination

## Structure

`Pagination`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `page_number` | `Integer` | Optional | - |
| `page_size` | `Integer` | Optional | - |
| `total_result_count` | `Integer` | Optional | - |
| `total_page_count` | `Integer` | Optional | - |

## Example (as JSON)

```json
{
  "PageNumber": null,
  "PageSize": null,
  "TotalResultCount": null,
  "TotalPageCount": null
}
```

