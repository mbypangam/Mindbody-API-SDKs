
# Mindbody Public Api Dto Models V6 Sale Controller Get Products Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetProductsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `products` | [`Array<MindbodyPublicApiDtoModelsV6Product>`](../../doc/models/mindbody-public-api-dto-models-v6-product.md) | Optional | Contains information about the products. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Products": null
}
```

