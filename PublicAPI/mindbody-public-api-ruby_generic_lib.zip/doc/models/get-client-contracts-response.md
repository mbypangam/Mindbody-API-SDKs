
# Get Client Contracts Response

## Structure

`GetClientContractsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `contracts` | [`Array<MindbodyPublicApiDtoModelsV6ClientContract>`](../../doc/models/mindbody-public-api-dto-models-v6-client-contract.md) | Optional | Contains the details of the client’s contract. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Contracts": null
}
```

