
# Status 1 Enum

The status of this appointment.

## Enumeration

`Status1Enum`

## Fields

| Name |
|  --- |
| `BOOKED` |
| `COMPLETED` |
| `CONFIRMED` |
| `ARRIVED` |
| `NOSHOW` |
| `CANCELLED` |
| `LATECANCELLED` |

