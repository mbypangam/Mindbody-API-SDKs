
# Get Client Rewards Response

## Structure

`GetClientRewardsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `balance` | `Integer` | Optional | The total rewards points available to the indicated client after the above transaction. |
| `transactions` | [`Array<ClientRewardTransaction>`](../../doc/models/client-reward-transaction.md) | Optional | Contains information about the reward transaction details. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Balance": null,
  "Transactions": null
}
```

