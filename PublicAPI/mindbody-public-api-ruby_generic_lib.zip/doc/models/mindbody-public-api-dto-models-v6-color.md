
# Mindbody Public Api Dto Models V6 Color

A color used by products.

## Structure

`MindbodyPublicApiDtoModelsV6Color`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The ID of the product color. |
| `name` | `String` | Optional | The name of the product color. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

