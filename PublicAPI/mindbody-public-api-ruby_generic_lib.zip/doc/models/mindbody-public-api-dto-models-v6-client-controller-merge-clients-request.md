
# Mindbody Public Api Dto Models V6 Client Controller Merge Clients Request

Request for clients/mergeclients

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerMergeClientsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `source_client_id` | `Integer` | Optional | The client that will be merged into TargetClientId |
| `target_client_id` | `Integer` | Optional | The client that will remain |

## Example (as JSON)

```json
{
  "SourceClientId": null,
  "TargetClientId": null
}
```

