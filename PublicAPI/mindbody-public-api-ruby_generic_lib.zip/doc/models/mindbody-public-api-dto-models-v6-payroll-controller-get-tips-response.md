
# Mindbody Public Api Dto Models V6 Payroll Controller Get Tips Response

## Structure

`MindbodyPublicApiDtoModelsV6PayrollControllerGetTipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `tips` | [`Array<MindbodyPublicApiDtoModelsV6Tip>`](../../doc/models/mindbody-public-api-dto-models-v6-tip.md) | Optional | Contains information about tips given to staff members within the given date range. Results are ordered by StaffId. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Tips": null
}
```

