
# Initialize Credit Card Entry Response

## Structure

`InitializeCreditCardEntryResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `callback_url` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "CallbackUrl": "CallbackUrl2"
}
```

