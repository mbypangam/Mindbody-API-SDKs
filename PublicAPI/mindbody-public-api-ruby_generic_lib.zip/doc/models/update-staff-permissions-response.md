
# Update Staff Permissions Response

## Structure

`UpdateStaffPermissionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_group` | [`MindbodyPublicApiDtoModelsV6StaffPermissionGroup`](../../doc/models/mindbody-public-api-dto-models-v6-staff-permission-group.md) | Optional | Contains information about the staff member’s permission group. |

## Example (as JSON)

```json
{
  "UserGroup": null
}
```

