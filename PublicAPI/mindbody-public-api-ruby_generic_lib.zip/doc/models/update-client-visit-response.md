
# Update Client Visit Response

## Structure

`UpdateClientVisitResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `visit` | [`Visit`](../../doc/models/visit.md) | Optional | The updated visit. |

## Example (as JSON)

```json
{
  "Visit": null
}
```

