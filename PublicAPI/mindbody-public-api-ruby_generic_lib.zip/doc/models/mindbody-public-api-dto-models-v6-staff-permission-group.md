
# Mindbody Public Api Dto Models V6 Staff Permission Group

## Structure

`MindbodyPublicApiDtoModelsV6StaffPermissionGroup`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `permission_group_name` | `String` | Optional | The name of the permission group. |
| `ip_restricted` | `TrueClass\|FalseClass` | Optional | When `true`, the staff member's permissions are restricted to specific IP addresses.<br /><br>When `false`, the staff member's permissions are not restricted to specific IP addresses. |
| `allowed_permissions` | [`Array<AllowedPermissionEnum>`](../../doc/models/allowed-permission-enum.md) | Optional | A list of the permissions allowed to the staff member. See [Permission Values](https://developers.mindbodyonline.com/PublicDocumentation/V6#epermission-values) for descriptions of the possible permissions. |
| `denied_permissions` | [`Array<DeniedPermissionEnum>`](../../doc/models/denied-permission-enum.md) | Optional | A list of the permissions that the staff member is not allowed to exercise. See [Permission Values](https://developers.mindbodyonline.com/PublicDocumentation/V6#epermission-values) for descriptions of the possible permissions. |

## Example (as JSON)

```json
{
  "PermissionGroupName": null,
  "IpRestricted": null,
  "AllowedPermissions": null,
  "DeniedPermissions": null
}
```

