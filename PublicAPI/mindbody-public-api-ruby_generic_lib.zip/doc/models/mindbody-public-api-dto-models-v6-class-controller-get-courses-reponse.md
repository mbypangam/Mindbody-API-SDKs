
# Mindbody Public Api Dto Models V6 Class Controller Get Courses Reponse

This is the response class for the get courses API

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetCoursesReponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | This is the pgaination response |
| `courses` | [`Array<MindbodyPublicApiDtoModelsV6Course>`](../../doc/models/mindbody-public-api-dto-models-v6-course.md) | Optional | This is the list course data |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Courses": null
}
```

