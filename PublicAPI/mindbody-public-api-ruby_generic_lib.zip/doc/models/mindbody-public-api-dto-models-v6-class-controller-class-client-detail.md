
# Mindbody Public Api Dto Models V6 Class Controller Class Client Detail

Class Client Detail Object

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerClassClientDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_ids` | `Array<String>` | Required | The RSSID of the clients to remove from the specified classes. |
| `class_id` | `Integer` | Required | The ID of the classes that you want to remove the clients from. |

## Example (as JSON)

```json
{
  "ClientIds": [
    "ClientIds3",
    "ClientIds4"
  ],
  "ClassId": 58
}
```

