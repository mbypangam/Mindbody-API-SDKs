
# Mindbody Public Api Dto Models V6 Staff Controller Get Staff Response

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | - |
| `staff_members` | [`Array<MindbodyPublicApiDtoModelsV6Staff>`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | A list of staff members. See Staff for a description of the 'Staff' information. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "StaffMembers": null
}
```

