
# Get Client Indexes Response

## Structure

`GetClientIndexesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_indexes` | [`Array<ClientIndex>`](../../doc/models/client-index.md) | Optional | Contains information about the client indexes. |

## Example (as JSON)

```json
{
  "ClientIndexes": null
}
```

