
# Appointment Gender Preference 1 Enum

The gender of staff member with whom the client prefers to book appointments.

## Enumeration

`AppointmentGenderPreference1Enum`

## Fields

| Name |
|  --- |
| `NONE` |
| `FEMALE` |
| `MALE` |

