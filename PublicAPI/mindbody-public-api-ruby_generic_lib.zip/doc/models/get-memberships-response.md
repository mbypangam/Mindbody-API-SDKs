
# Get Memberships Response

## Structure

`GetMembershipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `memberships` | [`Array<Membership>`](../../doc/models/membership.md) | Optional | Details about the memberships. |

## Example (as JSON)

```json
{
  "Memberships": null
}
```

