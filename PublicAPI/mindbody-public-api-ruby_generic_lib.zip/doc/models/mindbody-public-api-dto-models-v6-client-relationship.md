
# Mindbody Public Api Dto Models V6 Client Relationship

A relation between two clients.

## Structure

`MindbodyPublicApiDtoModelsV6ClientRelationship`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `related_client_id` | `String` | Optional | The RSSID of the related client. |
| `relationship` | [`MindbodyPublicApiDtoModelsV6Relationship`](../../doc/models/mindbody-public-api-dto-models-v6-relationship.md) | Optional | Contains details about the relationship between two clients. |
| `relationship_name` | `String` | Optional | The name of the relationship of the related client. |
| `delete` | `TrueClass\|FalseClass` | Optional | When true, the associated relationship is removed from the client's list of relationships.<br><br>This property is ignored in all other use cases.<br>Default: *false* |

## Example (as JSON)

```json
{
  "RelatedClientId": null,
  "Relationship": null,
  "RelationshipName": null,
  "Delete": null
}
```

