
# Get Contact Log Types Response

## Structure

`GetContactLogTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `contact_log_types` | [`Array<MindbodyPublicApiDtoModelsV6ContactLogType>`](../../doc/models/mindbody-public-api-dto-models-v6-contact-log-type.md) | Optional | The requested Active ContactLogTypes |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ContactLogTypes": null
}
```

