
# Get Staff Session Types Response

## Structure

`GetStaffSessionTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination properties used. |
| `staff_session_types` | [`Array<MindbodyPublicApiDtoModelsV6StaffSessionType>`](../../doc/models/mindbody-public-api-dto-models-v6-staff-session-type.md) | Optional | Contains information about staff member session types. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "StaffSessionTypes": null
}
```

