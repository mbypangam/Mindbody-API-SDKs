
# Get Semesters Response

Get Semesters Response Model

## Structure

`GetSemestersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `semesters` | [`Array<MindbodyPublicApiDtoModelsV6Semester>`](../../doc/models/mindbody-public-api-dto-models-v6-semester.md) | Optional | Contains the Semester objects, each of which describes the semesters for a site. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Semesters": null
}
```

