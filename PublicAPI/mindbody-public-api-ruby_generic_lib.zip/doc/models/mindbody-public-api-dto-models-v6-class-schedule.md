
# Mindbody Public Api Dto Models V6 Class Schedule

Represents a single class instance. The class meets at the start time, goes until the end time.

## Structure

`MindbodyPublicApiDtoModelsV6ClassSchedule`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `classes` | [`Array<MindbodyPublicApiDtoModelsV6Class>`](../../doc/models/mindbody-public-api-dto-models-v6-class.md) | Optional | Contains information about a class. |
| `clients` | [`Array<MindbodyPublicApiDtoModelsV6Client>`](../../doc/models/mindbody-public-api-dto-models-v6-client.md) | Optional | Contains information about clients. |
| `course` | [`MindbodyPublicApiDtoModelsV6Course`](../../doc/models/mindbody-public-api-dto-models-v6-course.md) | Optional | Contains information about the course that the enrollment is a part of. |
| `semester_id` | `Integer` | Optional | The semester ID for the enrollment (if any). |
| `is_available` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that the enrollment shows in consumer mode, has not started yet, and there is room in each class of the enrollment.<br /><br>When `false`, indicates that either the enrollment does not show in consumer mode, has already started, or there is no room in some classes of the enrollment. |
| `id` | `Integer` | Optional | The unique ID of the class schedule. |
| `class_description` | [`MindbodyPublicApiDtoModelsV6ClassDescription`](../../doc/models/mindbody-public-api-dto-models-v6-class-description.md) | Optional | Contains information about the class. |
| `day_sunday` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that this schedule occurs on Sundays. |
| `day_monday` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that this schedule occurs on Mondays. |
| `day_tuesday` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that this schedule occurs on Tuesdays. |
| `day_wednesday` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that this schedule occurs on Wednesdays. |
| `day_thursday` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that this schedule occurs on Thursdays. |
| `day_friday` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that this schedule occurs on Fridays. |
| `day_saturday` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that this schedule occurs on Saturdays. |
| `allow_open_enrollment` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that the enrollment allows booking after the enrollment has started. |
| `allow_date_forward_enrollment` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that this the enrollment shows in consumer mode, the enrollment has not started yet, and there is room in each class of the enrollment. |
| `start_time` | `DateTime` | Optional | The time this class schedule starts. |
| `end_time` | `DateTime` | Optional | The time this class schedule ends. |
| `start_date` | `DateTime` | Optional | The date this class schedule starts. |
| `end_date` | `DateTime` | Optional | The date this class schedule ends. |
| `staff` | [`MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | Contains information about the staff member who is regularly scheduled to teach the class. |
| `location` | [`MindbodyPublicApiDtoModelsV6Location`](../../doc/models/mindbody-public-api-dto-models-v6-location.md) | Optional | Contains information about the regularly scheduled location of this class. |

## Example (as JSON)

```json
{
  "Classes": null,
  "Clients": null,
  "Course": null,
  "SemesterId": null,
  "IsAvailable": null,
  "Id": null,
  "ClassDescription": null,
  "DaySunday": null,
  "DayMonday": null,
  "DayTuesday": null,
  "DayWednesday": null,
  "DayThursday": null,
  "DayFriday": null,
  "DaySaturday": null,
  "AllowOpenEnrollment": null,
  "AllowDateForwardEnrollment": null,
  "StartTime": null,
  "EndTime": null,
  "StartDate": null,
  "EndDate": null,
  "Staff": null,
  "Location": null
}
```

