
# Mindbody Public Api Dto Models V6 Autopay Schedule

## Structure

`MindbodyPublicApiDtoModelsV6AutopaySchedule`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `frequency_type` | `String` | Optional | Defines how often clients are charged. Possible values are:<br><br>* SetNumberOfAutopays<br>* MonthToMonth |
| `frequency_value` | `Integer` | Optional | The interval of AutoPay frequency, combined with `FrequencyTimeUnit`. This value is null if `FrequencyType` is `MonthToMonth`. |
| `frequency_time_unit` | `String` | Optional | Defines the time unit that sets how often to run the AutoPay, combined with `FrequencyValue`. This value is null if `FrequencyType` is `MonthToMonth`. Possible values are:<br><br>* Weekly<br>* Monthly<br>* Yearly |

## Example (as JSON)

```json
{
  "FrequencyType": null,
  "FrequencyValue": null,
  "FrequencyTimeUnit": null
}
```

