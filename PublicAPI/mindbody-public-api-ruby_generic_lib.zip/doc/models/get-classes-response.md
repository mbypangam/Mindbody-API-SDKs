
# Get Classes Response

## Structure

`GetClassesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `classes` | [`Array<MindbodyPublicApiDtoModelsV6Class>`](../../doc/models/mindbody-public-api-dto-models-v6-class.md) | Optional | A list of the requested classes. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Classes": null
}
```

