
# Pick a Spot Class

Pick A Spot class detail.

## Structure

`PickASpotClass`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `site_id` | `Integer` | Optional | Site ID. |
| `location_id` | `Integer` | Optional | Location ID. |
| `class_id` | `String` | Optional | Class ID. |
| `class_external_id` | `String` | Optional | Class external ID. |
| `class_name` | `String` | Optional | Class Name. |
| `class_start_time` | `DateTime` | Optional | Class start time. |
| `class_end_time` | `DateTime` | Optional | Class end time. |
| `class_maximum_capacity` | `Integer` | Optional | Class maximum capacity |
| `room_id` | `String` | Optional | - |
| `spots` | [`Spot`](../../doc/models/spot.md) | Optional | - |
| `reservations` | [`Array<Reservation>`](../../doc/models/reservation.md) | Optional | - |

## Example (as JSON)

```json
{
  "SiteId": null,
  "LocationId": null,
  "ClassId": null,
  "ClassExternalId": null,
  "ClassName": null,
  "ClassStartTime": null,
  "ClassEndTime": null,
  "ClassMaximumCapacity": null,
  "RoomId": null,
  "Spots": null,
  "Reservations": null
}
```

