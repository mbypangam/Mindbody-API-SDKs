
# Mindbody Public Api Dto Models V6 Client Controller Get Required Client Fields Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetRequiredClientFieldsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `required_client_fields` | `Array<String>` | Optional | A list of strings that maps to the client fields that are required by the site. |

## Example (as JSON)

```json
{
  "RequiredClientFields": null
}
```

