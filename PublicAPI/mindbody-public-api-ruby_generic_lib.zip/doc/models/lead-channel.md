
# Lead Channel

## Structure

`LeadChannel`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |
| `name` | `String` | Optional | - |
| `salespipeline_id` | `Integer` | Optional | - |
| `universal_customer_id` | `UUID \| String` | Optional | - |
| `studio_id` | `Integer` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "SalespipelineId": null,
  "UniversalCustomerId": null,
  "StudioId": null
}
```

