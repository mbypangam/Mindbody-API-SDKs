
# Reservation

## Structure

`Reservation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reservation_id` | `String` | Optional | - |
| `reservation_external_id` | `String` | Optional | - |
| `class_id` | `String` | Optional | - |
| `class_external_id` | `String` | Optional | - |
| `member_external_id` | `String` | Optional | - |
| `reservation_type` | `String` | Optional | - |
| `spots` | [`Spot`](../../doc/models/spot.md) | Optional | - |
| `is_confirmed` | `TrueClass\|FalseClass` | Optional | - |
| `confirmation_date` | `DateTime` | Optional | - |

## Example (as JSON)

```json
{
  "ReservationId": null,
  "ReservationExternalId": null,
  "ClassId": null,
  "ClassExternalId": null,
  "MemberExternalId": null,
  "ReservationType": null,
  "Spots": null,
  "IsConfirmed": null,
  "ConfirmationDate": null
}
```

