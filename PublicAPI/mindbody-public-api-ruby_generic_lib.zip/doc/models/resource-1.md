
# Resource 1

## Structure

`Resource1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |
| `name` | `String` | Optional | - |
| `location_id` | `Integer` | Optional | - |
| `is_active` | `TrueClass\|FalseClass` | Optional | - |
| `schedule_types` | [`Array<ScheduleType4Enum>`](../../doc/models/schedule-type-4-enum.md) | Optional | - |
| `program_ids` | `Array<Integer>` | Optional | - |

## Example (as JSON)

```json
{
  "Id": 146,
  "Name": "Name0",
  "LocationId": 50,
  "IsActive": false,
  "ScheduleTypes": [
    "Media",
    "Arrival"
  ]
}
```

