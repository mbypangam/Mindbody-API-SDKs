
# Mindbody Public Api Dto Models V6 Appointment Controller Get Add Ons Response

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerGetAddOnsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `add_ons` | [`Array<MindbodyPublicApiDtoModelsV6AppointmentAddOn>`](../../doc/models/mindbody-public-api-dto-models-v6-appointment-add-on.md) | Optional | Contains information about the availabilities for appointment booking. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "AddOns": null
}
```

