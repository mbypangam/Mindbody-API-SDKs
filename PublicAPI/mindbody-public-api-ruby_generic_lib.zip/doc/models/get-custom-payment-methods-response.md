
# Get Custom Payment Methods Response

## Structure

`GetCustomPaymentMethodsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `payment_methods` | [`Array<CustomPaymentMethod>`](../../doc/models/custom-payment-method.md) | Optional | Contains information about the custom payment methods. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "PaymentMethods": null
}
```

