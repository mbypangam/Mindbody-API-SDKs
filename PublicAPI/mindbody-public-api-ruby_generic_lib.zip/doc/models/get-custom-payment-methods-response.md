
# Get Custom Payment Methods Response

## Structure

`GetCustomPaymentMethodsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `payment_methods` | [`Array<MindbodyPublicApiDtoModelsV6CustomPaymentMethod>`](../../doc/models/mindbody-public-api-dto-models-v6-custom-payment-method.md) | Optional | Contains information about the custom payment methods. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "PaymentMethods": null
}
```

