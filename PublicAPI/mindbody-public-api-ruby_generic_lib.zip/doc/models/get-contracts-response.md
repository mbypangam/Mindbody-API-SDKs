
# Get Contracts Response

## Structure

`GetContractsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `contracts` | [`Array<Contract>`](../../doc/models/contract.md) | Optional | Contains information about each contract. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Contracts": null
}
```

