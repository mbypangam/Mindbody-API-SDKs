
# Get Contracts Response

## Structure

`GetContractsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `contracts` | [`Array<Contract>`](../../doc/models/contract.md) | Optional | Contains information about each contract. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Contracts": [
    {
      "Id": 249,
      "Name": "Name9",
      "Description": "Description3",
      "AssignsMembershipId": 125,
      "AssignsMembershipName": "AssignsMembershipName9"
    },
    {
      "Id": 250,
      "Name": "Name0",
      "Description": "Description4",
      "AssignsMembershipId": 126,
      "AssignsMembershipName": "AssignsMembershipName0"
    }
  ]
}
```

