
# Mindbody Public Api Dto Models V6 Class Controller Get Semesters Response

Get Semesters Response Model

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerGetSemestersResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. |
| `semesters` | [`Array<MindbodyPublicApiDtoModelsV6Semester>`](../../doc/models/mindbody-public-api-dto-models-v6-semester.md) | Optional | Contains the Semester objects, each of which describes the semesters for a site. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Semesters": null
}
```

