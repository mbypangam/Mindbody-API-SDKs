
# Get Client Referral Types Response

## Structure

`GetClientReferralTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `referral_types` | `Array<String>` | Optional | The list of available referral types. |

## Example (as JSON)

```json
{
  "ReferralTypes": [
    "ReferralTypes9",
    "ReferralTypes0"
  ]
}
```

