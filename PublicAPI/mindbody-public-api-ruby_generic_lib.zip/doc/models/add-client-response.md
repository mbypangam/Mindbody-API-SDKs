
# Add Client Response

## Structure

`AddClientResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client` | [`Client`](../../doc/models/client.md) | Optional | Contains information about the client. |

## Example (as JSON)

```json
{
  "Client": null
}
```

