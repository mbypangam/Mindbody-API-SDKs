
# Remove Clients From Classes Response

Remove Clients From Classes Response

## Structure

`RemoveClientsFromClassesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `classes` | [`Array<Class>`](../../doc/models/class.md) | Optional | Contains information about the classes from which the clients were removed. |
| `errors` | [`Array<ApiError>`](../../doc/models/api-error.md) | Optional | Contains information about the errors |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Classes": null,
  "Errors": null
}
```

