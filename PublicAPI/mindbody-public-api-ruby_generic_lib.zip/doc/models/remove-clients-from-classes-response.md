
# Remove Clients From Classes Response

Remove Clients From Classes Response

## Structure

`RemoveClientsFromClassesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `classes` | [`Array<MindbodyPublicApiDtoModelsV6Class>`](../../doc/models/mindbody-public-api-dto-models-v6-class.md) | Optional | Contains information about the classes from which the clients were removed. |
| `errors` | [`Array<MindbodyPublicApiDtoModelsV6ApiError>`](../../doc/models/mindbody-public-api-dto-models-v6-api-error.md) | Optional | Contains information about the errors |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Classes": null,
  "Errors": null
}
```

