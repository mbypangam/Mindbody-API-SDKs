
# Mindbody Public Api Dto Models V6 Client Controller Update Client Service Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerUpdateClientServiceResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_service` | [`MindbodyPublicApiDtoModelsV6ClientService`](../../doc/models/mindbody-public-api-dto-models-v6-client-service.md) | Optional | A service that is on a client's account. |

## Example (as JSON)

```json
{
  "ClientService": null
}
```

