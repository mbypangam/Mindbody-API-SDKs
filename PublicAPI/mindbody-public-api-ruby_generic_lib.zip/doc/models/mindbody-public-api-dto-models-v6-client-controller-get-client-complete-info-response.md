
# Mindbody Public Api Dto Models V6 Client Controller Get Client Complete Info Response

Contains information about the requested client.

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientCompleteInfoResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client` | [`MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo`](../../doc/models/mindbody-public-api-dto-models-v6-client-with-suspension-info.md) | Optional | A Client DTO with Suspension Informatoin |
| `client_services` | [`Array<MindbodyPublicApiDtoModelsV6ClientService>`](../../doc/models/mindbody-public-api-dto-models-v6-client-service.md) | Optional | Contains information about client pricing options. |
| `client_contracts` | [`Array<MindbodyPublicApiDtoModelsV6ClientContract>`](../../doc/models/mindbody-public-api-dto-models-v6-client-contract.md) | Optional | Contains information about client contract. |
| `client_memberships` | [`Array<MindbodyPublicApiDtoModelsV6ClientMembership>`](../../doc/models/mindbody-public-api-dto-models-v6-client-membership.md) | Optional | Contains information about client Memberships. |
| `client_arrivals` | [`Array<MindbodyPublicApiDtoModelsV6ClientArrival>`](../../doc/models/mindbody-public-api-dto-models-v6-client-arrival.md) | Optional | Contains information about client arrival services. |

## Example (as JSON)

```json
{
  "Client": null,
  "ClientServices": null,
  "ClientContracts": null,
  "ClientMemberships": null,
  "ClientArrivals": null
}
```

