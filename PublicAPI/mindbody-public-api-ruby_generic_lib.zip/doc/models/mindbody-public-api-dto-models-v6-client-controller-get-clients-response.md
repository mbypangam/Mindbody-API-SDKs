
# Mindbody Public Api Dto Models V6 Client Controller Get Clients Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetClientsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `clients` | [`Array<MindbodyPublicApiDtoModelsV6ClientWithSuspensionInfo>`](../../doc/models/mindbody-public-api-dto-models-v6-client-with-suspension-info.md) | Optional | The requested clients. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Clients": null
}
```

