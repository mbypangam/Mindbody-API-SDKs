
# Mindbody Public Api Dto Models V6 Level

A session level.

## Structure

`MindbodyPublicApiDtoModelsV6Level`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The level's ID. |
| `name` | `String` | Optional | The level's name. |
| `description` | `String` | Optional | The level's description. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "Description": null
}
```

