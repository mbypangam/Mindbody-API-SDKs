
# Promo Code

## Structure

`PromoCode`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `String` | Optional | Name of the promo code |
| `code` | `String` | Optional | The code of the promocode. |
| `active` | `TrueClass\|FalseClass` | Optional | Indicates that promocode is active. |
| `discount` | [`Discount`](../../doc/models/discount.md) | Optional | Contains information about the discount. |
| `activation_date` | `DateTime` | Optional | The promocode activation date. |
| `expiration_date` | `DateTime` | Optional | The promocode expiration date. |
| `max_uses` | `Integer` | Optional | The maximun number of uses. |
| `number_of_autopays` | `Integer` | Optional | Number of Autopays |
| `days_after_close_date` | `Integer` | Optional | The number of days a client has to use a promocode after they are no longer a prospect. |
| `allow_online` | `TrueClass\|FalseClass` | Optional | Indicates if promocode to be redeemed online in consumer mode. |
| `days_valid` | [`Array<DaysValidEnum>`](../../doc/models/days-valid-enum.md) | Optional | Indicates what days of the week promocode can be redeemed. |
| `applicable_items` | [`Array<ApplicableItem>`](../../doc/models/applicable-item.md) | Optional | Contains information about a promocode applicable items. |

## Example (as JSON)

```json
{
  "Name": null,
  "Code": null,
  "Active": null,
  "Discount": null,
  "ActivationDate": null,
  "ExpirationDate": null,
  "MaxUses": null,
  "NumberOfAutopays": null,
  "DaysAfterCloseDate": null,
  "AllowOnline": null,
  "DaysValid": null,
  "ApplicableItems": null
}
```

