
# Checkout Item Wrapper

## Structure

`CheckoutItemWrapper`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `item` | [`CheckoutItem`](../../doc/models/checkout-item.md) | Optional | - |
| `discount_amount` | `Float` | Optional | The amount the item is discounted. This parameter is ignored for packages. |
| `appointment_booking_requests` | [`Array<CheckoutAppointmentBookingRequest>`](../../doc/models/checkout-appointment-booking-request.md) | Optional | A list of appointments to be booked then paid for by this item. This parameter applies only to pricing option items. |
| `enrollment_ids` | `Array<Integer>` | Optional | A list of enrollment IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `class_ids` | `Array<Integer>` | Optional | A list of class IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `course_ids` | `Array<Integer>` | Optional | A list of course IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `visit_ids` | `Array<Integer>` | Optional | A list of visit IDs that this item is to pay for. This parameter applies only to pricing option items. |
| `appointment_ids` | `Array<Integer>` | Optional | A list of appointment IDs that this item is to reconcile. |
| `id` | `Integer` | Optional | The item’s unique ID within the cart. |
| `quantity` | `Integer` | Optional | The number of this item to be purchased. |

## Example (as JSON)

```json
{
  "Item": {
    "Type": "Type2",
    "Metadata": {
      "key0": {
        "key1": "val1",
        "key2": "val2"
      }
    }
  },
  "DiscountAmount": 68.14,
  "AppointmentBookingRequests": [
    {
      "StaffId": 214,
      "LocationId": 248,
      "SessionTypeId": 108,
      "Resources": [
        {
          "Id": 169,
          "Name": "Name7"
        },
        {
          "Id": 168,
          "Name": "Name8"
        }
      ],
      "StartDateTime": "2016-03-13T12:52:32.123Z"
    }
  ],
  "EnrollmentIds": [
    51,
    52
  ],
  "ClassIds": [
    211,
    212,
    213
  ]
}
```

