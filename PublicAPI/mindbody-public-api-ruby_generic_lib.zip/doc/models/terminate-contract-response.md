
# Terminate Contract Response

## Structure

`TerminateContractResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contract` | [`MindbodyPublicApiDtoModelsV6ClientContract`](../../doc/models/mindbody-public-api-dto-models-v6-client-contract.md) | Optional | Contains confirmation message for the successful contract termination. |

## Example (as JSON)

```json
{
  "Contract": null
}
```

