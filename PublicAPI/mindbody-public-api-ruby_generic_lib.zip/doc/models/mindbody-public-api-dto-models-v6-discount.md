
# Mindbody Public Api Dto Models V6 Discount

Discount for a promo code

## Structure

`MindbodyPublicApiDtoModelsV6Discount`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `String` | Optional | Type of discount percentage/amount |
| `amount` | `Float` | Optional | Amount of discount |

## Example (as JSON)

```json
{
  "Type": null,
  "Amount": null
}
```

