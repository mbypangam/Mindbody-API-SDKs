
# Update Availability Response

This is the update avaialability response

## Structure

`UpdateAvailabilityResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `staff_members` | [`Array<Staff>`](../../doc/models/staff.md) | Optional | This is the success list of the trainer availability |
| `errors` | [`Array<ApiError>`](../../doc/models/api-error.md) | Optional | - |

## Example (as JSON)

```json
{
  "StaffMembers": [
    {
      "Address": "Address4",
      "AppointmentInstructor": false,
      "AlwaysAllowDoubleBooking": false,
      "Bio": "Bio8",
      "City": "City4"
    },
    {
      "Address": "Address5",
      "AppointmentInstructor": true,
      "AlwaysAllowDoubleBooking": true,
      "Bio": "Bio9",
      "City": "City5"
    }
  ],
  "Errors": [
    {
      "Message": "Message8",
      "Code": "Code2"
    }
  ]
}
```

