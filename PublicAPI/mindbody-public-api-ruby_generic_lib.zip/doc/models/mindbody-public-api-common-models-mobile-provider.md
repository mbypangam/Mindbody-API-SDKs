
# Mindbody Public Api Common Models Mobile Provider

## Structure

`MindbodyPublicApiCommonModelsMobileProvider`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |
| `active` | `TrueClass\|FalseClass` | Optional | - |
| `provider_name` | `String` | Optional | - |
| `provider_address` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "Id": null,
  "Active": null,
  "ProviderName": null,
  "ProviderAddress": null
}
```

