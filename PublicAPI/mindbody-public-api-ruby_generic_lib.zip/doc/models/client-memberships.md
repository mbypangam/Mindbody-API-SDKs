
# Client Memberships

## Structure

`ClientMemberships`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `String` | Optional | ID of the client. |
| `memberships` | [`Array<ClientMembership>`](../../doc/models/client-membership.md) | Optional | Contains information about the Client Memberships details. |
| `error_message` | `String` | Optional | Incase if invalid clientID passed, we get ErrorMessage instead of Memberships. |

## Example (as JSON)

```json
{
  "ClientId": null,
  "Memberships": null,
  "ErrorMessage": null
}
```

