
# Get Sites Response

## Structure

`GetSitesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `sites` | [`Array<Site>`](../../doc/models/site.md) | Optional | Contains information about the sites. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Sites": null
}
```

