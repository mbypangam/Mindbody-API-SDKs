
# Mindbody Public Api Dto Models V6 Sale Payment

## Structure

`MindbodyPublicApiDtoModelsV6SalePayment`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | A unique identifier for this payment. |
| `amount` | `Float` | Optional | The amount of this payment. |
| `method` | `Integer` | Optional | The method for this payment. |
| `type` | `String` | Optional | The type of payment. |
| `notes` | `String` | Optional | Notes about this payment. |
| `transaction_id` | `Integer` | Optional | The payment transaction ID |

## Example (as JSON)

```json
{
  "Id": null,
  "Amount": null,
  "Method": null,
  "Type": null,
  "Notes": null,
  "TransactionId": null
}
```

