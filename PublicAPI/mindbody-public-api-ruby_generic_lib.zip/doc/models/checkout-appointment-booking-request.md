
# Checkout Appointment Booking Request

## Structure

`CheckoutAppointmentBookingRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `staff_id` | `Integer` | Optional | The ID of the staff member who is to provide the service being booked. |
| `location_id` | `Integer` | Optional | The ID of the location where the appointment is to take place. |
| `session_type_id` | `Integer` | Optional | The ID of the session type of this appointment. |
| `resources` | [`Array<ResourceSlim>`](../../doc/models/resource-slim.md) | Optional | Contains information about the resources to be used for the appointment. |
| `start_date_time` | `DateTime` | Optional | The date and time that the appointment is to start in the business’ timezone. This value must be passed in the format yyyy-mm-ddThh:mm:ss. |
| `end_date_time` | `DateTime` | Optional | The date and time that the appointment is to end in the business’ timezone. This value must be passed in the format yyyy-mm-ddThh:mm:ss. |
| `provider_id` | `String` | Optional | The National Provider Identifier (NPI) of the staff member who is to provide the service. For an explanation of Provider IDs, see [Provider IDs](https://support.mindbodyonline.com/s/article/204075743-Provider-IDs?language=en_US). |

## Example (as JSON)

```json
{
  "StaffId": 156,
  "LocationId": 50,
  "SessionTypeId": 50,
  "Resources": [
    {
      "Id": 181,
      "Name": "Name3"
    },
    {
      "Id": 182,
      "Name": "Name4"
    }
  ],
  "StartDateTime": "2016-03-13T12:52:32.123Z"
}
```

