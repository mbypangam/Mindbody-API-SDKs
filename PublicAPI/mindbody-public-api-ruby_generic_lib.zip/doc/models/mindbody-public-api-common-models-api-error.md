
# Mindbody Public Api Common Models Api Error

## Structure

`MindbodyPublicApiCommonModelsApiError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Optional | - |
| `code` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "Message": null,
  "Code": null
}
```

