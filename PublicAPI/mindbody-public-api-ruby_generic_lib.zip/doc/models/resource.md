
# Resource

## Structure

`Resource`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | - |
| `name` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "Id": 22,
  "Name": "Name6"
}
```

