
# Mindbody Public Api Dto Models V6 Availability

A staff availability entry

## Structure

`MindbodyPublicApiDtoModelsV6Availability`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The ID of the availability. |
| `staff` | [`MindbodyPublicApiDtoModelsV6Staff`](../../doc/models/mindbody-public-api-dto-models-v6-staff.md) | Optional | The Staff |
| `session_type` | [`MindbodyPublicApiDtoModelsV6SessionType`](../../doc/models/mindbody-public-api-dto-models-v6-session-type.md) | Optional | - |
| `programs` | [`Array<MindbodyPublicApiDtoModelsV6Program>`](../../doc/models/mindbody-public-api-dto-models-v6-program.md) | Optional | Contains information about the programs. |
| `start_date_time` | `DateTime` | Optional | The date and time the availability starts. |
| `end_date_time` | `DateTime` | Optional | The date and time the availability ends. |
| `bookable_end_date_time` | `DateTime` | Optional | The time of day that the last appointment can start. |
| `location` | [`MindbodyPublicApiDtoModelsV6Location`](../../doc/models/mindbody-public-api-dto-models-v6-location.md) | Optional | - |
| `prep_time` | `Integer` | Optional | Prep time in minutes |
| `finish_time` | `Integer` | Optional | Finish time in minutes |

## Example (as JSON)

```json
{
  "Id": null,
  "Staff": null,
  "SessionType": null,
  "Programs": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "BookableEndDateTime": null,
  "Location": null,
  "PrepTime": null,
  "FinishTime": null
}
```

