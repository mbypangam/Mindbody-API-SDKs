
# Mindbody Public Api Dto Models V6 Sale Controller Get Packages Response

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerGetPackagesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `packages` | [`Array<MindbodyPublicApiDtoModelsV6Package>`](../../doc/models/mindbody-public-api-dto-models-v6-package.md) | Optional | Contains information about the resulting packages. |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |

## Example (as JSON)

```json
{
  "Packages": null,
  "PaginationResponse": null
}
```

