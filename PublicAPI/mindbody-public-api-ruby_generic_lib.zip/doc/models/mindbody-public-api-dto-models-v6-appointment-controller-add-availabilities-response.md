
# Mindbody Public Api Dto Models V6 Appointment Controller Add Availabilities Response

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAvailabilitiesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `staff_members` | [`Array<MindbodyPublicApiCommonModelsStaff>`](../../doc/models/mindbody-public-api-common-models-staff.md) | Optional | - |
| `errors` | [`Array<MindbodyPublicApiCommonModelsApiError>`](../../doc/models/mindbody-public-api-common-models-api-error.md) | Optional | - |

## Example (as JSON)

```json
{
  "StaffMembers": null,
  "Errors": null
}
```

