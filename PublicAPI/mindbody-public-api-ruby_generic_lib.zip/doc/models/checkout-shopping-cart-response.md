
# Checkout Shopping Cart Response

## Structure

`CheckoutShoppingCartResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `shopping_cart` | [`ShoppingCart`](../../doc/models/shopping-cart.md) | Optional | - |
| `classes` | [`Array<Class>`](../../doc/models/class.md) | Optional | Contains information about the classes. |
| `appointments` | [`Array<Appointment>`](../../doc/models/appointment.md) | Optional | Contains information about the appointments. |
| `enrollments` | [`Array<ClassSchedule>`](../../doc/models/class-schedule.md) | Optional | Contains information about enrollment class schedules. |

## Example (as JSON)

```json
{
  "ShoppingCart": null,
  "Classes": null,
  "Appointments": null,
  "Enrollments": null
}
```

