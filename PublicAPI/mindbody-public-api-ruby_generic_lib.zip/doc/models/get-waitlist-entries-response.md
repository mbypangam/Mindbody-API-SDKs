
# Get Waitlist Entries Response

## Structure

`GetWaitlistEntriesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `waitlist_entries` | [`Array<WaitlistEntry>`](../../doc/models/waitlist-entry.md) | Optional | Contains information about the waiting list entries. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "WaitlistEntries": null
}
```

