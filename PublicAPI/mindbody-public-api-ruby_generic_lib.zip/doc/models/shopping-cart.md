
# Shopping Cart

## Structure

`ShoppingCart`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | The shopping cart ID. |
| `cart_items` | [`Array<CartItem>`](../../doc/models/cart-item.md) | Optional | Contains information about the items in the shopping cart. |
| `sub_total` | `Float` | Optional | The cart’s total cost before taxes and discounts were applied. |
| `discount_total` | `Float` | Optional | The monetary amount removed from the cart’s total cost by applied discounts. |
| `tax_total` | `Float` | Optional | The monetary amount paid in taxes, included in the cart’s `GrandTotal`. |
| `grand_total` | `Float` | Optional | The cart’s total cost, including taxes and discounts. |
| `transactions` | [`Array<TransactionResponse>`](../../doc/models/transaction-response.md) | Optional | Contains information returned from the first call to CheckoutShoppingCart. |

## Example (as JSON)

```json
{
  "Id": "Id6",
  "CartItems": [
    {
      "Item": {
        "key1": "val1",
        "key2": "val2"
      },
      "DiscountAmount": 27.53,
      "VisitIds": [
        115,
        116
      ],
      "AppointmentIds": [
        237
      ],
      "Appointments": [
        {
          "GenderPreference": "Male",
          "Duration": 29,
          "ProviderId": "ProviderId3",
          "Id": 239,
          "Status": "LateCancelled"
        },
        {
          "GenderPreference": "None",
          "Duration": 30,
          "ProviderId": "ProviderId4",
          "Id": 240,
          "Status": "None"
        }
      ]
    }
  ],
  "SubTotal": 108.7,
  "DiscountTotal": 61.16,
  "TaxTotal": 97.6
}
```

