
# Get Class Descriptions Response

## Structure

`GetClassDescriptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `class_descriptions` | [`Array<ClassDescription>`](../../doc/models/class-description.md) | Optional | Contains information about the class descriptions. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClassDescriptions": null
}
```

