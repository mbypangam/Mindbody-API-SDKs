
# Get Client Complete Info Response

Contains information about the requested client.

## Structure

`GetClientCompleteInfoResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client` | [`ClientWithSuspensionInfo`](../../doc/models/client-with-suspension-info.md) | Optional | A Client DTO with Suspension Informatoin |
| `client_services` | [`Array<ClientService>`](../../doc/models/client-service.md) | Optional | Contains information about client pricing options. |
| `client_contracts` | [`Array<ClientContract>`](../../doc/models/client-contract.md) | Optional | Contains information about client contract. |
| `client_memberships` | [`Array<ClientMembership>`](../../doc/models/client-membership.md) | Optional | Contains information about client Memberships. |
| `client_arrivals` | [`Array<ClientArrival>`](../../doc/models/client-arrival.md) | Optional | Contains information about client arrival services. |

## Example (as JSON)

```json
{
  "Client": null,
  "ClientServices": null,
  "ClientContracts": null,
  "ClientMemberships": null,
  "ClientArrivals": null
}
```

