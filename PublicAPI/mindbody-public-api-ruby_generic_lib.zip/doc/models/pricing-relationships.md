
# Pricing Relationships

## Structure

`PricingRelationships`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pays_for` | `Array<Integer>` | Optional | - |
| `paid_by` | `Array<Integer>` | Optional | - |

## Example (as JSON)

```json
{
  "PaysFor": [
    92
  ],
  "PaidBy": [
    198,
    199
  ]
}
```

