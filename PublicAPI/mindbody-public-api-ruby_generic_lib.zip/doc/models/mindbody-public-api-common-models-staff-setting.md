
# Mindbody Public Api Common Models Staff Setting

contains the information about the staff settings.

## Structure

`MindbodyPublicApiCommonModelsStaffSetting`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `use_staff_nicknames` | `TrueClass\|FalseClass` | Optional | When `true`, `DisplayName` of the staff will be displayed.<br>When `false`, `DisplayName` will be displayed as null. |
| `show_staff_last_names_on_schedules` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that the Name contains both the `FirstName` and `LastName` of the staff.<br>When `false`, indicates that the Name contains only the `FirstName` of the staff. |

## Example (as JSON)

```json
{
  "UseStaffNicknames": null,
  "ShowStaffLastNamesOnSchedules": null
}
```

