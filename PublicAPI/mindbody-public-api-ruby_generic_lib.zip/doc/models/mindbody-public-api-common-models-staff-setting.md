
# Mindbody Public Api Common Models Staff Setting

## Structure

`MindbodyPublicApiCommonModelsStaffSetting`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `use_staff_nicknames` | `TrueClass\|FalseClass` | Optional | - |
| `show_staff_last_names_on_schedules` | `TrueClass\|FalseClass` | Optional | - |

## Example (as JSON)

```json
{
  "UseStaffNicknames": null,
  "ShowStaffLastNamesOnSchedules": null
}
```

