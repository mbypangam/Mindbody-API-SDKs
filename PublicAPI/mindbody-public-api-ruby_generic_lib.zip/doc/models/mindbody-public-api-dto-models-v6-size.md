
# Mindbody Public Api Dto Models V6 Size

## Structure

`MindbodyPublicApiDtoModelsV6Size`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The unique ID of the product size. |
| `name` | `String` | Optional | The name of the size of product. |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null
}
```

