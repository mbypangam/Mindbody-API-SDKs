
# Get Transactions Response

Get transactions response properties

## Structure

`GetTransactionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `transactions` | [`Array<Transaction>`](../../doc/models/transaction.md) | Optional | Contains the transaction objects, each of which describes the transaction details for a purchase event. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Transactions": null
}
```

