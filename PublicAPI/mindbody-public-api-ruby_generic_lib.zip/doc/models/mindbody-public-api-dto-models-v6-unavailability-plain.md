
# Mindbody Public Api Dto Models V6 Unavailability Plain

## Structure

`MindbodyPublicApiDtoModelsV6UnavailabilityPlain`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The ID of the unavailability. |
| `staff_id` | `Integer` | Optional | Id of the staff |
| `start_date_time` | `DateTime` | Optional | The date and time the unavailability starts. |
| `end_date_time` | `DateTime` | Optional | The date and time the unavailability ends. |
| `description` | `String` | Optional | A description of the unavailability. |

## Example (as JSON)

```json
{
  "Id": null,
  "StaffId": null,
  "StartDateTime": null,
  "EndDateTime": null,
  "Description": null
}
```

