
# Mindbody Public Api Dto Models V6 Client Reward Transaction

Contains information about the transaction details.

## Structure

`MindbodyPublicApiDtoModelsV6ClientRewardTransaction`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `action_date_time` | `DateTime` | Optional | The date and time when the points were earned or redeemed in the site local time zone. |
| `action` | [`Action9Enum`](../../doc/models/action-9-enum.md) | Optional | Indicates if rewards were earned or redeemed. |
| `source` | `String` | Optional | The source of the reward transaction. |
| `source_id` | `Integer` | Optional | The unique identifier in the MINDBODY system for the **Source**. |
| `expiration_date_time` | `DateTime` | Optional | The date and time when earned points expire. This is calculated based on site and client rewards settings. This date will be in the site local time zone and may be **null**. |
| `points` | `Integer` | Optional | The amount of points the client earned or redeemed. |

## Example (as JSON)

```json
{
  "ActionDateTime": null,
  "Action": null,
  "Source": null,
  "SourceID": null,
  "ExpirationDateTime": null,
  "Points": null
}
```

