
# Spot

## Structure

`Spot`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `reserved_spot_numbers` | `Array<Integer>` | Optional | - |
| `available_spot_numbers` | `Array<Integer>` | Optional | - |
| `unavailable_spot_numbers` | `Array<Integer>` | Optional | - |

## Example (as JSON)

```json
{
  "ReservedSpotNumbers": null,
  "AvailableSpotNumbers": null,
  "UnavailableSpotNumbers": null
}
```

