
# Get Bookable Items Response

## Structure

`GetBookableItemsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `availabilities` | [`Array<Availability>`](../../doc/models/availability.md) | Optional | Contains information about the availabilities for appointment booking. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Availabilities": null
}
```

