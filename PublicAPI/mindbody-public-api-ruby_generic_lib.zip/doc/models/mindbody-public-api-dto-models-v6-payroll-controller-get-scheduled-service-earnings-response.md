
# Mindbody Public Api Dto Models V6 Payroll Controller Get Scheduled Service Earnings Response

## Structure

`MindbodyPublicApiDtoModelsV6PayrollControllerGetScheduledServiceEarningsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination to use. |
| `scheduled_service_earnings` | [`Array<MindbodyPublicApiDtoModelsV6ScheduledServiceEarningsEvent>`](../../doc/models/mindbody-public-api-dto-models-v6-scheduled-service-earnings-event.md) | Optional | Contains the class payroll events. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ScheduledServiceEarnings": null
}
```

