
# Get Appointment Options Response

## Structure

`GetAppointmentOptionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `options` | [`Array<AppointmentOption>`](../../doc/models/appointment-option.md) | Optional | Contains information about the appointment options. |

## Example (as JSON)

```json
{
  "Options": [
    {
      "DisplayName": "DisplayName0",
      "Name": "Name4",
      "Value": "Value6",
      "Type": "Type6"
    },
    {
      "DisplayName": "DisplayName9",
      "Name": "Name3",
      "Value": "Value5",
      "Type": "Type7"
    },
    {
      "DisplayName": "DisplayName8",
      "Name": "Name2",
      "Value": "Value4",
      "Type": "Type8"
    }
  ]
}
```

