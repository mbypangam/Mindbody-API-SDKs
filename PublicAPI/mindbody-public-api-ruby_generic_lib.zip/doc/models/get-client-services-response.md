
# Get Client Services Response

## Structure

`GetClientServicesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `client_services` | [`Array<MindbodyPublicApiDtoModelsV6ClientService>`](../../doc/models/mindbody-public-api-dto-models-v6-client-service.md) | Optional | Contains information about client pricing options. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "ClientServices": null
}
```

