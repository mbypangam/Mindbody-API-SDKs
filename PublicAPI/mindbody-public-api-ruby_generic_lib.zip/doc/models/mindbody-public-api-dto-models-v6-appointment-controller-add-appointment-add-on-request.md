
# Mindbody Public Api Dto Models V6 Appointment Controller Add Appointment Add on Request

Creates an add-on for an appointment

## Structure

`MindbodyPublicApiDtoModelsV6AppointmentControllerAddAppointmentAddOnRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `apply_payment` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that a payment should be applied to the appointment. Currently only ApplyPayment=false is implemented.<br>Default: **true** |
| `appointment_id` | `Integer` | Optional | The appointment ID the add-on is getting added to. |
| `session_type_id` | `Integer` | Optional | The session type associated with the new appointment add-on. |
| `staff_id` | `Integer` | Optional | The ID of the staff member who is adding the new appointment add-on.<br>Default: staff member performing the appointment. |
| `test` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that the method is to be validated, but no new appointment add-on data is added.<br>Default: **false** |

## Example (as JSON)

```json
{
  "ApplyPayment": null,
  "AppointmentId": null,
  "SessionTypeId": null,
  "StaffId": null,
  "Test": null
}
```

