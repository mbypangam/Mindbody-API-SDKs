
# Mindbody Public Api Dto Models V6 Applicable Item

Item that will be applied to a promo code

## Structure

`MindbodyPublicApiDtoModelsV6ApplicableItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `String` | Optional | Type of a promo code |
| `id` | `Integer` | Optional | ID of the item |
| `name` | `String` | Optional | Name of the item |

## Example (as JSON)

```json
{
  "Type": null,
  "Id": null,
  "Name": null
}
```

