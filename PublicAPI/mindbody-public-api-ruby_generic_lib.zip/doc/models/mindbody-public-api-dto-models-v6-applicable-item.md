
# Mindbody Public Api Dto Models V6 Applicable Item

Item that will be applied to a promo code

## Structure

`MindbodyPublicApiDtoModelsV6ApplicableItem`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `type` | `String` | Optional | The promotional item type.<br>Possible values are:<br><br>* ServiceCategory<br>* RevenueCategory<br>* Supplier<br>* Item |
| `id` | `Integer` | Optional | The promotional item ID. |
| `name` | `String` | Optional | The promotional item name. |

## Example (as JSON)

```json
{
  "Type": null,
  "Id": null,
  "Name": null
}
```

