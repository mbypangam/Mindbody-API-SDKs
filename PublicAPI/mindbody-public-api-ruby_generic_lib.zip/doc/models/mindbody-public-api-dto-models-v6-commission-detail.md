
# Mindbody Public Api Dto Models V6 Commission Detail

## Structure

`MindbodyPublicApiDtoModelsV6CommissionDetail`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `commission_type` | `String` | Optional | The type of commission earned. Possible values are:<br><br>* ItemStandardPercentageCommission<br>* ItemStandardFlatCommission<br>* ItemPromotionalPercentageCommission<br>* ItemPromotionalFlatCommission<br>* StaffStandardPercentageCommission<br>* StaffStandardFlatCommission<br>* StaffPromotionalPercentageCommission<br>* StaffPromotionalFlatCommission |
| `commission_earnings` | `Float` | Optional | The portion of `Earnings` earned by this `CommissionType`. |

## Example (as JSON)

```json
{
  "CommissionType": null,
  "CommissionEarnings": null
}
```

