
# Delete Reservation Response

## Structure

`DeleteReservationResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `delete_succeeded` | `TrueClass\|FalseClass` | Optional | delete successded status. |
| `response_detail` | [`ResponseDetails`](../../doc/models/response-details.md) | Optional | Response details information. |

## Example (as JSON)

```json
{
  "DeleteSucceeded": null,
  "ResponseDetail": null
}
```

