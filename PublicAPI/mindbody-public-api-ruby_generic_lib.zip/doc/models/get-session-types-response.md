
# Get Session Types Response

## Structure

`GetSessionTypesResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `session_types` | [`Array<SessionType>`](../../doc/models/session-type.md) | Optional | Contains information about sessions. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "SessionTypes": null
}
```

