
# Get Active Client Memberships Response

## Structure

`GetActiveClientMembershipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `client_memberships` | [`Array<ClientMembership>`](../../doc/models/client-membership.md) | Optional | Details about the requested memberships. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "ClientMemberships": [
    {
      "RestrictedLocations": [
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs3"
          ],
          "Address": "Address1",
          "Address2": "Address23",
          "Amenities": [
            {
              "Id": 71,
              "Name": "Name9"
            },
            {
              "Id": 72,
              "Name": "Name8"
            }
          ],
          "BusinessDescription": "BusinessDescription7"
        },
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs2",
            "AdditionalImageURLs3",
            "AdditionalImageURLs4"
          ],
          "Address": "Address2",
          "Address2": "Address24",
          "Amenities": [
            {
              "Id": 70,
              "Name": "Name0"
            }
          ],
          "BusinessDescription": "BusinessDescription8"
        }
      ],
      "IconCode": "IconCode6",
      "MembershipId": 116,
      "ActiveDate": "2016-03-13T12:52:32.123Z",
      "Count": 116
    },
    {
      "RestrictedLocations": [
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs4",
            "AdditionalImageURLs5"
          ],
          "Address": "Address0",
          "Address2": "Address22",
          "Amenities": [
            {
              "Id": 72,
              "Name": "Name8"
            },
            {
              "Id": 73,
              "Name": "Name7"
            },
            {
              "Id": 74,
              "Name": "Name6"
            }
          ],
          "BusinessDescription": "BusinessDescription6"
        }
      ],
      "IconCode": "IconCode7",
      "MembershipId": 117,
      "ActiveDate": "2016-03-13T12:52:32.123Z",
      "Count": 117
    },
    {
      "RestrictedLocations": [
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs5",
            "AdditionalImageURLs6",
            "AdditionalImageURLs7"
          ],
          "Address": "Address9",
          "Address2": "Address21",
          "Amenities": [
            {
              "Id": 73,
              "Name": "Name7"
            }
          ],
          "BusinessDescription": "BusinessDescription5"
        },
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs4",
            "AdditionalImageURLs5"
          ],
          "Address": "Address0",
          "Address2": "Address22",
          "Amenities": [
            {
              "Id": 72,
              "Name": "Name8"
            },
            {
              "Id": 73,
              "Name": "Name7"
            },
            {
              "Id": 74,
              "Name": "Name6"
            }
          ],
          "BusinessDescription": "BusinessDescription6"
        },
        {
          "AdditionalImageURLs": [
            "AdditionalImageURLs3"
          ],
          "Address": "Address1",
          "Address2": "Address23",
          "Amenities": [
            {
              "Id": 71,
              "Name": "Name9"
            },
            {
              "Id": 72,
              "Name": "Name8"
            }
          ],
          "BusinessDescription": "BusinessDescription7"
        }
      ],
      "IconCode": "IconCode8",
      "MembershipId": 118,
      "ActiveDate": "2016-03-13T12:52:32.123Z",
      "Count": 118
    }
  ]
}
```

