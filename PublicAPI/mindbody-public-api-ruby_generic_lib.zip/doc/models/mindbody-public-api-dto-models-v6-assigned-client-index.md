
# Mindbody Public Api Dto Models V6 Assigned Client Index

Represents a client index value assigned to a client

## Structure

`MindbodyPublicApiDtoModelsV6AssignedClientIndex`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The index ID assigned to the client. |
| `value_id` | `Integer` | Optional | The index?s value ID. |

## Example (as JSON)

```json
{
  "Id": null,
  "ValueId": null
}
```

