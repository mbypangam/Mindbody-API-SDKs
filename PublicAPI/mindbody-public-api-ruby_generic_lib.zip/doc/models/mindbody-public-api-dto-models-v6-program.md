
# Mindbody Public Api Dto Models V6 Program

## Structure

`MindbodyPublicApiDtoModelsV6Program`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `Integer` | Optional | The service category’s ID. |
| `name` | `String` | Optional | The name of this service category. |
| `schedule_type` | [`ScheduleTypeEnum`](../../doc/models/schedule-type-enum.md) | Optional | - |
| `cancel_offset` | `Integer` | Optional | The offset to use for the service category. |
| `content_formats` | `Array<String>` | Optional | The content delivery platform(s) used by the service category. Possible values are:<br><br>* InPerson<br>* Livestream:Mindbody<br>* Livestream:Other |

## Example (as JSON)

```json
{
  "Id": null,
  "Name": null,
  "ScheduleType": null,
  "CancelOffset": null,
  "ContentFormats": null
}
```

