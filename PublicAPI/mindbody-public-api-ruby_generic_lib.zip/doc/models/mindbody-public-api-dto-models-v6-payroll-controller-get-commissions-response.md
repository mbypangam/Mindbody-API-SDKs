
# Mindbody Public Api Dto Models V6 Payroll Controller Get Commissions Response

## Structure

`MindbodyPublicApiDtoModelsV6PayrollControllerGetCommissionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`MindbodyPublicApiDtoModelsV6PaginationResponse`](../../doc/models/mindbody-public-api-dto-models-v6-pagination-response.md) | Optional | Contains information about the pagination used. |
| `commissions` | [`Array<MindbodyPublicApiDtoModelsV6CommissionPayrollPurchaseEvent>`](../../doc/models/mindbody-public-api-dto-models-v6-commission-payroll-purchase-event.md) | Optional | Contains information about commissions earned by staff for sales within the given date range. Results are ordered by `SaleId`, then by `StaffId`. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "Commissions": null
}
```

