
# Get Enrollments Response

## Structure

`GetEnrollmentsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination to use. |
| `enrollments` | [`Array<ClassSchedule>`](../../doc/models/class-schedule.md) | Optional | Contains information about the enrollments. |

## Example (as JSON)

```json
{
  "PaginationResponse": {
    "RequestedLimit": 22,
    "RequestedOffset": 0,
    "PageSize": 172,
    "TotalResults": 112
  },
  "Enrollments": [
    {
      "Classes": [
        {
          "ClassScheduleId": 38,
          "Visits": [
            {
              "AppointmentId": 189,
              "AppointmentGenderPreference": "Male",
              "AppointmentStatus": "Booked",
              "ClassId": 147,
              "ClientId": "ClientId1"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "Male",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country7",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value8",
                  "Id": 46,
                  "DataType": "DataType4",
                  "Name": "Name0"
                },
                {
                  "Value": "Value9",
                  "Id": 47,
                  "DataType": "DataType5",
                  "Name": "Name1"
                },
                {
                  "Value": "Value0",
                  "Id": 48,
                  "DataType": "DataType6",
                  "Name": "Name2"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "None",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country8",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value9",
                  "Id": 47,
                  "DataType": "DataType5",
                  "Name": "Name1"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "Female",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country9",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value0",
                  "Id": 48,
                  "DataType": "DataType6",
                  "Name": "Name2"
                },
                {
                  "Value": "Value1",
                  "Id": 49,
                  "DataType": "DataType7",
                  "Name": "Name3"
                }
              ]
            }
          ],
          "Location": {},
          "Resource": {
            "Id": 244,
            "Name": "Name8"
          }
        },
        {
          "ClassScheduleId": 39,
          "Visits": [
            {
              "AppointmentId": 190,
              "AppointmentGenderPreference": "Female",
              "AppointmentStatus": "Completed",
              "ClassId": 146,
              "ClientId": "ClientId2"
            },
            {
              "AppointmentId": 191,
              "AppointmentGenderPreference": "None",
              "AppointmentStatus": "Confirmed",
              "ClassId": 145,
              "ClientId": "ClientId3"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "None",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country8",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value9",
                  "Id": 47,
                  "DataType": "DataType5",
                  "Name": "Name1"
                }
              ]
            }
          ],
          "Location": {},
          "Resource": {
            "Id": 243,
            "Name": "Name7"
          }
        },
        {
          "ClassScheduleId": 40,
          "Visits": [
            {
              "AppointmentId": 191,
              "AppointmentGenderPreference": "None",
              "AppointmentStatus": "Confirmed",
              "ClassId": 145,
              "ClientId": "ClientId3"
            },
            {
              "AppointmentId": 192,
              "AppointmentGenderPreference": "Male",
              "AppointmentStatus": "Arrived",
              "ClassId": 144,
              "ClientId": "ClientId4"
            },
            {
              "AppointmentId": 193,
              "AppointmentGenderPreference": "Female",
              "AppointmentStatus": "NoShow",
              "ClassId": 143,
              "ClientId": "ClientId5"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "Female",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country9",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value0",
                  "Id": 48,
                  "DataType": "DataType6",
                  "Name": "Name2"
                },
                {
                  "Value": "Value1",
                  "Id": 49,
                  "DataType": "DataType7",
                  "Name": "Name3"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "Male",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country0",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value1",
                  "Id": 49,
                  "DataType": "DataType7",
                  "Name": "Name3"
                },
                {
                  "Value": "Value2",
                  "Id": 50,
                  "DataType": "DataType8",
                  "Name": "Name4"
                },
                {
                  "Value": "Value3",
                  "Id": 51,
                  "DataType": "DataType9",
                  "Name": "Name5"
                }
              ]
            }
          ],
          "Location": {},
          "Resource": {
            "Id": 242,
            "Name": "Name6"
          }
        }
      ],
      "Clients": [
        {},
        {}
      ],
      "Course": {
        "Id": 245,
        "Name": "Name1",
        "Description": "Description5",
        "Notes": "Notes3",
        "StartDate": "2016-03-13T12:52:32.123Z"
      },
      "SemesterId": 203,
      "IsAvailable": true
    },
    {
      "Classes": [
        {
          "ClassScheduleId": 37,
          "Visits": [
            {
              "AppointmentId": 188,
              "AppointmentGenderPreference": "None",
              "AppointmentStatus": "Requested",
              "ClassId": 148,
              "ClientId": "ClientId0"
            },
            {
              "AppointmentId": 189,
              "AppointmentGenderPreference": "Male",
              "AppointmentStatus": "Booked",
              "ClassId": 147,
              "ClientId": "ClientId1"
            },
            {
              "AppointmentId": 190,
              "AppointmentGenderPreference": "Female",
              "AppointmentStatus": "Completed",
              "ClassId": 146,
              "ClientId": "ClientId2"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "Female",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country6",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value7",
                  "Id": 45,
                  "DataType": "DataType3",
                  "Name": "Name9"
                },
                {
                  "Value": "Value8",
                  "Id": 46,
                  "DataType": "DataType4",
                  "Name": "Name0"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "Male",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country7",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value8",
                  "Id": 46,
                  "DataType": "DataType4",
                  "Name": "Name0"
                },
                {
                  "Value": "Value9",
                  "Id": 47,
                  "DataType": "DataType5",
                  "Name": "Name1"
                },
                {
                  "Value": "Value0",
                  "Id": 48,
                  "DataType": "DataType6",
                  "Name": "Name2"
                }
              ]
            }
          ],
          "Location": {},
          "Resource": {
            "Id": 245,
            "Name": "Name9"
          }
        },
        {
          "ClassScheduleId": 38,
          "Visits": [
            {
              "AppointmentId": 189,
              "AppointmentGenderPreference": "Male",
              "AppointmentStatus": "Booked",
              "ClassId": 147,
              "ClientId": "ClientId1"
            }
          ],
          "Clients": [
            {
              "AppointmentGenderPreference": "Male",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country7",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value8",
                  "Id": 46,
                  "DataType": "DataType4",
                  "Name": "Name0"
                },
                {
                  "Value": "Value9",
                  "Id": 47,
                  "DataType": "DataType5",
                  "Name": "Name1"
                },
                {
                  "Value": "Value0",
                  "Id": 48,
                  "DataType": "DataType6",
                  "Name": "Name2"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "None",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country8",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value9",
                  "Id": 47,
                  "DataType": "DataType5",
                  "Name": "Name1"
                }
              ]
            },
            {
              "AppointmentGenderPreference": "Female",
              "BirthDate": "2016-03-13T12:52:32.123Z",
              "Country": "Country9",
              "CreationDate": "2016-03-13T12:52:32.123Z",
              "CustomClientFields": [
                {
                  "Value": "Value0",
                  "Id": 48,
                  "DataType": "DataType6",
                  "Name": "Name2"
                },
                {
                  "Value": "Value1",
                  "Id": 49,
                  "DataType": "DataType7",
                  "Name": "Name3"
                }
              ]
            }
          ],
          "Location": {},
          "Resource": {
            "Id": 244,
            "Name": "Name8"
          }
        }
      ],
      "Clients": [
        {},
        {},
        {}
      ],
      "Course": {
        "Id": 246,
        "Name": "Name2",
        "Description": "Description4",
        "Notes": "Notes4",
        "StartDate": "2016-03-13T12:52:32.123Z"
      },
      "SemesterId": 202,
      "IsAvailable": false
    }
  ]
}
```

