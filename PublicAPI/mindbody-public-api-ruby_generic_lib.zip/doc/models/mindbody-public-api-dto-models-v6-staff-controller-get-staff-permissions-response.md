
# Mindbody Public Api Dto Models V6 Staff Controller Get Staff Permissions Response

## Structure

`MindbodyPublicApiDtoModelsV6StaffControllerGetStaffPermissionsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `user_group` | [`MindbodyPublicApiDtoModelsV6StaffPermissionGroup`](../../doc/models/mindbody-public-api-dto-models-v6-staff-permission-group.md) | Optional | Contains information about the requested staff member’s permission group. |

## Example (as JSON)

```json
{
  "UserGroup": null
}
```

