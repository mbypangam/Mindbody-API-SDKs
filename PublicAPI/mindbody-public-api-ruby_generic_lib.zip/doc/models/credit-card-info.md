
# Credit Card Info

INformation about an individual credit card

## Structure

`CreditCardInfo`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `credit_card_number` | `String` | Optional | - |
| `exp_month` | `String` | Optional | - |
| `exp_year` | `String` | Optional | - |
| `billing_name` | `String` | Optional | - |
| `billing_address` | `String` | Optional | - |
| `billing_city` | `String` | Optional | - |
| `billing_state` | `String` | Optional | - |
| `billing_postal_code` | `String` | Optional | - |
| `save_info` | `TrueClass \| FalseClass` | Optional | - |
| `card_id` | `String` | Optional | Card Id of a stored instruments card |

## Example (as JSON)

```json
{
  "CreditCardNumber": "CreditCardNumber0",
  "ExpMonth": "ExpMonth2",
  "ExpYear": "ExpYear0",
  "BillingName": "BillingName4",
  "BillingAddress": "BillingAddress6"
}
```

