
# Mindbody Public Api Dto Models V6 Class Controller Cancel Single Class Request

## Structure

`MindbodyPublicApiDtoModelsV6ClassControllerCancelSingleClassRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `class_id` | `Integer` | Optional | Class ID to lookup. |
| `hide_cancel` | `TrueClass\|FalseClass` | Optional | When `true`, indicates that this class is hidden when cancelled.<br>When `false`, indicates that this class is not hidden when cancelled. |
| `send_client_email` | `TrueClass\|FalseClass` | Optional | When `true`, sends the client an automatic email about the cancellation, if the client has opted to receive email. |
| `send_staff_email` | `TrueClass\|FalseClass` | Optional | When `true`, sends the staff an automatic email about the cancellation, if the staff has opted to receive email. |

## Example (as JSON)

```json
{
  "ClassID": null,
  "HideCancel": null,
  "SendClientEmail": null,
  "SendStaffEmail": null
}
```

