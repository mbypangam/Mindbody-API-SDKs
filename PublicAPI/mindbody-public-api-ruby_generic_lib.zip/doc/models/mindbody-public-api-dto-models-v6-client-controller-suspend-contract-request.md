
# Mindbody Public Api Dto Models V6 Client Controller Suspend Contract Request

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerSuspendContractRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `client_id` | `String` | Required | The RSSID of the client for whom the contract is getting suspended. |
| `client_contract_id` | `Integer` | Required | The unique ID of the sale of the contract |
| `suspension_type` | `String` | Optional | The suspension type |
| `suspension_start` | `DateTime` | Optional | The date to start contract suspension |
| `duration` | `Integer` | Optional | The number of (DurationUnit) the suspension lasts |
| `duration_unit` | `Integer` | Optional | The unit applied to duration |
| `open_ended` | `TrueClass\|FalseClass` | Optional | Indicates open ended suspension |
| `suspension_notes` | `String` | Optional | The suspension notes |
| `suspension_fee` | `Float` | Optional | charge to suspend a contract for a set period of time |

## Example (as JSON)

```json
{
  "ClientId": "ClientId6",
  "ClientContractId": 86,
  "SuspensionType": null,
  "SuspensionStart": null,
  "Duration": null,
  "DurationUnit": null,
  "OpenEnded": null,
  "SuspensionNotes": null,
  "SuspensionFee": null
}
```

