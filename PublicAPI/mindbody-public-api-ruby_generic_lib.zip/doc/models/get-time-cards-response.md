
# Get Time Cards Response

## Structure

`GetTimeCardsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `pagination_response` | [`PaginationResponse`](../../doc/models/pagination-response.md) | Optional | Contains information about the pagination used. |
| `time_cards` | [`Array<MindbodyPublicApiDtoModelsV6TimeCardEvent>`](../../doc/models/mindbody-public-api-dto-models-v6-time-card-event.md) | Optional | Information about time card entries, ordered by staff ID. |

## Example (as JSON)

```json
{
  "PaginationResponse": null,
  "TimeCards": null
}
```

