
# Mindbody Public Api Dto Models V6 Sale Controller Completed Sale Shopping Cart

## Structure

`MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleShoppingCart`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | The shopping cart ID. |
| `cart_items` | [`Array<MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleCartItem>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-completed-sale-cart-item.md) | Optional | Contains information about the items in the shopping cart. |
| `sub_total` | `Float` | Optional | The cart?s total cost before taxes and discounts were applied. |
| `discount_total` | `Float` | Optional | The monetary amount removed from the cart?s total cost by applied discounts. |
| `tax_total` | `Float` | Optional | The monetary amount paid in taxes, included in the cart?s `GrandTotal`. |
| `grand_total` | `Float` | Optional | The cart?s total cost, including taxes and discounts. |
| `transactions` | [`Array<MindbodyPublicApiDtoModelsV6SaleControllerCompletedSaleTransactionResponse>`](../../doc/models/mindbody-public-api-dto-models-v6-sale-controller-completed-sale-transaction-response.md) | Optional | Contains information returned from the first call to CheckoutShoppingCart. |

## Example (as JSON)

```json
{
  "Id": null,
  "CartItems": null,
  "SubTotal": null,
  "DiscountTotal": null,
  "TaxTotal": null,
  "GrandTotal": null,
  "Transactions": null
}
```

