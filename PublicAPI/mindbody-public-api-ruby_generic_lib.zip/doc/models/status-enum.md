
# Status Enum

The status of this appointment.

## Enumeration

`StatusEnum`

## Fields

| Name |
|  --- |
| `NONE` |
| `REQUESTED` |
| `BOOKED` |
| `COMPLETED` |
| `CONFIRMED` |
| `ARRIVED` |
| `NOSHOW` |
| `CANCELLED` |
| `LATECANCELLED` |

