
# Mindbody Public Api Dto Models V6 Api Error

## Structure

`MindbodyPublicApiDtoModelsV6ApiError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `message` | `String` | Optional | - |
| `code` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "Message": null,
  "Code": null
}
```

