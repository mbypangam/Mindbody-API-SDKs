
# Mindbody Public Api Dto Models V6 Client Controller Get Memberships Response

## Structure

`MindbodyPublicApiDtoModelsV6ClientControllerGetMembershipsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `memberships` | [`Array<MindbodyPublicApiDtoModelsV6Membership>`](../../doc/models/mindbody-public-api-dto-models-v6-membership.md) | Optional | Details about the memberships. |

## Example (as JSON)

```json
{
  "Memberships": null
}
```

